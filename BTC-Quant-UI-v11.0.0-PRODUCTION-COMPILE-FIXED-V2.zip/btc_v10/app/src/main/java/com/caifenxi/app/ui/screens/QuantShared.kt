package com.caifenxi.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.caifenxi.app.domain.btc.BtcPlanFamily
import com.caifenxi.app.domain.btc.MarketRegime
import java.text.SimpleDateFormat
import java.util.Date

/** 量化 UI 共享辅助函数 */
@Composable
internal fun SectionTitleInline(text: String) {
    Text(text, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.padding(bottom = 6.dp))
}

@Composable
internal fun MetricLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

internal fun fmtTime(ts: Long): String =
    if (ts == 0L) "\u2014" else SimpleDateFormat("HH:mm:ss").format(Date(ts))

internal fun MarketRegime.label() = when (this) {
    MarketRegime.TREND_UP -> "趋势 \u00b7 多"
    MarketRegime.TREND_DOWN -> "趋势 \u00b7 空"
    MarketRegime.RANGE -> "震荡"
    MarketRegime.BREAKOUT -> "突破"
    MarketRegime.HIGH_VOLATILITY -> "高波动"
}

internal fun BtcPlanFamily.label() = when (this) {
    BtcPlanFamily.TREND -> "趋势"
    BtcPlanFamily.MOMENTUM -> "动量"
    BtcPlanFamily.STRUCTURE -> "结构"
    BtcPlanFamily.VOLUME -> "量价"
    BtcPlanFamily.VOLATILITY -> "波动"
    BtcPlanFamily.DERIVATIVES -> "衍生品"
    BtcPlanFamily.AI -> "AI"
}
