package com.caifenxi.app.data.config

import android.content.Context
import com.caifenxi.app.domain.model.ManualMark
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

class ManualStore(context: Context) {
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
    private val prefs = context.getSharedPreferences("caifenxi_manual", Context.MODE_PRIVATE)

    fun load(lotteryKey: String): Map<String, ManualMark> {
        val raw = prefs.getString(KEY, null) ?: return emptyMap()
        return try {
            json.decodeFromString<List<ManualMark>>(raw)
                .filter { it.lotteryKey == lotteryKey }
                .associateBy { it.category }
        } catch (_: Exception) {
            emptyMap()
        }
    }

    fun save(mark: ManualMark) {
        val all = loadAll().toMutableList()
        all.removeAll { it.lotteryKey == mark.lotteryKey && it.category == mark.category }
        all.add(mark)
        prefs.edit().putString(KEY, json.encodeToString(all.takeLast(200))).apply()
    }

    fun clear(lotteryKey: String) {
        val rest = loadAll().filter { it.lotteryKey != lotteryKey }
        prefs.edit().putString(KEY, json.encodeToString(rest)).apply()
    }

    private fun loadAll(): List<ManualMark> {
        val raw = prefs.getString(KEY, null) ?: return emptyList()
        return try {
            json.decodeFromString(raw)
        } catch (_: Exception) {
            emptyList()
        }
    }

    companion object {
        private const val KEY = "manual_marks"
    }
}
