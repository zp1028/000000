package com.caifenxi.app.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Circle
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import kotlinx.coroutines.delay
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.caifenxi.app.domain.btc.hs.BayesParticle
import com.caifenxi.app.domain.btc.hs.HsPredictionSnapshot
import com.caifenxi.app.domain.btc.hs.TimeframePhat
import com.caifenxi.app.ui.BtcQuantViewModel
import kotlin.math.cos
import kotlin.math.sin

/**
 * HS PREDICTION ENGINE 看板 —— 算法 + UI 全量对齐截图/视频
 */
@Composable
fun DashboardTab(viewModel: BtcQuantViewModel) {
    val state by viewModel.state.collectAsState()
    val exec by viewModel.executionStatus.collectAsState()
    val hs = state.hsSnapshot
    var timeframe by remember { mutableStateOf(state.timeframe.ifBlank { "15m" }) }

    val bg = Color(0xFF0A0A0F)
    val cardBg = Color(0xFF12121A)
    val border = Color(0xFF1E1E2A)
    val green = Color(0xFF00E676)
    val red = Color(0xFFFF5252)
    val cyan = Color(0xFF00E5FF)
    val muted = Color(0xFF6B7280)
    val textPrimary = Color(0xFFE5E7EB)

    val balance = hs?.balance ?: 0.0
    val available = hs?.available ?: 0.0
    val openNotional = hs?.openNotional ?: 0.0
    val todayPnl = hs?.todayPnl ?: 0.0
    val pnl30d = hs?.pnl30d ?: 0.0
    val maxDd = hs?.maxDrawdownPct ?: 0.0
    val p5 = hs?.tf5m?.pHat ?: 0.5
    val p15 = hs?.tf15m?.pHat ?: 0.5
    val p1h = hs?.tf1h?.pHat ?: 0.5
    val edge = (hs?.aggregateEdge ?: 0.0) * 100
    val trigger = hs?.bayesTrigger ?: 0.0
    val logs = hs?.engineLog ?: emptyList()

    Column(
        Modifier.fillMaxSize().background(bg).verticalScroll(rememberScrollState())
    ) {
        HsTopBar(
            updatedAt = hs?.updatedAt ?: state.updatedAt,
            edge = edge,
            dataMode = hs?.dataMode ?: "OFFLINE",
            onRefresh = { viewModel.refresh(timeframe = timeframe) },
            textPrimary = textPrimary, muted = muted, green = green
        )

        // 执行门控状态条
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 2.dp)
                .background(cardBg, RoundedCornerShape(8.dp))
                .padding(horizontal = 10.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            val liveOk = hs?.dataQuality?.liveTradeAllowed == true
            val kill = exec.killSwitch
            Text(
                when {
                    kill -> "KILL SWITCH ON"
                    !liveOk -> "GATE BLOCKED"
                    else -> "GATE OPEN"
                },
                color = when {
                    kill -> red
                    !liveOk -> red
                    else -> green
                },
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
            Text(
                exec.lastVerdictReason?.take(42) ?: (hs?.dataQuality?.blockReasons?.firstOrNull() ?: "ready"),
                color = muted,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                maxLines = 1
            )
        }

        Row(
            Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("TIMEFRAME", color = muted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
            listOf("5m", "15m", "1h").forEach { tf ->
                FilterChip(
                    selected = timeframe == tf,
                    onClick = {
                        timeframe = tf
                        viewModel.refresh(timeframe = tf)
                    },
                    label = { Text(tf, fontSize = 10.sp, fontFamily = FontFamily.Monospace) },
                    modifier = Modifier.height(30.dp)
                )
            }
        }

        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(10.dp, 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            MetricCard("BALANCE", "$${fmtMoney(balance)}", "现金 + 当前持仓价值", textPrimary, muted, cardBg, border)
            MetricCard("AVAILABLE", "$${fmtMoney(available)}", "CLOB cash balance", textPrimary, muted, cardBg, border)
            MetricCard("OPEN NOTIONAL", "$${fmtMoney(openNotional)}", "active positions value", textPrimary, muted, cardBg, border)
            MetricCard("TODAY PNL", "${if (todayPnl >= 0) "+" else ""}$${fmtMoney(todayPnl)}", "positions pnl", green, muted, cardBg, border, if (todayPnl >= 0) green else red)
            MetricCard("30D PNL", "${if (pnl30d >= 0) "+" else ""}$${fmtMoney(pnl30d)}", "closed positions", green, muted, cardBg, border, if (pnl30d >= 0) green else red)
            MetricCard("MAX DD", if (hs == null) "—" else "${"%.1f".format(maxDd)}%", if (hs?.dataMode == "PAPER") "paper account" else "account snapshots", if (hs == null) muted else red, muted, cardBg, border, if (hs == null) muted else red)
        }

        PolymarketTerminalPanel(
            panel = hs?.polymarketPanels?.get("5m"),
            currentPrice = hs?.markPrice ?: 0.0,
            cardBg = cardBg, border = border, textPrimary = textPrimary,
            muted = muted, green = green, red = red, cyan = cyan
        )

        Column(Modifier.padding(horizontal = 10.dp, vertical = 4.dp)) {
            SectionLabel("BTC DEPTH / POLY BOOK", muted)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                DepthFromPhat(hs?.tf5m, "5m", p5, cardBg, border, green, red, textPrimary, muted)
                DepthFromPhat(hs?.tf15m, "15m", p15, cardBg, border, green, red, textPrimary, muted)
                DepthFromPhat(hs?.tf1h, "1h", p1h, cardBg, border, green, red, textPrimary, muted)
            }
        }

        Row(
            Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 4.dp).height(140.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Column(Modifier.weight(1.4f)) {
                SectionLabel("EDGE + SPREAD", muted)
                EdgeSpreadChart(
                    Modifier.fillMaxWidth().height(110.dp).background(cardBg, RoundedCornerShape(8.dp))
                        .border(1.dp, border, RoundedCornerShape(8.dp)).padding(8.dp),
                    green, cyan, hs?.edgeHistory.orEmpty()
                )
            }
            Column(Modifier.weight(0.9f)) {
                SectionLabel("P(UP) / ASK / SPREAD ANALYSIS", muted)
                KellyPhatTable(hs?.tf5m, hs?.tf15m, p5, p15, cardBg, border, textPrimary, muted, green)
            }
        }

        SectionLabel("BAYES PARTICLE FIELD", muted, Modifier.padding(start = 10.dp, top = 6.dp))
        BayesParticleField(
            Modifier.fillMaxWidth().height(200.dp).padding(horizontal = 10.dp)
                .background(Color(0xFF08080C), RoundedCornerShape(8.dp))
                .border(1.dp, border, RoundedCornerShape(8.dp)),
            trigger = trigger,
            particles = hs?.particles.orEmpty(),
            bayesMean = hs?.bayesMean ?: 0.5,
            cyan = cyan, green = green, muted = muted
        )

        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatusChip("active 5m", green)
            StatusChip("p_hat ${"%.3f".format(p5)}", cyan)
            StatusChip("depth ${if (hs == null) "—" else "%,.2f".format(hs.tf5m.depthBid)}", muted)
            StatusChip("news ${"%.2f".format(hs?.newsScore ?: 0.0)}", muted)
            StatusChip("depth ${"%+.3f".format(hs?.binanceDepthImbalance ?: 0.0)}", muted)
            StatusChip("POLY ${if (hs?.polymarketBookLive == true) "LIVE" else "OFF"}", if (hs?.polymarketBookLive == true) green else muted)
            StatusChip("ORACLE ${if (hs?.oracleLive == true) "LIVE" else "OFF"}", if (hs?.oracleLive == true) green else muted)
            StatusChip("${hs?.tf15m?.action ?: "NO_DATA"}", if (hs?.tf15m?.action?.startsWith("BUY") == true) green else Color(0xFFFFAB00))
        }

        HsOpportunityPanel(
            hs = hs,
            cardBg = cardBg,
            border = border,
            textPrimary = textPrimary,
            muted = muted,
            green = green,
            red = red
        )

        Row(
            Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 4.dp).height(160.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Column(
                Modifier.weight(1f).fillMaxHeight().background(cardBg, RoundedCornerShape(8.dp))
                    .border(1.dp, border, RoundedCornerShape(8.dp)).padding(8.dp)
            ) {
                SectionLabel("ENGINE LOG", muted)
                logs.takeLast(6).forEach { line ->
                    Text(
                        line,
                        color = if (line.contains("PHAT") || line.contains("BAYES") || line.contains("SYNC")) green else textPrimary,
                        fontSize = 9.sp, fontFamily = FontFamily.Monospace,
                        maxLines = 1, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(vertical = 1.dp)
                    )
                }
            }
            Column(
                Modifier.weight(1.2f).fillMaxHeight().background(cardBg, RoundedCornerShape(8.dp))
                    .border(1.dp, border, RoundedCornerShape(8.dp)).padding(8.dp)
            ) {
                SectionLabel(
                    "PHAT PROBABILITY   5m ${"%.1f".format(p5 * 100)}% · 15m ${"%.1f".format(p15 * 100)}% · 1h ${"%.1f".format(p1h * 100)}%",
                    muted
                )
                PhatProbabilityChart(Modifier.fillMaxSize(), hs?.phatHistory ?: emptyMap(), green, cyan, Color(0xFFEF5350))
            }
            Column(
                Modifier.weight(0.85f).fillMaxHeight().background(cardBg, RoundedCornerShape(8.dp))
                    .border(1.dp, border, RoundedCornerShape(8.dp)).padding(8.dp)
            ) {
                SectionLabel("BOT STATUS", muted)
                BotStatusPanel(balance, available, p5, p15, p1h, textPrimary, muted, green)
            }
        }

        Text(
            "反正整个高频系统做下来 · HS Prediction Engine · ML p_hat · Bayes Particle · ½Kelly · GLM/GPT/FABLE5",
            color = muted, fontSize = 10.sp,
            modifier = Modifier.fillMaxWidth().padding(12.dp), textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun DepthFromPhat(
    tf: TimeframePhat?,
    label: String,
    fallbackP: Double,
    cardBg: Color, border: Color, green: Color, red: Color, textPrimary: Color, muted: Color
) {
    val p = tf?.pHat ?: fallbackP
    val bid = tf?.bestBid
    val ask = tf?.bestAsk
    val alpha = tf?.alpha ?: 0.0
    val spread = tf?.spread ?: 0.0
    Column(
        Modifier.width(110.dp).background(cardBg, RoundedCornerShape(6.dp))
            .border(1.dp, border, RoundedCornerShape(6.dp)).padding(8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(label, color = textPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Spacer(Modifier.weight(1f))
            Text("WATCH", color = muted, fontSize = 8.sp)
        }
        Text("Bitcoin Up or Down", color = muted, fontSize = 8.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Spacer(Modifier.height(4.dp))
        LinearProgressIndicator(
            progress = { p.toFloat() },
            modifier = Modifier.fillMaxWidth().height(4.dp),
            color = if (p > 0.5) green else red,
            trackColor = Color(0xFF1E1E2A)
        )
        Spacer(Modifier.height(4.dp))
        Text("p_hat ${"%.3f".format(p)}", color = textPrimary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
        Text("bid ${bid?.let { "%.3f".format(it) } ?: "—"}  ask ${ask?.let { "%.3f".format(it) } ?: "—"}", color = textPrimary, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
        Text("spread ${"%.3f".format(spread)}  netEdge ${"%+.3f".format(tf?.netEdge ?: 0.0)}", color = muted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
        Text("depth ${"%.0f".format(tf?.depthBid ?: 0.0)}/${"%.0f".format(tf?.depthAsk ?: 0.0)}", color = muted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
    }
}

@Composable
private fun KellyPhatTable(
    tf5: TimeframePhat?, tf15: TimeframePhat?,
    p5: Double, p15: Double,
    cardBg: Color, border: Color, textPrimary: Color, muted: Color, green: Color
) {
    Column(
        Modifier.fillMaxSize().background(cardBg, RoundedCornerShape(8.dp))
            .border(1.dp, border, RoundedCornerShape(8.dp)).padding(8.dp)
    ) {
        Text("CLASSIC_HIGH_P_HAT_INTERP", color = muted, fontSize = 8.sp)
        Spacer(Modifier.height(4.dp))
        TfRow("5m", tf5?.pHat ?: p5, tf5?.edgeAsk ?: 0.0, tf5?.kelly ?: 0.0, tf5?.bucket ?: 0.0, textPrimary, muted, green)
        Spacer(Modifier.height(6.dp))
        TfRow("15m", tf15?.pHat ?: p15, tf15?.edgeAsk ?: 0.0, tf15?.kelly ?: 0.0, tf15?.bucket ?: 0.0, textPrimary, muted, green)
    }
}

@Composable
private fun TfRow(label: String, pHat: Double, edgeAsk: Double, kelly: Double, bucket: Double, textPrimary: Color, muted: Color, green: Color) {
    Row(Modifier.fillMaxWidth()) {
        Text(label, color = textPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(28.dp))
        Text("p_hat", color = muted, fontSize = 9.sp, modifier = Modifier.width(36.dp))
        Text("%.3f".format(pHat), color = green, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.width(40.dp))
        Text("edgeAsk", color = muted, fontSize = 9.sp, modifier = Modifier.width(42.dp))
        Text("%+.3f".format(edgeAsk), color = green, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
    }
    Row(Modifier.fillMaxWidth()) {
        Spacer(Modifier.width(28.dp))
        Text("kelly", color = muted, fontSize = 9.sp, modifier = Modifier.width(36.dp))
        Text("%.3f".format(kelly), color = textPrimary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.width(40.dp))
        Text("bucket", color = muted, fontSize = 9.sp, modifier = Modifier.width(42.dp))
        Text("%.2f".format(bucket), color = textPrimary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
    }
}

@Composable
private fun HsOpportunityPanel(
    hs: HsPredictionSnapshot?,
    cardBg: Color, border: Color, textPrimary: Color, muted: Color, green: Color, red: Color
) {
    val explanation = hs?.decisionExplanation
    val score = hs?.opportunityScore ?: 0.0
    val quality = hs?.dataQualityScore ?: 0.0
    Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 3.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Column(
            Modifier.weight(1.1f).background(cardBg, RoundedCornerShape(8.dp)).border(1.dp, border, RoundedCornerShape(8.dp)).padding(10.dp)
        ) {
            SectionLabel("OPPORTUNITY / DECISION", muted)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(explanation?.decision ?: "NO_DATA", color = if (score >= .70) green else muted, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Spacer(Modifier.width(8.dp))
                Text(explanation?.direction ?: "—", color = textPrimary, fontSize = 12.sp)
                Spacer(Modifier.weight(1f))
                Text("${"%.0f".format(score * 100)}/100", color = textPrimary, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
            }
            Text(explanation?.headline ?: "等待真实市场数据", color = muted, fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(5.dp))
            LinearProgressIndicator(progress = { score.toFloat() }, modifier = Modifier.fillMaxWidth().height(4.dp), color = if (score >= .70) green else muted, trackColor = border)
            Spacer(Modifier.height(5.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("DATA ${"%.0f%%".format(quality * 100)}", color = if (quality >= .80) green else red, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                Text("EDGE ${"%+.2f%%".format((hs?.aggregateEdge ?: 0.0) * 100)}", color = textPrimary, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                Text("${hs?.tf15m?.action ?: "NO_DATA"}", color = muted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
            }
        }
        Column(
            Modifier.weight(1f).background(cardBg, RoundedCornerShape(8.dp)).border(1.dp, border, RoundedCornerShape(8.dp)).padding(10.dp)
        ) {
            SectionLabel("WHY / RISK", muted)
            (explanation?.reasons ?: listOf("暂无可解释信号")).take(3).forEach {
                Text("✓ $it", color = green, fontSize = 8.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            (explanation?.risks ?: emptyList()).take(2).forEach {
                Text("! $it", color = red, fontSize = 8.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
private fun HsTopBar(updatedAt: Long, edge: Double, dataMode: String, onRefresh: () -> Unit, textPrimary: Color, muted: Color, green: Color) {
    Row(
        Modifier.fillMaxWidth().background(Color(0xFF0D0D14)).padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(28.dp).background(Color(0xFF1A1A2E), RoundedCornerShape(6.dp)), contentAlignment = Alignment.Center) {
            Text("H", color = green, fontWeight = FontWeight.Black, fontSize = 16.sp)
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text("HS PREDICTION ENGINE  //  BTC 5m / 15m / 1h", color = textPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Row {
                listOf("总览", "市场", "交易记录", "接入", "管理", "文档").forEachIndexed { i, t ->
                    Text(t, color = if (i == 0) green else muted, fontSize = 11.sp, modifier = Modifier.padding(end = 10.dp))
                }
            }
        }
        Text("UPDATED ${if (updatedAt == 0L) "—" else fmtTime(updatedAt)}", color = muted, fontSize = 10.sp)
        Spacer(Modifier.width(8.dp))
        Box(Modifier.background(Color(0xFF0A2A1A), RoundedCornerShape(4.dp)).padding(horizontal = 6.dp, vertical = 2.dp)) {
            Text(dataMode, color = if (dataMode == "LIVE_ACCOUNT") green else muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.width(6.dp))
        Text("EDGE +${"%.1f".format(edge)}%", color = green, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.width(6.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.Circle, null, tint = green, modifier = Modifier.size(8.dp))
            Spacer(Modifier.width(3.dp))
            Text(if (dataMode == "LIVE_ACCOUNT") "LIVE" else dataMode, color = if (dataMode == "LIVE_ACCOUNT") green else muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        IconButton(onClick = onRefresh, modifier = Modifier.size(32.dp)) {
            Icon(Icons.Filled.Refresh, "刷新", tint = muted, modifier = Modifier.size(16.dp))
        }
    }
}

@Composable
private fun MetricCard(title: String, value: String, subtitle: String, textPrimary: Color, muted: Color, cardBg: Color, border: Color, valueColor: Color = textPrimary) {
    Column(Modifier.width(130.dp).background(cardBg, RoundedCornerShape(8.dp)).border(1.dp, border, RoundedCornerShape(8.dp)).padding(10.dp)) {
        Text(title, color = muted, fontSize = 9.sp, fontWeight = FontWeight.Medium, letterSpacing = 0.5.sp)
        Text(value, color = valueColor, fontSize = 18.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        Text(subtitle, color = muted, fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun EdgeSpreadChart(modifier: Modifier, green: Color, cyan: Color, edgeHistory: List<Double>) {
    Canvas(modifier) {
        val w = size.width; val h = size.height
        for (i in 1..4) drawLine(Color(0xFF1A1A28), Offset(0f, h * i / 5), Offset(w, h * i / 5), 1f)
        fun path(pts: List<Float>, c: Color, sw: Float) {
            val p = Path()
            pts.forEachIndexed { i, v ->
                val x = w * i / (pts.size - 1); val y = h * (1f - v)
                if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
            }
            drawPath(p, c, style = Stroke(sw, cap = StrokeCap.Round))
        }
        if (edgeHistory.size >= 2) {
            val pts = edgeHistory.takeLast(60).map { (0.5 + it * 4.0).coerceIn(0.05, 0.95).toFloat() }
            path(pts, green, 2f)
        }
        drawLine(Color(0xFF333344), Offset(0f, h * 0.5f), Offset(w, h * 0.5f), 1f)
    }
}

@Composable
private fun BayesParticleField(
    modifier: Modifier,
    trigger: Double,
    particles: List<BayesParticle>,
    bayesMean: Double,
    cyan: Color,
    green: Color,
    muted: Color
) {
    // 真实粒子：x = state（上涨概率），y 由 weight+velocity 映射；无数据时轻微抖动兜底
    val pts = remember(particles, bayesMean) {
        if (particles.isNotEmpty()) {
            particles.mapIndexed { i, p ->
                val nx = p.state.toFloat().coerceIn(0.02f, 0.98f)
                val ny = (0.5 + (p.velocity * 2.5) + ((i % 7) - 3) * 0.04).toFloat().coerceIn(0.08f, 0.92f)
                val a = (0.25f + p.weight.toFloat() * particles.size * 0.55f).coerceIn(0.15f, 0.95f)
                Triple(nx, ny, a)
            }
        } else emptyList()
    }
    Box(modifier) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width; val h = size.height
            // 以 bayesMean 为中心的径向辉光
            val cx = (bayesMean.toFloat().coerceIn(0.15f, 0.85f)) * w
            drawCircle(
                Brush.radialGradient(
                    listOf(Color(0xFF0A2A2A).copy(alpha = 0.45f), Color.Transparent),
                    Offset(cx, h * 0.45f),
                    w * 0.32f
                ),
                w * 0.32f,
                Offset(cx, h * 0.45f)
            )
            pts.forEach { (nx, ny, a) ->
                val r = 1.4f + a * 2.8f
                drawCircle(cyan.copy(alpha = a * 0.75f), r, Offset(nx * w, ny * h))
            }
            // 高权重点（weight 前 15%）用绿色标出
            val top = if (particles.isNotEmpty()) {
                particles.sortedByDescending { it.weight }.take((particles.size * 0.15).toInt().coerceAtLeast(3))
            } else emptyList()
            top.forEachIndexed { i, p ->
                val x = p.state.toFloat().coerceIn(0.05f, 0.95f) * w
                val y = (0.42f + (i % 5) * 0.03f) * h
                drawCircle(green.copy(alpha = 0.7f), 3.2f, Offset(x, y))
            }
        }
        if (pts.isEmpty()) Text("NO LIVE PARTICLES", color = muted, fontSize = 10.sp, modifier = Modifier.align(Alignment.Center))
        Text("BAYES", color = green, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.Center).offset(y = (-8).dp))
        Text("trigger +${"%.1f".format(trigger)}", color = cyan, fontSize = 10.sp, modifier = Modifier.align(Alignment.Center).offset(y = 10.dp))
        Text("mean ${"%.3f".format(bayesMean)}", color = muted, fontSize = 9.sp, modifier = Modifier.align(Alignment.TopEnd).padding(12.dp))
        Text("n=${particles.size.coerceAtLeast(pts.size)}", color = muted, fontSize = 9.sp, modifier = Modifier.align(Alignment.CenterEnd).padding(12.dp))
        Text("5m p_hat", color = muted, fontSize = 9.sp, modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 12.dp))
    }
}

@Composable
private fun PhatProbabilityChart(modifier: Modifier, history: Map<String, List<Double>>, green: Color, cyan: Color, red: Color) {
    Canvas(modifier) {
        val w = size.width; val h = size.height
        fun line(pts: List<Double>, c: Color) {
            if (pts.size < 2) return
            val p = Path()
            pts.forEachIndexed { i, v ->
                val x = w * i / (pts.size - 1f); val y = h * (1f - v.coerceIn(0.0, 1.0).toFloat())
                if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
            }
            drawPath(p, c, style = Stroke(1.8f, cap = StrokeCap.Round))
        }
        line(history["5m"].orEmpty(), green)
        line(history["15m"].orEmpty(), cyan)
        line(history["1h"].orEmpty(), red.copy(alpha = 0.8f))
    }
}

@Composable
private fun BotStatusPanel(balance: Double, available: Double, p5: Double, p15: Double, p1h: Double, textPrimary: Color, muted: Color, green: Color) {
    Column {
        listOf(
            "Balance" to "$${fmtMoney(balance)}",
            "Available" to "$${fmtMoney(available)}",
            "Trade Volume" to if (hs == null) "—" else "$${fmtMoney(hs.binanceDepthBid + hs.binanceDepthAsk)}",
            "DATA" to (hs?.dataMode ?: "OFFLINE"),
            "5m p_hat" to "${"%.3f".format(p5)} (${(p5 * 100).toInt()}%)",
            "15m p_hat" to "${"%.3f".format(p15)} (${(p15 * 100).toInt()}%)",
            "1h p_hat" to "${"%.3f".format(p1h)} (${(p1h * 100).toInt()}%)"
        ).forEach { (k, v) ->
            Row(Modifier.fillMaxWidth().padding(vertical = 1.dp)) {
                Text(k, color = muted, fontSize = 9.sp, modifier = Modifier.weight(1f))
                Text(v, color = if (k.contains("p_hat") || k.contains("API")) green else textPrimary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
            }
        }
        Spacer(Modifier.height(4.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(if (hs?.systemsOnline == true) "SYSTEMS ONLINE" else "SYSTEMS DEGRADED", color = muted, fontSize = 8.sp)
            Spacer(Modifier.weight(1f))
            Text(if (hs?.systemsOnline == true) "ON" else "OFF", color = if (hs?.systemsOnline == true) green else red, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable private fun SectionLabel(text: String, color: Color, modifier: Modifier = Modifier) {
    Text(text, color = color, fontSize = 9.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.8.sp, modifier = modifier.padding(bottom = 4.dp))
}

@Composable private fun StatusChip(text: String, color: Color) {
    Box(Modifier.background(color.copy(alpha = 0.12f), RoundedCornerShape(4.dp)).border(1.dp, color.copy(alpha = 0.3f), RoundedCornerShape(4.dp)).padding(horizontal = 8.dp, vertical = 3.dp)) {
        Text(text, color = color, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
    }
}

private fun fmtMoney(v: Double): String = "%,.0f".format(v)
private fun fmtTime(ts: Long): String =
    java.text.SimpleDateFormat("yyyy/MM/dd HH:mm:ss", java.util.Locale.US).format(java.util.Date(ts))


@Composable
private fun PolymarketTerminalPanel(
    panel: com.caifenxi.app.domain.btc.hs.HsPolymarketPanel?,
    currentPrice: Double,
    cardBg: Color,
    border: Color,
    textPrimary: Color,
    muted: Color,
    green: Color,
    red: Color,
    cyan: Color
) {
    if (panel == null) {
        Column(
            Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 5.dp)
                .background(cardBg, RoundedCornerShape(8.dp))
                .border(1.dp, border, RoundedCornerShape(8.dp)).padding(10.dp)
        ) {
            SectionLabel("POLYMARKET / BTC UP OR DOWN 5M", muted)
            Text("NO ACTIVE 5m MARKET", color = muted, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
            Text("未发现符合条件的实时市场；不会用本地数据冒充 Polymarket。", color = muted, fontSize = 10.sp)
        }
        return
    }

    var clock by remember(panel.market.conditionId) { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(panel.market.conditionId, panel.market.endDateMs) {
        while (true) {
            clock = System.currentTimeMillis()
            delay(1000L)
        }
    }
    val remaining = ((panel.market.endDateMs ?: clock) - clock).coerceAtLeast(0L)
    val mins = remaining / 60_000L
    val secs = (remaining / 1_000L) % 60L
    val yes = panel.market.yesPrice.coerceIn(0.0, 1.0)
    val no = panel.market.noPrice.coerceIn(0.0, 1.0)
    val yesAsk = panel.yesAsk
    val noAsk = panel.noAsk
    val yesBid = panel.yesBid
    val noBid = panel.noBid

    Column(
        Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 5.dp)
            .background(cardBg, RoundedCornerShape(8.dp))
            .border(1.dp, border, RoundedCornerShape(8.dp)).padding(10.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("POLYMARKET", color = textPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text("BTC UP OR DOWN 5M", color = cyan, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
            }
            Text("%02d:%02d".format(mins, secs), color = if (remaining < 30_000L) red else green, fontSize = 16.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
        }
        Text(panel.market.question, color = muted, fontSize = 10.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 5.dp))

        Row(Modifier.fillMaxWidth().padding(top = 9.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TerminalPriceBox("PRICE TO BEAT", panel.market.priceToBeat, textPrimary, muted, Modifier.weight(1f))
            TerminalPriceBox("CURRENT BTC", currentPrice.takeIf { it > 0.0 }, textPrimary, muted, Modifier.weight(1f))
            TerminalPriceBox("DELTA", panel.market.priceToBeat?.let { currentPrice - it }, if ((panel.market.priceToBeat ?: currentPrice) <= currentPrice) green else red, muted, Modifier.weight(1f), signed = true)
        }

        Row(Modifier.fillMaxWidth().padding(top = 9.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            OutcomeQuote("UP", yes, yesBid, yesAsk, green, cardBg, border, textPrimary, muted, Modifier.weight(1f))
            OutcomeQuote("DOWN", no, noBid, noAsk, red, cardBg, border, textPrimary, muted, Modifier.weight(1f))
        }

        Text("ORDER BOOK", color = muted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.padding(top = 9.dp))
        Row(Modifier.fillMaxWidth().padding(top = 3.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            BookMiniColumn("UP BIDS", panel.yesBids.sortedByDescending { it.price }.take(3), green, textPrimary, muted, Modifier.weight(1f))
            BookMiniColumn("UP ASKS", panel.yesAsks.sortedBy { it.price }.take(3), red, textPrimary, muted, Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            BookMiniColumn("DOWN BIDS", panel.noBids.sortedByDescending { it.price }.take(3), green, textPrimary, muted, Modifier.weight(1f))
            BookMiniColumn("DOWN ASKS", panel.noAsks.sortedBy { it.price }.take(3), red, textPrimary, muted, Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            StatusChip(if (panel.bookLive) "CLOB LIVE" else "CLOB PARTIAL", if (panel.bookLive) green else muted)
            Spacer(Modifier.weight(1f))
            Text("snapshot ${panel.fetchedAt}", color = muted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
        }
    }
}

@Composable
private fun TerminalPriceBox(title: String, value: Double?, valueColor: Color, muted: Color, modifier: Modifier, signed: Boolean = false) {
    Column(modifier.background(Color(0xFF0D0D13), RoundedCornerShape(6.dp)).padding(7.dp)) {
        Text(title, color = muted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
        Text(value?.let { if (signed) "%+.2f".format(it) else "$${"%,.2f".format(it)}" } ?: "—", color = valueColor, fontSize = 12.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun OutcomeQuote(title: String, probability: Double, bid: Double?, ask: Double?, accent: Color, cardBg: Color, border: Color, textPrimary: Color, muted: Color, modifier: Modifier) {
    Column(modifier.background(cardBg, RoundedCornerShape(6.dp)).border(1.dp, border, RoundedCornerShape(6.dp)).padding(8.dp)) {
        Text(title, color = accent, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        Text("${"%.0f".format(probability * 100)}¢", color = textPrimary, fontSize = 18.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
        Text("B ${bid?.let { "%.3f".format(it) } ?: "—"}  A ${ask?.let { "%.3f".format(it) } ?: "—"}", color = muted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
    }
}

@Composable
private fun BookMiniColumn(title: String, levels: List<com.caifenxi.app.domain.btc.polymarket.PolyBookLevel>, accent: Color, textPrimary: Color, muted: Color, modifier: Modifier) {
    Column(modifier) {
        Text(title, color = accent, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
        levels.forEach { level ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("%.3f".format(level.price), color = textPrimary, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                Text("%.1f".format(level.size), color = muted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
            }
        }
        if (levels.isEmpty()) Text("—", color = muted, fontSize = 8.sp)
    }
}
