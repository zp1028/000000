package com.caifenxi.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import com.caifenxi.app.ui.components.GlobalCard
import com.caifenxi.app.ui.theme.CaiTokens

/**
 * 旧版网页执行页占位。正式入口请用底部导航「网页」→ [WebBetScreen]。
 */
@Composable
fun WebExecutorScreen() {
    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = CaiTokens.ScreenHPadding, vertical = CaiTokens.S16)
    ) {
        Text("网页执行（旧入口）", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(CaiTokens.S16))
        GlobalCard {
            Text("请使用底部导航「网页」进入全屏执行台。", fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(CaiTokens.S8))
            Text(
                "该页仅作兼容占位，避免旧路由编译失败。",
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
