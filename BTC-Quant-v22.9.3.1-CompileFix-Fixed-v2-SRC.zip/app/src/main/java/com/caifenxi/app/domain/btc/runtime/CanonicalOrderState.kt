package com.caifenxi.app.domain.btc.runtime

/** Single canonical order lifecycle for Binance/Polymarket/PAPER adapters. UNKNOWN is frozen. */
enum class CanonicalOrderState {
    CREATED, SUBMITTING, OPEN, PARTIAL, FILLED,
    CANCEL_REQUESTED, CANCELED, REJECTED, EXPIRED,
    REPLACE_REQUESTED, REPLACED, UNKNOWN, ERROR
}

object CanonicalOrderStateMachine {
    private val allowed = mapOf(
        CanonicalOrderState.CREATED to setOf(CanonicalOrderState.SUBMITTING, CanonicalOrderState.REJECTED, CanonicalOrderState.UNKNOWN),
        CanonicalOrderState.SUBMITTING to setOf(CanonicalOrderState.OPEN, CanonicalOrderState.PARTIAL, CanonicalOrderState.FILLED, CanonicalOrderState.REJECTED, CanonicalOrderState.UNKNOWN),
        CanonicalOrderState.OPEN to setOf(CanonicalOrderState.PARTIAL, CanonicalOrderState.FILLED, CanonicalOrderState.CANCEL_REQUESTED, CanonicalOrderState.REPLACE_REQUESTED, CanonicalOrderState.EXPIRED, CanonicalOrderState.UNKNOWN),
        CanonicalOrderState.PARTIAL to setOf(CanonicalOrderState.PARTIAL, CanonicalOrderState.FILLED, CanonicalOrderState.CANCEL_REQUESTED, CanonicalOrderState.REPLACE_REQUESTED, CanonicalOrderState.EXPIRED, CanonicalOrderState.UNKNOWN),
        CanonicalOrderState.FILLED to emptySet(),
        CanonicalOrderState.CANCEL_REQUESTED to setOf(CanonicalOrderState.CANCELED, CanonicalOrderState.FILLED, CanonicalOrderState.PARTIAL, CanonicalOrderState.UNKNOWN),
        CanonicalOrderState.REPLACE_REQUESTED to setOf(CanonicalOrderState.CANCELED, CanonicalOrderState.EXPIRED, CanonicalOrderState.REPLACED, CanonicalOrderState.UNKNOWN),
        CanonicalOrderState.CANCELED to emptySet(),
        CanonicalOrderState.REJECTED to emptySet(),
        CanonicalOrderState.EXPIRED to emptySet(),
        CanonicalOrderState.REPLACED to setOf(CanonicalOrderState.OPEN, CanonicalOrderState.PARTIAL, CanonicalOrderState.FILLED, CanonicalOrderState.UNKNOWN),
        CanonicalOrderState.UNKNOWN to setOf(CanonicalOrderState.OPEN, CanonicalOrderState.PARTIAL, CanonicalOrderState.FILLED, CanonicalOrderState.CANCELED, CanonicalOrderState.REJECTED, CanonicalOrderState.EXPIRED, CanonicalOrderState.UNKNOWN),
        CanonicalOrderState.ERROR to setOf(CanonicalOrderState.UNKNOWN, CanonicalOrderState.REJECTED)
    )

    fun canTransition(from: CanonicalOrderState, to: CanonicalOrderState): Boolean = from == to || allowed[from].orEmpty().contains(to)
    fun requireTransition(from: CanonicalOrderState, to: CanonicalOrderState) {
        require(canTransition(from, to)) { "非法订单状态迁移: $from -> $to" }
    }
}
