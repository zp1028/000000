package com.caifenxi.app.domain.btc.research

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Durable research lineage used by the runtime after process/service restart. */
class QuantResearchLifecycleStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("btc_quant_research_lifecycle_v1", Context.MODE_PRIVATE)

    fun save(decisions: Collection<QuantResearchLifecycleEngine.Decision>, datasetCutoffMs: Long, nowMs: Long = System.currentTimeMillis()) {
        val arr = JSONArray()
        decisions.forEach { d ->
            arr.put(JSONObject().apply {
                put("id", d.id); put("status", d.status.name); put("multiplier", d.weightMultiplier)
                put("score", d.score); put("reason", d.reason); put("evaluatedAt", d.evaluatedAtMs)
            })
        }
        prefs.edit().putString("decisions", arr.toString()).putLong("datasetCutoffMs", datasetCutoffMs).putLong("updatedAt", nowMs).apply()
    }

    fun load(): List<QuantResearchLifecycleEngine.Decision> = runCatching {
        val arr = JSONArray(prefs.getString("decisions", "[]"))
        buildList {
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                add(QuantResearchLifecycleEngine.Decision(
                    o.getString("id"), QuantResearchLifecycleEngine.Status.valueOf(o.getString("status")),
                    o.getDouble("multiplier"), o.getDouble("score"), o.getString("reason"), o.optLong("evaluatedAt", 0L)
                ))
            }
        }
    }.getOrDefault(emptyList())

    fun datasetCutoffMs(): Long = prefs.getLong("datasetCutoffMs", 0L)
}
