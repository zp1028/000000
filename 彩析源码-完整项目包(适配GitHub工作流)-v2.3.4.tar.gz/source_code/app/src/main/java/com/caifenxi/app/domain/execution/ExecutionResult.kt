package com.caifenxi.app.domain.execution

/**
 * 执行结果（ActionResult 校验通过后的最终结果）。
 *
 * SUCCESS / FAILED / UNKNOWN / TIMEOUT / DUPLICATE / EXPIRED / CANCELLED / WEBVIEW_DISCONNECTED
 *
 * 注意：动作成功（点了按钮）≠ 执行成功（页面状态确认），
 * 只有 ExecutionVerifier 校验通过才能返回 SUCCESS。
 */
data class ExecutionResult(
    val cmdId: String,
    val success: Boolean,
    val message: String,
    val errorType: String? = null,
    val durationMs: Long = 0L,
    val actionResults: List<ActionResult> = emptyList()
) {
    enum class ResultCode {
        SUCCESS,
        FAILED,
        UNKNOWN,
        TIMEOUT,
        DUPLICATE,
        EXPIRED,
        CANCELLED,
        WEBVIEW_DISCONNECTED
    }

    companion object {
        const val PAGE_NOT_READY = "PAGE_NOT_READY"
        const val LOGIN_REQUIRED = "LOGIN_REQUIRED"
        const val LOTTERY_MISMATCH = "LOTTERY_MISMATCH"
        const val ISSUE_MISMATCH = "ISSUE_MISMATCH"
        const val ELEMENT_NOT_FOUND = "ELEMENT_NOT_FOUND"
        const val ACTION_FAILED = "ACTION_FAILED"
        const val VERIFY_FAILED = "VERIFY_FAILED"
        const val TIMEOUT = "TIMEOUT"
        const val NETWORK_ERROR = "NETWORK_ERROR"
        const val WEBVIEW_DISCONNECTED = "WEBVIEW_DISCONNECTED"
        const val DUPLICATE_COMMAND = "DUPLICATE_COMMAND"
        const val COMMAND_EXPIRED = "COMMAND_EXPIRED"
        const val UNKNOWN_RESULT = "UNKNOWN_RESULT"
        const val CANCELLED = "CANCELLED"

        fun ok(cmdId: String, message: String = "执行成功", durationMs: Long = 0L) =
            ExecutionResult(cmdId, true, message, durationMs = durationMs)

        fun fail(cmdId: String, errorType: String, message: String, durationMs: Long = 0L) =
            ExecutionResult(cmdId, false, message, errorType, durationMs)

        fun unknown(cmdId: String, message: String = "结果未知，需查询执行状态") =
            ExecutionResult(cmdId, false, message, UNKNOWN_RESULT)

        fun timeout(cmdId: String, message: String = "执行超时，结果未知") =
            ExecutionResult(cmdId, false, message, TIMEOUT)
    }
}

/** 单步动作结果（点击到按钮 ≠ 执行成功） */
data class ActionResult(
    val category: String,
    val value: String,
    val success: Boolean,
    val message: String = "",
    val durationMs: Long = 0L
)
