# BTC Quant v13 重构说明

## 1. 三大页面
- 二元预测：二元预测、Edge、赔率、二元执行与自动运行全部归属本页。
- 模拟：虚拟账户与模拟交易环境归属本页。
- 量化合约：合约运行、策略回测、策略研究归属本页；不再通过其它顶级页面控制合约。

## 2. 合约配置持久化
新增 `FuturesQuantConfigStore`，合约配置不再使用 `FuturesQuantConfig()` 作为运行时唯一来源。
配置保存包括杠杆、仓位比例、ATR止损/止盈、追踪止损、保证金模式、最低置信度、日损、回撤、最大持仓、最大杠杆、资金费率套利、多档止盈、交易品种等。

追踪止损关闭使用显式 `trailingStopEnabled=false`，不会再因为 nullable 参数回退到旧值。

## 3. 合约后台运行隔离
新增独立 `FuturesQuantRuntimeService` 与 `btc_futures_runtime` 状态空间。
二元预测的运行时与合约运行时不再共享同一套启动/停止状态。

合约页面的自动挂机启动前台服务，离开页面后仍由 Service 驱动；页面只负责观察与控制。

## 4. 实盘参数贯通
`BtcRuntimeController` 增加可选 futures config provider。
合约挂机使用持久化合约配置覆盖信号工厂默认 ATR 止损/止盈与杠杆，并根据账户权益与 positionSizePct 重新计算目标仓位。

## 5. 回测/研究入口
量化合约页面内部保留三个工作区：
- 合约运行
- 策略回测
- 策略研究

它们属于同一个量化合约工作台，不再作为互相独立的顶级页面。

## 6. 构建验证
本环境无法访问 services.gradle.org，因此无法在当前沙箱完成 Gradle 8.9 下载与 APK 编译。源码修改已完成，建议在已有 Gradle 缓存的 Android/GitHub Actions 环境执行 `./gradlew :app:assembleDebug`。

## v13.1 Quant execution completion pass

- 自动合约执行路径收口到 `FuturesQuantRuntimeService`，`BtcQuantViewModel.tickFuturesQuant()` 不再因 UI refresh 直接下单，避免前台刷新与后台服务双执行。
- “手动开仓”改为一次性 `manualFuturesOpen()`，不会隐式打开后台自动模式。
- 合约后台增加 15m/1h 高周期过滤：基础周期负责入场与 ATR，15m/1h 负责趋势一致性；至少两个高周期反向时拒绝执行。
- 合约运行增加日损百分比、峰值回撤硬闸门，并继续保留原有日损 USDT、名义价值、概率、连续失败、LIVE 授权、SL/TP 等保护。
- 回测执行模型增加 spread、signal-to-fill latency、最大名义占比、部分成交系数；修正 latency 后退出区间计算。
- 回测增加 Bootstrap/Monte-Carlo 路径压力测试接口：中位收益、P05/P95、回撤中位数、亏损概率。
- 以上修改均直接同步进源码，不使用外置补丁。
