package com.caifenxi.app.domain.btc.hs

import android.content.Context

/** 持久化 HsRuntimeConfig，供设置页与引擎共用 */
class HsRuntimeConfigStore(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences("hs_runtime_config_v1", Context.MODE_PRIVATE)

    fun load(): HsRuntimeConfig {
        if (!sp.contains("feeRate")) return HsRuntimeConfig.Default
        return HsRuntimeConfig(
            feeRate = sp.getFloat("feeRate", 0.01f).toDouble(),
            latencySec = sp.getFloat("latencySec", 2f).toDouble(),
            minNetEdge = sp.getFloat("minNetEdge", 0.03f).toDouble(),
            kellyFraction = sp.getFloat("kellyFraction", 0.5f).toDouble(),
            maxRiskFraction = sp.getFloat("maxRiskFraction", 0.02f).toDouble(),
            maxNotionalUsdt = sp.getFloat("maxNotionalUsdt", 200f).toDouble(),
            minNotionalUsdt = sp.getFloat("minNotionalUsdt", 1f).toDouble(),
            minDataQualityForLive = sp.getFloat("minDataQualityForLive", 0.75f).toDouble(),
            minOpportunityScore = sp.getFloat("minOpportunityScore", 0.60f).toDouble(),
            minModelHitRate = sp.getFloat("minModelHitRate", 0.52f).toDouble(),
            maxBrierScore = sp.getFloat("maxBrierScore", 0.25f).toDouble(),
            mlCacheTtlMs = sp.getLong("mlCacheTtlMs", 55_000L),
            dailyLossKillPct = sp.getFloat("dailyLossKillPct", 0.05f).toDouble()
        )
    }

    fun save(c: HsRuntimeConfig) {
        sp.edit()
            .putFloat("feeRate", c.feeRate.toFloat())
            .putFloat("latencySec", c.latencySec.toFloat())
            .putFloat("minNetEdge", c.minNetEdge.toFloat())
            .putFloat("kellyFraction", c.kellyFraction.toFloat())
            .putFloat("maxRiskFraction", c.maxRiskFraction.coerceIn(0.005, 0.05).toFloat())
            .putFloat("maxNotionalUsdt", c.maxNotionalUsdt.toFloat())
            .putFloat("minNotionalUsdt", c.minNotionalUsdt.toFloat())
            .putFloat("minDataQualityForLive", c.minDataQualityForLive.toFloat())
            .putFloat("minOpportunityScore", c.minOpportunityScore.toFloat())
            .putFloat("minModelHitRate", c.minModelHitRate.toFloat())
            .putFloat("maxBrierScore", c.maxBrierScore.toFloat())
            .putLong("mlCacheTtlMs", c.mlCacheTtlMs)
            .putFloat("dailyLossKillPct", c.dailyLossKillPct.toFloat())
            .apply()
    }
}
