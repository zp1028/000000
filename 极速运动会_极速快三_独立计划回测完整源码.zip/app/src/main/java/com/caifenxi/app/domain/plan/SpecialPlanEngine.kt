package com.caifenxi.app.domain.plan

import com.caifenxi.app.domain.model.DrawRecord
import com.caifenxi.app.domain.model.PlanDefinition

/** 新彩种专用预测/结算：只读取当前彩种 numbers，不使用旧彩种 dx/ds/combo。 */
object SpecialPlanEngine {
    fun predict(plan: PlanDefinition, history: List<DrawRecord>, outputCount: Int = 1): String? {
        val data = history.filter { it.lotteryKey == plan.lotteryKey }.takeLast(plan.window.coerceAtLeast(5))
        if (data.size < 5) return null
        val algoSalt = kotlin.math.abs(plan.planId.hashCode())
        val values: List<String> = when (plan.playType) {
            "定位大小" -> data.mapNotNull { it.numberAt(plan.positionIndex) }.map { if (it >= 4) "大" else "小" }
            "定位单双" -> data.mapNotNull { it.numberAt(plan.positionIndex) }.map { if (it % 2 == 1) "单" else "双" }
            "定位号码" -> data.mapNotNull { it.numberAt(plan.positionIndex) }.map(Int::toString)
            "龙虎" -> data.mapNotNull { row ->
                val pair = when (plan.positionIndex) { 0 -> 0 to 5; 1 -> 1 to 4; 2 -> 2 to 3; else -> return@mapNotNull null }
                val a = row.numberAt(pair.first) ?: return@mapNotNull null
                val b = row.numberAt(pair.second) ?: return@mapNotNull null
                if (a == b) "和" else if (a > b) "龙" else "虎"
            }
            "三军" -> data.map { row -> row.numbers.groupingBy { it }.eachCount().maxByOrNull { it.value }?.key?.toString() ?: "1" }
            "和值大小" -> data.mapNotNull { it.numbers.takeIf { n -> n.size >= 3 }?.sum()?.let { s -> if (s >= 11) "大" else "小" } }
            "鱼虾蟹" -> data.mapNotNull { row -> row.numbers.firstOrNull()?.let { when (it) { 1 -> "鱼"; 2 -> "虾"; 3 -> "蟹"; else -> null } } }
            "长牌" -> data.mapNotNull { row ->
                if (row.numbers.size >= 3) {
                    val distinct = row.numbers.distinct().sorted()
                    if (distinct.size >= 2) "${'$'}{distinct[0]}${'$'}{distinct[1]}" else null
                } else null
            }
            else -> emptyList()
        }
        if (values.isEmpty()) return null
        val counts = values.groupingBy { it }.eachCount()
        val ranked = counts.entries.sortedWith(compareByDescending<Map.Entry<String,Int>> { it.value }.thenBy { kotlin.math.abs(it.key.hashCode() xor algoSalt) })
        return ranked.take(outputCount.coerceIn(1, 6)).joinToString("/") { it.key }
    }

    fun evaluate(planId: String, parts: List<String>, actual: DrawRecord): Boolean {
        val plan = SpecialPlanPool.ALL.firstOrNull { it.planId == planId } ?: return false
        if (actual.lotteryKey != plan.lotteryKey) return false
        return when (plan.playType) {
            "定位大小" -> { val n=actual.numberAt(plan.positionIndex) ?: return false; parts.any { it == if(n>=4) "大" else "小" } }
            "定位单双" -> { val n=actual.numberAt(plan.positionIndex) ?: return false; parts.any { it == if(n%2==1) "单" else "双" } }
            "定位号码" -> { val n=actual.numberAt(plan.positionIndex) ?: return false; parts.any { it.toIntOrNull()==n } }
            "龙虎" -> {
                val pair=when(plan.positionIndex){0->0 to 5;1->1 to 4;2->2 to 3;else->return false}; val a=actual.numberAt(pair.first)?:return false; val b=actual.numberAt(pair.second)?:return false
                if(a==b) false else parts.any { it==(if(a>b) "龙" else "虎") }
            }
            "三军" -> parts.any { it.toIntOrNull()?.let { n -> actual.numbers.count { x -> x==n } > 0 } == true }
            "和值大小" -> { val s=actual.numbers.sum(); parts.any { it==(if(s>=11) "大" else "小") } }
            "鱼虾蟹" -> { val map=mapOf(1 to "鱼",2 to "虾",3 to "蟹"); parts.any { p -> actual.numbers.any { map[it]==p } } }
            "长牌" -> {
                if (actual.numbers.size < 3) false else {
                    val distinct = actual.numbers.distinct().sorted()
                    if (distinct.size < 2) false else parts.contains("${'$'}{distinct[0]}${'$'}{distinct[1]}")
                }
            }
            else -> false
        }
    }
}
