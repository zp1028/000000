package com.caifenxi.app.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.caifenxi.app.domain.model.DrawRecord
import com.caifenxi.app.domain.model.PlanDefinition
import com.caifenxi.app.domain.model.PlanRuntime
import com.caifenxi.app.domain.plan.AlgoChartPlans
import com.caifenxi.app.domain.plan.LotteryPlanPools
import com.caifenxi.app.domain.plan.NovaPlanAnalytics
import com.caifenxi.app.domain.plan.PlanPool
import com.caifenxi.app.ui.MainViewModel
import com.caifenxi.app.ui.components.CaptionMuted
import com.caifenxi.app.ui.components.GlobalCard
import com.caifenxi.app.ui.components.PageHeader
import com.caifenxi.app.ui.components.PrimaryButton
import com.caifenxi.app.ui.theme.CaiTokens

private enum class WorkbenchTab(val label: String) {
    DETAIL("计划详情"),
    REVERSE("相反计划"),
    HISTORY("历史开奖"),
    TREND("计划走势"),
    GUIDE("计划攻略")
}

private enum class WorkbenchSource(val label: String) {
    ALL("全部计划"), LEGACY("原计划"), NOVA("新计划"), CANDIDATE("候选池"), CUSTOM("自定义"), MODEL("算法模型")
}

private enum class WorkbenchLevel(val label: String, val source: WorkbenchSource?) {
    HALL("计划大厅", null), BASIC("基础计划", WorkbenchSource.LEGACY), COMBO("组合计划", WorkbenchSource.NOVA), EXTREME("极限方案", WorkbenchSource.CANDIDATE)
}

private enum class LeaderboardTab(val label: String) {
    HIT_STREAK("最高连中"), HIT_RATE("最高胜率"), MISS_STREAK("最高连挂"),
    CURRENT_HIT("当前连中"), CURRENT_MISS("当前连挂")
}

@Composable
fun PlanWorkbenchScreen(vm: MainViewModel) {
    var source by remember { mutableStateOf(WorkbenchSource.ALL) }
    var level by remember { mutableStateOf(WorkbenchLevel.HALL) }
    var category by remember { mutableStateOf("全部") }
    var positionFilter by remember { mutableStateOf("全部") }
    var selectedId by remember { mutableStateOf<String?>(null) }
    var tab by remember { mutableStateOf(WorkbenchTab.DETAIL) }
    var leaderboardTab by remember { mutableStateOf(LeaderboardTab.HIT_STREAK) }
    var periods by remember { mutableStateOf(500) }
    var resultLimit by remember { mutableStateOf(50) }
    var cycleFilter by remember { mutableStateOf(0) }
    /** 当前连中跳最小值：0=不限，≥N 则只显示当前连中 ≥ N 的计划 */
    var minCurrentHit by remember { mutableStateOf(0) }
    /** 当前连挂跳最小值：0=不限，≥N 则只显示当前连挂 ≥ N 的计划 */
    var minCurrentMiss by remember { mutableStateOf(0) }
    var report by remember { mutableStateOf<NovaPlanAnalytics.ChartReport?>(null) }
    var running by remember { mutableStateOf(false) }

    val lottery = vm.currentLottery.value
    val history = vm.history.value.sortedWith(compareBy<DrawRecord> { it.issue.toLongOrNull() ?: Long.MIN_VALUE }.thenBy { it.issue })
    val custom = vm.customPlans.value.filter { it.lotteryKey == lottery.key }.map { it.toDefinition() }
    val generated = vm.planVM.generatedNovaPlans.value.filter { LotteryPlanPools.belongsTo(it, lottery.type) }
    val nova = (LotteryPlanPools.novaPlansFor(lottery.type) + generated).distinctBy { it.planId }
    val candidates = when (lottery.type) {
        com.caifenxi.app.domain.model.LotteryType.PKS -> com.caifenxi.app.domain.plan.NovaPlanPool.CANDIDATES
        com.caifenxi.app.domain.model.LotteryType.YDH -> com.caifenxi.app.domain.plan.NovaYdhPlanPool.CANDIDATES
        com.caifenxi.app.domain.model.LotteryType.K3 -> com.caifenxi.app.domain.plan.NovaK3PlanPool.CANDIDATES
        com.caifenxi.app.domain.model.LotteryType.PC28 -> com.caifenxi.app.domain.plan.NovaPc28PlanPool.CANDIDATES
        com.caifenxi.app.domain.model.LotteryType.LUCK20 -> com.caifenxi.app.domain.plan.NovaLuck20PlanPool.CANDIDATES
        else -> emptyList()
    }
    val legacy = LotteryPlanPools.legacyPlansFor(lottery.type)
    val models = if (lottery.type.name in listOf("YDH", "K3")) emptyList() else AlgoChartPlans.EXPERIENCE + AlgoChartPlans.PATTERN + AlgoChartPlans.FUSION

    val all = (legacy + nova + custom + models).distinctBy { it.planId }
    val sourcePlans = when (source) {
        WorkbenchSource.ALL -> all
        WorkbenchSource.LEGACY -> legacy
        WorkbenchSource.NOVA -> nova
        WorkbenchSource.CANDIDATE -> candidates
        WorkbenchSource.CUSTOM -> custom
        WorkbenchSource.MODEL -> models
    }
    val favoriteIds = vm.favoritePlanIds(lottery.key)
    val playOptions = listOf("全部") + sourcePlans.map { it.playType }.distinct().sorted()
    val positionOptions = listOf("全部") + sourcePlans.mapNotNull { p ->
        if (p.positionIndex >= 0) "位置${p.positionIndex + 1}" else null
    }.distinct().sortedBy { it.removePrefix("位置").toIntOrNull() ?: 0 }
    val filtered = sourcePlans.asSequence()
        .filter { category == "全部" || category == "★ 收藏" || it.playType == category }
        .filter { positionFilter == "全部" || "位置${it.positionIndex + 1}" == positionFilter }
        .filter { cycleFilter == 0 || it.cyclePeriods == cycleFilter }
        .let { seq -> if (category == "★ 收藏") seq.filter { it.planId in favoriteIds } else seq }
        .let { seq ->
            if (minCurrentHit > 0 || minCurrentMiss > 0) {
                seq.filter { p ->
                    val rt = vm.planVM.runtimeForPlan(p.planId)
                    (minCurrentHit == 0 || rt.consecutiveHit >= minCurrentHit) &&
                        (minCurrentMiss == 0 || rt.consecutiveMiss >= minCurrentMiss)
                }
            } else seq
        }
        .take(resultLimit)
        .toList()
    val selected = filtered.firstOrNull { it.planId == selectedId } ?: filtered.firstOrNull()
    val leaderboardRows = filtered.map { p -> p to vm.planVM.runtimeForPlan(p.planId) }
        .sortedWith(when (leaderboardTab) {
            LeaderboardTab.HIT_STREAK -> compareByDescending<Pair<PlanDefinition, PlanRuntime>> { it.second.maxConsecutiveHit }.thenByDescending { it.second.hitRate }.thenByDescending { it.second.sampleCount }
            LeaderboardTab.HIT_RATE -> compareByDescending<Pair<PlanDefinition, PlanRuntime>> { if (it.second.sampleCount >= 5) it.second.hitRate else -1.0 }.thenByDescending { it.second.score }.thenByDescending { it.second.sampleCount }
            LeaderboardTab.MISS_STREAK -> compareByDescending<Pair<PlanDefinition, PlanRuntime>> { it.second.maxConsecutiveMiss }.thenByDescending { it.second.sampleCount }
            LeaderboardTab.CURRENT_HIT -> compareByDescending<Pair<PlanDefinition, PlanRuntime>> { it.second.consecutiveHit }.thenByDescending { it.second.maxConsecutiveHit }.thenByDescending { it.second.sampleCount }
            LeaderboardTab.CURRENT_MISS -> compareByDescending<Pair<PlanDefinition, PlanRuntime>> { it.second.consecutiveMiss }.thenByDescending { it.second.maxConsecutiveMiss }.thenByDescending { it.second.sampleCount }
        }).take(20)

    LaunchedEffect(lottery.key, all.size, candidates.size) {
        vm.pruneFavoritePlans((all + candidates + custom + models).map { it.planId }.toSet(), lottery.key)
    }

    LaunchedEffect(source, level, category, positionFilter, cycleFilter, minCurrentHit, minCurrentMiss, filtered.size, lottery.key) {
        if (selectedId !in filtered.map { it.planId }) selectedId = filtered.firstOrNull()?.planId
    }

    LaunchedEffect(lottery.key) {
        vm.loadCustomPlans()
        selectedId = null
        report = null
    }

    fun runPlanBacktest(plan: PlanDefinition) {
        if (history.size < 6) return
        running = true
        // 工作台只做历史统计，不改变原计划/Nova计划的运行态和共识状态。
        report = NovaPlanAnalytics.chartBacktest(
            plan = plan,
            history = history,
            periods = periods,
            stake = 10.0,
            stage = 1,
            invert = false,
            outputCount = when (plan.playType) { "组合" -> vm.prefs.value.comboPredCount; "数字", "位置", "定位" -> vm.prefs.value.positionTopN; else -> null }
        )
        running = false
    }

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = CaiTokens.S12, vertical = CaiTokens.S8),
        verticalArrangement = Arrangement.spacedBy(CaiTokens.S8),
        contentPadding = PaddingValues(bottom = CaiTokens.ScreenBottom)
    ) {
        item {
            GlobalCard {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(lottery.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        CaptionMuted("计划工作台 · ${com.caifenxi.app.domain.model.LotteryPlayCatalog.summaryText(lottery.type)}")
                    }
                    Text("★ ${favoriteIds.size}", color = CaiTokens.Warning, fontWeight = FontWeight.Bold)
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                WorkbenchLevel.entries.forEach { l ->
                    Column(
                        Modifier.weight(1f).clickable {
                            level = l
                            source = l.source ?: WorkbenchSource.ALL
                            category = "全部"
                            positionFilter = "全部"
                            selectedId = null
                        }.padding(vertical = 8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(l.label, fontWeight = if (level == l) FontWeight.Bold else FontWeight.Normal,
                            color = if (level == l) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
                        if (level == l) HorizontalDivider(Modifier.padding(top = 6.dp), thickness = 3.dp)
                    }
                }
            }
        }
        item {
            GlobalCard {
                Text("玩法分类", fontWeight = FontWeight.Bold)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    playOptions.forEach { c ->
                        FilterChip(selected = category == c, onClick = { category = c; selectedId = null }, label = { Text(c) })
                    }
                    FilterChip(selected = category == "★ 收藏", onClick = { category = "★ 收藏"; selectedId = null }, label = { Text("★ 收藏 ${favoriteIds.size}") })
                }
                Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    positionOptions.forEach { p ->
                        FilterChip(selected = positionFilter == p, onClick = { positionFilter = p; selectedId = null }, label = { Text(p) })
                    }
                }
                Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    WorkbenchSource.entries.filter { it == WorkbenchSource.CUSTOM || it == WorkbenchSource.MODEL }.forEach { s ->
                        FilterChip(selected = source == s, onClick = { source = s; category = "全部"; positionFilter = "全部"; selectedId = null }, label = { Text(s.label) })
                    }
                }
            }
        }
        item {
            GlobalCard {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    WorkbenchFilterButton("计划数量", "≤${resultLimit}", Modifier.weight(1f)) { resultLimit = when (resultLimit) { 20 -> 50; 50 -> 100; else -> 20 } }
                    WorkbenchFilterButton("计划周期", if (cycleFilter == 0) "全部" else "${cycleFilter}期", Modifier.weight(1f)) { cycleFilter = when (cycleFilter) { 0 -> 1; 1 -> 2; 2 -> 3; 3 -> 5; else -> 0 } }
                    WorkbenchFilterButton(
                        "当前连中",
                        if (minCurrentHit == 0) "全部" else "≥${minCurrentHit}跳",
                        Modifier.weight(1f)
                    ) {
                        minCurrentHit = when (minCurrentHit) {
                            0 -> 1; 1 -> 2; 2 -> 3; 3 -> 5; 5 -> 8; else -> 0
                        }
                        selectedId = null
                    }
                }
                Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    WorkbenchFilterButton(
                        "当前连挂",
                        if (minCurrentMiss == 0) "全部" else "≥${minCurrentMiss}跳",
                        Modifier.weight(1f)
                    ) {
                        minCurrentMiss = when (minCurrentMiss) {
                            0 -> 1; 1 -> 2; 2 -> 3; 3 -> 5; 5 -> 8; else -> 0
                        }
                        selectedId = null
                    }
                    WorkbenchFilterButton(
                        "连中/连挂",
                        when {
                            minCurrentHit > 0 && minCurrentMiss > 0 -> "中≥${minCurrentHit}/挂≥${minCurrentMiss}"
                            minCurrentHit > 0 -> "连中≥${minCurrentHit}"
                            minCurrentMiss > 0 -> "连挂≥${minCurrentMiss}"
                            else -> "不限"
                        },
                        Modifier.weight(1f)
                    ) {
                        // 快速切换：全部 → 连中≥1 → 连挂≥1 → 连中≥2 → 连挂≥2 → 全部
                        when {
                            minCurrentHit == 0 && minCurrentMiss == 0 -> { minCurrentHit = 1; minCurrentMiss = 0 }
                            minCurrentHit == 1 && minCurrentMiss == 0 -> { minCurrentHit = 0; minCurrentMiss = 1 }
                            minCurrentHit == 0 && minCurrentMiss == 1 -> { minCurrentHit = 2; minCurrentMiss = 0 }
                            minCurrentHit == 2 && minCurrentMiss == 0 -> { minCurrentHit = 0; minCurrentMiss = 2 }
                            else -> { minCurrentHit = 0; minCurrentMiss = 0 }
                        }
                        selectedId = null
                    }
                    WorkbenchFilterButton("重置筛选", "清空", Modifier.weight(1f)) {
                        minCurrentHit = 0
                        minCurrentMiss = 0
                        cycleFilter = 0
                        resultLimit = 50
                        selectedId = null
                    }
                }
                Spacer(Modifier.height(8.dp))
                PrimaryButton("开始搜索", { selectedId = filtered.firstOrNull()?.planId }, Modifier.fillMaxWidth(), enabled = filtered.isNotEmpty())
                CaptionMuted(
                    buildString {
                        append("当前 ${source.label} · ${filtered.size} 个结果 · 核心 ${all.size} · 候选 ${candidates.size}")
                        if (minCurrentHit > 0) append(" · 连中≥${minCurrentHit}")
                        if (minCurrentMiss > 0) append(" · 连挂≥${minCurrentMiss}")
                    }
                )
            }
        }
        item {
            GlobalCard {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    LeaderboardTab.entries.forEach { t ->
                        FilterChip(selected = leaderboardTab == t, onClick = { leaderboardTab = t }, label = { Text(t.label) })
                    }
                }
            }
        }
        item {
            val chunks = leaderboardRows.chunked(2)
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                chunks.forEach { pair ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        pair.forEach { (p, rt) ->
                            GlobalCard(Modifier.weight(1f).clickable { selectedId = p.planId; tab = WorkbenchTab.DETAIL; report = null }) {
                                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                    Text(p.planName.take(11), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                                    Text(if (p.planId in favoriteIds) "★" else "☆", color = CaiTokens.Warning)
                                }
                                when (leaderboardTab) {
                                    LeaderboardTab.HIT_STREAK -> Text("最高连中${rt.maxConsecutiveHit}期")
                                    LeaderboardTab.HIT_RATE -> Text(if (rt.sampleCount > 0) "中奖率${"%.0f".format(rt.hitRate * 100)}%" else "中奖率—")
                                    LeaderboardTab.MISS_STREAK -> Text("最高连挂${rt.maxConsecutiveMiss}期")
                                    LeaderboardTab.CURRENT_HIT -> Text("当前连中${rt.consecutiveHit}跳")
                                    LeaderboardTab.CURRENT_MISS -> Text("当前连挂${rt.consecutiveMiss}跳")
                                }
                                CaptionMuted("${p.playType} · ${if (p.positionIndex >= 0) "位置${p.positionIndex + 1}" else "不定位"}")
                            }
                        }
                        if (pair.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            }
        }
        item {
            GlobalCard {
                Text("计划列表", fontWeight = FontWeight.Bold)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    filtered.forEach { p ->
                        FilterChip(selected = p.planId == selected?.planId, onClick = { selectedId = p.planId; tab = WorkbenchTab.DETAIL; report = null }, label = { Text(p.planName.take(14)) })
                    }
                }
            }
        }

        if (selected != null) {
            val plan = selected
            val planRt = vm.planVM.runtimeForPlan(plan.planId)
            item {
                GlobalCard(containerColor = MaterialTheme.colorScheme.secondaryContainer) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(plan.planName, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        IconButton(onClick = { vm.togglePlanFavorite(plan.planId) }) {
                            Icon(
                                imageVector = if (vm.isPlanFavorite(plan.planId)) Icons.Filled.Star else Icons.Filled.StarBorder,
                                contentDescription = if (vm.isPlanFavorite(plan.planId)) "取消收藏" else "收藏计划"
                            )
                        }
                    }
                    CaptionMuted("${sourceLabel(plan, legacy, nova, candidates, custom, models)} · ${plan.playType} · 算法 ${plan.algorithm} · 窗口 ${plan.window}期 · 周期 ${plan.cyclePeriods}期")
                    // 当前连中/连挂跳（与图片中「当前连中跳」「当前连挂跳」一致）
                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(
                            "当前连中跳：${planRt.consecutiveHit}次",
                            color = if (planRt.consecutiveHit > 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 13.sp
                        )
                        Text(
                            "当前连挂跳：${planRt.consecutiveMiss}次",
                            color = if (planRt.consecutiveMiss > 0) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 13.sp
                        )
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        CaptionMuted("今日/历史最大连中：${planRt.maxConsecutiveHit}次")
                        CaptionMuted("今日/历史最大连挂：${planRt.maxConsecutiveMiss}次")
                    }
                    CaptionMuted(if (vm.isPlanFavorite(plan.planId)) "★ 已收藏 · 收藏按彩种独立保存" else "☆ 未收藏 · 点击右上角星标加入收藏")
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        PrimaryButton(if (running) "回测中…" else "回测当前计划", { runPlanBacktest(plan) }, Modifier.weight(1f), enabled = !running && history.size >= 6)
                        PrimaryButton("相反计划", { tab = WorkbenchTab.REVERSE }, Modifier.weight(1f), ghost = true)
                    }
                    Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        WorkbenchTab.entries.forEach { t -> FilterChip(selected = tab == t, onClick = { tab = t }, label = { Text(t.label) }) }
                    }
                }
            }

            when (tab) {
                WorkbenchTab.DETAIL -> {
                    item { PlanDetailCard(plan, report) }
                }
                WorkbenchTab.REVERSE -> {
                    item { ReversePlanCard(plan, history, periods, vm) }
                }
                WorkbenchTab.HISTORY -> {
                    item {
                        GlobalCard {
                            Text("历史开奖与计划结算", fontWeight = FontWeight.Bold)
                            if (report == null) CaptionMuted("先点击“回测当前计划”生成对应的历史结算")
                            report?.points?.takeLast(80)?.reversed()?.forEach { p ->
                                Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Text(p.issue, modifier = Modifier.weight(1f), fontSize = 12.sp)
                                    Text(p.prediction, modifier = Modifier.weight(1.4f), fontSize = 12.sp)
                                    Text(if (p.hit) "中" else "挂", fontSize = 12.sp, color = if (p.hit) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                                }
                            }
                        }
                    }
                }
                WorkbenchTab.TREND -> {
                    item { TrendCard(report, periods, onPeriodsChange = { periods = it }, onRun = { runPlanBacktest(plan) }) }
                }
                WorkbenchTab.GUIDE -> {
                    item { GuideCard(plan) }
                }
            }
        } else {
            item { GlobalCard { CaptionMuted("请先选择一个计划") } }
        }
    }
}

@Composable
private fun WorkbenchFilterButton(title: String, value: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    OutlinedButton(
        onClick = onClick,
        modifier = modifier,
        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 8.dp)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(title, fontSize = 11.sp)
            Text(value, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

private fun sourceLabel(p: PlanDefinition, legacy: List<PlanDefinition>, nova: List<PlanDefinition>, candidates: List<PlanDefinition>, custom: List<PlanDefinition>, models: List<PlanDefinition>): String = when {
    legacy.any { it.planId == p.planId } -> "原计划池"
    nova.any { it.planId == p.planId } -> "新计划池"
    candidates.any { it.planId == p.planId } -> "候选策略池"
    custom.any { it.planId == p.planId } -> "自定义计划"
    models.any { it.planId == p.planId } -> "算法模型"
    else -> "计划"
}


@Composable
private fun PlanDetailCard(plan: PlanDefinition, report: NovaPlanAnalytics.ChartReport?) {
    GlobalCard {
        Text("计划详情", fontWeight = FontWeight.Bold)
        DetailRow("计划ID", plan.planId)
        DetailRow("计划名称", plan.planName)
        DetailRow("玩法", plan.playType)
        DetailRow("分类", plan.category)
        DetailRow("算法", plan.algorithm)
        DetailRow("样本窗口", "${plan.window}期")
        DetailRow("执行周期", "${plan.cyclePeriods}期")
        DetailRow("命中基准", "${"%.1f".format(plan.baselineValue * 100)}%")
        DetailRow("共识参与", if (plan.participateConsensus) "是" else "否")
        report?.let {
            HorizontalDivider(Modifier.padding(vertical = 6.dp))
            Text("最近回测", fontWeight = FontWeight.SemiBold)
            DetailRow("回测期数", "${it.periods}期")
            DetailRow("命中", "${it.hits} / ${it.misses}")
            DetailRow("命中率", "${"%.2f".format(it.hitRate * 100)}%")
            DetailRow("累计收益", "${"%.2f".format(it.netProfit)}")
            DetailRow("最大连中", "${it.maxHitStreak}期")
            DetailRow("最大连挂", "${it.maxMissStreak}期")
            DetailRow("最大回撤", "${"%.2f".format(it.maxDrawdown)}")
        }
    }
}

@Composable
private fun ReversePlanCard(plan: PlanDefinition, history: List<DrawRecord>, periods: Int, vm: MainViewModel) {
    val reverse = remember(plan.planId, history.size, periods) {
        NovaPlanAnalytics.chartBacktest(plan, history, periods, 10.0, invert = true, outputCount = when (plan.playType) { "组合" -> vm.prefs.value.comboPredCount; "数字", "位置", "定位" -> vm.prefs.value.positionTopN; else -> null })
    }
    GlobalCard {
        Text("相反计划", fontWeight = FontWeight.Bold)
        CaptionMuted("正投计划 ${plan.planName} 的方向/对错取反后的独立统计，不修改原计划。")
        DetailRow("计划名称", reverse.plan.planName)
        DetailRow("回测期数", "${reverse.periods}期")
        DetailRow("命中率", "${"%.2f".format(reverse.hitRate * 100)}%")
        DetailRow("累计收益", "${"%.2f".format(reverse.netProfit)}")
        DetailRow("最大连中", "${reverse.maxHitStreak}期")
        DetailRow("最大连挂", "${reverse.maxMissStreak}期")
    }
}

@Composable
private fun TrendCard(report: NovaPlanAnalytics.ChartReport?, periods: Int, onPeriodsChange: (Int) -> Unit, onRun: () -> Unit) {
    GlobalCard {
        Text("计划走势", fontWeight = FontWeight.Bold)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf(100, 200, 500, 1000, 2000, 5000).forEach { n -> FilterChip(selected = periods == n, onClick = { onPeriodsChange(n) }, label = { Text("${n}期") }) }
        }
        PrimaryButton("刷新走势", onRun, Modifier.fillMaxWidth(), ghost = true)
        if (report == null || report.points.size < 2) {
            CaptionMuted("暂无走势数据")
        } else {
            val points = report.points.takeLast(150)
            val lineColor = MaterialTheme.colorScheme.primary
            Canvas(Modifier.fillMaxWidth().height(180.dp).padding(top = 8.dp)) {
                val min = points.minOf { it.cumulativeProfit }
                val max = points.maxOf { it.cumulativeProfit }
                val range = (max - min).coerceAtLeast(1.0)
                val path = Path()
                points.forEachIndexed { i, p ->
                    val x = if (points.size == 1) 0f else size.width * i / (points.size - 1)
                    val y = size.height - ((p.cumulativeProfit - min) / range * size.height).toFloat()
                    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                drawPath(path = path, color = lineColor, style = androidx.compose.ui.graphics.drawscope.Stroke(width = 4f))
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("${points.first().issue}", fontSize = 11.sp)
                Text("${points.last().issue}", fontSize = 11.sp)
            }
            DetailRow("当前趋势", report.currentTrend)
            DetailRow("累计收益", "${"%.2f".format(report.netProfit)}")
            DetailRow("最大回撤", "${"%.2f".format(report.maxDrawdown)}")
        }
    }
}

@Composable
private fun GuideCard(plan: PlanDefinition) {
    GlobalCard {
        Text("计划攻略", fontWeight = FontWeight.Bold)
        CaptionMuted("这里展示当前计划的计算口径，方便在工作台直接理解计划，而不需要跳到其它页面。")
        DetailRow("计划类型", plan.playType)
        DetailRow("计算算法", plan.algorithm)
        DetailRow("历史窗口", "最近 ${plan.window} 期")
        DetailRow("输出形式", plan.outputFormat.name)
        DetailRow("命中标准", plan.hitCriteria.name)
        DetailRow("基础概率", "${"%.1f".format(plan.baselineValue * 100)}%")
        Text("回测规则", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 8.dp))
        CaptionMuted("采用 walk-forward：预测某一期时只使用该期之前的开奖数据；每期独立结算，避免把未来开奖号码泄漏到历史预测。")
        CaptionMuted("过关斩将、正投/反投等资金模式属于图表回测层，不改变计划本身的预测算法。")
    }
}

@Composable
private fun DetailRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
        Text(label, modifier = Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
        Text(value, modifier = Modifier.weight(1.7f), fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}
