package com.caifenxi.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.caifenxi.app.domain.model.*
import com.caifenxi.app.domain.plan.NovaPlanAnalytics
import com.caifenxi.app.domain.plan.NovaPlanPool
import com.caifenxi.app.domain.plan.NovaPlanWorkbench
import com.caifenxi.app.ui.MainViewModel
import com.caifenxi.app.ui.components.CaptionMuted
import com.caifenxi.app.ui.components.GlobalCard
import com.caifenxi.app.ui.components.PrimaryButton
import com.caifenxi.app.ui.theme.CaiTokens
import kotlin.math.roundToInt

private enum class NovaTab(val label: String) {
    OVERVIEW("总览"), RANK("排行榜"), LIBRARY("计划库"), CONSENSUS("共识预测")
}

@Composable
fun NovaPlanScreen(vm: MainViewModel) {
    var tab by remember { mutableStateOf(NovaTab.OVERVIEW) }
    var expandedId by remember { mutableStateOf<String?>(null) }
    var rankExpandedId by remember { mutableStateOf<String?>(null) }
    var rankHistPage by remember { mutableStateOf(0) }
    var consensusHistPage by remember { mutableStateOf(0) }
    var libraryCategory by remember { mutableStateOf("全部") }
    var libraryPeriods by remember { mutableStateOf(500) }
    var detailReport by remember { mutableStateOf<NovaPlanAnalytics.BacktestReport?>(null) }
    var explanation by remember { mutableStateOf<NovaPlanWorkbench.Explanation?>(null) }
    val history = vm.history.value
    val target = vm.nextIssueText.value.takeIf { it.isNotBlank() && it != "-" } ?: vm.planVM.planTargetIssue.value
    val custom = vm.customPlans.value.map { it.toDefinition() }.filter { it.planId.startsWith("NOVA-CUSTOM-") }
    val plans = (NovaPlanPool.ALL + custom).distinctBy { it.planId }
    val novaRecords = vm.planHistory.value.filter { isNova(it.planId) }
    val currentPreds = vm.currentPredictions.value.filter { isNova(it.planId) && (target.isBlank() || it.targetIssue == target) }
    val rank = vm.planVM.novaLeaderboard.value
    val rankCategory = vm.planVM.novaLeaderboardCategory.value
    val rankStage = vm.planVM.novaLeaderboardStage.value
    val rankPeriods = vm.planVM.novaLeaderboardPeriods.value
    val rankPage = vm.planVM.novaLeaderboardPage.value
    val rankPageSize = 20

    LaunchedEffect(target, history.size) { vm.refreshNovaPlanData() }
    LaunchedEffect(tab, history.size, rankCategory, rankStage, rankPeriods) {
        if (tab == NovaTab.RANK) vm.planVM.refreshNovaLeaderboard(history)
    }
    LaunchedEffect(tab) {
        if (tab == NovaTab.CONSENSUS) {
            // 进入共识页时刷新持久化记录，供分页展示
            vm.refreshConsensusStats()
        }
    }

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = CaiTokens.ScreenHPadding, vertical = CaiTokens.S12),
        verticalArrangement = Arrangement.spacedBy(CaiTokens.S8),
        contentPadding = PaddingValues(bottom = CaiTokens.ScreenBottom)
    ) {
        item {
            Text("新计划池", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            CaptionMuted("NovaPlan · 独立计划池；预测、回测、结算、挂机、悬浮窗、无障碍点击共用同一数据链路")
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                NovaTab.entries.forEach { t -> FilterChip(selected = tab == t, onClick = { tab = t }, label = { Text(t.label) }) }
            }
        }
        item {
            GlobalCard(containerColor = MaterialTheme.colorScheme.secondaryContainer) {
                Text("当前目标 · 第 ${target.ifBlank { "-" }} 期", fontWeight = FontWeight.Bold)
                CaptionMuted("Nova 计划 ${plans.size} 个 · 当期预测 ${currentPreds.size} 条 · 共识上限 ${vm.planVM.novaConsensusLimit.value} 个")
                val locked = vm.planVM.lockedConsensusVersion.value
                if (locked != null) {
                    Text("🔒 挂机共识已锁定：$locked", fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                    CaptionMuted("停止挂机后才会使用新的排行/上限配置")
                }
            }
        }
        // 数据异常检测横幅
        val anomalies = vm.planVM.novaAnomalyReport.value.anomalies
        if (anomalies.isNotEmpty()) {
            item {
                GlobalCard(containerColor = MaterialTheme.colorScheme.errorContainer) {
                    Text("数据异常检测", fontWeight = FontWeight.Bold)
                    anomalies.take(5).forEach { a ->
                        Text(a.message, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                    }
                    if (anomalies.size > 5) CaptionMuted("另有 ${anomalies.size - 5} 条…")
                }
            }
        }

        when (tab) {
            NovaTab.OVERVIEW -> {
                item {
                    GlobalCard {
                        Text("当期共识预测", fontWeight = FontWeight.Bold)
                        val cons = vm.consensus.value.filter { it.targetIssue == target }
                        if (cons.isEmpty()) CaptionMuted("暂无 Nova 共识，请刷新首页开奖或进入共识页刷新")
                        cons.forEach { c -> ConsensusRow(c) }
                    }
                }
                item {
                    GlobalCard {
                        Text("共识预测分类战绩", fontWeight = FontWeight.Bold)
                        CaptionMuted("按分类独立统计；两期/三期均采用其他计划页面相同的滚动窗口口径")
                        val novaStats = novaCategoryStats(novaRecords, plans)
                        if (novaStats.isEmpty()) CaptionMuted("暂无已结算 Nova 预测")
                        novaStats.forEach { (cat, st) -> CategoryRateRow(cat, st) }
                    }
                }
                item {
                    GlobalCard {
                        Text("计划池概览", fontWeight = FontWeight.Bold)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                            Summary("计划", plans.size)
                            Summary("大小", plans.count { it.playType == "大小" })
                            Summary("单双", plans.count { it.playType == "单双" })
                            Summary("组合", plans.count { it.playType == "组合" })
                            Summary("位置", plans.count { it.playType == "位置" })
                        }
                        Spacer(Modifier.height(8.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            PrimaryButton("排行榜", { tab = NovaTab.RANK }, modifier = Modifier.weight(1f))
                            PrimaryButton("计划库", { tab = NovaTab.LIBRARY }, ghost = true, modifier = Modifier.weight(1f))
                            PrimaryButton("共识", { tab = NovaTab.CONSENSUS }, ghost = true, modifier = Modifier.weight(1f))
                        }
                    }
                }
            }
            NovaTab.RANK -> {
                item {
                    GlobalCard {
                        Text("统一回测动态胜率排行榜", fontWeight = FontWeight.Bold)
                        CaptionMuted("全部 Nova 计划使用同一回测窗口；切换分类/期次不会丢失上次排行榜状态")
                        FilterLine("分类", listOf("全部") + NovaPlanPool.PLAY_TYPES, rankCategory) { vm.planVM.novaLeaderboardCategory.value = it; vm.planVM.novaLeaderboardPage.value = 0 }
                        FilterLine("口径", listOf("全部", "首期", "两期窗口", "三期窗口"), listOf("全部", "首期", "两期窗口", "三期窗口")[rankStage]) { v ->
                            vm.planVM.novaLeaderboardStage.value = listOf("全部", "首期", "两期窗口", "三期窗口").indexOf(v)
                            vm.planVM.novaLeaderboardPage.value = 0
                        }
                        FilterLine("回测", listOf(50,100,200,500,1000,2000,5000).map { "${it}期" }, "${rankPeriods}期") { v ->
                            vm.planVM.novaLeaderboardPeriods.value = v.removeSuffix("期").toInt()
                            vm.planVM.novaLeaderboardPage.value = 0
                        }
                        PrimaryButton(if (vm.planVM.novaLeaderboardLoading.value) "正在计算…" else "重新计算排行榜", { vm.planVM.refreshNovaLeaderboard(history) }, Modifier.fillMaxWidth(), enabled = !vm.planVM.novaLeaderboardLoading.value)
                    }
                }
                val pageRows = rank.drop(rankPage * rankPageSize).take(rankPageSize)
                item {
                    GlobalCard {
                        Text("共 ${rank.size} 个计划 · 第 ${if (rank.isEmpty()) 0 else rankPage + 1} / ${((rank.size - 1).coerceAtLeast(0) / rankPageSize) + 1} 页", fontWeight = FontWeight.Bold)
                        if (rank.isEmpty()) CaptionMuted("暂无排行榜，请点击重新计算")
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(enabled = rankPage > 0, onClick = { vm.planVM.novaLeaderboardPage.value = rankPage - 1 }, modifier = Modifier.weight(1f)) { Text("上一页") }
                            OutlinedButton(enabled = (rankPage + 1) * rankPageSize < rank.size, onClick = { vm.planVM.novaLeaderboardPage.value = rankPage + 1 }, modifier = Modifier.weight(1f)) { Text("下一页") }
                        }
                    }
                }
                items(pageRows, key = { "rank-${it.first.planId}" }) { (p, r) ->
                    val expanded = rankExpandedId == p.planId
                    GlobalCard {
                        Row(
                            Modifier.fillMaxWidth().clickable {
                                if (expanded) {
                                    rankExpandedId = null
                                } else {
                                    rankExpandedId = p.planId
                                    rankHistPage = 0
                                }
                            },
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("${rank.indexOfFirst { it.first.planId == p.planId } + 1}", fontWeight = FontWeight.Bold, modifier = Modifier.width(32.dp))
                            Column(Modifier.weight(1f)) {
                                Text(p.planName, fontWeight = FontWeight.Bold)
                                CaptionMuted("${p.playType} · ${r.periods}样本 · 对 ${r.hits} / 错 ${r.misses}")
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("${(r.hitRate * 100).roundToInt()}%", fontWeight = FontWeight.Bold)
                                CaptionMuted("综合 ${"%.3f".format(rankScore(r))}")
                                Text(if (expanded) "收起 ▲" else "展开 ▼", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                        if (expanded) {
                            Spacer(Modifier.height(6.dp))
                            HorizontalDivider()
                            Spacer(Modifier.height(6.dp))
                            // 当期预测
                            val cur = currentPreds.filter { it.planId == p.planId }
                            Text("当期预测 · 第 ${target.ifBlank { "-" }} 期", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            if (cur.isEmpty()) CaptionMuted("暂无当期预测")
                            else cur.forEach { PredictionMini(it) }
                            Spacer(Modifier.height(4.dp))
                            // 历史预测分页
                            val histAll = novaRecords.filter { it.planId == p.planId }
                                .sortedByDescending { it.targetIssue }
                            val histPageSize = 10
                            val histTotalPages = ((histAll.size - 1).coerceAtLeast(0) / histPageSize) + 1
                            val safePage = rankHistPage.coerceIn(0, (histTotalPages - 1).coerceAtLeast(0))
                            val histPageRows = histAll.drop(safePage * histPageSize).take(histPageSize)
                            Text("历史预测记录 · 共 ${histAll.size} 条 · 第 ${if (histAll.isEmpty()) 0 else safePage + 1}/$histTotalPages 页", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            if (histPageRows.isEmpty()) CaptionMuted("暂无历史预测")
                            else histPageRows.forEach { PredictionMini(it) }
                            if (histAll.size > histPageSize) {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedButton(
                                        enabled = safePage > 0,
                                        onClick = { rankHistPage = (safePage - 1).coerceAtLeast(0) },
                                        modifier = Modifier.weight(1f)
                                    ) { Text("上一页") }
                                    OutlinedButton(
                                        enabled = (safePage + 1) * histPageSize < histAll.size,
                                        onClick = { rankHistPage = safePage + 1 },
                                        modifier = Modifier.weight(1f)
                                    ) { Text("下一页") }
                                }
                            }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                                PrimaryButton(
                                    "用于驾驶舱",
                                    { vm.selectCockpitPlan(p.planId, 1) },
                                    modifier = Modifier.weight(1f),
                                    enabled = vm.prefs.value.cockpitPlanId != p.planId
                                )
                                TextButton(onClick = { expandedId = p.planId; tab = NovaTab.LIBRARY }) {
                                    Text("详情")
                                }
                            }
                        }
                    }
                }
            }
            NovaTab.LIBRARY -> {
                item {
                    GlobalCard {
                        Text("计划库 · 全部计划", fontWeight = FontWeight.Bold)
                        CaptionMuted("显示所有计划胜率；点击计划展开历史预测、战绩、对错率和回测详情")
                        FilterLine("分类", listOf("全部") + NovaPlanPool.PLAY_TYPES, libraryCategory) { libraryCategory = it; expandedId = null }
                        FilterLine("几期", listOf(50,100,200,500,1000,2000,5000).map { "${it}期" }, "${libraryPeriods}期") { libraryPeriods = it.removeSuffix("期").toInt() }
                    }
                }
                val visible = plans.filter { libraryCategory == "全部" || it.playType == libraryCategory }
                items(visible, key = { "lib-${it.planId}" }) { p ->
                    val rt = vm.planVM.runtimeForPlan(p.planId)
                    val expanded = expandedId == p.planId
                    GlobalCard(containerColor = if (expanded) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) { Text(p.planName, fontWeight = FontWeight.Bold); CaptionMuted("${p.playType} · ${p.algorithm} · 窗口 ${p.window}期") }
                            Column(horizontalAlignment = Alignment.End) { Text(rt.hitRatePercent, fontWeight = FontWeight.Bold); CaptionMuted("样本 ${rt.sampleCount}") }
                        }
                        TextButton(onClick = {
                            expandedId = if (expanded) null else p.planId
                            if (!expanded) { vm.loadPlanDetail(p.planId); detailReport = null }
                        }) { Text(if (expanded) "收起" else "展开详情") }
                        if (expanded) {
                            val report = remember(p.planId, libraryPeriods, history.size) { NovaPlanAnalytics.backtest(p.copy(cyclePeriods = 1), history, libraryPeriods) }
                            Text("战绩 · 对 ${report.hits} / 错 ${report.misses} · 胜率 ${(report.hitRate * 100).roundToInt()}%", fontWeight = FontWeight.SemiBold)
                            Text("两期对 ${(report.twoHitRate*100).roundToInt()}% / 错 ${(report.twoMissRate*100).roundToInt()}% · 三期对 ${(report.threeHitRate*100).roundToInt()}% / 错 ${(report.threeMissRate*100).roundToInt()}%")
                            CaptionMuted("两期窗口 ${report.twoWindows} · 三期窗口 ${report.threeWindows} · Edge ${(report.edge*100).roundToInt()}%")
                            Spacer(Modifier.height(5.dp))
                            Text("历史预测记录", fontWeight = FontWeight.SemiBold)
                            val rows = novaRecords.filter { it.planId == p.planId }.take(10)
                            if (rows.isEmpty()) CaptionMuted("暂无历史预测") else rows.forEach { r -> PredictionMini(r) }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                                PrimaryButton("用于驾驶舱", { vm.selectCockpitPlan(p.planId, 1) }, modifier = Modifier.weight(1f), enabled = vm.prefs.value.cockpitPlanId != p.planId)
                                PrimaryButton("解释", { explanation = NovaPlanWorkbench.explain(p, history) }, ghost = true, modifier = Modifier.weight(1f))
                            }
                        }
                    }
                }
            }
            NovaTab.CONSENSUS -> {
                item {
                    GlobalCard {
                        Text("Nova 共识预测", fontWeight = FontWeight.Bold)
                        CaptionMuted("只使用 Nova 计划；参与上限已放开（1～500），与预测/挂机/悬浮窗共用目标期。设为较大值可让全部计划参与。")
                        var limitText by remember(vm.planVM.novaConsensusLimit.value) { mutableStateOf(vm.planVM.novaConsensusLimit.value.toString()) }
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(
                                value = limitText,
                                onValueChange = { limitText = it.filter(Char::isDigit).take(3) },
                                label = { Text("参与计划上限") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            Spacer(Modifier.width(8.dp))
                            Button(onClick = {
                                vm.planVM.novaConsensusLimit.value = (limitText.toIntOrNull() ?: 50).coerceIn(1, 500)
                                vm.refreshNovaPlanData()
                            }) { Text("应用") }
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf(10, 20, 30, 50, 100, 200, 500).forEach { n ->
                                FilterChip(
                                    selected = vm.planVM.novaConsensusLimit.value == n,
                                    onClick = {
                                        vm.planVM.novaConsensusLimit.value = n
                                        vm.refreshNovaPlanData()
                                    },
                                    label = { Text("$n") }
                                )
                            }
                        }
                    }
                }
                item {
                    GlobalCard {
                        Text("当期共识 · 第 ${target.ifBlank { "-" }} 期", fontWeight = FontWeight.Bold)
                        val cons = vm.consensus.value.filter { it.targetIssue == target }
                        if (cons.isEmpty()) CaptionMuted("暂无共识") else cons.forEach { ConsensusRow(it) }
                    }
                }
                item {
                    // 共识预测历史记录分页
                    val allRecs = vm.consensusRecords.value
                        .sortedWith(
                            compareByDescending<com.caifenxi.app.domain.model.ConsensusRecord> { it.targetIssue }
                                .thenByDescending { it.createdAt }
                        )
                    val pageSize = 15
                    val totalPages = ((allRecs.size - 1).coerceAtLeast(0) / pageSize) + 1
                    val safePage = consensusHistPage.coerceIn(0, (totalPages - 1).coerceAtLeast(0))
                    val pageRecs = allRecs.drop(safePage * pageSize).take(pageSize)
                    GlobalCard {
                        Text("共识预测记录", fontWeight = FontWeight.Bold)
                        CaptionMuted("共 ${allRecs.size} 条 · 第 ${if (allRecs.isEmpty()) 0 else safePage + 1}/$totalPages 页 · 含待开与已结算")
                        if (allRecs.isEmpty()) {
                            CaptionMuted("暂无共识记录；刷新首页或调整上限后会自动写入")
                        } else {
                            // 按目标期分组展示
                            pageRecs.groupBy { it.targetIssue }.forEach { (issue, group) ->
                                Text("第 $issue 期", fontWeight = FontWeight.SemiBold, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
                                group.forEach { rec ->
                                    Row(
                                        Modifier.fillMaxWidth().padding(vertical = 3.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column(Modifier.weight(1f)) {
                                            Text("${rec.category} → ${rec.leadingDirection}", fontSize = 13.sp)
                                            CaptionMuted(
                                                "参与 ${rec.participatingPlans} · 支持 ${(rec.supportRatio * 100).roundToInt()}%" +
                                                    (rec.actual?.let { " · 开奖 $it" } ?: "")
                                            )
                                        }
                                        Text(
                                            rec.result,
                                            fontWeight = FontWeight.Bold,
                                            color = when (rec.result) {
                                                "对" -> Color(0xFF2E7D32)
                                                "错" -> Color(0xFFC62828)
                                                else -> MaterialTheme.colorScheme.onSurfaceVariant
                                            }
                                        )
                                    }
                                }
                            }
                        }
                        if (allRecs.size > pageSize) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(
                                    enabled = safePage > 0,
                                    onClick = { consensusHistPage = (safePage - 1).coerceAtLeast(0) },
                                    modifier = Modifier.weight(1f)
                                ) { Text("上一页") }
                                OutlinedButton(
                                    enabled = (safePage + 1) * pageSize < allRecs.size,
                                    onClick = { consensusHistPage = safePage + 1 },
                                    modifier = Modifier.weight(1f)
                                ) { Text("下一页") }
                            }
                        }
                    }
                }
            }
        }
    }
    explanation?.let { e -> AlertDialog(onDismissRequest = { explanation = null }, title = { Text("计划解释") }, text = { Column { Text(e.title, fontWeight = FontWeight.Bold); CaptionMuted("${e.planId} · 窗口 ${e.inputWindow}期 · 评分 ${e.score.roundToInt()}"); e.factors.forEach { Text("${it.first} · ${(it.second*100).roundToInt()}%") } } }, confirmButton = { TextButton(onClick = { explanation = null }) { Text("关闭") } }) }
}

private fun isNova(id: String) = id.startsWith("NOVA-") || id.startsWith("NOVA-CUSTOM-")

@Composable private fun Summary(label: String, value: Int) { Column(horizontalAlignment = Alignment.CenterHorizontally) { Text(value.toString(), fontWeight = FontWeight.Bold); Text(label, fontSize = 10.sp) } }

@Composable private fun FilterLine(title: String, options: List<String>, selected: String, onSelect: (String) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(top = 5.dp)) { CaptionMuted(title); Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp)) { options.forEach { FilterChip(selected = selected == it, onClick = { onSelect(it) }, label = { Text(it) }) } } }
}

@Composable private fun ConsensusRow(c: ModelConsensus) {
    GlobalCard {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("${c.category} → ${c.leadingDirection}", fontWeight = FontWeight.Bold)
            Text("${(c.supportRatio * 100).roundToInt()}%", fontWeight = FontWeight.Bold)
        }
        val strength = when {
            c.supportRatio >= 0.70 -> "共识强度：高"
            c.disagreement >= 0.85 -> "共识分歧：高"
            c.supportRatio >= 0.58 -> "共识强度：中"
            else -> "共识分歧：偏高"
        }
        CaptionMuted("参与 ${c.participatingPlans} 个计划 · 分歧 ${(c.disagreement * 100).roundToInt()}% · $strength")
        if (c.consensusVersion.isNotBlank()) {
            CaptionMuted("版本 ${c.consensusVersion}")
        }
        LinearProgressIndicator(
            progress = { c.supportRatio.toFloat().coerceIn(0f, 1f) },
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable private fun PredictionMini(r: PlanPredictionRecord) { Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.SpaceBetween) { Column(Modifier.weight(1f)) { Text("第${r.targetIssue}期 · ${r.output}", fontSize = 12.sp); CaptionMuted("${if (r.settled) if (r.hit == true) "对" else "错" else "待开"} · ${r.cutoffIssue}") }; Text(if (!r.settled) "待开" else if (r.hit == true) "对" else "错", fontWeight = FontWeight.Bold) } }

@Composable private fun CategoryRateRow(cat: String, st: CategoryStats) { val total = st.hit + st.miss; Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) { Column(Modifier.weight(1f)) { Text(cat, fontWeight = FontWeight.SemiBold); CaptionMuted("首期 对 ${st.hit} / 错 ${st.miss} · ${(if (total==0) 0 else st.hit*100/total)}%") }; Column(horizontalAlignment = Alignment.End) { Text("两期 ${(st.twoHitRate*100).roundToInt()}%", fontWeight = FontWeight.Bold); Text("三期 ${(st.threeHitRate*100).roundToInt()}%", fontSize = 12.sp) } } }

private fun novaCategoryStats(records: List<PlanPredictionRecord>, plans: List<PlanDefinition>): Map<String, CategoryStats> {
    return plans.groupBy { it.playType }.mapNotNull { (cat, defs) ->
        val ids = defs.map { it.planId }.toSet()
        val results = records.filter { it.planId in ids && it.settled }.sortedBy { it.targetIssue }.map { if (it.hit == true) "对" else "错" }
        if (results.isEmpty()) null else cat to com.caifenxi.app.data.config.StreakCalc.buildCategoryStats(results)
    }.toMap()
}

private fun rankScore(r: NovaPlanAnalytics.BacktestReport): Double = r.hitRate*.50 + r.edge.coerceIn(-1.0,1.0)*.25 + r.stability*.15 + (r.maxHitStreak.toDouble()/(r.maxHitStreak+r.maxMissStreak+1.0))*.10
