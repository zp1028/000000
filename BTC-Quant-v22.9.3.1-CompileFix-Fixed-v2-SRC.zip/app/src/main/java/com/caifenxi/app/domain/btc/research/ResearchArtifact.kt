package com.caifenxi.app.domain.btc.research

import org.json.JSONArray
import org.json.JSONObject

/** Versioned, reproducible research artifact used by runtime consumers. */
data class ResearchArtifact(
    val artifactId: String,
    val createdAtMs: Long,
    val datasetCutoffMs: Long,
    val featureVersion: String,
    val modelVersion: String,
    val factorWeights: Map<String, Double>,
    val strategyWeights: Map<String, Double>,
    val fusionWeights: Map<String, Double>,
    val regime: String,
    val source: String = "WFO",
    val wfoSamples: Int = 0,
    val profitFactor: Double = 0.0,
    val maxDrawdownPct: Double = 0.0,
    val sharpe: Double = 0.0,
    val sortino: Double = 0.0,
    val brierScore: Double = 0.0,
    val logLoss: Double = 0.0,
    val ic: Double = 0.0,
    val icir: Double = 0.0,
    val costModelVersion: String = "",
    val lineageId: String = ""
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("artifactId", artifactId); put("createdAtMs", createdAtMs); put("datasetCutoffMs", datasetCutoffMs)
        put("featureVersion", featureVersion); put("modelVersion", modelVersion); put("regime", regime); put("source", source)
        put("factorWeights", JSONObject(factorWeights)); put("strategyWeights", JSONObject(strategyWeights)); put("fusionWeights", JSONObject(fusionWeights))
        put("wfoSamples", wfoSamples); put("profitFactor", profitFactor); put("maxDrawdownPct", maxDrawdownPct)
        put("sharpe", sharpe); put("sortino", sortino); put("brierScore", brierScore); put("logLoss", logLoss)
        put("ic", ic); put("icir", icir); put("costModelVersion", costModelVersion); put("lineageId", lineageId)
    }
}

object ResearchArtifactCodec {
    fun encode(artifact: ResearchArtifact): String = artifact.toJson().toString()
    fun decode(raw: String): ResearchArtifact {
        val o = JSONObject(raw)
        fun map(name: String): Map<String, Double> {
            val x = o.optJSONObject(name) ?: return emptyMap()
            return buildMap { x.keys().forEach { k -> put(k, x.optDouble(k, 0.0)) } }
        }
        return ResearchArtifact(o.getString("artifactId"), o.optLong("createdAtMs"), o.optLong("datasetCutoffMs"),
            o.optString("featureVersion"), o.optString("modelVersion"), map("factorWeights"), map("strategyWeights"), map("fusionWeights"), o.optString("regime"), o.optString("source", "WFO"), o.optInt("wfoSamples"), o.optDouble("profitFactor"), o.optDouble("maxDrawdownPct"), o.optDouble("sharpe"), o.optDouble("sortino"), o.optDouble("brierScore"), o.optDouble("logLoss"), o.optDouble("ic"), o.optDouble("icir"), o.optString("costModelVersion"), o.optString("lineageId"))
    }
}
