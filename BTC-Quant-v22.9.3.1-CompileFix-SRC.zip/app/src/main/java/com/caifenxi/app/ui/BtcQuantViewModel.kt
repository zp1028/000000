package com.caifenxi.app.ui

import com.caifenxi.app.util.AndroidCompat
import com.caifenxi.app.domain.btc.runtime.UnifiedExecutionGateway
import android.app.Application
import android.content.Intent
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.caifenxi.app.BtcQuantApplication
import com.caifenxi.app.domain.btc.BinanceDerivativesRepository
import com.caifenxi.app.domain.btc.BinanceMarketRepository
import com.caifenxi.app.domain.btc.BinanceOrderBookRepository
import com.caifenxi.app.domain.btc.BinanceLiveMarketStream
import com.caifenxi.app.domain.btc.BtcDashboardState
import com.caifenxi.app.domain.btc.BtcDemoDataProvider
import com.caifenxi.app.domain.btc.BtcDirection
import com.caifenxi.app.domain.btc.RealtimeMarketPoint
import com.caifenxi.app.domain.btc.BtcPlanEngine
import com.caifenxi.app.domain.btc.hs.HsPredictionEngine
import com.caifenxi.app.domain.btc.hs.HsRuntimeConfig
import com.caifenxi.app.domain.btc.hs.HsRuntimeConfigHolder
import com.caifenxi.app.domain.btc.hs.HsRuntimeConfigStore
import com.caifenxi.app.domain.btc.hs.ProductionReadiness
import com.caifenxi.app.domain.btc.coord.MarketDataCoordinator
import com.caifenxi.app.domain.btc.coord.PaperAccountCoordinator
import com.caifenxi.app.domain.btc.coord.HsEngineCoordinator
import com.caifenxi.app.domain.btc.coord.ExecutionCoordinator
import com.caifenxi.app.domain.btc.hs.ChainlinkOracleRepository
import com.caifenxi.app.domain.btc.polymarket.PolymarketRepository
import com.caifenxi.app.domain.btc.polymarket.PolymarketAccountRepository
import com.caifenxi.app.domain.btc.BtcSignalFactory
import com.caifenxi.app.domain.btc.DerivativesFeatureEngine
import com.caifenxi.app.domain.btc.TradingSignal
import com.caifenxi.app.domain.btc.factor.QuantFactorEngine
import com.caifenxi.app.domain.btc.factor.QuantFactorResearchEngine
import com.caifenxi.app.domain.btc.research.QuantResearchLifecycleEngine
import com.caifenxi.app.domain.btc.research.QuantResearchLifecycleStore
import com.caifenxi.app.domain.btc.factor.QuantFactorWeightStore
import com.caifenxi.app.domain.btc.plan.BtcPlanPoolStore
import com.caifenxi.app.domain.btc.polymarket.strategy.PolymarketAutoQuantEngine
import com.caifenxi.app.domain.btc.polymarket.strategy.PolymarketStrategyPool
import com.caifenxi.app.domain.btc.polymarket.research.PolymarketHistoryStore
import com.caifenxi.app.domain.btc.polymarket.research.PolymarketStrategyLifecycleEngine
import com.caifenxi.app.domain.btc.polymarket.research.PolymarketWalkForwardEngine
import com.caifenxi.app.domain.btc.ai.AiBrain
import com.caifenxi.app.domain.btc.ai.AiPolicy
import com.caifenxi.app.domain.btc.ai.AiPolicyConfig
import com.caifenxi.app.domain.btc.backtest.BacktestConfig
import com.caifenxi.app.domain.btc.backtest.BacktestRange
import com.caifenxi.app.domain.btc.backtest.BacktestResult
import com.caifenxi.app.domain.btc.backtest.BtcBacktestEngine
import com.caifenxi.app.domain.btc.backtest.BtcBacktestOptimizer
import com.caifenxi.app.domain.btc.backtest.BacktestOptimizationResult
import com.caifenxi.app.domain.btc.broker.BinanceFuturesBroker
import com.caifenxi.app.domain.btc.broker.BrokerCredentialStore
import com.caifenxi.app.domain.btc.broker.BrokerCredentials
import com.caifenxi.app.domain.btc.broker.PaperPerpBroker
import com.caifenxi.app.domain.btc.broker.BrokerFactory
import com.caifenxi.app.domain.btc.broker.PerpBroker
import com.caifenxi.app.domain.btc.futures.FuturesDailyStats
import com.caifenxi.app.domain.btc.futures.FuturesLogEntry
import com.caifenxi.app.domain.btc.futures.FuturesPosition
import com.caifenxi.app.domain.btc.futures.FuturesQuantConfig
import com.caifenxi.app.domain.btc.futures.FuturesQuantEngine
import com.caifenxi.app.domain.btc.futures.FuturesSignal
import com.caifenxi.app.domain.btc.futures.LogLevel
import com.caifenxi.app.domain.btc.futures.MarginMode
import com.caifenxi.app.domain.btc.futures.PositionManager
import com.caifenxi.app.domain.btc.futures.FuturesQuantConfigStore
import com.caifenxi.app.domain.btc.futures.FuturesExchangePositionStore
import com.caifenxi.app.domain.btc.futures.ExchangePositionSnapshot
import com.caifenxi.app.domain.btc.futures.PositionRiskInfo
import com.caifenxi.app.domain.btc.futures.FuturesPositionReconciler
import com.caifenxi.app.domain.btc.futures.PositionReconciliation
import com.caifenxi.app.domain.btc.futures.ReconciliationState
import com.caifenxi.app.domain.btc.futures.PositionSide
import com.caifenxi.app.domain.btc.futures.ClosePositionRequest
import com.caifenxi.app.domain.btc.futures.FuturesOrderType
import com.caifenxi.app.domain.btc.futures.FuturesOpenOrder
import com.caifenxi.app.domain.btc.futures.FuturesOrderReconciler
import com.caifenxi.app.domain.btc.futures.FuturesExecutionSnapshot
import com.caifenxi.app.domain.btc.futures.FuturesExecutionStateMachine
import com.caifenxi.app.domain.btc.news.CryptoNewsRepository
import com.caifenxi.app.domain.btc.paper.BinaryOptionAccount
import com.caifenxi.app.domain.btc.paper.BinaryOptionConfig
import com.caifenxi.app.domain.btc.paper.BinaryOptionEngine
import com.caifenxi.app.domain.btc.paper.BinaryOptionStore
import com.caifenxi.app.domain.btc.paper.BinaryOptionStats
import com.caifenxi.app.domain.btc.paper.BetDirection
import com.caifenxi.app.domain.btc.paper.BetRequest
import com.caifenxi.app.domain.btc.paper.BetResult
import com.caifenxi.app.domain.btc.paper.BetSource
import com.caifenxi.app.domain.btc.paper.BinanceOrderRequest
import com.caifenxi.app.domain.btc.paper.BinanceOrderResult
import com.caifenxi.app.domain.btc.paper.DailyControlConfig
import com.caifenxi.app.domain.btc.paper.DailyStats
import com.caifenxi.app.domain.btc.paper.EdgeAssessment
import com.caifenxi.app.domain.btc.paper.EdgeAssessmentEngine
import com.caifenxi.app.domain.btc.paper.MarketOdds
import com.caifenxi.app.domain.btc.paper.PolymarketOrderRequest
import com.caifenxi.app.domain.btc.paper.PolymarketOrderResult
import com.caifenxi.app.domain.btc.paper.PredictionMarketConnector
import com.caifenxi.app.domain.btc.paper.PredictionRound
import com.caifenxi.app.domain.btc.paper.SettledBet
import com.caifenxi.app.domain.btc.paper.StakeSizingEngine
import com.caifenxi.app.domain.btc.portfolio.MultiEngineOrchestrator
import com.caifenxi.app.domain.btc.runtime.BtcRunMode
import com.caifenxi.app.domain.btc.runtime.BtcRuntimeConfig
import com.caifenxi.app.domain.btc.runtime.BtcRuntimeState
import com.caifenxi.app.domain.btc.runtime.BtcRuntimeStatus
import com.caifenxi.app.domain.btc.runtime.BtcRuntimeStore
import com.caifenxi.app.domain.btc.runtime.LiveUnattendedGuard
import com.caifenxi.app.service.btc.BtcQuantRuntimeService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlin.math.abs
import com.caifenxi.app.domain.btc.runtime.PolymarketOrderLifecycleStore
import com.caifenxi.app.domain.btc.settlement.PolymarketSettlementPnLStore
import com.caifenxi.app.domain.btc.settlement.PolymarketSettlementPnLEngine
import com.caifenxi.app.domain.btc.runtime.PolymarketExecutionGuard
import com.caifenxi.app.domain.btc.runtime.PolymarketFundingGuard

/**
 * BTC 量化交易 ViewModel — 不再接受 Context 参数，通过 AndroidViewModel 获取 Application。
 */
class BtcQuantViewModel(application: Application) : AndroidViewModel(application) {

    private val app = getApplication<BtcQuantApplication>()

    private val runtimeStore: BtcRuntimeStore = BtcRuntimeStore(app)
    private val futuresRuntimeStore: BtcRuntimeStore = BtcRuntimeStore(app, "btc_futures_runtime")
    private val futuresConfigStore = FuturesQuantConfigStore(app)
    private val credentialStore = BrokerCredentialStore(app)
    private val dailyPnlStore = com.caifenxi.app.domain.btc.broker.DailyPnlStore(app)

    private val repo = BinanceMarketRepository()
    private val derivRepo = BinanceDerivativesRepository()
    private val orderBookRepo = BinanceOrderBookRepository()
    private val polymarketRepo = PolymarketRepository()
    private val newsRepo = CryptoNewsRepository()
    private val aiBrain = AiBrain()
    private val aiPolicy = AiPolicyConfig(allowLiveAiOrders = false)
    private val polymarketHistoryStore = PolymarketHistoryStore(app)
    private val polymarketOrderLifecycleStore = PolymarketOrderLifecycleStore(app)
    private val polymarketSettlementPnLStore = PolymarketSettlementPnLStore(app)
    private val polymarketAccountRepository = PolymarketAccountRepository()
    private val polymarketExecutionGuard = PolymarketExecutionGuard(app)
    private val polymarketFundingGuard = PolymarketFundingGuard()
    private val factorWeightStore = QuantFactorWeightStore(app)
    private val researchLifecycleStore = QuantResearchLifecycleStore(app)
    private val orchestrator = MultiEngineOrchestrator(
        polyHistoryStore = polymarketHistoryStore,
        polyLifecycleStore = polymarketOrderLifecycleStore,
        polyExecutionGuard = polymarketExecutionGuard,
        polyFundingGuard = polymarketFundingGuard
    )
    private val engine = BtcPlanEngine()
    private val binaryOptionStore = BinaryOptionStore(app)
    private val binaryOptionEngine = BinaryOptionEngine().also { eng ->
        binaryOptionStore.load()?.let { eng.restoreAccount(it) }
        eng.onAccountChanged = { acc -> binaryOptionStore.save(acc) }
    }
    private val refreshMutex = Mutex()
    private val hsEngine = HsPredictionEngine(app)
    private val marketDataCoordinator = MarketDataCoordinator(repo, derivRepo, orderBookRepo, newsRepo, polymarketRepo)
    private val liveMarketStream = BinanceLiveMarketStream()
    private val paperAccountCoordinator = PaperAccountCoordinator(binaryOptionEngine)
    private val hsEngineCoordinator = HsEngineCoordinator(hsEngine)
    private val executionCoordinator = ExecutionCoordinator()
    private val hsConfigStore = HsRuntimeConfigStore(app)
    private val _hsRuntimeConfig = MutableStateFlow(hsConfigStore.load().also { HsRuntimeConfigHolder.update(it) })
    val hsRuntimeConfig = _hsRuntimeConfig.asStateFlow()
    private val _readiness = MutableStateFlow<ProductionReadiness.Report?>(null)
    val readiness = _readiness.asStateFlow()
    private val _executionStatus = MutableStateFlow(executionCoordinator.status())
    val executionStatus = _executionStatus.asStateFlow()
    private val signalFactory = BtcSignalFactory()
    private val backtestEngine = BtcBacktestEngine()
    private val predictionMarketConnector = PredictionMarketConnector()
    private val stakeSizingEngine = StakeSizingEngine()
    private val edgeAssessmentEngine = EdgeAssessmentEngine()
    private val polymarketAutoQuantEngine = PolymarketAutoQuantEngine(factorWeights = factorWeightStore)

    /** Refresh BTC factor weights from point-in-time walk-forward research and persist them for runtime. */
    suspend fun refreshFactorWeights(): List<QuantFactorResearchEngine.Metric> {
        val candles = runCatching { repo.loadKlines(_state.value.symbol, _state.value.timeframe, 600) }.getOrDefault(emptyList())
        if (candles.size < 100) return emptyList()
        val metrics = QuantFactorResearchEngine.walkForward(candles, forwardBars = 3)
        if (metrics.isNotEmpty()) {
            factorWeightStore.save(metrics)
            val decisions = metrics.map { QuantResearchLifecycleEngine.evaluate(it) }
            val cutoff = candles.maxOfOrNull { it.openTime } ?: System.currentTimeMillis()
            researchLifecycleStore.save(decisions, cutoff)
        }
        return metrics
    }

    /** Refreshes settlement observations without claiming an on-chain redemption. */
    suspend fun reconcilePolymarketSettlement(user: String): List<com.caifenxi.app.domain.btc.settlement.PolymarketSettlementPnL> {
        val positions = polymarketAccountRepository.positions(user)
        val activities = polymarketAccountRepository.activity(user, limit = 500)
        val out = mutableListOf<com.caifenxi.app.domain.btc.settlement.PolymarketSettlementPnL>()
        positions.forEach { position ->
            val observed = PolymarketSettlementPnLEngine.fromResolvedPosition(position) ?: return@forEach
            val confirmed = PolymarketSettlementPnLEngine.confirmFromActivity(observed.pnl, activities)
            polymarketSettlementPnLStore.upsert(confirmed)
            out += confirmed
        }
        return out
    }

    fun polymarketSettlementPnlRecent(limit: Int = 50) = polymarketSettlementPnLStore.recent(limit)
    fun polymarketRealizedSettlementPnl(): Double = polymarketSettlementPnLStore.realizedTotal()
    fun polymarketSettlementFees(): Double = polymarketSettlementPnLStore.feeTotal()

    suspend fun refreshPolymarketStrategyLifecycle(): List<PolymarketStrategyLifecycleEngine.Decision> {
        val rows = polymarketHistoryStore.historyForAllStrategies()
        val metrics = PolymarketWalkForwardEngine.evaluate(rows)
        val byId = metrics.associateBy { it.strategyId }
        val decisions = PolymarketStrategyPool.definitions.map { def ->
            PolymarketStrategyLifecycleEngine.evaluate(byId[def.id], def)
        }
        PolymarketStrategyPool.applyLifecycle(decisions)
        return decisions
    }

    // === 合约量化引擎 ===
    private val futuresEngine = FuturesQuantEngine()
    private var positionManager = PositionManager(futuresConfigStore.load())
    private var perpBroker: PerpBroker = BrokerFactory.perp(credentialStore.load(), forcePaper = true)
    private var executionGateway: UnifiedExecutionGateway = UnifiedExecutionGateway(perp = perpBroker)
    private var lastFuturesAutoTickTime = 0L
    private var lastRealtimeUiEmitAt = 0L

    private val _state = MutableStateFlow(BtcDashboardState())
    val state: StateFlow<BtcDashboardState> = _state.asStateFlow()

    private val _orch = MutableStateFlow<String?>(null)
    val orchestratorNote: StateFlow<String?> = _orch.asStateFlow()

    private val _runtimeState = MutableStateFlow(runtimeStore.state())
    val runtimeState: StateFlow<BtcRuntimeState> = _runtimeState.asStateFlow()

    private val _runtimeConfig = MutableStateFlow(runtimeStore.config())
    val runtimeConfig: StateFlow<BtcRuntimeConfig> = _runtimeConfig.asStateFlow()

    private val _creds = MutableStateFlow(credentialStore.load())
    val credentials: StateFlow<BrokerCredentials> = _creds.asStateFlow()

    // === 策略池管理 ===
    data class PlanPoolConfig(
        // 必须与 BtcPlanRegistry.defaultPlans() 的 id 一致，否则策略池全灭、回测永远 0 笔
        val enabledPlans: Set<String> = setOf(
            "BTC-TURTLE", "BTC-EMA-TREND", "BTC-MACD",
            "BTC-MTF-PULLBACK", "BTC-RSI-RANGE", "BTC-BB-ATR",
            "BTC-VWAP-VOLUME", "BTC-FUNDING-FADE"
        ),
        val weightOverrides: Map<String, Double> = emptyMap()
    )

    private val planPoolStore = BtcPlanPoolStore(app)
    private fun loadPlanPoolConfig(): PlanPoolConfig {
        val stored = planPoolStore.load()
        return PlanPoolConfig(stored.enabledPlans, stored.weightOverrides)
    }
    private fun persistPlanPoolConfig(config: PlanPoolConfig) {
        planPoolStore.save(BtcPlanPoolStore.Config(config.enabledPlans, config.weightOverrides))
    }
    private val _planPoolConfig = MutableStateFlow(loadPlanPoolConfig())
    val planPoolConfig: StateFlow<PlanPoolConfig> = _planPoolConfig.asStateFlow()

    fun togglePlan(planId: String, enabled: Boolean) {
        val current = _planPoolConfig.value.enabledPlans.toMutableSet()
        if (enabled) current.add(planId) else current.remove(planId)
        _planPoolConfig.value = _planPoolConfig.value.copy(enabledPlans = current)
        persistPlanPoolConfig(_planPoolConfig.value)
    }

    fun updatePlanWeight(planId: String, weight: Double) {
        _planPoolConfig.value = _planPoolConfig.value.copy(
            weightOverrides = _planPoolConfig.value.weightOverrides + (planId to weight.coerceIn(0.05, 5.0))
        )
        persistPlanPoolConfig(_planPoolConfig.value)
    }

    fun resetPlanPool() {
        _planPoolConfig.value = PlanPoolConfig()
        persistPlanPoolConfig(_planPoolConfig.value)
    }

    // === 回测 ===
    data class BacktestUiState(
        val planId: String = "BTC-EMA-TREND",
        val config: BacktestConfig = BacktestConfig(),
        val result: BacktestResult? = null,
        val optimizationResults: List<BacktestOptimizationResult> = emptyList(),
        val loading: Boolean = false,
        val optimizing: Boolean = false,
        val error: String? = null
    )

    private val _backtestState = MutableStateFlow(BacktestUiState())
    val backtestState: StateFlow<BacktestUiState> = _backtestState.asStateFlow()

    // 与 BtcPlanRegistry.defaultPlans() 保持一致（旧 id 会导致回测匹配不到信号 → 永远 0 笔）
    val availablePlans = listOf(
        "BTC-EMA-TREND" to "EMA 趋势",
        "BTC-TURTLE" to "Turtle / Donchian",
        "BTC-MACD" to "MACD 动量",
        "BTC-MTF-PULLBACK" to "多周期回撤",
        "BTC-RSI-RANGE" to "RSI 均值回归",
        "BTC-BB-ATR" to "布林/ATR 突破",
        "BTC-VWAP-VOLUME" to "VWAP 量价",
        "BTC-FUNDING-FADE" to "资金费率消退"
    )

    fun selectBacktestPlan(planId: String) {
        _backtestState.value = _backtestState.value.copy(planId = planId)
    }

    fun updateBacktestConfig(config: BacktestConfig) {
        _backtestState.value = _backtestState.value.copy(config = config)
    }

    private suspend fun loadBacktestWindow(config: BacktestConfig): Pair<List<com.caifenxi.app.domain.btc.BtcCandle>, Int> {
        val now = System.currentTimeMillis()
        val end = config.customEndTimeMs?.takeIf { config.range == BacktestRange.CUSTOM } ?: now
        val start = when (config.range) {
            BacktestRange.CUSTOM -> config.customStartTimeMs ?: error("自定义回测需要开始时间")
            else -> end - config.range.days * 86_400_000L
        }
        require(start < end) { "回测时间范围无效" }
        val candles = repo.loadKlinesRange(
            symbol = _state.value.symbol.ifBlank { "BTCUSDT" },
            interval = _state.value.timeframe.ifBlank { "15m" },
            startTimeMs = start,
            endTimeMs = end,
            warmupBars = 100
        )
        val testStart = candles.indexOfFirst { it.openTime >= start }
        if (testStart < 0) error("历史数据没有覆盖所选回测开始时间")
        val testBars = candles.drop(testStart).size
        val expectedBars = when (config.range) {
            BacktestRange.CUSTOM -> ((end - start) / intervalMillis(_state.value.timeframe)).toInt()
            else -> (config.range.days * 86_400_000L / intervalMillis(_state.value.timeframe)).toInt()
        }
        if (testBars < (expectedBars * 0.95).toInt()) {
            val actualDays = ((candles.last().openTime - candles[testStart].openTime).coerceAtLeast(0L)).toDouble() / 86_400_000.0
            error("真实行情覆盖不足：需要约 ${config.range.days} 天，实际约 %.1f 天（${testBars} 根），未使用 Demo 数据".format(actualDays))
        }
        return candles to testStart
    }

    private fun intervalMillis(interval: String): Long = when (interval) {
        "1m" -> 60_000L
        "5m" -> 300_000L
        "15m" -> 900_000L
        "30m" -> 1_800_000L
        "1h" -> 3_600_000L
        "4h" -> 14_400_000L
        "1d" -> 86_400_000L
        else -> 900_000L
    }

    fun runBacktestOptimization() {
        _backtestState.value = _backtestState.value.copy(optimizing = true, error = null)
        viewModelScope.launch(Dispatchers.Default) {
            runCatching {
                val bt = _backtestState.value
                val (candles, testStart) = loadBacktestWindow(bt.config)
                // Optimizer receives the complete real-data window including warm-up;
                // its own walk-forward split is therefore not polluted by synthetic candles.
                BtcBacktestOptimizer.optimize(
                    engine = backtestEngine,
                    planId = bt.planId,
                    candles = candles,
                    base = bt.config,
                    topK = 10
                ) to testStart
            }.onSuccess { (results, _) ->
                _backtestState.value = _backtestState.value.copy(optimizationResults = results, optimizing = false)
            }.onFailure { e ->
                _backtestState.value = _backtestState.value.copy(optimizing = false, error = e.message ?: "参数优化失败")
            }
        }
    }

    fun runBacktest() {
        _backtestState.value = _backtestState.value.copy(loading = true, error = null)
        viewModelScope.launch(Dispatchers.Default) {
            runCatching {
                val bt = _backtestState.value
                val (candles, testStart) = loadBacktestWindow(bt.config)
                val result = backtestEngine.run(
                    planId = bt.planId,
                    candles = candles,
                    config = bt.config,
                    startIndex = testStart,
                    endIndex = candles.lastIndex
                )
                val note = when {
                    result.sampleSize == 0 ->
                        "所选真实样本期内未产生有效信号（方向均为 FLAT 或 planId 未匹配）。"
                    else -> null
                }
                result to note
            }.onSuccess { (result, note) ->
                _backtestState.value = _backtestState.value.copy(result = result, loading = false, error = note)
            }.onFailure { e ->
                _backtestState.value = _backtestState.value.copy(loading = false, error = e.message ?: "回测执行失败")
            }
        }
    }

    fun buildPerpSignalPreview(positionSize: Double = 0.001): TradingSignal.ContractSignal? {
        val s = _state.value
        val c = s.consensus ?: return null
        return signalFactory.buildPerpSignal(s.symbol, s.candles, s.plans, c, positionSize)
    }

    // ==================== 交易闭环：SIM / LIVE + SL/TP 括号单 + 持仓 ====================

    enum class TradeExecMode { SIM, LIVE }

    data class TradeRiskLimits(
        val maxLeverage: Int = 10,
        val maxNotionalUsdt: Double = 500.0,
        val maxDailyLossUsdt: Double = 100.0,
        val requireSlTp: Boolean = true
    )

    data class LivePositionUi(
        val symbol: String,
        val positionAmt: Double,
        val entryPrice: Double,
        val markPrice: Double,
        val unrealizedPnl: Double,
        val leverage: String,
        val marginType: String
    )

    data class TradeTicketResult(
        val ok: Boolean,
        val mode: TradeExecMode,
        val message: String,
        val entryOrderId: Long? = null,
        val slOrderId: Long? = null,
        val tpOrderId: Long? = null
    )

    private val _tradeMode = MutableStateFlow(TradeExecMode.SIM)
    val tradeMode: StateFlow<TradeExecMode> = _tradeMode.asStateFlow()

    private val _tradeRisk = MutableStateFlow(TradeRiskLimits())
    val tradeRisk: StateFlow<TradeRiskLimits> = _tradeRisk.asStateFlow()

    private val _livePosition = MutableStateFlow<LivePositionUi?>(null)
    val livePosition: StateFlow<LivePositionUi?> = _livePosition.asStateFlow()

    private val _lastTradeTicket = MutableStateFlow<TradeTicketResult?>(null)
    val lastTradeTicket: StateFlow<TradeTicketResult?> = _lastTradeTicket.asStateFlow()

    private val _tradeBusy = MutableStateFlow(false)
    val tradeBusy: StateFlow<Boolean> = _tradeBusy.asStateFlow()

    fun realizedPnlToday(): Double = dailyPnlStore.realizedPnlToday()

    fun resetDailyPnl() {
        dailyPnlStore.resetToday()
    }

    fun setTradeMode(mode: TradeExecMode) {
        _tradeMode.value = mode
        val creds = credentialStore.load()
        if (mode == TradeExecMode.LIVE && (creds.binanceApiKey.isBlank() || creds.binanceSecret.isBlank())) {
            _lastTradeTicket.value = TradeTicketResult(false, mode, "LIVE 未配置 Binance API Key/Secret，不允许回退到 SIM")
            return
        }
        perpBroker = when (mode) {
            TradeExecMode.SIM -> com.caifenxi.app.domain.btc.broker.PaperPerpBroker()
            TradeExecMode.LIVE -> BrokerFactory.perp(creds, forcePaper = false)
        }
        executionGateway = UnifiedExecutionGateway(perp = perpBroker)
        refreshLivePosition()
    }

    fun updateTradeRisk(limits: TradeRiskLimits) {
        _tradeRisk.value = limits.copy(
            maxLeverage = limits.maxLeverage.coerceIn(1, 20),
            maxNotionalUsdt = limits.maxNotionalUsdt.coerceAtLeast(10.0),
            maxDailyLossUsdt = limits.maxDailyLossUsdt.coerceAtLeast(1.0)
        )
    }

    fun refreshLivePosition(symbol: String = _state.value.symbol) {
        viewModelScope.launch {
            runCatching {
                val risk = perpBroker.fetchPositionRisk(symbol)
                _livePosition.value = risk?.takeIf { kotlin.math.abs(it.positionAmt) > 1e-12 }?.let {
                    LivePositionUi(
                        symbol = it.symbol,
                        positionAmt = it.positionAmt,
                        entryPrice = it.entryPrice,
                        markPrice = it.markPrice,
                        unrealizedPnl = it.unRealizedProfit,
                        leverage = it.leverage,
                        marginType = it.marginType
                    )
                }
            }
        }
    }

    /**
     * 下单闭环：杠杆 → 市价开仓 → SL/TP 条件单。
     * SIM 使用 PaperPerpBroker；LIVE 需密钥且 confirmLive=true。
     */
    fun placePerpWithBracket(positionSize: Double, leverage: Int, confirmLive: Boolean = false) {
        viewModelScope.launch {
            if (_tradeBusy.value) return@launch
            _tradeBusy.value = true
            try {
                val mode = _tradeMode.value
                val limits = _tradeRisk.value
                if (mode == TradeExecMode.LIVE && !confirmLive) {
                    _lastTradeTicket.value = TradeTicketResult(false, mode, "LIVE 需要二次确认")
                    return@launch
                }
                if (mode == TradeExecMode.LIVE && _creds.value.binanceApiKey.isBlank()) {
                    _lastTradeTicket.value = TradeTicketResult(false, mode, "LIVE 需要配置 API Key")
                    return@launch
                }
                val dayPnl = dailyPnlStore.realizedPnlToday()
                if (dayPnl <= -limits.maxDailyLossUsdt) {
                    _lastTradeTicket.value = TradeTicketResult(
                        false, mode,
                        "日损熔断已触发（今日 ${"%.2f".format(dayPnl)} / 限 ${limits.maxDailyLossUsdt} USDT），禁止开仓"
                    )
                    return@launch
                }
                val sym = _state.value.symbol
                val qty = com.caifenxi.app.domain.btc.broker.ExchangeFilters.roundQty(sym, positionSize)
                if (qty <= 0.0) {
                    _lastTradeTicket.value = TradeTicketResult(false, mode, "数量过小，低于最小下单量")
                    return@launch
                }
                val preview = buildPerpSignalPreview(qty)
                if (preview == null || preview.direction == BtcDirection.FLAT) {
                    _lastTradeTicket.value = TradeTicketResult(false, mode, "无有效信号（需非 FLAT 共识）")
                    return@launch
                }
                val lev = leverage.coerceIn(1, limits.maxLeverage)
                val entryPx = com.caifenxi.app.domain.btc.broker.ExchangeFilters.roundPrice(sym, preview.entry)
                val slPx = com.caifenxi.app.domain.btc.broker.ExchangeFilters.roundPrice(sym, preview.stopLoss)
                val tpPx = com.caifenxi.app.domain.btc.broker.ExchangeFilters.roundPrice(sym, preview.takeProfit)
                val notional = qty * entryPx
                if (notional > limits.maxNotionalUsdt) {
                    _lastTradeTicket.value = TradeTicketResult(
                        false, mode, "名义价值 ${"%.2f".format(notional)} 超过上限 ${limits.maxNotionalUsdt}"
                    )
                    return@launch
                }
                if (limits.requireSlTp && (slPx <= 0 || tpPx <= 0)) {
                    _lastTradeTicket.value = TradeTicketResult(false, mode, "缺少有效 SL/TP")
                    return@launch
                }

                val signal = preview.copy(
                    positionSize = qty,
                    leverageCap = lev,
                    entry = entryPx,
                    stopLoss = slPx,
                    takeProfit = tpPx
                )
                val clientId = "cfx-${System.currentTimeMillis() % 1_000_000_000}".take(36)

                val levRes = executionGateway.setPerpLeverage(signal.symbol, lev)
                if (!levRes.success && mode == TradeExecMode.LIVE) {
                    _lastTradeTicket.value = TradeTicketResult(false, mode, "设杠杆失败: ${levRes.message}")
                    return@launch
                }

                val entryRes = executionGateway.placePerp(signal, clientId)
                if (!entryRes.success) {
                    _lastTradeTicket.value = TradeTicketResult(false, mode, "开仓失败: ${entryRes.message}")
                    return@launch
                }

                val closeSide = if (signal.direction == BtcDirection.UP) "SELL" else "BUY"
                val slRes = executionGateway.placePerpConditional(
                    symbol = signal.symbol,
                    side = closeSide,
                    type = com.caifenxi.app.domain.btc.futures.FuturesOrderType.STOP_MARKET,
                    quantity = qty,
                    stopPrice = signal.stopLoss,
                    clientOrderId = ("sl-" + clientId).take(36)
                )
                val tpRes = executionGateway.placePerpConditional(
                    symbol = signal.symbol,
                    side = closeSide,
                    type = com.caifenxi.app.domain.btc.futures.FuturesOrderType.TAKE_PROFIT_MARKET,
                    quantity = qty,
                    stopPrice = signal.takeProfit,
                    clientOrderId = ("tp-" + clientId).take(36)
                )

                val msg = buildString {
                    append(if (mode == TradeExecMode.SIM) "SIM" else "LIVE")
                    append(" 开仓 ").append(signal.direction.name)
                    append(" qty=").append(qty)
                    append(" @").append("%.2f".format(signal.entry))
                    append(" lev=").append(lev).append("x")
                    append(" dayPnL=").append("%.2f".format(dayPnl)).append('\n')
                    append("entry=").append(entryRes.status).append(" ").append(entryRes.message).append('\n')
                    append("SL=").append(if (slRes.success) "OK ${signal.stopLoss}" else "FAIL ${slRes.message}").append('\n')
                    append("TP=").append(if (tpRes.success) "OK ${signal.takeProfit}" else "FAIL ${tpRes.message}")
                }
                _lastTradeTicket.value = TradeTicketResult(
                    ok = true,
                    mode = mode,
                    message = msg,
                    entryOrderId = entryRes.orderId,
                    slOrderId = slRes.orderId,
                    tpOrderId = tpRes.orderId
                )
                refreshLivePosition(signal.symbol)
            } catch (e: Exception) {
                _lastTradeTicket.value = TradeTicketResult(false, _tradeMode.value, e.message ?: "下单异常")
            } finally {
                _tradeBusy.value = false
            }
        }
    }

    fun closeLivePosition(symbol: String = _state.value.symbol) {
        viewModelScope.launch {
            if (_tradeBusy.value) return@launch
            _tradeBusy.value = true
            try {
                // 平仓前快照，用于估算已实现盈亏并写入日统计
                val before = perpBroker.fetchPositionRisk(symbol)
                val res = executionGateway.closePerpPosition(
                    com.caifenxi.app.domain.btc.futures.ClosePositionRequest(
                        symbol = symbol,
                            reason = "manual_close"
                    )
                )
                if (res.success && before != null && kotlin.math.abs(before.positionAmt) > 1e-12) {
                    // 优先用交易所返回的未实现盈亏作为平仓实现盈亏近似
                    val realized = before.unRealizedProfit
                    if (realized.isFinite()) {
                        dailyPnlStore.addRealized(realized)
                    }
                }
                val day = dailyPnlStore.realizedPnlToday()
                _lastTradeTicket.value = TradeTicketResult(
                    res.success, _tradeMode.value,
                    if (res.success) {
                        "已平仓: ${res.message}\n计入日PnL后今日=${"%.2f".format(day)} USDT"
                    } else {
                        "平仓失败: ${res.message}"
                    }
                )
                refreshLivePosition(symbol)
            } catch (e: Exception) {
                _lastTradeTicket.value = TradeTicketResult(false, _tradeMode.value, e.message ?: "平仓异常")
            } finally {
                _tradeBusy.value = false
            }
        }
    }

    /** 尝试从当前 broker 端点或公共主网拉 exchangeInfo 精度 */
    fun refreshExchangeFilters(symbol: String = _state.value.symbol) {
        viewModelScope.launch {
            val broker = perpBroker
            val ok = if (broker is BinanceFuturesBroker) {
                broker.loadSymbolFilters(symbol)
            } else {
                // Paper 模式：直连公共主网只读接口
                runCatching {
                    val client = okhttp3.OkHttpClient()
                    val url = "https://fapi.binance.com/fapi/v1/exchangeInfo?symbol=${symbol.uppercase()}"
                    val req = okhttp3.Request.Builder().url(url).get().build()
                    client.newCall(req).execute().use { resp ->
                        val body = resp.body?.string().orEmpty()
                        resp.isSuccessful && com.caifenxi.app.domain.btc.broker.ExchangeFilters
                            .updateFromExchangeInfoJson(body, preferSymbol = symbol)
                    }
                }.getOrDefault(false)
            }
            _lastTradeTicket.value = TradeTicketResult(
                ok, _tradeMode.value,
                if (ok) {
                    val f = com.caifenxi.app.domain.btc.broker.ExchangeFilters.forSymbol(symbol)
                    "已更新 $symbol 精度: step=${f.qtyStep} tick=${f.priceTick} minQty=${f.qtyMin}"
                } else {
                    "exchangeInfo 拉取失败，仍使用默认精度"
                }
            )
        }
    }

    // === 二元期权自动下注日志 ===
    data class AutoTradeLogEntry(
        val timestamp: Long,
        val direction: String,         // YES / NO
        val betAmount: Double,         // 下注金额 USDT
        val odds: Double,              // 赔率
        val roundId: Long,             // 周期 ID
        val openPrice: Double,         // 开窗价格
        val mode: String,              // PAPER / POLYMARKET / BINANCE
        val result: String
    )

    private val _autoTradeLog = MutableStateFlow<List<AutoTradeLogEntry>>(emptyList())
    val autoTradeLog: StateFlow<List<AutoTradeLogEntry>> = _autoTradeLog.asStateFlow()

    fun addAutoTradeLog(entry: AutoTradeLogEntry) {
        _autoTradeLog.value = (listOf(entry) + _autoTradeLog.value).take(100)
    }

    fun clearAutoTradeLog() {
        _autoTradeLog.value = emptyList()
    }

    /** 更新运行时配置（自动下注 / 无人值守参数） */
    fun updateRuntimeConfig(
        symbol: String? = null,
        timeframe: String? = null,
        runMode: BtcRunMode? = null,
        maxPositionQty: Double? = null,
        pollSeconds: Long? = null,
        maxLeverage: Int? = null,
        maxNotionalUsdt: Double? = null,
        maxDailyLossUsdt: Double? = null,
        minProbability: Double? = null,
        liveAutoAuthorized: Boolean? = null
    ) {
        val current = runtimeStore.config()
        val updated = current.copy(
            symbol = symbol ?: current.symbol,
            timeframe = timeframe ?: current.timeframe,
            runMode = runMode ?: current.runMode,
            maxPositionQty = maxPositionQty ?: current.maxPositionQty,
            pollSeconds = pollSeconds ?: current.pollSeconds,
            maxLeverage = maxLeverage ?: current.maxLeverage,
            maxNotionalUsdt = maxNotionalUsdt ?: current.maxNotionalUsdt,
            maxDailyLossUsdt = maxDailyLossUsdt ?: current.maxDailyLossUsdt,
            minProbability = minProbability ?: current.minProbability,
            liveAutoAuthorized = liveAutoAuthorized ?: current.liveAutoAuthorized
        )
        runtimeStore.saveConfig(updated)
        _runtimeConfig.value = runtimeStore.config()
    }

    /**
     * 授权 / 撤销 LIVE 无人值守。
     * @param confirmPhrase 必须为 [LIVE_AUTO_CONFIRM_PHRASE]，防止误触
     */
    fun saveHsRuntimeConfig(cfg: HsRuntimeConfig) {
        hsConfigStore.save(cfg)
        HsRuntimeConfigHolder.update(cfg)
        _hsRuntimeConfig.value = HsRuntimeConfigHolder.current
        evaluateReadiness()
        addAutoTradeLog(
            AutoTradeLogEntry(
                System.currentTimeMillis(), "FLAT", 0.0, 0.0, 0L, 0.0,
                _runtimeConfig.value.runMode.name,
                "HS 风控参数已保存 minEdge=${"%.1f".format(cfg.minNetEdge * 100)}% maxRisk=${"%.1f".format(cfg.maxRiskFraction * 100)}%"
            )
        )
    }

    fun evaluateReadiness() {
        _readiness.value = ProductionReadiness.evaluate(
            snapshot = _state.value.hsSnapshot,
            creds = credentialStore.load(),
            runtimeCfg = runtimeStore.config(),
            runtimeState = runtimeStore.state(),
            execKill = executionCoordinator.isKillSwitchOn(),
            hsCfg = HsRuntimeConfigHolder.current
        )
        _executionStatus.value = executionCoordinator.status()
    }

    fun setExecutionKillSwitch(on: Boolean) {
        executionCoordinator.setKillSwitch(on)
        runtimeStore.setKillSwitch(on)
        _executionStatus.value = executionCoordinator.status()
        refreshRuntimeState()
        addAutoTradeLog(
            AutoTradeLogEntry(
                System.currentTimeMillis(), "FLAT", 0.0, 0.0, 0L, 0.0,
                _runtimeConfig.value.runMode.name,
                if (on) "Kill Switch 已开启 — 禁止新开仓" else "Kill Switch 已关闭"
            )
        )
    }

    fun refreshExecutionStatus() {
        _executionStatus.value = executionCoordinator.status()
    }

    fun authorizeLiveUnattended(confirmPhrase: String, authorize: Boolean): String {
        if (authorize) {
            if (confirmPhrase.trim() != LIVE_AUTO_CONFIRM_PHRASE) {
                return "授权失败：请完整输入确认语「$LIVE_AUTO_CONFIRM_PHRASE」"
            }
            val creds = credentialStore.load()
            if (creds.binanceApiKey.isBlank() || creds.binanceSecret.isBlank()) {
                return "授权失败：请先配置币安 API Key/Secret"
            }
            updateRuntimeConfig(liveAutoAuthorized = true, runMode = BtcRunMode.LIVE)
            return "已授权 LIVE 无人值守。仍受日损/仓位/连续失败熔断约束。资金有风险。"
        } else {
            updateRuntimeConfig(liveAutoAuthorized = false, runMode = BtcRunMode.PAPER)
            setRuntimeEnabled(false, BtcRunMode.PAPER)
            return "已撤销 LIVE 授权，并停止运行时"
        }
    }

    companion object {
        const val LIVE_AUTO_CONFIRM_PHRASE = "I ACCEPT LIVE AUTO RISK"
    }

    /**
     * 执行一次二元期权自动下注。
     * 变动赔率链路：EdgeAssessment(模型概率 vs 市场定价) -> 锁定方向 -> 固定1U + 变动赔率 -> 平台下单
     * 日级控制：日亏损达阈值或日止盈达目标时自动停机。
     */
    fun executeAutoTradeTick() {
        val s = _state.value
        val cfg = _runtimeConfig.value
        val now = System.currentTimeMillis()
        val currentPrice = s.candles.lastOrNull()?.close ?: s.markPrice ?: 0.0

        if (currentPrice <= 0) {
            addAutoTradeLog(AutoTradeLogEntry(
                now, "FLAT", 0.0, 0.0, 0L, 0.0,
                cfg.runMode.name, "无可用价格，跳过"
            ))
            return
        }

        // === 日级止盈止损检查 ===
        if (binaryOptionEngine.shouldStopAutoTrading()) {
            val reason = binaryOptionEngine.dailyStopReason() ?: "日级控制停机"
            addAutoTradeLog(AutoTradeLogEntry(
                now, "FLAT", 0.0, 0.0, 0L, 0.0,
                cfg.runMode.name, "日级停机: $reason"
            ))
            refreshBinaryOptionState()
            return
        }

        // 确保周期存在（方向已在 tickBinaryRound 中通过 edge 评估锁定）
        val round = binaryOptionEngine.ensureRound(now, currentPrice)

        val direction = round.lockedDirection

        if (direction == null) {
            val assessment = _edgeAssessment.value
            addAutoTradeLog(AutoTradeLogEntry(
                now, "FLAT", 0.0, assessment?.chosenOdds ?: 0.0,
                round.roundId, round.openPrice,
                cfg.runMode.name,
                if (assessment != null) "Edge 不足，跳过: ${assessment.reason}" else "本周期未锁定方向"
            ))
            return
        }

        // === 防止同周期重复下注 ===
        if (binaryOptionEngine.account().hasBetForRound(round.roundId)) {
            addAutoTradeLog(AutoTradeLogEntry(
                now, direction.name, 0.0,
                _edgeAssessment.value?.chosenOdds ?: 0.0,
                round.roundId, round.openPrice,
                cfg.runMode.name, "本周期已下注，等待结算"
            ))
            return
        }

        // === 变动赔率 + 固定 1U 下注 ===
        val assessment = _edgeAssessment.value
        val odds = assessment?.chosenOdds ?: 1.9  // 回退到默认赔率（无市场数据时）
        val betAmount = 1.0  // 固定 1 USDT/注

        // === 执行协调器：Kill Switch / 数据门 / 冷却 / 幂等 ===
        val hs = s.hsSnapshot
        if (hs != null) {
            val verdict = executionCoordinator.canExecute(
                snapshot = hs,
                marketId = "BTC-BINARY-${s.timeframe}",
                direction = direction.name,
                windowId = round.roundId.toString(),
                nowMs = now
            )
            if (!verdict.allowed) {
                _executionStatus.value = executionCoordinator.status()
                addAutoTradeLog(AutoTradeLogEntry(
                    now, direction.name, 0.0, odds, round.roundId, round.openPrice,
                    cfg.runMode.name, "执行门控: ${verdict.reason}"
                ))
                return
            }
            _executionStatus.value = executionCoordinator.status()
        }

        // 余额检查
        val balance = _binaryAccount.value.balance
        if (balance < betAmount) {
            addAutoTradeLog(AutoTradeLogEntry(
                now, direction.name, 0.0, odds, round.roundId, round.openPrice,
                cfg.runMode.name, "余额不足: 需 %.0f, 可用 %.2f".format(betAmount, balance)
            ))
            return
        }

        // 更新 stake preview（供 UI 展示）
        val suggestion = stakeSizingEngine.calculate(
            balance = balance,
            odds = odds,
            consensusProbability = assessment?.chosenModelProb ?: 0.5,
            consensusStrength = s.consensus?.consensusStrength ?: 0.5
        )
        _stakePreview.value = suggestion

        val betSource = when (cfg.runMode) {
            BtcRunMode.PAPER -> BetSource.PAPER
            BtcRunMode.TESTNET -> BetSource.POLYMARKET
            BtcRunMode.LIVE -> BetSource.BINANCE
        }

        when (betSource) {
            BetSource.PAPER -> executePaperBet(direction, betAmount, odds, round, now, cfg.runMode.name, suggestion)
            BetSource.POLYMARKET -> executePolymarketBet(direction, betAmount, odds, round, now, suggestion)
            BetSource.BINANCE -> executeBinanceBet(direction, betAmount, odds, round, now, suggestion)
        }
    }

    /** Paper 模式：本地模拟下注 */
    private fun executePaperBet(
        direction: BetDirection,
        amount: Double,
        odds: Double,
        round: PredictionRound,
        now: Long,
        modeName: String,
        suggestion: StakeSizingEngine.StakeSuggestion
    ) {
        val req = BetRequest(
            direction = direction,
            amount = amount,
            odds = odds,
            source = BetSource.PAPER,
            timestamp = now
        )
        when (val result = binaryOptionEngine.placeBet(req, now)) {
            is BetResult.Accepted -> {
                executionCoordinator.markPlaced(
                    "BTC-BINARY-${_state.value.timeframe}|${direction.name}|${round.roundId}"
                )
                val msg = "PAPER -> ${direction.label} · %.0f USDT @ %.2fx · EV=%+.3f".format(
                    amount, odds, suggestion.expectedValue
                )
                addAutoTradeLog(AutoTradeLogEntry(
                    now, direction.name, amount, odds, round.roundId, round.openPrice, modeName, msg
                ))
                _lastExecution.value = ExecutionResult(
                    now, direction, amount, odds, round.roundId, round.openPrice,
                    modeName, true, result.bet.betId, msg
                )
                refreshBinaryOptionState()
            }
            is BetResult.Rejected -> {
                val msg = "REJECTED: ${result.reason}"
                addAutoTradeLog(AutoTradeLogEntry(
                    now, direction.name, amount, odds, round.roundId, round.openPrice, modeName, msg
                ))
                _lastExecution.value = ExecutionResult(
                    now, direction, amount, odds, round.roundId, round.openPrice,
                    modeName, false, null, msg
                )
            }
        }
    }

    /** Polymarket 模式：真实下单到 Polymarket CLOB */
    private fun executePolymarketBet(
        direction: BetDirection,
        amount: Double,
        odds: Double,
        round: PredictionRound,
        now: Long,
        suggestion: StakeSizingEngine.StakeSuggestion
    ) {
        val creds = credentialStore.load()
        val polyMarket = _marketOddsList.value.firstOrNull { it.platform == "POLYMARKET" && !it.resolved }

        // 查找匹配的 Polymarket 市场 tokenId
        val tokenId = polyMarket?.marketId ?: ""
        val price = if (direction == BetDirection.YES) {
            polyMarket?.yesPrice ?: MarketOdds.oddsToPrice(odds)
        } else {
            polyMarket?.noPrice ?: MarketOdds.oddsToPrice(odds)
        }
        val size = if (price > 0) amount / price else amount / odds

        val orderReq = PolymarketOrderRequest(
            tokenId = tokenId,
            side = "BUY",
            price = price,
            size = size,
            feeRateBps = 0
        )

        viewModelScope.launch {
            val result = predictionMarketConnector.placePolymarketOrder(
                request = orderReq,
                apiKey = creds.polymarketApiKey,
                apiSecret = creds.polymarketApiSecret,
                passphrase = creds.polymarketPassphrase,
                dryRun = creds.polymarketDryRun || creds.polymarketApiKey.isBlank()
            )

            val modeName = if (creds.polymarketDryRun || creds.polymarketApiKey.isBlank()) "POLYMARKET-DRY" else "POLYMARKET"

            if (result.success) {
                executionCoordinator.markPlaced(
                    "POLYMARKET|${direction.name}|${round.roundId}|$tokenId"
                )
                _executionStatus.value = executionCoordinator.status()
                // 同时在本地引擎记录 Paper 账本（用于跟踪统计）
                val localReq = BetRequest(
                    direction = direction,
                    amount = amount,
                    odds = odds,
                    source = BetSource.POLYMARKET,
                    platformMarketId = tokenId,
                    timestamp = now
                )
                binaryOptionEngine.placeBet(localReq, now)
                refreshBinaryOptionState()

                val msg = "$modeName -> ${direction.label} · %.0f USDT @ %.1fx · orderId=%s".format(
                    amount, odds, result.orderId ?: "?"
                )
                addAutoTradeLog(AutoTradeLogEntry(
                    now, direction.name, amount, odds, round.roundId, round.openPrice, modeName, msg
                ))
                _lastExecution.value = ExecutionResult(
                    now, direction, amount, odds, round.roundId, round.openPrice,
                    modeName, true, result.orderId, msg
                )
            } else {
                val msg = "POLYMARKET FAIL: ${result.error ?: result.status}"
                addAutoTradeLog(AutoTradeLogEntry(
                    now, direction.name, amount, odds, round.roundId, round.openPrice, modeName, msg
                ))
                _lastExecution.value = ExecutionResult(
                    now, direction, amount, odds, round.roundId, round.openPrice,
                    modeName, false, null, msg
                )
            }
        }
    }

    /** Binance 模式：真实现货下单作为方向代理 */
    private fun executeBinanceBet(
        direction: BetDirection,
        amount: Double,
        odds: Double,
        round: PredictionRound,
        now: Long,
        suggestion: StakeSizingEngine.StakeSuggestion
    ) {
        val creds = credentialStore.load()
        if (creds.binanceApiKey.isBlank()) {
            val msg = "BINANCE: API Key 未配置，降级为 Paper"
            addAutoTradeLog(AutoTradeLogEntry(
                now, direction.name, amount, odds, round.roundId, round.openPrice, "BINANCE-NOKEY", msg
            ))
            executePaperBet(direction, amount, odds, round, now, "BINANCE-NOKEY", suggestion)
            return
        }

        // 方向 -> Binance 交易方向：YES(涨)=BUY，NO(跌)=SELL（先卖出再买回）
        // 但现货不能做空，所以 NO 方向时买入 BTC 后在结算时卖出
        // 简化处理：YES=BUY BTC（赌涨），NO 不下单仅本地记录（真实做空需要合约，违反无杠杆约束）
        val binanceSide = if (direction == BetDirection.YES) "BUY" else "SELL"

        // 计算购买 BTC 数量
        val btcPrice = round.openPrice
        val quantity = if (btcPrice > 0) amount / btcPrice * 0.99 else 0.0  // 0.99 留手续费

        if (quantity <= 0) {
            addAutoTradeLog(AutoTradeLogEntry(
                now, direction.name, amount, odds, round.roundId, round.openPrice,
                "BINANCE", "数量计算失败: price=$btcPrice"
            ))
            return
        }

        val orderReq = BinanceOrderRequest(
            symbol = _state.value.symbol,
            side = binanceSide,
            quantity = quantity,
            orderType = "MARKET"
        )

        val testnet = creds.binanceEndpoint.name != "MAINNET"

        viewModelScope.launch {
            val result = predictionMarketConnector.placeBinanceOrder(
                request = orderReq,
                apiKey = creds.binanceApiKey,
                apiSecret = creds.binanceSecret,
                testnet = testnet
            )

            val modeName = if (testnet) "BINANCE-TESTNET" else "BINANCE-LIVE"

            if (result.success) {
                executionCoordinator.markPlaced(
                    "BINANCE|${direction.name}|${round.roundId}|${_state.value.symbol}"
                )
                // 同时在本地引擎记录
                val localReq = BetRequest(
                    direction = direction,
                    amount = amount,
                    odds = odds,
                    source = BetSource.BINANCE,
                    platformMarketId = result.orderId?.toString(),
                    timestamp = now
                )
                binaryOptionEngine.placeBet(localReq, now)
                refreshBinaryOptionState()

                val msg = "$modeName -> ${direction.label} · %.0f USDT · qty=%.6f BTC · orderId=%d · status=%s".format(
                    amount, quantity, result.orderId ?: 0L, result.status
                )
                addAutoTradeLog(AutoTradeLogEntry(
                    now, direction.name, amount, odds, round.roundId, round.openPrice, modeName, msg
                ))
                _lastExecution.value = ExecutionResult(
                    now, direction, amount, odds, round.roundId, round.openPrice,
                    modeName, true, result.orderId?.toString(), msg
                )
            } else {
                val msg = "BINANCE FAIL: ${result.error ?: result.status}"
                addAutoTradeLog(AutoTradeLogEntry(
                    now, direction.name, amount, odds, round.roundId, round.openPrice, modeName, msg
                ))
                _lastExecution.value = ExecutionResult(
                    now, direction, amount, odds, round.roundId, round.openPrice,
                    modeName, false, null, msg
                )
            }
        }
    }

    /** 预览当前 edge 评估结果（供执行台面板展示，不下单） */
    fun previewStakeSizing(): StakeSizingEngine.StakeSuggestion {
        val s = _state.value
        val balance = _binaryAccount.value.balance
        val marketOdds = _marketOddsList.value.firstOrNull { !it.resolved }
            ?: _marketOddsList.value.firstOrNull()

        val assessment = edgeAssessmentEngine.assess(s.consensus, marketOdds)
        _edgeAssessment.value = assessment

        val odds = assessment.chosenOdds
        val suggestion = stakeSizingEngine.calculate(
            balance = balance,
            odds = odds,
            consensusProbability = assessment.chosenModelProb,
            consensusStrength = s.consensus?.consensusStrength ?: 0.5
        )
        _stakePreview.value = suggestion
        return suggestion
    }

    /** 检查平台连接状态和余额 */
    fun checkPlatformConnectivity() {
        val creds = credentialStore.load()
        viewModelScope.launch {
            try {
                val polyBalance = 0.0  // Polymarket 余额需通过 API 查询，此处简化
                val binanceBalance = if (creds.binanceApiKey.isNotBlank()) {
                    runCatching {
                        predictionMarketConnector.fetchBinanceAccountBalance(
                            creds.binanceApiKey,
                            creds.binanceSecret,
                            testnet = creds.binanceEndpoint.name != "MAINNET"
                        )
                    }.getOrElse { 0.0 }
                } else 0.0

                _platformStatus.value = PlatformStatus(
                    polymarketConnected = creds.polymarketApiKey.isNotBlank(),
                    binanceConnected = creds.binanceApiKey.isNotBlank() && binanceBalance > 0,
                    polymarketBalance = polyBalance,
                    binanceBalance = binanceBalance,
                    lastCheck = System.currentTimeMillis()
                )
                addBetLog("平台检查: Polymarket=%s Binance=%s(%.2f USDT)".format(
                    if (creds.polymarketApiKey.isNotBlank()) "OK" else "NO_KEY",
                    if (creds.binanceApiKey.isNotBlank()) "OK" else "NO_KEY",
                    binanceBalance
                ))
            } catch (e: Exception) {
                _platformStatus.value = PlatformStatus(
                    polymarketConnected = false,
                    binanceConnected = false,
                    polymarketBalance = 0.0,
                    binanceBalance = 0.0,
                    lastCheck = System.currentTimeMillis()
                )
                addBetLog("平台检查失败: ${e.message}")
            }
        }
    }

    /** 刷新运行时状态（供 UI 轮询） */
    fun refreshRuntimeState() {
        _runtimeState.value = runtimeStore.state()
        _runtimeConfig.value = runtimeStore.config()
    }

    fun setRuntimeEnabled(enabled: Boolean, mode: BtcRunMode = BtcRunMode.PAPER) {
        val current = runtimeStore.config()
        if (enabled && mode == BtcRunMode.LIVE) {
            val gate = LiveUnattendedGuard.authorizeStart(
                current.copy(enabled = true, runMode = mode),
                credentialStore.load(),
                runtimeStore.state()
            )
            if (!gate.allowed) {
                _lastTradeTicket.value = TradeTicketResult(false, TradeExecMode.LIVE, "无法启动 LIVE: ${gate.reason}")
                refreshRuntimeState()
                return
            }
        }
        runtimeStore.saveConfig(current.copy(enabled = enabled, runMode = mode))
        _runtimeConfig.value = runtimeStore.config()
        val intent = Intent(app, BtcQuantRuntimeService::class.java)
        if (enabled) {
            val started = AndroidCompat.startDataSyncService(app, intent)
            _lastTradeTicket.value = TradeTicketResult(
                started,
                if (mode == BtcRunMode.LIVE) TradeExecMode.LIVE else TradeExecMode.SIM,
                if (started) "运行时启动请求已提交 mode=${mode.name}" else "运行时启动失败：Android 前台服务未能启动"
            )
        } else {
            intent.action = BtcQuantRuntimeService.ACTION_STOP
            AndroidCompat.startDataSyncService(app, intent)
        }
        refreshRuntimeState()
    }

    fun killRuntime() {
        runtimeStore.setKillSwitch(true)
        executionCoordinator.setKillSwitch(true)
        _executionStatus.value = executionCoordinator.status()
        AndroidCompat.startDataSyncService(
            app, Intent(app, BtcQuantRuntimeService::class.java).setAction(BtcQuantRuntimeService.ACTION_KILL)
        )
        refreshRuntimeState()
        evaluateReadiness()
        addAutoTradeLog(
            AutoTradeLogEntry(
                System.currentTimeMillis(), "FLAT", 0.0, 0.0, 0L, 0.0,
                _runtimeConfig.value.runMode.name, "KILL 全链路停机"
            )
        )
    }

    fun resumeRuntime() {
        runtimeStore.setKillSwitch(false)
        executionCoordinator.setKillSwitch(false)
        _executionStatus.value = executionCoordinator.status()
        runtimeStore.saveConfig(runtimeStore.config().copy(enabled = true))
        _runtimeConfig.value = runtimeStore.config()
        AndroidCompat.startDataSyncService(
            app,
            Intent(app, BtcQuantRuntimeService::class.java)
                .setAction(BtcQuantRuntimeService.ACTION_RESUME)
        )
        refreshRuntimeState()
        evaluateReadiness()
    }

    // === 二元期权预测下注 ===
    private val _binaryAccount = MutableStateFlow(binaryOptionEngine.account())
    val binaryAccount: StateFlow<BinaryOptionAccount> = _binaryAccount.asStateFlow()

    private val _binaryStats = MutableStateFlow(binaryOptionEngine.statsSummary())
    val binaryStats: StateFlow<BinaryOptionStats> = _binaryStats.asStateFlow()

    private val _currentRound = MutableStateFlow<PredictionRound?>(null)
    val currentRound: StateFlow<PredictionRound?> = _currentRound.asStateFlow()

    private val _betLog = MutableStateFlow<List<String>>(emptyList())
    val betLog: StateFlow<List<String>> = _betLog.asStateFlow()

    private val _marketOddsList = MutableStateFlow<List<MarketOdds>>(emptyList())
    val marketOddsList: StateFlow<List<MarketOdds>> = _marketOddsList.asStateFlow()

    // === 动态份额预览（供执行台面板展示） ===
    private val _stakePreview = MutableStateFlow<StakeSizingEngine.StakeSuggestion?>(null)
    val stakePreview: StateFlow<StakeSizingEngine.StakeSuggestion?> = _stakePreview.asStateFlow()

    // === Edge 评估结果（变动赔率核心） ===
    private val _edgeAssessment = MutableStateFlow<EdgeAssessment?>(null)
    val edgeAssessment: StateFlow<EdgeAssessment?> = _edgeAssessment.asStateFlow()

    // === 平台连接状态 ===
    data class PlatformStatus(
        val polymarketConnected: Boolean = false,
        val binanceConnected: Boolean = false,
        val polymarketBalance: Double = 0.0,
        val binanceBalance: Double = 0.0,
        val lastCheck: Long = 0L
    )
    private val _platformStatus = MutableStateFlow(PlatformStatus())
    val platformStatus: StateFlow<PlatformStatus> = _platformStatus.asStateFlow()

    // === 自动下注执行结果（最新一笔） ===
    data class ExecutionResult(
        val timestamp: Long,
        val direction: BetDirection,
        val amount: Double,
        val odds: Double,
        val roundId: Long,
        val openPrice: Double,
        val mode: String,
        val success: Boolean,
        val orderId: String?,
        val message: String
    )
    private val _lastExecution = MutableStateFlow<ExecutionResult?>(null)
    val lastExecution: StateFlow<ExecutionResult?> = _lastExecution.asStateFlow()

    // === 日级盈亏统计 ===
    private val _dailyStats = MutableStateFlow<DailyStats>(DailyStats(
        date = "",
        startBalance = 10_000.0,
        currentBalance = 10_000.0,
        peakBalance = 10_000.0
    ))
    val dailyStats: StateFlow<DailyStats> = _dailyStats.asStateFlow()

    // === 日级控制配置 ===
    private val _dailyControlConfig = MutableStateFlow(DailyControlConfig())
    val dailyControlConfig: StateFlow<DailyControlConfig> = _dailyControlConfig.asStateFlow()

    private fun addBetLog(msg: String) {
        _betLog.value = (listOf("[${System.currentTimeMillis()}] $msg") + _betLog.value).take(50)
    }

    /**
     * 确保 5 分钟周期存在并更新倒计时。
     * 新周期开始时通过 EdgeAssessmentEngine 计算一次方向并锁定，周期内不再改变。
     *
     * 变动赔率核心：不是简单映射 consensus→YES/NO，
     * 而是比较模型概率与市场定价，选 edge 为正的方向。
     */
    fun tickBinaryRound() {
        val s = _state.value
        val now = System.currentTimeMillis()
        val price = s.candles.lastOrNull()?.close ?: s.markPrice ?: 0.0
        if (price <= 0) return

        val current = binaryOptionEngine.currentRound()
        val needsNewRound = current == null || now >= current.endTime

        // 新周期开始时，通过 edge 评估决定方向
        val lockedDir: BetDirection? = if (needsNewRound) {
            // 获取市场赔率（Polymarket 优先，否则用 Binance 本地市场）
            val marketOdds = _marketOddsList.value.firstOrNull { !it.resolved }
                ?: _marketOddsList.value.firstOrNull()

            // Edge 评估：比较模型概率与市场定价
            val assessment = edgeAssessmentEngine.assess(s.consensus, marketOdds)
            _edgeAssessment.value = assessment

            if (assessment.shouldBet) assessment.chosenDirection else null
        } else {
            current!!.lockedDirection
        }

        val round = binaryOptionEngine.ensureRound(now, price, lockedDir)
        _currentRound.value = round
        refreshBinaryOptionState()
    }

    /** 手动下注：在当前周期内下 Yes 或 No */
    fun placeBinaryBet(direction: BetDirection, amount: Double, odds: Double = 1.9) {  // odds 默认仅作回退，实际由 EdgeAssessment 提供
        val now = System.currentTimeMillis()
        val s = _state.value
        val price = s.candles.lastOrNull()?.close ?: s.markPrice ?: 0.0
        if (price <= 0) {
            addBetLog("下注失败: 无可用价格")
            return
        }
        // 确保周期存在（传入共识方向作为锁定方向）
        val lockedDir = s.consensus?.direction?.let {
            when (it) {
                BtcDirection.UP -> BetDirection.YES
                BtcDirection.DOWN -> BetDirection.NO
                else -> null
            }
        }
        val round = binaryOptionEngine.ensureRound(now, price, lockedDir)
        _currentRound.value = round

        val req = BetRequest(
            direction = direction,  // 用户手动选择的方向（覆盖锁定方向）
            amount = amount,
            odds = odds,
            source = BetSource.PAPER,
            timestamp = now
        )
        when (val result = binaryOptionEngine.placeBet(req, now)) {
            is BetResult.Accepted -> {
                addBetLog("BET ${direction.label} \u00b7 %.0f USDT @ %.1fx \u00b7 Round #%d \u00b7 Open=%.2f".format(
                    amount, odds, round.roundId / (binaryOptionEngine.roundDurationSeconds() * 1000L), round.openPrice))
                refreshBinaryOptionState()
            }
            is BetResult.Rejected -> addBetLog("REJECTED: ${result.reason}")
        }
    }

    /** 自动信号下注：通过 EdgeAssessment 决定方向 + 变动赔率 + 固定 1U */
    fun executeBinaryAutoBet() {
        val s = _state.value
        val consensus = s.consensus ?: run {
            addBetLog("无共识方向，跳过")
            return
        }

        // 获取市场赔率
        val marketOdds = _marketOddsList.value.firstOrNull { !it.resolved }
            ?: _marketOddsList.value.firstOrNull()

        // Edge 评估
        val assessment = edgeAssessmentEngine.assess(consensus, marketOdds)
        _edgeAssessment.value = assessment

        if (!assessment.shouldBet || assessment.chosenDirection == null) {
            addBetLog("Edge 不足，跳过: ${assessment.reason}")
            return
        }

        val direction = assessment.chosenDirection!!
        val odds = assessment.chosenOdds
        val betAmount = 1.0  // 固定 1 USDT

        addBetLog("EDGE -> ${direction.label} · 1 USDT @ %.2fx · edge=+%.1f%% · EV=+%.3f".format(
            odds, assessment.chosenEdge * 100, assessment.evPerBet
        ))
        placeBinaryBet(direction, betAmount, odds)
    }

    /** 强制结算当前周期（手动测试用） */
    fun forceSettleCurrentRound() {
        val s = _state.value
        val price = s.candles.lastOrNull()?.close ?: s.markPrice ?: 0.0
        if (price <= 0) return
        val now = System.currentTimeMillis()
        binaryOptionEngine.forceSettle(now, price)
        addBetLog("手动结算: close=%.2f".format(price))
        // 立即开启新周期
        tickBinaryRound()
    }

    /** 重置二元期权账户 */
    fun resetBinaryAccount() {
        binaryOptionEngine.reset()
        _currentRound.value = null
        refreshBinaryOptionState()
        addBetLog("账户已重置: 初始资金 %.0f USDT".format(binaryOptionEngine.account().initialBalance))
    }

    /** 切换模拟/二元交易周期：1m / 5m / 15m / 30m / 1h。切换后立即建立新周期。 */
    fun setBinaryRoundDurationSec(seconds: Long) {
        binaryOptionEngine.setRoundDurationSeconds(seconds)
        _currentRound.value = null
        tickBinaryRound()
        refreshBinaryOptionState()
        addBetLog("模拟周期切换: ${seconds / 60} 分钟")
    }

    fun binaryRoundDurationSec(): Long = binaryOptionEngine.roundDurationSeconds()

    /** 获取当前周期倒计时（秒） */
    fun binaryRemainingSec(): Long {
        val now = System.currentTimeMillis()
        return binaryOptionEngine.remainingSeconds(now)
    }

    /** 获取当前价格相对开窗的涨跌幅 */
    fun binaryCurrentMovePct(): Double {
        val s = _state.value
        val price = s.candles.lastOrNull()?.close ?: s.markPrice ?: 0.0
        return binaryOptionEngine.currentMovePct(price)
    }

    /** 获取当前实时方向（未结算） */
    fun binaryLiveDirection(): BetDirection {
        val s = _state.value
        val price = s.candles.lastOrNull()?.close ?: s.markPrice ?: 0.0
        return binaryOptionEngine.currentLiveDirection(price)
    }

    /** 获取历史周期列表 */
    fun binaryRoundHistory(): List<PredictionRound> = binaryOptionEngine.roundHistory()

    /** 获取已结算下注列表 */
    fun binarySettledBets(): List<SettledBet> = binaryOptionEngine.account().settledBets

    /** 刷新 Polymarket + Binance 市场赔率 */
    fun refreshMarketOdds() {
        viewModelScope.launch {
            runCatching {
                val roundEnd = _currentRound.value?.endTime ?: 0L
                val result = predictionMarketConnector.fetchAllMarkets(
                    _state.value.symbol, roundEnd
                )
                _marketOddsList.value = result.allMarkets
                addBetLog("市场刷新: ${result.polymarketMarkets.size} Polymarket + 1 Binance \u00b7 price=%.2f".format(
                    result.binancePrice))
            }.onFailure { e ->
                addBetLog("市场刷新失败: ${e.message}")
            }
        }
    }

    private fun refreshBinaryOptionState() {
        _binaryAccount.value = binaryOptionEngine.account()
        _binaryStats.value = binaryOptionEngine.statsSummary()
        _dailyStats.value = binaryOptionEngine.dailyStats()
    }

    /** 更新日级控制配置（止损/止盈百分比） */
    fun updateDailyControlConfig(
        stopLossPct: Double? = null,
        takeProfitPct: Double? = null,
        maxDailyBets: Int? = null,
        enabled: Boolean? = null
    ) {
        val current = _dailyControlConfig.value
        _dailyControlConfig.value = current.copy(
            dailyStopLossPct = stopLossPct ?: current.dailyStopLossPct,
            dailyTakeProfitPct = takeProfitPct ?: current.dailyTakeProfitPct,
            maxDailyBets = maxDailyBets ?: current.maxDailyBets,
            enabled = enabled ?: current.enabled
        )
    }

    fun clearBetLog() {
        _betLog.value = emptyList()
    }

    // ==================== 合约量化交易 ====================

    private val _futuresConfig = MutableStateFlow(futuresConfigStore.load())
    val futuresConfig: StateFlow<FuturesQuantConfig> = _futuresConfig.asStateFlow()

    private val _futuresSignal = MutableStateFlow<FuturesSignal?>(null)
    val futuresSignal: StateFlow<FuturesSignal?> = _futuresSignal.asStateFlow()

    private val _futuresPosition = MutableStateFlow(FuturesPosition.empty())
    val futuresPosition: StateFlow<FuturesPosition> = _futuresPosition.asStateFlow()

    private val futuresExchangePositionStore = FuturesExchangePositionStore(app)
    private val _futuresExchangeSnapshot = MutableStateFlow(futuresExchangePositionStore.load())
    val futuresExchangeSnapshot: StateFlow<ExchangePositionSnapshot?> = _futuresExchangeSnapshot.asStateFlow()

    private val _futuresReconciliation = MutableStateFlow(PositionReconciliation())
    val futuresReconciliation: StateFlow<PositionReconciliation> = _futuresReconciliation.asStateFlow()

    private val _futuresOrderReconciliation = MutableStateFlow(FuturesOrderReconciler.Result(
        FuturesOrderReconciler.State.UNKNOWN, emptyList(), emptyList(), emptyList(), emptyList(), emptyList(), "等待保护单对账"
    ))
    val futuresOrderReconciliation: StateFlow<FuturesOrderReconciler.Result> = _futuresOrderReconciliation.asStateFlow()
    private val _futuresExecutionSnapshot = MutableStateFlow(FuturesExecutionSnapshot())
    val futuresExecutionSnapshot: StateFlow<FuturesExecutionSnapshot> = _futuresExecutionSnapshot.asStateFlow()

    private val _futuresDailyStats = MutableStateFlow(FuturesDailyStats(
        date = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())
    ))
    val futuresDailyStats: StateFlow<FuturesDailyStats> = _futuresDailyStats.asStateFlow()

    private val _futuresLog = MutableStateFlow<List<FuturesLogEntry>>(emptyList())
    val futuresLog: StateFlow<List<FuturesLogEntry>> = _futuresLog.asStateFlow()

    private val _futuresAutoMode = MutableStateFlow(futuresConfigStore.load().autoMode)
    val futuresAutoMode: StateFlow<Boolean> = _futuresAutoMode.asStateFlow()

    private fun addFuturesLog(action: String, detail: String, level: LogLevel = LogLevel.INFO, pnl: Double? = null) {
        val entry = FuturesLogEntry(System.currentTimeMillis(), action, detail, pnl, level)
        _futuresLog.value = (listOf(entry) + _futuresLog.value).take(100)
    }

    /**
     * Exchange-authoritative position reconciliation. The exchange snapshot is the source of truth
     * for live/testnet positions; local PositionManager remains a UI/risk cache only.
     */
    fun syncFuturesExchangePosition() {
        viewModelScope.launch {
            val cfg = _futuresConfig.value
            _futuresReconciliation.value = FuturesPositionReconciler.syncing(_futuresReconciliation.value)
            runCatching {
                val creds = credentialStore.load()
                // Runtime mode is authoritative: LIVE/TESTNET never silently fall back to PAPER.
                // This prevents an empty/misconfigured credential set from showing fake positions.
                val isPaper = _runtimeConfig.value.runMode == BtcRunMode.PAPER
                val broker = when (_runtimeConfig.value.runMode) {
                    BtcRunMode.PAPER -> PaperPerpBroker()
                    BtcRunMode.TESTNET, BtcRunMode.LIVE -> BrokerFactory.perp(creds, forcePaper = false)
                }
                val risk = broker.fetchPositionRisk(cfg.symbol)
                val openOrders = broker.fetchOpenOrders(cfg.symbol)
                val orderResult = FuturesOrderReconciler.reconcile(risk, openOrders)
                _futuresOrderReconciliation.value = orderResult
                _futuresExecutionSnapshot.value = FuturesExecutionStateMachine.from(risk, openOrders, _futuresReconciliation.value)
                val source = if (isPaper) "PAPER" else creds.binanceEndpoint.label.uppercase()
                futuresExchangePositionStore.save(risk, source)
                val snapshot = futuresExchangePositionStore.load()
                _futuresExchangeSnapshot.value = snapshot
                val compared = FuturesPositionReconciler.compare(_futuresPosition.value, risk)
                _futuresReconciliation.value = compared
                _futuresExecutionSnapshot.value = FuturesExecutionStateMachine.from(risk, openOrders, compared)
                if (!isPaper) {
                    applyExchangePositionToUi(risk, cfg)
                    addFuturesLog("RECONCILE", if (risk?.isOpen == true)
                        "交易所同步 ${risk.sideLabel} qty=${"%.6f".format(kotlin.math.abs(risk.positionAmt))} entry=${"%.2f".format(risk.entryPrice)} PnL=${"%+.2f".format(risk.unRealizedProfit)} · 保护单=${orderResult.state}"
                        else "交易所同步：当前无 BTCUSDT 持仓 · ${orderResult.message}",
                        if (orderResult.state == FuturesOrderReconciler.State.PROTECTED || risk?.isOpen != true) LogLevel.SUCCESS else LogLevel.WARN)
                }
            }.onFailure {
                val msg = it.message ?: "unknown"
                _futuresReconciliation.value = FuturesPositionReconciler.error(_futuresReconciliation.value, msg)
                _futuresOrderReconciliation.value = FuturesOrderReconciler.Result(FuturesOrderReconciler.State.ERROR, emptyList(), emptyList(), emptyList(), emptyList(), emptyList(), msg)
                addFuturesLog("RECONCILE", "交易所仓位/订单同步失败：$msg", LogLevel.ERROR)
            }
        }
    }

    private fun applyExchangePositionToUi(risk: PositionRiskInfo?, cfg: FuturesQuantConfig) {
        if (risk == null || !risk.isOpen) {
            positionManager.clear()
            _futuresPosition.value = FuturesPosition.empty(cfg.symbol)
            return
        }
        val side = if (risk.positionAmt > 0.0) PositionSide.LONG else PositionSide.SHORT
        val qty = kotlin.math.abs(risk.positionAmt)
        val lev = risk.leverage.toIntOrNull()?.coerceAtLeast(1) ?: cfg.leverage
        val margin = if (risk.isolatedWallet > 0.0) risk.isolatedWallet
            else (risk.notional.takeIf { it > 0.0 } ?: qty * risk.markPrice) / lev.coerceAtLeast(1)
        positionManager.register(
            entryPrice = risk.entryPrice, quantity = qty, leverage = lev, margin = margin,
            liquidationPrice = risk.liquidationPrice, stopLoss = positionManager.current().stopLossPrice,
            takeProfit = positionManager.current().takeProfitPrice, trailingStopPct = cfg.trailingStopPct,
            side = side, symbol = risk.symbol, openTime = if (risk.updateTime > 0) risk.updateTime else System.currentTimeMillis()
        )
        positionManager.updateMarkPrice(risk.markPrice, _state.value.fundingRate ?: 0.0)
        _futuresPosition.value = positionManager.current().copy(unrealizedPnl = risk.unRealizedProfit)
    }

    /** Update futures quant configuration */
    fun updateFuturesConfig(
        leverage: Int? = null,
        positionSizePct: Double? = null,
        stopLossAtrMult: Double? = null,
        takeProfitAtrMult: Double? = null,
        trailingStopPct: Double? = null,
        marginMode: MarginMode? = null,
        minConfidence: Double? = null,
        maxDailyLossUsdt: Double? = null,
        maxPositions: Int? = null,
        enableFundingArb: Boolean? = null,
        enableMultiTakeProfit: Boolean? = null,
        trailingStopEnabled: Boolean? = null,
        maxDailyLossPct: Double? = null,
        maxDrawdownPct: Double? = null,
        maxLeverage: Int? = null,
        symbol: String? = null
    ) {
        val cur = _futuresConfig.value
        val updated = cur.copy(
            symbol = symbol ?: cur.symbol,
            leverage = leverage ?: cur.leverage,
            positionSizePct = positionSizePct ?: cur.positionSizePct,
            stopLossAtrMult = stopLossAtrMult ?: cur.stopLossAtrMult,
            takeProfitAtrMult = takeProfitAtrMult ?: cur.takeProfitAtrMult,
            trailingStopPct = when (trailingStopEnabled) {
                false -> null
                true -> trailingStopPct ?: cur.trailingStopPct ?: 3.0
                null -> trailingStopPct ?: cur.trailingStopPct
            },
            marginMode = marginMode ?: cur.marginMode,
            minConfidence = minConfidence ?: cur.minConfidence,
            maxDailyLossUsdt = maxDailyLossUsdt ?: cur.maxDailyLossUsdt,
            maxDailyLossPct = maxDailyLossPct ?: cur.maxDailyLossPct,
            maxDrawdownPct = maxDrawdownPct ?: cur.maxDrawdownPct,
            maxPositions = maxPositions ?: cur.maxPositions,
            maxLeverage = maxLeverage ?: cur.maxLeverage,
            enableFundingArb = enableFundingArb ?: cur.enableFundingArb,
            enableMultiTakeProfit = enableMultiTakeProfit ?: cur.enableMultiTakeProfit,
            autoMode = _futuresAutoMode.value
        )
        _futuresConfig.value = updated
        futuresConfigStore.save(updated)
        positionManager = PositionManager(updated)
        // Keep the isolated futures runtime in sync. The binary-prediction runtime uses a different store.
        val runtime = futuresRuntimeStore.config()
        futuresRuntimeStore.saveConfig(runtime.copy(
            symbol = updated.symbol,
            maxLeverage = updated.maxLeverage,
            maxNotionalUsdt = maxOf(1.0, runtime.maxNotionalUsdt),
            maxDailyLossUsdt = updated.maxDailyLossUsdt,
            minProbability = updated.minConfidence
        ))
        addFuturesLog("CONFIG", "配置已持久化 v=${System.currentTimeMillis()} lev=${updated.leverage}x size=${updated.positionSizePct}% SL=${updated.stopLossAtrMult}ATR TP=${updated.takeProfitAtrMult}ATR trail=${updated.trailingStopPct ?: "OFF"}", LogLevel.SUCCESS)
    }

    /** Toggle auto trading mode */
    fun setFuturesAutoMode(enabled: Boolean) {
        _futuresAutoMode.value = enabled
        val updated = _futuresConfig.value.copy(autoMode = enabled)
        _futuresConfig.value = updated
        futuresConfigStore.save(updated)
        if (enabled) {
            val current = futuresRuntimeStore.config()
            futuresRuntimeStore.saveConfig(current.copy(
                symbol = updated.symbol,
                enabled = true,
                maxLeverage = updated.maxLeverage,
                maxDailyLossUsdt = updated.maxDailyLossUsdt,
                minProbability = updated.minConfidence
            ))
            val started = AndroidCompat.startDataSyncService(
                app, Intent(app, com.caifenxi.app.service.btc.FuturesQuantRuntimeService::class.java)
            )
            if (!started) {
                _futuresAutoMode.value = false
                val failed = _futuresConfig.value.copy(autoMode = false)
                _futuresConfig.value = failed
                futuresConfigStore.save(failed)
                futuresRuntimeStore.saveConfig(futuresRuntimeStore.config().copy(enabled = false))
            }
        } else {
            futuresRuntimeStore.saveConfig(futuresRuntimeStore.config().copy(enabled = false))
            AndroidCompat.startDataSyncService(app, Intent(app, com.caifenxi.app.service.btc.FuturesQuantRuntimeService::class.java).setAction(com.caifenxi.app.service.btc.FuturesQuantRuntimeService.ACTION_STOP))
        }
        addFuturesLog("AUTO", if (enabled) "量化合约后台挂机已开启" else "量化合约后台挂机已关闭",
            if (enabled) LogLevel.SUCCESS else LogLevel.WARN)
    }

    /**
     * Main tick for futures quant: called on each refresh cycle.
     * Full automatic chain when autoMode is ON:
     * 1. Generate signal from consensus + candles
     * 2. If no position and signal is valid → execute full open chain
     * 3. If position exists → update mark price, check trailing stop / emergency close / signal reversal
     * 4. Auto-close if any trigger fires
     *
     * When autoMode is OFF: only updates signal preview and position monitoring.
     */
    fun tickFuturesQuant() {
        val s = _state.value
        val now = System.currentTimeMillis()
        val config = _futuresConfig.value

        // Throttle: don't auto-execute more than once per 10 seconds
        if (now - lastFuturesAutoTickTime < 10_000L && _futuresAutoMode.value) return

        val consensus = s.consensus
        val candles = s.candles
        if (candles.isEmpty() || consensus == null) return
        // Live/testnet position state is exchange-authoritative. UI refresh only monitors;
        // background FuturesQuantRuntimeService owns automated execution.
        if (_futuresAutoMode.value && now - lastFuturesAutoTickTime >= 10_000L) {
            syncFuturesExchangePosition()
        }

        // Get account balance (use cached value; actual broker call in execute)
        val balance = _binaryAccount.value.balance.coerceAtLeast(1_000.0)

        // Generate / update signal preview
        val signal = futuresEngine.evaluateSignal(
            consensus = consensus,
            candles = candles,
            config = config,
            balance = balance
        )
        _futuresSignal.value = signal

        // === Position management branch ===
        if (positionManager.isActive()) {
            // Update mark price for existing position
            val markPrice = candles.lastOrNull()?.close ?: 0.0
            val fundingRate = s.fundingRate ?: 0.0
            positionManager.updateMarkPrice(markPrice, fundingRate)
            val snapshot = positionManager.snapshot()
            _futuresPosition.value = snapshot.position

            // Check emergency close (margin ratio / liquidation distance / trailing stop)
            snapshot.emergencyReason?.let { reason ->
                addFuturesLog("EMERGENCY_CLOSE", reason, LogLevel.ERROR, snapshot.position.unrealizedPnl)
                if (_futuresAutoMode.value) {
                    addFuturesLog("AUTO_OWNER", "后台合约服务负责紧急平仓：$reason", LogLevel.WARN)
                }
                return
            }

            // Check signal reversal close
            val closeReason = futuresEngine.shouldClosePosition(
                currentPosition = snapshot.position,
                newConsensus = consensus,
                dailyPnlUsdt = _futuresDailyStats.value.netPnl,
                config = config
            )
            closeReason?.let { reason ->
                addFuturesLog("SIGNAL_CLOSE", reason, LogLevel.WARN, snapshot.position.unrealizedPnl)
                if (_futuresAutoMode.value) {
                    addFuturesLog("AUTO_OWNER", "后台合约服务负责信号平仓：$reason", LogLevel.WARN)
                }
                return
            }

            // Position healthy — just update log
            if (snapshot.isProfitable) {
                addFuturesLog("POSITION", "PnL=+%.2fU ROI=+%.1f%% liqDist=%.1f%%".format(
                    snapshot.position.unrealizedPnl,
                    snapshot.pnlRoi,
                    snapshot.liquidationDistancePct
                ), LogLevel.INFO)
            }
            return
        }

        // === No position: check if we should open one ===
        if (!_futuresAutoMode.value) return
        if (signal == null) {
            if (consensus.direction != BtcDirection.FLAT) {
                addFuturesLog("SKIP", "Signal=null consensus=${consensus.direction} conf=${"%.0f%%".format(consensus.probability * 100)}")
            }
            return
        }

        // Throttle check passed
        lastFuturesAutoTickTime = now

        // Background service is the sole automatic executor. The ViewModel only
        // previews/monitors while auto mode is enabled, preventing UI refreshes
        // from racing the foreground service and submitting duplicate orders.
        return
    }

    /** One-shot manual opening. It never enables background auto trading. */
    fun manualFuturesOpen() {
        if (_futuresAutoMode.value) {
            addFuturesLog("MANUAL", "后台自动模式运行中，手动开仓被忽略", LogLevel.WARN)
            return
        }
        val s = _state.value
        val signal = futuresEngine.evaluateSignal(
            consensus = s.consensus,
            candles = s.candles,
            config = _futuresConfig.value,
            balance = _binaryAccount.value.balance.coerceAtLeast(1_000.0),
            deriv = null
        ) ?: run {
            addFuturesLog("MANUAL", "当前没有满足条件的合约信号", LogLevel.WARN)
            return
        }
        executeFuturesOrderInternal(signal, _binaryAccount.value.balance.coerceAtLeast(1_000.0))
    }

    /**
     * Execute the full automated opening chain:
     * setLeverage → setMarginMode → MARKET entry → STOP_MARKET(SL) → TAKE_PROFIT_MARKET(TP) → register position
     */
    private fun executeFuturesOrderInternal(signal: FuturesSignal, balance: Double) {
        val config = _futuresConfig.value
        val symbol = config.symbol
        val now = System.currentTimeMillis()

        addFuturesLog("AUTO_OPEN", signal.reason, LogLevel.INFO)

        viewModelScope.launch(Dispatchers.IO) {
            var step = "setLeverage"
            try {
                // 1. Set leverage
                val levResult = executionGateway.setPerpLeverage(symbol, signal.leverage)
                if (!levResult.success) {
                    addFuturesLog("OPEN_FAIL", "setLeverage: ${levResult.message}", LogLevel.ERROR)
                    return@launch
                }
                addFuturesLog("LEVERAGE", "set to ${signal.leverage}x", LogLevel.SUCCESS)

                // 2. Set margin mode
                step = "setMarginMode"
                executionGateway.setPerpMarginMode(symbol, config.marginMode)

                // 3. Build ContractSignal for MARKET entry
                step = "marketEntry"
                val contractSignal = TradingSignal.ContractSignal(
                    planId = "FUTURES-QUANT",
                    barId = now,
                    symbol = symbol,
                    direction = signal.direction,
                    probability = signal.confidence,
                    expectedMovePct = (signal.takeProfit - signal.entry) / signal.entry * 100.0,
                    entry = signal.entry,
                    stopLoss = signal.stopLoss,
                    takeProfit = signal.takeProfit,
                    horizonBars = 12,
                    positionSize = signal.quantity,
                    leverageCap = signal.leverage,
                    confidence = signal.confidence,
                    reasonPlanIds = listOf("FUTURES-QUANT")
                )

                val entryResult = executionGateway.placePerp(contractSignal, "fq-entry-$now".take(36))
                if (!entryResult.success) {
                    addFuturesLog("OPEN_FAIL", "entry: ${entryResult.message}", LogLevel.ERROR)
                    return@launch
                }
                addFuturesLog("ENTRY", "MARKET ${signal.direction} qty=${"%.4f".format(signal.quantity)} @ ${"%.0f".format(signal.entry)} lev=${signal.leverage}x", LogLevel.SUCCESS)

                // 4. Place STOP_MARKET for stop loss
                step = "stopLoss"
                val slSide = if (signal.direction == BtcDirection.UP) "SELL" else "BUY"
                val slResult = executionGateway.placePerpConditional(
                    symbol = symbol,
                    side = slSide,
                    type = FuturesOrderType.STOP_MARKET,
                    quantity = signal.quantity,
                    stopPrice = signal.stopLoss,
                    clientOrderId = "fq-sl-$now".take(36)
                )
                if (slResult.success) {
                    addFuturesLog("STOP_LOSS", "STOP_MARKET @ ${"%.0f".format(signal.stopLoss)}", LogLevel.SUCCESS)
                } else {
                    addFuturesLog("SL_WARN", "stop loss order: ${slResult.message}", LogLevel.WARN)
                }

                // 5. Place TAKE_PROFIT_MARKET for take profit
                step = "takeProfit"
                val tpSide = if (signal.direction == BtcDirection.UP) "SELL" else "BUY"
                val tpResult = executionGateway.placePerpConditional(
                    symbol = symbol,
                    side = tpSide,
                    type = FuturesOrderType.TAKE_PROFIT_MARKET,
                    quantity = signal.quantity,
                    stopPrice = signal.takeProfit,
                    clientOrderId = "fq-tp-$now".take(36)
                )
                if (tpResult.success) {
                    addFuturesLog("TAKE_PROFIT", "TP_MARKET @ ${"%.0f".format(signal.takeProfit)}", LogLevel.SUCCESS)
                } else {
                    addFuturesLog("TP_WARN", "take profit order: ${tpResult.message}", LogLevel.WARN)
                }

                // 6. Trailing stop if configured
                if (config.trailingStopPct != null) {
                    step = "trailingStop"
                    val trailResult = executionGateway.placePerpConditional(
                        symbol = symbol,
                        side = tpSide,
                        type = FuturesOrderType.TRAILING_STOP_MARKET,
                        quantity = signal.quantity,
                        trailingDelta = config.trailingStopPct * 100, // bps
                            clientOrderId = "fq-trail-$now".take(36)
                    )
                    if (trailResult.success) {
                        addFuturesLog("TRAILING", "TRAILING_STOP delta=${config.trailingStopPct}%", LogLevel.SUCCESS)
                    }
                }

                // 7. Register position in PositionManager
                step = "register"
                val posSide = if (signal.direction == BtcDirection.UP) PositionSide.LONG else PositionSide.SHORT
                // Simplified liquidation price: entry - (margin/qty) for long, entry + (margin/qty) for short
                val liqDist = if (signal.quantity > 0.0) signal.margin / signal.quantity else 0.0
                val liqPrice = if (posSide == PositionSide.LONG) {
                    (signal.entry - liqDist).coerceAtLeast(0.0)
                } else {
                    signal.entry + liqDist
                }

                positionManager.register(
                    entryPrice = signal.entry,
                    quantity = signal.quantity,
                    leverage = signal.leverage,
                    margin = signal.margin,
                    liquidationPrice = liqPrice,
                    stopLoss = signal.stopLoss,
                    takeProfit = signal.takeProfit,
                    trailingStopPct = config.trailingStopPct,
                    side = posSide,
                    symbol = symbol,
                    openTime = now
                )
                _futuresPosition.value = positionManager.current()

                addFuturesLog("POSITION_OPENED", "FULL CHAIN COMPLETE: ${signal.direction} ${"%.4f".format(signal.quantity)} BTC @ ${signal.leverage}x", LogLevel.SUCCESS)

            } catch (e: Exception) {
                addFuturesLog("OPEN_ERROR", "step=$step: ${e.message ?: "unknown"}", LogLevel.ERROR)
            }
        }
    }

    /**
     * Close the current futures position (auto or manual).
     * Cancels conditional orders via reduceOnly, then closes with MARKET reduceOnly.
     */
    fun closeFuturesPosition(reason: String = "manual") {
        closeFuturesPositionInternal(reason)
    }

    private fun closeFuturesPositionInternal(reason: String) {
        if (!positionManager.isActive()) {
            addFuturesLog("CLOSE_SKIP", "no open position", LogLevel.WARN)
            return
        }
        val pos = positionManager.current()
        val pnl = pos.unrealizedPnl
        val now = System.currentTimeMillis()

        viewModelScope.launch(Dispatchers.IO) {
            try {
                val result = executionGateway.closePerpPosition(
                    ClosePositionRequest(
                        symbol = pos.symbol,
                            reason = reason
                    )
                )
                if (result.success) {
                    addFuturesLog("CLOSED", "$reason | pnl=${"%+.2f".format(pnl)}U qty=${"%.4f".format(pos.quantity)}", LogLevel.SUCCESS, pnl)

                    // Update daily stats
                    val cur = _futuresDailyStats.value
                    val newStats = cur.copy(
                        totalTrades = cur.totalTrades + 1,
                        wins = if (pnl > 0) cur.wins + 1 else cur.wins,
                        losses = if (pnl < 0) cur.losses + 1 else cur.losses,
                        grossProfit = if (pnl > 0) cur.grossProfit + pnl else cur.grossProfit,
                        grossLoss = if (pnl < 0) cur.grossLoss + abs(pnl) else cur.grossLoss,
                        netPnl = cur.netPnl + pnl,
                        currentConsecutiveLosses = if (pnl < 0) cur.currentConsecutiveLosses + 1 else 0,
                        maxConsecutiveLosses = maxOf(cur.maxConsecutiveLosses, if (pnl < 0) cur.currentConsecutiveLosses + 1 else 0),
                        stopLossHits = if (reason.contains("stop") || reason.contains("emergency")) cur.stopLossHits + 1 else cur.stopLossHits,
                        takeProfitHits = if (reason.contains("signal") && pnl > 0) cur.takeProfitHits + 1 else cur.takeProfitHits
                    )
                    _futuresDailyStats.value = newStats
                } else {
                    addFuturesLog("CLOSE_FAIL", "${result.message}", LogLevel.ERROR)
                }

                positionManager.clear()
                _futuresPosition.value = FuturesPosition.empty(pos.symbol)

            } catch (e: Exception) {
                addFuturesLog("CLOSE_ERROR", e.message ?: "unknown", LogLevel.ERROR)
            }
        }
    }

    /** Initialize broker with real credentials (called from settings) */
    fun initFuturesBroker() {
        val creds = credentialStore.load()
        if (creds.binanceApiKey.isBlank() || creds.binanceSecret.isBlank()) {
            addFuturesLog("BROKER", "credentials missing: no implicit PAPER fallback", LogLevel.WARN)
            return
        }
        perpBroker = BrokerFactory.perp(creds, forcePaper = false)
        executionGateway = UnifiedExecutionGateway(perp = perpBroker)
        addFuturesLog("BROKER", "initialized: ${creds.binanceEndpoint.label.uppercase()}", LogLevel.INFO)
    }

    fun clearFuturesLog() {
        _futuresLog.value = emptyList()
    }

    fun resetFuturesDailyStats() {
        val today = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())
        _futuresDailyStats.value = FuturesDailyStats(date = today)
        addFuturesLog("RESET", "daily stats reset", LogLevel.INFO)
    }

    fun saveBrokerCredentials(creds: BrokerCredentials) {
        credentialStore.save(creds)
        _creds.value = creds
    }

    fun loadBrokerCredentials(): BrokerCredentials = credentialStore.load()

    fun runMultiEngineTickWithKeys(paperPerp: Boolean = true) {
        viewModelScope.launch {
            runCatching {
                val creds = credentialStore.load()
                val submissionJournal = com.caifenxi.app.domain.btc.runtime.PolymarketSubmissionJournal(getApplication())
                val orch = MultiEngineOrchestrator.fromCredentials(creds, paperPerp = paperPerp, polyHistoryStore = polymarketHistoryStore, polySubmissionJournal = submissionJournal)
                val report = orch.tick(_state.value.symbol, _state.value.timeframe)
                _orch.value = buildString {
                    append("perp=${report.perpResult?.message ?: "-"}")
                    append(" | event=${report.eventResult?.message ?: "-"}")
                    append(" | poly=${report.polyResults.joinToString { it.message }}")
                    if (report.notes.isNotEmpty()) append(" | ").append(report.notes.joinToString(";"))
                }
            }.onFailure { _orch.value = it.message }
        }
    }

    fun testBinanceConnectivity() {
        viewModelScope.launch {
            runCatching {
                val c = credentialStore.load()
                if (c.binanceApiKey.isBlank()) {
                    _orch.value = "未配置币安Key：仅公共行情可用"
                    return@launch
                }
                val b = BinanceFuturesBroker(c.binanceApiKey, c.binanceSecret, c.binanceEndpoint)
                val ping = b.ping()
                val acct = runCatching { b.accountSnapshot() }.getOrNull()
                _orch.value = "ping=$ping endpoint=${c.binanceEndpoint.label} bal=${acct?.availableBalance}"
            }.onFailure { _orch.value = "连通性失败: ${it.message}" }
        }
    }

    fun runMultiEngineTick() {
        viewModelScope.launch {
            runCatching {
                val report = orchestrator.tick(_state.value.symbol, _state.value.timeframe)
                _orch.value = buildString {
                    append("perp=${report.perpResult?.message ?: "-"}")
                    append(" | event=${report.eventResult?.message ?: "-"}")
                    append(" | poly=${report.polyResults.size}")
                    if (report.notes.isNotEmpty()) append(" | ").append(report.notes.joinToString(";"))
                }
            }.onFailure { _orch.value = it.message }
        }
    }

    init {
        // 启动时加载已有 Polymarket OOS 生命周期权重；后台自动量化与页面共享同一策略池状态。
        viewModelScope.launch(Dispatchers.IO) {
            runCatching { refreshFactorWeights(); refreshPolymarketStrategyLifecycle() }
        }
        // 高频实时层：WebSocket 只更新行情/K线/盘口，不绕过 HS、风控或执行链路。
        liveMarketStream.start("BTCUSDT", object : BinanceLiveMarketStream.Listener {
            override fun onTick(tick: BinanceLiveMarketStream.LiveTick) {
                // aggTrade 高频事件只以 250ms 节流写入 Compose State，避免 UI 重组风暴；
                // 数据本身仍来自真实 WebSocket，不用定时器伪造走势。
                val now = System.currentTimeMillis()
                if (now - lastRealtimeUiEmitAt < 250L) return
                lastRealtimeUiEmitAt = now
                val cur = _state.value
                val book = cur.liveDepth
                val point = RealtimeMarketPoint(
                    eventTime = tick.eventTime,
                    price = tick.price,
                    spread = book?.spread ?: 0.0,
                    imbalance = book?.imbalance ?: 0.0
                )
                _state.value = cur.copy(
                    livePrice = tick.price,
                    livePriceAt = tick.eventTime,
                    liveStreamStatus = "LIVE",
                    realtimeMarketTimeline = (cur.realtimeMarketTimeline + point).takeLast(240)
                )
            }
            override fun onKline(kline: BinanceLiveMarketStream.LiveKline) {
                fun merge(src: List<com.caifenxi.app.domain.btc.BtcCandle>): List<com.caifenxi.app.domain.btc.BtcCandle> {
                    if (src.isEmpty()) return listOf(kline.candle)
                    val last = src.last()
                    return when {
                        kline.candle.openTime == last.openTime -> src.dropLast(1) + kline.candle
                        kline.candle.openTime > last.openTime -> (src + kline.candle).takeLast(300)
                        else -> src
                    }
                }
                val cur = _state.value
                val next = when (kline.interval) {
                    "5m" -> merge(cur.candles5m)
                    "15m" -> merge(cur.candles15m)
                    "1h" -> merge(cur.candles1h)
                    else -> null
                }
                if (next != null) {
                    val primary = when (cur.timeframe) { "5m" -> if (kline.interval == "5m") next else cur.candles5m; "1h" -> if (kline.interval == "1h") next else cur.candles1h; else -> if (kline.interval == "15m") next else cur.candles15m }
                    _state.value = when (kline.interval) {
                        "5m" -> cur.copy(candles5m = next, candles = primary, liveStreamStatus = "LIVE")
                        "15m" -> cur.copy(candles15m = next, candles = primary, liveStreamStatus = "LIVE")
                        "1h" -> cur.copy(candles1h = next, candles = primary, liveStreamStatus = "LIVE")
                        else -> cur
                    }
                }
            }
            override fun onDepth(depth: BinanceLiveMarketStream.LiveDepth) {
                val snap = BinanceOrderBookRepository.Snapshot(
                    symbol = depth.symbol,
                    bids = depth.bids.sortedByDescending { it.price }.take(20),
                    asks = depth.asks.sortedBy { it.price }.take(20),
                    lastUpdateId = depth.updateId,
                    fetchedAt = depth.eventTime
                )
                val cur = _state.value
                // 盘口事件频率最高，只有在价格没有刚刚写入时才补一条时间轴采样。
                val now = System.currentTimeMillis()
                val price = cur.livePrice ?: snap.mid ?: 0.0
                val point = if (price > 0.0 && (cur.realtimeMarketTimeline.lastOrNull()?.eventTime ?: 0L) + 250L <= depth.eventTime) {
                    RealtimeMarketPoint(depth.eventTime, price, snap.spread, snap.imbalance)
                } else null
                _state.value = cur.copy(
                    liveDepth = snap,
                    liveStreamStatus = "LIVE",
                    liveStreamDetail = "${depth.bids.size}/${depth.asks.size} levels",
                    realtimeMarketTimeline = if (point != null) (cur.realtimeMarketTimeline + point).takeLast(240) else cur.realtimeMarketTimeline
                )
            }
            override fun onStatus(status: String, detail: String?) {
                _state.value = _state.value.copy(liveStreamStatus = status, liveStreamDetail = detail)
            }
        })
        // 启动：解除误开的熔断 → 先尝试真实行情 → 失败再 Demo → 持续轮询
        viewModelScope.launch(Dispatchers.Default) {
            runCatching {
                runtimeStore.setKillSwitch(false)
                executionCoordinator.setKillSwitch(false)
                // 坏数据修复：余额被写成 0 时恢复默认模拟金
                val acc = binaryOptionEngine.account()
                if (acc.balance <= 0.0) {
                    binaryOptionEngine.reset()
                    binaryOptionStore.save(binaryOptionEngine.account())
                }
            }
            // 先保证有快照（后台线程跑引擎），再尝试真实行情
            runCatching {
                applyMarketBundle(
                    symbol = "BTCUSDT",
                    timeframe = _state.value.timeframe.ifBlank { "15m" },
                    candles = BtcDemoDataProvider.generateCandles("BTCUSDT", "15m", 300),
                    candles5m = BtcDemoDataProvider.generateCandles("BTCUSDT", "5m", 300),
                    candles15m = BtcDemoDataProvider.generateCandles("BTCUSDT", "15m", 300),
                    candles1h = BtcDemoDataProvider.generateCandles("BTCUSDT", "1h", 300),
                    marketYes5m = 0.55,
                    marketYes15m = 0.52,
                    marketYes1h = 0.51,
                    funding = BtcDemoDataProvider.generateFundingHistory("BTCUSDT", 100),
                    oi = BtcDemoDataProvider.generateOiHistory("BTCUSDT", 100),
                    snap = BtcDemoDataProvider.generateDerivativesSnapshot("BTCUSDT"),
                    news = BtcDemoDataProvider.generateNewsSnapshot(),
                    useDemo = true,
                    errorMsg = "启动演示数据 · 正在尝试真实行情"
                )
            }.onFailure { e ->
                android.util.Log.e("BtcQuant", "startup demo failed", e)
                _state.value = _state.value.copy(loading = false, error = "启动失败: ${e.message}")
            }
            evaluateReadiness()
            // 真实行情轮询
            while (true) {
                runCatching { refresh() }
                evaluateReadiness()
                kotlinx.coroutines.delay(8_000L)
            }
        }
    }

    /** 强制使用 Demo 数据（无网/调试） */
    fun loadDemo(symbol: String = "BTCUSDT", timeframe: String = _state.value.timeframe) {
        _state.value = _state.value.copy(symbol = symbol, timeframe = timeframe, loading = true, error = null)
        viewModelScope.launch(Dispatchers.Default) {
            runCatching {
                applyMarketBundle(
                    symbol = symbol,
                    timeframe = timeframe,
                    candles = BtcDemoDataProvider.generateCandles(symbol, timeframe, 300),
                    candles5m = BtcDemoDataProvider.generateCandles(symbol, "5m", 300),
                    candles15m = BtcDemoDataProvider.generateCandles(symbol, "15m", 300),
                    candles1h = BtcDemoDataProvider.generateCandles(symbol, "1h", 300),
                    marketYes5m = 0.63,
                    marketYes15m = 0.345,
                    marketYes1h = 0.457,
                    funding = BtcDemoDataProvider.generateFundingHistory(symbol, 100),
                    oi = BtcDemoDataProvider.generateOiHistory(symbol, 100),
                    snap = BtcDemoDataProvider.generateDerivativesSnapshot(symbol),
                    news = BtcDemoDataProvider.generateNewsSnapshot(),
                    useDemo = true,
                    errorMsg = "演示数据已加载（可离线查看看板）"
                )
            }.onFailure { e ->
                _state.value = _state.value.copy(
                    loading = false,
                    error = "演示数据引擎失败: ${e.message ?: e.javaClass.simpleName}"
                )
            }
        }
    }

    fun refresh(symbol: String = "BTCUSDT", timeframe: String = _state.value.timeframe) {
        viewModelScope.launch(Dispatchers.Default) {
            if (!refreshMutex.tryLock()) return@launch
            try {
            // 刷新前先记住是否已有“真实”快照（Demo 不算）。用于防止 Demo 覆盖真实数据，
            // 同时在纯离线情况下允许 Demo 持续刷新，避免看板“卡死不动”。
            val hadLiveSnapshot = _state.value.hsSnapshot != null && !_state.value.isDemoMode
            // 仅当尚无任何快照时才显示“正在加载”，否则保留上一份数据，避免看板被“正在加载行情”长期覆盖。
            _state.value = _state.value.copy(
                symbol = symbol,
                timeframe = timeframe,
                loading = _state.value.hsSnapshot == null,
                error = null
            )
            runCatching {
                val credsNow = credentialStore.load()
                // 统一走 MarketDataCoordinator 并行拉取；加超时，防止网络挂起导致“一直加载”。
                val bundle = kotlinx.coroutines.withTimeoutOrNull(25_000L) {
                    marketDataCoordinator.loadParallel(
                        symbol = symbol,
                        timeframe = timeframe,
                        chainlinkRpc = credsNow.chainlinkRpcUrl,
                        chainlinkFeed = credsNow.chainlinkFeedAddress
                    )
                } ?: throw IllegalStateException("行情请求超时（25s），已切换离线/Demo")
                val c5 = bundle.candles5m
                val c15 = bundle.candles15m
                val c1h = bundle.candles1h
                val funding = bundle.funding
                val oi = bundle.oi
                val snap = bundle.snap
                val news = bundle.news
                val depth = bundle.depth
                val oracle = bundle.oracle
                val polyMarkets = bundle.polyMarkets
                val primaryCandles = bundle.primary

                fun matchPoly(tf: String): com.caifenxi.app.domain.btc.polymarket.PolyMarket? {
                    val now = System.currentTimeMillis()
                    val targetMinutes = when (tf) { "5m" -> 5L; "15m" -> 15L; else -> 60L }
                    fun isBtc(m: com.caifenxi.app.domain.btc.polymarket.PolyMarket): Boolean {
                        val text = "${m.question} ${m.slug}".lowercase()
                        return text.contains("bitcoin") || text.contains("btc") || text.contains("crypto")
                    }
                    fun score(m: com.caifenxi.app.domain.btc.polymarket.PolyMarket): Long {
                        val text = "${m.question} ${m.slug}".lowercase()
                        val interval = if (m.startDateMs != null && m.endDateMs != null) (m.endDateMs - m.startDateMs) / 60_000L else null
                        val explicit = when (targetMinutes) {
                            5L -> listOf("5 min", "5-minute", "5 minute", "5m", "up or down").any(text::contains)
                            15L -> listOf("15 min", "15-minute", "15 minute", "15m").any(text::contains)
                            else -> listOf("1 hour", "1-hour", "60 min", "60-minute", "1h", "daily", "today").any(text::contains)
                        }
                        val intervalOk = interval != null && kotlin.math.abs(interval - targetMinutes) <= maxOf(2L, targetMinutes / 4)
                        // 越匹配分越低
                        var s = kotlin.math.abs((m.endDateMs ?: Long.MAX_VALUE) - (now + targetMinutes * 60_000L))
                        if (explicit || intervalOk) s -= 10_000_000_000L
                        if (text.contains("up or down") || text.contains("updown")) s -= 1_000_000_000L
                        return s
                    }
                    val open = polyMarkets.filter { !it.closed && (it.endDateMs == null || it.endDateMs > now) && isBtc(it) }
                    // 1) 优先精确周期
                    open.minByOrNull { score(it) }?.let { best ->
                        val text = "${best.question} ${best.slug}".lowercase()
                        val interval = if (best.startDateMs != null && best.endDateMs != null) (best.endDateMs - best.startDateMs) / 60_000L else null
                        val explicit = when (targetMinutes) {
                            5L -> listOf("5 min", "5-minute", "5 minute", "5m").any(text::contains)
                            15L -> listOf("15 min", "15-minute", "15 minute", "15m").any(text::contains)
                            else -> listOf("1 hour", "1-hour", "60 min", "1h", "daily").any(text::contains)
                        }
                        if (explicit || (interval != null && kotlin.math.abs(interval - targetMinutes) <= maxOf(2L, targetMinutes / 4))) {
                            return best
                        }
                    }
                    // 2) 降级：任意 BTC 相关活跃盘（避免面板长期空白）
                    return open.minByOrNull { score(it) }
                }
                val selectedPoly = listOf("5m", "15m", "1h").mapNotNull { tf -> matchPoly(tf)?.let { tf to it } }.toMap()
                val polyBooks = selectedPoly.mapNotNull { (tf, m) ->
                    runCatching { polymarketRepo.orderBook(m.yesTokenId) }.getOrNull()
                        ?.takeIf { it.bestAsk != null || it.bestBid != null }
                        ?.let { tf to it }
                }.toMap()
                val polyNoBooks = selectedPoly.mapNotNull { (tf, m) ->
                    runCatching { polymarketRepo.orderBook(m.noTokenId) }.getOrNull()
                        ?.takeIf { it.bestAsk != null || it.bestBid != null }
                        ?.let { tf to it }
                }.toMap()
                fun indicative(tf: String) = selectedPoly[tf]?.yesPrice?.coerceIn(0.02, 0.98) ?: 0.50

                val useDemo = bundle.useDemo || primaryCandles.size < 2
                // 实时轮询期间遇到一次网络抖动，不得把上一份真实快照覆盖成 Demo；
                // 但若此前本身就是 Demo/无快照，则允许用新的 Demo 刷新，避免看板“卡死不动”。
                // 软超时：真实快照超过 90s 未刷新，允许 Demo 接管，防止看板/决策长期静止。
                val snapshotAgeMs = System.currentTimeMillis() - (_state.value.hsSnapshot?.updatedAt ?: _state.value.updatedAt)
                val snapshotStale = snapshotAgeMs > 90_000L
                if (useDemo && hadLiveSnapshot && !snapshotStale) {
                    // 网络失败但仍在保鲜期内：至少允许切换周期时从缓存换图，避免“周期无法切换”
                    val cur = _state.value
                    val switchedCandles = when (timeframe) {
                        "5m" -> cur.candles5m.ifEmpty { cur.candles }
                        "1h" -> cur.candles1h.ifEmpty { cur.candles }
                        else -> cur.candles15m.ifEmpty { cur.candles }
                    }
                    _state.value = cur.copy(
                        loading = false,
                        timeframe = timeframe,
                        candles = if (switchedCandles.isNotEmpty()) switchedCandles else cur.candles,
                        error = "实时数据暂不可用，已保留上一份真实快照（${snapshotAgeMs / 1000}s 前）；不会用 Demo 覆盖 LIVE 数据"
                    )
                    return@runCatching
                }
                // 超过保鲜期则继续往下走，允许 Demo 刷新，保持看板有动态
                val final5 = if (c5.size >= 40) c5 else if (useDemo) BtcDemoDataProvider.generateCandles(symbol, "5m", 300) else primaryCandles
                val final15 = if (c15.size >= 40) c15 else if (useDemo) BtcDemoDataProvider.generateCandles(symbol, "15m", 300) else primaryCandles
                val final1h = if (c1h.size >= 40) c1h else if (useDemo) BtcDemoDataProvider.generateCandles(symbol, "1h", 300) else primaryCandles
                applyMarketBundle(
                    symbol = symbol, timeframe = timeframe,
                    candles = when (timeframe) { "5m" -> final5; "1h" -> final1h; else -> final15 },
                    candles5m = final5, candles15m = final15, candles1h = final1h,
                    marketYes5m = indicative("5m"), marketYes15m = indicative("15m"), marketYes1h = indicative("1h"),
                    funding = if (useDemo) BtcDemoDataProvider.generateFundingHistory(symbol, 100) else funding,
                    oi = if (useDemo) BtcDemoDataProvider.generateOiHistory(symbol, 100) else oi,
                    snap = if (useDemo) BtcDemoDataProvider.generateDerivativesSnapshot(symbol) else snap,
                    news = if (useDemo) BtcDemoDataProvider.generateNewsSnapshot() else news,
                    binanceOrderBook = if (useDemo) null else depth,
                    polyBooks = if (useDemo) emptyMap() else polyBooks,
                    polyNoBooks = if (useDemo) emptyMap() else polyNoBooks,
                    polyMarkets = if (useDemo) emptyMap() else selectedPoly,
                    oraclePrice = if (useDemo) 0.0 else oracle?.price ?: 0.0,
                    oracleUpdatedAt = if (useDemo) 0L else oracle?.updatedAt ?: 0L,
                    oracleLive = !useDemo && oracle != null,
                    useDemo = useDemo,
                    errorMsg = if (useDemo) "网络不可达或 K 线不足，已切换 Demo；Demo 不伪造盘口/Oracle/账户数据" else null
                )
            }.onFailure { e ->
                // 无“真实”快照时自动刷新 Demo，避免看板/决策空白或静止
                if (!hadLiveSnapshot) {
                    applyMarketBundle(
                        symbol = symbol,
                        timeframe = timeframe,
                        candles = BtcDemoDataProvider.generateCandles(symbol, timeframe, 300),
                        candles5m = BtcDemoDataProvider.generateCandles(symbol, "5m", 300),
                        candles15m = BtcDemoDataProvider.generateCandles(symbol, "15m", 300),
                        candles1h = BtcDemoDataProvider.generateCandles(symbol, "1h", 300),
                        marketYes5m = 0.50,
                        marketYes15m = 0.50,
                        marketYes1h = 0.50,
                        funding = BtcDemoDataProvider.generateFundingHistory(symbol, 100),
                        oi = BtcDemoDataProvider.generateOiHistory(symbol, 100),
                        snap = BtcDemoDataProvider.generateDerivativesSnapshot(symbol),
                        news = BtcDemoDataProvider.generateNewsSnapshot(),
                        useDemo = true,
                        errorMsg = "行情加载失败，已切换演示数据：${e.message ?: "未知错误"}"
                    )
                } else {
                    _state.value = _state.value.copy(loading = false, error = e.message ?: "行情加载失败")
                }
            }
            } finally {
                refreshMutex.unlock()
            }
        }
    }

    private suspend fun applyMarketBundle(
        symbol: String,
        timeframe: String,
        candles: List<com.caifenxi.app.domain.btc.BtcCandle>,
        candles5m: List<com.caifenxi.app.domain.btc.BtcCandle> = candles,
        candles15m: List<com.caifenxi.app.domain.btc.BtcCandle> = candles,
        candles1h: List<com.caifenxi.app.domain.btc.BtcCandle> = candles,
        marketYes5m: Double = 0.50,
        marketYes15m: Double = 0.50,
        marketYes1h: Double = 0.50,
        funding: List<com.caifenxi.app.domain.btc.FundingPoint>,
        oi: List<com.caifenxi.app.domain.btc.OpenInterestPoint>,
        snap: com.caifenxi.app.domain.btc.BtcDerivativesSnapshot?,
        news: com.caifenxi.app.domain.btc.news.NewsSnapshot?,
        binanceOrderBook: BinanceOrderBookRepository.Snapshot? = null,
        polyBooks: Map<String, com.caifenxi.app.domain.btc.polymarket.PolyOrderBook> = emptyMap(),
        polyNoBooks: Map<String, com.caifenxi.app.domain.btc.polymarket.PolyOrderBook> = emptyMap(),
        polyMarkets: Map<String, com.caifenxi.app.domain.btc.polymarket.PolyMarket> = emptyMap(),
        oraclePrice: Double = 0.0,
        oracleUpdatedAt: Long = 0L,
        oracleLive: Boolean = false,
        useDemo: Boolean,
        errorMsg: String?
    ) {
        val last = candles.lastOrNull()
        val prev = candles.getOrNull((candles.size - 2).coerceAtLeast(0))
        val deriv = if (last != null) {
            DerivativesFeatureEngine.build(last.openTime, last.close, prev?.close, funding, oi, snap)
        } else null
        val pool = _planPoolConfig.value
        val (basePlans, baseConsensus) = engine.evaluate(
            candles, deriv,
            weightOverrides = pool.weightOverrides,
            enabledPlanIds = pool.enabledPlans
        )
        val aiCand = aiBrain.generateCandidate(candles, basePlans, baseConsensus, news, deriv)
        val aiJson = aiBrain.toForcedJson(aiCand)
        val aiPlan = AiPolicy.toPlanSignal(aiCand, aiPolicy)
        val (plans, consensus) = if (aiPlan != null) {
            engine.evaluate(
                candles, deriv,
                extraSignals = listOf(aiPlan),
                weightOverrides = pool.weightOverrides,
                enabledPlanIds = pool.enabledPlans
            )
        } else basePlans to baseConsensus
        // 过滤非法数值，降低 UI 层崩溃概率
        val safePlans = plans.map { p ->
            p.copy(
                rawScore = p.rawScore.takeIf { it.isFinite() } ?: 0.0,
                confidence = p.confidence.takeIf { it.isFinite() }?.coerceIn(0.0, 1.0) ?: 0.0,
                weight = p.weight.takeIf { it.isFinite() }?.coerceIn(0.1, 3.0) ?: 1.0,
                hitRate = p.hitRate.takeIf { it.isFinite() }?.coerceIn(0.0, 1.0) ?: 0.0,
                regimeFit = p.regimeFit.takeIf { it.isFinite() }?.coerceIn(0.0, 1.0) ?: 0.0,
                contribution = p.contribution.takeIf { it.isFinite() } ?: 0.0
            )
        }
        // 3) 账户源：有真实 Binance 凭据则读取真实账户；否则明确显示 PAPER，不再填充演示余额。
        val paperAcc = binaryOptionEngine.account()
        val paperDaily = binaryOptionEngine.dailyStats()
        val paperStats = binaryOptionEngine.statsSummary()
        var hsBalance = paperAcc.balance
        var hsAvailable = (paperAcc.balance - paperAcc.pendingBets.sumOf { it.amount }).coerceAtLeast(0.0)
        var hsOpenNotional = paperAcc.pendingBets.sumOf { it.amount }
        var hsTodayPnl = paperDaily.netProfit
        var hsPnl30d = paperStats.netProfit
        var hsMaxDd = -kotlin.math.abs(paperAcc.maxDrawdownPct)
        var accountMode = if (useDemo) "DEMO" else "PAPER"
        val liveCreds = credentialStore.load()
        if (!useDemo && liveCreds.binanceApiKey.isNotBlank() && liveCreds.binanceSecret.isNotBlank()) {
            runCatching {
                val broker = BrokerFactory.perp(liveCreds, forcePaper = false)
                val account = broker.accountSnapshot()
                val position = broker.fetchPositionRisk(symbol)
                hsBalance = account.totalWalletBalance
                hsAvailable = account.availableBalance
                hsOpenNotional = kotlin.math.abs(position?.positionAmt ?: 0.0) * (snap?.markPrice ?: candles.lastOrNull()?.close ?: 0.0)
                hsTodayPnl = account.unrealizedPnl
                hsPnl30d = 0.0
                hsMaxDd = 0.0
                accountMode = "LIVE_ACCOUNT"
            }.onFailure {
                accountMode = "ACCOUNT_OFFLINE"
                hsBalance = 0.0; hsAvailable = 0.0; hsOpenNotional = 0.0; hsTodayPnl = 0.0; hsPnl30d = 0.0; hsMaxDd = 0.0
            }
        }

        // HS Prediction Engine：真实多周期 K 线 + 真实盘口 + 明确标识的账户源
        // 纸交易账户统一走 PaperAccountCoordinator（LIVE 账户覆盖见上）
        val paperSnap = paperAccountCoordinator.snapshot()
        if (accountMode == "PAPER" || accountMode == "DEMO") {
            hsBalance = paperSnap.balance
            hsAvailable = paperSnap.available
            hsOpenNotional = paperSnap.openNotional
            hsTodayPnl = paperSnap.todayPnl
            hsPnl30d = paperSnap.pnl30d
            hsMaxDd = paperSnap.maxDrawdownPct
        }
        var hsError: String? = null
        val hsSnap = runCatching {
            hsEngineCoordinator.evaluate(
                candles5m = candles5m,
                candles15m = candles15m,
                candles1h = candles1h,
                deriv = deriv,
                marketYes5m = marketYes5m,
                marketYes15m = marketYes15m,
                marketYes1h = marketYes1h,
                paper = com.caifenxi.app.domain.btc.coord.PaperAccountCoordinator.Snapshot(
                    balance = hsBalance,
                    available = hsAvailable,
                    openNotional = hsOpenNotional,
                    todayPnl = hsTodayPnl,
                    pnl30d = hsPnl30d,
                    maxDrawdownPct = hsMaxDd
                ),
                newsScore = news?.netSentiment ?: 0.0,
                markPrice = snap?.markPrice ?: candles.lastOrNull()?.close ?: 0.0,
                chainlinkPrice = oraclePrice,
                binanceOrderBook = binanceOrderBook,
                polyBooks = polyBooks,
                polyNoBooks = polyNoBooks,
                polyMarkets = polyMarkets,
                oracleUpdatedAt = oracleUpdatedAt,
                oracleLive = oracleLive,
                dataMode = if (useDemo) "DEMO" else accountMode
            )
        }.onFailure { e ->
            hsError = "HS引擎: ${e.message ?: e.javaClass.simpleName}"
            android.util.Log.e("BtcQuant", "HS evaluate failed", e)
        }.getOrNull()

        // 引擎失败时保留上一份快照，避免看板被清空成「无快照」
        val finalHs = hsSnap ?: _state.value.hsSnapshot
        val finalError = listOfNotNull(errorMsg, hsError).joinToString(" · ").ifBlank { null }

        val polyHistory = (_state.value.polymarketYesHistory + (polyMarkets["5m"]?.yesPrice ?: marketYes5m))
            .filter { it.isFinite() && it in 0.0..1.0 }
            .takeLast(120)

        val factorSnapshot = QuantFactorEngine.calculate(candles, deriv, symbol, timeframe)
        val polyAuto = if (!useDemo) {
            val pm = polyMarkets["5m"]
            val yes = pm?.let { polyBooks["5m"] }
            if (pm != null && yes != null) {
                polymarketAutoQuantEngine.evaluate(
                    candles = candles5m, market = pm, yesBook = yes, noBook = polyNoBooks["5m"], deriv = deriv
                )
            } else null
        } else null

        _state.value = _state.value.copy(
            symbol = symbol,
            timeframe = timeframe,
            candles = candles,
            candles5m = candles5m,
            candles15m = candles15m,
            candles1h = candles1h,
            plans = safePlans,
            consensus = consensus,
            loading = false,
            isDemoMode = useDemo,
            error = finalError,
            updatedAt = System.currentTimeMillis(),
            newsNetSentiment = news?.netSentiment,
            newsBlackSwan = news?.blackSwan == true,
            newsHeadlines = news?.topHeadlines ?: emptyList(),
            aiDirection = aiCand.direction,
            aiConfidence = aiCand.confidence,
            aiJson = aiJson,
            aiLiveAllowed = AiPolicy.mayExecuteLive(aiPolicy, aiCand),
            fundingRate = deriv?.fundingRate ?: snap?.fundingRate,
            fundingZScore = deriv?.fundingZScore,
            fundingExtreme = deriv?.fundingExtreme == true,
            oiChangePct = deriv?.oiChangePct,
            derivativesScore = deriv?.derivativesScore,
            markPrice = snap?.markPrice ?: candles.lastOrNull()?.close,
            hsSnapshot = finalHs,
            polymarketYesHistory = polyHistory,
            quantFactors = factorSnapshot,
            polymarketStrategies = polyAuto?.candidates ?: emptyList(),
            polymarketAutoReason = polyAuto?.reason
        )
        tickBinaryRound()
        tickFuturesQuant()
        // 首次成功有行情后异步拉一次 exchangeInfo 精度（失败则保持默认）
        if (!exchangeFiltersLoaded) {
            exchangeFiltersLoaded = true
            refreshExchangeFilters(symbol)
        }
    }

    @Volatile
    private var exchangeFiltersLoaded: Boolean = false

    override fun onCleared() {
        liveMarketStream.stop()
        super.onCleared()
    }
}
