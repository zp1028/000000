package com.caifenxi.app.domain.btc.polymarket.research

import com.caifenxi.app.data.db.entity.PolymarketSnapshotEntity
import kotlin.math.abs

/** True expanding-window OOS evaluator with explicit trading costs. */
object PolymarketWalkForwardEngine {
    data class StrategyMetric(
        val strategyId: String,
        val samples: Int,
        val settled: Int,
        val winRate: Double,
        val avgEdge: Double,
        val avgReturn: Double,
        val profitFactor: Double,
        val maxDrawdown: Double,
        val stability: Double,
        val lookaheadViolations: Int,
        val score: Double,
        val folds: Int = 0,
        val costDrag: Double = 0.0
    )

    fun evaluate(
        rows: List<PolymarketSnapshotEntity>,
        minTrainSamples: Int = 30,
        testWindow: Int = 12,
        feeRate: Double = 0.002,
        slippage: Double = 0.003
    ): List<StrategyMetric> {
        return rows.filter { it.strategyId != null }.groupBy { it.strategyId!! }.mapNotNull { (id, all) ->
            val ordered = all.sortedBy { it.capturedAtMs }
            if (ordered.size < minTrainSamples + testWindow) return@mapNotNull null
            val returns = mutableListOf<Double>()
            val foldWins = mutableListOf<Double>()
            var cursor = minTrainSamples
            var folds = 0
            while (cursor < ordered.size) {
                val end = (cursor + testWindow).coerceAtMost(ordered.size)
                val train = ordered.take(cursor)
                val test = ordered.subList(cursor, end).filter { it.resolvedOutcome != null && it.signalOutcome != null }
                if (test.isNotEmpty()) {
                    val trainEdge = train.mapNotNull { it.signalEdge }.average().takeIf { !it.isNaN() } ?: 0.0
                    val foldReturns = test.map { netReturn(it, feeRate, slippage) }
                    returns += foldReturns
                    foldWins += ((foldReturns.count { it > 0.0 }.toDouble() / foldReturns.size) + trainEdge.coerceIn(-1.0, 1.0) * 0.05).coerceIn(0.0, 1.0)
                    folds++
                }
                cursor = end
            }
            if (returns.isEmpty()) return@mapNotNull null
            val winRate = returns.count { it > 0.0 }.toDouble() / returns.size
            val grossWin = returns.filter { it > 0.0 }.sum()
            val grossLoss = -returns.filter { it < 0.0 }.sum()
            val pf = if (grossLoss <= 1e-9) grossWin.coerceAtLeast(0.0) else grossWin / grossLoss
            val avgReturn = returns.average()
            val maxDd = maxDrawdown(returns)
            val half = foldWins.size / 2
            val first = if (half > 0) foldWins.take(half).average() else 0.5
            val second = if (foldWins.size - half > 0) foldWins.drop(half).average() else 0.5
            val stability = (1.0 - abs(first - second)).coerceIn(0.0, 1.0)
            val avgEdge = ordered.filter { it.resolvedOutcome != null }.mapNotNull { it.signalEdge }.average().takeIf { !it.isNaN() } ?: 0.0
            val costDrag = ordered.filter { it.resolvedOutcome != null }.map { row ->
                val entry = if (row.signalOutcome.equals("YES", true)) row.yesAsk ?: 0.5 else row.noAsk ?: 0.5
                (entry * feeRate + slippage) / entry.coerceAtLeast(0.01)
            }.average().coerceIn(0.0, 1.0)
            val score = ((pf - 1.0) / 1.5).coerceIn(-1.0, 1.0) * 0.30 +
                ((winRate - 0.5) * 2.0).coerceIn(-1.0, 1.0) * 0.20 +
                avgReturn.coerceIn(-1.0, 1.0) * 0.20 + stability * 0.15 - costDrag * 0.15
            StrategyMetric(id, ordered.size, returns.size, winRate, avgEdge, avgReturn, pf, maxDd, stability, lookaheadViolations(ordered), score, folds, costDrag)
        }.sortedByDescending { it.score }
    }

    private fun netReturn(row: PolymarketSnapshotEntity, feeRate: Double, slippage: Double): Double {
        val outcome = row.signalOutcome?.uppercase() ?: return 0.0
        val price = when (outcome) { "YES" -> row.yesAsk; "NO" -> row.noAsk; else -> null } ?: return 0.0
        val entryCost = price + price * feeRate + slippage
        return if (outcome.equals(row.resolvedOutcome, true)) {
            (1.0 - entryCost) / price.coerceAtLeast(0.01)
        } else {
            -entryCost / price.coerceAtLeast(0.01)
        }
    }

    private fun maxDrawdown(returns: List<Double>): Double {
        var equity = 1.0
        var peak = 1.0
        var maxDd = 0.0
        returns.forEach { r ->
            equity *= (1.0 + r).coerceAtLeast(0.001)
            peak = maxOf(peak, equity)
            maxDd = maxOf(maxDd, 1.0 - equity / peak)
        }
        return maxDd.coerceIn(0.0, 1.0)
    }

    private fun lookaheadViolations(rows: List<PolymarketSnapshotEntity>): Int = rows.count { row ->
        row.endDateMs != null && row.capturedAtMs > row.endDateMs
    }
}
