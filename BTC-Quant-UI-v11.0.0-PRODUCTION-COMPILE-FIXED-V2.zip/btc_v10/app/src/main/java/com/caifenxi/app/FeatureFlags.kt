package com.caifenxi.app

/**
 * 产品功能开关 —— 由 productFlavor 的 BuildConfig 控制。
 * btc: 仅 BTC Quant；legacy: 仅彩票；full: 全部。
 */
object FeatureFlags {
    val btcQuantEnabled: Boolean
        get() = runCatching { BuildConfig.FEATURE_BTC_QUANT }.getOrDefault(true)
    val legacyLotteryEnabled: Boolean
        get() = runCatching { BuildConfig.FEATURE_LEGACY_LOTTERY }.getOrDefault(true)
}
