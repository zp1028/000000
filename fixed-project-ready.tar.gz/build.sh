#!/system/bin/sh
cd /storage/emulated/0/对1/彩析源码-v2.3.4-无障碍倍投自由输入-挂机跟随收藏预测-7/source_code
chmod +x gradlew
./gradlew assembleDebug