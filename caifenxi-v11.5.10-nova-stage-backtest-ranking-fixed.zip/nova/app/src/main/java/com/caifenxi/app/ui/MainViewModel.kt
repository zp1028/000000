package com.caifenxi.app.ui

import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.caifenxi.app.CaiFenXiApplication
import com.caifenxi.app.domain.engine.AnalysisEngine
import com.caifenxi.app.domain.engine.DataConsistency
import com.caifenxi.app.domain.engine.PredictEngine
import com.caifenxi.app.domain.engine.StatsEngine
import com.caifenxi.app.domain.engine.ConsensusEngine
import com.caifenxi.app.domain.model.AlgoMode
import com.caifenxi.app.domain.model.AlgoResult
import com.caifenxi.app.domain.model.AnalysisBundle
import com.caifenxi.app.domain.model.DrawRecord
import com.caifenxi.app.domain.model.LabRow
import com.caifenxi.app.domain.model.LotteryConfig
import com.caifenxi.app.domain.model.ManualMark
import com.caifenxi.app.domain.model.ModelConsensus
import com.caifenxi.app.domain.model.ConsensusRecord
import com.caifenxi.app.domain.model.ConsensusStats
import com.caifenxi.app.domain.model.BetStats
import com.caifenxi.app.domain.model.BetView
import com.caifenxi.app.domain.model.BotConfig
import com.caifenxi.app.domain.model.PlanDefinition
import com.caifenxi.app.domain.model.PlanPredictionRecord
import com.caifenxi.app.domain.model.PlanRuntime
import com.caifenxi.app.domain.model.PredictionSnapshot
import com.caifenxi.app.domain.model.StatRecord
import com.caifenxi.app.domain.model.WalletView
import com.caifenxi.app.domain.model.StatsSummary
import com.caifenxi.app.domain.model.UserPrefs
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.concurrent.atomic.AtomicBoolean
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.caifenxi.app.util.RuntimeLog
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 主 ViewModel:首页数据、预测、统计、设置与数据导出。
 * 计划/回测/共识/自定义计划委托给 [PlanViewModel],挂机/下注委托给 [BetViewModel],
 * 三者在 Application 级共享 planEngine / betEngine,保证状态一致。
 */
class MainViewModel : ViewModel() {

    private val app get() = CaiFenXiApplication.instance
    private val repo get() = app.drawRepository
    private val configStore get() = app.configStore
    private val statStore get() = app.statStore
    private val manualStore get() = app.manualStore
    private val consensusStore get() = app.consensusStore
    private val planEngine get() = app.planEngine

    // ---- 子 ViewModel(委托) ----
    val planVM = PlanViewModel()
    val betVM = BetViewModel()

    val prefs = mutableStateOf(configStore.loadPrefs())
    val currentLottery = mutableStateOf(
        LotteryConfig.findByKey(prefs.value.selectedLotteryKey) ?: LotteryConfig.CATALOG.first()
    )
    val currentAlgo = mutableStateOf(AlgoMode.fromId(prefs.value.currentAlgo))
    val history = mutableStateOf<List<DrawRecord>>(emptyList())
    val latest = mutableStateOf<DrawRecord?>(null)
    val loading = mutableStateOf(false)
    val errorMessage = mutableStateOf<String?>(null)
    val prediction = mutableStateOf<PredictionSnapshot?>(null)
    val algoCompare = mutableStateOf<Map<String, List<AlgoResult>>>(emptyMap())
    val statusText = mutableStateOf("")
    val statsSummary = mutableStateOf(StatsSummary())
    val statRecords = mutableStateOf<List<StatRecord>>(emptyList())
    val analysis = mutableStateOf(AnalysisBundle())
    val manualMarks = mutableStateOf<Map<String, ManualMark>>(emptyMap())
    val countdownText = mutableStateOf("--:--")
    val nextIssueText = mutableStateOf("-")
    val historyPageLoading = mutableStateOf(false)
    val historyTotalCount = mutableStateOf(0)

    // V9.3 预测历史分页状态：历史记录从数据库按页读取，避免几千条预测一次性进入 Compose。
    val predictionPageLoading = mutableStateOf(false)
    val predictionTotalCount = mutableStateOf(0)

    /** 分页读取历史开奖，避免 History 页面一次性读取全部数据库记录。 */
    fun loadHistoryPage(page: Int, pageSize: Int = 100, onResult: (List<DrawRecord>) -> Unit) {
        if (historyPageLoading.value) return
        viewModelScope.launch {
            historyPageLoading.value = true
            val result = withContext(Dispatchers.IO) {
                try {
                    historyTotalCount.value = repo.countLocal(currentLottery.value.key)
                    repo.getHistoryPage(currentLottery.value.key, page, pageSize)
                } catch (_: Exception) {
                    emptyList()
                }
            }
            historyPageLoading.value = false
            onResult(result)
        }
    }

    /** V9.3：预测历史分页。category=位置时匹配全部“位置-*”记录。 */
    fun loadPredictionPage(
        page: Int,
        pageSize: Int = 100,
        category: String = "全部",
        result: String = "",
        onResult: (List<StatRecord>) -> Unit
    ) {
        if (predictionPageLoading.value) return
        viewModelScope.launch {
            predictionPageLoading.value = true
            val normalized = if (category == "全部") "" else category
            val normalizedResult = if (result == "全部") "" else result
            val pageResult = withContext(Dispatchers.IO) {
                try {
                    predictionTotalCount.value = statStore.countPageSource(currentLottery.value.key, normalized, normalizedResult)
                    statStore.loadPage(currentLottery.value.key, page, pageSize, normalized, normalizedResult)
                } catch (_: Exception) {
                    emptyList()
                }
            }
            predictionPageLoading.value = false
            onResult(pageResult)
        }
    }



    // ---- 数据导出/备份 ----
    /** 最近一次导出的文件(UI 观察后触发分享) */
    val exportedFile = mutableStateOf<java.io.File?>(null)
    /** 恢复进行中标志 */
    val restoring = mutableStateOf(false)

    // ---- 计划 / 共识(委托 PlanViewModel) ----
    val consensus get() = planVM.consensus
    val planRows get() = planVM.planRows
    val backtestRunning get() = planVM.backtestRunning
    val labRows get() = planVM.labRows
    val planHistory get() = planVM.planHistory
    val currentPredictions get() = planVM.currentPredictions
    val selectedPlanHistory get() = planVM.selectedPlanHistory
    val consensusRecords get() = planVM.consensusRecords
    val consensusStats get() = planVM.consensusStats
    val customPlans get() = planVM.customPlans

    // ---- 挂机 / 下注(委托 BetViewModel) ----
    val botConfig get() = betVM.botConfig
    val wallet get() = betVM.wallet
    val betHistory get() = betVM.betHistory
    val betStats get() = betVM.betStats
    val betCurveRevision get() = betVM.betCurveRevision
    val betCurveReset get() = betVM.betCurveReset

    private var refreshJob: Job? = null
    private var countdownJob: Job? = null
    private val loadMutex = Mutex()
    private val loadingGuard = AtomicBoolean(false)
    /** 同步进行中再次请求加载(如切换彩种)时置位,当前任务结束后自动接续 */
    private val pendingReload = AtomicBoolean(false)
    private var failStreak = 0
    private var lastForegroundRefresh = 0L

    init {
        loadData()
        viewModelScope.launch {
            try {
                refreshConsensusStats()
            } catch (e: Exception) {
                // 共识统计失败不影响启动
            }
        }
        refreshBetState()
        startAutoRefreshIfNeeded()
        startCountdown()
    }

    fun selectLottery(config: LotteryConfig) {
        currentLottery.value = config
        val p = prefs.value.copy(selectedLotteryKey = config.key)
        prefs.value = p
        configStore.savePrefs(p)
        loadData()
    }

    fun selectCockpitPlan(planId: String, cyclePeriods: Int = prefs.value.cockpitPlanCyclePeriods) {
        val normalized = planId.trim()
        val cycle = cyclePeriods.coerceIn(1, 20)
        val p = prefs.value.copy(cockpitPlanId = normalized, cockpitPlanCyclePeriods = cycle)
        prefs.value = p
        configStore.savePrefs(p)
        statusText.value = if (normalized.isBlank()) "驾驶舱已恢复算法模式" else "驾驶舱已指定计划：$normalized"
        viewModelScope.launch {
            try {
                if (history.value.isNotEmpty()) {
                    // 清空计划来源后，明确按当前算法重新生成并写入预测记录。
                    if (normalized.isBlank()) {
                        runPredictAndPlans(history.value, forceAlgo = currentAlgo.value)
                    } else {
                        runPredictAndPlans(history.value)
                    }
                }
            } catch (e: Exception) {
                errorMessage.value = e.message ?: "切换驾驶舱计划失败"
            }
        }
    }

    fun selectAlgo(mode: AlgoMode) {
        // 切换到“算法”来源时，必须同时解除已选择的新/原计划来源。
        // 否则驾驶舱仍会优先使用 cockpitPlanId，导致预测页面虽然显示了新算法，
        // 预测记录却继续按之前默认计划/模型写入。
        currentAlgo.value = mode
        val p = prefs.value.copy(
            currentAlgo = mode.id,
            cockpitPlanId = ""
        )
        prefs.value = p
        configStore.savePrefs(p)
        statusText.value = "预测来源已切换为算法：${mode.label}"
        viewModelScope.launch {
            try {
                if (history.value.isNotEmpty()) runPredictAndPlans(history.value, forceAlgo = mode)
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                errorMessage.value = e.message ?: "切换算法失败"
            }
        }
    }

    fun setManualMark(category: String, direction: String) {
        viewModelScope.launch {
            try {
                val m = ManualMark(currentLottery.value.key, category, direction)
                manualStore.save(m)
                manualMarks.value = manualStore.load(currentLottery.value.key)
                if (currentAlgo.value == AlgoMode.MANUAL) {
                    if (history.value.isNotEmpty()) runPredictAndPlans(history.value, forceAlgo = AlgoMode.MANUAL)
                }
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                errorMessage.value = e.message ?: "手动标记失败"
            }
        }
    }

    fun clearManualMarks() {
        viewModelScope.launch {
            try {
                manualStore.clear(currentLottery.value.key)
                manualMarks.value = emptyMap()
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                // 清空失败不影响主流程
            }
        }
    }

    fun updatePrefs(transform: (UserPrefs) -> UserPrefs) {
        val p = transform(prefs.value)
        prefs.value = p
        configStore.savePrefs(p)
        if (p.autoRefresh) startAutoRefreshIfNeeded() else stopAutoRefresh()
    }

    /** 从实验室将模板计划加入共识计划池 */
    fun addPlanToPool(planId: String) {
        updatePrefs { p ->
            val cur = p.selectedPlanIds
            // 首次从「默认池」切换到显式勾选:先纳入当前默认前 N 条,再追加
            val base = if (cur.isEmpty()) {
                com.caifenxi.app.domain.plan.PlanPool.ALL
                    .take(p.planPoolCount.coerceIn(4, 40))
                    .map { it.planId }
            } else cur
            p.copy(selectedPlanIds = (base + planId).distinct())
        }
        statusText.value = "已加入计划池"
    }

    fun removePlanFromPool(planId: String) {
        updatePrefs { p ->
            val cur = if (p.selectedPlanIds.isEmpty()) {
                com.caifenxi.app.domain.plan.PlanPool.ALL
                    .take(p.planPoolCount.coerceIn(4, 40))
                    .map { it.planId }
            } else p.selectedPlanIds
            p.copy(selectedPlanIds = cur.filter { it != planId })
        }
        statusText.value = "已移出计划池"
    }

    /** 前台恢复时轻量刷新,避免卡死与掉线 */
    fun onForeground() {
        val now = System.currentTimeMillis()
        if (now - lastForegroundRefresh < 8_000) return
        lastForegroundRefresh = now
        // 重置可能卡住的 loading
        if (loading.value && !loadingGuard.get()) {
            loading.value = false
        }
        startAutoRefreshIfNeeded()
        startCountdown()
        refreshBetState()
        softRefreshLatest()
    }

    fun softRefreshLatest() {
        viewModelScope.launch {
            try {
                withTimeout(20_000) {
                    val one = app.apiClient.fetchLatest(currentLottery.value)
                    if (one != null) {
                        val exists = history.value.any { it.issue == one.issue }
                        if (!exists) {
                            loadData()
                        } else {
                            // 用最新一期刷新下期显示,并补生成缺失的计划共识
                            latest.value = one
                            if (history.value.isNotEmpty()) {
                                val merged = history.value.map {
                                    if (it.issue == one.issue) one else it
                                }
                                history.value = merged
                                updateNextIssue(merged)
                                ensureNextPlanConsensus(merged)
                            } else {
                                updateNextIssue(listOf(one))
                            }
                            statusText.value = "已同步 · 最新 ${one.issue}"
                            failStreak = 0
                        }
                    } else if (history.value.isNotEmpty()) {
                        // 网络拿不到最新也根据本地最新推算下期,并尽量补共识
                        updateNextIssue(history.value)
                        ensureNextPlanConsensus(history.value)
                    }
                }
            } catch (_: Exception) {
                failStreak++
                statusText.value = "弱网 · 使用缓存"
                if (history.value.isNotEmpty()) {
                    updateNextIssue(history.value)
                    try { ensureNextPlanConsensus(history.value) } catch (_: Exception) {}
                }
            }
        }
    }

    fun loadData() {
        if (!loadingGuard.compareAndSet(false, true)) {
            // 正在同步时(例如切换了彩种)标记待重载,当前任务结束后自动加载新彩种,
            // 修复原实现直接 return 导致「界面已切新彩种、数据仍是旧彩种」的问题
            pendingReload.set(true)
            statusText.value = "同步中,请稍候..."
            return
        }
        viewModelScope.launch {
            loading.value = true
            errorMessage.value = null
            statusText.value = "拉取开奖..."
            // 固定本次加载的彩种,避免加载中途切换彩种造成数据错乱
            val cfg = currentLottery.value
            var hadCache = false
            try {
                // 1) 先快速展示工作窗口缓存(不读全库 8000+)
                val cached = withContext(Dispatchers.IO) {
                    repo.getWorkingHistory(cfg.key)
                }
                val totalLocal = withContext(Dispatchers.IO) { repo.countLocal(cfg.key) }
                if (cached.isNotEmpty() && cfg.key == currentLottery.value.key) {
                    hadCache = true
                    history.value = cached
                    latest.value = trueLatest(cached)
                    updateNextIssue(cached)
                    statusText.value = if (totalLocal > cached.size) {
                        "缓存 ${cached.size}/${totalLocal} 期 · 同步中..."
                    } else {
                        "缓存 ${cached.size} 期 · 同步中..."
                    }
                }

                // 2) 网络合并 + 轻量结算 + 预测(限时;超时若有缓存则降级成功)
                withTimeout(55_000) {
                    val (rows, source, total) = withContext(Dispatchers.IO) {
                        repo.fetchAndCacheHistory(cfg)
                    }
                    if (cfg.key != currentLottery.value.key) return@withTimeout
                    history.value = rows
                    latest.value = trueLatest(rows)
                    val latestRow = latest.value
                    if (isStaleLatest(latestRow)) {
                        RuntimeLog.warn(
                            "E301",
                            "最新开奖已过期(${latestRow?.drawTime?.take(19) ?: "无时间"}) 期号${latestRow?.issue}。" +
                                "可能是停盘彩种(如北京PK10)或网络未同步到新数据,计划目标会偏旧"
                        )
                    }

                    val lastCachedIssue = cached.lastOrNull()?.issue
                    val newRows = if (lastCachedIssue != null) {
                        val idx = rows.indexOfFirst { it.issue == lastCachedIssue }
                        if (idx >= 0) rows.subList(idx + 1, rows.size)
                        else rows.filter {
                            (it.issue.toLongOrNull() ?: -1L) > (lastCachedIssue.toLongOrNull() ?: -1L)
                        }
                    } else rows
                    if (newRows.isNotEmpty()) {
                        StatsEngine.settleWithDraws(statStore, cfg.key, newRows)
                        ConsensusEngine.settleWithDraws(consensusStore, cfg.key, newRows)
                        newRows.forEach {
                            planEngine.settlePendingWithDraw(it, prefs.value.backtestParams)
                            betVM.settleWithDraw(cfg.key, it)
                        }
                        planVM.refreshRuntimeState()
                        betVM.refreshBetState(cfg.key, ::setStatus)
                    }
                    // 一致性只对工作窗口,避免扫全库超时
                    val consistency = try {
                        DataConsistency.checkAndRepair(cfg.key, rows, repair = true)
                    } catch (_: Exception) {
                        null
                    }
                    if (consistency != null && consistency.repaired.isNotEmpty()) {
                        planVM.refreshRuntimeState()
                        betVM.refreshBetState(cfg.key, ::setStatus)
                    }
                    refreshConsensusStats()
                    refreshStats()
                    manualMarks.value = manualStore.load(cfg.key)
                    statusText.value = "分析与预测...($source)"
                    runPredictAndPlans(rows)
                    rebuildAnalysis(rows)
                    val cTag = consistency?.let {
                        if (it.repaired.isNotEmpty()) " · 已修复${it.repaired.size}项"
                        else if (!it.ok) " · 校验异常"
                        else ""
                    } ?: ""
                    val sizeTag = if (total > rows.size) "${rows.size}/${total}" else "${rows.size}"
                    statusText.value = "就绪 · ${sizeTag} 期 · $source$cTag"
                    updateNextIssue(rows)
                }
                failStreak = 0
                errorMessage.value = null
            } catch (e: Exception) {
                failStreak++
                // 有缓存时不算致命失败:界面已可用
                if (hadCache || history.value.isNotEmpty()) {
                    errorMessage.value = null
                    statusText.value = "弱网/超时 · 已用缓存 ${history.value.size} 期"
                    try {
                        updateNextIssue(history.value)
                        ensureNextPlanConsensus(history.value)
                        refreshStats()
                        refreshConsensusStats()
                    } catch (_: Exception) {
                    }
                } else {
                    errorMessage.value = e.message ?: "数据加载失败"
                    statusText.value = "失败 · 无可用缓存"
                }
            } finally {
                loading.value = false
                loadingGuard.set(false)
                // 同步期间有新的加载请求(切换彩种/再次点击刷新):立即接续
                if (pendingReload.compareAndSet(true, false)) loadData()
            }
        }
    }

    private fun setStatus(text: String) {
        statusText.value = text
    }

    /** 仅用本地缓存重算分析/预测/计划,不访问网络(首页「仅用缓存重算」入口) */
    fun recomputeFromCache() {
        viewModelScope.launch {
            val rows = history.value
            if (rows.isEmpty()) {
                statusText.value = "暂无缓存数据,请先刷新"
                return@launch
            }
            statusText.value = "本地重算..."
            try {
                withTimeout(30_000) {
                    StatsEngine.backfillFromHistory(statStore, currentLottery.value.key, rows)
                    refreshStats()
                    refreshConsensusStats()
                    runPredictAndPlans(rows)
                    rebuildAnalysis(rows)
                    updateNextIssue(rows)
                    statusText.value = "已用缓存重算 · ${rows.size} 期"
                }
            } catch (e: Exception) {
                errorMessage.value = e.message ?: "本地重算失败"
                statusText.value = "重算失败"
            }
        }
    }

    // ---- 计划 / 共识(委托 PlanViewModel) ----

    fun runBacktest(requestedPeriods: Int? = 500) {
        planVM.runBacktest(
            rows = history.value,
            prefs = prefs.value,
            lotteryKey = currentLottery.value.key,
            onStatus = ::setStatus,
            onError = { errorMessage.value = it },
            requestedPeriods = requestedPeriods
        )
    }

    suspend fun refreshConsensusStats() {
        planVM.refreshConsensusStats(currentLottery.value.key)
    }

    fun clearConsensusStats() {
        planVM.clearConsensusStats(currentLottery.value.key)
    }

    fun loadPlanDetail(planId: String) {
        planVM.loadPlanDetail(planId)
    }

    fun clearStats() {
        viewModelScope.launch {
            try {
                statStore.clear(currentLottery.value.key)
                refreshStats()
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                // 清空失败不影响主流程
            }
        }
    }

    fun backfillStats() {
        viewModelScope.launch {
            try {
                StatsEngine.backfillFromHistory(statStore, currentLottery.value.key, history.value)
                refreshStats()
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                // 回填失败不影响主流程
            }
        }
    }

    /**
     * 手动数据一致性校验并修复:
     * 漏结算的战绩/共识/挂机、缺失的下期共识等。
     */
    fun runConsistencyCheck() {
        viewModelScope.launch {
            val key = currentLottery.value.key
            val rows = history.value.ifEmpty {
                try { repo.getWorkingHistory(key) } catch (_: Exception) { emptyList() }
            }
            if (rows.isEmpty()) {
                statusText.value = "无历史数据,无法校验"
                return@launch
            }
            statusText.value = "一致性校验中..."
            try {
                val report = withContext(Dispatchers.IO) {
                    DataConsistency.checkAndRepair(key, rows, repair = true)
                }
                planVM.refreshRuntimeState()
                betVM.refreshBetState(key, ::setStatus)
                refreshConsensusStats()
                refreshStats()
                // 修复后若仍缺下期共识,再跑一遍预测管线
                ensureNextPlanConsensus(rows)
                statusText.value = report.summary() +
                    if (report.repaired.isNotEmpty()) " · ${report.repaired.joinToString("；")}" else ""
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                statusText.value = "校验失败:${e.message?.take(40)}"
            }
        }
    }

    // ---- 自定义计划(委托 PlanViewModel) ----

    /** 从 Room 加载当前彩种的自定义计划并注入共享 PlanEngine */
    fun loadCustomPlans() {
        planVM.loadCustomPlans(currentLottery.value.key)
    }

    /** 保存(新增或更新)自定义计划 */
    fun saveCustomPlan(plan: com.caifenxi.app.domain.model.CustomPlan) {
        planVM.saveCustomPlan(plan, ::setStatus)
    }

    /** 删除自定义计划 */
    fun deleteCustomPlan(planId: String) {
        planVM.deleteCustomPlan(planId, currentLottery.value.key, ::setStatus)
    }

    /** 启用/停用自定义计划 */
    fun toggleCustomPlan(plan: com.caifenxi.app.domain.model.CustomPlan, enabled: Boolean) {
        planVM.toggleCustomPlan(plan, enabled)
    }

    // ---- 数据导出 / 备份 / 恢复 ----

    /** 导出开奖历史 CSV(可指定彩种;null = 全部) */
    fun exportDrawsCsv(lotteryKey: String? = null) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val file = com.caifenxi.app.data.config.DataExportHelper.exportDrawsCsv(app, app.database, lotteryKey)
                exportedFile.value = file
                statusText.value = "已导出开奖历史:${file.name}"
            } catch (e: Exception) {
                statusText.value = "导出失败:${e.message}"
            }
        }
    }

    /** 导出下注历史 CSV */
    fun exportBetsCsv(lotteryKey: String? = null) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val file = com.caifenxi.app.data.config.DataExportHelper.exportBetsCsv(app, app.database, lotteryKey)
                exportedFile.value = file
                statusText.value = "已导出下注历史:${file.name}"
            } catch (e: Exception) {
                statusText.value = "导出失败:${e.message}"
            }
        }
    }

    /** 导出统计记录 CSV */
    fun exportStatsCsv(lotteryKey: String? = null) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val file = com.caifenxi.app.data.config.DataExportHelper.exportStatsCsv(app, app.database, lotteryKey)
                exportedFile.value = file
                statusText.value = "已导出统计记录:${file.name}"
            } catch (e: Exception) {
                statusText.value = "导出失败:${e.message}"
            }
        }
    }

    /** 导出共识记录 CSV */
    fun exportConsensusCsv(lotteryKey: String? = null) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val file = com.caifenxi.app.data.config.DataExportHelper.exportConsensusCsv(app, app.database, lotteryKey)
                exportedFile.value = file
                statusText.value = "已导出共识记录:${file.name}"
            } catch (e: Exception) {
                statusText.value = "导出失败:${e.message}"
            }
        }
    }

    /** 全量备份(Room 全表 + 用户偏好) */
    fun exportFullBackup() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val prefsJson = Json.encodeToString(prefs.value)
                val file = com.caifenxi.app.data.config.DataExportHelper.exportFullBackup(app, app.database, prefsJson)
                exportedFile.value = file
                statusText.value = "已备份全部数据:${file.name}"
            } catch (e: Exception) {
                statusText.value = "备份失败:${e.message}"
            }
        }
    }

    /** 从备份文件恢复(文件需在应用外部文件目录 export/ 下) */
    fun restoreFromBackup(fileName: String) {
        viewModelScope.launch(Dispatchers.IO) {
            if (restoring.value) return@launch
            restoring.value = true
            try {
                val f = java.io.File(com.caifenxi.app.data.config.DataExportHelper.exportDir(app), fileName)
                if (!f.exists()) {
                    statusText.value = "备份文件不存在:$fileName"
                    return@launch
                }
                val prefsJson = com.caifenxi.app.data.config.DataExportHelper.restoreFullBackup(app.database, f)
                // 恢复用户偏好
                if (prefsJson != null) {
                    val restored = Json { ignoreUnknownKeys = true; encodeDefaults = true }
                        .decodeFromString<com.caifenxi.app.domain.model.UserPrefs>(prefsJson)
                    prefs.value = restored
                    configStore.savePrefs(restored)
                }
                statusText.value = "恢复完成:${f.name}(重启应用后生效)"
            } catch (e: Exception) {
                statusText.value = "恢复失败:${e.message}"
            } finally {
                restoring.value = false
            }
        }
    }

    /** 恢复成功后刷新内存状态 */
    fun reloadAfterRestore() {
        loadData()
        refreshBetState()
        viewModelScope.launch { refreshConsensusStats() }
        loadCustomPlans()
    }

    // ---- 挂机 / 下注(委托 BetViewModel) ----

    /** 从 DB 刷新挂机策略、钱包与下注历史到 UI 状态 */
    fun refreshBetState() {
        betVM.refreshBetState(currentLottery.value.key, ::setStatus)
    }

    /** 重新读取挂机订单、钱包和统计,不删除任何数据。 */
    fun refreshBetOverview() {
        betVM.refreshBetOverview(currentLottery.value.key, ::setStatus)
    }

    /** 清零挂机总览:删除订单、恢复钱包,保留当前挂机策略。 */
    fun resetBetOverview() {
        betVM.resetBetOverview(currentLottery.value.key, ::setStatus)
    }

    /** 重新从现有订单生成收益曲线。 */
    fun refreshBetCurve() {
        betVM.refreshBetCurve(currentLottery.value.key)
    }

    /** 只重置曲线视图状态,不删除订单、钱包或挂机策略。 */
    fun resetBetCurve() {
        betVM.resetBetCurve()
    }

    /** 保存挂机策略 */
    fun saveBotConfig(config: BotConfig) {
        betVM.saveBotConfig(config, currentLottery.value.key, ::setStatus)
    }

    /** 初始化/重置虚拟账户资金 */
    fun setInitialBalance(amount: Double) {
        betVM.setInitialBalance(amount, currentLottery.value.key, ::setStatus)
    }

    /** 清空下注历史(不影响余额) */
    fun clearBetHistory() {
        betVM.clearBetHistory(currentLottery.value.key)
    }

    // ---- 内部:预测 / 计划 / 挂机链路 ----

    private suspend fun refreshStats() {
        val key = currentLottery.value.key
        statsSummary.value = statStore.summary(key)
        // 仅保留首屏缓存；HistoryScreen 的“预测记录”通过 loadPredictionPage 增量读取。
        statRecords.value = statStore.loadPage(key, 0, 100, "")
        predictionTotalCount.value = statStore.countPageSource(key, "")
    }

    private suspend fun rebuildAnalysis(rows: List<DrawRecord>) {
        analysis.value = withContext(Dispatchers.Default) {
            AnalysisEngine.build(rows, prefs.value.predictionWindow)
        }
        labRows.value = withContext(Dispatchers.Default) {
            AnalysisEngine.labTable(rows, prefs.value)
        }
    }

    /**
     * 预测 / 计划 / 共识 / 挂机 主链路。
     * 用 loadMutex 串行化:loadData、心跳、切算法、手动标记等并发入口
     * 排队执行,避免并发回测与并发 Room 写入导致卡死/崩溃。
     */
    /** 解析开奖时间毫秒;失败返回 null */
    private fun parseDrawTimeMs(drawTime: String): Long? {
        if (drawTime.isBlank()) return null
        return try {
            val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
            fmt.parse(drawTime.take(19).replace('T', ' '))?.time
        } catch (_: Exception) {
            null
        }
    }

    /**
     * 取真正最新一期:
     * 1) 优先开奖时间在 [FRESH_DAYS] 天内的记录(按时间再按期号)
     * 2) 全过期时仍按开奖时间最大(避免只按期号把停盘样例当最新)
     * 3) 无时间字段时退回期号数值
     */
    private fun trueLatest(rows: List<DrawRecord>): DrawRecord? {
        if (rows.isEmpty()) return null
        val now = System.currentTimeMillis()
        val withTime = rows.mapNotNull { r ->
            parseDrawTimeMs(r.drawTime)?.let { t -> r to t }
        }
        val fresh = withTime.filter { now - it.second <= FRESH_MS }
        val pool = when {
            fresh.isNotEmpty() -> fresh
            withTime.isNotEmpty() -> withTime
            else -> return rows.maxByOrNull { it.issue.toLongOrNull() ?: Long.MIN_VALUE }
        }
        return pool.maxWithOrNull(
            compareBy<Pair<DrawRecord, Long>> { it.second }
                .thenBy { it.first.issue.toLongOrNull() ?: Long.MIN_VALUE }
        )?.first
    }

    /** 最新一期是否已过期(>3 天无新开奖,常见于停盘彩种或仅本地旧缓存) */
    private fun isStaleLatest(draw: DrawRecord?): Boolean {
        val t = draw?.let { parseDrawTimeMs(it.drawTime) } ?: return true
        return System.currentTimeMillis() - t > FRESH_MS
    }

    /**
     * 合法下期:
     * - 必须严格大于最新期号
     * - API nextIssue 若更小/相等/空白则丢弃,改用最新期+1
     * - 过期开奖同样只用期号+1,不用可疑 nextIssue
     */
    private fun resolveTargetIssue(latest: DrawRecord): String {
        val suggested = PredictEngine.suggestNextIssue(latest.issue)
        if (isStaleLatest(latest)) {
            return suggested
        }
        val fromApi = latest.nextIssue?.takeIf { n ->
            n.isNotBlank() && n != latest.issue && isIssueStrictlyAfter(n, latest.issue)
        }
        // 双重校验:最终目标绝不能 ≤ 最新期
        val candidate = fromApi ?: suggested
        return if (isIssueStrictlyAfter(candidate, latest.issue)) candidate else suggested
    }

    private fun isIssueStrictlyAfter(a: String, b: String): Boolean {
        val na = a.toLongOrNull()
        val nb = b.toLongOrNull()
        if (na != null && nb != null) return na > nb
        return a > b
    }

    companion object {
        /** 超过此天数视为停盘/未同步,不应用作「当前目标」可信依据 */
        private const val FRESH_MS = 3L * 24 * 3600_000
    }

    /**
     * 检查下期计划共识/挂机是否就绪。
     * - 缺共识 → 整段预测+共识+挂机
     * - 有共识但无挂机待开单 → 仅补挂机(Service 抢先写共识时常见)
     */
    private suspend fun ensureNextPlanConsensus(rows: List<DrawRecord>) {
        if (rows.isEmpty()) return
        val last = trueLatest(rows) ?: return
        val target = resolveTargetIssue(last)
        if (target.isBlank() || target == "-") return
        // 目标必须严格晚于最新期;旧共识目标(如 34131503 < 最新 74389184)一律作废重算
        if (!isIssueStrictlyAfter(target, last.issue) && target != PredictEngine.suggestNextIssue(last.issue)) {
            RuntimeLog.warn("E302", "目标期 $target 不晚于最新 ${last.issue},强制按最新重算")
        }
        planVM.planTargetIssue.value = target
        nextIssueText.value = target
        val key = currentLottery.value.key
        val hasPending = try {
            consensusStore.loadAll(key).any { it.targetIssue == target && it.result == "待开" }
        } catch (_: Exception) {
            false
        }
        val uiEmpty = planVM.consensus.value.isEmpty() ||
            planVM.consensus.value.none { it.targetIssue == target }
        // 内存共识仍是旧目标期 → 必须整段重跑
        val memStale = planVM.consensus.value.isNotEmpty() &&
            planVM.consensus.value.none { it.targetIssue == target }
        if (!hasPending || uiEmpty || memStale) {
            if (memStale) {
                RuntimeLog.warn("E303", "丢弃旧共识目标,重算目标第$target 期")
            }
            runPredictAndPlans(rows)
            return
        }
        // 共识已在库中:仍须尝试挂机补单(防重在引擎内)
        try {
            var cons = planVM.consensus.value.filter { it.targetIssue == target }
            if (cons.isEmpty()) {
                val preds = planEngine.predictForNext(rows, prefs.value, target, last.issue)
                cons = planEngine.consensus(
                    key, target, preds,
                    comboTopN = prefs.value.comboPredCount.coerceIn(1, 4)
                )
                if (cons.isNotEmpty()) {
                    ConsensusEngine.recordPending(consensusStore, key, target, cons)
                    planVM.consensus.value = cons
                    planVM.planTargetIssue.value = target
                    planVM.currentPredictions.value = planEngine.getCurrentPredictions(target)
                }
            }
            cons = resolveConsensusForBet(key, target, cons)
            val recent = planEngine.getAllRecentPredictions(100)
            val predForBet = predictionForBot(rows, key, target, last.issue)
            val result = betVM.placeAutoBetsDetailed(
                lotteryKey = key,
                targetIssue = target,
                prediction = predForBet,
                planPredictions = recent,
                consensus = cons
            )
            if (result.placed > 0) {
                RuntimeLog.info("I210", "自动下注 ${result.placed}注 第$target · ${result.picksSummary}")
                statusText.value = "挂机已自动下注 ${result.placed} 注 · 第${target}期"
                betVM.refreshBetState(key, ::setStatus)
            } else if (result.reason.isNotBlank() && !result.reason.contains("未开启") &&
                !result.reason.contains("已有待开")
            ) {
                RuntimeLog.warn("E211", "自动下注未成交:${result.reason}")
                statusText.value = "挂机未下单[E211]:${result.reason}"
            }
        } catch (e: Exception) {
            RuntimeLog.exception("E212", "自动下注异常", e)
        }
    }

    /** 计划页进入「共识预测」时调用:强制按最新期对齐目标并刷新共识 */
    fun refreshPlanConsensusTab() {
        viewModelScope.launch {
            val rows = history.value
            if (rows.isEmpty()) {
                statusText.value = "请先在首页加载开奖"
                RuntimeLog.warn("E101", "刷新共识跳过:无开奖历史")
                return@launch
            }
            try {
                ensureNextPlanConsensus(rows)
                updateNextIssue(rows)
                val last = trueLatest(rows)
                if (last != null) {
                    planVM.planTargetIssue.value = resolveTargetIssue(last)
                }
                RuntimeLog.info("I101", "共识已刷新 · 目标 ${planVM.planTargetIssue.value}")
            } catch (e: Exception) {
                RuntimeLog.exception("E102", "刷新共识失败", e)
                statusText.value = "刷新共识失败[E102]:${e.message?.take(40)}"
            }
        }
    }

    /** 设置页:清空运行日志 */
    fun clearRuntimeLog() {
        RuntimeLog.clear()
    }

    /**
     * 挂机页手动「立即尝试下单」:不依赖心跳,用当前历史重跑一遍。
     */
    fun tryPlaceBotNow() {
        viewModelScope.launch {
            val rows = history.value
            if (rows.isEmpty()) {
                RuntimeLog.warn("E201", "立即下单失败:无历史")
                statusText.value = "请先加载开奖"
                return@launch
            }
            try {
                val last = trueLatest(rows) ?: rows.last()
                val target = resolveTargetIssue(last)
                val pred = predictionForBot(rows, currentLottery.value.key, target, last.issue)
                val recent = planEngine.getAllRecentPredictions(100)
                val cons = resolveConsensusForBet(
                    currentLottery.value.key, target, planVM.consensus.value
                )
                val result = betVM.placeAutoBetsDetailed(
                    lotteryKey = currentLottery.value.key,
                    targetIssue = target,
                    prediction = pred,
                    planPredictions = recent,
                    consensus = cons
                )
                if (result.placed > 0) {
                    RuntimeLog.info("I201", "立即下单成功 ${result.placed}注 第$target · ${result.picksSummary}")
                    statusText.value = "挂机已下单 ${result.placed} 注 · 第$target"
                    betVM.refreshBetState(currentLottery.value.key, ::setStatus)
                } else {
                    RuntimeLog.warn("E202", "立即下单未成交:${result.reason}")
                    statusText.value = "未下单[E202]:${result.reason}"
                }
            } catch (e: Exception) {
                RuntimeLog.exception("E203", "立即下单异常", e)
                statusText.value = "下单异常[E203]:${e.message?.take(40)}"
            }
        }
    }

    private suspend fun runPredictAndPlans(rows: List<DrawRecord>, forceAlgo: AlgoMode? = null) {
        if (rows.isEmpty()) return
        loadMutex.withLock {
            val cfg = currentLottery.value
            val mode = forceAlgo ?: currentAlgo.value
            val latestRow = trueLatest(rows) ?: rows.last()
            val cutoff = latestRow.issue
            val target = resolveTargetIssue(latestRow)

            var snap = withContext(Dispatchers.Default) {
                PredictEngine.predict(rows, cfg.type, prefs.value, target, cutoff, mode)
            }
            // 手动标记覆盖
            if (mode == AlgoMode.MANUAL) {
                val marks = manualStore.load(cfg.key)
                snap = snap.copy(
                    dx = marks["大小"]?.let { snap.dx?.copy(direction = it.direction, algo = "manual", score = 1.0, detail = "手动") } ?: snap.dx,
                    ds = marks["单双"]?.let { snap.ds?.copy(direction = it.direction, algo = "manual", score = 1.0, detail = "手动") } ?: snap.ds,
                    combo = marks["组合"]?.let { snap.combo?.copy(direction = it.direction, algo = "manual", score = 1.0, detail = "手动") } ?: snap.combo,
                    algoTag = "manual"
                )
            }
            // 预测冻结:同目标期已有待开/已结算则不覆盖展示(仍允许算法切换 force)
            val freeze = prefs.value.predFreeze
            val existing = if (freeze) {
                statStore.loadAll(cfg.key).any {
                    it.issue == target && it.algoId == mode.id && it.result != "待开"
                }
            } else false
            if (!existing || forceAlgo != null) {
                prediction.value = snap
            }

            if (mode != AlgoMode.COMPARE) {
                StatsEngine.recordPending(statStore, snap, mode.id)
                refreshStats()
            }

            algoCompare.value = withContext(Dispatchers.Default) {
                PredictEngine.compareAll(rows, prefs.value)
            }

            // 计划池:共享 planEngine,状态由 PlanViewModel 同步
            // (回测已异步化,这里只等轻量预测+共识,挂机可立即使用最新预测)
            val botConfigForPlans = try { app.database.betDao().getBotConfig(cfg.key) } catch (_: Exception) { null }
            val planPrefs = prefs.value.let { p ->
                val selected = when {
                    !p.cockpitPlanId.isBlank() -> listOf(p.cockpitPlanId)
                    botConfigForPlans?.sourceType == "nova" && !botConfigForPlans.sourceId.isBlank() -> listOf(botConfigForPlans.sourceId)
                    botConfigForPlans?.sourceType == "plan" && !botConfigForPlans.sourceId.isBlank() -> listOf(botConfigForPlans.sourceId)
                    else -> p.selectedPlanIds
                }
                p.copy(selectedPlanIds = selected)
            }
            val syncResult = planVM.syncAfterPredict(
                rows = rows,
                prefs = planPrefs,
                target = target,
                cutoff = cutoff,
                lotteryKey = cfg.key
            )
            val (_, _, recent) = syncResult
            try {
                com.caifenxi.app.service.publishFloatingSnapshot(
                    context = app,
                    lotteryName = cfg.name,
                    lotteryKey = cfg.key,
                    latestIssue = latestRow.issue,
                    latestDrawTime = latestRow.drawTime,
                    latestDx = latestRow.dx,
                    latestDs = latestRow.ds,
                    targetIssue = target,
                    consensus = syncResult.first,
                    predictions = recent
                )
            } catch (_: Exception) {
                // 悬浮窗快照失败不得影响主预测链路
            }
            try {
                if (prefs.value.floatingEnabled) {
                    // 已有后台监听时会自动刷新；这里仅保证快照已落盘。
                }
            } catch (_: Exception) {}
            // 共识优先用刚生成的;若空则从「共识预测」持久化待开记录回填(与计划子页同源)
            val consForBet = resolveConsensusForBet(cfg.key, target, syncResult.first)

            // 算法挂机:按挂机页所选算法单独重算,不依赖首页当前算法/冻结预测
            val predForBet = predictionForBot(rows, cfg.key, target, cutoff)
            val result = betVM.placeAutoBetsDetailed(
                lotteryKey = cfg.key,
                targetIssue = target,
                prediction = predForBet,
                planPredictions = recent,
                consensus = consForBet
            )
            if (result.placed > 0) {
                RuntimeLog.info("I220", "预测后下注 ${result.placed}注 第$target · ${result.picksSummary}")
                statusText.value = "挂机已自动下注 ${result.placed} 注 · 第${target}期 · ${result.picksSummary}"
            } else if (result.reason.isNotBlank() &&
                !result.reason.contains("未开启") &&
                !result.reason.contains("已有待开")
            ) {
                RuntimeLog.warn("E221", "预测后未下单:${result.reason}")
                statusText.value = "挂机未下单[E221]:${result.reason}"
            }
            refreshBetState()
        }
    }

    /**
     * 按挂机配置生成算法预测:
     * - 来源=算法时用挂机所选算法重算(避免首页算法/预测冻结导致空)
     * - 其它来源仍返回当前 prediction 作兜底
     */
    private suspend fun predictionForBot(
        rows: List<DrawRecord>,
        lotteryKey: String,
        target: String,
        cutoff: String
    ): PredictionSnapshot? {
        if (rows.isEmpty()) return prediction.value
        val bot = try {
            app.database.betDao().getBotConfig(lotteryKey)
        } catch (_: Exception) {
            null
        }
        val source = bot?.sourceType ?: "algo"
        if (source != "algo") return prediction.value
        val mode = AlgoMode.fromId(bot?.sourceId ?: currentAlgo.value.id)
        val cfg = currentLottery.value
        return try {
            withContext(Dispatchers.Default) {
                PredictEngine.predict(rows, cfg.type, prefs.value, target, cutoff, mode)
            }
        } catch (_: Exception) {
            prediction.value
        }
    }

    /** 挂机用共识:内存 → DB 待开,保证与计划页「共识预测」子页一致 */
    private suspend fun resolveConsensusForBet(
        lotteryKey: String,
        target: String,
        mem: List<com.caifenxi.app.domain.model.ModelConsensus>
    ): List<com.caifenxi.app.domain.model.ModelConsensus> {
        val matched = mem.filter { it.targetIssue == target }
        if (matched.isNotEmpty()) return matched
        val fromDb = planVM.loadPendingConsensusAsModels(lotteryKey, target)
        if (fromDb.isNotEmpty()) {
            planVM.consensus.value = fromDb
            planVM.planTargetIssue.value = target
        }
        return fromDb
    }

    private fun updateNextIssue(rows: List<DrawRecord>) {
        val last = trueLatest(rows)
        if (last == null) {
            nextIssueText.value = "-"
            planVM.planTargetIssue.value = "-"
            return
        }
        val target = resolveTargetIssue(last)
        nextIssueText.value = target
        // 计划/共识目标与首页下期强制同一来源,避免仍显示几个月前的旧共识期号
        planVM.planTargetIssue.value = target
    }

    private fun startCountdown() {
        countdownJob?.cancel()
        countdownJob = viewModelScope.launch {
            val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
            while (isActive) {
                val last = latest.value
                val t = last?.drawTime
                if (t != null) {
                    try {
                        // 按彩种配置的开奖间隔估算下期时间
                        val periodMs = currentLottery.value.periodMs
                        val base = fmt.parse(t.take(19).replace('T', ' '))
                        if (base != null) {
                            val next = base.time + periodMs
                            val left = next - System.currentTimeMillis()
                            countdownText.value = if (left <= 0) "即将开奖" else {
                                val s = (left / 1000).toInt()
                                "%02d:%02d".format(s / 60, s % 60)
                            }
                        }
                    } catch (_: Exception) {
                        countdownText.value = "--:--"
                    }
                }
                delay(1000)
            }
        }
    }

    private fun startAutoRefreshIfNeeded() {
        stopAutoRefresh()
        if (!prefs.value.autoRefresh) return
        refreshJob = viewModelScope.launch {
            while (isActive) {
                // 失败越多,间隔越长,减轻卡死与封禁风险
                val wait = when {
                    failStreak >= 5 -> 90_000L
                    failStreak >= 2 -> 45_000L
                    else -> 25_000L
                }
                delay(wait)
                // 正在整库加载或手动回测时跳过本轮心跳:
                // 避免与 loadData 并发触发预测/回测(曾导致并发读写崩溃与启动初期闪退)
                if (loadingGuard.get() || backtestRunning.value) continue
                try {
                    // 25s:覆盖增量回测(≤8s 持锁)等待 + 预测/共识/下注/分析余量
                    withTimeout(25_000) {
                        val one = app.apiClient.fetchLatest(currentLottery.value)
                        if (one != null) {
                            failStreak = 0
                            val curKey = currentLottery.value.key
                            // 彩种切换瞬间的保护:最新开奖与内存历史不属于同一彩种时
                            // 不合并(否则会把 A 彩种的开奖混进 B 彩种的历史),交给 loadData 处理
                            if (one.lotteryKey == curKey &&
                                (history.value.isEmpty() || history.value.lastOrNull()?.lotteryKey == curKey)
                            ) {
                                // 拒绝比本地最新还旧的「最新」污染界面
                                val localMax = trueLatest(history.value)
                                if (localMax != null && !isIssueStrictlyAfter(one.issue, localMax.issue) &&
                                    one.issue != localMax.issue
                                ) {
                                    statusText.value = "忽略过期开奖 ${one.issue}"
                                    updateNextIssue(history.value)
                                    ensureNextPlanConsensus(history.value)
                                    return@withTimeout
                                }
                                val exists = history.value.any { it.issue == one.issue }
                                if (!exists) {
                                    // 先落库,避免仅内存合并导致杀进程后丢期
                                    repo.cacheDraw(one)
                                    val merged = (history.value + one).distinctBy { it.issue }
                                        .sortedBy { it.issue.toLongOrNull() ?: 0L }
                                    history.value = merged
                                    latest.value = trueLatest(merged) ?: one
                                    StatsEngine.settleWithDraw(statStore, currentLottery.value.key, one)
                                    planEngine.settlePendingWithDraw(one, prefs.value.backtestParams)
                                    ConsensusEngine.settleWithDraw(consensusStore, currentLottery.value.key, one)
                                    betVM.settleWithDraw(currentLottery.value.key, one)
                                    planVM.refreshRuntimeState()
                                    betVM.refreshBetState(currentLottery.value.key, ::setStatus)
                                    refreshConsensusStats()
                                    refreshStats()
                                    runPredictAndPlans(merged)
                                    rebuildAnalysis(merged)
                                    updateNextIssue(merged)
                                    statusText.value = "新期 ${one.issue} · 已更新"
                                } else {
                                    // 期号已在本地(可能被前台服务抢先写入):仍须补生成下期计划/共识
                                    latest.value = one
                                    updateNextIssue(history.value)
                                    ensureNextPlanConsensus(history.value)
                                    statusText.value = "心跳正常 · ${one.issue}"
                                }
                            }
                        }
                    }
                } catch (_: Exception) {
                    failStreak++
                    // 失败时仍用本地真正最新期刷新下期显示,避免一直显示很早期号
                    if (history.value.isNotEmpty()) {
                        updateNextIssue(history.value)
                        try {
                            ensureNextPlanConsensus(history.value)
                        } catch (_: Exception) {
                        }
                    }
                    statusText.value = "后台同步失败($failStreak) · 缓存仍可用"
                }
            }
        }
    }

    private fun stopAutoRefresh() {
        refreshJob?.cancel()
        refreshJob = null
    }

    override fun onCleared() {
        stopAutoRefresh()
        countdownJob?.cancel()
        super.onCleared()
    }
}
