package com.caifenxi.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.caifenxi.app.domain.btc.BtcDirection
import com.caifenxi.app.ui.BtcQuantViewModel

/** Dense terminal-style decision center. Every displayed value comes from BtcQuantViewModel state. */
@Composable
fun DecisionCenterScreen(viewModel: BtcQuantViewModel) {
    val state by viewModel.state.collectAsState()
    val hs = state.hsSnapshot
    val bg = Color(0xFF08090C)
    val panel = Color(0xFF101217)
    val border = Color(0xFF20242D)
    val text = Color(0xFFE7EAF0)
    val muted = Color(0xFF737B88)
    val green = Color(0xFF00E676)
    val red = Color(0xFFFF5252)
    val cyan = Color(0xFF00E5FF)

    Column(Modifier.fillMaxSize().background(bg).verticalScroll(rememberScrollState())) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("DECISION CENTER", color = text, fontSize = 13.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                Text("MARKET → MODEL → EDGE → RISK → EXECUTION GATE", color = muted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
            }
            TerminalPill(hs?.dataMode ?: "OFFLINE", if (hs?.dataMode == "LIVE_ACCOUNT") green else cyan)
        }

        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(10.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            MiniMetric("DIRECTION", direction(hs?.primaryDirection), if (hs?.primaryDirection == BtcDirection.DOWN) red else green, panel, border)
            MiniMetric("P_HAT", hs?.primaryPhat?.let { "%.1f%%".format(it * 100) } ?: "—", cyan, panel, border)
            MiniMetric("EDGE", hs?.aggregateEdge?.let { "%+.2f%%".format(it * 100) } ?: "—", if ((hs?.aggregateEdge ?: 0.0) > 0) green else muted, panel, border)
            MiniMetric("OPPORTUNITY", hs?.opportunityScore?.let { "%.0f%%".format(it * 100) } ?: "—", cyan, panel, border)
            MiniMetric("QUALITY", hs?.dataQualityScore?.let { "%.0f%%".format(it * 100) } ?: "—", if ((hs?.dataQualityScore ?: 0.0) >= .8) green else red, panel, border)
        }

        TerminalCard("MARKET STATE", panel, border) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Metric("REGIME", state.consensus?.regime?.name ?: "WAIT", text, muted)
                Metric("TREND", state.consensus?.trendScore?.let { "%.2f".format(it) } ?: "—", text, muted)
                Metric("VOL", state.consensus?.volatility?.let { "%.3f%%".format(it * 100) } ?: "—", text, muted)
                Metric("RISK", state.consensus?.riskScore?.let { "%.2f".format(it) } ?: "—", if ((state.consensus?.riskScore ?: 0.0) >= .7) red else text, muted)
            }
        }

        TerminalCard("TIMEFRAME MATRIX", panel, border) {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                hs?.tf5m?.let { TimeframeCard(it, "5m", green, red, text, muted, border) }
                hs?.tf15m?.let { TimeframeCard(it, "15m", green, red, text, muted, border) }
                hs?.tf1h?.let { TimeframeCard(it, "1h", green, red, text, muted, border) }
            } ?: Text("等待实时数据", color = muted, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
        }

        TerminalCard("MODEL LAB · WALK-FORWARD / REGIME", panel, border) {
            val reports = hs?.modelLabByTimeframe.orEmpty()
            listOf("5m", "15m", "1h").forEach { tf ->
                val report = reports[tf]
                Text(tf, color = cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                if (report == null || report.models.isEmpty()) {
                    Text("holdout insufficient", color = muted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                } else {
                    report.models.sortedByDescending { it.hitRate }.forEach { m ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(m.modelId, color = text, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                            Text("n=${m.samples}", color = muted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                            Text("hit %.1f%%".format(m.hitRate * 100), color = if (m.hitRate >= .55) green else muted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.padding(start = 10.dp))
                            Text("brier %.3f".format(m.brier), color = muted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.padding(start = 10.dp))
                        }
                    }
                }
                Spacer(Modifier.height(4.dp))
            }
        }

        TerminalCard("MODEL LIFECYCLE", panel, border) {
            hs?.modelLifecycle?.states?.forEach { m ->
                Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(m.modelId, color = text, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                    Text(m.status.name, color = lifecycleColor(m.status.name, green, red, cyan, muted), fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    Text("score %.0f%%".format(m.score * 100), color = muted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.padding(start = 10.dp))
                    Text("drift %.2f%%".format(m.drift * 100), color = muted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.padding(start = 10.dp))
                }
            } ?: Text("暂无生命周期记录", color = muted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
        }

        TerminalCard("TRANSACTION ATTRIBUTION", panel, border) {
            val a = hs?.attribution
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                Metric("SAMPLES", "${a?.samples ?: 0}", text, muted)
                Metric("HIT", "%.1f%%".format((a?.hitRate ?: 0.0) * 100), green, muted)
                Metric("EDGE CAP", "%.1f%%".format((a?.edgeCaptureRate ?: 0.0) * 100), cyan, muted)
                Metric("BIAS", "%.2f".format(a?.directionBias ?: 0.0), text, muted)
            }
            Text("return %.3f%% · MFE %.3f%% · MAE %.3f%%".format(a?.avgReturnPct ?: 0.0, a?.avgMfePct ?: 0.0, a?.avgMaePct ?: 0.0), color = muted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.padding(top = 7.dp))
        }

        TerminalCard("SNAPSHOT REPLAY", panel, border) {
            Text("${hs?.snapshotHistory?.size ?: 0} persisted snapshots · current ${hs?.snapshotId?.take(20) ?: "—"}", color = muted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
            hs?.snapshotHistory?.takeLast(8)?.reversed()?.forEach { r ->
                Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(r.timeframe, color = cyan, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                    Text(r.direction, color = text, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                    Text("p %.1f%%".format(r.pHat * 100), color = text, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                    Text("edge %+.2f%%".format(r.edge * 100), color = if (r.edge > 0) green else muted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                    Text(r.id.take(12), color = muted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                }
            }
        }
        Spacer(Modifier.height(20.dp))
    }
}

@Composable
private fun TerminalCard(title: String, bg: Color, border: Color, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 4.dp).background(bg, RoundedCornerShape(8.dp)).border(1.dp, border, RoundedCornerShape(8.dp)).padding(10.dp)) {
        Text(title, color = Color(0xFF737B88), fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, modifier = Modifier.padding(bottom = 7.dp))
        content()
    }
}

@Composable
private fun MiniMetric(label: String, value: String, color: Color, bg: Color, border: Color) {
    Column(Modifier.width(120.dp).background(bg, RoundedCornerShape(7.dp)).border(1.dp, border, RoundedCornerShape(7.dp)).padding(9.dp)) {
        Text(label, color = Color(0xFF737B88), fontSize = 8.sp, fontFamily = FontFamily.Monospace)
        Text(value, color = color, fontSize = 15.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
    }
}

@Composable
private fun TimeframeCard(tf: com.caifenxi.app.domain.btc.hs.TimeframePhat, label: String, green: Color, red: Color, text: Color, muted: Color, border: Color) {
    Column(Modifier.width(180.dp).border(1.dp, border, RoundedCornerShape(7.dp)).padding(8.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = text, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            Text(tf.action, color = if (tf.action.startsWith("BUY")) green else muted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
        }
        Text("p_up %.1f%%".format(tf.pHat * 100), color = if (tf.pHat >= .5) green else red, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
        Text("edge %+.2f%% · ask %.3f · spread %.3f".format(tf.netEdge * 100, tf.bestAsk ?: 0.0, tf.spread), color = muted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
        Text("Kelly %.2f · liquidity %.0f%%".format(tf.halfKelly, tf.liquidityScore * 100), color = muted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
    }
}

@Composable
private fun Metric(label: String, value: String, color: Color, muted: Color) {
    Column(Modifier.width(90.dp)) {
        Text(label, color = muted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
        Text(value, color = color, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
    }
}

@Composable
private fun TerminalPill(text: String, color: Color) {
    Surface(shape = RoundedCornerShape(50), color = color.copy(alpha = .10f), border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = .45f))) {
        Text(text, color = color, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp))
    }
}

private fun lifecycleColor(status: String, green: Color, red: Color, cyan: Color, muted: Color) = when (status) {
    "ACTIVE" -> green
    "RETIRED" -> red
    "CANDIDATE" -> cyan
    else -> muted
}

private fun direction(v: BtcDirection?): String = when (v) {
    BtcDirection.UP -> "LONG"
    BtcDirection.DOWN -> "SHORT"
    BtcDirection.FLAT, null -> "WAIT"
}
