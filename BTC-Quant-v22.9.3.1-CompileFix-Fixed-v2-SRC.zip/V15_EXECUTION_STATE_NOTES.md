# v15.0.0 Execution State

- Exchange position remains authoritative.
- Added exchange open-order query for Binance Futures.
- Added FuturesOrderReconciler to classify protection as PROTECTED/PARTIAL/ORPHAN/NO_POSITION/ERROR.
- UI now shows SL/TP/Trailing counts and reconciliation state.
- Open-order sync failures are no longer converted into an empty order list.
- PAPER broker returns an empty open-order list because its conditional orders are simulation-only.
- Version 15.0.0-ExecutionState.
