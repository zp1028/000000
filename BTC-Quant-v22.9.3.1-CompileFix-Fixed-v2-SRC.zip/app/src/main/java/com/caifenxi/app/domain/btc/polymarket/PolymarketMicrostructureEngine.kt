package com.caifenxi.app.domain.btc.polymarket

import kotlin.math.abs

/** Converts a full CLOB book into execution-aware microstructure features. */
object PolymarketMicrostructureEngine {
    data class Snapshot(
        val mid: Double?, val spread: Double, val microPrice: Double?, val imbalance: Double,
        val bidDepth: Double, val askDepth: Double, val executableVwap: Double?, val bookSlope: Double,
        val pressure: Double
    )

    fun calculate(book: PolyOrderBook, depthLevels: Int = 10, targetSize: Double = 0.0): Snapshot {
        val bids = book.bids.sortedByDescending { it.price }.take(depthLevels)
        val asks = book.asks.sortedBy { it.price }.take(depthLevels)
        val bidDepth = bids.sumOf { it.size }
        val askDepth = asks.sumOf { it.size }
        val imbalance = ((bidDepth - askDepth) / (bidDepth + askDepth).coerceAtLeast(1e-9)).coerceIn(-1.0, 1.0)
        val bid = bids.firstOrNull(); val ask = asks.firstOrNull()
        val micro = if (bid != null && ask != null) {
            val total = (bid.size + ask.size).coerceAtLeast(1e-9)
            (ask.price * bid.size + bid.price * ask.size) / total
        } else book.mid
        val vwap = if (targetSize > 0.0) executableVwap(asks, targetSize) else null
        val bidSlope = slope(bids.map { it.price to it.size })
        val askSlope = slope(asks.map { it.price to it.size })
        val pressure = (imbalance * 0.65 + (bidSlope - askSlope).coerceIn(-1.0, 1.0) * 0.20 + ((micro ?: book.mid ?: 0.5) - (book.mid ?: 0.5)) * 0.15).coerceIn(-1.0, 1.0)
        return Snapshot(book.mid, book.spread, micro, imbalance, bidDepth, askDepth, vwap, (bidSlope - askSlope).coerceIn(-1.0, 1.0), pressure)
    }

    private fun executableVwap(levels: List<PolyBookLevel>, size: Double): Double? {
        var remaining = size; var cost = 0.0; var filled = 0.0
        for (l in levels) {
            if (remaining <= 0) break
            val take = remaining.coerceAtMost(l.size); cost += take * l.price; filled += take; remaining -= take
        }
        return if (filled > 0 && remaining <= 1e-9) cost / filled else null
    }

    private fun slope(levels: List<Pair<Double, Double>>): Double {
        if (levels.size < 2) return 0.0
        val base = levels.first().second.coerceAtLeast(1e-9)
        val last = levels.last().second
        return ((last - base) / base).coerceIn(-1.0, 1.0)
    }
}
