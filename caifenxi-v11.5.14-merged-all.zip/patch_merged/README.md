# 彩分析 合并补丁 V11.5.14-merged

包含此前全部改动，按工程路径直接覆盖即可。

## 包含内容

### A. 共识与排行（原 11.5.12）
- 共识参与上限 1～500 + 快捷档位
- 共识预测记录分页
- 排行榜计划点开折叠 + 历史分页

### B. P0 基础设施（原 11.5.13）
- 预测来源快照（algorithmId / paramSummary / rank / sourceType / version）
- 共识版本锁定（挂机启停联动）
- 数据异常检测横幅
- 共识强度 / 分歧文案

### C. 无障碍三项（原 11.5.14）
- ① 大小单双全屏框选点击区域
- ② 输入框全屏框选识别区域（同交互）
- ③ 数字输入：原始/倍投 + 追投 1 期复原
- 执行顺序可配置；结算后记录上期对错

## 覆盖文件清单

```
app/src/main/java/com/caifenxi/app/domain/model/LotteryModels.kt
app/src/main/java/com/caifenxi/app/domain/model/PlanModels.kt
app/src/main/java/com/caifenxi/app/domain/plan/PlanEngine.kt
app/src/main/java/com/caifenxi/app/domain/plan/ConsensusVersionLock.kt   【新建】
app/src/main/java/com/caifenxi/app/domain/engine/ConsensusEngine.kt
app/src/main/java/com/caifenxi/app/domain/engine/DataAnomalyDetector.kt 【新建】
app/src/main/java/com/caifenxi/app/ui/PlanViewModel.kt
app/src/main/java/com/caifenxi/app/ui/MainViewModel.kt
app/src/main/java/com/caifenxi/app/ui/BetViewModel.kt
app/src/main/java/com/caifenxi/app/ui/ClickRegionPickActivity.kt
app/src/main/java/com/caifenxi/app/ui/screens/NovaPlanScreen.kt
app/src/main/java/com/caifenxi/app/ui/screens/SettingsScreen.kt
app/src/main/java/com/caifenxi/app/service/AutoBetAccessibilityService.kt
app/src/main/java/com/caifenxi/app/service/AutoBetController.kt
```

## 使用方法

将 `nova/app/src/main/java/...` 下文件按相对路径覆盖到工程对应位置，**新建**两个文件需一并放入：

- `domain/plan/ConsensusVersionLock.kt`
- `domain/engine/DataAnomalyDetector.kt`

然后重新构建 APK。无需改 AndroidManifest。
