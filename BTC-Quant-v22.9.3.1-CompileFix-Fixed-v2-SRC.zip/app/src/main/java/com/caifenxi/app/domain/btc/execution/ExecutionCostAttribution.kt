package com.caifenxi.app.domain.btc.execution

/** Post-trade cost attribution; percentages are expressed in price-relative terms. */
object ExecutionCostAttribution {
    data class Input(
        val referencePrice: Double,
        val executedPrice: Double,
        val side: String,
        val requestedNotional: Double,
        val filledNotional: Double,
        val fee: Double = 0.0,
        val expectedPrice: Double? = null,
        val latencyMs: Long = 0L
    )
    data class Breakdown(
        val spread: Double,
        val slippage: Double,
        val marketImpact: Double,
        val fee: Double,
        val latency: Double,
        val total: Double,
        val fillRatio: Double
    )

    fun attribute(x: Input): Breakdown {
        val r = x.referencePrice.coerceAtLeast(1e-12)
        val direction = if (x.side.equals("BUY", true)) 1.0 else -1.0
        val raw = ((x.executedPrice - r) / r) * direction
        val expected = x.expectedPrice?.let { ((x.executedPrice - it.coerceAtLeast(1e-12)) / it) * direction } ?: 0.0
        val spread = (raw * 0.5).coerceAtLeast(0.0)
        val slippage = ((raw - spread).coerceAtLeast(0.0) * 0.55).coerceAtLeast(0.0)
        val impact = (raw - spread - slippage).coerceAtLeast(0.0) + expected.coerceAtLeast(0.0) * 0.25
        val feeRate = if (x.filledNotional > 0) (x.fee / x.filledNotional).coerceAtLeast(0.0) else 0.0
        val latency = (x.latencyMs.coerceAtLeast(0L) / 1000.0 * 0.0001).coerceAtMost(0.02)
        val total = (spread + slippage + impact + feeRate + latency).coerceAtLeast(0.0)
        return Breakdown(spread, slippage, impact, feeRate, latency, total, (x.filledNotional / x.requestedNotional.coerceAtLeast(1e-12)).coerceIn(0.0, 1.0))
    }
}
