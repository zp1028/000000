package com.caifenxi.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.lifecycle.viewmodel.compose.viewModel
import com.caifenxi.app.ui.ExecutorViewModel
import com.caifenxi.app.ui.components.GlobalCard
import com.caifenxi.app.ui.theme.CaiTokens
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun ExecutorLogScreen(executorViewModel: ExecutorViewModel = viewModel()) {
    val logs by executorViewModel.executorLogs.collectAsState()
    
    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = CaiTokens.ScreenHPadding, vertical = CaiTokens.S16)
    ) {
        Text("执行日志", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(CaiTokens.S16))
        
        // 统计信息
        GlobalCard {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text("总执行次数", fontWeight = FontWeight.Bold)
                    Text(logs.size.toString(), fontSize = 24.sp)
                }
                Column {
                    Text("成功次数", fontWeight = FontWeight.Bold)
                    Text(logs.count { it.success }.toString(), color = MaterialTheme.colorScheme.secondary)
                }
                Column {
                    Text("失败次数", fontWeight = FontWeight.Bold)
                    Text(logs.count { !it.success }.toString(), color = MaterialTheme.colorScheme.error)
                }
                Column {
                    Text("成功率", fontWeight = FontWeight.Bold)
                    val successRate = if (logs.isNotEmpty()) (logs.count { it.success } * 100 / logs.size) else 0
                    Text("$successRate%", color = MaterialTheme.colorScheme.secondary)
                }
            }
        }
        
        Spacer(Modifier.height(CaiTokens.S16))
        
        // 日志列表
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(CaiTokens.S8)
        ) {
            items(logs.reversed()) { log ->
                LogItem(log)
            }
        }
    }
}

@Composable
private fun LogItem(log: ExecutorViewModel.LogEntry) {
    val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
    val timeStr = dateFormat.format(Date(log.timestamp))
    
    GlobalCard {
        Column(Modifier.fillMaxWidth().padding(CaiTokens.S12)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(
                    log.taskId,
                    fontWeight = FontWeight.Bold,
                    color = if (log.success) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.error
                )
                Text(timeStr, style = MaterialTheme.typography.labelMedium)
            }
            Spacer(Modifier.height(CaiTokens.S4))
            Text(log.message, style = MaterialTheme.typography.bodyMedium)
            if (log.details.isNotEmpty()) {
                Spacer(Modifier.height(CaiTokens.S4))
                Text(
                    log.details,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}        )
            }
        }
    }
}

// 日志条目数据类
data class LogEntry(
    val taskId: String,
    val message: String,
    val details: String,
    val success: Boolean,
    val timestamp: Long
)