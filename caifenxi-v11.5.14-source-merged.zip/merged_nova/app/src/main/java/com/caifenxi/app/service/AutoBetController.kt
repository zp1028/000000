package com.caifenxi.app.service

import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.text.TextUtils
import com.caifenxi.app.CaiFenXiApplication
import com.caifenxi.app.domain.model.UserPrefs
import com.caifenxi.app.util.RuntimeLog

/**
 * 真实自动点击控制器。
 * - 读取内部预测（与悬浮窗同源逻辑）
 * - 按期号去重，避免同一期重复点击
 * - 通过无障碍服务执行点击
 * - 仅在点击成功后写入去重标记，失败可重试
 */
object AutoBetController {

    private const val PREFS = "auto_bet_runtime"
    private const val KEY_LAST_ISSUE = "last_bet_issue"
    private const val KEY_LAST_LOTTERY = "last_bet_lottery"

    /** 是否已开启系统无障碍服务 */
    fun isAccessibilityEnabled(context: Context): Boolean {
        val expected = context.packageName + "/" + AutoBetAccessibilityService::class.java.canonicalName
        val enabled = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val splitter = TextUtils.SimpleStringSplitter(':')
        splitter.setString(enabled)
        while (splitter.hasNext()) {
            val item = splitter.next()
            if (item.equals(expected, ignoreCase = true)) return true
            // 部分 ROM 用简写组件名
            if (item.contains(context.packageName, ignoreCase = true) &&
                item.contains("AutoBetAccessibilityService", ignoreCase = true)
            ) {
                return true
            }
        }
        return false
    }

    fun openAccessibilitySettings(context: Context) {
        try {
            context.startActivity(
                Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (_: Exception) {
            try {
                context.startActivity(
                    Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (_: Exception) {
            }
        }
    }

    /**
     * 预测 READY 时调用。根据 UserPrefs 决定是否真实点击第三方页面。
     */
    fun onPredictionReady(context: Context, snap: FloatingSnapshot, force: Boolean = false) {
        val app = try {
            CaiFenXiApplication.instance
        } catch (_: Exception) {
            return
        }
        val prefs = app.configStore.loadPrefs()
        // force=true：悬浮窗「开始」手动触发，不依赖自动开关
        if (!force && !prefs.autoClickEnabled) return
        if (!force && snap.status != "READY") return
        if (force && snap.status != "READY" && snap.status != "CALCULATING") {
            // 手动时允许用最后一份快照
        } else if (!force && snap.status != "READY") return
        if (snap.targetIssue.isBlank() || snap.targetIssue == "-") return

        // 期号 + 彩种 去重（仅成功后写入，见 markDone）
        val sp = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val lastIssue = sp.getString(KEY_LAST_ISSUE, "")
        val lastLottery = sp.getString(KEY_LAST_LOTTERY, "")
        if (snap.targetIssue == lastIssue && snap.lotteryKey == lastLottery) {
            RuntimeLog.info("AutoBet", "期号 ${snap.targetIssue} 已成功点击过，跳过")
            return
        }

        if (!isAccessibilityEnabled(context)) {
            RuntimeLog.warn("AutoBet", "无障碍服务未开启，跳过自动点击（请到系统设置开启「彩析」）")
            return
        }
        val service = AutoBetAccessibilityService.instance
        if (service == null) {
            RuntimeLog.warn("AutoBet", "无障碍服务实例为空：开关已开但进程未连上，请关闭再打开一次服务")
            return
        }

        val (dx, ds) = resolvePrediction(prefs, snap)
        if (dx.isNullOrBlank() && ds.isNullOrBlank()) {
            RuntimeLog.info("AutoBet", "无有效大小/单双预测，跳过")
            return
        }

        val doDx = prefs.autoClickDx && !dx.isNullOrBlank()
        val doDs = prefs.autoClickDs && !ds.isNullOrBlank()
        if (!doDx && !doDs) return

        val amountText = resolveAmountText(context, prefs)
        RuntimeLog.info(
            "AutoBet",
            "提交自动执行 期号=${snap.targetIssue} 大小=${if (doDx) dx else "-"} 单双=${if (doDs) ds else "-"} 金额=${amountText ?: "-"}"
        )

        service.performBet(
            dx = if (doDx) dx else null,
            ds = if (doDs) ds else null,
            clickDelayMs = prefs.autoClickDelayMs.coerceIn(100L, 3000L),
            amountText = amountText
        )

        // 先写入去重，避免 READY 回调风暴；若用户需要重试可用「立即尝试一次」
        markDone(context, snap.targetIssue, snap.lotteryKey)
    }

    /**
     * 数字输入金额：
     * - 上一期对 / 未知 → 原始金额
     * - 上一期错且尚未追投 → 单次倍投金额，并标记已追投 1 期
     * - 已追投过 → 恢复原始金额并清除追投标记
     */
    private fun resolveAmountText(context: Context, prefs: UserPrefs): String? {
        if (!prefs.autoInputEnabled) return null
        val sp = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val lastHit = sp.getString(KEY_LAST_HIT, null)
        val chaseUsed = sp.getBoolean(KEY_CHASE_USED, false)
        val base = prefs.autoInputBaseAmount
        val mult = prefs.autoInputMultAmount
        return when {
            lastHit == "0" && !chaseUsed -> {
                sp.edit().putBoolean(KEY_CHASE_USED, true).apply()
                formatAmount(mult)
            }
            else -> {
                if (chaseUsed) sp.edit().putBoolean(KEY_CHASE_USED, false).apply()
                formatAmount(base)
            }
        }
    }

    private fun formatAmount(v: Double): String {
        return if (v == v.toLong().toDouble()) v.toLong().toString() else "%.2f".format(v)
    }

    /** 外部在结算后调用：记录上一期对错，供下一期金额策略使用 */
    fun recordLastHit(context: Context, hit: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_LAST_HIT, if (hit) "1" else "0")
            .apply()
        RuntimeLog.info("AutoBet", "记录上期结果 hit=$hit")
    }

    fun clearChaseState(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_CHASE_USED, false)
            .apply()
    }

    private fun markDone(context: Context, issue: String, lotteryKey: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_LAST_ISSUE, issue)
            .putString(KEY_LAST_LOTTERY, lotteryKey)
            .apply()
    }

    /**
     * 与悬浮窗完全一致的预测解析逻辑。
     */
    fun resolvePrediction(prefs: UserPrefs, snap: FloatingSnapshot): Pair<String?, String?> {
        val selectedDxId = prefs.floatingDxPlanId.ifBlank { prefs.floatingPlanId }
        val selectedDsId = prefs.floatingDsPlanId.ifBlank { prefs.floatingPlanId }
        val dxPlan = snap.plans.firstOrNull { it.planId == selectedDxId && !it.dx.isNullOrBlank() }
        val dsPlan = snap.plans.firstOrNull { it.planId == selectedDsId && !it.ds.isNullOrBlank() }

        val consensusDx = snap.consensusDx?.takeIf { it == "大" || it == "小" }
        val consensusDs = snap.consensusDs?.takeIf { it == "单" || it == "双" }
        val algoDx = snap.algoDx?.takeIf { it == "大" || it == "小" }
        val algoDs = snap.algoDs?.takeIf { it == "单" || it == "双" }

        var dx: String? = null
        var ds: String? = null

        when (prefs.floatingSource) {
            "plan" -> {
                dx = dxPlan?.dx?.split("/", "、", ",")?.firstOrNull { it == "大" || it == "小" }
                ds = dsPlan?.ds?.split("/", "、", ",")?.firstOrNull { it == "单" || it == "双" }
                if (dx == null) dx = consensusDx ?: algoDx
                if (ds == null) ds = consensusDs ?: algoDs
            }
            "algo" -> {
                dx = algoDx ?: consensusDx
                ds = algoDs ?: consensusDs
            }
            else -> {
                dx = consensusDx ?: algoDx
                ds = consensusDs ?: algoDs
            }
        }
        return dx to ds
    }

    /** 手动立即尝试一次（设置页按钮用） */
    fun tryNow(context: Context) {
        val snap = FloatingOverlayStore.loadLastReady(context)
            ?: FloatingOverlayStore.load(context)
        if (snap == null) {
            RuntimeLog.warn("AutoBet", "当前无可用预测快照")
            return
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .remove(KEY_LAST_ISSUE)
            .remove(KEY_LAST_LOTTERY)
            .apply()
        onPredictionReady(context, snap.copy(status = "READY"), force = true)
    }
}
