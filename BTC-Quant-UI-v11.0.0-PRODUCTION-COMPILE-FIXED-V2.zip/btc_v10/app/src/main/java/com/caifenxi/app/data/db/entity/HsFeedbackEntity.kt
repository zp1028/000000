package com.caifenxi.app.data.db.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "hs_feedback",
    indices = [Index(value = ["timeframe", "at"])]
)
data class HsFeedbackEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timeframe: String,
    val predictedUp: Double,
    val actualUp: Boolean,
    val at: Long
)

@Entity(
    tableName = "hs_shadow_open",
    indices = [Index(value = ["timeframe", "barId"])]
)
data class HsShadowOpenEntity(
    @PrimaryKey val id: String,
    val timeframe: String,
    val barId: Long,
    val entry: Double,
    val direction: String,
    val probability: Double,
    val modelVersion: String
)

@Entity(
    tableName = "hs_shadow_closed",
    indices = [Index(value = ["timeframe", "closedAt"])]
)
data class HsShadowClosedEntity(
    @PrimaryKey val id: String,
    val timeframe: String,
    val direction: String,
    val probability: Double,
    val outcome: Boolean,
    val returnPct: Double,
    val mfePct: Double,
    val maePct: Double,
    val modelVersion: String,
    val closedAt: Long
)
