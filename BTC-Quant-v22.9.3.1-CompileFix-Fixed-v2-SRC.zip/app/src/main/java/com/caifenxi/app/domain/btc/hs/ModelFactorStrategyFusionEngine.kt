package com.caifenxi.app.domain.btc.hs

import com.caifenxi.app.domain.btc.BtcDirection
import com.caifenxi.app.domain.btc.BtcPlanSignal
import com.caifenxi.app.domain.btc.MarketRegime
import com.caifenxi.app.domain.btc.factor.QuantFactorEngine
import kotlin.math.abs

/**
 * v18.1: runtime fusion of model, factor and strategy evidence.
 * This is a decision layer only: it never places orders.
 *
 * The three sources are deliberately kept separate until this point so that
 * disagreement is measurable and one source cannot silently overwrite another.
 */
object ModelFactorStrategyFusionEngine {
    data class Result(
        val probability: Double,
        val direction: BtcDirection,
        val confidence: Double,
        val modelComponent: Double,
        val factorComponent: Double,
        val strategyComponent: Double,
        val disagreement: Double,
        val regimeMultiplier: Double,
        val reason: String
    )

    fun fuse(
        modelProbability: Double,
        modelConfidence: Double,
        modelDisagreement: Double,
        factor: QuantFactorEngine.Snapshot?,
        factorWeights: Map<String, Double> = emptyMap(),
        strategyProbability: Double,
        strategyConfidence: Double,
        regime: MarketRegime,
        modelWeight: Double = 0.42,
        factorWeight: Double = 0.30,
        strategyWeight: Double = 0.28
    ): Result {
        val weightSum = (modelWeight + factorWeight + strategyWeight).coerceAtLeast(1e-9)
        val mw = modelWeight / weightSum
        val fw = factorWeight / weightSum
        val sw = strategyWeight / weightSum
        val mp = modelProbability.coerceIn(0.03, 0.97)
        val modelSigned = ((mp - 0.5) * 2.0).coerceIn(-1.0, 1.0) * modelConfidence.coerceIn(0.0, 1.0)
        val strategySigned = ((strategyProbability.coerceIn(0.03, 0.97) - 0.5) * 2.0) * strategyConfidence.coerceIn(0.0, 1.0)

        val factorSigned = factor?.let { snapshot ->
            val active = snapshot.factors.map { f ->
                val quality = factorWeights[f.id]?.coerceIn(0.0, 1.0) ?: 0.50
                f.normalized.coerceIn(-1.0, 1.0) * (0.35 + 0.65 * quality)
            }
            val denom = active.sumOf { abs(it) }.coerceAtLeast(1e-9)
            (active.sum() / denom).coerceIn(-1.0, 1.0) * snapshot.confidence.coerceIn(0.0, 1.0)
        } ?: 0.0

        val regimeMultiplier = when (regime) {
            MarketRegime.TREND_UP, MarketRegime.TREND_DOWN -> 1.05
            MarketRegime.BREAKOUT -> 1.08
            MarketRegime.RANGE -> 0.86
            MarketRegime.HIGH_VOLATILITY -> 0.62
        }
        val disagreement = (
            abs(modelSigned - factorSigned) * 0.45 +
                abs(modelSigned - strategySigned) * 0.30 +
                abs(factorSigned - strategySigned) * 0.25 +
                modelDisagreement * 0.60
            ).coerceIn(0.0, 1.0)
        val agreementPenalty = (1.0 - disagreement * 0.45).coerceIn(0.50, 1.0)
        val raw = (modelSigned * mw + factorSigned * fw + strategySigned * sw) * regimeMultiplier * agreementPenalty
        val probability = (0.5 + raw * 0.5).coerceIn(0.03, 0.97)
        val direction = when {
            probability >= 0.53 -> BtcDirection.UP
            probability <= 0.47 -> BtcDirection.DOWN
            else -> BtcDirection.FLAT
        }
        val confidence = (abs(raw) * 0.70 + (1.0 - disagreement) * 0.30).coerceIn(0.0, 1.0)
        val reason = "model=${"%.2f".format(modelSigned)} factor=${"%.2f".format(factorSigned)} strategy=${"%.2f".format(strategySigned)} regime=${regime.name} disagreement=${"%.2f".format(disagreement)}"
        return Result(probability, direction, confidence, modelSigned, factorSigned, strategySigned, disagreement, regimeMultiplier, reason)
    }
}
