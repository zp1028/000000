package com.caifenxi.app.ui

import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.caifenxi.app.CaiFenXiApplication
import com.caifenxi.app.domain.engine.AnalysisEngine
import com.caifenxi.app.domain.engine.ConsensusEngine
import com.caifenxi.app.domain.engine.PredictEngine
import com.caifenxi.app.domain.model.ConsensusRecord
import com.caifenxi.app.domain.model.ConsensusStats
import com.caifenxi.app.domain.model.CustomPlan
import com.caifenxi.app.domain.model.DrawRecord
import com.caifenxi.app.domain.model.LabRow
import com.caifenxi.app.domain.model.ModelConsensus
import com.caifenxi.app.domain.model.PlanDefinition
import com.caifenxi.app.domain.model.PlanPredictionRecord
import com.caifenxi.app.domain.model.PlanRuntime
import com.caifenxi.app.domain.model.UserPrefs
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * 计划大厅 ViewModel。
 * 从 MainViewModel 拆出:负责计划池/回测/共识/自定义计划与实验室排行。
 * 与 MainViewModel 共享 Application 级 planEngine(同一份战绩状态)。
 */
class PlanViewModel : ViewModel() {

    private val app get() = CaiFenXiApplication.instance
    private val engine get() = app.planEngine
    private val consensusStore get() = app.consensusStore

    val planRows = mutableStateOf<List<Pair<PlanDefinition, PlanRuntime>>>(emptyList())
    val backtestRunning = mutableStateOf(false)
    val labRows = mutableStateOf<List<LabRow>>(emptyList())
    val planHistory = mutableStateOf<List<PlanPredictionRecord>>(emptyList())
    val selectedPlanHistory = mutableStateOf<List<PlanPredictionRecord>>(emptyList())
    val consensus = mutableStateOf<List<ModelConsensus>>(emptyList())
    val consensusRecords = mutableStateOf<List<ConsensusRecord>>(emptyList())
    val consensusStats = mutableStateOf(ConsensusStats())
    val customPlans = mutableStateOf<List<CustomPlan>>(emptyList())

    /** 异步增量回测任务:新任务开始前取消旧任务,避免回测堆积占用 CPU */
    private var backtestJob: Job? = null

    /** 手动回测:清零战绩后全量滚动验证,并生成本期计划与共识 */
    fun runBacktest(
        rows: List<DrawRecord>,
        prefs: UserPrefs,
        lotteryKey: String,
        onStatus: (String) -> Unit,
        onError: (String?) -> Unit
    ) {
        viewModelScope.launch {
            if (rows.size < 40) {
                onError("历史不足,至少约 40 期再回测")
                return@launch
            }
            // 手动回测接管:取消正在跑的异步回测,避免状态互相覆盖
            backtestJob?.cancel()
            backtestRunning.value = true
            onStatus("回测中...")
            try {
                withContext(Dispatchers.Default) {
                    // 手动「重新滚动验证」:先清零旧战绩,再全量回测一次,
                    // 保证各计划样本数与历史预测不重复累加
                    engine.clearCareer()
                    engine.backtest(rows, prefs, minWarm = 30, forceFull = true) { !isActive }
                }
                val target = PredictEngine.suggestNextIssue(rows.lastOrNull()?.issue)
                val cutoff = rows.last().issue
                // 强制为本期目标重新随机生成计划
                val preds = withContext(Dispatchers.Default) {
                    engine.generateRandomPlansForIssue(target, count = prefs.planPoolCount.coerceIn(4, 30), force = true)
                    engine.predictForNext(rows, prefs, target, cutoff)
                }
                planRows.value = engine.getRuntimes()
                planHistory.value = engine.getAllRecentPredictions(100)
                consensus.value = engine.consensus(lotteryKey, target, preds)
                ConsensusEngine.recordPending(consensusStore, lotteryKey, target, consensus.value)
                refreshConsensusStats(lotteryKey)
                labRows.value = withContext(Dispatchers.Default) {
                    AnalysisEngine.labTable(rows, prefs)
                }
                onStatus("已随机生成 ${planRows.value.size} 条计划 · 回测完成")
            } catch (e: CancellationException) {
                onError("回测已取消")
            } catch (e: Exception) {
                onError(e.message)
            } finally {
                backtestRunning.value = false
            }
        }
    }

    /**
     * 由 MainViewModel 数据管线在预测完成后调用:同步计划/共识状态。
     * 主链路只做「轻量预测 + 共识」(不阻塞),增量回测放到后台异步执行,
     * 完成后自动刷新计划战绩与共识 —— 修复原实现回测卡死主链路导致
     * 共识丢失、计划页卡死、挂机无法下注的问题。
     * @return (共识列表, 计划运行态, 最近预测)
     */
    suspend fun syncAfterPredict(
        rows: List<DrawRecord>,
        prefs: UserPrefs,
        target: String,
        cutoff: String,
        lotteryKey: String
    ): Triple<List<ModelConsensus>, List<Pair<PlanDefinition, PlanRuntime>>, List<PlanPredictionRecord>> {
        val result = withContext(Dispatchers.Default) {
            val preds = engine.predictForNext(rows, prefs, target, cutoff)
            val cons = engine.consensus(lotteryKey, target, preds)
            val runtimes = engine.getRuntimes()
            val recent = engine.getAllRecentPredictions(100)
            Triple(cons, runtimes, recent)
        }
        val (cons, runtimes, recent) = result
        consensus.value = cons
        ConsensusEngine.recordPending(consensusStore, lotteryKey, target, cons)
        planRows.value = runtimes
        planHistory.value = recent
        refreshConsensusStats(lotteryKey)
        // 异步增量回测:不阻塞主链路,完成后用最新战绩刷新计划/共识
        startIncrementalBacktest(rows, prefs, target, cutoff, lotteryKey)
        return result
    }

    /** 后台增量回测:每期检查协程取消;完成后重算本期计划/共识与战绩 */
    private fun startIncrementalBacktest(
        rows: List<DrawRecord>,
        prefs: UserPrefs,
        target: String,
        cutoff: String,
        lotteryKey: String
    ) {
        backtestJob?.cancel()
        backtestJob = viewModelScope.launch {
            try {
                withContext(Dispatchers.Default) {
                    if (rows.size >= 40) engine.backtest(rows, prefs, minWarm = 30) { !isActive }
                }
                val (cons, runtimes, recent) = withContext(Dispatchers.Default) {
                    val preds = engine.predictForNext(rows, prefs, target, cutoff)
                    Triple(
                        engine.consensus(lotteryKey, target, preds),
                        engine.getRuntimes(),
                        engine.getAllRecentPredictions(100)
                    )
                }
                consensus.value = cons
                ConsensusEngine.recordPending(consensusStore, lotteryKey, target, cons)
                planRows.value = runtimes
                planHistory.value = recent
                refreshConsensusStats(lotteryKey)
            } catch (e: CancellationException) {
                // 被新任务接管或 ViewModel 销毁:静默
            } catch (e: Exception) {
                // 后台回测失败不影响主链路
            }
        }
    }

    /** 新开奖结算后刷新内存态(由 MainViewModel 调用) */
    fun refreshRuntimeState() {
        planRows.value = engine.getRuntimes()
        planHistory.value = engine.getAllRecentPredictions(80)
    }

    suspend fun refreshConsensusStats(lotteryKey: String) {
        consensusRecords.value = consensusStore.loadAll(lotteryKey).sortedByDescending { it.createdAt }
        consensusStats.value = consensusStore.stats(lotteryKey)
    }

    fun clearConsensusStats(lotteryKey: String) {
        viewModelScope.launch {
            try {
                consensusStore.clear(lotteryKey)
                refreshConsensusStats(lotteryKey)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // 清空/统计失败不影响主流程
            }
        }
    }

    fun loadPlanDetail(planId: String) {
        // 后台线程读取(回测持锁期间避免阻塞主线程)
        viewModelScope.launch(Dispatchers.Default) {
            try {
                selectedPlanHistory.value = engine.getPredictionHistory(planId, 40)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // 读取失败保持原状态
            }
        }
    }

    // ---- 自定义计划 ----

    /** 从 Room 加载当前彩种的自定义计划并注入 PlanEngine */
    fun loadCustomPlans(lotteryKey: String) {
        viewModelScope.launch {
            try {
                val key = lotteryKey
                val entities = app.customPlanDao.getByLottery(key)
                val plans = entities.map { it.toDomain() }
                customPlans.value = plans
                engine.setCustomPlans(
                    plans.filter { it.enabled }.map { it.toDefinition() }
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // 加载失败不影响主流程
            }
        }
    }

    /** 保存(新增或更新)自定义计划 */
    fun saveCustomPlan(plan: CustomPlan, onStatus: (String) -> Unit = {}) {
        viewModelScope.launch {
            try {
                app.customPlanDao.upsert(com.caifenxi.app.data.db.entity.CustomPlanEntity.fromDomain(plan))
                loadCustomPlans(plan.lotteryKey)
                onStatus("已保存计划「${plan.planName}」")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                onStatus("保存失败:${e.message}")
            }
        }
    }

    /** 删除自定义计划 */
    fun deleteCustomPlan(planId: String, lotteryKey: String, onStatus: (String) -> Unit = {}) {
        viewModelScope.launch {
            try {
                app.customPlanDao.deleteById(planId)
                loadCustomPlans(lotteryKey)
                onStatus("已删除计划")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                onStatus("删除失败:${e.message}")
            }
        }
    }

    /** 启用/停用自定义计划 */
    fun toggleCustomPlan(plan: CustomPlan, enabled: Boolean) {
        viewModelScope.launch {
            try {
                app.customPlanDao.upsert(
                    com.caifenxi.app.data.db.entity.CustomPlanEntity.fromDomain(
                        plan.copy(enabled = enabled, updatedAt = System.currentTimeMillis())
                    )
                )
                loadCustomPlans(plan.lotteryKey)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // 切换失败不影响主流程
            }
        }
    }
}
