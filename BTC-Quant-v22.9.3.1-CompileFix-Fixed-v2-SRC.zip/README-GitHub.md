# BTC Quant GitHub 构建指南

## 环境
- JDK 17
- Android SDK 35 / Build Tools 35.0.0
- Gradle 8.9
- minSdk 24

## Debug
GitHub Actions → **BTC Quant Build APK**。工作流通过 `gradle/actions/setup-gradle@v4` 提供 Gradle 8.9，然后执行 `assembleDebug（单一 debug APK，无 flavor）`。

## Release
GitHub Actions → **BTC Quant Release APK**。配置签名 Secrets 后可生成签名 APK；未配置签名密钥时生成 unsigned release artifact。

## 数据
运行时不会使用截图中的固定账户数字。没有真实 API/CLOB/Oracle 数据时会明确显示 PAPER/OFFLINE/UNAVAILABLE。

## v16.6 逻辑落地核验

本版本不是仅保存 GitHub 仓库名称：
- radioman 的 `btc_momentum`、`odds_favorite`、`btc_and_odds`、`btc_or_odds`、`contrarian`、`btc_mean_revert` 已在 `PolymarketGithubStrategyLogic.kt` 原生重实现。
- 已按其公开文档使用 BTC price-to-beat、BTC delta、favorite odds、entry window 等条件。
- py-clob-client 的 CLOB endpoint/TradeParams 结构已核验：`/data/trades` 支持 market、asset_id、before、after 等参数；Android 端继续保持自己的 OkHttp 原生实现，不复制第三方源码。
- Hummingbot / Freqtrade / Emmanuel Westra 的策略思想用于架构与研究生命周期；未直接复制 GPL/第三方源码。

## v16.6 自动量化闭环

实时候选 → 全策略 PIT 快照 → 结算回填 → expanding-window OOS → 成本后 PF/WR/DD/stability → lifecycle → runtime weight/status → 下一轮自动候选。
