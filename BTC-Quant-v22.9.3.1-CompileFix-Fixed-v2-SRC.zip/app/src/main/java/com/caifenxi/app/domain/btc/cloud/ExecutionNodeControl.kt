package com.caifenxi.app.domain.btc.cloud

/** Control-plane contract. Android is a controller; a remote node may implement this later. */
enum class NodeState { OFFLINE, STARTING, RUNNING, DEGRADED, STOPPING, ERROR }
data class ExecutionNodeStatus(val nodeId: String, val state: NodeState, val heartbeatAtMs: Long, val mode: String, val detail: String = "")
interface ExecutionNodeControl {
    suspend fun status(): ExecutionNodeStatus
    suspend fun start(mode: String): Boolean
    suspend fun stop(reason: String): Boolean
    suspend fun emergencyStop(reason: String): Boolean
}

class LocalExecutionNodeControl : ExecutionNodeControl {
    @Volatile private var status = ExecutionNodeStatus("android-local", NodeState.OFFLINE, 0L, "PAPER")
    override suspend fun status() = status.copy(heartbeatAtMs = System.currentTimeMillis())
    override suspend fun start(mode: String): Boolean { status = ExecutionNodeStatus("android-local", NodeState.RUNNING, System.currentTimeMillis(), mode, "local control"); return true }
    override suspend fun stop(reason: String): Boolean { status = status.copy(state = NodeState.OFFLINE, detail = reason); return true }
    override suspend fun emergencyStop(reason: String): Boolean { status = status.copy(state = NodeState.ERROR, detail = "EMERGENCY: $reason"); return true }
}
