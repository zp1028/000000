package com.caifenxi.app.domain.btc.recovery

/** Restart-safe recovery decisions derived only from persisted execution facts. */
enum class RecoveryStage { CLEAN, RESUME, RECONCILE, HEDGE, CANCEL, BLOCK }

data class RecoveryRecord(
    val executionId: String,
    val marketId: String,
    val stage: String,
    val targetSize: Double,
    val legAFilled: Double,
    val legBFilled: Double,
    val lastVenueUpdateMs: Long,
    val nowMs: Long,
    val venueReachable: Boolean
)

data class RecoveryDecision(val stage: RecoveryStage, val reason: String, val safeToResume: Boolean)

object ExecutionRecoveryCore {
    fun decide(record: RecoveryRecord, staleAfterMs: Long = 15_000L): RecoveryDecision {
        if (!record.venueReachable) return RecoveryDecision(RecoveryStage.BLOCK, "venue unreachable; preserve state and retry reconciliation", false)
        if (record.lastVenueUpdateMs <= 0L || record.nowMs - record.lastVenueUpdateMs > staleAfterMs) {
            return RecoveryDecision(RecoveryStage.RECONCILE, "venue state stale after restart", false)
        }
        if (record.legAFilled < 0.0 || record.legBFilled < 0.0 || record.targetSize <= 0.0) {
            return RecoveryDecision(RecoveryStage.BLOCK, "invalid persisted execution quantities", false)
        }
        val imbalance = kotlin.math.abs(record.legAFilled - record.legBFilled)
        return when {
            record.legAFilled + 1e-9 >= record.targetSize && record.legBFilled + 1e-9 >= record.targetSize -> RecoveryDecision(RecoveryStage.RESUME, "both legs confirmed filled", true)
            imbalance > 1e-9 -> RecoveryDecision(RecoveryStage.HEDGE, "restart detected unhedged leg exposure", false)
            record.stage.uppercase() in setOf("CANCELED", "CLOSED", "REDEEMED") -> RecoveryDecision(RecoveryStage.CLEAN, "terminal execution", false)
            else -> RecoveryDecision(RecoveryStage.RESUME, "persisted execution can resume", true)
        }
    }
}
