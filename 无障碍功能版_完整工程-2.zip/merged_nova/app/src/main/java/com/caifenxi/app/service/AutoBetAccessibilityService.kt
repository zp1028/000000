package com.caifenxi.app.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import com.caifenxi.app.CaiFenXiApplication
import com.caifenxi.app.util.AndroidCompat
import com.caifenxi.app.util.RuntimeLog

/**
 * 无障碍自动点击服务：根据彩分析内部预测，在第三方页面点击「大/小/单/双」。
 *
 * 关键能力：
 * 1. canPerformGestures：支持 WebView / 不响应 ACTION_CLICK 的控件
 * 2. 多窗口扫描：不只看 rootInActiveWindow
 * 3. 跳过本应用窗口，避免点到彩析自己的界面
 * 4. 精确文字 / contentDescription / 递归子节点匹配
 * 5. 若当前仍在本应用，挂起任务，等切到第三方页面再执行
 */
class AutoBetAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: AutoBetAccessibilityService? = null

        fun isRunning(): Boolean = instance != null
    }

    private val mainHandler = Handler(Looper.getMainLooper())

    private var lastActionFingerprint: String = ""
    private var lastActionAt: Long = 0L
    private val actionCooldownMs = 2_000L

    /** 等待用户切到第三方页面时的挂起任务 */
    private var pendingDx: String? = null
    private var pendingDs: String? = null
    private var pendingAmount: String? = null
    private var pendingDelayMs: Long = 350L
    private var pendingUntil: Long = 0L
    private var pendingIssue: String? = null
    private var pendingLotteryKey: String? = null
    private val pendingMaxWaitMs = 45_000L

    private val supportsGestureTap: Boolean
        get() = AndroidCompat.supportsAccessibilityGesture()

    /**
     * 临时区域覆盖：点数字键盘时优先用「输入区域」，避免受大小单双点击区域限制。
     * null 表示回落到 [activeClickRegionPx]。
     */
    @Volatile
    private var regionOverridePx: Rect? = null

    /** 当前点击区域（屏幕像素），null 表示不限制 */
    private fun activeClickRegionPx(): Rect? {
        regionOverridePx?.let { return it }
        return try {
            val prefs = CaiFenXiApplication.instance.configStore.loadPrefs()
            if (!prefs.autoClickRegionEnabled) return null
            normalizedToPx(
                prefs.autoClickRegionLeft,
                prefs.autoClickRegionTop,
                prefs.autoClickRegionRight,
                prefs.autoClickRegionBottom
            )
        } catch (_: Exception) {
            null
        }
    }

    /** 数字键盘/输入区域（屏幕像素），null 表示未框选 */
    private fun activeInputRegionPx(): Rect? {
        return try {
            val prefs = CaiFenXiApplication.instance.configStore.loadPrefs()
            if (!prefs.autoInputRegionEnabled) return null
            normalizedToPx(
                prefs.autoInputRegionLeft,
                prefs.autoInputRegionTop,
                prefs.autoInputRegionRight,
                prefs.autoInputRegionBottom
            )
        } catch (_: Exception) {
            null
        }
    }

    private fun normalizedToPx(lN: Float, tN: Float, rN: Float, bN: Float): Rect? {
        val dm = resources.displayMetrics
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()
        val l = (lN.coerceIn(0f, 1f) * w).toInt()
        val top = (tN.coerceIn(0f, 1f) * h).toInt()
        val r = (rN.coerceIn(0f, 1f) * w).toInt()
        val b = (bN.coerceIn(0f, 1f) * h).toInt()
        // 允许较小框选（数字键区域可能很紧凑），最低约 8px
        if (r - l < 8 || b - top < 8) return null
        return Rect(l, top, r, b)
    }

    private fun centerInsideRegion(rect: Rect, region: Rect?): Boolean {
        if (region == null) return true
        val cx = rect.centerX()
        val cy = rect.centerY()
        return region.contains(cx, cy)
    }

    private fun showClickFeedback(x: Float, y: Float, label: String) {
        try {
            val prefs = CaiFenXiApplication.instance.configStore.loadPrefs()
            if (!prefs.autoClickShowFeedback) return
            ClickFeedbackOverlay.show(this, x, y, label, fromA11y = true)
        } catch (_: Exception) {
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        // 运行时再补一次能力（兼容部分 ROM 对 XML 解析不完整）
        serviceInfo = serviceInfo?.apply {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                // FLAG 已在 xml 中声明；这里确保 eventTypes 覆盖窗口切换
                eventTypes = eventTypes or
                    AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or
                    AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED or
                    AccessibilityEvent.TYPE_WINDOWS_CHANGED
            }
        }
        RuntimeLog.info("AutoBet", "无障碍服务已连接 package=$packageName")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        if (pendingDx == null && pendingDs == null) return
        if (System.currentTimeMillis() > pendingUntil) {
            clearPending("等待超时，取消挂起点击", reportFailure = true)
            return
        }
        val type = event.eventType
        if (type == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
            type == AccessibilityEvent.TYPE_WINDOWS_CHANGED ||
            type == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
        ) {
            val pkg = event.packageName?.toString().orEmpty()
            if (pkg.isNotBlank() && pkg != packageName) {
                RuntimeLog.info("AutoBet", "检测到第三方窗口 pkg=$pkg，尝试执行挂起点击")
                mainHandler.post { executePendingIfPossible() }
            }
        }
    }

    override fun onInterrupt() {
        RuntimeLog.warn("AutoBet", "无障碍服务被中断")
    }

    override fun onDestroy() {
        instance = null
        clearPending("无障碍服务销毁", reportFailure = true)
        RuntimeLog.info("AutoBet", "无障碍服务已销毁")
        super.onDestroy()
    }

    /**
     * 根据预测执行点击。
     * 若当前前台是本应用，则挂起最多 [pendingMaxWaitMs]，等用户切到第三方页面再点。
     * 仅在流水线成功后回调 [AutoBetController.notifyBetSucceeded] 写入期号去重。
     *
     * @param amountText 若非空且开启自动点击数字，则在点击大小单双后，于数字键盘区域内逐位点击金额
     * @param targetIssue 目标期号；成功后写入去重
     * @param lotteryKey 彩种；与期号一起用于成功/失败回调
     */
    fun performBet(
        dx: String?,
        ds: String?,
        clickDelayMs: Long = 350L,
        amountText: String? = null,
        targetIssue: String? = null,
        lotteryKey: String? = null
    ) {
        val fingerprint = "${dx.orEmpty()}|${ds.orEmpty()}|${amountText.orEmpty()}|${targetIssue.orEmpty()}"
        val now = System.currentTimeMillis()
        if (fingerprint.isBlank() || fingerprint == "|||" ||
            (fingerprint == lastActionFingerprint && now - lastActionAt < actionCooldownMs)
        ) {
            RuntimeLog.info("AutoBet", "重复触发保护：跳过 $fingerprint")
            return
        }

        mainHandler.post {
            val activePkg = activeWindowPackage()
            RuntimeLog.info(
                "AutoBet",
                "performBet 当前前台=$activePkg 目标 dx=$dx ds=$ds amount=${amountText ?: "-"} issue=${targetIssue ?: "-"}"
            )

            if (activePkg.isNullOrBlank() || activePkg == packageName) {
                pendingDx = dx
                pendingDs = ds
                pendingAmount = amountText
                pendingDelayMs = clickDelayMs
                pendingIssue = targetIssue
                pendingLotteryKey = lotteryKey
                pendingUntil = System.currentTimeMillis() + pendingMaxWaitMs
                RuntimeLog.warn(
                    "AutoBet",
                    "当前仍在本应用($activePkg)，已挂起，请在 ${pendingMaxWaitMs / 1000}s 内切换到第三方投注页"
                )
                return@post
            }

            val ok = doExecutePipeline(dx, ds, clickDelayMs, amountText)
            if (ok) {
                lastActionFingerprint = fingerprint
                lastActionAt = System.currentTimeMillis()
                reportSuccessToController(targetIssue, lotteryKey)
                clearPending(null, reportFailure = false)
            } else {
                pendingDx = dx
                pendingDs = ds
                pendingAmount = amountText
                pendingDelayMs = clickDelayMs
                pendingIssue = targetIssue
                pendingLotteryKey = lotteryKey
                pendingUntil = System.currentTimeMillis() + pendingMaxWaitMs
                RuntimeLog.warn("AutoBet", "本次执行未完成，已挂起等待页面内容出现")
            }
        }
    }

    private fun executePendingIfPossible() {
        val dx = pendingDx
        val ds = pendingDs
        val amount = pendingAmount
        val issue = pendingIssue
        val lottery = pendingLotteryKey
        if (dx == null && ds == null && amount.isNullOrBlank()) return
        if (System.currentTimeMillis() > pendingUntil) {
            clearPending("挂起任务超时", reportFailure = true)
            return
        }
        val activePkg = activeWindowPackage()
        if (activePkg.isNullOrBlank() || activePkg == packageName) return

        val ok = doExecutePipeline(dx, ds, pendingDelayMs, amount)
        if (ok) {
            lastActionFingerprint = "${dx.orEmpty()}|${ds.orEmpty()}|${amount.orEmpty()}|${issue.orEmpty()}"
            lastActionAt = System.currentTimeMillis()
            reportSuccessToController(issue, lottery)
            clearPending("挂起执行成功", reportFailure = false)
        }
    }

    private fun reportSuccessToController(issue: String?, lotteryKey: String?) {
        if (issue.isNullOrBlank()) return
        try {
            AutoBetController.notifyBetSucceeded(this, issue, lotteryKey.orEmpty())
        } catch (e: Exception) {
            RuntimeLog.warn("AutoBet", "notifyBetSucceeded 失败: ${e.message}")
        }
    }

    private fun reportFailureToController(issue: String?, lotteryKey: String?, reason: String?) {
        try {
            AutoBetController.notifyBetFailedOrTimedOut(this, issue, lotteryKey, reason)
        } catch (e: Exception) {
            RuntimeLog.warn("AutoBet", "notifyBetFailedOrTimedOut 失败: ${e.message}")
        }
    }

    /**
     * @param reportFailure 为 true 时（超时等）通知 Controller 清除 inflight，允许同一期重试
     */
    private fun clearPending(reason: String?, reportFailure: Boolean = false) {
        val issue = pendingIssue
        val lottery = pendingLotteryKey
        pendingDx = null
        pendingDs = null
        pendingAmount = null
        pendingUntil = 0L
        pendingIssue = null
        pendingLotteryKey = null
        if (!reason.isNullOrBlank()) {
            RuntimeLog.info("AutoBet", reason)
        }
        if (reportFailure) {
            reportFailureToController(issue, lottery, reason)
        }
    }

    /** 在非本应用窗口上真正执行点击 */
    /**
     * 严格顺序：
     * ① 先点击大小单双（若开启）→ 等待页面响应
     * ② 再逐位点击数字（若开启）——绝不会插到①之前
     */
    private fun doExecutePipeline(
        dx: String?,
        ds: String?,
        clickDelayMs: Long,
        amountText: String?
    ): Boolean {
        val prefs = try {
            CaiFenXiApplication.instance.configStore.loadPrefs()
        } catch (_: Exception) {
            return doClickOnThirdParty(dx, ds, clickDelayMs)
        }

        var dxDsOk = true
        val needDxDs = prefs.autoExecClickDxDs && (!dx.isNullOrBlank() || !ds.isNullOrBlank())
        val needDigits = !amountText.isNullOrBlank() && prefs.autoInputEnabled &&
            (prefs.autoExecFindInput || prefs.autoExecTypeAmount)

        // ── 步骤①：大小单双（必须先完成；仅用点击区域，不用数字区域覆盖）──
        if (needDxDs) {
            RuntimeLog.info("AutoBet", "流水线步骤① 开始：点击大小单双 dx=$dx ds=$ds")
            regionOverridePx = null
            dxDsOk = doClickOnThirdParty(dx, ds, clickDelayMs)
            if (!dxDsOk) {
                RuntimeLog.warn("AutoBet", "步骤① 点击大小单双失败，中止（不进入点数字）")
                return false
            }
            RuntimeLog.info("AutoBet", "流水线步骤① 完成，等待后进入点数字")
            try {
                Thread.sleep((clickDelayMs * 1.5).toLong().coerceIn(250L, 2500L))
            } catch (_: InterruptedException) {
            }
        } else {
            RuntimeLog.info("AutoBet", "流水线步骤① 跳过（未要求点大小单双）")
        }

        // ── 步骤②：数字（仅在①之后）──
        if (needDigits) {
            RuntimeLog.info("AutoBet", "流水线步骤② 开始：逐位点击数字 amount=$amountText")
            val typed = clickAmountDigitsOnScreen(amountText!!, clickDelayMs)
            if (!typed) {
                RuntimeLog.warn("AutoBet", "步骤② 点击数字失败 amount=$amountText")
                return dxDsOk
            }
            RuntimeLog.info("AutoBet", "流水线步骤② 完成：数字已点击 amount=$amountText")
        } else {
            RuntimeLog.info("AutoBet", "流水线步骤② 跳过（未启用点数字或金额为空）")
        }

        return dxDsOk
    }

    /**
     * 将金额拆成「0-9 / .」序列，用与大小单双**完全相同**的 findAndClick 逻辑逐位点击。
     * 区域策略：优先数字键盘区域 → 否则点击区域 → 否则全屏（与大小单双一致，不因未框选而直接失败）。
     */
    private fun clickAmountDigitsOnScreen(amountText: String, clickDelayMs: Long): Boolean {
        val digits = amountText.trim().map { ch ->
            when {
                ch in '０'..'９' -> ('0'.code + (ch - '０')).toChar()
                ch == '．' || ch == '。' -> '.'
                else -> ch
            }
        }.filter { it.isDigit() || it == '.' }
        if (digits.isEmpty()) {
            RuntimeLog.warn("AutoBet", "金额无可点击字符 amount=$amountText")
            return false
        }

        // 与大小单双相同：有区域限制就用，没有就全屏搜
        val digitRegion = activeInputRegionPx() ?: activeClickRegionPxRaw()
        val gapMs = clickDelayMs.coerceIn(120L, 800L)
        regionOverridePx = digitRegion
        try {
            RuntimeLog.info(
                "AutoBet",
                "开始逐位点击数字(同大小单双逻辑) sequence=$digits region=${digitRegion ?: "全屏"} gap=${gapMs}ms"
            )
            for ((idx, ch) in digits.withIndex()) {
                val label = ch.toString()
                // 与 doClickOnThirdParty 相同：扫所有第三方窗口根节点 + findAndClick
                val ok = doClickLabelOnThirdParty(label)
                if (!ok) {
                    RuntimeLog.warn("AutoBet", "第${idx + 1}位数字「$label」未找到或点击失败")
                    return false
                }
                RuntimeLog.info("AutoBet", "已点击数字「$label」(${idx + 1}/${digits.length})")
                if (idx < digits.lastIndex) {
                    try {
                        Thread.sleep(gapMs)
                    } catch (_: InterruptedException) {
                    }
                }
            }
            return true
        } finally {
            regionOverridePx = null
        }
    }

    /**
     * 与 [doClickOnThirdParty] 单目标路径一致：遍历第三方窗口，findAndClick(text)。
     */
    private fun doClickLabelOnThirdParty(text: String): Boolean {
        val roots = collectCandidateRoots()
        if (roots.isEmpty()) {
            RuntimeLog.warn("AutoBet", "点「$text」：无可用窗口根节点")
            return false
        }
        try {
            for (root in roots) {
                val pkg = root.packageName?.toString().orEmpty()
                if (pkg == packageName) continue
                if (findAndClick(root, text)) {
                    RuntimeLog.info("AutoBet", "窗口=$pkg 点击[$text] => true")
                    return true
                }
            }
        } finally {
            roots.forEach { try { it.recycle() } catch (_: Exception) {} }
        }
        RuntimeLog.warn("AutoBet", "未找到可点击的「$text」")
        return false
    }

    /** 读取点击区域原始配置（不经过 regionOverride），供数字回落使用 */
    private fun activeClickRegionPxRaw(): Rect? {
        return try {
            val prefs = CaiFenXiApplication.instance.configStore.loadPrefs()
            if (!prefs.autoClickRegionEnabled) return null
            normalizedToPx(
                prefs.autoClickRegionLeft,
                prefs.autoClickRegionTop,
                prefs.autoClickRegionRight,
                prefs.autoClickRegionBottom
            )
        } catch (_: Exception) {
            null
        }
    }

    private fun doClickOnThirdParty(dx: String?, ds: String?, clickDelayMs: Long): Boolean {
        val roots = collectCandidateRoots()
        if (roots.isEmpty()) {
            RuntimeLog.warn("AutoBet", "无可用窗口根节点")
            return false
        }

        var clickedDx = false
        var clickedDs = false

        try {
            if (!dx.isNullOrBlank() && (dx == "大" || dx == "小")) {
                for (root in roots) {
                    val pkg = root.packageName?.toString().orEmpty()
                    if (pkg == packageName) continue
                    if (findAndClick(root, dx)) {
                        RuntimeLog.info("AutoBet", "窗口=$pkg 点击[$dx] => true")
                        clickedDx = true
                        break
                    }
                }
                if (!clickedDx) {
                    RuntimeLog.warn("AutoBet", "未找到可点击的「$dx」")
                }
            } else {
                clickedDx = true // 未要求点大小，视为通过
            }

            if (!ds.isNullOrBlank() && (ds == "单" || ds == "双")) {
                val runDs = {
                    val roots2 = collectCandidateRoots()
                    var ok = false
                    for (root in roots2) {
                        val pkg = root.packageName?.toString().orEmpty()
                        if (pkg == packageName) continue
                        if (findAndClick(root, ds)) {
                            RuntimeLog.info("AutoBet", "窗口=$pkg 点击[$ds] => true")
                            ok = true
                            break
                        }
                    }
                    if (!ok) RuntimeLog.warn("AutoBet", "未找到可点击的「$ds」")
                    roots2.forEach { try { it.recycle() } catch (_: Exception) {} }
                    clickedDs = ok
                }
                if (clickedDx && clickDelayMs > 0 && !dx.isNullOrBlank()) {
                    // 同步等待一小段，保证顺序（挂起路径里已在主线程）
                    try {
                        Thread.sleep(clickDelayMs.coerceIn(100L, 1500L))
                    } catch (_: InterruptedException) {
                    }
                }
                runDs()
            } else {
                clickedDs = true
            }
        } finally {
            roots.forEach { try { it.recycle() } catch (_: Exception) {} }
        }

        return (dx.isNullOrBlank() || clickedDx) && (ds.isNullOrBlank() || clickedDs) &&
            (!dx.isNullOrBlank() || !ds.isNullOrBlank()) && (clickedDx || clickedDs)
    }

    private fun activeWindowPackage(): String? {
        val root = rootInActiveWindow ?: return null
        return try {
            root.packageName?.toString()
        } finally {
            try { root.recycle() } catch (_: Exception) {}
        }
    }

    /** 收集所有可交互窗口的根节点（排除本应用） */
    private fun collectCandidateRoots(): List<AccessibilityNodeInfo> {
        val out = ArrayList<AccessibilityNodeInfo>()
        val seen = HashSet<Int>()

        fun addRoot(node: AccessibilityNodeInfo?) {
            if (node == null) return
            val key = System.identityHashCode(node)
            if (!seen.add(key)) {
                try { node.recycle() } catch (_: Exception) {}
                return
            }
            val pkg = node.packageName?.toString().orEmpty()
            if (pkg == packageName) {
                try { node.recycle() } catch (_: Exception) {}
                return
            }
            out.add(node)
        }

        // 1) 活动窗口
        addRoot(rootInActiveWindow)

        // 2) 多窗口（浏览器分屏、悬浮层等）
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            val wins = windows
            if (wins != null) {
                for (w in wins) {
                    try {
                        if (w.type != AccessibilityWindowInfo.TYPE_APPLICATION &&
                            w.type != AccessibilityWindowInfo.TYPE_SPLIT_SCREEN_DIVIDER
                        ) {
                            // 仍尝试取 root，部分投注页在 TYPE_APPLICATION
                        }
                        addRoot(w.root)
                    } catch (_: Exception) {
                    }
                }
            }
        }
        return out
    }

    /**
     * 严格查找并点击目标文字（大/小/单/双 与 0-9/. 共用同一套逻辑）。
     * 优先点「自身可点 + 面积小」的按钮，禁止点超大父容器。
     * 额外：系统 findAccessibilityNodeInfosByText 作为兜底候选源。
     */
    private fun findAndClick(root: AccessibilityNodeInfo, text: String): Boolean {
        val candidates = ArrayList<ScoredNode>()
        collectStrictMatches(root, text, candidates)
        // 系统 API 兜底：很多 WebView/原生数字键只通过 findByText 能扫到
        try {
            val byText = root.findAccessibilityNodeInfosByText(text)
            if (byText != null) {
                for (n in byText) {
                    try {
                        scoreAndMaybeAdd(n, text, candidates)
                    } finally {
                        try { n.recycle() } catch (_: Exception) {}
                    }
                }
            }
        } catch (_: Exception) {
        }
        if (candidates.isEmpty()) {
            RuntimeLog.warn("AutoBet", "严格匹配无结果: $text")
            return false
        }
        candidates.sortWith(
            compareByDescending<ScoredNode> { it.score }
                .thenBy { it.area }
        )
        RuntimeLog.info(
            "AutoBet",
            "候选「$text」${candidates.size}个 最佳score=${candidates.first().score} area=${candidates.first().area}"
        )

        try {
            for (c in candidates) {
                if (c.score < 40) continue
                if (tryClickNodeStrict(c.node, c.area, text)) {
                    RuntimeLog.info("AutoBet", "命中点击「$text」score=${c.score} bounds=${boundsStr(c.node)}")
                    return true
                }
            }
        } finally {
            candidates.forEach { try { it.node.recycle() } catch (_: Exception) {} }
        }
        return false
    }

    private data class ScoredNode(
        val node: AccessibilityNodeInfo,
        val score: Int,
        val area: Int
    )

    private fun collectStrictMatches(
        node: AccessibilityNodeInfo,
        text: String,
        out: MutableList<ScoredNode>
    ) {
        scoreAndMaybeAdd(node, text, out)
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            try {
                collectStrictMatches(child, text, out)
            } finally {
                try { child.recycle() } catch (_: Exception) {}
            }
        }
    }

    /** 对单个节点打分，合格则加入候选（递归与 findByText 共用） */
    private fun scoreAndMaybeAdd(
        node: AccessibilityNodeInfo,
        text: String,
        out: MutableList<ScoredNode>
    ) {
        val nodeText = normalizeLabel(node.text?.toString())
        val desc = normalizeLabel(node.contentDescription?.toString())
        val cls = node.className?.toString().orEmpty()
        val isDigitKey = text.length == 1 && (text[0].isDigit() || text == ".")

        var score = 0
        // 大小单双与数字共用：优先整段相等；数字额外允许极短标签（防点到「大1.98」）
        when {
            nodeText == text -> score += 100
            desc == text -> score += 90
            isDigitKey && nodeText.length in 1..2 && nodeText.contains(text) &&
                nodeText.all { it.isDigit() || it == '.' } -> score += 85
            isDigitKey && desc.length in 1..2 && desc.contains(text) &&
                desc.all { it.isDigit() || it == '.' } -> score += 80
            !isDigitKey && isSingleTargetToken(nodeText, text) -> score += 80
            !isDigitKey && isSingleTargetToken(desc, text) -> score += 70
            !isDigitKey && nodeText.contains(text) && nodeText.length <= 4 && !containsRival(nodeText, text) -> score += 55
            !isDigitKey && desc.contains(text) && desc.length <= 4 && !containsRival(desc, text) -> score += 50
        }
        if (score <= 0) return

        val rect = Rect()
        node.getBoundsInScreen(rect)
        val area = (rect.width().coerceAtLeast(0) * rect.height().coerceAtLeast(0))
        val dm = resources.displayMetrics
        val screenArea = (dm.widthPixels * dm.heightPixels).coerceAtLeast(1)

        // 数字键通常更小：放宽最小尺寸；大小单双保持原阈值
        val minSide = if (isDigitKey) 12 else 24
        val tooBig = area > screenArea * 0.12 || rect.width() > dm.widthPixels * 0.55
        val tooSmall = rect.width() < minSide || rect.height() < minSide
        val notOnScreen = rect.isEmpty || rect.right <= 0 || rect.bottom <= 0 ||
            rect.left >= dm.widthPixels || rect.top >= dm.heightPixels
        val notVisible = !node.isVisibleToUser
        val outsideRegion = !centerInsideRegion(rect, activeClickRegionPx())

        if (tooBig || tooSmall || notOnScreen || notVisible || outsideRegion) return

        if (node.isClickable && node.isEnabled) score += 25
        if (node.isEnabled) score += 5
        if (cls.contains("Button", ignoreCase = true) ||
            cls.contains("TextView", ignoreCase = true) ||
            cls.contains("ViewGroup", ignoreCase = true) ||
            cls.contains("Image", ignoreCase = true)
        ) score += 5
        val cy = rect.exactCenterY()
        if (cy > dm.heightPixels * 0.35f) score += 8
        if (area < 80_000) score += 10
        if (area < 30_000) score += 8

        out.add(ScoredNode(AccessibilityNodeInfo.obtain(node), score, area))
    }

    /** 去掉空白，全角数字/小数点转半角，便于精确比对 */
    private fun normalizeLabel(raw: String?): String {
        if (raw.isNullOrBlank()) return ""
        val sb = StringBuilder()
        for (c in raw.trim()) {
            when {
                c in '０'..'９' -> sb.append(('0'.code + (c - '０')).toChar())
                c == '．' || c == '。' -> sb.append('.')
                c == ' ' || c == '\n' || c == '\t' || c == '　' -> Unit
                else -> sb.append(c)
            }
        }
        return sb.toString()
    }

    /** 如「大1.98」「大@2」视为单目标；「大小」这类对立词组合不算 */
    private fun isSingleTargetToken(label: String, text: String): Boolean {
        if (label.isEmpty() || !label.contains(text)) return false
        if (containsRival(label, text)) return false
        // 去掉目标字后只剩数字/符号
        val rest = label.replace(text, "")
        return rest.isEmpty() || rest.all { it.isDigit() || it in ".@xX倍赔:-_/" }
    }

    private fun containsRival(label: String, text: String): Boolean {
        val rivals = when (text) {
            "大" -> listOf("小")
            "小" -> listOf("大")
            "单" -> listOf("双")
            "双" -> listOf("单")
            else -> emptyList()
        }
        return rivals.any { it in label }
    }

    private fun boundsStr(node: AccessibilityNodeInfo): String {
        val r = Rect()
        node.getBoundsInScreen(r)
        return "[${r.left},${r.top}-${r.right},${r.bottom}]"
    }

    /**
     * 严格点击：优先 ACTION_CLICK → 可点父节点 → 手势点中心。
     * 数字键与大小单双共用；数字键放宽父层深度与手势面积下限。
     */
    private fun tryClickNodeStrict(node: AccessibilityNodeInfo, area: Int, label: String = ""): Boolean {
        if (!node.isEnabled || !node.isVisibleToUser) return false

        val rect = Rect()
        node.getBoundsInScreen(rect)
        val dm = resources.displayMetrics
        if (rect.isEmpty) return false
        if (rect.width() > dm.widthPixels * 0.55) return false
        if (area > dm.widthPixels * dm.heightPixels * 0.12) return false
        if (!centerInsideRegion(rect, activeClickRegionPx())) return false

        val isDigitKey = label.length == 1 && (label[0].isDigit() || label == ".")

        fun feedback(x: Float = rect.exactCenterX(), y: Float = rect.exactCenterY()) {
            showClickFeedback(x, y, label)
        }

        // 1) 节点自身可点
        if (node.isClickable) {
            if (node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                feedback()
                return true
            }
        }

        // 2) 向上找可点父节点（数字键多包一层，允许 3 层）
        val maxDepth = if (isDigitKey) 3 else 2
        var parent = node.parent
        var depth = 0
        while (parent != null && depth < maxDepth) {
            try {
                if (parent.isClickable && parent.isEnabled) {
                    val pr = Rect()
                    parent.getBoundsInScreen(pr)
                    val pArea = pr.width().coerceAtLeast(0) * pr.height().coerceAtLeast(0)
                    val parentOk = pArea > 0 &&
                        pArea <= dm.widthPixels * dm.heightPixels * 0.12 &&
                        pr.width() <= dm.widthPixels * 0.55 &&
                        centerInsideRegion(pr, activeClickRegionPx())
                    if (parentOk && parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                        showClickFeedback(pr.exactCenterX(), pr.exactCenterY(), label)
                        return true
                    }
                    // 父节点可点但 ACTION_CLICK 失败时，手势点父中心
                    if (parentOk && supportsGestureTap &&
                        dispatchTap(pr.exactCenterX(), pr.exactCenterY())
                    ) {
                        showClickFeedback(pr.exactCenterX(), pr.exactCenterY(), label)
                        return true
                    }
                }
            } finally {
                val next = parent.parent
                try { parent.recycle() } catch (_: Exception) {}
                parent = next
                depth++
            }
        }

        // 3) 手势点节点中心（不再要求 isClickable，数字 TextView 常不可点）
        if (supportsGestureTap) {
            val cx = rect.exactCenterX()
            val cy = rect.exactCenterY()
            val minArea = if (isDigitKey) 100 else 800
            val maxArea = 120_000
            if (cx > 0 && cy > 0 && area in minArea..maxArea && dispatchTap(cx, cy)) {
                feedback(cx, cy)
                return true
            }
        }
        return false
    }

    private fun dispatchTap(x: Float, y: Float): Boolean {
        if (!supportsGestureTap) return false
        return try {
            val path = Path().apply { moveTo(x, y) }
            val stroke = GestureDescription.StrokeDescription(path, 0, 40)
            val gesture = GestureDescription.Builder().addStroke(stroke).build()
            dispatchGesture(gesture, null, null)
        } catch (e: Exception) {
            RuntimeLog.warn("AutoBet", "手势点击失败: ${e.message}")
            false
        }
    }
}
