package com.caifenxi.app.domain.btc.runtime

enum class ExecutionHealthState { HEALTHY, DEGRADED, BLOCKED, UNKNOWN }

data class ExecutionHealth(
    val state: ExecutionHealthState = ExecutionHealthState.UNKNOWN,
    val reason: String = "未检查",
    val marketDataAgeMs: Long = Long.MAX_VALUE,
    val privateStreamAgeMs: Long = Long.MAX_VALUE,
    val reconciliationRequired: Boolean = false,
    val killSwitch: Boolean = false,
    val checkedAtMs: Long = 0L
) {
    val canExecute: Boolean get() = state == ExecutionHealthState.HEALTHY && !reconciliationRequired && !killSwitch
}

object ExecutionHealthEvaluator {
    fun evaluate(nowMs: Long, marketDataAt: Long, privateStreamAt: Long, reconciliationRequired: Boolean, killSwitch: Boolean): ExecutionHealth {
        if (killSwitch) return ExecutionHealth(ExecutionHealthState.BLOCKED, "Kill Switch", nowMs-marketDataAt, nowMs-privateStreamAt, reconciliationRequired, true, nowMs)
        if (reconciliationRequired) return ExecutionHealth(ExecutionHealthState.BLOCKED, "需要REST权威对账", nowMs-marketDataAt, nowMs-privateStreamAt, true, false, nowMs)
        val marketAge = nowMs-marketDataAt; val privateAge = nowMs-privateStreamAt
        return when { marketAge > 30_000 || privateAge > 90_000 -> ExecutionHealth(ExecutionHealthState.DEGRADED, "数据流陈旧", marketAge, privateAge, false, false, nowMs)
            else -> ExecutionHealth(ExecutionHealthState.HEALTHY, "执行链健康", marketAge, privateAge, false, false, nowMs) }
    }
}
