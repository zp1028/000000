package com.caifenxi.app.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.caifenxi.app.MainActivity
import com.caifenxi.app.util.AndroidCompat

object NotificationHelper {
    const val CHANNEL_ID = "caifenxi_sync"
    private const val NOTIFY_ID = 1001

    fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(
                CHANNEL_ID,
                "开奖同步",
                NotificationManager.IMPORTANCE_LOW
            ).apply { description = "后台同步开奖与提醒" }
            val nm = context.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(ch)
        }
    }

    fun buildForeground(context: Context, text: String): android.app.Notification {
        ensureChannel(context)
        val pi = PendingIntent.getActivity(
            context, 0, Intent(context, MainActivity::class.java),
            AndroidCompat.pendingIntentFlags()
        )
        return NotificationCompat.Builder(context, CHANNEL_ID)
            .setContentTitle("彩析")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }

    fun notifyNewDraw(context: Context, issue: String, summary: String) {
        ensureChannel(context)
        val nm = context.getSystemService(NotificationManager::class.java)
        val pi = PendingIntent.getActivity(
            context, 0, Intent(context, MainActivity::class.java),
            AndroidCompat.pendingIntentFlags()
        )
        val n = NotificationCompat.Builder(context, CHANNEL_ID)
            .setContentTitle("新开奖 第 $issue 期")
            .setContentText(summary)
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        nm.notify(NOTIFY_ID + 1, n)
    }

    fun notifySyncDone(context: Context, issueCount: Int, latestIssue: String, summary: String) {
        ensureChannel(context)
        val nm = context.getSystemService(NotificationManager::class.java)
        val pi = PendingIntent.getActivity(
            context, 0, Intent(context, MainActivity::class.java),
            AndroidCompat.pendingIntentFlags()
        )
        val n = NotificationCompat.Builder(context, CHANNEL_ID)
            .setContentTitle("后台同步完成")
            .setContentText("已更新 $issueCount 期 · 最新第 $latestIssue 期 · $summary")
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        nm.notify(NOTIFY_ID + 2, n)
    }
}
