package com.caifenxi.app.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.caifenxi.app.domain.plan.NovaPlanAnalytics
import com.caifenxi.app.ui.components.CaptionMuted
import kotlin.math.roundToInt

internal fun chartFmtMoney(v: Double): String = if (v >= 0) "+${"%.2f".format(v)}" else "${"%.2f".format(v)}"

@Composable
internal fun ChartFilterLine(title: String, options: List<String>, selected: String, onSelect: (String) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(top = 5.dp)) {
        CaptionMuted(title)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            options.forEach { option ->
                FilterChip(selected = selected == option, onClick = { onSelect(option) }, label = { Text(option) })
            }
        }
    }
}

@Composable
internal fun ChartCurve(
    reports: List<NovaPlanAnalytics.ChartReport>,
    mode: String,
    onPointClick: (NovaPlanAnalytics.ChartPoint) -> Unit
) {
    val chartHeight = 220.dp
    val chartSecondaryColor = MaterialTheme.colorScheme.secondary
    var scale by remember(reports.map { it.plan.planId to it.points.size }) { mutableFloatStateOf(1f) }
    var offsetX by remember(reports.map { it.plan.planId to it.points.size }) { mutableFloatStateOf(0f) }
    var offsetY by remember(reports.map { it.plan.planId to it.points.size }) { mutableFloatStateOf(0f) }
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            CaptionMuted(if (scale <= 1.01f) "双指缩放 · 放大后单指拖动 · 当前1x" else "拖动查看细节 · 当前${"%.1f".format(scale)}x")
            if (scale > 1.01f || kotlin.math.abs(offsetX) > 1f || kotlin.math.abs(offsetY) > 1f) {
                TextButton(onClick = { scale = 1f; offsetX = 0f; offsetY = 0f }) { Text("复位") }
            }
        }
        Box(
            Modifier.fillMaxWidth().height(chartHeight).clip(RoundedCornerShape(8.dp))
                .pointerInput(reports.map { it.points.size } to mode) {
                    detectTapGestures { pos ->
                        val r = reports.firstOrNull()
                        if (r != null && r.points.isNotEmpty()) {
                            val idx = ((pos.x / size.width) * r.points.size).roundToInt().coerceIn(0, r.points.lastIndex)
                            onPointClick(r.points[idx])
                        }
                    }
                }
                .pointerInput(reports.map { it.points.size }) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        val newScale = (scale * zoom).coerceIn(1f, 6f)
                        val ratio = if (scale > 0f) newScale / scale else 1f
                        scale = newScale
                        if (newScale <= 1.01f) {
                            scale = 1f
                            offsetX = 0f
                            offsetY = 0f
                        } else {
                            val maxX = size.width * (newScale - 1f)
                            val maxY = size.height * (newScale - 1f) * 0.4f
                            offsetX = (offsetX * ratio + pan.x).coerceIn(-maxX, maxX)
                            offsetY = (offsetY * ratio + pan.y).coerceIn(-maxY, maxY)
                        }
                    }
                }
        ) {
            Canvas(Modifier.fillMaxSize().graphicsLayer {
                scaleX = scale; scaleY = scale; translationX = offsetX; translationY = offsetY
            }) {
                val all = reports.flatMap { it.points }
                if (all.isEmpty()) return@Canvas
                val maxCount = reports.maxOf { it.points.size }.coerceAtLeast(1)
                val padL = 10f; val padR = 10f; val padT = 12f; val padB = 14f
                val cw = size.width - padL - padR; val ch = size.height - padT - padB
                fun x(i: Int): Float = if (maxCount <= 1) padL + cw / 2f else padL + cw * i / (maxCount - 1)
                fun valueAt(r: NovaPlanAnalytics.ChartReport, p: NovaPlanAnalytics.ChartPoint): Double = when (mode) {
                    "单期盈亏" -> p.periodProfit
                    "命中率" -> p.hitRate * 100.0
                    "涨跌趋势" -> if (p.periodProfit > 0) 1.0 else if (p.periodProfit < 0) -1.0 else 0.0
                    "回撤" -> p.drawdown
                    else -> p.cumulativeProfit
                }
                val values = reports.flatMap { r -> r.points.map { p -> valueAt(r, p) } }
                val modeMin = values.minOrNull() ?: 0.0
                val modeMax = values.maxOrNull() ?: 0.0
                val modeLo = minOf(0.0, modeMin)
                val modeHi = maxOf(0.0, modeMax)
                val modeRange = (modeHi - modeLo).coerceAtLeast(1.0) * 1.15
                fun y(v: Double): Float = padT + ch * (((modeHi - v) / modeRange).toFloat().coerceIn(0f, 1f))
                val zeroY = y(0.0)
                drawLine(Color(0xFF999999), Offset(padL, zeroY), Offset(size.width - padR, zeroY), 1.5f,
                    pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(8f, 6f)))
                reports.forEachIndexed { idx, r ->
                    val path = Path()
                    r.points.forEachIndexed { i, p ->
                        if (i == 0) path.moveTo(x(i), y(valueAt(r, p))) else path.lineTo(x(i), y(valueAt(r, p)))
                    }
                    // 与挂机页一致：红涨、绿跌。非收益指标保持主题色。
                    val positive = Color(0xFFC62828)
                    val negative = Color(0xFF2E7D32)
                    if (mode == "累计收益" || mode == "单期盈亏" || mode == "涨跌趋势") {
                        r.points.forEachIndexed { i, p ->
                            if (i == 0) return@forEachIndexed
                            val prev = r.points[i - 1]
                            val c = if (p.periodProfit >= 0.0) positive else negative
                            drawLine(c, Offset(x(i - 1), y(valueAt(r, prev))), Offset(x(i), y(valueAt(r, p))), 3.5f, cap = StrokeCap.Round)
                        }
                    } else {
                        drawPath(path, chartSecondaryColor, style = Stroke(width = 3f, cap = StrokeCap.Round))
                    }
                    val hiIdx = r.points.indices.maxByOrNull { r.points[it].cumulativeProfit } ?: -1
                    val loIdx = r.points.indices.minByOrNull { r.points[it].cumulativeProfit } ?: -1
                    if (hiIdx >= 0) drawCircle(positive, 4f, Offset(x(hiIdx), y(valueAt(r, r.points[hiIdx]))))
                    if (loIdx >= 0) drawCircle(negative, 4f, Offset(x(loIdx), y(valueAt(r, r.points[loIdx]))))
                }
            }
        }
        reports.forEach { r ->
            CaptionMuted("${r.plan.planName} · 最高 ${chartFmtMoney(r.maxPeak)} · 最低 ${chartFmtMoney(r.minTrough)} · 当前 ${chartFmtMoney(r.points.lastOrNull()?.cumulativeProfit ?: 0.0)}")
        }
    }
}
