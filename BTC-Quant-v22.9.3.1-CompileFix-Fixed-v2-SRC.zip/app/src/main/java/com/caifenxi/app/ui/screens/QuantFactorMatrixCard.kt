package com.caifenxi.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.caifenxi.app.domain.btc.factor.QuantFactorEngine

@Composable
fun QuantFactorMatrixCard(snapshot: QuantFactorEngine.Snapshot?) {
    if (snapshot == null) return
    val selected = listOf("TREND-COMPOSITE", "MOMENTUM-COMPOSITE", "DONCHIAN-20", "VOLUME-CONFIRM", "VOLATILITY-REGIME", "DIRECTIONAL-EFFICIENCY-20")
    Column(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 5.dp).background(Color(0xFF11151B), RoundedCornerShape(10.dp)).padding(10.dp)) {
        Text("FACTOR MATRIX", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
        Text("QF-3.0 · PIT · MTF research substrate", color = Color(0xFF6F7885), fontSize = 8.sp, modifier = Modifier.padding(top = 2.dp, bottom = 7.dp))
        selected.forEach { id ->
            val v = snapshot.value(id)
            Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(id, color = Color(0xFFB8C0CC), fontSize = 9.sp)
                Text(String.format("%+.3f", v), color = if (v >= 0) Color(0xFF69F0AE) else Color(0xFFFF6B6B), fontSize = 9.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}
