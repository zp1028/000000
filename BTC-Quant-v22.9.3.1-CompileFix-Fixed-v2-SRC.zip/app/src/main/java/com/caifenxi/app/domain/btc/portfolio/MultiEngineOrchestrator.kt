package com.caifenxi.app.domain.btc.portfolio

import com.caifenxi.app.domain.btc.BinanceDerivativesRepository
import com.caifenxi.app.domain.btc.BinanceMarketRepository
import com.caifenxi.app.domain.btc.BtcPlanEngine
import com.caifenxi.app.domain.btc.BtcSignalFactory
import com.caifenxi.app.domain.btc.DerivativesFeatureEngine
import com.caifenxi.app.domain.btc.TradingSignal
import com.caifenxi.app.domain.btc.ai.AiBrain
import com.caifenxi.app.domain.btc.ai.AiPolicy
import com.caifenxi.app.domain.btc.ai.AiPolicyConfig
import com.caifenxi.app.domain.btc.broker.BrokerResult
import com.caifenxi.app.domain.btc.broker.EventContractBroker
import com.caifenxi.app.domain.btc.broker.EventMarketBroker
import com.caifenxi.app.domain.btc.broker.PaperEventContractBroker
import com.caifenxi.app.domain.btc.broker.PerpBroker
import com.caifenxi.app.domain.btc.broker.PolymarketClobBroker
import com.caifenxi.app.domain.btc.event.EventContractEngine
import com.caifenxi.app.domain.btc.event.EventExpiryWindow
import com.caifenxi.app.domain.btc.futures.FuturesQuantConfig
import com.caifenxi.app.domain.btc.futures.FuturesQuantEngine
import com.caifenxi.app.domain.btc.futures.FuturesSignal
import com.caifenxi.app.domain.btc.news.CryptoNewsRepository
import com.caifenxi.app.domain.btc.polymarket.PolymarketEdgeEngine
import com.caifenxi.app.domain.btc.polymarket.strategy.PolymarketAutoQuantEngine
import com.caifenxi.app.domain.btc.polymarket.research.PolymarketHistoryStore
import com.caifenxi.app.domain.btc.polymarket.PolymarketRepository
import com.caifenxi.app.domain.btc.polymarket.PolymarketUserEventStream
import com.caifenxi.app.domain.btc.polymarket.PolymarketUserEventStore
import com.caifenxi.app.domain.btc.polymarket.strategy.PolymarketBinaryArbitrageEngine
import com.caifenxi.app.domain.btc.runtime.PolymarketSubmissionJournal
import com.caifenxi.app.domain.btc.runtime.PolymarketSubmissionUncertainty
import com.caifenxi.app.domain.btc.runtime.PolymarketOrderLifecycleStore
import com.caifenxi.app.domain.btc.runtime.PolymarketExecutionStateCenter
import com.caifenxi.app.domain.btc.runtime.PolymarketExecutionGuard
import com.caifenxi.app.domain.btc.runtime.PolymarketFundingGuard
import com.caifenxi.app.domain.btc.runtime.UnifiedExecutionGateway
import com.caifenxi.app.domain.btc.recovery.PolymarketRecoveryCenter
import com.caifenxi.app.domain.btc.engine.ExecutionIdempotency
import com.caifenxi.app.domain.btc.engine.MarketDataQualityGate
import com.caifenxi.app.domain.btc.risk.BtcRiskEngine
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope

data class OrchestratorReport(
    val perpSignal: TradingSignal.ContractSignal?,
    val perpResult: BrokerResult?,
    val futuresSignal: FuturesSignal? = null,
    val eventSignal: TradingSignal.EventContractSignal?,
    val eventResult: BrokerResult?,
    val polySignals: List<TradingSignal.PredictionMarketSignal>,
    val polyResults: List<BrokerResult>,
    val notes: List<String>
)

/**
 * Single tick across engines with shared features but isolated signals + portfolio shell.
 */
class MultiEngineOrchestrator(
    private val market: BinanceMarketRepository = BinanceMarketRepository(),
    private val derivRepo: BinanceDerivativesRepository = BinanceDerivativesRepository(),
    private val newsRepo: CryptoNewsRepository = CryptoNewsRepository(),
    private val planEngine: BtcPlanEngine = BtcPlanEngine(),
    private val signalFactory: BtcSignalFactory = BtcSignalFactory(),
    private val aiBrain: AiBrain = AiBrain(),
    private val aiPolicy: AiPolicyConfig = AiPolicyConfig(allowLiveAiOrders = false),
    private val perpRisk: BtcRiskEngine = BtcRiskEngine(),
    private val portfolio: PortfolioRiskEngine = PortfolioRiskEngine(),
    private val eventEngine: EventContractEngine = EventContractEngine(),
    private val polyRepo: PolymarketRepository = PolymarketRepository(),
    private val polyEdge: PolymarketEdgeEngine = PolymarketEdgeEngine(),
    private val polyAutoQuant: PolymarketAutoQuantEngine = PolymarketAutoQuantEngine(),
    private val polyHistoryStore: PolymarketHistoryStore? = null,
    private val perpBroker: PerpBroker? = null,
    private val eventBroker: EventContractBroker = PaperEventContractBroker(),
    private val polyBroker: EventMarketBroker = PolymarketClobBroker(dryRun = true),
    private val futuresEngine: FuturesQuantEngine = FuturesQuantEngine(),
    private val futuresConfig: FuturesQuantConfig = FuturesQuantConfig(),
    private val enableEvent: Boolean = true,
    private val enablePoly: Boolean = true,
    private val enableFutures: Boolean = false,
    private val polySubmissionJournal: PolymarketSubmissionJournal? = null,
    private val polyLifecycleStore: PolymarketOrderLifecycleStore? = null,
    private val polyExecutionGuard: PolymarketExecutionGuard? = null,
    private val polyFundingGuard: PolymarketFundingGuard? = null,
    /** v22.6: all order writes pass this single gateway. */
    private val executionGateway: UnifiedExecutionGateway = UnifiedExecutionGateway(perpBroker, eventBroker, polyBroker)
) {
    private var lastPolyLifecycleRefreshAt = 0L
    private var lastPolySettlementRefreshAt = 0L
    private var polyUserStreamStarted = false
    private var lastPolyHeartbeatAt = 0L
    private val polyUserEventStore = PolymarketUserEventStore()
    private val executionIdempotency = ExecutionIdempotency()
    suspend fun tick(
        symbol: String = "BTCUSDT",
        timeframe: String = "15m",
        portfolioState: PortfolioState = PortfolioState(),
        eventWindow: EventExpiryWindow = EventExpiryWindow.M30
    ): OrchestratorReport = coroutineScope {
        val notes = mutableListOf<String>()
        val candlesDef = async { market.loadKlines(symbol, timeframe, 300) }
        val fundingDef = async { runCatching { derivRepo.fundingHistory(symbol) }.getOrDefault(emptyList()) }
        val oiDef = async { runCatching { derivRepo.openInterestHistory(symbol, timeframe) }.getOrDefault(emptyList()) }
        val newsDef = async { runCatching { newsRepo.snapshot() }.getOrNull() }
        val candles = candlesDef.await()
        if (candles.size < 80) {
            return@coroutineScope OrchestratorReport(null, null, null, null, null, emptyList(), emptyList(), listOf("kline不足"))
        }
        val last = candles.last()
        val prev = candles.getOrNull(candles.lastIndex - 1)
        val quality = MarketDataQualityGate.evaluate(
            sampleCount = candles.size,
            latestTimestampMs = last.openTime,
            price = last.close,
            previousPrice = prev?.close,
            nowMs = System.currentTimeMillis(),
            maxAgeMs = 30_000L
        )
        if (!quality.ok) {
            return@coroutineScope OrchestratorReport(null, null, null, null, null, emptyList(), emptyList(), listOf("数据质量闸门：${quality.reason()}"))
        }
        val deriv = DerivativesFeatureEngine.build(last.openTime, last.close, prev?.close, fundingDef.await(), oiDef.await())
        val news = newsDef.await()
        if (news?.blackSwan == true) {
            return@coroutineScope OrchestratorReport(null, null, null, null, null, emptyList(), emptyList(), listOf("新闻黑天鹅：全引擎停开"))
        }
        val (basePlans, baseConsensus) = planEngine.evaluate(candles, deriv)
        val ai = aiBrain.generateCandidate(candles, basePlans, baseConsensus, news, deriv)
        val aiPlan = AiPolicy.toPlanSignal(ai, aiPolicy)
        val (plans, consensus) = if (aiPlan != null) planEngine.evaluate(candles, deriv, extraSignals = listOf(aiPlan))
        else basePlans to baseConsensus

        // --- Perp ---
        var perpSig: TradingSignal.ContractSignal? = null
        var perpRes: BrokerResult? = null
        var futuresSig: FuturesSignal? = null
        if (consensus != null) {
            val s = signalFactory.buildPerpSignal(symbol, candles, plans, consensus, 0.001)
            if (s != null) {
                val r1 = perpRisk.authorize(consensus, 0.0, 0.0, 5.0)
                val r2 = portfolio.authorizePerp(s, portfolioState, last.close)
                if (r1.allowed && r2.allowed) {
                    val cid = "P-${s.planId}-${s.barId}"
                    if (executionIdempotency.tryAcquire(cid)) {
                        perpSig = s
                        perpRes = if (perpBroker != null) {
                            runCatching {
                                val r = executionGateway.placePerp(s, cid)
                                BrokerResult(r.success, r.clientOrderId, r.message.ifBlank { r.status })
                            }.getOrElse { BrokerResult(false, null, it.message ?: "err") }
                        } else BrokerResult(true, "PERP-PAPER", "paper perp ${s.direction}")
                        if (perpRes?.ok == false) executionIdempotency.release(cid)
                    } else {
                        notes += "perp幂等拦截: $cid"
                    }
                } else notes += "perp拒绝: ${r1.reason}/${r2.reason}"
            }

            // --- Futures quant signal (shared consensus, independent execution) ---
            if (enableFutures) {
                futuresSig = futuresEngine.evaluateSignal(
                    consensus = consensus,
                    candles = candles,
                    config = futuresConfig,
                    balance = 10_000.0,
                    deriv = deriv
                )
                if (futuresSig != null) {
                    notes += "futures signal: ${futuresSig.direction} lev=${futuresSig.leverage}x conf=${"%.0f%%".format(futuresSig.confidence * 100)}"
                }
            }
        }

        // --- Event contract ---
        var eventSig: TradingSignal.EventContractSignal? = null
        var eventRes: BrokerResult? = null
        if (enableEvent && consensus != null) {
            val q = eventEngine.quote(symbol, eventWindow, consensus, candles)
            if (q != null) {
                val sig = eventEngine.toSignal(q, "${symbol}-${eventWindow}-${last.openTime}")
                if (sig != null) {
                    val pr = portfolio.authorizeEvent(sig, portfolioState)
                    if (pr.allowed) {
                        val eid = "E-${sig.underlying}-${sig.direction}-${last.openTime}"
                        if (executionIdempotency.tryAcquire(eid)) {
                            eventSig = sig
                            eventRes = executionGateway.placeEvent(sig)
                            if (eventRes?.ok == false) executionIdempotency.release(eid)
                        } else {
                            notes += "event幂等拦截: $eid"
                        }
                    } else notes += "event拒绝: ${pr.reason}"
                } else notes += "event无足够edge"
            }
        }

        // --- Polymarket ---
        if (enablePoly && polyHistoryStore != null && System.currentTimeMillis() - lastPolySettlementRefreshAt > 5 * 60_000L) {
            runCatching {
                val closed = polyRepo.searchClosedCryptoMarkets(80)
                closed.forEach { m ->
                    m.resolvedOutcome?.let { polyHistoryStore.settle(m.conditionId, it) }
                }
                lastPolySettlementRefreshAt = System.currentTimeMillis()
            }.onFailure { notes += "poly结算同步失败: ${it.message}" }
        }
        val polySigs = mutableListOf<TradingSignal.PredictionMarketSignal>()
        val polyResults = mutableListOf<BrokerResult>()
        val polyCandidates = mutableListOf<com.caifenxi.app.domain.btc.polymarket.strategy.PolymarketStrategyPool.Signal>()
        if (enablePoly) {
            // Restart/reconnect recovery must happen before new candidate submission.
            // An indeterminate write remains frozen until venue state is observed.
            if (polySubmissionJournal != null && polyBroker is PolymarketClobBroker && !polyBroker.capabilities.canPlaceLive) {
                // Dry-run/disabled execution does not need venue reconciliation.
            } else if (polySubmissionJournal != null) {
                runCatching {
                    val recovery = PolymarketRecoveryCenter(polyBroker, polySubmissionJournal).recoverPending()
                    recovery.filter { it.resolution != PolymarketRecoveryCenter.Resolution.SKIPPED }.forEach { r ->
                        notes += when (r.resolution) {
                            PolymarketRecoveryCenter.Resolution.CONFIRMED -> "poly恢复确认 ${r.intentKey} status=${r.status} filled=${"%.6f".format(r.filledSize)}"
                            PolymarketRecoveryCenter.Resolution.NOT_FOUND -> "poly恢复未找到 ${r.intentKey}：继续冻结，等待下一次对账"
                            PolymarketRecoveryCenter.Resolution.STILL_UNKNOWN -> "poly恢复仍未知 ${r.intentKey}: ${r.message}"
                            PolymarketRecoveryCenter.Resolution.SKIPPED -> ""
                        }
                    }
                }.onFailure { notes += "poly恢复中心异常: ${it.message}" }
            }
            if (polyLifecycleStore != null && polyBroker is PolymarketClobBroker) {
                runCatching { PolymarketExecutionStateCenter(polyLifecycleStore).reconcileLive(polyBroker) }
                    .onFailure { notes += "poly执行状态对账失败: ${it.message}" }
            }
            val modelYes = polyEdge.modelYesProbability(consensus, news?.netSentiment ?: 0.0)
            val markets = runCatching { polyRepo.searchCryptoMarkets(10) }.getOrElse {
                notes += "poly发现失败: ${it.message}"
                emptyList()
            }
            if (polyBroker is PolymarketClobBroker && (polyExecutionGuard?.heartbeatDue() == true || polyExecutionGuard == null) && System.currentTimeMillis() - lastPolyHeartbeatAt >= 8_000L) {
                runCatching {
                    val hb = polyBroker.sendHeartbeat()
                    polyExecutionGuard?.recordHeartbeat(hb)
                    if (hb.ok) lastPolyHeartbeatAt = System.currentTimeMillis()
                    else notes += "poly CLOB heartbeat失败: ${hb.message}"
                }.onFailure { notes += "poly CLOB heartbeat异常: ${it.message}" }
            }
            if (!polyUserStreamStarted && polyBroker is PolymarketClobBroker) {
                val privateMarkets = markets.take(5).map { it.conditionId }
                val stream = polyBroker.startUserStream(privateMarkets, object : PolymarketUserEventStream.Listener {
                    override fun onConnected() { notes += "poly私有User WS已连接" }
                    override fun onOrder(event: PolymarketUserEventStream.UserOrderEvent) {
                        polyUserEventStore.record(PolymarketUserEventStore.Event.Order(event))
                    }
                    override fun onTrade(event: PolymarketUserEventStream.UserTradeEvent) {
                        polyUserEventStore.record(PolymarketUserEventStore.Event.Trade(event))
                    }
                    override fun onError(message: String, throwable: Throwable?) { notes += "poly User WS: $message" }
                })
                polyUserStreamStarted = stream != null
                if (!polyUserStreamStarted) notes += "poly User WS未启动：需要LIVE L2凭证且非dry-run"
            }
            for (m in markets.take(5)) {
                val bookYes = runCatching { polyRepo.orderBook(m.yesTokenId) }.getOrNull()
                val bookNo = runCatching { polyRepo.orderBook(m.noTokenId) }.getOrNull()
                if (bookYes == null) {
                    notes += "poly跳过 ${m.slug}: YES盘口不可用"
                    continue
                }
                runCatching {
                    PolymarketBinaryArbitrageEngine.detect(m, bookYes, bookNo)?.let { arb ->
                        notes += "poly双腿套利候选 ${m.slug}: netEdge=${"%.3f".format(arb.netEdge)} size=${"%.2f".format(arb.size)}（仅生成执行意图，未拆腿下单）"
                    }
                }
                val auto = polyAutoQuant.evaluate(
                    candles = candles,
                    market = m,
                    yesBook = bookYes,
                    noBook = bookNo,
                    deriv = deriv,
                    externalModelYes = modelYes,
                    currentBtc = last.close
                )
                runCatching {
                    polyHistoryStore?.record(
                        market = m,
                        yesBook = bookYes,
                        noBook = bookNo,
                        currentBtc = last.close,
                        modelYes = modelYes,
                        candidates = auto.candidates
                    )
                }.onFailure { notes += "poly历史记录失败: ${it.message}" }
                val historyCount = runCatching { polyHistoryStore?.count() ?: 0L }.getOrDefault(0L)
                if (polyHistoryStore != null && historyCount >= 120L && historyCount % 60L == 0L &&
                    System.currentTimeMillis() - lastPolyLifecycleRefreshAt > 60_000L) {
                    runCatching {
                        val rows = polyHistoryStore.historyForAllStrategies()
                        val metrics = com.caifenxi.app.domain.btc.polymarket.research.PolymarketWalkForwardEngine.evaluate(rows)
                        val byId = metrics.associateBy { it.strategyId }
                        val decisions = com.caifenxi.app.domain.btc.polymarket.strategy.PolymarketStrategyPool.definitions.map { def ->
                            com.caifenxi.app.domain.btc.polymarket.research.PolymarketStrategyLifecycleEngine.evaluate(byId[def.id], def)
                        }
                        com.caifenxi.app.domain.btc.polymarket.strategy.PolymarketStrategyPool.applyLifecycle(decisions)
                        lastPolyLifecycleRefreshAt = System.currentTimeMillis()
                        notes += "poly策略生命周期刷新: ${metrics.size} 个策略"
                    }.onFailure { notes += "poly生命周期刷新失败: ${it.message}" }
                }
                if (!auto.autoEligible || auto.best == null) {
                    notes += "poly ${m.slug}: ${auto.reason}"
                    continue
                }
                polyCandidates += auto.candidates.take(4)
            }
            // Portfolio-level allocation happens only after all markets have competed.
            val correlation = runCatching {
                val rows = polyHistoryStore?.historyForAllStrategies().orEmpty()
                com.caifenxi.app.domain.btc.polymarket.strategy.PolymarketStrategyCorrelationEngine.fromSnapshots(rows)
            }.getOrDefault(emptyMap())
            val allocations = com.caifenxi.app.domain.btc.polymarket.strategy.PolymarketPortfolioAllocator.allocate(
                candidates = polyCandidates,
                bankroll = 10_000.0,
                maxPortfolioRisk = 0.02,
                maxMarketRisk = 0.0075,
                maxStrategyRisk = 0.006,
                correlation = correlation
            )
            allocations.forEach { allocation ->
                val s = allocation.signal
                val sig = polyAutoQuant.toExecutionSignal(s, size = allocation.notional.coerceAtLeast(1.0))
                val pr = portfolio.authorizeProb(sig, portfolioState, sizeUsdt = allocation.notional)
                if (!pr.allowed) {
                    notes += "poly拒绝 ${s.marketId}/${s.strategyId}: ${pr.reason}"
                } else {
                    val pid = "M-${s.marketId}-${s.strategyId}-${s.outcome}-${last.openTime}"
                    val journalBlocked = polySubmissionJournal?.pending(pid) == true
                    if (journalBlocked) {
                        val pending = polySubmissionJournal?.get(pid)
                        notes += "poly不确定提交拦截: $pid${pending?.orderId?.let { " order=$it" } ?: ""}；先完成对账，不自动重提"
                    } else if (executionIdempotency.tryAcquire(pid)) {
                        val guardDecision = polyExecutionGuard?.beforeOrder() ?: com.caifenxi.app.domain.btc.runtime.PolymarketExecutionGuard.Decision(true)
                        if (!guardDecision.allowed) {
                            executionIdempotency.release(pid)
                            notes += "poly执行闸门拦截 $pid: ${guardDecision.reason}"
                        } else {
                            val fundingDecision = if (polyBroker is PolymarketClobBroker) {
                                polyFundingGuard?.beforeOrder(polyBroker, sig, allocation.notional)
                                    ?: PolymarketFundingGuard.Decision(true)
                            } else {
                                PolymarketFundingGuard.Decision(true, "non-CLOB event broker")
                            }
                            if (!fundingDecision.allowed) {
                                executionIdempotency.release(pid)
                                notes += "poly资金/市场闸门拦截 $pid: ${fundingDecision.reason}"
                                return@forEach
                            }
                            polyExecutionGuard?.markOrderAttempt()
                            polySigs += sig
                            val result = executionGateway.placePrediction(sig)
                            polyFundingGuard?.afterOrder(allocation.notional, result.ok, result.indeterminate)
                            polyExecutionGuard?.afterOrder(result)
                            polyResults += result
                            when {
                            result.ok -> {
                                polySubmissionJournal?.resolve(pid)
                                if (polyLifecycleStore != null && result.orderId != null) {
                                    PolymarketExecutionStateCenter(polyLifecycleStore).recordSubmitted(
                                        executionId = pid, decisionId = pid, orderId = result.orderId,
                                        marketId = s.marketId, outcome = s.outcome, price = s.marketPrice,
                                        size = allocation.notional
                                    )
                                }
                            }
                            result.indeterminate -> {
                                polySubmissionJournal?.markUncertain(PolymarketSubmissionUncertainty(
                                    intentKey = pid, marketId = s.marketId, outcome = s.outcome,
                                    requestedSize = allocation.notional, requestedPrice = s.marketPrice,
                                    orderId = result.orderId, message = result.message
                                ))
                                if (polyLifecycleStore != null) {
                                    PolymarketExecutionStateCenter(polyLifecycleStore).recordIndeterminate(
                                        executionId = pid, decisionId = pid, orderId = result.orderId.orEmpty(),
                                        marketId = s.marketId, outcome = s.outcome, price = s.marketPrice,
                                        size = allocation.notional, message = result.message
                                    )
                                }
                            }
                            else -> {
                                executionIdempotency.release(pid)
                                if (polyLifecycleStore != null) {
                                    PolymarketExecutionStateCenter(polyLifecycleStore).recordRejected(
                                        executionId = pid, decisionId = pid, orderId = result.orderId.orEmpty(),
                                        marketId = s.marketId, outcome = s.outcome, price = s.marketPrice,
                                        size = allocation.notional, message = result.message
                                    )
                                }
                            }
                        }
                            notes += if (result.indeterminate) {
                                "poly组合执行结果不确定 ${s.strategyId} ${s.outcome}：已持久化冻结，禁止自动重提"
                            } else {
                                "poly组合执行 ${s.strategyId} ${s.outcome} edge=${"%.3f".format(s.edge)} ${allocation.reason}"
                            }
                        }
                    } else {
                        notes += "poly幂等拦截: $pid"
                    }
                }
            }
            if (allocations.isEmpty() && polyCandidates.isNotEmpty()) notes += "poly组合分配：Kelly/相关性/风险预算未产生可执行仓位"
            if (polyUserStreamStarted) {
                val recent = polyUserEventStore.latest(5)
                if (recent.isNotEmpty()) notes += "poly私有事件缓存: ${recent.size} 条（REST仍作为最终对账源）"
            }
        }

        OrchestratorReport(perpSig, perpRes, futuresSig, eventSig, eventRes, polySigs, polyResults, notes)
    }

    companion object {
        fun fromCredentials(
            creds: com.caifenxi.app.domain.btc.broker.BrokerCredentials,
            paperPerp: Boolean = false,
            polyHistoryStore: PolymarketHistoryStore? = null,
            polySubmissionJournal: PolymarketSubmissionJournal? = null
        ): MultiEngineOrchestrator = MultiEngineOrchestrator(
            perpBroker = com.caifenxi.app.domain.btc.broker.BrokerFactory.perp(creds, forcePaper = paperPerp),
            eventBroker = com.caifenxi.app.domain.btc.broker.BrokerFactory.eventContract(creds),
            polyBroker = com.caifenxi.app.domain.btc.broker.BrokerFactory.polymarket(creds),
            polyHistoryStore = polyHistoryStore,
            polySubmissionJournal = polySubmissionJournal,
            polyFundingGuard = PolymarketFundingGuard()
        )
    }
}
