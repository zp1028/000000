package com.caifenxi.app.domain.btc.hs

import android.content.Context
import com.caifenxi.app.domain.btc.BtcCandle
import kotlin.math.abs

/**
 * v17.9 heterogeneous local model pool. Each member is independently trained,
 * persisted and evaluated; runtime uses only validated members.
 */
class HsModelPool(private val context: Context? = null, private val tf: String) {
    private val lineage = ModelLineageStore(context)
    data class Member(val id:String, val result:BtcMlProbabilityModel.Result, val weight:Double)
    data class Ensemble(val probability:Double, val members:List<Member>, val confidence:Double, val disagreement:Double, val version:String)

    private val models = listOf(
        BtcMlProbabilityModel.forTimeframe(tf, context=context, modelId="LOGISTIC-FAST"),
        BtcMlProbabilityModel(epochs=14, learningRate=0.018, l2=0.0025, horizonBars=1, contextConfig(), BtcMlModelArtifactStore(context), tf, "LOGISTIC-STABLE"),
        BtcMlProbabilityModel(epochs=22, learningRate=0.010, l2=0.0060, horizonBars=1, contextConfig(), BtcMlModelArtifactStore(context), tf, "LOGISTIC-REGULARIZED")
    )

    private fun contextConfig() = HsRuntimeConfig.Default

    fun fit(candles:List<BtcCandle>):Ensemble {
        if(candles.size < 60) return Ensemble(0.5, emptyList(), 0.0, 0.0, VERSION)
        val byTime=candles.associateBy { it.openTime }
        lineage.resolveThrough(tf, candles.last().openTime, { target ->
            val current=byTime[target]
            val prev=candles.lastOrNull { it.openTime < target }
            current != null && prev != null && current.close >= prev.close
        })
        val results=models.mapIndexed { idx,m -> m.fitAndPredict(candles) to MODEL_IDS[idx] }
        val valid=results.filter { it.first.samples >= 20 && it.first.probability.isFinite() }
        if(valid.isEmpty()) return Ensemble(0.5, emptyList(), 0.0, 0.0, VERSION)
        val raw=valid.map { (r,id) ->
            val baseQuality=(0.55*r.hitRate + 0.45*(1.0-r.brierScore)).coerceIn(0.05,1.0)
            val fb=lineage.metrics(id, tf)
            val feedbackMultiplier=if(fb.third>=20) {
                val drift=lineage.drift(id,tf)
                (0.55 + 0.75 * (0.55*fb.second + 0.45*(1.0-fb.first)) * (1.0-drift*4.0)).coerceIn(0.35,1.20)
            } else 1.0
            val quality=(baseQuality*feedbackMultiplier).coerceIn(0.05,1.0)
            val stability=(1.0-abs(r.probability-r.rawProbability)).coerceIn(0.55,1.0)
            id to (quality*stability)
        }
        val sum=raw.sumOf { it.second }.coerceAtLeast(1e-9)
        val members=valid.map { (r,id) ->
            val observationId=ModelLineageEngine.observationId(id,tf,1,r.featureVersion,candles.last().openTime)
            lineage.record(ModelLineageEngine.Observation(observationId,id,tf,1,r.featureVersion,candles.firstOrNull()?.openTime ?: 0L,candles.last().let { r.probability },candles.last().openTime,System.currentTimeMillis()))
            Member(id,r,(raw.first { it.first==id }.second/sum).coerceAtLeast(0.02))
        }
        val total=members.sumOf { it.weight }.coerceAtLeast(1e-9)
        val p=members.sumOf { it.result.probability*it.weight }/total
        val disagreement=members.map { abs(it.result.probability-p) }.average().coerceIn(0.0,0.5)
        val confidence=(abs(p-0.5)*2.0*(1.0-disagreement*1.8)).coerceIn(0.0,1.0)
        return Ensemble(p.coerceIn(0.03,0.97),members,confidence,disagreement,VERSION)
    }

    companion object {
        const val VERSION="HS-MODEL-POOL-1.0"
        private val MODEL_IDS=listOf("LOGISTIC-FAST","LOGISTIC-STABLE","LOGISTIC-REGULARIZED")
    }
}
