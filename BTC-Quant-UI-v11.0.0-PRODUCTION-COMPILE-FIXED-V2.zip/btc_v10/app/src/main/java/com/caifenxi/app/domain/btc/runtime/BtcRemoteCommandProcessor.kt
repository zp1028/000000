package com.caifenxi.app.domain.btc.runtime

/** Applies only safe runtime controls. It cannot create an order. */
class BtcRemoteCommandProcessor(private val store: BtcRuntimeStore) {
    fun apply(command: BtcRemoteCommand): Boolean {
        if (command.expiresAt < System.currentTimeMillis()) return false
        return when (command.action.uppercase()) {
            "KILL", "STOP_ALL", "HALT_NEW_ORDERS" -> { store.setKillSwitch(true); true }
            "RESUME" -> { store.setKillSwitch(false); store.saveConfig(store.config().copy(enabled = true)); true }
            "STOP" -> { store.saveConfig(store.config().copy(enabled = false)); true }
            else -> false
        }
    }
}
