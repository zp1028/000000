package com.caifenxi.app.domain.btc.execution

/** Venue-independent order/fill reconciliation primitives. */
enum class ReconcileStatus { SYNCED, PARTIAL, DRIFT, STALE, UNKNOWN, ERROR }

data class ObservedOrder(
    val orderId: String,
    val executionId: String,
    val leg: String,
    val status: String,
    val requestedSize: Double,
    val filledSize: Double,
    val remainingSize: Double,
    val observedAtMs: Long,
    val venueEventAtMs: Long = observedAtMs
)

data class ReconciledOrder(
    val orderId: String,
    val executionId: String,
    val leg: String,
    val status: String,
    val requestedSize: Double,
    val filledSize: Double,
    val remainingSize: Double,
    val statusResult: ReconcileStatus,
    val staleMs: Long,
    val reason: String
)

object ExecutionReconciliationCore {
    private val terminal = setOf("FILLED", "CANCELED", "CANCELLED", "REJECTED", "EXPIRED")

    fun reconcile(local: ObservedOrder, venue: ObservedOrder, nowMs: Long, staleAfterMs: Long = 15_000L): ReconciledOrder {
        if (local.orderId != venue.orderId || local.executionId != venue.executionId) {
            return result(venue, ReconcileStatus.DRIFT, nowMs - venue.observedAtMs, "identity mismatch")
        }
        val stale = (nowMs - venue.observedAtMs).coerceAtLeast(0L)
        if (stale > staleAfterMs && venue.status.uppercase() !in terminal) {
            return result(venue, ReconcileStatus.STALE, stale, "venue state stale")
        }
        val fillDrift = kotlin.math.abs(local.filledSize - venue.filledSize)
        val remainDrift = kotlin.math.abs(local.remainingSize - venue.remainingSize)
        val sizeTolerance = 1e-9
        if (fillDrift > sizeTolerance || remainDrift > sizeTolerance || local.status.uppercase() != venue.status.uppercase()) {
            return result(venue, ReconcileStatus.DRIFT, stale, "local/venue state differs")
        }
        val status = when {
            venue.filledSize > 0.0 && venue.remainingSize > 0.0 -> ReconcileStatus.PARTIAL
            else -> ReconcileStatus.SYNCED
        }
        return result(venue, status, stale, "reconciled")
    }

    private fun result(v: ObservedOrder, s: ReconcileStatus, stale: Long, reason: String) = ReconciledOrder(
        v.orderId, v.executionId, v.leg, v.status, v.requestedSize,
        v.filledSize.coerceAtLeast(0.0), v.remainingSize.coerceAtLeast(0.0), s, stale, reason
    )
}
