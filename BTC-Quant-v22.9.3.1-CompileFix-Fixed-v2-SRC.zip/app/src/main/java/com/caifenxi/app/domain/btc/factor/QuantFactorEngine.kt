package com.caifenxi.app.domain.btc.factor

import com.caifenxi.app.domain.btc.BtcCandle
import com.caifenxi.app.domain.btc.BtcDirection
import com.caifenxi.app.domain.btc.DerivativesFeatures
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Quant operator + factor layer.
 * Every factor is point-in-time: only candles up to the supplied last bar are used.
 * Raw operators are intentionally reusable by both Binance/futures and Polymarket engines.
 */
object QuantFactorEngine {
    const val VERSION = "QF-3.0-PIT-MTF-RESEARCH"

    enum class Operator { RETURN, LOG_RETURN, EMA, EMA_SLOPE, SMA, RSI, ATR_PCT, STDDEV, ZSCORE, VOLUME_RATIO, DONCHIAN, VWAP, CORRELATION, RANGE_POSITION, EFFICIENCY, SKEW, VOLATILITY, CANDLE_STRUCTURE }

    data class Factor(
        val id: String,
        val value: Double,
        val normalized: Double,
        val operator: Operator,
        val horizon: Int,
        val description: String
    )

    data class Snapshot(
        val barTime: Long,
        val symbol: String,
        val timeframe: String,
        val factors: List<Factor>,
        val composite: Double,
        val direction: BtcDirection,
        val confidence: Double,
        val version: String = VERSION
    ) {
        fun value(id: String): Double = factors.firstOrNull { it.id == id }?.normalized ?: 0.0
    }

    fun calculate(candles: List<BtcCandle>, deriv: DerivativesFeatures? = null, symbol: String = "BTCUSDT", timeframe: String = ""): Snapshot? {
        if (candles.size < 60) return null
        val close = candles.map { it.close }
        val volume = candles.map { it.volume }
        val last = close.last()
        val ret5 = pctChange(close, 5)
        val ret20 = pctChange(close, 20)
        val ema9 = ema(close, 9)
        val ema21 = ema(close, 21)
        val ema50 = ema(close, 50)
        val emaSlope = if (ema21.size >= 6) (ema21.last() - ema21[ema21.lastIndex - 5]) / last else 0.0
        val rsi14 = rsi(close, 14)
        val atrPct = atr(candles, 14) / last.coerceAtLeast(1e-9)
        val volRatio = volume.takeLast(20).average() / volume.dropLast(20).takeLast(80).average().coerceAtLeast(1e-9)
        val volZ = zscore(volume, 30)
        val priceZ = zscore(close, 30)
        val rangeHigh = close.takeLast(20).maxOrNull() ?: last
        val rangeLow = close.takeLast(20).minOrNull() ?: last
        val breakout = when {
            last >= rangeHigh -> 1.0
            last <= rangeLow -> -1.0
            else -> ((last - rangeLow) / (rangeHigh - rangeLow).coerceAtLeast(1e-9) * 2.0 - 1.0)
        }
        val vwap = vwap(candles.takeLast(40))
        val vwapDistance = (last - vwap) / last.coerceAtLeast(1e-9)
        val trend = clamp((ema9.last() - ema50.last()) / (last * 0.003).coerceAtLeast(1e-9))
        val momentum = clamp((ret20 / 0.025) * 0.55 + ((rsi14 - 50.0) / 18.0) * 0.45)
        val meanRevert = clamp(-priceZ / 2.5)
        val volumeConfirm = clamp((volRatio - 1.0) * 1.5 * if (trend == 0.0) 0.0 else trend)
        val volatility = clamp((atrPct - 0.004) * 100.0)
        val derivScore = deriv?.derivativesScore ?: 0.0
        val funding = deriv?.fundingBias ?: 0.0
        val oiAlign = deriv?.priceOiAlign ?: 0.0

        // QF-2.0: orthogonal price/volume/volatility/structure factors.
        // All calculations are PIT-safe and use only candles up to the current bar.
        val rangePosition = rangePosition(candles, 20)
        val efficiency = directionalEfficiency(close, 20)
        val upVol = signedVolumeBias(candles, 20)
        val bodyWick = candleStructure(candles.takeLast(14))
        val volTrend = slope(volume.takeLast(30))
        val downsideVol = downsideReturnStdDev(close, 30)
        val upsideVol = upsideReturnStdDev(close, 30)
        val skew = returnSkew(close, 40)
        val trendPersistence = directionalPersistence(close, 30)

        val factors = listOf(
            Factor("RET-5", ret5, clamp(ret5 / 0.012), Operator.RETURN, 5, "5根收益率"),
            Factor("RET-20", ret20, clamp(ret20 / 0.03), Operator.RETURN, 20, "20根收益率"),
            Factor("LOGRET-20", logReturn(close, 20), clamp(logReturn(close, 20) / 0.03), Operator.LOG_RETURN, 20, "20根对数收益"),
            Factor("EMA-SLOPE-21", emaSlope, clamp(emaSlope / 0.006), Operator.EMA_SLOPE, 5, "EMA21斜率"),
            Factor("RSI-14", rsi14, clamp((rsi14 - 50.0) / 25.0), Operator.RSI, 14, "RSI标准化"),
            Factor("ATR-PCT-14", atrPct, volatility, Operator.ATR_PCT, 14, "ATR波动率"),
            Factor("STDDEV-30", returnStdDev(close, 30), clamp(returnStdDev(close, 30) / 0.02), Operator.STDDEV, 30, "30根收益波动"),
            Factor("PRICE-Z-30", priceZ, clamp(-priceZ / 2.5), Operator.ZSCORE, 30, "价格Z分数，偏离越大均值回归越强"),
            Factor("VOLUME-RATIO-20", volRatio, clamp((volRatio - 1.0) / 1.5), Operator.VOLUME_RATIO, 20, "成交量相对比"),
            Factor("VOLUME-Z-30", volZ, clamp(volZ / 3.0), Operator.ZSCORE, 30, "成交量Z分数"),
            Factor("DONCHIAN-20", breakout, breakout, Operator.DONCHIAN, 20, "20根通道位置/突破"),
            Factor("VWAP-DIST", vwapDistance, clamp(vwapDistance / 0.012), Operator.VWAP, 40, "价格相对VWAP"),
            Factor("TREND-COMPOSITE", trend, trend, Operator.EMA, 50, "EMA趋势复合"),
            Factor("MOMENTUM-COMPOSITE", momentum, momentum, Operator.RETURN, 20, "动量复合"),
            Factor("MEAN-REVERSION", meanRevert, meanRevert, Operator.ZSCORE, 30, "均值回归因子"),
            Factor("VOLUME-CONFIRM", volumeConfirm, volumeConfirm, Operator.VOLUME_RATIO, 20, "量价确认"),
            Factor("VOLATILITY-REGIME", volatility, volatility, Operator.ATR_PCT, 14, "波动状态"),
            Factor("FUNDING-BIAS", funding, funding, Operator.ZSCORE, 30, "资金费率拥挤反向因子"),
            Factor("OI-ALIGN", oiAlign, oiAlign, Operator.CORRELATION, 12, "价格/OI方向一致性"),
            Factor("DERIVATIVES-COMPOSITE", derivScore, derivScore, Operator.CORRELATION, 30, "衍生品复合因子"),
            Factor("RANGE-POSITION-20", rangePosition, rangePosition, Operator.RANGE_POSITION, 20, "20根区间位置"),
            Factor("DIRECTIONAL-EFFICIENCY-20", efficiency, efficiency, Operator.EFFICIENCY, 20, "方向效率，过滤震荡噪声"),
            Factor("SIGNED-VOLUME-BIAS-20", upVol, upVol, Operator.VOLUME_RATIO, 20, "主动量价方向偏置"),
            Factor("CANDLE-STRUCTURE-14", bodyWick, bodyWick, Operator.CANDLE_STRUCTURE, 14, "实体/影线结构"),
            Factor("VOLUME-TREND-30", clamp(volTrend / volume.takeLast(30).average().coerceAtLeast(1e-9) * 30.0), clamp(volTrend / volume.takeLast(30).average().coerceAtLeast(1e-9) * 30.0), Operator.VOLUME_RATIO, 30, "成交量趋势"),
            Factor("DOWNSIDE-VOL-30", clamp(downsideVol / 0.02), clamp(downsideVol / 0.02), Operator.VOLATILITY, 30, "下行波动"),
            Factor("UPSIDE-VOL-30", clamp(upsideVol / 0.02), clamp(upsideVol / 0.02), Operator.VOLATILITY, 30, "上行波动"),
            Factor("RETURN-SKEW-40", clamp(skew / 1.5), clamp(skew / 1.5), Operator.SKEW, 40, "收益偏度"),
            Factor("TREND-PERSISTENCE-30", trendPersistence, trendPersistence, Operator.EFFICIENCY, 30, "方向持续性")
        )
        val composite = clamp(
            trend * 0.18 + momentum * 0.16 + breakout * 0.12 + volumeConfirm * 0.08 +
                meanRevert * 0.08 + clamp(vwapDistance / 0.012) * 0.06 +
                derivScore * 0.16 + funding * 0.08 + oiAlign * 0.08
        )
        val direction = when {
            composite > 0.10 -> BtcDirection.UP
            composite < -0.10 -> BtcDirection.DOWN
            else -> BtcDirection.FLAT
        }
        return Snapshot(
            barTime = candles.last().openTime,
            symbol = symbol,
            timeframe = timeframe,
            factors = factors,
            composite = composite,
            direction = direction,
            confidence = abs(composite).coerceIn(0.0, 1.0)
        )
    }

    private fun rangePosition(candles: List<BtcCandle>, period: Int): Double {
        val w = candles.takeLast(period); val hi = w.maxOfOrNull { it.high } ?: return 0.0; val lo = w.minOfOrNull { it.low } ?: return 0.0
        return clamp((w.last().close - lo) / (hi - lo).coerceAtLeast(1e-12) * 2.0 - 1.0)
    }

    private fun directionalEfficiency(values: List<Double>, period: Int): Double {
        val w = values.takeLast(period); if (w.size < 3) return 0.0
        val net = abs(w.last() - w.first()); val path = w.zipWithNext().sumOf { abs(it.second - it.first) }.coerceAtLeast(1e-12)
        return clamp((net / path) * if (w.last() >= w.first()) 1.0 else -1.0)
    }

    private fun signedVolumeBias(candles: List<BtcCandle>, period: Int): Double {
        val w = candles.takeLast(period); val den = w.sumOf { it.volume }.coerceAtLeast(1e-12)
        return clamp(w.sumOf { if (it.close >= it.open) it.volume else -it.volume } / den)
    }

    private fun candleStructure(candles: List<BtcCandle>): Double {
        if (candles.isEmpty()) return 0.0
        val vals = candles.map { c ->
            val range = (c.high - c.low).coerceAtLeast(1e-12); val body = c.close - c.open
            val upper = c.high - max(c.open, c.close); val lower = min(c.open, c.close) - c.low
            clamp(body / range - (upper - lower) / range * 0.35)
        }
        return clamp(vals.average())
    }

    private fun slope(values: List<Double>): Double {
        if (values.size < 2) return 0.0
        val n = values.size.toDouble(); val meanX = (n - 1.0) / 2.0; val meanY = values.average()
        val num = values.indices.sumOf { (it - meanX) * (values[it] - meanY) }; val den = values.indices.sumOf { (it - meanX) * (it - meanX) }.coerceAtLeast(1e-12)
        return num / den
    }

    private fun downsideReturnStdDev(values: List<Double>, period: Int): Double = sideReturnStdDev(values, period, downside = true)
    private fun upsideReturnStdDev(values: List<Double>, period: Int): Double = sideReturnStdDev(values, period, downside = false)
    private fun sideReturnStdDev(values: List<Double>, period: Int, downside: Boolean): Double {
        val rs = values.zipWithNext { a,b -> if (a == 0.0) 0.0 else (b-a)/a }.takeLast(period).filter { if (downside) it < 0 else it > 0 }
        if (rs.size < 2) return 0.0; val m = rs.average(); return sqrt(rs.sumOf { (it-m)*(it-m) } / rs.size)
    }

    private fun returnSkew(values: List<Double>, period: Int): Double {
        val r = values.zipWithNext { a,b -> if (a == 0.0) 0.0 else (b-a)/a }.takeLast(period); if (r.size < 3) return 0.0
        val m=r.average(); val sd=sqrt(r.sumOf{(it-m)*(it-m)}/r.size).coerceAtLeast(1e-12); return r.sumOf{((it-m)/sd)*((it-m)/sd)*((it-m)/sd)}/r.size
    }

    private fun directionalPersistence(values: List<Double>, period: Int): Double {
        val r=values.zipWithNext{a,b -> if(b>=a) 1 else -1}.takeLast(period); if(r.isEmpty()) return 0.0; return clamp(r.average().toDouble())
    }

    fun pctChange(values: List<Double>, n: Int): Double {
        if (values.size <= n) return 0.0
        val base = values[values.lastIndex - n]
        return if (base == 0.0) 0.0 else (values.last() - base) / base
    }

    fun logReturn(values: List<Double>, n: Int): Double {
        if (values.size <= n) return 0.0
        val a = values[values.lastIndex - n].coerceAtLeast(1e-12)
        val b = values.last().coerceAtLeast(1e-12)
        return ln(b / a)
    }

    fun ema(values: List<Double>, period: Int): List<Double> {
        if (values.isEmpty()) return emptyList()
        val k = 2.0 / (period + 1.0)
        var prev = values.first()
        return values.mapIndexed { i, x -> if (i == 0) prev else { prev = x * k + prev * (1 - k); prev } }
    }

    fun sma(values: List<Double>, period: Int): Double = values.takeLast(period).average()

    fun rsi(values: List<Double>, period: Int): Double {
        if (values.size <= period) return 50.0
        var gain = 0.0; var loss = 0.0
        for (i in values.lastIndex - period + 1..values.lastIndex) {
            val d = values[i] - values[i - 1]
            if (d >= 0) gain += d else loss -= d
        }
        val avgGain = gain / period; val avgLoss = loss / period
        return if (avgLoss <= 1e-12) 100.0 else 100.0 - 100.0 / (1.0 + avgGain / avgLoss)
    }

    fun atr(candles: List<BtcCandle>, period: Int): Double {
        if (candles.size < 2) return 0.0
        val trs = candles.zipWithNext().map { (p, c) -> max(c.high - c.low, max(abs(c.high - p.close), abs(c.low - p.close))) }
        return trs.takeLast(period).average()
    }

    fun stddev(values: List<Double>, period: Int): Double {
        val x = values.takeLast(period)
        if (x.size < 2) return 0.0
        val m = x.average()
        return sqrt(x.sumOf { (it - m) * (it - m) } / x.size).let { if (m != 0.0) it / abs(m) else it }
    }

    fun returnStdDev(values: List<Double>, period: Int): Double {
        val returns = values.zipWithNext { a, b -> if (a == 0.0) 0.0 else (b - a) / a }.takeLast(period)
        if (returns.size < 2) return 0.0
        val m = returns.average()
        return sqrt(returns.sumOf { (it - m) * (it - m) } / returns.size)
    }

    fun zscore(values: List<Double>, period: Int): Double {
        val x = values.takeLast(period)
        if (x.size < 3) return 0.0
        val m = x.dropLast(1).average()
        val sd = sqrt(x.dropLast(1).map { (it - m) * (it - m) }.average()).coerceAtLeast(1e-12)
        return (x.last() - m) / sd
    }

    fun vwap(candles: List<BtcCandle>): Double {
        val den = candles.sumOf { it.volume }.coerceAtLeast(1e-12)
        return candles.sumOf { ((it.high + it.low + it.close) / 3.0) * it.volume } / den
    }

    fun clamp(v: Double): Double = v.coerceIn(-1.0, 1.0)
}
