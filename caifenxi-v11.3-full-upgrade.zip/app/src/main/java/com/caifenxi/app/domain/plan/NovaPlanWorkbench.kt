package com.caifenxi.app.domain.plan

import com.caifenxi.app.domain.model.DrawRecord
import com.caifenxi.app.domain.model.PlanDefinition
import kotlin.math.roundToInt

/** NovaPlan v1.1: 竞技场、稳定性、生命周期、组合与解释的纯计算层。 */
object NovaPlanWorkbench {
    data class ArenaRow(
        val plan: PlanDefinition,
        val report: NovaPlanAnalytics.BacktestReport,
        val stabilityGrade: String,
        val lifecycle: String,
        val rankScore: Double
    )

    data class Ensemble(val planIds: List<String>, val weights: Map<String, Double>)

    data class Explanation(
        val planId: String,
        val title: String,
        val inputWindow: Int,
        val output: String,
        val score: Double,
        val factors: List<Pair<String, Double>>
    )

    fun arena(history: List<DrawRecord>, periods: Int): List<ArenaRow> {
        if (history.size < 6) return emptyList()
        return NovaPlanPool.ALL.mapNotNull { plan ->
            val report = NovaPlanAnalytics.backtest(plan, history, periods)
            if (report.periods <= 0) return@mapNotNull null
            val stability = report.stability * 100.0
            val edge = report.edge * 100.0
            val streakPenalty = (report.maxMissStreak - 4).coerceAtLeast(0) * 1.5
            val rank = report.hitRate * 60.0 + report.stability * 25.0 + edge * 0.5 - streakPenalty
            val grade = when {
                stability >= 85 -> "A"
                stability >= 70 -> "B"
                stability >= 55 -> "C"
                else -> "D"
            }
            val lifecycle = when {
                report.periods < 20 -> "观察"
                rank >= 72 && report.edge >= 0.02 -> "活跃"
                report.maxMissStreak >= 8 || report.edge < -0.05 -> "暂停"
                rank < 50 -> "降权"
                else -> "验证"
            }
            ArenaRow(plan, report, grade, lifecycle, rank)
        }.sortedByDescending { it.rankScore }
    }

    fun ensemble(rows: List<ArenaRow>, count: Int = 5): Ensemble {
        val top = rows.filter { it.lifecycle != "暂停" }.take(count.coerceIn(1, 10))
        if (top.isEmpty()) return Ensemble(emptyList(), emptyMap())
        val raw = top.associate { it.plan.planId to it.rankScore.coerceAtLeast(1.0) }
        val total = raw.values.sum()
        return Ensemble(top.map { it.plan.planId }, raw.mapValues { it.value / total })
    }

    fun explain(plan: PlanDefinition, history: List<DrawRecord>): Explanation? {
        val result = NovaPlanAnalytics.predict(plan, history) ?: return null
        val data = history.takeLast(plan.window.coerceAtLeast(5))
        val factors = when (plan.algorithm) {
            "STATE" -> listOf("状态样本" to 1.0, "近期连续性" to 0.8, "状态切换" to 0.6)
            "RHYTHM" -> listOf("间隔节奏" to 1.0, "周期偏移" to 0.8, "近期变化" to 0.6)
            "NETWORK" -> listOf("共现关系" to 1.0, "网络中心" to 0.8, "局部团簇" to 0.6)
            "SIMILAR" -> listOf("历史相似" to 1.0, "结构匹配" to 0.8, "后续映射" to 0.7)
            "STRUCT" -> listOf("结构指纹" to 1.0, "奇偶结构" to 0.7, "分布结构" to 0.6)
            "ANOMALY" -> listOf("偏移检测" to 1.0, "异常程度" to 0.8, "恢复状态" to 0.6)
            "CANDIDATE" -> listOf("候选频次" to 1.0, "稳定候选" to 0.8, "覆盖度" to 0.6)
            else -> listOf("候选覆盖" to 1.0, "结构平衡" to 0.8, "计划共识" to 0.6)
        }
        return Explanation(plan.planId, plan.planName, data.size, result.output, result.score, factors)
    }

    fun versionLabel(plan: PlanDefinition): String = "${plan.planId}@v${NovaPlanRegistry.version(plan.planId)?.version ?: 1}"

    /** 计划重叠率：用于组合去重，0=完全不同，1=完全相同。 */
    fun overlap(a: String, b: String): Double {
        val sa = a.split("/", "、", ",").map { it.trim() }.filter { it.isNotEmpty() }.toSet()
        val sb = b.split("/", "、", ",").map { it.trim() }.filter { it.isNotEmpty() }.toSet()
        if (sa.isEmpty() && sb.isEmpty()) return 1.0
        if (sa.isEmpty() || sb.isEmpty()) return 0.0
        return sa.intersect(sb).size.toDouble() / sa.union(sb).size.toDouble()
    }

    /** 从竞技场中选择低重叠组合，优先保留高评分计划。 */
    fun diverseEnsemble(rows: List<ArenaRow>, count: Int = 5, maxOverlap: Double = 0.60): Ensemble {
        val selected = mutableListOf<ArenaRow>()
        for (row in rows.filter { it.lifecycle != "暂停" }.sortedByDescending { it.rankScore }) {
            if (selected.size >= count.coerceIn(1, 10)) break
            val tooSimilar = selected.any { a ->
                a.plan.algorithm == row.plan.algorithm && a.plan.window == row.plan.window
            }
            if (!tooSimilar) selected += row
        }
        if (selected.isEmpty()) return Ensemble(emptyList(), emptyMap())
        val raw = selected.associate { it.plan.planId to it.rankScore.coerceAtLeast(1.0) }
        val total = raw.values.sum()
        return Ensemble(selected.map { it.plan.planId }, raw.mapValues { it.value / total })
    }

    /** Monte Carlo 压力测试：保持样本量和基准概率，估计随机命中率达到观察值的频率。 */
    fun monteCarlo(random: kotlin.random.Random = kotlin.random.Random.Default, periods: Int, observedRate: Double, trials: Int = 2000): Double {
        val n = periods.coerceAtLeast(1)
        val t = trials.coerceAtLeast(100)
        var exceed = 0
        repeat(t) {
            var hit = 0
            repeat(n) { if (random.nextDouble() < 0.5) hit++ }
            if (hit.toDouble() / n >= observedRate) exceed++
        }
        return exceed.toDouble() / t
    }

}
