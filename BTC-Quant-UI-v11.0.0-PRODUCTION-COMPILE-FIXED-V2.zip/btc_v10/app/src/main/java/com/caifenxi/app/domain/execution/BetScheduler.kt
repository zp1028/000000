package com.caifenxi.app.domain.execution

import com.caifenxi.app.service.WebViewBetExecutor
import com.caifenxi.app.util.RuntimeLog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeout
import kotlin.coroutines.resume

/**
 * 下注调度器：按彩种排队，优先 WebView，其次无障碍。
 */
class BetScheduler(
    private val repository: ExecutionRepository,
    private val webViewExecutor: WebViewBetExecutor,
    private val accessibilityExecutor: Executor? = null,
    private val scope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
) {
    private val _isRunning = MutableStateFlow(false)
    val isRunning: StateFlow<Boolean> = _isRunning

    private val queues = mutableMapOf<String, ArrayDeque<ExecutionTask>>()
    private val activeJobs = mutableMapOf<String, Job>()

    fun attachWebView(webView: android.webkit.WebView) {
        webViewExecutor.attachWebView(webView)
    }

    fun dispatch(task: ExecutionTask) {
        val key = task.lotteryKey
        queues.getOrPut(key) { ArrayDeque() }.addLast(task)
        RuntimeLog.info(
            "Scheduler",
            "派发任务 cmdId=${task.cmdId} $key/${task.issue} 队列=${queues[key]?.size}"
        )
        triggerNext(key)
    }

    fun start() {
        _isRunning.value = true
        RuntimeLog.info("Scheduler", "调度器启动")
    }

    fun stop() {
        _isRunning.value = false
        activeJobs.values.forEach { it.cancel() }
        RuntimeLog.info("Scheduler", "调度器停止")
    }

    private fun triggerNext(lotteryKey: String) {
        if (!_isRunning.value) return
        if (activeJobs[lotteryKey]?.isActive == true) return
        val queue = queues[lotteryKey] ?: return
        val task = queue.removeFirstOrNull() ?: return
        activeJobs[lotteryKey] = scope.launch {
            try {
                executeTask(task)
            } finally {
                activeJobs.remove(lotteryKey)
                triggerNext(lotteryKey)
            }
        }
    }

    private suspend fun executeTask(task: ExecutionTask) {
        val cmd = task.command ?: run {
            RuntimeLog.warn("Scheduler", "任务无 command，跳过 cmdId=${task.cmdId}")
            return
        }
        RuntimeLog.info("Scheduler", "开始执行 cmdId=${cmd.cmdId} ${cmd.lotteryKey}/${cmd.issue}")

        if (cmd.expireAt > 0L && System.currentTimeMillis() > cmd.expireAt) {
            repository.expire(cmd.cmdId)
            RuntimeLog.warn("Scheduler", "任务过期 cmdId=${cmd.cmdId}")
            return
        }

        if (repository.isLotteryBlocked(cmd.lotteryKey) && task.state == ExecutionTask.State.CREATED) {
            RuntimeLog.warn("Scheduler", "彩种阻塞，稍后重试 cmdId=${cmd.cmdId}")
            queues.getOrPut(cmd.lotteryKey) { ArrayDeque() }.addFirst(task)
            delay(5000)
            return
        }

        // 类型不同：分支调用，避免 if 合并后变成无 execute 的公共类型
        val useWeb = webViewExecutor.isAvailable
        val useA11y = accessibilityExecutor?.isAvailable == true
        if (!useWeb && !useA11y) {
            repository.complete(
                cmd.cmdId,
                ExecutionResult.fail(cmd.cmdId, ExecutionResult.WEBVIEW_DISCONNECTED, "无可用执行器")
            )
            return
        }

        repository.transition(cmd.cmdId, ExecutionTask.State.CREATED, ExecutionTask.State.LOCKED)

        val result = try {
            withTimeout(12_000) {
                suspendCancellableCoroutine<ExecutionResult> { cont ->
                    val cb: (ExecutionResult) -> Unit = { res ->
                        if (cont.isActive) cont.resume(res)
                    }
                    val accepted = if (useWeb) {
                        webViewExecutor.execute(cmd, cb)
                    } else {
                        accessibilityExecutor!!.execute(cmd, cb)
                    }
                    if (!accepted && cont.isActive) {
                        cont.resume(
                            ExecutionResult.fail(
                                cmd.cmdId,
                                ExecutionResult.WEBVIEW_DISCONNECTED,
                                "执行器拒绝受理"
                            )
                        )
                    }
                }
            }
        } catch (_: TimeoutCancellationException) {
            ExecutionResult.timeout(cmd.cmdId, "执行超时(12s)")
        } catch (e: Exception) {
            ExecutionResult.unknown(cmd.cmdId, "异常: ${e.message}")
        }

        repository.complete(cmd.cmdId, result)
        RuntimeLog.info("Scheduler", "执行完成 cmdId=${cmd.cmdId} code=${result.code}")

        // 明确失败可有限重试一次（新 cmdId）
        if (result.code == ExecutionResult.ResultCode.FAILED && task.retryCount < 1) {
            val retryCmd = cmd.copy(
                cmdId = BetCommand.generateCmdId(cmd.lotteryKey, cmd.issue),
                expireAt = System.currentTimeMillis() + 60_000L
            )
            val retryTask = repository.create(retryCmd).copy(retryCount = task.retryCount + 1)
            delay(3000)
            dispatch(retryTask)
            RuntimeLog.info("Scheduler", "自动重试 ${cmd.cmdId} -> ${retryCmd.cmdId}")
        }
    }

    fun getQueueSize(lotteryKey: String): Int = queues[lotteryKey]?.size ?: 0

    fun clearQueue(lotteryKey: String) {
        queues[lotteryKey]?.clear()
        activeJobs[lotteryKey]?.cancel()
    }
}
