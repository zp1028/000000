package com.caifenxi.app.domain.btc.hs

import kotlin.math.abs

/** Pure decision logic for model lineage and post-live feedback. */
object ModelLineageEngine {
    data class Observation(
        val id: String,
        val modelId: String,
        val timeframe: String,
        val horizon: Int,
        val featureVersion: String,
        val datasetCutoffMs: Long,
        val predictedUp: Double,
        val barId: Long,
        val createdAtMs: Long
    )
    data class Feedback(
        val observationId: String,
        val modelId: String,
        val timeframe: String,
        val predictedUp: Double,
        val actualUp: Boolean,
        val brier: Double,
        val correct: Boolean,
        val resolvedAtMs: Long
    )

    fun observationId(modelId:String, tf:String, horizon:Int, featureVersion:String, barId:Long):String =
        "OBS-${modelId}-${tf}-${horizon}-${featureVersion}-${barId}"

    fun resolve(o: Observation, actualUp:Boolean, resolvedAtMs:Long): Feedback {
        val y = if (actualUp) 1.0 else 0.0
        val e = o.predictedUp - y
        return Feedback(o.id,o.modelId,o.timeframe,o.predictedUp,actualUp,e*e,(o.predictedUp >= .5)==actualUp,resolvedAtMs)
    }

    fun drift(recent: List<Feedback>, baseline: List<Feedback>): Double {
        if (recent.isEmpty() || baseline.isEmpty()) return 0.0
        val r = recent.map { it.brier }.average()
        val b = baseline.map { it.brier }.average()
        return abs(r-b)
    }
}
