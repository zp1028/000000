package com.caifenxi.app.ui.screens

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.caifenxi.app.domain.model.AutoClickPostAction
import com.caifenxi.app.domain.model.LotteryPlayCatalog
import com.caifenxi.app.domain.model.AutoClickPostActionsCodec
import com.caifenxi.app.service.AutoBetAccessibilityService
import com.caifenxi.app.service.AutoBetController
import com.caifenxi.app.service.DataSyncService
import com.caifenxi.app.service.FloatingOverlayStore
import com.caifenxi.app.ui.ClickRegionPickActivity
import com.caifenxi.app.ui.MainViewModel
import com.caifenxi.app.ui.components.CaptionMuted
import com.caifenxi.app.ui.components.GlobalCard
import com.caifenxi.app.ui.components.PrimaryButton
import com.caifenxi.app.ui.components.SectionTitle
import com.caifenxi.app.util.AndroidCompat
import com.caifenxi.app.ui.theme.CaiTokens
import java.util.UUID

@Composable
private fun A11ySwitch(title: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(title, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

/**
 * 无障碍跟投独立页：权限、可编排点击流水线、区域框选、试点击。
 */
@Composable
fun AccessibilityScreen(vm: MainViewModel) {
    val context = LocalContext.current
    val p = vm.prefs.value
    var a11yOn by remember { mutableStateOf(AutoBetController.isAccessibilityEnabled(context)) }
    var serviceRunning by remember { mutableStateOf(AutoBetAccessibilityService.isRunning()) }
    var postActions by remember(p.autoClickPostActionsJson) {
        mutableStateOf(AutoClickPostActionsCodec.decode(p.autoClickPostActionsJson))
    }
    var newText by remember { mutableStateOf("") }

    fun refreshFlags() {
        a11yOn = AutoBetController.isAccessibilityEnabled(context)
        serviceRunning = AutoBetAccessibilityService.isRunning()
    }

    fun savePostActions(list: List<AutoClickPostAction>) {
        postActions = list
        vm.updatePrefs { it.copy(autoClickPostActionsJson = AutoClickPostActionsCodec.encode(list)) }
    }

    fun reloadPostActionsFromPrefs() {
        try {
            val json = vm.prefs.value.autoClickPostActionsJson
            postActions = AutoClickPostActionsCodec.decode(json)
        } catch (_: Exception) {
        }
    }

    LaunchedEffect(Unit) { refreshFlags() }

    // 从框选页返回后必须重新读动作列表，否则「已框选」状态不刷新
    // 注意：禁止 ON_RESUME 全量 updatePrefs，避免覆盖正在编辑的其它项并引发重组风暴
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val obs = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                refreshFlags()
                try {
                    val app = com.caifenxi.app.CaiFenXiApplication.instance
                    val freshJson = app.configStore.loadPrefs().autoClickPostActionsJson
                    postActions = AutoClickPostActionsCodec.decode(freshJson)
                    // 仅同步动作 JSON 到 ViewModel，不动其它字段
                    if (vm.prefs.value.autoClickPostActionsJson != freshJson) {
                        vm.updatePrefs { it.copy(autoClickPostActionsJson = freshJson) }
                    }
                } catch (_: Exception) {
                    reloadPostActionsFromPrefs()
                }
            }
        }
        lifecycleOwner.lifecycle.addObserver(obs)
        onDispose { lifecycleOwner.lifecycle.removeObserver(obs) }
    }

    LazyColumn(
        Modifier
            .fillMaxSize()
            .padding(horizontal = CaiTokens.ScreenHPadding),
        verticalArrangement = Arrangement.spacedBy(CaiTokens.S8),
        contentPadding = PaddingValues(top = CaiTokens.S16, bottom = CaiTokens.ScreenBottom)
    ) {
        item {
            Text("无障碍跟投", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            CaptionMuted("全部动作可增删排序：挂机预测·大小 / 单双可分别开关；组合/位置数字/倍投金额/点击文字；每步可框选区域")
        }

        item {
            SectionTitle("权限与总控")
            GlobalCard {
                Text(
                    when {
                        !a11yOn -> "系统无障碍：未开启"
                        !serviceRunning -> "无障碍：已开但未连接，请重开一次服务"
                        else -> "无障碍：已就绪"
                    },
                    fontWeight = FontWeight.SemiBold
                )
                PrimaryButton("打开系统无障碍设置", {
                    AutoBetController.openAccessibilitySettings(context)
                    refreshFlags()
                }, Modifier.fillMaxWidth())
                Spacer(Modifier.height(6.dp))
                A11ySwitch("启用真实自动点击", p.autoClickEnabled) { enabled ->
                    if (enabled && !AutoBetController.isAccessibilityEnabled(context)) {
                        AutoBetController.openAccessibilitySettings(context)
                    }
                    vm.updatePrefs { it.copy(autoClickEnabled = enabled) }
                    refreshFlags()
                }
                A11ySwitch("仅模拟（不真实点击）", p.autoClickSimulateOnly) {
                    vm.updatePrefs { pref -> pref.copy(autoClickSimulateOnly = it) }
                }
                A11ySwitch("跟随挂机预测来源", p.autoClickFollowBetSource) {
                    vm.updatePrefs { pref -> pref.copy(autoClickFollowBetSource = it) }
                }
                val lotteryKey = vm.currentLottery.value.key
                val srcDesc = remember(p.autoClickFollowBetSource, lotteryKey, p.floatingSource) {
                    AutoBetController.describeClickSource(context, p, lotteryKey)
                }
                CaptionMuted(srcDesc + "（关则仍用设置页悬浮窗来源）")
                // 识别当前挂机/快照预测，便于核对与添加动作（可手动刷新）
                var predRefresh by remember { mutableStateOf(0) }
                val snap = remember(lotteryKey, vm.latest.value?.issue, predRefresh) {
                    FloatingOverlayStore.loadLastReady(context) ?: FloatingOverlayStore.load(context)
                }
                val predTriple = remember(snap, p.autoClickFollowBetSource, lotteryKey, predRefresh) {
                    if (snap == null) Triple(null as String?, null, null as String?)
                    else AutoBetController.resolveClickTargets(p, snap)
                }
                val predCombo = remember(snap, p.autoClickFollowBetSource, predRefresh) {
                    if (snap == null) null else AutoBetController.resolveCombo(snap, p)
                }
                val botDesc = remember(lotteryKey, predRefresh) {
                    AutoBetController.describeClickSource(context, p, lotteryKey)
                }
                Text(
                    "当前识别预测：大小=${predTriple.first ?: "—"}  单双=${predTriple.second ?: "—"}  组合=${predCombo ?: "—"}  期号=${snap?.targetIssue ?: "—"}",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp
                )
                CaptionMuted("来源：$botDesc")
                CaptionMuted("若显示「—」：①打开跟随挂机 ②挂机页选好来源并产生目标期预测 ③点下方「刷新识别」")
                PrimaryButton(
                    text = "刷新识别挂机预测",
                    onClick = { predRefresh++ },
                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                    ghost = true
                )
                A11ySwitch("无障碍控制悬浮窗", p.autoClickPanelEnabled) { enabled ->
                    if (enabled && !Settings.canDrawOverlays(context)) {
                        try {
                            context.startActivity(
                                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        } catch (_: Exception) {
                        }
                    }
                    vm.updatePrefs { it.copy(autoClickPanelEnabled = enabled) }
                    AndroidCompat.startDataSyncService(
                        context,
                        Intent(context, DataSyncService::class.java).setAction(DataSyncService.ACTION_REFRESH_OVERLAY)
                    )
                }
                A11ySwitch("显示点击红点", p.autoClickShowFeedback) {
                    vm.updatePrefs { pref -> pref.copy(autoClickShowFeedback = it) }
                }
                CaptionMuted("大小 / 单双已拆分为流水线里两个独立动作，可分别开关，互不影响。")
            }
        }

        item {
            SectionTitle("倍投 / 复原数字")
            GlobalCard {
                CaptionMuted("流水线中的「倍投/金额数字」动作会使用以下参数；需在动作列表中开启该步骤才会执行。")
                A11ySwitch("启用金额数字输入", p.autoInputEnabled) {
                    vm.updatePrefs { pref -> pref.copy(autoInputEnabled = it) }
                }
                A11ySwitch("查找并点击输入框", p.autoExecFindInput) {
                    vm.updatePrefs { pref -> pref.copy(autoExecFindInput = it) }
                }
                A11ySwitch("逐位点击金额数字", p.autoExecTypeAmount) {
                    vm.updatePrefs { pref -> pref.copy(autoExecTypeAmount = it) }
                }
                A11ySwitch("输数字前先清空", p.autoClickClearBeforeDigits) {
                    vm.updatePrefs { pref -> pref.copy(autoClickClearBeforeDigits = it) }
                }
                // 自由输入：不再使用滑动条，支持任意正数
                val baseDraft = remember {
                    mutableStateOf(
                        p.autoInputBaseAmount.let {
                            if (it == it.toLong().toDouble()) it.toLong().toString() else it.toString()
                        }
                    )
                }
                val multDraft = remember {
                    mutableStateOf(
                        p.autoInputMultAmount.let {
                            if (it == it.toLong().toDouble()) it.toLong().toString() else it.toString()
                        }
                    )
                }
                val applyHint = remember { mutableStateOf("") }
                LaunchedEffect(p.autoInputBaseAmount, p.autoInputMultAmount) {
                    val baseStr = p.autoInputBaseAmount.let {
                        if (it == it.toLong().toDouble()) it.toLong().toString() else it.toString()
                    }
                    val multStr = p.autoInputMultAmount.let {
                        if (it == it.toLong().toDouble()) it.toLong().toString() else it.toString()
                    }
                    if (baseDraft.value.toDoubleOrNull() == p.autoInputBaseAmount) {
                        baseDraft.value = baseStr
                    }
                    if (multDraft.value.toDoubleOrNull() == p.autoInputMultAmount) {
                        multDraft.value = multStr
                    }
                }
                OutlinedTextField(
                    value = baseDraft.value,
                    onValueChange = { s -> baseDraft.value = s.filter { c -> c.isDigit() || c == '.' } },
                    label = { Text("复原数字（基础金额）") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
                )
                OutlinedTextField(
                    value = multDraft.value,
                    onValueChange = { s -> multDraft.value = s.filter { c -> c.isDigit() || c == '.' } },
                    label = { Text("倍投数字") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
                )
                PrimaryButton(
                    text = "应用金额设置",
                    onClick = {
                        val base = baseDraft.value.toDoubleOrNull()
                        val mult = multDraft.value.toDoubleOrNull()
                        when {
                            base == null || base <= 0 -> applyHint.value = "复原数字无效，请输入大于 0 的数字"
                            mult == null || mult <= 0 -> applyHint.value = "倍投数字无效，请输入大于 0 的数字"
                            else -> {
                                vm.updatePrefs {
                                    it.copy(autoInputBaseAmount = base, autoInputMultAmount = mult)
                                }
                                applyHint.value = "已应用：复原=$base  倍投=$mult"
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                )
                if (applyHint.value.isNotBlank()) {
                    CaptionMuted(applyHint.value)
                }
                CaptionMuted(
                    "当前已生效：复原=${
                        p.autoInputBaseAmount.let {
                            if (it == it.toLong().toDouble()) it.toLong().toString() else it.toString()
                        }
                    }  倍投=${
                        p.autoInputMultAmount.let {
                            if (it == it.toLong().toDouble()) it.toLong().toString() else it.toString()
                        }
                    }"
                )
                Text("追号期数上限：${p.autoInputChaseMax}（1=仅当期金额）")
                Slider(
                    value = p.autoInputChaseMax.toFloat().coerceIn(1f, 10f),
                    onValueChange = { v ->
                        vm.updatePrefs { pref -> pref.copy(autoInputChaseMax = v.toInt().coerceIn(1, 20)) }
                    },
                    valueRange = 1f..10f,
                    steps = 8
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = p.autoInputRegionEnabled,
                        onClick = {
                            context.startActivity(
                                Intent(context, ClickRegionPickActivity::class.java)
                                    .putExtra(ClickRegionPickActivity.EXTRA_MODE, ClickRegionPickActivity.MODE_INPUT)
                            )
                        },
                        label = { Text(if (p.autoInputRegionEnabled) "已框数字键盘区" else "框选数字键盘区域") }
                    )
                    if (p.autoInputRegionEnabled) {
                        FilterChip(
                            selected = false,
                            onClick = {
                                vm.updatePrefs { pref ->
                                    pref.copy(
                                        autoInputRegionEnabled = false,
                                        autoInputRegionLeft = 0f,
                                        autoInputRegionTop = 0f,
                                        autoInputRegionRight = 1f,
                                        autoInputRegionBottom = 1f
                                    )
                                }
                            },
                            label = { Text("清除键盘区域") }
                        )
                    }
                }
                CaptionMuted("基础金额用于复原；倍投金额用于连错后加码。与挂机倍投策略配合使用。")
            }
        }

        item {
            SectionTitle("大小单双点击区域（全局）")
            GlobalCard {
                CaptionMuted("挂机预测·大小 / 单双默认使用此全局框选。框住投注页大/小/单/双按钮所在范围，可显著提高命中率。")
                CaptionMuted(
                    if (p.autoClickRegionEnabled)
                        "已设置 ✓ 左${(p.autoClickRegionLeft * 100).toInt()}% 上${(p.autoClickRegionTop * 100).toInt()}% 右${(p.autoClickRegionRight * 100).toInt()}% 下${(p.autoClickRegionBottom * 100).toInt()}%"
                    else "未设置 → 全屏搜索（容易点到赔率/其它「大」字）"
                )
                A11ySwitch("启用大小单双区域限制", p.autoClickRegionEnabled) {
                    vm.updatePrefs { pref -> pref.copy(autoClickRegionEnabled = it) }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = p.autoClickRegionEnabled,
                        onClick = {
                            context.startActivity(
                                Intent(context, ClickRegionPickActivity::class.java)
                                    .putExtra(ClickRegionPickActivity.EXTRA_MODE, ClickRegionPickActivity.MODE_CLICK)
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        },
                        label = { Text(if (p.autoClickRegionEnabled) "已框选·重选" else "框选大小单双区域") }
                    )
                    if (p.autoClickRegionEnabled) {
                        FilterChip(
                            selected = false,
                            onClick = {
                                vm.updatePrefs { pref ->
                                    pref.copy(
                                        autoClickRegionEnabled = false,
                                        autoClickRegionLeft = 0f,
                                        autoClickRegionTop = 0f,
                                        autoClickRegionRight = 1f,
                                        autoClickRegionBottom = 1f
                                    )
                                }
                            },
                            label = { Text("清除区域") }
                        )
                    }
                }
                CaptionMuted("提示：框宜略大一点完整罩住按钮；点开始后看红点是否落在目标上。")
            }
        }

        item {
            SectionTitle("点击动作流水线（可排序 / 增删）")
            CaptionMuted("全部动作可自由排序：挂机预测·大小、挂机预测·单双（可分别开关）、倍投金额、组合、位置数字、点击文字。可一键重置默认。")
            val lot = vm.currentLottery.value
            CaptionMuted("当前彩种玩法：" + LotteryPlayCatalog.summaryText(lot.type))
            PrimaryButton(
                "按当前彩种重置动作",
                {
                    val list = AutoClickPostAction.defaultsForLottery(lot.type)
                    postActions = list
                    savePostActions(list)
                },
                Modifier.fillMaxWidth(),
                ghost = true
            )
        }

        itemsIndexed(postActions, key = { _, a -> a.id }) { index, action ->
            GlobalCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        AutoClickPostAction.typeLabel(action.type) +
                            if (action.text.isNotBlank()) " · ${action.text}" else "",
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.weight(1f)
                    )
                    Switch(
                        checked = action.enabled,
                        onCheckedChange = { on ->
                            savePostActions(postActions.mapIndexed { i, a -> if (i == index) a.copy(enabled = on) else a })
                        }
                    )
                }
                // 文案类：必须填要点击的屏幕文字；其它类型也可填备注
                if (action.type == AutoClickPostAction.TYPE_TEXT || action.type == AutoClickPostAction.TYPE_PLAY) {
                    OutlinedTextField(
                        value = action.text,
                        onValueChange = { t ->
                            savePostActions(postActions.mapIndexed { i, a -> if (i == index) a.copy(text = t.take(16)) else a })
                        },
                        label = { Text("识别并点击的文字（必填）") },
                        placeholder = { Text("如：确认、投注、提交") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
                    )
                    CaptionMuted("运行时在框选区域内查找完全匹配或近似的按钮文案并点击。")
                }
                if (action.regionEnabled) {
                    CaptionMuted(
                        "已框选区域：L${(action.regionLeft * 100).toInt()}% T${(action.regionTop * 100).toInt()}% " +
                            "R${(action.regionRight * 100).toInt()}% B${(action.regionBottom * 100).toInt()}%"
                    )
                } else {
                    CaptionMuted("未框选区域 → 全屏搜索该动作文字（建议框选提高准确度）")
                }
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(
                        selected = false,
                        onClick = {
                            if (index > 0) {
                                val list = postActions.toMutableList()
                                val tmp = list[index - 1]
                                list[index - 1] = list[index]
                                list[index] = tmp
                                savePostActions(list)
                            }
                        },
                        label = { Text("上移") },
                        enabled = index > 0
                    )
                    FilterChip(
                        selected = false,
                        onClick = {
                            if (index < postActions.lastIndex) {
                                val list = postActions.toMutableList()
                                val tmp = list[index + 1]
                                list[index + 1] = list[index]
                                list[index] = tmp
                                savePostActions(list)
                            }
                        },
                        label = { Text("下移") },
                        enabled = index < postActions.lastIndex
                    )
                    FilterChip(
                        selected = action.regionEnabled,
                        onClick = {
                            context.startActivity(
                                Intent(context, ClickRegionPickActivity::class.java)
                                    .putExtra(ClickRegionPickActivity.EXTRA_MODE, ClickRegionPickActivity.MODE_ACTION)
                                    .putExtra(ClickRegionPickActivity.EXTRA_ACTION_ID, action.id)
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        },
                        label = { Text(if (action.regionEnabled) "已框选·重选" else "框选识别区域") }
                    )
                    if (action.regionEnabled) {
                        FilterChip(
                            selected = false,
                            onClick = {
                                savePostActions(
                                    postActions.mapIndexed { i, a ->
                                        if (i == index) a.copy(
                                            regionEnabled = false,
                                            regionLeft = 0f,
                                            regionTop = 0f,
                                            regionRight = 1f,
                                            regionBottom = 1f
                                        ) else a
                                    }
                                )
                            },
                            label = { Text("清除区域") }
                        )
                    }
                    FilterChip(
                        selected = false,
                        onClick = {
                            savePostActions(postActions.filterIndexed { i, _ -> i != index })
                        },
                        label = { Text("删除") }
                    )
                }
            }
        }

        item {
            GlobalCard {
                Text("添加动作", fontWeight = FontWeight.SemiBold)
                CaptionMuted("挂机预测·大小 / 挂机预测·单双 为两个独立动作，可分别添加与开关。执行时自动读取挂机下单或 Bot 配置方向。")
                // 根据当前识别到的挂机预测一键添加（与上方「刷新识别」共用逻辑）
                val liveSnap = FloatingOverlayStore.loadLastReady(context) ?: FloatingOverlayStore.load(context)
                val livePred = if (liveSnap != null) AutoBetController.resolveClickTargets(p, liveSnap) else Triple(null, null, null)
                val liveCombo = if (liveSnap != null) AutoBetController.resolveCombo(liveSnap, p) else null
                val hasLive = livePred.first != null || livePred.second != null || liveCombo != null
                if (hasLive) {
                    CaptionMuted("已识别：大小=${livePred.first ?: "—"} 单双=${livePred.second ?: "—"} 组合=${liveCombo ?: "—"}，可一键加入：")
                } else {
                    CaptionMuted("暂未识别到具体方向。仍可添加「挂机预测·大小/单双」动作；运行时会自动跟挂机结果。也可点上方「刷新识别」。")
                }
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    // 始终可加大小/单双（识别到方向时显示在标签上）
                    FilterChip(
                        selected = false,
                        onClick = {
                            if (postActions.none { it.type == AutoClickPostAction.TYPE_PRED_DX }) {
                                val dir = livePred.first
                                savePostActions(
                                    postActions + AutoClickPostAction(
                                        id = "pred_dx_" + UUID.randomUUID().toString().take(4),
                                        type = AutoClickPostAction.TYPE_PRED_DX,
                                        enabled = true,
                                        text = if (dir != null) "大小·$dir" else "大小"
                                    )
                                )
                            }
                        },
                        label = { Text(if (livePred.first != null) "+ 大小(${livePred.first})" else "+ 挂机预测·大小") }
                    )
                    FilterChip(
                        selected = false,
                        onClick = {
                            if (postActions.none { it.type == AutoClickPostAction.TYPE_PRED_DS }) {
                                val dir = livePred.second
                                savePostActions(
                                    postActions + AutoClickPostAction(
                                        id = "pred_ds_" + UUID.randomUUID().toString().take(4),
                                        type = AutoClickPostAction.TYPE_PRED_DS,
                                        enabled = true,
                                        text = if (dir != null) "单双·$dir" else "单双"
                                    )
                                )
                            }
                        },
                        label = { Text(if (livePred.second != null) "+ 单双(${livePred.second})" else "+ 挂机预测·单双") }
                    )
                    liveCombo?.let { c ->
                        FilterChip(
                            selected = false,
                            onClick = {
                                if (postActions.none { it.type == AutoClickPostAction.TYPE_COMBO }) {
                                    savePostActions(
                                        postActions + AutoClickPostAction(
                                            id = "combo_" + UUID.randomUUID().toString().take(4),
                                            type = AutoClickPostAction.TYPE_COMBO,
                                            enabled = true,
                                            text = "组合·$c"
                                        )
                                    )
                                }
                            },
                            label = { Text("+ 组合($c)") }
                        )
                    }
                }
                CaptionMuted("其他动作：")
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(
                        AutoClickPostAction.TYPE_BET_AMOUNT to "金额数字",
                        AutoClickPostAction.TYPE_COMBO to "组合",
                        AutoClickPostAction.TYPE_PRED_NUMBERS to "位置数字"
                    ).forEach { (ty, label) ->
                        FilterChip(
                            selected = false,
                            onClick = {
                                if (postActions.none { it.type == ty }) {
                                    savePostActions(
                                        postActions + AutoClickPostAction(
                                            id = ty + "_" + UUID.randomUUID().toString().take(4),
                                            type = ty,
                                            enabled = true,
                                            text = label
                                        )
                                    )
                                }
                            },
                            label = { Text("+ $label") }
                        )
                    }
                }
                OutlinedTextField(
                    value = newText,
                    onValueChange = { newText = it.take(16) },
                    label = { Text("自定义点击文字，如：确认 / 投注") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                CaptionMuted("添加后可在该动作上点「框选识别区域」，限定只在框内找这段文字。")
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PrimaryButton(
                        text = "添加文字动作",
                        onClick = {
                            val t = newText.trim()
                            if (t.isNotEmpty()) {
                                savePostActions(
                                    postActions + AutoClickPostAction(
                                        id = UUID.randomUUID().toString().take(8),
                                        type = AutoClickPostAction.TYPE_TEXT,
                                        enabled = true,
                                        text = t
                                    )
                                )
                                newText = ""
                            }
                        },
                        modifier = Modifier.weight(1f)
                    )
                    PrimaryButton(
                        text = "添加并框选",
                        onClick = {
                            val t = newText.trim()
                            if (t.isEmpty()) return@PrimaryButton
                            val id = UUID.randomUUID().toString().take(8)
                            savePostActions(
                                postActions + AutoClickPostAction(
                                    id = id,
                                    type = AutoClickPostAction.TYPE_TEXT,
                                    enabled = true,
                                    text = t
                                )
                            )
                            newText = ""
                            context.startActivity(
                                Intent(context, ClickRegionPickActivity::class.java)
                                    .putExtra(ClickRegionPickActivity.EXTRA_MODE, ClickRegionPickActivity.MODE_ACTION)
                                    .putExtra(ClickRegionPickActivity.EXTRA_ACTION_ID, id)
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        },
                        modifier = Modifier.weight(1f),
                        ghost = true
                    )
                }
                // 当前彩种扩展玩法
                val plays = LotteryPlayCatalog.plays(vm.currentLottery.value.type)
                if (plays.isNotEmpty()) {
                    CaptionMuted("当前彩种玩法标签（可添加为点击）")
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        plays.take(8).forEach { play ->
                            FilterChip(
                                selected = false,
                                onClick = {
                                    savePostActions(
                                        postActions + AutoClickPostAction(
                                            id = "play_" + play.id + UUID.randomUUID().toString().take(3),
                                            type = AutoClickPostAction.TYPE_PLAY,
                                            enabled = true,
                                            text = play.label.take(6)
                                        )
                                    )
                                },
                                label = { Text("+ ${play.label}") }
                            )
                        }
                    }
                }
            }
        }

        item {
            SectionTitle("参数")
            GlobalCard {
                Text("点击间隔：${p.autoClickDelayMs}ms")
                Slider(
                    value = p.autoClickDelayMs.toFloat(),
                    onValueChange = { v -> vm.updatePrefs { it.copy(autoClickDelayMs = v.toLong().coerceIn(100L, 2000L)) } },
                    valueRange = 100f..2000f
                )
                Text("连续失败停点：${p.autoClickFailStopCount} 次（0=不限制）")
                Slider(
                    value = p.autoClickFailStopCount.toFloat(),
                    onValueChange = { v -> vm.updatePrefs { it.copy(autoClickFailStopCount = v.toInt().coerceIn(0, 10)) } },
                    valueRange = 0f..10f,
                    steps = 9
                )
            }
        }

        item {
            SectionTitle("试点击")
            GlobalCard {
                CaptionMuted("不记挂机订单；请先切到投注页再点。会走完整流水线（含已开启的后续动作）。")
                PrimaryButton("立即试跑一轮", {
                    refreshFlags()
                    AutoBetController.tryNow(context)
                }, Modifier.fillMaxWidth())
            }
        }
    }
}
