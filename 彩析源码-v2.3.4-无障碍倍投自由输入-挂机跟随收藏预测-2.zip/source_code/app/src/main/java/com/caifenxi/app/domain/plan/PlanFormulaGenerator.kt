package com.caifenxi.app.domain.plan

import com.caifenxi.app.domain.model.LotteryType
import com.caifenxi.app.domain.model.PlanDefinition
import kotlin.math.absoluteValue

/**
 * 新计划生成器 V2：不再随机拼“玩法+算法+窗口”造成重复，而是从候选策略空间采样。
 * 每个候选已经绑定玩法、位置、算法、窗口；因此同一算法在不同位置是独立计划。
 */
object PlanFormulaGenerator {
    fun generate(
        type: LotteryType,
        count: Int = 20,
        seedIssue: String = "",
        salt: Int = 0
    ): List<PlanDefinition> {
        val candidates = PlanPoolV2.candidates(type)
        if (candidates.isEmpty()) return emptyList()
        val n = count.coerceIn(1, 100)
        val seed = seedIssue.hashCode().toLong().absoluteValue + salt * 9973L + type.name.hashCode()
        val shuffled = candidates.shuffled(java.util.Random(seed))
        return shuffled.take(n).mapIndexed { index, base ->
            base.copy(
                planId = "NOVA-GEN-V2-${type.name}-${seedIssue}-${salt}-${index}",
                planName = "${base.planName}·生成${index + 1}",
                category = "NovaGen|${type.name}|${base.playType}",
                randomGenerated = true,
                seedIssue = seedIssue,
                participateConsensus = base.participateConsensus
            )
        }
    }
}
