package com.caifenxi.app.data.config

import android.content.Context
import com.caifenxi.app.domain.model.ConsensusRecord
import com.caifenxi.app.domain.model.ConsensusStats
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

class ConsensusStore(context: Context) {
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
    private val prefs = context.getSharedPreferences("caifenxi_consensus", Context.MODE_PRIVATE)

    fun loadAll(lotteryKey: String? = null): List<ConsensusRecord> {
        val raw = prefs.getString(KEY, null) ?: return emptyList()
        return try {
            val list = json.decodeFromString<List<ConsensusRecord>>(raw)
            if (lotteryKey == null) list else list.filter { it.lotteryKey == lotteryKey }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun saveAll(list: List<ConsensusRecord>) {
        prefs.edit().putString(KEY, json.encodeToString(list.takeLast(500))).apply()
    }

    fun upsert(record: ConsensusRecord) {
        val list = loadAll().toMutableList()
        val idx = list.indexOfFirst { it.id == record.id }
        if (idx >= 0) {
            // 不覆盖已结算
            if (list[idx].result != "待开" && record.result == "待开") return
            list[idx] = record
        } else list.add(record)
        saveAll(list)
    }

    fun clear(lotteryKey: String? = null) {
        if (lotteryKey == null) prefs.edit().remove(KEY).apply()
        else saveAll(loadAll().filter { it.lotteryKey != lotteryKey })
    }

    fun stats(lotteryKey: String): ConsensusStats {
        val all = loadAll(lotteryKey)
        val settled = all.filter { it.result == "对" || it.result == "错" }
        val hit = settled.count { it.result == "对" }
        val miss = settled.count { it.result == "错" }

        val chrono = StreakCalc.chronoOf(settled, { it.targetIssue }, { it.createdAt }, { it.id })
        val (recent, maxH, maxM) = StreakCalc.streaksOf(chrono.map { it.result })
        val results = chrono.map { it.result }
        val (w2, w2Hit, w2Miss) = StreakCalc.windowRates(results, 2)
        val (w3, w3Hit, w3Miss) = StreakCalc.windowRates(results, 3)

        // 每个分类（大小/单双/组合）各自的完整统计：连击 + 两期/三期窗口率
        val byCat = settled.groupBy { it.category }.mapValues { (_, rows) ->
            val gChrono = StreakCalc.chronoOf(rows, { it.targetIssue }, { it.createdAt }, { it.id })
            StreakCalc.buildCategoryStats(gChrono.map { it.result })
        }

        return ConsensusStats(
            total = all.size,
            pending = all.count { it.result == "待开" },
            hit = hit,
            miss = miss,
            hitRate = if (hit + miss == 0) 0.0 else hit.toDouble() / (hit + miss),
            byCategory = byCat,
            recentStreak = recent,
            maxHitStreak = maxH,
            maxMissStreak = maxM,
            twoWindows = w2,
            twoHitRate = if (w2 > 0) w2Hit.toDouble() / w2 else 0.0,
            twoMissRate = if (w2 > 0) w2Miss.toDouble() / w2 else 0.0,
            threeWindows = w3,
            threeHitRate = if (w3 > 0) w3Hit.toDouble() / w3 else 0.0,
            threeMissRate = if (w3 > 0) w3Miss.toDouble() / w3 else 0.0
        )
    }

    companion object {
        private const val KEY = "consensus_records"
    }
}
