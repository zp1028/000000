package com.caifenxi.app.domain.engine

import com.caifenxi.app.data.config.ConsensusStore
import com.caifenxi.app.domain.model.ConsensusRecord
import com.caifenxi.app.domain.model.DrawRecord
import com.caifenxi.app.domain.model.ModelConsensus

object ConsensusEngine {

    suspend fun recordPending(
        store: ConsensusStore,
        lotteryKey: String,
        targetIssue: String,
        list: List<ModelConsensus>
    ) {
        list.forEach { c ->
            val parts = c.leadingDirection.split("/", "、", ",")
                .map { it.trim() }.filter { it.isNotEmpty() }
            val id = "$lotteryKey|$targetIssue|${c.category}"
            store.upsert(
                ConsensusRecord(
                    id = id,
                    lotteryKey = lotteryKey,
                    targetIssue = targetIssue,
                    category = c.category,
                    leadingDirection = c.leadingDirection,
                    candidates = parts.ifEmpty { listOf(c.leadingDirection) },
                    supportRatio = c.supportRatio,
                    participatingPlans = c.participatingPlans,
                    result = "待开"
                )
            )
        }
    }

    suspend fun settleWithDraw(store: ConsensusStore, lotteryKey: String, draw: DrawRecord) {
        settleWithDraws(store, lotteryKey, listOf(draw))
    }

    /**
     * 批量结算：一次加载、内存结算、一次保存（原实现逐期全量读写，历史一多会严重卡顿）。
     */
    suspend fun settleWithDraws(store: ConsensusStore, lotteryKey: String, draws: List<DrawRecord>) {
        if (draws.isEmpty()) return
        val all = store.loadAll(lotteryKey)
        val pending = all.filter { it.result == "待开" }
        if (pending.isEmpty()) return
        val byId = all.associateBy { it.id }.toMutableMap()
        var changed = false
        for (r in pending) {
            val draw = draws.firstOrNull { issueReached(r.targetIssue, it.issue) } ?: continue
            val actual = when (r.category) {
                "大小" -> draw.dx
                "单双" -> draw.ds
                "组合" -> draw.combo
                "位置-冠军" -> draw.numberAt(0)?.toString()
                "位置-亚军" -> draw.numberAt(1)?.toString()
                "位置-第3" -> draw.numberAt(2)?.toString()
                else -> null
            } ?: continue
            val cands = r.candidates.ifEmpty {
                r.leadingDirection.split("/").map { it.trim() }.filter { it.isNotEmpty() }
            }
            val hit = cands.any { it == actual }
            byId[r.id] = r.copy(
                actual = actual,
                result = if (hit) "对" else "错",
                settledAt = System.currentTimeMillis()
            )
            changed = true
        }
        if (changed) store.saveAll(byId.values.toList())
    }

    /** 仅精确匹配期号结算，避免用后期开奖结果错误结算前期预测 */
    private fun issueReached(pred: String, draw: String): Boolean =
        pred == draw || (
            pred.toLongOrNull() != null &&
            draw.toLongOrNull() != null &&
            pred.toLongOrNull() == draw.toLongOrNull()
        )

}
