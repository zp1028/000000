package com.caifenxi.app.domain.btc.hs

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.ArrayDeque

/** Immutable compact market/decision snapshots for audit and deterministic replay. */
class HsSnapshotStore(context: Context? = null, private val maxRecords: Int = 1000) {
    data class Record(
        val id: String, val at: Long, val symbol: String, val timeframe: String,
        val mark: Double, val pHat: Double, val direction: String,
        val marketYes: Double, val bid: Double, val ask: Double,
        val edge: Double, val opportunity: Double, val quality: Double,
        val regime: String, val modelVersion: String
    )
    private val rows = ArrayDeque<Record>()
    private val prefs = context?.applicationContext?.getSharedPreferences("btc_hs_snapshot_v1", Context.MODE_PRIVATE)
    init { load() }

    @Synchronized fun append(r: Record) {
        if (r.id.isBlank()) return
        if (rows.any { it.id == r.id }) return
        rows.addLast(r); while (rows.size > maxRecords) rows.removeFirst(); persist()
    }
    @Synchronized fun recent(limit: Int = 100): List<Record> = rows.toList().takeLast(limit.coerceAtMost(maxRecords))
    @Synchronized fun find(id: String): Record? = rows.lastOrNull { it.id == id }
    @Synchronized fun size(): Int = rows.size

    private fun load() = runCatching {
        val a = JSONArray(prefs?.getString("rows", "[]") ?: "[]")
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            rows.addLast(Record(o.getString("id"),o.getLong("at"),o.getString("symbol"),o.getString("tf"),o.getDouble("mark"),o.getDouble("p"),o.getString("dir"),o.getDouble("my"),o.getDouble("bid"),o.getDouble("ask"),o.getDouble("edge"),o.getDouble("opp"),o.getDouble("q"),o.getString("regime"),o.getString("model")))
        }
        while (rows.size > maxRecords) rows.removeFirst()
    }
    private fun persist() {
        val p = prefs ?: return; val a = JSONArray()
        rows.forEach { r -> a.put(JSONObject().apply { put("id",r.id);put("at",r.at);put("symbol",r.symbol);put("tf",r.timeframe);put("mark",r.mark);put("p",r.pHat);put("dir",r.direction);put("my",r.marketYes);put("bid",r.bid);put("ask",r.ask);put("edge",r.edge);put("opp",r.opportunity);put("q",r.quality);put("regime",r.regime);put("model",r.modelVersion) }) }
        p.edit().putString("rows", a.toString()).apply()
    }
}
