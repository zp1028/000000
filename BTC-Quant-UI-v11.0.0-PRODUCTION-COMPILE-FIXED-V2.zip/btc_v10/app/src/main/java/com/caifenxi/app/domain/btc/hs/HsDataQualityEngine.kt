package com.caifenxi.app.domain.btc.hs

/**
 * 数据质量门（v2）—— score 展示 + 硬门控 LIVE 交易
 *
 * decisionSafe：基础安全（可做研究/观察）
 * liveTradeAllowed：允许真实下单（CLOB + Book + 多周期 + 质量分）
 */
object HsDataQualityEngine {
    enum class Status { LIVE, STALE, DEGRADED, OFFLINE }
    data class Source(val name: String, val status: Status, val ageMs: Long, val detail: String)
    data class Snapshot(
        val sources: List<Source>,
        val score: Double,
        val decisionSafe: Boolean,
        val liveTradeAllowed: Boolean = false,
        val blockReasons: List<String> = emptyList()
    ) {
        val liveCount: Int get() = sources.count { it.status == Status.LIVE }
    }

    fun evaluate(
        candle5m: Int,
        candle15m: Int,
        candle1h: Int,
        orderBookAgeMs: Long?,
        polyLive: Boolean,
        oracleLive: Boolean,
        oracleAgeMs: Long?,
        config: HsRuntimeConfig = HsRuntimeConfig.Default,
        /** 多周期最后一根 bar 时间对齐误差（ms），过大则降级 */
        tfAlignErrorMs: Long = 0L
    ): Snapshot {
        val sources = listOf(
            Source("BTC 5m", statusFor(candle5m >= 40, candle5m >= 20), 0L, "$candle5m bars"),
            Source("BTC 15m", statusFor(candle15m >= 40, candle15m >= 20), 0L, "$candle15m bars"),
            Source("BTC 1h", statusFor(candle1h >= 40, candle1h >= 20), 0L, "$candle1h bars"),
            Source(
                "Binance Book",
                ageStatus(orderBookAgeMs, 2_500L, 10_000L),
                orderBookAgeMs ?: Long.MAX_VALUE,
                if (orderBookAgeMs == null) "unavailable" else "age=${orderBookAgeMs}ms"
            ),
            Source(
                "Polymarket CLOB",
                if (polyLive) Status.LIVE else Status.OFFLINE,
                0L,
                if (polyLive) "executable book" else "no executable book"
            ),
            Source(
                "Chainlink",
                ageStatus(if (oracleLive) oracleAgeMs else null, 120_000L, 300_000L),
                oracleAgeMs ?: Long.MAX_VALUE,
                if (oracleLive) "oracle feed" else "unavailable"
            ),
            Source(
                "TF Align",
                when {
                    tfAlignErrorMs <= 60_000L -> Status.LIVE
                    tfAlignErrorMs <= 180_000L -> Status.DEGRADED
                    else -> Status.STALE
                },
                tfAlignErrorMs,
                "alignErr=${tfAlignErrorMs}ms"
            )
        )
        val weights = mapOf(
            "BTC 5m" to 0.10, "BTC 15m" to 0.16, "BTC 1h" to 0.10,
            "Binance Book" to 0.20, "Polymarket CLOB" to 0.26,
            "Chainlink" to 0.08, "TF Align" to 0.10
        )
        val score = sources.sumOf { src ->
            (weights[src.name] ?: 0.1) * when (src.status) {
                Status.LIVE -> 1.0
                Status.DEGRADED -> 0.65
                Status.STALE -> 0.25
                Status.OFFLINE -> 0.0
            }
        }.coerceIn(0.0, 1.0)

        val polyOk = sources.any { it.name == "Polymarket CLOB" && it.status == Status.LIVE }
        val bookOk = sources.any { it.name == "Binance Book" && it.status == Status.LIVE }
        val btcLive = sources.filter { it.name.startsWith("BTC ") }.count { it.status == Status.LIVE }
        val decisionSafe = polyOk && bookOk && btcLive >= 2

        val blocks = mutableListOf<String>()
        if (!polyOk) blocks += "Polymarket CLOB 不可用"
        if (!bookOk) blocks += "Binance OrderBook 不可用/过期"
        if (btcLive < 2) blocks += "多周期 K 线不足"
        if (score < config.minDataQualityForLive) blocks += "质量分 ${"%.0f".format(score * 100)}% < ${"%.0f".format(config.minDataQualityForLive * 100)}%"
        if (tfAlignErrorMs > 180_000L) blocks += "多周期时间对齐偏差过大"

        val liveTradeAllowed = decisionSafe && blocks.isEmpty()

        return Snapshot(sources, score, decisionSafe, liveTradeAllowed, blocks)
    }

    private fun statusFor(full: Boolean, partial: Boolean): Status = when {
        full -> Status.LIVE
        partial -> Status.DEGRADED
        else -> Status.OFFLINE
    }

    private fun ageStatus(age: Long?, staleMs: Long, offlineMs: Long): Status = when {
        age == null -> Status.OFFLINE
        age <= staleMs -> Status.LIVE
        age <= offlineMs -> Status.STALE
        else -> Status.OFFLINE
    }
}
