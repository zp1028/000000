package com.caifenxi.app.domain.btc.runtime

import java.util.concurrent.CopyOnWriteArrayList

enum class NotificationSeverity { INFO, WARNING, CRITICAL }
data class NotificationEvent(val atMs: Long, val severity: NotificationSeverity, val title: String, val message: String, val dedupeKey: String)
class NotificationEventBus {
    private val listeners = CopyOnWriteArrayList<(NotificationEvent) -> Unit>()
    private val seen = HashMap<String, Long>()
    fun subscribe(listener: (NotificationEvent) -> Unit): () -> Unit { listeners += listener; return { listeners -= listener } }
    @Synchronized fun publish(event: NotificationEvent, dedupeMs: Long = 60_000L) {
        val previous = seen[event.dedupeKey]
        if (previous != null && event.atMs - previous < dedupeMs) return
        seen[event.dedupeKey] = event.atMs
        if (seen.size > 500) seen.entries.removeIf { event.atMs - it.value > dedupeMs * 10 }
        listeners.forEach { it(event) }
    }
}
