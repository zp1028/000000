package com.caifenxi.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.caifenxi.app.domain.btc.ResearchCenterEngine
import com.caifenxi.app.domain.btc.hs.HsDataQualityEngine
import com.caifenxi.app.ui.BtcQuantViewModel

@Composable
fun ResearchCenterScreen(viewModel: BtcQuantViewModel) {
    val state by viewModel.state.collectAsState()
    val snap = state.hsSnapshot
    val bg = Color(0xFF08090C)
    val panel = Color(0xFF101217)
    val text = Color(0xFFE8ECF2)
    val muted = Color(0xFF7D8795)
    val cyan = Color(0xFF00E5FF)

    Column(Modifier.fillMaxSize().background(bg).verticalScroll(rememberScrollState()).padding(10.dp)) {
        Text("RESEARCH CENTER", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        Text("MARKET → MODEL → EDGE → RISK → EXECUTION", color = muted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
        Spacer(Modifier.height(8.dp))
        if (snap == null) {
            Text("等待实时快照…", color = muted, fontFamily = FontFamily.Monospace)
            return@Column
        }
        val report = ResearchCenterEngine.build(snap)
        MetricRow("DIRECTION", report.direction, "pHat %.1f%%".format(report.pHatPct), text, cyan, panel)
        MetricRow("REGIME", report.regime, "5m", text, cyan, panel)
        MetricRow("RAW EDGE", "%+.2f%%".format(report.rawEdgePct), "model vs ask", text, cyan, panel)
        MetricRow("NET EDGE", "%+.2f%%".format(report.netEdgePct), if (report.executable) "EXECUTABLE" else "NO TRADE", text, cyan, panel)
        MetricRow("DATA", "%.1f%%".format(report.dataQualityPct), "live quality", text, cyan, panel)
        MetricRow("NET EXPOSURE", "%+.2f".format(report.exposure.netExposure), "USDT view", text, cyan, panel)
        MetricRow("GROSS", "%.2f".format(report.exposure.grossExposure), "USDT", text, cyan, panel)
        MetricRow("CONCENTRATION", "%.1f%%".format(report.exposure.concentration * 100), "directional", text, cyan, panel)

        Spacer(Modifier.height(10.dp))
        SectionTitle("DATA QUALITY", muted)
        snap.dataQuality?.sources?.forEach { source ->
            val status = source.status.name
            Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("${source.name.padEnd(18)} ${status.padEnd(9)}", color = if (source.status == HsDataQualityEngine.Status.LIVE) cyan else muted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                Text(source.detail, color = muted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
            }
        }

        Spacer(Modifier.height(10.dp))
        SectionTitle("MODEL × TIMEFRAME", muted)
        Row(Modifier.horizontalScroll(rememberScrollState())) {
            listOf("5m" to snap.tf5m, "15m" to snap.tf15m, "1h" to snap.tf1h).forEach { (tf, m) ->
                Column(Modifier.width(130.dp).background(panel).padding(8.dp).padding(end = 6.dp)) {
                    Text(tf, color = cyan, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    Text("pHat  %.1f%%".format(m.pHat * 100), color = text, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
                    Text("Edge  %+.2f%%".format(m.netEdge * 100), color = text, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
                    Text("Hit   %.1f%%".format(m.modelHitRate * 100), color = text, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
                    Text("Brier %.3f".format(m.brierScore), color = muted, fontFamily = FontFamily.Monospace, fontSize = 9.sp)
                    Text("${m.action} / ${m.regime.name}", color = muted, fontFamily = FontFamily.Monospace, fontSize = 8.sp)
                }
                Spacer(Modifier.width(6.dp))
            }
        }

        Spacer(Modifier.height(10.dp))
        SectionTitle("RISKS", muted)
        if (report.risks.isEmpty()) Text("NO ACTIVE RISK FLAGS", color = cyan, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
        else report.risks.forEach { Text("• $it", color = Color(0xFFFFB74D), fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.padding(vertical = 2.dp)) }

        Spacer(Modifier.height(10.dp))
        SectionTitle("SNAPSHOT REPLAY", muted)
        Text("Snapshots: ${snap.snapshotHistory.size}   Current: ${snap.snapshotId.take(16)}", color = text, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
        Text("历史快照用于回放当时的价格、概率、Edge、数据质量与模型状态；不会把未来数据带入过去。", color = muted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
    }
}

@Composable private fun SectionTitle(title: String, color: Color) {
    Text(title, color = color, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, modifier = Modifier.padding(bottom = 5.dp))
}

@Composable private fun MetricRow(title: String, value: String, detail: String, text: Color, accent: Color, panel: Color) {
    Row(Modifier.fillMaxWidth().background(panel).padding(horizontal = 9.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = Color(0xFF7D8795), fontSize = 8.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.width(110.dp))
        Text(value, color = text, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
        Text(detail, color = accent, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
    }
    Spacer(Modifier.height(2.dp))
}
