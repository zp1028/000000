package com.caifenxi.app.domain.model

import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

/**
 * 大小单双、倍投数字之后的可编排点击动作。
 * - COMBO：点击预测组合（大单/大双/小单/小双）
 * - PRED_NUMBERS：点击预测号码（任选或位置 TopN）
 * - TEXT：固定文案点击（确认/投注/删除等），可单独框选区域
 */
@Serializable
data class AutoClickPostAction(
    val id: String,
    val type: String = TYPE_TEXT,
    val enabled: Boolean = true,
    /** TEXT 类型时要点击的文案 */
    val text: String = "",
    /** 是否限制在自定义区域 */
    val regionEnabled: Boolean = false,
    val regionLeft: Float = 0f,
    val regionTop: Float = 0f,
    val regionRight: Float = 1f,
    val regionBottom: Float = 1f
) {
    companion object {
        const val TYPE_COMBO = "combo"
        const val TYPE_PRED_NUMBERS = "pred_numbers"
        const val TYPE_TEXT = "text"

        fun defaultList(): List<AutoClickPostAction> = listOf(
            AutoClickPostAction(id = "combo", type = TYPE_COMBO, enabled = false, text = "组合"),
            AutoClickPostAction(id = "pred_numbers", type = TYPE_PRED_NUMBERS, enabled = false, text = "预测数字")
        )
    }
}

object AutoClickPostActionsCodec {
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    fun encode(list: List<AutoClickPostAction>): String =
        try {
            json.encodeToString(list)
        } catch (_: Exception) {
            "[]"
        }

    fun decode(raw: String?): List<AutoClickPostAction> {
        if (raw.isNullOrBlank()) return AutoClickPostAction.defaultList()
        return try {
            json.decodeFromString<List<AutoClickPostAction>>(raw).ifEmpty { AutoClickPostAction.defaultList() }
        } catch (_: Exception) {
            AutoClickPostAction.defaultList()
        }
    }
}
