package com.caifenxi.app.data.config

import android.content.Context
import com.caifenxi.app.data.db.CaiDatabase
import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File

/**
 * 数据导出与全量备份/恢复。
 * - CSV:开奖历史 / 下注历史 / 统计记录 / 共识记录
 * - 全量备份:所有 Room 表 + 用户偏好,打包为单个 JSON 文件
 * - 恢复:读取备份 JSON,先清空各表再批量写入
 */
object DataExportHelper {

    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
        prettyPrint = true
    }

    /** 全量备份内容 */
    @Serializable
    data class FullBackup(
        val appVersion: Int = 1,
        val exportedAt: Long = System.currentTimeMillis(),
        val prefsJson: String? = null,
        val draws: List<com.caifenxi.app.data.db.entity.DrawEntity> = emptyList(),
        val bets: List<com.caifenxi.app.data.db.entity.BetEntity> = emptyList(),
        val botConfigs: List<com.caifenxi.app.data.db.entity.BotConfigEntity> = emptyList(),
        val wallets: List<com.caifenxi.app.data.db.entity.WalletEntity> = emptyList(),
        val stats: List<com.caifenxi.app.data.db.entity.StatEntity> = emptyList(),
        val consensus: List<com.caifenxi.app.data.db.entity.ConsensusEntity> = emptyList(),
        val manualMarks: List<com.caifenxi.app.data.db.entity.ManualMarkEntity> = emptyList(),
        val customPlans: List<com.caifenxi.app.data.db.entity.CustomPlanEntity> = emptyList()
    )

    // ---------- 文件位置 ----------

    fun exportDir(context: Context): File =
        File(context.getExternalFilesDir(null), "export").apply { mkdirs() }

    private fun timestamp(): String =
        java.text.SimpleDateFormat("yyyyMMdd-HHmmss", java.util.Locale.getDefault()).format(java.util.Date())

    // ---------- CSV 导出 ----------

    private fun csvEscape(v: String): String =
        if (v.contains(',') || v.contains('"') || v.contains('\n')) "\"${v.replace("\"", "\"\"")}\"" else v

    private fun csvRow(vararg cols: String): String = cols.joinToString(",") { csvEscape(it) }

    /** 开奖历史 CSV */
    suspend fun exportDrawsCsv(context: Context, db: CaiDatabase, lotteryKey: String? = null): File {
        val draws = if (lotteryKey != null) db.drawDao().getByLottery(lotteryKey) else db.drawDao().getAll()
        val sb = StringBuilder()
        sb.append(csvRow("彩种", "期号", "开奖时间", "号码", "和值", "大小", "单双", "组合")).append('\n')
        draws.forEach { d ->
            val numbers = kotlinx.serialization.json.Json.decodeFromString<List<Int>>(d.numbersJson)
            sb.append(csvRow(d.lotteryKey, d.issue, d.drawTime, numbers.joinToString(","), d.sum?.toString() ?: "", d.dx ?: "", d.ds ?: "", d.combo ?: "")).append('\n')
        }
        val file = File(exportDir(context), "draws-$timestamp().csv")
        file.writeText(sb.toString(), Charsets.UTF_8)
        return file
    }

    /** 下注历史 CSV */
    suspend fun exportBetsCsv(context: Context, db: CaiDatabase, lotteryKey: String? = null): File {
        val bets = if (lotteryKey != null) db.betDao().getBets(lotteryKey) else db.betDao().getAllBets()
        val sb = StringBuilder()
        sb.append(csvRow("彩种", "期号", "来源", "类别", "下注值", "金额", "赔率", "状态", "盈亏", "时间")).append('\n')
        bets.forEach { b ->
            sb.append(csvRow(b.lotteryKey, b.issue, b.sourceId, b.category, b.betValue, b.amount.toString(), b.odds.toString(), b.status, b.profit.toString(), java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date(b.createdAt)))).append('\n')
        }
        val file = File(exportDir(context), "bets-$timestamp().csv")
        file.writeText(sb.toString(), Charsets.UTF_8)
        return file
    }

    /** 统计记录 CSV */
    suspend fun exportStatsCsv(context: Context, db: CaiDatabase, lotteryKey: String? = null): File {
        val stats = if (lotteryKey != null) db.statDao().getByLottery(lotteryKey) else db.statDao().getAll()
        val sb = StringBuilder()
        sb.append(csvRow("彩种", "期号", "类别", "方向", "候选", "实际", "结果", "算法", "得分", "时间")).append('\n')
        stats.forEach { s ->
            sb.append(csvRow(s.lotteryKey, s.issue, s.category, s.lean, s.candidatesJson, s.actual ?: "", s.result, s.algoId, s.score.toString(), java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date(s.createdAt)))).append('\n')
        }
        val file = File(exportDir(context), "stats-$timestamp().csv")
        file.writeText(sb.toString(), Charsets.UTF_8)
        return file
    }

    /** 共识记录 CSV */
    suspend fun exportConsensusCsv(context: Context, db: CaiDatabase, lotteryKey: String? = null): File {
        val records = if (lotteryKey != null) db.consensusDao().getByLottery(lotteryKey) else db.consensusDao().getAll()
        val sb = StringBuilder()
        sb.append(csvRow("彩种", "期号", "类别", "共识方向", "支持度", "计划数", "实际", "结果", "时间")).append('\n')
        records.forEach { r ->
            sb.append(csvRow(r.lotteryKey, r.targetIssue, r.category, r.leadingDirection, r.supportRatio.toString(), r.participatingPlans.toString(), r.actual ?: "", r.result, java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date(r.createdAt)))).append('\n')
        }
        val file = File(exportDir(context), "consensus-$timestamp().csv")
        file.writeText(sb.toString(), Charsets.UTF_8)
        return file
    }

    // ---------- 全量备份 / 恢复 ----------

    /** 导出全量备份 JSON 文件(含 Room 全表 + 用户偏好) */
    suspend fun exportFullBackup(context: Context, db: CaiDatabase, prefsJson: String?): File {
        val backup = FullBackup(
            prefsJson = prefsJson,
            draws = db.drawDao().getAll(),
            bets = db.betDao().getAllBets(),
            botConfigs = db.betDao().getAllBotConfigs(),
            wallets = db.betDao().getAllWallets(),
            stats = db.statDao().getAll(),
            consensus = db.consensusDao().getAll(),
            manualMarks = db.manualMarkDao().getAll(),
            customPlans = db.customPlanDao().getAll()
        )
        val file = File(exportDir(context), "backup-$timestamp().json")
        file.writeText(json.encodeToString(backup), Charsets.UTF_8)
        return file
    }

    /**
     * 从备份 JSON 文件恢复。
     * 清空各表后写入备份数据;prefsJson 非空则同时返回供上层恢复偏好。
     * @return prefsJson(可能为 null)
     */
    suspend fun restoreFullBackup(db: CaiDatabase, file: File): String? {
        val backup = json.decodeFromString<FullBackup>(file.readText(Charsets.UTF_8))
        // 清空旧数据
        db.drawDao().deleteAll()
        db.betDao().deleteAllBets()
        db.betDao().deleteAllBotConfigs()
        db.betDao().deleteAllWallets()
        db.statDao().deleteAll()
        db.consensusDao().deleteAll()
        db.manualMarkDao().deleteAll()
        db.customPlanDao().deleteAll()
        // 写入备份数据
        if (backup.draws.isNotEmpty()) db.drawDao().upsertAll(backup.draws)
        if (backup.bets.isNotEmpty()) db.betDao().upsertAllBets(backup.bets)
        if (backup.botConfigs.isNotEmpty()) db.betDao().upsertAllBotConfigs(backup.botConfigs)
        if (backup.wallets.isNotEmpty()) db.betDao().upsertAllWallets(backup.wallets)
        if (backup.stats.isNotEmpty()) db.statDao().upsertAll(backup.stats)
        if (backup.consensus.isNotEmpty()) db.consensusDao().upsertAll(backup.consensus)
        if (backup.manualMarks.isNotEmpty()) db.manualMarkDao().upsertAll(backup.manualMarks)
        if (backup.customPlans.isNotEmpty()) db.customPlanDao().upsertAll(backup.customPlans)
        return backup.prefsJson
    }

    /** 列出已导出的文件(CSV/备份) */
    fun listExports(context: Context): List<File> =
        exportDir(context).listFiles()?.sortedByDescending { it.lastModified() }?.toList() ?: emptyList()
}
