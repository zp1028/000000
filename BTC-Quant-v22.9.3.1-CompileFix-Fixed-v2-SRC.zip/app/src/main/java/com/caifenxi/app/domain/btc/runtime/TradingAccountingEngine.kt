package com.caifenxi.app.domain.btc.runtime

import kotlin.math.abs
import kotlin.math.max

/** Canonical futures-style position/accounting semantics for PAPER/BACKTEST adapters. */
class TradingAccountingEngine(
    startingCash: Double,
    private val marginRate: Double = 1.0
) {
    private val positions = mutableMapOf<String, PaperPosition>()
    private var realizedPnl = 0.0
    private var fees = 0.0
    private val initialCash = startingCash
    private var equity = startingCash
    private var peakEquity = startingCash
    private var unrealizedPnl = 0.0
    private var usedMargin = 0.0
    private var lastMarks = mutableMapOf<String, Double>()

    init {
        require(startingCash >= 0.0) { "startingCash must be >= 0" }
        require(marginRate > 0.0) { "marginRate must be > 0" }
    }

    fun applyFill(intent: OrderIntentSpec, price: Double, quantity: Double, fee: Double, atMs: Long): ExecutionFill {
        require(price > 0.0 && quantity > 0.0) { "invalid fill" }
        val signed = if (intent.side == OrderSide.BUY) quantity else -quantity
        val old = positions[intent.symbol] ?: PaperPosition(intent.symbol)

        if (intent.reduceOnly && old.quantity == 0.0) {
            throw IllegalStateException("reduceOnly order cannot open a position")
        }
        if (intent.reduceOnly && old.quantity * signed >= 0.0) {
            throw IllegalStateException("reduceOnly order cannot increase or reverse the position")
        }

        val closingQty = if (old.quantity * signed < 0.0) minOf(abs(old.quantity), abs(signed)) else 0.0
        val realizedDelta = when {
            closingQty == 0.0 -> 0.0
            old.quantity > 0.0 -> (price - old.averageEntry) * closingQty
            else -> (old.averageEntry - price) * closingQty
        }
        val residual = old.quantity + signed
        val next = when {
            residual == 0.0 -> old.copy(quantity = 0.0, averageEntry = 0.0, realizedPnl = old.realizedPnl + realizedDelta)
            old.quantity == 0.0 || old.quantity * signed > 0.0 -> {
                val total = abs(old.quantity) + abs(signed)
                val avg = if (total <= 0.0) 0.0 else
                    (old.averageEntry * abs(old.quantity) + price * abs(signed)) / total
                old.copy(quantity = residual, averageEntry = avg, realizedPnl = old.realizedPnl + realizedDelta)
            }
            abs(signed) > abs(old.quantity) -> old.copy(
                quantity = residual,
                averageEntry = price,
                realizedPnl = old.realizedPnl + realizedDelta
            )
            else -> old.copy(quantity = residual, realizedPnl = old.realizedPnl + realizedDelta)
        }

        positions[intent.symbol] = next
        realizedPnl += realizedDelta
        fees += fee
        lastMarks[intent.symbol] = price
        recalculate()
        return ExecutionFill(intent.clientId, "PAPER-${intent.clientId}", intent.symbol, intent.side, price, quantity, fee, atMs)
    }

    fun mark(symbol: String, price: Double): PaperAccount {
        if (price > 0.0) lastMarks[symbol] = price
        recalculate()
        return snapshot()
    }

    fun position(symbol: String): PaperPosition = positions[symbol] ?: PaperPosition(symbol)

    fun account(): PaperAccount = snapshot()

    private fun recalculate() {
        unrealizedPnl = positions.values.sumOf { p ->
            val mark = lastMarks[p.symbol] ?: p.averageEntry
            when {
                p.quantity > 0.0 -> (mark - p.averageEntry) * p.quantity
                p.quantity < 0.0 -> (p.averageEntry - mark) * abs(p.quantity)
                else -> 0.0
            }
        }
        equity = max(0.0, (initialCash + realizedPnl - fees) + unrealizedPnl)
        usedMargin = positions.values.sumOf { p ->
            val mark = lastMarks[p.symbol] ?: p.averageEntry
            abs(p.quantity) * mark * marginRate
        }
        peakEquity = max(peakEquity, equity)
    }

    private fun snapshot(): PaperAccount {
        val available = (equity - usedMargin).coerceAtLeast(0.0)
        return PaperAccount(
            startingCash = initialCash,
            cash = available,
            equity = equity,
            peakEquity = peakEquity,
            realizedPnl = realizedPnl,
            unrealizedPnl = unrealizedPnl,
            fees = fees,
            usedMargin = usedMargin,
            availableMargin = available
        )
    }
}
