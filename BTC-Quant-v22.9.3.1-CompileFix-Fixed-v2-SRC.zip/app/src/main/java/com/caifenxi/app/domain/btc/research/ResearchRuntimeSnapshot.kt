package com.caifenxi.app.domain.btc.research

/** Runtime-safe projection. Research never directly executes orders; it only supplies validated weights. */
data class ResearchRuntimeSnapshot(
    val artifactId: String? = null,
    val datasetCutoffMs: Long = 0L,
    val factorWeights: Map<String, Double> = emptyMap(),
    val strategyWeights: Map<String, Double> = emptyMap(),
    val fusionWeights: Map<String, Double> = emptyMap(),
    val status: String = "NONE"
)
