package com.caifenxi.app.domain.btc.hs

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Persistent, versioned model artifact store. Parameters are learned from historical data only. */
class BtcMlModelArtifactStore(context: Context?) {
    data class Artifact(
        val modelId: String, val timeframe: String, val horizon: Int, val featureVersion: String, val trainedAtMs: Long,
        val weights: DoubleArray, val bias: Double, val probability: Double, val samples: Int,
        val brierScore: Double, val hitRate: Double, val logLoss: Double, val modelVersion: String,
        val datasetStartMs: Long = 0L, val datasetCutoffMs: Long = trainedAtMs, val trainSamples: Int = samples,
        val calibrationSamples: Int = 0, val oosSamples: Int = 0, val lineageId: String = ""
    )
    private val prefs = context?.applicationContext?.getSharedPreferences("btc_ml_artifacts_v1", Context.MODE_PRIVATE)
    @Synchronized fun save(a: Artifact) {
        val p=prefs?:return
        val w=JSONArray(); a.weights.forEach{w.put(it)}
        p.edit().putString(key(a.modelId,a.timeframe,a.horizon,a.featureVersion), JSONObject().apply {
            put("modelId",a.modelId); put("timeframe",a.timeframe); put("horizon",a.horizon); put("featureVersion",a.featureVersion); put("trainedAtMs",a.trainedAtMs);
            put("datasetStartMs",a.datasetStartMs); put("datasetCutoffMs",a.datasetCutoffMs); put("trainSamples",a.trainSamples); put("calibrationSamples",a.calibrationSamples); put("oosSamples",a.oosSamples); put("lineageId",a.lineageId); put("bias",a.bias); put("probability",a.probability); put("samples",a.samples);
            put("brier",a.brierScore); put("hit",a.hitRate); put("logLoss",a.logLoss); put("version",a.modelVersion); put("weights",w)
        }.toString()).apply()
    }
    @Synchronized fun load(modelId:String,tf:String,horizon:Int,featureVersion:String):Artifact? {
        val raw=prefs?.getString(key(modelId,tf,horizon,featureVersion),null) ?: return null
        return runCatching {
            val o=JSONObject(raw); val a=o.getJSONArray("weights"); val w=DoubleArray(a.length()){a.getDouble(it)}
            Artifact(modelId,tf,horizon,featureVersion,o.getLong("trainedAtMs"),w,o.getDouble("bias"),o.getDouble("probability"),o.getInt("samples"),o.getDouble("brier"),o.getDouble("hit"),o.getDouble("logLoss"),o.getString("version"),o.optLong("datasetStartMs",0L),o.optLong("datasetCutoffMs",o.getLong("trainedAtMs")),o.optInt("trainSamples",o.getInt("samples")),o.optInt("calibrationSamples",0),o.optInt("oosSamples",0),o.optString("lineageId",""))
        }.getOrNull()
    }
    private fun key(modelId:String,tf:String,h:Int,fv:String)="artifact_${modelId}_${tf}_${h}_${fv}"
}
