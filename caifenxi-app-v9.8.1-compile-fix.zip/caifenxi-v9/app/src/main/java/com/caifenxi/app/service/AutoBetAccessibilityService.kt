package com.caifenxi.app.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.caifenxi.app.util.RuntimeLog

/**
 * 无障碍自动点击服务：根据彩分析内部预测，在第三方页面点击「大/小/单/双」。
 * 用户需在系统设置中手动开启本服务。
 */
class AutoBetAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: AutoBetAccessibilityService? = null

        fun isRunning(): Boolean = instance != null
    }

    private val mainHandler = Handler(Looper.getMainLooper())

    // V9：防止预测 READY、前后台恢复、网络重复回调在极短时间内重复触发。
    private var lastActionFingerprint: String = ""
    private var lastActionAt: Long = 0L
    private val actionCooldownMs = 2_000L

    // Android 7+ compatibility: gesture dispatch is available from API 24.
    private val supportsGestureTap: Boolean
        get() = Build.VERSION.SDK_INT >= Build.VERSION_CODES.N

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        RuntimeLog.info("AutoBet", "无障碍服务已连接")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // 主要靠外部主动调用 performBet，这里仅作备用窗口变化监听
    }

    override fun onInterrupt() {
        RuntimeLog.warn("AutoBet", "无障碍服务被中断")
    }

    override fun onDestroy() {
        instance = null
        RuntimeLog.info("AutoBet", "无障碍服务已销毁")
        super.onDestroy()
    }

    /**
     * 根据预测执行点击。
     * @param dx 「大」或「小」，为空则跳过
     * @param ds 「单」或「双」，为空则跳过
     * @param clickDelayMs 两次点击之间的间隔
     */
    fun performBet(dx: String?, ds: String?, clickDelayMs: Long = 350L) {
        val fingerprint = "${dx.orEmpty()}|${ds.orEmpty()}"
        val now = System.currentTimeMillis()
        if (fingerprint.isBlank() || (fingerprint == lastActionFingerprint && now - lastActionAt < actionCooldownMs)) {
            RuntimeLog.info("AutoBet", "V9 重复触发保护：跳过 $fingerprint")
            return
        }
        mainHandler.post {
            val root = rootInActiveWindow
            if (root == null) {
                RuntimeLog.warn("AutoBet", "rootInActiveWindow 为空，无法执行操作")
                return@post
            }
            val windowPackage = root.packageName?.toString().orEmpty()
            if (windowPackage.isBlank()) {
                RuntimeLog.warn("AutoBet", "当前窗口包名为空，跳过操作")
                root.recycle()
                return@post
            }
            try {
                var clickedAny = false
                if (!dx.isNullOrBlank() && (dx == "大" || dx == "小")) {
                    val ok = findAndClick(root, dx)
                    RuntimeLog.info("AutoBet", "窗口=$windowPackage 点击[$dx] => $ok")
                    clickedAny = clickedAny || ok
                    if (ok) {
                        lastActionFingerprint = fingerprint
                        lastActionAt = System.currentTimeMillis()
                    }
                }
                if (!ds.isNullOrBlank() && (ds == "单" || ds == "双")) {
                    mainHandler.postDelayed({
                        val r2 = rootInActiveWindow
                        if (r2 != null) {
                            try {
                                val ok = findAndClick(r2, ds)
                                RuntimeLog.info("AutoBet", "窗口=${r2.packageName ?: "-"} 点击[$ds] => $ok")
                                if (ok) {
                                    lastActionFingerprint = fingerprint
                                    lastActionAt = System.currentTimeMillis()
                                }
                            } finally {
                                r2.recycle()
                            }
                        }
                    }, if (clickedAny) clickDelayMs else 0L)
                }
            } finally {
                root.recycle()
            }
        }
    }

    /**
     * 在当前窗口按文字查找并点击。
     * 优先点自身可点击节点，否则向上找可点击父节点；再不行用坐标手势点击中心。
     */
    private fun findAndClick(root: AccessibilityNodeInfo, text: String): Boolean {
        val nodes = root.findAccessibilityNodeInfosByText(text) ?: return false
        try {
            for (node in nodes) {
                if (tryClickNode(node)) {
                    return true
                }
                // 向上找可点击父节点
                var parent = node.parent
                var depth = 0
                while (parent != null && depth < 6) {
                    if (tryClickNode(parent)) {
                        parent.recycle()
                        return true
                    }
                    val next = parent.parent
                    parent.recycle()
                    parent = next
                    depth++
                }
            }
        } finally {
            nodes.forEach { it.recycle() }
        }
        return false
    }

    private fun tryClickNode(node: AccessibilityNodeInfo): Boolean {
        if (node.isClickable && node.isEnabled) {
            if (node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                return true
            }
        }
        // 部分 WebView / 自定义 View 不响应 ACTION_CLICK，尝试手势点击中心
        if (supportsGestureTap) {
            val rect = android.graphics.Rect()
            node.getBoundsInScreen(rect)
            if (!rect.isEmpty && rect.width() > 4 && rect.height() > 4) {
                val cx = rect.exactCenterX()
                val cy = rect.exactCenterY()
                return dispatchTap(cx, cy)
            }
        }
        return false
    }

    private fun dispatchTap(x: Float, y: Float): Boolean {
        if (!supportsGestureTap) return false
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0, 60)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        return dispatchGesture(gesture, null, null)
    }
}
