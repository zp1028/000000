package com.caifenxi.app.ui.screens

import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import com.caifenxi.app.ui.MainViewModel
import com.caifenxi.app.ui.ExecutorViewModel
import com.caifenxi.app.ui.components.GlobalCard
import com.caifenxi.app.ui.components.PrimaryButton
import com.caifenxi.app.ui.theme.CaiTokens

@Composable
fun WebExecutorScreen(
    mainViewModel: MainViewModel = viewModel(),
    executorViewModel: ExecutorViewModel = viewModel()
) {
    val context = LocalContext.current
    var webView: WebView? = null
    
    // 执行状态
    val executorStatus by executorViewModel.executorStatus.collectAsState()
    val currentTask by executorViewModel.currentTask.collectAsState()
    val executorLogs by executorViewModel.executorLogs.collectAsState()
    
    // 网页状态
    var webpageUrl by remember { mutableStateOf("") }
    var webpageTitle by remember { mutableStateOf("") }
    var webpageStatus by remember { mutableStateOf("加载中...") }

    BackHandler {
        webView?.let { wv ->
            if (wv.canGoBack()) {
                wv.goBack()
            } else {
                // 返回首页
                // todo: 实现导航逻辑
            }
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = CaiTokens.ScreenHPadding, vertical = CaiTokens.S16)
    ) {
        Text("内置网页执行中心", style = MaterialTheme.typography.headlineMedium)
        
        Spacer(Modifier.height(CaiTokens.S16))

        // 状态概览卡片
        GlobalCard {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text("当前网站", fontWeight = FontWeight.Bold)
                    Text(webpageTitle.ifEmpty { "彩析内置执行器" }, color = MaterialTheme.colorScheme.secondary)
                }
                Column {
                    Text("当前彩种", fontWeight = FontWeight.Bold)
                    Text(mainViewModel.currentLottery.value.name, color = MaterialTheme.colorScheme.secondary)
                }
                Column {
                    Text("当前期号", fontWeight = FontWeight.Bold)
                    Text(mainViewModel.nextIssueText.value, color = MaterialTheme.colorScheme.secondary)
                }
            }
            Spacer(Modifier.height(CaiTokens.S8))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text("登录状态", fontWeight = FontWeight.Bold)
                    Text("未登录", color = Color.Red)
                }
                Column {
                    Text("网页状态", fontWeight = FontWeight.Bold)
                    Text(webpageStatus, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Column {
                    Text("执行器状态", fontWeight = FontWeight.Bold)
                    Text(
                        when (executorStatus) {
                            ExecutorViewModel.ExecutorStatus.IDLE -> "待机"
                            ExecutorViewModel.ExecutorStatus.RUNNING -> "执行中"
                            ExecutorViewModel.ExecutorStatus.COMPLETED -> "已完成"
                            ExecutorViewModel.ExecutorStatus.FAILED -> "失败"
                            ExecutorViewModel.ExecutorStatus.CANCELLED -> "已取消"
                        },
                        color = when (executorStatus) {
                            ExecutorViewModel.ExecutorStatus.RUNNING -> MaterialTheme.colorScheme.primary
                            ExecutorViewModel.ExecutorStatus.COMPLETED -> Color.Green
                            ExecutorViewModel.ExecutorStatus.FAILED -> Color.Red
                            else -> MaterialTheme.colorScheme.onSurfaceVariant
                        }
                    )
                }
            }
        }

        Spacer(Modifier.height(CaiTokens.S16))

        // 执行控制面板
        GlobalCard {
            Text("执行控制", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(CaiTokens.S8))
            
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(CaiTokens.S8)) {
                PrimaryButton(
                    text = "生成测试任务",
                    enabled = true,
                    modifier = Modifier.weight(1f)
                ) {
                    val testTask = executorViewModel.generateTestTask()
                    executorViewModel.startTask(testTask)
                }
                
                PrimaryButton(
                    text = "停止执行",
                    enabled = executorStatus == ExecutorViewModel.ExecutorStatus.RUNNING,
                    modifier = Modifier.weight(1f)
                ) {
                    currentTask?.taskId?.let { executorViewModel.stopTask(it) }
                }
                
                PrimaryButton(
                    text = "刷新页面",
                    enabled = true,
                    modifier = Modifier.weight(1f)
                ) {
                    webView?.reload()
                }
            }
        }

        Spacer(Modifier.height(CaiTokens.S16))

        // 当前执行任务
        GlobalCard {
            Text("当前执行任务", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(CaiTokens.S8))
            currentTask?.let { task ->
                Column {
                    Text("任务ID: ${task.cmdId}")
                    Text("彩种: ${task.lotteryKey}")
                    Text("期号: ${task.issue}")
                    Text("下注方向: ${task.dx}/${task.ds}")
                    if (!task.amountText.isNullOrEmpty()) {
                        Text("金额: ${task.amountText}")
                    }
                }
            } ?: Text("暂无执行任务", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        Spacer(Modifier.height(CaiTokens.S16))

        // WebView 容器
        GlobalCard {
            Text("网页浏览器", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(CaiTokens.S8))
            
            AndroidView(
                factory = { ctx ->
                    WebView(ctx).apply {
                        webView = this
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.loadsImagesAutomatically = true
                        
                        webViewClient = object : WebViewClient() {
                            override fun onPageFinished(view: WebView?, url: String?) {
                                webpageUrl = url ?: ""
                                webpageStatus = "已加载"
                            }
                        }
                        
                        webChromeClient = object : WebChromeClient() {
                            override fun onReceivedTitle(view: WebView?, title: String?) {
                                webpageTitle = title ?: ""
                            }
                        }
                        
                        // 加载测试页面
                        loadUrl("https://www.baidu.com")
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(400.dp)
            )
        }

        Spacer(Modifier.height(CaiTokens.S16))

        // 执行记录
        GlobalCard {
            Text("执行记录", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(CaiTokens.S8))
            
            Column {
                if (executorLogs.isEmpty()) {
                    Text("暂无执行记录", color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    executorLogs.forEach { log ->
                        Text(log, color = if (log.contains("成功")) Color.Green else 
                                     if (log.contains("失败")) Color.Red else 
                                     MaterialTheme.colorScheme.onSurfaceVariant,
                             modifier = Modifier.padding(vertical = 2.dp))
                    }
                }
            }
        }

        Spacer(Modifier.height(CaiTokens.S16))

        // 快速操作
        GlobalCard {
            Text("快速操作", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(CaiTokens.S8))
            
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(CaiTokens.S8)) {
                PrimaryButton("清空日志", enabled = true, modifier = Modifier.weight(1f)) {
                    executorViewModel.clearLogs()
                }
                PrimaryButton("生成多个任务", enabled = true, modifier = Modifier.weight(1f)) {
                    repeat(3) {
                        val testTask = executorViewModel.generateTestTask()
                        executorViewModel.startTask(testTask)
                    }
                }
            }
        }
    }
}  }
}                  override fun onPageFinished(view: WebView?, url: String?) {
                                webpageUrl = url ?: ""
                                webpageStatus = "已加载"
                                pageAdapter?.initialize()
                                bridge?.addLog("网页加载完成: $url")
                            }
                        }
                        
                        webChromeClient = object : WebChromeClient() {
                            override fun onReceivedTitle(view: WebView?, title: String?) {
                                webpageTitle = title ?: ""
                            }
                        }
                        
                        // 注入JavaScript接口
                        val jsInterface = WebViewInterface(bridge!!)
                        addJavascriptInterface(jsInterface, "Android")
                        
                        // 加载默认页面
                        loadUrl("about:blank")
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(400.dp)
            )
        }

        Spacer(Modifier.height(CaiTokens.S16))

        // 执行进度
        GlobalCard {
            Text("执行进度", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(CaiTokens.S8))
            LinearProgressIndicator(
                progress = executionProgress,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(CaiTokens.S8))
            Text("进度: ${(executionProgress * 100).toInt()}%", 
                 color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        Spacer(Modifier.height(CaiTokens.S16))

        // 执行记录
        GlobalCard {
            Text("执行记录", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(CaiTokens.S8))
            Column {
                if (executorLogs.isEmpty()) {
                    Text("暂无执行记录", color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    executorLogs.forEach { log ->
                        Text(log, color = if (log.contains("成功")) Color.Green else 
                                     if (log.contains("失败")) Color.Red else 
                                     MaterialTheme.colorScheme.onSurfaceVariant,
                             modifier = Modifier.padding(vertical = 2.dp))
                    }
                }
            }
        }

        Spacer(Modifier.height(CaiTokens.S16))

        // 快速操作
        GlobalCard {
            Text("快速操作", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(CaiTokens.S8))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(CaiTokens.S8)) {
                PrimaryButton("清空日志", enabled = true, modifier = Modifier.weight(1f)) {
                    executorViewModel.clearLogs()
                    bridge?.reset()
                }
                PrimaryButton("生成测试任务", enabled = true, modifier = Modifier.weight(1f)) {
                    val testTask = executorViewModel.generateTestTask()
                    executorViewModel.startTask(testTask)
                }
            }
        }
    }
}任务", enabled = true, modifier = Modifier.weight(1f)) {
                    val testTask = executorViewModel.generateTestTask()
                    executorViewModel.startTask(testTask)
                }
            }
        }
    }
}