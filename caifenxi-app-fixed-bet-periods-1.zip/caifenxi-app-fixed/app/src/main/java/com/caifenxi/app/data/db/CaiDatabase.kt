package com.caifenxi.app.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.caifenxi.app.data.db.dao.BetDao
import com.caifenxi.app.data.db.dao.DrawDao
import com.caifenxi.app.data.db.entity.BetEntity
import com.caifenxi.app.data.db.entity.BotConfigEntity
import com.caifenxi.app.data.db.entity.DrawEntity
import com.caifenxi.app.data.db.entity.WalletEntity

@Database(
    entities = [DrawEntity::class, BetEntity::class, BotConfigEntity::class, WalletEntity::class],
    version = 4,
    exportSchema = false
)
abstract class CaiDatabase : RoomDatabase() {
    abstract fun drawDao(): DrawDao
    abstract fun betDao(): BetDao

    companion object {
        @Volatile private var instance: CaiDatabase? = null

        fun getInstance(context: Context): CaiDatabase {
            return instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    CaiDatabase::class.java,
                    "caifenxi.db"
                )
                    // 本地分析/开奖缓存可重建;模拟下注是新增表。
                    // 升版本未提供迁移时允许重建,避免老用户升级闪退。
                    .fallbackToDestructiveMigration()
                    .build().also { instance = it }
            }
        }
    }
}
