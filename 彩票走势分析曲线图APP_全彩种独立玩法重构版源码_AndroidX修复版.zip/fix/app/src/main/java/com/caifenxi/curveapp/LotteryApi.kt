package com.caifenxi.curveapp

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL

object LotteryApi {
    data class Config(val host:String,val path:String,val historyPath:String,val lotCode:String,val apiKey:String)
    fun fetchHistory(c:Config,date:String?=null):List<Draw>{
        val params=mutableListOf("lotCode=${enc(c.lotCode)}","apiKey=${enc(c.apiKey)}"); if(!date.isNullOrBlank())params+="date=${enc(date)}"
        val url="${c.host.trimEnd('/')}/${c.historyPath.trimStart('/')}?${params.joinToString("&")}"; return request(url)
    }
    fun fetchCurrent(c:Config):List<Draw>{
        val url="${c.host.trimEnd('/')}/${c.path.trimStart('/')}?lotCode=${enc(c.lotCode)}&apiKey=${enc(c.apiKey)}"; return request(url)
    }
    private fun request(url:String):List<Draw>{
        val conn=(URL(url).openConnection() as HttpURLConnection).apply{requestMethod="GET";connectTimeout=12000;readTimeout=15000;setRequestProperty("Accept","application/json")}
        return try{val code=conn.responseCode;val text=(if(code in 200..299)conn.inputStream else conn.errorStream)?.bufferedReader()?.use{it.readText()}?:"";if(code !in 200..299)error("HTTP $code");parse(text)}finally{conn.disconnect()}
    }
    private fun parse(raw:String):List<Draw>{
        val root=JSONObject(raw); val data=root.optJSONObject("result")?.opt("data") ?: root.opt("data") ?: root
        val arr=when(data){is JSONArray->data;is JSONObject->JSONArray().also{it.put(data)};else->JSONArray()}; val out=mutableListOf<Draw>()
        for(i in 0 until arr.length()){val o=arr.optJSONObject(i)?:continue;val issue=first(o,"preDrawIssue","drawIssue","issue","lotteryDrawNum","expect")?:continue;val time=first(o,"preDrawTime","drawTime","time").orEmpty();val nums=parseNums(o);if(nums.isNotEmpty())out+=Draw(issue,time,nums)}
        return out.distinctBy{it.issue}.sortedBy{it.issue}
    }
    private fun parseNums(o:JSONObject):List<Int>{for(k in listOf("preDrawCode","drawCode","openNum","openNumber","lotteryDrawResult","result","numbers","code","drawResult")){val v=o.opt(k);val nums=when(v){is JSONArray->(0 until v.length()).mapNotNull{v.optString(it).trim().toIntOrNull()};is String->Regex("\\d+").findAll(v).mapNotNull{it.value.toIntOrNull()}.toList();else->emptyList()};if(nums.isNotEmpty())return nums};return emptyList()}
    private fun first(o:JSONObject,vararg ks:String)=ks.firstNotNullOfOrNull{if(o.has(it)&&!o.isNull(it))o.optString(it).takeIf(String::isNotBlank)else null}
    private fun enc(v:String)=URLEncoder.encode(v,"UTF-8")
}
