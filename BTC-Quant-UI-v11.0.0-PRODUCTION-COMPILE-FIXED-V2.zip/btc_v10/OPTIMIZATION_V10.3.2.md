# v10.3.2 协调器接线完成

## refresh → MarketDataCoordinator
- `BtcQuantViewModel.refresh()` 不再内联十路 async
- 统一调用 `marketDataCoordinator.loadParallel(...)`
- 保留：LIVE 快照不被偶发 Demo 覆盖；Polymarket 匹配与 orderbook 拉取

## HS 评估 → HsEngineCoordinator + PaperAccountCoordinator
- `applyMarketBundle` 通过 `hsEngineCoordinator.evaluate`
- PAPER/DEMO 账户字段来自 `paperAccountCoordinator.snapshot()`
- LIVE_ACCOUNT 仍优先真实 Binance 账户

## 自动下单 → ExecutionCoordinator
- `executeAutoTradeTick` 在下单前检查：
  - Kill Switch
  - 数据质量门 `liveTradeAllowed`
  - 机会分门槛
  - 冷却 / 幂等键（market|direction|window）
- PAPER 成交成功后 `markPlaced`
- 新增 `setExecutionKillSwitch(on: Boolean)` 供 UI 绑定

## 建议 UI
- 设置页增加「Kill Switch」开关调用 `viewModel.setExecutionKillSwitch`
