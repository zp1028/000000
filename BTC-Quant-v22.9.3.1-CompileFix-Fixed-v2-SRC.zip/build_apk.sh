#!/system/bin/sh
# 一键构建 BTC-Quant 的 debug APK（手机端，受限网络环境）
# 工具链固定在 /data/local/tmp 下：JJDK=fj, Gradle=gradle, SDK=asdk, aapt2=bt
set -e
HERE=$(cd "$(dirname "$0")" && pwd)
cd "$HERE"

# 自检工具链
for p in /data/local/tmp/gradle-run.sh /data/local/tmp/fj/bin/java /data/local/tmp/asdk/platforms/android-35/android.jar /data/local/tmp/bt/aapt2; do
  if [ ! -e "$p" ]; then echo "缺少工具链: $p （需重新部署，见对话说明）"; exit 3; fi
done

# 生成本机 SDK 路径
printf 'sdk.dir=/data/local/tmp/asdk\n' > local.properties

# 调用 Gradle（手机专用启动器，自动带上 JDK 库路径与全部环境变量）
TASK="${1:-assembleDebug}"
/data/local/tmp/gradle-run.sh --no-daemon --console=plain "$TASK"

# 复制产物到项目根，工作区只保留这一份最终 APK
APK="app/build/outputs/apk/debug/app-debug.apk"
if [ -f "$APK" ]; then
  cp "$APK" ./btc-quant-debug.apk
  rm -f "$APK"                      # 删除 Gradle 输出目录里的重复 APK
  rm -f ./app-debug.apk             # 删除历史遗留的重复命名
  echo "APK: $HERE/btc-quant-debug.apk"
fi
