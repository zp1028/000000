package com.caifenxi.app.domain.btc.factor

import com.caifenxi.app.domain.btc.BtcDirection
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * Portfolio-level factor allocator. Research metrics determine quality, then
 * correlation and regime fit prevent stacking many copies of the same signal.
 * It never places orders; it only returns a deterministic risk budget.
 */
object QuantFactorPortfolioEngine {
    data class FactorStat(
        val factorId: String,
        val score: Double,
        val icir: Double,
        val stability: Double = 1.0,
        val regimeFit: Double = 1.0,
        val currentValue: Double = 0.0
    )

    data class Allocation(
        val factorId: String,
        val rawWeight: Double,
        val diversifiedWeight: Double,
        val riskBudget: Double,
        val contribution: Double,
        val reason: String
    )

    data class Portfolio(
        val direction: BtcDirection,
        val allocations: List<Allocation>,
        val grossRiskFraction: Double,
        val confidence: Double,
        val concentration: Double
    )

    fun allocate(
        stats: List<FactorStat>,
        correlations: Map<Pair<String, String>, Double> = emptyMap(),
        maxGrossRisk: Double = 0.02,
        maxSingleRisk: Double = 0.006,
        correlationThreshold: Double = 0.82
    ): Portfolio {
        if (stats.isEmpty()) return Portfolio(BtcDirection.FLAT, emptyList(), 0.0, 0.0, 0.0)
        val usable = stats.filter { it.score > 0.0 && it.stability >= 0.35 && it.regimeFit > 0.0 }
        if (usable.isEmpty()) return Portfolio(BtcDirection.FLAT, emptyList(), 0.0, 0.0, 0.0)

        val raw = usable.associateWith {
            (it.score * (0.65 + 0.35 * it.icir.coerceIn(0.0, 2.0)) *
                it.stability.coerceIn(0.0, 1.0) * it.regimeFit.coerceIn(0.0, 1.0)).coerceAtLeast(0.0)
        }
        val total = raw.values.sum().coerceAtLeast(1e-9)
        val sorted = usable.sortedByDescending { raw[it] ?: 0.0 }
        val kept = mutableListOf<FactorStat>()
        val allocations = mutableListOf<Allocation>()
        for (factor in sorted) {
            val base = (raw[factor] ?: 0.0) / total
            val duplicate = kept.firstOrNull { abs(correlation(it.factorId, factor.factorId, correlations)) >= correlationThreshold }
            val penalty = if (duplicate != null) 0.35 else 1.0
            val diversified = (base * penalty).coerceIn(0.0, maxSingleRisk / maxGrossRisk.coerceAtLeast(1e-9))
            val contribution = diversified * factor.currentValue.coerceIn(-1.0, 1.0)
            allocations += Allocation(
                factor.factorId, base, diversified, diversified * maxGrossRisk,
                contribution,
                if (duplicate == null) "独立因子" else "与${duplicate.factorId}高相关，降集中度"
            )
            kept += factor
        }
        val weightSum = allocations.sumOf { it.diversifiedWeight }.coerceAtLeast(1e-9)
        val normalized = allocations.map { it.copy(
            diversifiedWeight = it.diversifiedWeight / weightSum,
            riskBudget = maxGrossRisk * it.diversifiedWeight / weightSum,
            contribution = it.contribution / weightSum
        ) }
        val net = normalized.sumOf { it.contribution }
        val direction = when {
            net > 0.10 -> BtcDirection.UP
            net < -0.10 -> BtcDirection.DOWN
            else -> BtcDirection.FLAT
        }
        val gross = normalized.sumOf { abs(it.riskBudget) }.coerceAtMost(maxGrossRisk)
        val concentration = normalized.maxOfOrNull { it.riskBudget }?.div(gross.coerceAtLeast(1e-9)) ?: 0.0
        val confidence = (abs(net) * 0.75 + normalized.map { abs(it.contribution) }.average() * 0.25).coerceIn(0.0, 1.0)
        return Portfolio(direction, normalized, gross, confidence, concentration)
    }

    private fun correlation(a: String, b: String, map: Map<Pair<String, String>, Double>): Double =
        map[a to b] ?: map[b to a] ?: 0.0

    fun pearson(a: List<Double>, b: List<Double>): Double {
        val n = minOf(a.size, b.size)
        if (n < 3) return 0.0
        val aa = a.takeLast(n); val bb = b.takeLast(n)
        val ma = aa.average(); val mb = bb.average()
        var num = 0.0; var da = 0.0; var db = 0.0
        for (i in 0 until n) {
            val x = aa[i] - ma; val y = bb[i] - mb
            num += x * y; da += x * x; db += y * y
        }
        val den = sqrt(da * db)
        return if (den <= 1e-12) 0.0 else (num / den).coerceIn(-1.0, 1.0)
    }
}
