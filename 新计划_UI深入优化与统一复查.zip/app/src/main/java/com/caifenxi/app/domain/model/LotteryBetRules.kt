package com.caifenxi.app.domain.model

/**
 * 各彩种真实玩法口径的大小/单双/组合分类。
 *
 * - PK拾 / 飞艇 / 赛车：默认「冠亚和」大小单双（冠+亚，3～11 小、12～19 大；和值单双）。
 *   各名次另有位置大小（1～5 小、6～10 大）与位置单双，不占用主 dx/ds 字段。
 * - 快乐8 / 幸运20 / 宾果：默认「总和」大小单双（和值 ≥810 大；和值单双）。
 */
object LotteryBetRules {

    data class Classified(
        val sum: Int,
        val dx: String,
        val ds: String,
        val combo: String,
        /** 规则说明，便于 UI 展示 */
        val ruleId: String,
        val ruleLabel: String
    )

    data class Profile(
        val type: LotteryType,
        val ruleId: String,
        val ruleLabel: String,
        val dxLabel: String,
        val dsLabel: String,
        val comboLabel: String,
        val sumLabel: String,
        val dxThresholdText: String,
        val dsRuleText: String
    )

    fun profile(type: LotteryType): Profile = when (type) {
        LotteryType.PKS -> Profile(
            type = LotteryType.PKS,
            ruleId = "pks_guanya",
            ruleLabel = "冠亚和",
            dxLabel = "冠亚和大小",
            dsLabel = "冠亚和单双",
            comboLabel = "冠亚和组合",
            sumLabel = "冠亚和",
            dxThresholdText = "冠+亚：3～11 小，12～19 大",
            dsRuleText = "冠亚和值奇=单，偶=双"
        )
        LotteryType.LUCK20 -> Profile(
            type = LotteryType.LUCK20,
            ruleId = "luck20_sum",
            ruleLabel = "总和",
            dxLabel = "总和大小",
            dsLabel = "总和单双",
            comboLabel = "总和组合",
            sumLabel = "总和",
            dxThresholdText = "20 码和值：≤809 小，≥810 大",
            dsRuleText = "总和奇=单，偶=双"
        )
        LotteryType.YDH -> Profile(
            type = LotteryType.YDH,
            ruleId = "ydh_pos",
            ruleLabel = "运动会定位",
            dxLabel = "定位大小",
            dsLabel = "定位单双",
            comboLabel = "龙虎",
            sumLabel = "六位和",
            dxThresholdText = "每球1-3小、4-6大",
            dsRuleText = "1/3/5单，2/4/6双；龙虎：1vs6、2vs5、3vs4（等不中）"
        )
        LotteryType.K3 -> Profile(
            type = LotteryType.K3,
            ruleId = "k3_sum",
            ruleLabel = "快三",
            dxLabel = "和值大小",
            dsLabel = "三军",
            comboLabel = "鱼虾蟹/长牌",
            sumLabel = "三数和",
            dxThresholdText = "和值≥11大、≤10小",
            dsRuleText = "三军/鱼虾蟹点数；长牌两不同号都出现（不含二同号）"
        )
        LotteryType.PC28, LotteryType.OTHER -> Profile(
            type = type,
            ruleId = "pending",
            ruleLabel = "待设计",
            dxLabel = "大小(待定)",
            dsLabel = "单双(待定)",
            comboLabel = "组合(待定)",
            sumLabel = "和值",
            dxThresholdText = "当前仅同步开奖",
            dsRuleText = "玩法后续设计"
        )
    }

    fun profileForKey(lotteryKey: String): Profile {
        val type = LotteryConfig.findByKey(lotteryKey)?.type ?: LotteryType.PKS
        return profile(type)
    }

    fun profileOf(config: LotteryConfig): Profile = profile(config.type)

    /**
     * 按彩种规则从开奖号码计算主玩法大小/单双/组合。
     * @param apiDx API 可选：1=大 0=小（仅快乐8 类参考）
     * @param apiDs API 可选：1=单 0=双
     * @param apiSum API 可选和值
     */
    fun classify(
        type: LotteryType,
        numbers: List<Int>,
        apiSum: Int? = null,
        apiDx: Int? = null,
        apiDs: Int? = null
    ): Classified? {
        return when (type) {
            LotteryType.PKS -> classifyPks(numbers)
            LotteryType.LUCK20 -> classifyLuck20(numbers, apiSum, apiDx, apiDs)
            LotteryType.YDH -> classifyYdh(numbers)
            LotteryType.K3 -> classifyK3(numbers)
            LotteryType.PC28, LotteryType.OTHER -> null
        }
    }

    fun classifyKey(lotteryKey: String, numbers: List<Int>): Classified? {
        val type = LotteryConfig.findByKey(lotteryKey)?.type ?: return null
        return classify(type, numbers)
    }

    /** 用正确规则覆盖/补全 DrawRecord 的 sum/dx/ds/combo */
    fun enrich(record: DrawRecord): DrawRecord {
        val type = LotteryConfig.findByKey(record.lotteryKey)?.type ?: return record
        val c = classify(type, record.numbers) ?: return record
        return record.copy(
            sum = c.sum,
            dx = c.dx,
            ds = c.ds,
            combo = c.combo
        )
    }

    private fun classifyPks(numbers: List<Int>): Classified? {
        if (numbers.size < 2) return null
        // 冠、亚必须在 1～10 且互异（完整一期应 10 码不重复）
        val guan = numbers[0]
        val ya = numbers[1]
        if (guan !in 1..10 || ya !in 1..10) return null
        val guanYa = guan + ya // 3～19
        // 行业通行：12～19 大，3～11 小（11 为小）
        val dx = if (guanYa >= 12) "大" else "小"
        val ds = if (guanYa % 2 == 1) "单" else "双"
        return Classified(
            sum = guanYa,
            dx = dx,
            ds = ds,
            combo = dx + ds,
            ruleId = "pks_guanya",
            ruleLabel = "冠亚和"
        )
    }

    private fun classifyLuck20(
        numbers: List<Int>,
        apiSum: Int?,
        apiDx: Int?,
        apiDs: Int?
    ): Classified? {
        val take = if (numbers.size >= 20) numbers.take(20) else numbers
        if (take.size < 20) return null
        val sum = apiSum ?: take.sum()
        val dx = when (apiDx) {
            1 -> "大"
            0 -> "小"
            else -> if (sum >= 810) "大" else "小"
        }
        val ds = when (apiDs) {
            1 -> "单"
            0 -> "双"
            else -> if (sum % 2 == 1) "单" else "双"
        }
        return Classified(
            sum = sum,
            dx = dx,
            ds = ds,
            combo = dx + ds,
            ruleId = "luck20_sum",
            ruleLabel = "总和"
        )
    }

    /** PK 单位置大小：1～5 小，6～10 大 */
    fun positionDx(number: Int): String? = when (number) {
        in 1..5 -> "小"
        in 6..10 -> "大"
        else -> null
    }

    /** PK 单位置单双 */
    fun positionDs(number: Int): String? = when {
        number !in 1..10 -> null
        number % 2 == 1 -> "单"
        else -> "双"
    }

    /** 展示用：当前彩种主玩法三分类标题 */
    fun categoryTitles(lotteryKey: String): Triple<String, String, String> {
        val p = profileForKey(lotteryKey)
        return Triple(p.dxLabel, p.dsLabel, p.comboLabel)
    }

    /**
     * 极速运动会：6 位 1-6。
     * 主展示用第1球大小/单双；combo 存第一球龙虎（1vs6）。
     * 完整位标签由 ydhPosDx/Ds/Dt 提供给计划引擎。
     */
    fun classifyYdh(numbers: List<Int>): Classified? {
        if (numbers.size < 6) return null
        if (numbers.any { it !in 1..6 }) return null
        val n = numbers.take(6)
        val p1 = n[0]
        val dx = if (p1 in 4..6) "大" else "小"
        val ds = if (p1 % 2 == 1) "单" else "双"
        val dt = when {
            n[0] > n[5] -> "龙"
            n[0] < n[5] -> "虎"
            else -> "和" // 展示用；结算龙虎玩法「和」视为不中
        }
        return Classified(
            sum = n.sum(),
            dx = dx,
            ds = ds,
            combo = dt,
            ruleId = "ydh_pos",
            ruleLabel = "运动会定位"
        )
    }

    fun ydhBallDx(ball: Int): String = if (ball in 4..6) "大" else "小"
    fun ydhBallDs(ball: Int): String = if (ball % 2 == 1) "单" else "双"

    /** index 0→1vs6, 1→2vs5, 2→3vs4；相等返回 null（不中） */
    fun ydhDragonTiger(numbers: List<Int>, pairIndex: Int): String? {
        if (numbers.size < 6) return null
        val (a, b) = when (pairIndex) {
            0 -> numbers[0] to numbers[5]
            1 -> numbers[1] to numbers[4]
            2 -> numbers[2] to numbers[3]
            else -> return null
        }
        return when {
            a > b -> "龙"
            a < b -> "虎"
            else -> null
        }
    }

    /** 快三：3 码 1-6；和值≥11 大、≤10 小 */
    fun classifyK3(numbers: List<Int>): Classified? {
        if (numbers.size < 3) return null
        if (numbers.any { it !in 1..6 }) return null
        val n = numbers.take(3)
        val s = n.sum()
        val dx = if (s >= 11) "大" else "小"
        val ds = if (s % 2 == 1) "单" else "双"
        return Classified(
            sum = s,
            dx = dx,
            ds = ds,
            combo = dx + ds,
            ruleId = "k3_sum",
            ruleLabel = "快三和值"
        )
    }

    /** 长牌：两个不同点数都出现（不含二同号/豹子） */
    fun k3ChangPaiHit(numbers: List<Int>, a: Int, b: Int): Boolean {
        if (a == b) return false
        if (a !in 1..6 || b !in 1..6) return false
        val set = numbers.filter { it in 1..6 }.toSet()
        return a in set && b in set
    }

    fun k3SanJunHit(numbers: List<Int>, point: Int): Boolean =
        point in 1..6 && numbers.any { it == point }

}
