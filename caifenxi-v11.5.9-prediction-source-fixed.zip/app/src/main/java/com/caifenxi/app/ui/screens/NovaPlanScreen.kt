package com.caifenxi.app.ui.screens

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.caifenxi.app.domain.model.PlanDefinition
import com.caifenxi.app.domain.model.CustomPlan
import com.caifenxi.app.domain.model.PlanPredictionRecord
import com.caifenxi.app.domain.model.DrawRecord
import com.caifenxi.app.domain.plan.NovaPlanAnalytics
import com.caifenxi.app.domain.plan.NovaPlanPool
import com.caifenxi.app.domain.plan.NovaPlanWorkbench
import com.caifenxi.app.ui.MainViewModel
import com.caifenxi.app.ui.components.CaptionMuted
import com.caifenxi.app.ui.components.GlobalCard
import com.caifenxi.app.ui.components.PrimaryButton
import com.caifenxi.app.ui.theme.CaiTokens
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

/**
 * Nova 新计划池：完整可视化入口。
 * 重点解决：计划打不开、没有排行榜/胜率、没有大小单双/组合/数字/位置分类、
 * 没有一期/二期/三期周期、无法筛选、无法切换到预测/驾驶舱的问题。
 */
@Composable
fun NovaPlanScreen(vm: MainViewModel) {
    var page by remember { mutableStateOf("总览") }
    var playType by remember { mutableStateOf("全部") }
    var group by remember { mutableStateOf("全部") }
    var position by remember { mutableStateOf("全部") }
    var cycle by remember { mutableStateOf(1) }
    var search by remember { mutableStateOf("") }
    var selectedId by remember { mutableStateOf<String?>(null) }
    var backtestPeriods by remember { mutableStateOf(100) }
    var arenaRows by remember { mutableStateOf<List<NovaPlanWorkbench.ArenaRow>>(emptyList()) }
    var selectedReport by remember { mutableStateOf<NovaPlanAnalytics.BacktestReport?>(null) }
    var running by remember { mutableStateOf(false) }
    var explanation by remember { mutableStateOf<NovaPlanWorkbench.Explanation?>(null) }
    var ensemble by remember { mutableStateOf<NovaPlanWorkbench.Ensemble?>(null) }
    var showCreateDialog by remember { mutableStateOf(false) }
    var customName by remember { mutableStateOf("") }
    var customTemplateId by remember { mutableStateOf(NovaPlanPool.ALL.firstOrNull()?.planId.orEmpty()) }
    var customWindow by remember { mutableStateOf(30) }
    var customCycle by remember { mutableStateOf(1) }
    val scope = rememberCoroutineScope()
    val history = vm.history.value
    val cockpitId = vm.prefs.value.cockpitPlanId
    val novaCustomPlans = vm.customPlans.value.map { it.toDefinition() }.filter { it.planId.startsWith("NOVA-CUSTOM-") }
    val allNovaPlans = (NovaPlanPool.ALL + novaCustomPlans).distinctBy { it.planId }
    val allGroups = (NovaPlanPool.GROUPS + novaCustomPlans.map { it.category.removePrefix("Nova-") }).distinct()
    val filtered = allNovaPlans.filter { p ->
        (playType == "全部" || p.playType == playType) &&
            (group == "全部" || p.category == "Nova-$group") &&
            (position == "全部" || (p.positionIndex >= 0 && NovaPlanPool.meta(p).positionLabel == position)) &&
            (search.isBlank() || p.planId.contains(search, true) || p.planName.contains(search, true))
    }
    // 只有用户主动点「查看」后才选中；不默认落到第一个，避免“点了没反应”的错觉
    val selected = selectedId?.let { id ->
        filtered.firstOrNull { it.planId == id }
            ?: allNovaPlans.firstOrNull { it.planId == id }
            ?: NovaPlanPool.find(id)
    }
    val listState = rememberLazyListState()
    LaunchedEffect(selectedId) {
        if (selectedId != null) {
            // 详情卡固定在列表顶部附近，滚动回去让用户立刻看到
            listState.animateScrollToItem(0)
        }
    }

    // 周期变化时清空旧回测结果，避免仍显示「一期」胜率
    LaunchedEffect(cycle) {
        arenaRows = emptyList()
        selectedReport = null
        ensemble = null
    }
    LaunchedEffect(page) {
        if (page == "共识预测") vm.refreshPlanConsensusTab()
    }

    if (showCreateDialog) {
        val template = allNovaPlans.firstOrNull { it.planId == customTemplateId } ?: NovaPlanPool.ALL.first()
        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            title = { Text("新增 Nova 计划", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(customName, { customName = it }, label = { Text("计划名称") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Text("复制模板：${template.planName}", fontWeight = FontWeight.SemiBold)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        allNovaPlans.take(30).forEach { p ->
                            FilterChip(selected = p.planId == customTemplateId, onClick = { customTemplateId = p.planId }, label = { Text(p.planName.take(8), fontSize = 10.sp) })
                        }
                    }
                    Text("玩法：${template.playType}${if (template.positionIndex >= 0) " · ${NovaPlanPool.meta(template).positionLabel}" else ""}")
                    Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        listOf(10,20,30,50,100,200,500).forEach { n -> FilterChip(selected = customWindow == n, onClick = { customWindow = n }, label = { Text("${n}期") }) }
                    }
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        NovaPlanPool.CYCLE_OPTIONS.forEach { n -> FilterChip(selected = customCycle == n, onClick = { customCycle = n }, label = { Text("${n}期") }) }
                    }
                    CaptionMuted("新增计划会持久化到本彩种，立即进入 Nova 计划库、战绩、排行榜、回测和驾驶舱选择。")
                }
            },
            confirmButton = {
                Button(onClick = {
                    val name = customName.trim().ifBlank { "${template.planName}·自定义" }
                    val id = "NOVA-CUSTOM-${System.currentTimeMillis()}"
                    val encoded = "NovaCustom|${template.playType}|${template.positionIndex}|${template.category.removePrefix("Nova-")}"
                    vm.saveCustomPlan(CustomPlan(
                        planId = id, lotteryKey = vm.currentLottery.value.key, planName = name, category = encoded,
                        algorithm = template.algorithm, window = customWindow, cyclePeriods = customCycle,
                        outputFormat = template.outputFormat.name, hitCriteria = template.hitCriteria.name, enabled = true, participateConsensus = true
                    ))
                    customName = ""
                    customWindow = 30
                    customCycle = 1
                    showCreateDialog = false
                }) { Text("保存") }
            },
            dismissButton = { TextButton(onClick = { showCreateDialog = false }) { Text("取消") } }
        )
    }

    LazyColumn(
        state = listState,
        modifier = Modifier.fillMaxSize().padding(horizontal = CaiTokens.ScreenHPadding, vertical = CaiTokens.S12),
        verticalArrangement = Arrangement.spacedBy(CaiTokens.S8)
    ) {
        item {
            Text("新计划池", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            CaptionMuted("NovaPlan ${NovaPlanPool.VERSION} · 独立新算法池，但预测、驾驶舱、挂机、悬浮窗统一互通")
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("总览", "计划库", "回测", "历史记录", "预测记录", "共识预测", "计划详情", "排行榜", "战绩", "计划组合").forEach { p ->
                    FilterChip(selected = page == p, onClick = { page = p }, label = { Text(p) })
                }
            }
        }

        item {
            GlobalCard(containerColor = MaterialTheme.colorScheme.secondaryContainer) {
                Text("统一来源", fontWeight = FontWeight.Bold)
                Text(if (cockpitId.isBlank()) "当前：算法/计划池自动模式" else "当前驾驶舱：$cockpitId · 周期${vm.prefs.value.cockpitPlanCyclePeriods}期")
                Spacer(Modifier.height(6.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PrimaryButton(
                        if (selected != null) "将当前计划切到预测/驾驶舱" else "请选择计划",
                        onClick = { selected?.let { vm.selectCockpitPlan(it.planId, cycle) } },
                        enabled = selected != null,
                        modifier = Modifier.weight(1f)
                    )
                    PrimaryButton("恢复自动", onClick = { vm.selectCockpitPlan("") }, ghost = true, modifier = Modifier.weight(1f))
                }
            }
        }

        item {
            GlobalCard {
                Text("计划筛选", fontWeight = FontWeight.Bold)
                OutlinedTextField(
                    value = search,
                    onValueChange = { search = it },
                    modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
                    singleLine = true,
                    label = { Text("搜索计划名称 / ID") }
                )
                FilterRow("玩法", listOf("全部") + NovaPlanPool.PLAY_TYPES, playType) { playType = it }
                FilterRow("算法组", listOf("全部") + allGroups, group) { group = it }
                FilterRow("位置", listOf("全部", "冠军", "亚军", "第3", "第4", "第5", "第6", "第7", "第8", "第9", "第10"), position) { position = it }
                FilterRow("执行周期", NovaPlanPool.CYCLE_OPTIONS.map { "${it}期" }, "${cycle}期") { cycle = it.removeSuffix("期").toInt() }
                CaptionMuted("当前筛选 ${filtered.size} 个计划 · 周期只控制本次执行/追踪窗口，不改变历史回测数据")
            }
        }

        
        // 选中计划后，详情固定展示在顶部，避免埋在长列表底部“点不开”
        selected?.let { plan ->
            item(key = "detail-${plan.planId}") {
                PlanDetailCard(
                    plan = plan,
                    history = history,
                    records = vm.planHistory.value,
                    prefs = vm.prefs.value,
                    cycle = cycle,
                    runtime = vm.planVM.runtimeForPlan(plan.planId),
                    currentPrediction = vm.currentPredictions.value.firstOrNull { it.planId == plan.planId },
                    selected = plan.planId == cockpitId,
                    onUse = { vm.selectCockpitPlan(plan.planId, cycle) },
                    onExplain = {
                        explanation = NovaPlanWorkbench.explain(plan, history)
                            ?: NovaPlanWorkbench.Explanation(plan.planId, plan.planName, 0, "样本不足", 0.0, listOf("提示" to 1.0))
                    },
                    onViewRecords = { page = "战绩" },
                    onClose = { selectedId = null; explanation = null }
                )
            }
        }
        explanation?.let { e ->
            item(key = "explain-${e.planId}") {
                GlobalCard(containerColor = MaterialTheme.colorScheme.primaryContainer) {
                    Text("计划解释", fontWeight = FontWeight.Bold)
                    Text(e.title, style = MaterialTheme.typography.titleMedium)
                    CaptionMuted("${e.planId} · 输入 ${e.inputWindow}期 · 输出 ${e.output}")
                    e.factors.forEach { (name, value) -> Text("$name · ${(value * 100).toInt()}/100") }
                    TextButton(onClick = { explanation = null }) { Text("关闭解释") }
                }
            }
        }

        when (page) {
            "总览" -> renderOverview(this, history, filtered, selected, backtestPeriods) { page = it }

            "计划库" -> renderPlanLibrary(
                this, history, vm.planHistory.value, filtered, selected, cycle,
                vm.prefs.value,
                onSelect = { selectedId = it; vm.loadPlanDetail(it); page = "计划详情" },
                onExplain = { p ->
                    explanation = NovaPlanWorkbench.explain(p, history)
                        ?: NovaPlanWorkbench.Explanation(p.planId, p.planName, 0, "样本不足", 0.0, listOf("提示" to 1.0))
                },
                onAdd = { showCreateDialog = true }
            )

            "回测" -> {
                item {
                    ArenaHeader(
                        periods = backtestPeriods,
                        onPeriods = { backtestPeriods = it },
                        running = running,
                        onRun = {
                            selected?.let { plan ->
                                scope.launch {
                                    running = true
                                    selectedReport = withContext(Dispatchers.Default) {
                                        NovaPlanAnalytics.backtest(
                                            plan.copy(cyclePeriods = cycle),
                                            history,
                                            backtestPeriods.coerceAtMost(10000)
                                        )
                                    }
                                    running = false
                                }
                            }
                        }
                    )
                }
                if (selected == null) {
                    item { GlobalCard { Text("请先在计划库选择计划"); CaptionMuted("选择计划后，这里会按照计划引擎的滚动验证口径展示回测结果。") } }
                } else {
                    item { BacktestCard(selected, selectedReport) }
                    selectedReport?.let { report ->
                        item {
                            GlobalCard {
                                Text("回测明细", fontWeight = FontWeight.Bold)
                                CaptionMuted("计划 ${selected.planName} · 执行周期 ${cycle}期 · 窗口 ${backtestPeriods}期")
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                                    SummaryBox("样本", report.periods.toString(), Modifier.weight(1f))
                                    SummaryBox("命中", report.hits.toString(), Modifier.weight(1f))
                                    SummaryBox("错", report.misses.toString(), Modifier.weight(1f))
                                    SummaryBox("胜率", "${(report.hitRate * 100).roundToInt()}%", Modifier.weight(1f))
                                }
                                Spacer(Modifier.height(8.dp))
                                Text("基准 ${(report.randomBaseline * 100).roundToInt()}% · Edge ${(report.edge * 100).roundToInt()}% · 稳定性 ${(report.stability * 100).roundToInt()}%")
                                Text("最长连中 ${report.maxHitStreak} · 最长连错 ${report.maxMissStreak}")
                            }
                        }
                    }
                }
            }

            "历史记录" -> {
                val rows = if (selected == null) vm.planHistory.value else vm.planHistory.value.filter { it.planId == selected.planId }
                item {
                    GlobalCard {
                        Text("历史纪录", fontWeight = FontWeight.Bold)
                        CaptionMuted("完全复用计划引擎的历史预测记录口径：预测期、截止期、计划、输出、评分、权重、结算结果均保留。")
                        Text("${selected?.planName ?: "全部 Nova 计划"} · 共 ${rows.size} 条")
                    }
                }
                if (rows.isEmpty()) {
                    item { GlobalCard { Text("暂无历史纪录"); CaptionMuted("先执行回测或等待开奖结算。") } }
                } else {
                    rows.take(500).forEach { r ->
                        item(key = "history-${r.planId}-${r.targetIssue}-${r.cutoffIssue}") {
                            HistoryRecordCard(r)
                        }
                    }
                    if (rows.size > 500) item { CaptionMuted("当前展示最近 500 条；底层历史不限制 500 期。") }
                }
            }

            "预测记录" -> {
                val target = vm.nextIssueText.value.takeIf { it.isNotBlank() && it != "-" }
                    ?: vm.planVM.planTargetIssue.value
                val current = vm.currentPredictions.value.filter { target.isBlank() || target == "-" || it.targetIssue == target }
                item {
                    GlobalCard {
                        Text("预测记录", fontWeight = FontWeight.Bold)
                        CaptionMuted("目标第 ${if (target.isBlank()) "-" else target} 期 · 当前 Nova 计划预测")
                        Text("${current.size} 个计划正在输出")
                    }
                }
                if (current.isEmpty()) {
                    item { GlobalCard { Text("暂无本期预测"); CaptionMuted("请先首页刷新开奖，或运行一次计划回测。") } }
                } else {
                    current.forEach { r ->
                        item(key = "predict-${r.planId}-${r.targetIssue}") {
                            GlobalCard {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Column(Modifier.weight(1f)) {
                                        Text(r.planName.ifBlank { r.planId }, fontWeight = FontWeight.Bold)
                                        CaptionMuted("${r.planId} · ${r.category} · 目标 ${r.targetIssue}")
                                        Text(r.output, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                    }
                                    Column(horizontalAlignment = androidx.compose.ui.Alignment.End) {
                                        Text("${r.scoreAtPredict.toInt()}分", fontWeight = FontWeight.Bold)
                                        Text("权重 ${"%.2f".format(r.weightAtPredict)}", fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            "共识预测" -> {
                val target = vm.nextIssueText.value.takeIf { it.isNotBlank() && it != "-" }
                    ?: vm.planVM.planTargetIssue.value
                val cons = vm.consensus.value.filter { it.targetIssue == target }
                val records = vm.consensusRecords.value
                item {
                    GlobalCard {
                        Text("共识预测 · 目标第 ${if (target.isBlank()) "-" else target} 期", fontWeight = FontWeight.Bold)
                        CaptionMuted("与计划引擎共识预测保持同一数据源，并同步挂机的「来源=共识」。")
                    }
                }
                if (cons.isEmpty()) {
                    item { GlobalCard { Text("当前目标期暂无共识预测"); CaptionMuted("请首页同步开奖后再刷新，或先执行计划池回测。") } }
                } else {
                    cons.forEach { c ->
                        item(key = "nova-consensus-${c.category}-${c.targetIssue}") {
                            val rec = records.firstOrNull { it.targetIssue == c.targetIssue && it.category == c.category }
                            val resultColor = when (rec?.result) {
                                "对" -> Color(0xFF2E7D32)
                                "错" -> Color(0xFFC62828)
                                else -> Color(0xFFF9A825)
                            }
                            GlobalCard {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("${c.category} → ${c.leadingDirection}", fontWeight = FontWeight.Bold)
                                    Text(rec?.result ?: "待开", fontWeight = FontWeight.Bold, color = resultColor)
                                }
                                CaptionMuted("支持 ${(c.supportRatio * 100).roundToInt()}% · ${c.participatingPlans} 个计划 · 分歧 ${(c.disagreement * 100).roundToInt()}%")
                                if (c.detail.isNotEmpty()) {
                                    CaptionMuted("候选：" + c.detail.entries.sortedByDescending { it.value }.joinToString(" · ") { "${it.key} ${(it.value * 100).roundToInt()}%" })
                                }
                                LinearProgressIndicator(
                                    progress = { c.supportRatio.toFloat().coerceIn(0f, 1f) },
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                                )
                            }
                        }
                    }
                }
            }

            "计划详情" -> {
                if (selected == null) {
                    item { GlobalCard { Text("暂无计划详情"); CaptionMuted("请先进入计划库，点击一个 Nova 计划。") } }
                } else {
                    item {
                        PlanDetailCard(
                            plan = selected,
                            history = history,
                            records = vm.planHistory.value,
                            prefs = vm.prefs.value,
                            cycle = cycle,
                            runtime = vm.planVM.runtimeForPlan(selected.planId),
                            currentPrediction = vm.currentPredictions.value.firstOrNull { it.planId == selected.planId },
                            selected = selected.planId == cockpitId,
                            onUse = { vm.selectCockpitPlan(selected.planId, cycle) },
                            onExplain = {
                                explanation = NovaPlanWorkbench.explain(selected, history)
                                    ?: NovaPlanWorkbench.Explanation(selected.planId, selected.planName, selected.window, "样本不足", 0.0, listOf("提示" to 1.0))
                            },
                            onViewRecords = { page = "历史记录" },
                            onClose = { selectedId = null; explanation = null; page = "计划库" }
                        )
                    }
                    item {
                        GlobalCard {
                            Text("计划详情 · 引擎参数", fontWeight = FontWeight.Bold)
                            CaptionMuted("计划 = 算法 + 参数 + 窗口 + 玩法；Nova 与原计划引擎共享运行时、回测和结算数据。")
                            Text("算法：${selected.algorithm}")
                            Text("玩法：${selected.playType}${if (selected.positionIndex >= 0) " · ${NovaPlanPool.meta(selected).positionLabel}" else ""}")
                            Text("输入窗口：${selected.window}期 · 执行周期：${cycle}期")
                            Text("基准：${selected.baselineType} · ${selected.baselineValue}")
                            Text("参与共识：${if (selected.participateConsensus) "是" else "否"} · 组合：${if (selected.participateCombo) "是" else "否"}")
                        }
                    }
                }
            }

            "排行榜" -> {
                item {
                    ArenaHeader(
                        periods = backtestPeriods,
                        onPeriods = { backtestPeriods = it },
                        running = running,
                        onRun = {
                            scope.launch {
                                running = true
                                arenaRows = withContext(Dispatchers.Default) {
                                    NovaPlanWorkbench.arena(history, backtestPeriods.coerceAtMost(10000), filtered.ifEmpty { allNovaPlans }.take(100), cycle)
                                }
                                running = false
                            }
                        }
                    )
                }
                if (arenaRows.isNotEmpty()) item { CaptionMuted("按执行 ${cycle} 期回测；评分综合胜率、样本、Edge、稳定性和连挂风险。") }
                arenaRows.filter { filtered.any { p -> p.planId == it.plan.planId } }.take(100).forEach { row ->
                    item(key = "rank-${row.plan.planId}") {
                        RankingRow(row, row.plan.planId == selected?.planId) { selectedId = row.plan.planId; vm.loadPlanDetail(row.plan.planId); page = "计划详情" }
                    }
                }
                if (arenaRows.isEmpty()) item { CaptionMuted("选择周期后点击开始回测/更新排行榜。") }
            }

            "战绩" -> renderRecords(this, history, vm.planHistory.value, selected, cycle)

            "计划组合" -> {
                item {
                    GlobalCard {
                        Text("NovaPlan Ensemble", fontWeight = FontWeight.Bold)
                        CaptionMuted("按排行榜评分生成低相关计划组合；组合仍需单独回测。")
                        PrimaryButton("生成组合", onClick = { ensemble = NovaPlanWorkbench.diverseEnsemble(arenaRows) }, modifier = Modifier.fillMaxWidth())
                        ensemble?.let { e ->
                            Spacer(Modifier.height(8.dp))
                            e.planIds.forEachIndexed { index, id ->
                                Text("${index + 1}. $id · 权重 ${"%.1f".format((e.weights[id] ?: 0.0) * 100)}%")
                            }
                        }
                    }
                }
            }
        }

    }
}

@Composable
private fun FilterRow(title: String, options: List<String>, selected: String, onSelect: (String) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        Text("$title", modifier = Modifier.padding(top = 8.dp), fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
        options.forEach { value -> FilterChip(selected = selected == value, onClick = { onSelect(value) }, label = { Text(value, fontSize = 11.sp) }) }
    }
}

private fun renderOverview(
    scope: LazyListScope,
    history: List<DrawRecord>,
    plans: List<PlanDefinition>,
    selected: PlanDefinition?,
    periods: Int,
    go: (String) -> Unit
) {
    scope.item {
        GlobalCard {
            Text("新计划池驾驶舱", fontWeight = FontWeight.Bold)
            Text("${plans.size} 个计划 · 回测窗口 ${periods} 期 · 支持大小/单双/组合/数字/位置")
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                SummaryBox("大小", plans.count { it.playType == "大小" }.toString(), Modifier.weight(1f))
                SummaryBox("单双", plans.count { it.playType == "单双" }.toString(), Modifier.weight(1f))
                SummaryBox("组合", plans.count { it.playType == "组合" }.toString(), Modifier.weight(1f))
                SummaryBox("数字", plans.count { it.playType == "数字" }.toString(), Modifier.weight(1f))
                SummaryBox("位置", plans.count { it.playType == "位置" }.toString(), Modifier.weight(1f))
            }
            Spacer(Modifier.height(8.dp))
            CaptionMuted("竞品常见的“计划→周期→结果→胜率→排行”链路已经统一到 Nova；历史开奖与回测数据继续由原数据层提供。")
            if (selected != null) Text("当前计划：${selected.planName} · ${selected.playType}${if (selected.positionIndex >= 0) " · ${NovaPlanPool.meta(selected).positionLabel}" else ""}")
            Spacer(Modifier.height(6.dp))
            PrimaryButton("打开计划库", onClick = { go("计划库") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                PrimaryButton("排行榜", onClick = { go("排行榜") }, ghost = true, modifier = Modifier.weight(1f))
                PrimaryButton("战绩", onClick = { go("战绩") }, ghost = true, modifier = Modifier.weight(1f))
                PrimaryButton("回测", onClick = { go("回测") }, ghost = true, modifier = Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun SummaryBox(label: String, value: String, modifier: Modifier) {
    Column(modifier, horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally) {
        Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text(label, fontSize = 10.sp)
    }
}

private fun renderPlanLibrary(
    scope: LazyListScope,
    history: List<DrawRecord>,
    records: List<PlanPredictionRecord>,
    plans: List<PlanDefinition>,
    selected: PlanDefinition?,
    cycle: Int,
    prefs: com.caifenxi.app.domain.model.UserPrefs,
    onSelect: (String) -> Unit,
    onExplain: (PlanDefinition) -> Unit,
    onAdd: () -> Unit
) {
    scope.item {
        GlobalCard {
            Text("计划记录", fontWeight = FontWeight.Bold)
            CaptionMuted("按竞品式表格查看：计划周期 / 最终截止 / 计划结果 / 推荐号；点击任意计划即可打开详情、回测和战绩。")
            PrimaryButton("＋ 新增计划", onClick = onAdd, modifier = Modifier.fillMaxWidth())
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("计划周期", fontWeight = FontWeight.Bold)
                Text("最终截止", fontWeight = FontWeight.Bold)
                Text("计划结果", fontWeight = FontWeight.Bold)
                Text("推荐号", fontWeight = FontWeight.Bold)
            }
        }
    }
    // 不使用 LazyListScope.items(List) 扩展，避免不同 Compose 版本下的泛型/作用域解析问题。
    // 所有计划仍作为独立的 LazyList item 渲染，不改变原有 UI 和交互。
    if (plans.size > 80) {
        scope.item {
            CaptionMuted("当前筛选 ${plans.size} 个，列表仅渲染前 80 个以保持流畅；请用玩法/分组/搜索继续缩小范围。")
        }
    }
    plans.take(80).forEach { plan ->
        scope.item {
            // 列表不在主线程同步跑 predict，避免卡顿；推荐号优先用已有战绩/预测记录
            val latest = records.firstOrNull { record -> record.planId == plan.planId }
            val preview = latest?.output ?: "点查看"
            GlobalCard(containerColor = if (selected?.planId == plan.planId) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface, onClick = { onSelect(plan.planId) }) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(Modifier.weight(1.1f)) {
                        Text("1/${cycle}期", fontWeight = FontWeight.SemiBold)
                        Text("执行周期", fontSize = 11.sp)
                    }
                    Column(Modifier.weight(1f)) {
                        Text("窗口${plan.window}期")
                        Text("截止${history.lastOrNull()?.issue ?: "-"}", fontSize = 11.sp)
                    }
                    Column(Modifier.weight(1.2f)) {
                        Text(if (latest?.settled == true) if (latest.hit == true) "中" else "错" else "待开")
                        Text(plan.playType, fontSize = 11.sp)
                    }
                    Column(Modifier.weight(1.6f)) {
                        Text(preview, fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            FilterChip(selected = selected?.planId == plan.planId, onClick = { onSelect(plan.planId) }, label = { Text("查看") })
                            FilterChip(selected = false, onClick = { onExplain(plan) }, label = { Text("解释") })
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RankingRow(row: NovaPlanWorkbench.ArenaRow, selected: Boolean, onSelect: () -> Unit) {
    // 整卡可点，避免只点小按钮“没反应”
    GlobalCard(
        containerColor = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
        onClick = onSelect
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column(Modifier.weight(1f)) {
                Text(row.plan.planName, fontWeight = FontWeight.SemiBold)
                CaptionMuted("${row.plan.planId} · ${row.plan.playType}${if (row.plan.positionIndex >= 0) " · ${NovaPlanPool.meta(row.plan).positionLabel}" else ""}")
                Text("胜率 ${(row.report.hitRate * 100).toInt()}% · 样本 ${row.report.periods} · 连中 ${row.report.maxHitStreak} · 连错 ${row.report.maxMissStreak}")
                Text("Edge ${(row.report.edge * 100).toInt()}% · 稳定性 ${(row.report.stability * 100).toInt()}% · ${row.lifecycle}", fontSize = 11.sp)
            }
            Column(horizontalAlignment = androidx.compose.ui.Alignment.End) {
                Text("${row.rankScore.toInt()}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("查看详情", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        }
    }
}

private fun renderRecords(
    scope: LazyListScope,
    history: List<DrawRecord>,
    records: List<PlanPredictionRecord>,
    selected: PlanDefinition?,
    cycle: Int
) {
    val rows = if (selected == null) records else records.filter { it.planId == selected.planId }
    scope.item {
        GlobalCard {
            Text("计划战绩", fontWeight = FontWeight.Bold)
            CaptionMuted("只统计已结算预测；完整数据不限制500期，当前页面按最近记录分页展示。")
            Text("${selected?.planName ?: "全部计划"} · 周期 ${cycle}期 · 记录 ${rows.size}")
        }
    }
    rows.take(200).forEach { r ->
        scope.item(key = "${r.planId}-${r.targetIssue}-${r.cutoffIssue}") {
            GlobalCard {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(Modifier.weight(1f)) {
                        Text("${r.targetIssue} · ${r.planName}", fontWeight = FontWeight.SemiBold)
                        Text("${r.category} · 预测 ${r.output}", fontSize = 12.sp)
                        Text(if (r.settled) "已结算 · ${if (r.hit == true) "中" else "错"}" else "待开", fontSize = 12.sp)
                    }
                    Text(if (r.hit == true) "中" else if (r.settled) "错" else "?", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun HistoryRecordCard(r: PlanPredictionRecord) {
    val result = when {
        !r.settled -> "待开"
        r.hit == true -> "中"
        else -> "错"
    }
    val resultColor = when (result) {
        "中" -> Color(0xFF2E7D32)
        "错" -> Color(0xFFC62828)
        else -> Color(0xFFF9A825)
    }
    GlobalCard {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column(Modifier.weight(1f)) {
                Text("第 ${r.targetIssue} 期 · ${r.planName.ifBlank { r.planId }}", fontWeight = FontWeight.Bold)
                CaptionMuted("截止 ${r.cutoffIssue} · ${r.category}")
                Text("预测：${r.output}", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                CaptionMuted("预测评分 ${"%.1f".format(r.scoreAtPredict)} · 权重 ${"%.3f".format(r.weightAtPredict)}")
            }
            Text(result, fontWeight = FontWeight.Bold, color = resultColor, fontSize = 16.sp)
        }
    }
}

@Composable
private fun BacktestCard(plan: PlanDefinition, report: NovaPlanAnalytics.BacktestReport?) {
    GlobalCard {
        Text("${plan.planName} · 回测结果", fontWeight = FontWeight.Bold)
        if (report == null) CaptionMuted("正在计算或历史样本不足") else {
            Text("样本 ${report.periods} · 对 ${report.hits} · 错 ${report.misses}")
            Text("胜率 ${(report.hitRate * 100).toInt()}% · 随机基准 ${(report.randomBaseline * 100).toInt()}% · Edge ${(report.edge * 100).toInt()}%")
            Text("最大连中 ${report.maxHitStreak} · 最大连错 ${report.maxMissStreak} · 稳定性 ${(report.stability * 100).toInt()}%")
        }
    }
}

@Composable
private fun PlanDetailCard(
    plan: PlanDefinition,
    history: List<DrawRecord>,
    records: List<PlanPredictionRecord>,
    prefs: com.caifenxi.app.domain.model.UserPrefs,
    cycle: Int,
    runtime: com.caifenxi.app.domain.model.PlanRuntime,
    currentPrediction: PlanPredictionRecord?,
    selected: Boolean,
    onUse: () -> Unit,
    onExplain: () -> Unit,
    onViewRecords: () -> Unit,
    onClose: () -> Unit = {}
) {
    val count = when (plan.playType) {
        "组合" -> prefs.comboPredCount
        "数字" -> prefs.zuheTopN
        "位置" -> prefs.positionTopN
        else -> 1
    }
    val result = NovaPlanAnalytics.predict(plan.copy(cyclePeriods = cycle), history, count)
    val historyRows = records.filter { it.planId == plan.planId }.take(10)
    GlobalCard(containerColor = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("计划详情 · ${plan.planName}", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            TextButton(onClick = onClose) { Text("关闭") }
        }
        CaptionMuted("${plan.planId} · ${plan.algorithm} · ${plan.playType}${if (plan.positionIndex >= 0) " · ${NovaPlanPool.meta(plan).positionLabel}" else ""} · 窗口${plan.window}期 · 执行${cycle}期（生涯胜率来自引擎；周期胜率请到「回测/排行榜」按当前周期计算）")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            SummaryBox("胜率", runtime.hitRatePercent, Modifier.weight(1f))
            SummaryBox("样本", runtime.sampleCount.toString(), Modifier.weight(1f))
            SummaryBox("连中", runtime.maxConsecutiveHit.toString(), Modifier.weight(1f))
            SummaryBox("连错", runtime.maxConsecutiveMiss.toString(), Modifier.weight(1f))
        }
        Spacer(Modifier.height(8.dp))
        Text("当期预测：${currentPrediction?.output ?: result?.output ?: "暂无"}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        CaptionMuted("目标期 ${currentPrediction?.targetIssue ?: "-"} · 输出数量按设置：组合${prefs.comboPredCount} / 号码${prefs.zuheTopN} / 位置${prefs.positionTopN}")
        if (historyRows.isNotEmpty()) {
            Spacer(Modifier.height(6.dp))
            Text("最近战绩", fontWeight = FontWeight.SemiBold)
            historyRows.forEach { r -> Text("${r.targetIssue} · ${r.output} · ${if (!r.settled) "待开" else if (r.hit == true) "中" else "错"}", fontSize = 12.sp) }
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            PrimaryButton(if (selected) "已用于驾驶舱" else "用于驾驶舱", onClick = onUse, modifier = Modifier.weight(1f), enabled = !selected)
            PrimaryButton("全部战绩", onClick = onViewRecords, ghost = true, modifier = Modifier.weight(1f))
            PrimaryButton("解释", onClick = onExplain, ghost = true, modifier = Modifier.weight(1f))
        }
    }
}

@Composable
private fun ArenaHeader(periods: Int, onPeriods: (Int) -> Unit, running: Boolean, onRun: () -> Unit) {
    GlobalCard {
        Text("排行榜 / 回测窗口", fontWeight = FontWeight.Bold)
        CaptionMuted("回测期数手动调整；支持20～10000期。历史战绩和回测窗口不再固定500期。")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { onPeriods((periods - 50).coerceAtLeast(20)) }) { Text("−") }
            Text("${periods}期", modifier = Modifier.padding(top = 12.dp))
            OutlinedButton(onClick = { onPeriods((periods + 50).coerceAtMost(10000)) }) { Text("+") }
        }
        PrimaryButton(if (running) "计算中…" else "开始回测 / 更新排行榜", onClick = onRun, modifier = Modifier.fillMaxWidth(), enabled = !running)
    }
}
