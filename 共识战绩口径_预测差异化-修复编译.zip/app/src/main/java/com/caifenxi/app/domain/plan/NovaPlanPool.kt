package com.caifenxi.app.domain.plan

import com.caifenxi.app.domain.model.PlanDefinition
import com.caifenxi.app.domain.model.PlanHitCriteria
import com.caifenxi.app.domain.model.PlanOutputFormat

/**
 * NovaPlan 全新算法池。
 *
 * 与旧 PlanPool 分离：旧池继续保留，Nova 负责“竞品式计划”体验：
 * 玩法分类、位置、周期、排行榜、计划战绩、可调回测窗口、精确计划选择。
 */
object NovaPlanPool {
    const val VERSION = "NOVAPLAN-96-V2.0"

    data class Meta(
        val playType: String,
        val positionIndex: Int = -1,
        val positionLabel: String = ""
    )

    private data class Spec(val prefix: String, val group: String, val names: List<String>, val algo: String)

    private val specs = listOf(
        Spec("A", "状态变化", listOf("状态持续性","状态切换率","状态反转","状态惯性","状态加速","状态减速","状态震荡","状态突破","状态回落","状态连续段","状态断点","组合状态"), "STATE"),
        Spec("B", "节奏周期", listOf("间隔均值","间隔波动","间隔压缩","间隔扩张","回补窗口","周期重合","周期偏移","节奏断裂","节奏恢复","多周期节奏"), "RHYTHM"),
        Spec("C", "关系网络", listOf("共现网络","排斥网络","邻接网络","跳跃关系","前后期关联","二元关系","三元关系","局部团簇","网络中心性","网络断裂","网络迁移","动态关系"), "NETWORK"),
        Spec("D", "历史相似", listOf("形态相似","节奏相似","分布相似","连续状态相似","遗漏结构相似","综合走势相似","局部相似","多窗口相似","相似阶段映射","相似度共识"), "SIMILAR"),
        Spec("E", "结构形态", listOf("密度结构","分区结构","间距结构","聚散结构","连续结构","重复结构","尾部结构","奇偶结构","和值结构","综合形态"), "STRUCT"),
        Spec("F", "异常偏移", listOf("频率偏移","分布偏移","节奏异常","结构异常","连续异常","关系异常","多指标异常","异常恢复"), "ANOMALY"),
        Spec("G", "候选池", listOf("核心候选池","边缘候选池","稳定候选池","变化候选池","关系候选池","相似候选池","异常候选池","多源候选池","候选池轮换","候选池覆盖"), "CANDIDATE"),
        Spec("H", "组合优化", listOf("最大覆盖","最低重复","区域覆盖","结构覆盖","候选分散","核心优先","风险分层","多计划覆盖","差异化组合","组合平衡","低相关组合","组合轮换","多目标优化","自适应组合"), "OPTIMIZE")
    )

    private val playTypes = listOf("大小", "单双", "组合", "数字", "位置")

    val ALL: List<PlanDefinition> = specs.flatMap { spec ->
        spec.names.mapIndexed { index, name ->
            val playType = playTypes[index % playTypes.size]
            val positionIndex = if (playType == "位置") index % 10 else -1
            val window = listOf(10, 20, 30, 50, 100, 200, 500)[index % 7]
            val output = when (playType) {
                "数字", "位置" -> PlanOutputFormat.NUMBER_SCORES
                "组合" -> PlanOutputFormat.DIRECTION
                else -> PlanOutputFormat.DIRECTION
            }
            val criteria = when (playType) {
                "数字", "位置" -> PlanHitCriteria.TOP20_HIT
                else -> PlanHitCriteria.DIRECTION_MATCH
            }
            PlanDefinition(
                planId = "NOVA-${spec.prefix}-${(index + 1).toString().padStart(2, '0')}",
                planName = "${spec.group}·$name",
                category = "Nova-${spec.group}",
                algorithm = spec.algo,
                window = window,
                cyclePeriods = 1,
                playType = playType,
                positionIndex = positionIndex,
                outputFormat = output,
                hitCriteria = criteria,
                participateConsensus = true,
                participateCombo = playType == "组合",
                baselineValue = when (playType) {
                    "组合" -> 0.25
                    "数字", "位置" -> 0.125
                    else -> 0.50
                },
                weightCap = 1.0
            )
        }
    }

    val GROUPS: List<String> = specs.map { it.group }
    val PLAY_TYPES: List<String> = playTypes
    val CYCLE_OPTIONS: List<Int> = listOf(1, 2, 3, 5, 10, 20)

    fun meta(plan: PlanDefinition): Meta = Meta(
        playType = plan.playType,
        positionIndex = plan.positionIndex,
        positionLabel = if (plan.positionIndex >= 0) {
            when (plan.positionIndex) {
                0 -> "冠军"
                1 -> "亚军"
                else -> "第${plan.positionIndex + 1}"
            }
        } else ""
    )

    fun find(planId: String): PlanDefinition? = ALL.firstOrNull { it.planId == planId }
}
