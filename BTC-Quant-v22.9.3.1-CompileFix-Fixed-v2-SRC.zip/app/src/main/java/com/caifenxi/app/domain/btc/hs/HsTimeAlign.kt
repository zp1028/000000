package com.caifenxi.app.domain.btc.hs

import com.caifenxi.app.domain.btc.BtcCandle
import kotlin.math.abs

/**
 * 多周期 K 线时间对齐工具。
 *
 * 决策时钟取 5m 周期最后一根 bar 的 openTime（若缺失则退到 15m / 1h）。
 * 每个周期各自的“当前 bar 起点” = floor(clock, 本周期时长)，
 * 对齐误差 = |该周期最后一根 bar 的 openTime - 本周期当前 bar 起点|。
 *
 * 注意：不能用统一时钟去减各周期 bar 时间——1h bar 的 openTime 天然会落后
 * 5m 边界最多约 59 分钟，那样会把正常的 1h 数据误判为 STALE。
 */
object HsTimeAlign {
    /** 5 分钟毫秒 */
    const val FIVE_MIN_MS = 5L * 60_000L
    const val FIFTEEN_MIN_MS = 15L * 60_000L
    const val ONE_HOUR_MS = 60L * 60_000L

    fun floorTo5m(ts: Long): Long = ts - (ts % FIVE_MIN_MS)

    /**
     * @return 最大对齐误差（ms）；无数据返回 Long.MAX_VALUE
     */
    fun maxAlignErrorMs(
        c5: List<BtcCandle>,
        c15: List<BtcCandle>,
        c1h: List<BtcCandle>
    ): Long {
        val reference = c5.lastOrNull()?.openTime
            ?: c15.lastOrNull()?.openTime
            ?: c1h.lastOrNull()?.openTime
            ?: return Long.MAX_VALUE

        fun errorFor(candles: List<BtcCandle>, intervalMs: Long): Long? {
            val last = candles.lastOrNull()?.openTime ?: return null
            val expected = reference - (reference % intervalMs)
            return abs(last - expected)
        }

        val errors = listOfNotNull(
            errorFor(c5, FIVE_MIN_MS),
            errorFor(c15, FIFTEEN_MIN_MS),
            errorFor(c1h, ONE_HOUR_MS)
        )
        return errors.maxOrNull() ?: Long.MAX_VALUE
    }

    /** 截断到 clock 及之前的已收盘 bar（openTime <= clock） */
    fun closedBarsUntil(candles: List<BtcCandle>, clock: Long): List<BtcCandle> =
        candles.filter { it.openTime <= clock }
}
