package com.caifenxi.app.domain.btc.ops

/** Operational severity used by the watchdog and dashboard. */
enum class OpsSeverity { INFO, WARNING, CRITICAL }

enum class OpsCode {
    HEARTBEAT_STALE,
    DATA_STALE,
    BROKER_UNAVAILABLE,
    RECONCILIATION_DRIFT,
    UNHEDGED_LEG,
    ORDER_TIMEOUT,
    RECOVERY_BLOCKED,
    SETTLEMENT_PENDING,
    REDEEM_PENDING,
    KILL_SWITCH
}

data class OpsAlert(
    val code: OpsCode,
    val severity: OpsSeverity,
    val message: String,
    val executionId: String? = null,
    val marketId: String? = null,
    val atMs: Long = System.currentTimeMillis()
)

data class OpsHealthInput(
    val heartbeatAgeMs: Long,
    val dataAgeMs: Long,
    val brokerReachable: Boolean,
    val reconciliationOk: Boolean,
    val unhedged: Boolean,
    val timedOutOrders: Int,
    val recoveryBlocked: Boolean,
    val settlementPending: Boolean,
    val redeemPending: Boolean,
    val killSwitch: Boolean
)

object ExecutionOpsCore {
    fun alerts(
        input: OpsHealthInput,
        nowMs: Long = System.currentTimeMillis(),
        heartbeatTimeoutMs: Long = 90_000L,
        dataTimeoutMs: Long = 20_000L
    ): List<OpsAlert> {
        val out = mutableListOf<OpsAlert>()
        if (input.killSwitch) out += OpsAlert(OpsCode.KILL_SWITCH, OpsSeverity.CRITICAL, "Kill switch active", atMs = nowMs)
        if (input.heartbeatAgeMs > heartbeatTimeoutMs) out += OpsAlert(OpsCode.HEARTBEAT_STALE, OpsSeverity.CRITICAL, "runtime heartbeat stale", atMs = nowMs)
        if (input.dataAgeMs > dataTimeoutMs) out += OpsAlert(OpsCode.DATA_STALE, OpsSeverity.CRITICAL, "market data stale", atMs = nowMs)
        if (!input.brokerReachable) out += OpsAlert(OpsCode.BROKER_UNAVAILABLE, OpsSeverity.CRITICAL, "broker unavailable", atMs = nowMs)
        if (!input.reconciliationOk) out += OpsAlert(OpsCode.RECONCILIATION_DRIFT, OpsSeverity.CRITICAL, "venue/local reconciliation drift", atMs = nowMs)
        if (input.unhedged) out += OpsAlert(OpsCode.UNHEDGED_LEG, OpsSeverity.CRITICAL, "two-leg execution has unhedged exposure", atMs = nowMs)
        if (input.timedOutOrders > 0) out += OpsAlert(OpsCode.ORDER_TIMEOUT, OpsSeverity.WARNING, "${input.timedOutOrders} order(s) timed out", atMs = nowMs)
        if (input.recoveryBlocked) out += OpsAlert(OpsCode.RECOVERY_BLOCKED, OpsSeverity.CRITICAL, "execution recovery is blocked", atMs = nowMs)
        if (input.settlementPending) out += OpsAlert(OpsCode.SETTLEMENT_PENDING, OpsSeverity.INFO, "settlement pending", atMs = nowMs)
        if (input.redeemPending) out += OpsAlert(OpsCode.REDEEM_PENDING, OpsSeverity.WARNING, "redeem pending venue confirmation", atMs = nowMs)
        return out
    }

    fun shouldBlockNewOrders(alerts: List<OpsAlert>): Boolean = alerts.any { it.severity == OpsSeverity.CRITICAL }
}
