package com.caifenxi.app.domain.plan

import com.caifenxi.app.domain.model.PlanDefinition
import com.caifenxi.app.domain.model.PlanHitCriteria
import com.caifenxi.app.domain.model.PlanOutputFormat

/**
 * 极速运动会专用计划池（与 PK10 Nova 池隔离）。
 * 玩法：第1～6球大小/单双、三组龙虎、定位。
 */
object NovaYdhPlanPool {
    private val algos = listOf("FREQ", "EWMA", "MKV1", "RHYTHM", "STATE")
    private val windows = listOf(10, 20, 30, 50)

    val ALL: List<PlanDefinition> = buildList {
        // 每位大小 / 单双
        for (pos in 0 until 6) {
            val ball = pos + 1
            for ((ai, algo) in algos.take(3).withIndex()) {
                val w = windows[ai % windows.size]
                add(
                    PlanDefinition(
                        planId = "NOVA-YDH-P${ball}-DX-$algo",
                        planName = "第${ball}球大小·$algo",
                        category = "YDH-大小",
                        algorithm = algo,
                        window = w,
                        playType = "球大小",
                        positionIndex = pos,
                        baselineValue = 0.50,
                        participateConsensus = true
                    )
                )
                add(
                    PlanDefinition(
                        planId = "NOVA-YDH-P${ball}-DS-$algo",
                        planName = "第${ball}球单双·$algo",
                        category = "YDH-单双",
                        algorithm = algo,
                        window = w,
                        playType = "球单双",
                        positionIndex = pos,
                        baselineValue = 0.50,
                        participateConsensus = true
                    )
                )
            }
        }
        // 三组龙虎：0=1vs6, 1=2vs5, 2=3vs4
        listOf(0 to "一球龙虎", 1 to "二球龙虎", 2 to "三球龙虎").forEach { (pair, label) ->
            for (algo in algos.take(3)) {
                add(
                    PlanDefinition(
                        planId = "NOVA-YDH-DT$pair-$algo",
                        planName = "$label·$algo",
                        category = "YDH-龙虎",
                        algorithm = algo,
                        window = 20,
                        playType = "龙虎",
                        positionIndex = pair,
                        baselineValue = 0.50,
                        participateConsensus = true
                    )
                )
            }
        }
        // 定位：第1～6球直选
        for (pos in 0 until 6) {
            val ball = pos + 1
            for (algo in listOf("FREQ", "EWMA")) {
                add(
                    PlanDefinition(
                        planId = "NOVA-YDH-POS$ball-$algo",
                        planName = "第${ball}球定位·$algo",
                        category = "YDH-定位",
                        algorithm = algo,
                        window = 30,
                        playType = "定位",
                        positionIndex = pos,
                        outputFormat = PlanOutputFormat.NUMBER_SCORES,
                        hitCriteria = PlanHitCriteria.TOP20_HIT,
                        baselineValue = 1.0 / 6.0,
                        participateConsensus = false
                    )
                )
            }
        }
    }

    fun find(planId: String): PlanDefinition? = ALL.find { it.planId == planId }
}
