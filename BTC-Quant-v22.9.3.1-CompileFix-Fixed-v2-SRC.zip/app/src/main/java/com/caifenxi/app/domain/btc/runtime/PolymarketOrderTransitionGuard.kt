package com.caifenxi.app.domain.btc.runtime

/** Centralizes legal order lifecycle transitions so stale venue events cannot move an order backwards. */
object PolymarketOrderTransitionGuard {
    private val allowed = mapOf(
        PolymarketOrderStage.CREATED to setOf(PolymarketOrderStage.SUBMITTING, PolymarketOrderStage.REJECTED, PolymarketOrderStage.ERROR),
        PolymarketOrderStage.SUBMITTING to setOf(PolymarketOrderStage.OPEN, PolymarketOrderStage.PARTIAL, PolymarketOrderStage.FILLED, PolymarketOrderStage.REJECTED, PolymarketOrderStage.ERROR, PolymarketOrderStage.UNKNOWN),
        PolymarketOrderStage.OPEN to setOf(PolymarketOrderStage.PARTIAL, PolymarketOrderStage.FILLED, PolymarketOrderStage.CANCELING, PolymarketOrderStage.REPLACE_REQUESTED, PolymarketOrderStage.EXPIRED, PolymarketOrderStage.UNKNOWN, PolymarketOrderStage.ERROR),
        PolymarketOrderStage.PARTIAL to setOf(PolymarketOrderStage.PARTIAL, PolymarketOrderStage.FILLED, PolymarketOrderStage.CANCELING, PolymarketOrderStage.REPLACE_REQUESTED, PolymarketOrderStage.EXPIRED, PolymarketOrderStage.UNKNOWN, PolymarketOrderStage.ERROR),
        PolymarketOrderStage.CANCELING to setOf(PolymarketOrderStage.CANCELED, PolymarketOrderStage.FILLED, PolymarketOrderStage.PARTIAL, PolymarketOrderStage.UNKNOWN, PolymarketOrderStage.ERROR),
        PolymarketOrderStage.REPLACE_REQUESTED to setOf(PolymarketOrderStage.REPLACED, PolymarketOrderStage.CANCELED, PolymarketOrderStage.UNKNOWN, PolymarketOrderStage.ERROR),
        PolymarketOrderStage.REPLACED to setOf(PolymarketOrderStage.OPEN, PolymarketOrderStage.PARTIAL, PolymarketOrderStage.FILLED, PolymarketOrderStage.UNKNOWN),
        PolymarketOrderStage.UNKNOWN to setOf(PolymarketOrderStage.OPEN, PolymarketOrderStage.PARTIAL, PolymarketOrderStage.FILLED, PolymarketOrderStage.CANCELED, PolymarketOrderStage.EXPIRED, PolymarketOrderStage.REJECTED, PolymarketOrderStage.ERROR),
    )

    fun canTransition(from: PolymarketOrderStage, to: PolymarketOrderStage): Boolean =
        from == to || allowed[from]?.contains(to) == true
}
