package com.caifenxi.app.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoGraph
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.caifenxi.app.ui.BtcQuantViewModel

private enum class MainMode(val title: String, val subtitle: String) {
    TERMINAL("量化终端", "市场 · 决策 · 自动 · 交易 · 研究"),
    SIMULATION("模拟盘", "实时行情 · 撮合 · 账户 · PnL"),
    FUTURES("合约", "持仓 · 风控 · 执行 · 回测")
}

private enum class TerminalSection(val title: String) {
    DASHBOARD("总览"),
    DECISION("决策"),
    AUTO("自动"),
    TRADE("交易"),
    STRATEGY("策略"),
    BACKTEST("回测"),
    RESEARCH("研究"),
    SETTINGS("设置")
}

private object BtcUi {
    val Background = Color(0xFF050810)
    val Header = Color(0xFF070B14)
    val Surface = Color(0xFF0B1220)
    val Surface2 = Color(0xFF0E1728)
    val Border = Color(0xFF1A2A40)
    val Cyan = Color(0xFF35D9FF)
    val Blue = Color(0xFF4E7CFF)
    val Green = Color(0xFF39E58C)
    val Red = Color(0xFFFF5C75)
    val Amber = Color(0xFFFFC857)
    val Text = Color(0xFFEAF2FF)
    val Muted = Color(0xFF7F91AA)
}

/**
 * BTC Quant v21.1 Mission Control 科技终端壳层。
 * 研究/执行业务页面继续复用现有 Domain/ViewModel；这里只统一视觉层级与导航。
 */
@Composable
fun BtcQuantScreen(viewModel: BtcQuantViewModel) {
    var selected by remember { mutableStateOf(MainMode.TERMINAL) }
    var terminalSection by remember { mutableStateOf(TerminalSection.DASHBOARD) }
    var futuresSection by remember { mutableIntStateOf(0) }
    val state by viewModel.state.collectAsState()

    Box(Modifier.fillMaxSize().background(BtcUi.Background)) {
        TechGridBackground()
        Column(Modifier.fillMaxSize()) {
            TerminalHeader(state.symbol, state.timeframe, state.candles.size, state.isDemoMode)
            ModeRail(selected) { selected = it }
            Box(Modifier.fillMaxSize()) {
                when (selected) {
                    MainMode.TERMINAL -> Column(Modifier.fillMaxSize()) {
                        SectionRail(terminalSection) { terminalSection = it }
                        Box(Modifier.fillMaxSize()) {
                            when (terminalSection) {
                                TerminalSection.DASHBOARD -> MissionControlTab(viewModel)
                                TerminalSection.DECISION -> DecisionCenterScreen(viewModel)
                                TerminalSection.AUTO -> AutoTradeTab(viewModel)
                                TerminalSection.TRADE -> 交易Tab(viewModel)
                                TerminalSection.STRATEGY -> StrategyTab(viewModel)
                                TerminalSection.BACKTEST -> BacktestTab(viewModel)
                                TerminalSection.RESEARCH -> ResearchCenterScreen(viewModel)
                                TerminalSection.SETTINGS -> SettingsTab(viewModel)
                            }
                        }
                    }
                    MainMode.SIMULATION -> PaperTradingTab(viewModel)
                    MainMode.FUTURES -> Column(Modifier.fillMaxSize()) {
                        FuturesRail(futuresSection) { futuresSection = it }
                        Box(Modifier.fillMaxSize()) {
                            when (futuresSection) {
                                0 -> FuturesQuantTab(viewModel)
                                1 -> BacktestTab(viewModel)
                                else -> StrategyTab(viewModel)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TechGridBackground() {
    Canvas(Modifier.fillMaxSize()) {
        val step = 42.dp.toPx()
        var x = 0f
        while (x < size.width) {
            drawLine(BtcUi.Border.copy(alpha = 0.22f), androidx.compose.ui.geometry.Offset(x, 0f), androidx.compose.ui.geometry.Offset(x, size.height), strokeWidth = 1f)
            x += step
        }
        var y = 0f
        while (y < size.height) {
            drawLine(BtcUi.Border.copy(alpha = 0.18f), androidx.compose.ui.geometry.Offset(0f, y), androidx.compose.ui.geometry.Offset(size.width, y), strokeWidth = 1f)
            y += step
        }
        drawCircle(BtcUi.Cyan.copy(alpha = 0.05f), radius = size.minDimension * 0.42f, center = androidx.compose.ui.geometry.Offset(size.width * 0.82f, size.height * 0.10f), style = Stroke(width = 1.5f))
    }
}

@Composable
private fun TerminalHeader(symbol: String, timeframe: String, bars: Int, demo: Boolean) {
    Row(
        Modifier.fillMaxWidth().background(BtcUi.Header.copy(alpha = 0.96f)).padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Surface(shape = RoundedCornerShape(12.dp), color = BtcUi.Surface2, border = androidx.compose.foundation.BorderStroke(1.dp, BtcUi.Cyan.copy(alpha = 0.35f))) {
            Box(Modifier.size(40.dp), contentAlignment = Alignment.Center) {
                Icon(Icons.Filled.Memory, null, tint = BtcUi.Cyan, modifier = Modifier.size(21.dp))
            }
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("BTC QUANT", color = BtcUi.Text, fontWeight = FontWeight.Black, fontSize = 15.sp)
                Spacer(Modifier.width(7.dp))
                Text("/", color = BtcUi.Muted, fontSize = 12.sp)
                Spacer(Modifier.width(7.dp))
                Text(symbol, color = BtcUi.Cyan, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
            Text("${timeframe} · ${bars} bars · QUANT ENGINE 21.1", color = BtcUi.Muted, fontSize = 9.sp)
        }
        Column(horizontalAlignment = Alignment.End) {
            StatusPill(if (demo) "模拟数据" else "实时数据", if (demo) BtcUi.Amber else BtcUi.Green)
            Spacer(Modifier.height(3.dp))
            Text("● ENGINE ONLINE", color = BtcUi.Green, fontSize = 7.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun StatusPill(text: String, accent: Color) {
    Surface(shape = RoundedCornerShape(100.dp), color = accent.copy(alpha = 0.10f), border = androidx.compose.foundation.BorderStroke(1.dp, accent.copy(alpha = 0.28f))) {
        Text(text, color = accent, fontSize = 8.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp))
    }
}

@Composable
private fun ModeRail(selected: MainMode, onSelected: (MainMode) -> Unit) {
    Row(Modifier.fillMaxWidth().background(BtcUi.Header).horizontalScroll(rememberScrollState()).padding(horizontal = 9.dp, vertical = 7.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
        MainMode.entries.forEach { mode ->
            val active = selected == mode
            val accent = when (mode) { MainMode.TERMINAL -> BtcUi.Cyan; MainMode.SIMULATION -> BtcUi.Blue; MainMode.FUTURES -> BtcUi.Amber }
            Surface(onClick = { onSelected(mode) }, shape = RoundedCornerShape(12.dp), color = if (active) accent.copy(alpha = 0.13f) else BtcUi.Surface.copy(alpha = 0.82f), border = androidx.compose.foundation.BorderStroke(1.dp, if (active) accent.copy(alpha = 0.55f) else BtcUi.Border)) {
                Row(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(if (mode == MainMode.TERMINAL) Icons.Filled.AutoGraph else if (mode == MainMode.SIMULATION) Icons.Filled.Timeline else Icons.Filled.ShowChart, null, tint = if (active) accent else BtcUi.Muted, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(7.dp))
                    Column {
                        Text(mode.title, color = if (active) BtcUi.Text else BtcUi.Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text(mode.subtitle, color = BtcUi.Muted, fontSize = 7.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun SectionRail(selected: TerminalSection, onSelected: (TerminalSection) -> Unit) {
    Row(Modifier.fillMaxWidth().background(BtcUi.Surface.copy(alpha = 0.94f)).horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
        TerminalSection.entries.forEach { section ->
            val active = selected == section
            Surface(onClick = { onSelected(section) }, shape = RoundedCornerShape(9.dp), color = if (active) BtcUi.Cyan.copy(alpha = 0.12f) else Color.Transparent, border = androidx.compose.foundation.BorderStroke(1.dp, if (active) BtcUi.Cyan.copy(alpha = 0.38f) else Color.Transparent)) {
                Row(Modifier.padding(horizontal = 10.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (active) Icon(Icons.Filled.Bolt, null, tint = BtcUi.Cyan, modifier = Modifier.size(12.dp))
                    if (active) Spacer(Modifier.width(3.dp))
                    Text(section.title, color = if (active) BtcUi.Cyan else BtcUi.Muted, fontSize = 10.sp, fontWeight = if (active) FontWeight.Bold else FontWeight.Medium)
                }
            }
        }
    }
}

@Composable
private fun FuturesRail(selected: Int, onSelected: (Int) -> Unit) {
    val titles = listOf("合约运行", "策略回测", "策略研究")
    Row(Modifier.fillMaxWidth().background(BtcUi.Surface.copy(alpha = 0.94f)).horizontalScroll(rememberScrollState()).padding(8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        titles.forEachIndexed { i, title ->
            val active = selected == i
            Surface(onClick = { onSelected(i) }, shape = RoundedCornerShape(9.dp), color = if (active) BtcUi.Amber.copy(alpha = 0.12f) else Color.Transparent, border = androidx.compose.foundation.BorderStroke(1.dp, if (active) BtcUi.Amber.copy(alpha = 0.38f) else Color.Transparent)) {
                Row(Modifier.padding(horizontal = 11.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(if (i == 0) Icons.Filled.ShowChart else if (i == 1) Icons.Filled.BarChart else Icons.Filled.AutoGraph, null, tint = if (active) BtcUi.Amber else BtcUi.Muted, modifier = Modifier.size(14.dp))
                    Spacer(Modifier.width(5.dp))
                    Text(title, color = if (active) BtcUi.Text else BtcUi.Muted, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}
