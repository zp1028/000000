package com.caifenxi.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoGraph
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.caifenxi.app.ui.BtcQuantViewModel

private val MC_BG = Color(0xFF050812)
private val MC_PANEL = Color(0xFF0B1321)
private val MC_BORDER = Color(0xFF1B3048)
private val MC_TEXT = Color(0xFFEAF5FF)
private val MC_MUTED = Color(0xFF7890A8)
private val MC_CYAN = Color(0xFF32DFFF)
private val MC_GREEN = Color(0xFF38E49A)
private val MC_RED = Color(0xFFFF5D78)
private val MC_AMBER = Color(0xFFFFC857)

/** v21.1 Mission Control: one screen answers what the system sees, decides and is allowed to do. */
@Composable
fun MissionControlTab(viewModel: BtcQuantViewModel) {
    val state by viewModel.state.collectAsState()
    val exec by viewModel.executionStatus.collectAsState()
    val hs = state.hsSnapshot
    val p5 = hs?.tf5m?.pHat ?: 0.5
    val p15 = hs?.tf15m?.pHat ?: 0.5
    val p1h = hs?.tf1h?.pHat ?: 0.5
    val edge = (hs?.aggregateEdge ?: 0.0) * 100.0
    val direction = when {
        p15 >= 0.55 -> "做多"
        p15 <= 0.45 -> "做空"
        else -> "观望"
    }
    val directionColor = when (direction) {
        "做多" -> MC_GREEN
        "做空" -> MC_RED
        else -> MC_AMBER
    }
    val liveAllowed = hs?.dataQuality?.liveTradeAllowed == true && !exec.killSwitch

    Column(Modifier.fillMaxSize().background(MC_BG).verticalScroll(rememberScrollState()).padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("MISSION CONTROL", color = MC_TEXT, fontSize = 18.sp, fontWeight = FontWeight.Black)
                Text("不是看板，而是量化系统驾驶舱", color = MC_MUTED, fontSize = 9.sp)
            }
            Surface(color = (if (liveAllowed) MC_GREEN else MC_AMBER).copy(alpha = .10f), shape = RoundedCornerShape(20.dp), border = androidx.compose.foundation.BorderStroke(1.dp, (if (liveAllowed) MC_GREEN else MC_AMBER).copy(alpha=.35f))) {
                Text(if (liveAllowed) "EXECUTION READY" else "EXECUTION BLOCKED", color = if (liveAllowed) MC_GREEN else MC_AMBER, fontSize = 8.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal=9.dp, vertical=6.dp))
            }
        }

        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            Metric("BTC", state.symbol, MC_CYAN)
            Metric("15M", "${(p15 * 100).format1()}%", directionColor)
            Metric("EDGE", "${edge.format2()}%", if (edge >= 0) MC_GREEN else MC_RED)
            Metric("RISK", if (liveAllowed) "PASS" else "BLOCK", if (liveAllowed) MC_GREEN else MC_RED)
        }

        Panel("核心结论", Icons.Filled.AutoGraph) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(direction, color = directionColor, fontSize = 28.sp, fontWeight = FontWeight.Black)
                    Text("5m ${(p5*100).format1()}%  ·  15m ${(p15*100).format1()}%  ·  1h ${(p1h*100).format1()}%", color = MC_MUTED, fontSize = 10.sp)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("市场状态", color = MC_MUTED, fontSize = 8.sp)
                    Text(hs?.tf15m?.regime?.name ?: "未知", color = MC_TEXT, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        Panel("决策链路", Icons.Filled.Bolt) {
            val stages = listOf("行情" to true, "因子" to true, "策略" to true, "模型" to true, "融合" to true, "风控" to liveAllowed, "执行" to false)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                stages.forEachIndexed { i, pair ->
                    val c = if (pair.second) MC_CYAN else MC_MUTED
                    Surface(color = c.copy(alpha=.08f), shape = RoundedCornerShape(8.dp), border = androidx.compose.foundation.BorderStroke(1.dp, c.copy(alpha=.25f))) {
                        Row(Modifier.padding(horizontal=7.dp, vertical=7.dp), verticalAlignment=Alignment.CenterVertically) {
                            Text("${i+1}", color=c, fontSize=8.sp, fontWeight=FontWeight.Bold)
                            Spacer(Modifier.width(4.dp))
                            Text(pair.first, color=if(pair.second) MC_TEXT else MC_MUTED, fontSize=9.sp)
                        }
                    }
                }
            }
            Spacer(Modifier.height(6.dp))
            Text(hs?.decisionExplanation?.compact() ?: "当前没有形成可执行结论", color = MC_TEXT, fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier=Modifier.fillMaxWidth()) {
            SmallPanel(Modifier.weight(1f), "模型一致性", "${((1.0 - kotlin.math.abs(p5-p1h))*100).format1()}%", MC_CYAN, Icons.Filled.AutoGraph)
            SmallPanel(Modifier.weight(1f), "执行保护", if(exec.killSwitch) "熔断" else "正常", if(exec.killSwitch) MC_RED else MC_GREEN, Icons.Filled.Shield)
        }

        Panel("运行状态", Icons.Filled.ShowChart) {
            StatusRow("行情", if (state.loading) "同步中" else "在线/缓存", !state.loading)
            StatusRow("数据质量", if (hs?.dataQuality?.liveTradeAllowed == true) "可执行" else "受限", hs?.dataQuality?.liveTradeAllowed == true)
            StatusRow("引擎", "QUANT ENGINE 21.1", true)
            StatusRow("账户模式", if (state.isDemoMode) "演示/研究" else "实时", !state.isDemoMode)
        }
    }
}

@Composable private fun Metric(label:String, value:String, accent:Color) {
    Surface(color=MC_PANEL, shape=RoundedCornerShape(10.dp), border=androidx.compose.foundation.BorderStroke(1.dp, MC_BORDER)) {
        Column(Modifier.padding(horizontal=12.dp, vertical=8.dp)) { Text(label,color=MC_MUTED,fontSize=7.sp); Text(value,color=accent,fontSize=12.sp,fontWeight=FontWeight.Bold) }
    }
}

@Composable private fun Panel(title:String, icon: androidx.compose.ui.graphics.vector.ImageVector, content:@Composable ColumnScope.()->Unit) {
    Column(Modifier.fillMaxWidth().background(MC_PANEL,RoundedCornerShape(12.dp)).border(1.dp,MC_BORDER,RoundedCornerShape(12.dp)).padding(10.dp), content= {
        Row(verticalAlignment=Alignment.CenterVertically) { Icon(icon,null,tint=MC_CYAN,modifier=Modifier.size(14.dp)); Spacer(Modifier.width(6.dp)); Text(title,color=MC_TEXT,fontSize=11.sp,fontWeight=FontWeight.Bold) }
        Spacer(Modifier.height(8.dp)); content()
    })
}

@Composable private fun SmallPanel(modifier:Modifier,title:String,value:String,accent:Color,icon:androidx.compose.ui.graphics.vector.ImageVector) {
    Column(modifier.background(MC_PANEL,RoundedCornerShape(12.dp)).border(1.dp,MC_BORDER,RoundedCornerShape(12.dp)).padding(10.dp)) { Icon(icon,null,tint=accent,modifier=Modifier.size(14.dp)); Spacer(Modifier.height(6.dp)); Text(title,color=MC_MUTED,fontSize=8.sp); Text(value,color=accent,fontSize=15.sp,fontWeight=FontWeight.Bold) }
}

@Composable private fun StatusRow(label:String,value:String,ok:Boolean) { Row(Modifier.fillMaxWidth().padding(vertical=3.dp),verticalAlignment=Alignment.CenterVertically){Text(label,color=MC_MUTED,fontSize=9.sp,modifier=Modifier.width(65.dp));Text(value,color=MC_TEXT,fontSize=9.sp,modifier=Modifier.weight(1f));Text(if(ok) "●" else "○",color=if(ok) MC_GREEN else MC_AMBER,fontSize=10.sp)}}
private fun Double.format1() = String.format(java.util.Locale.US,"%.1f",this)
private fun Double.format2() = String.format(java.util.Locale.US,"%.2f",this)
