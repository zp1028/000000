package com.caifenxi.app.domain.plan

import com.caifenxi.app.domain.model.PlanDefinition
import com.caifenxi.app.domain.model.PlanHitCriteria
import com.caifenxi.app.domain.model.PlanOutputFormat

/** PLAN-POOL-40-V1 完整 40 计划 */
object PlanPool {
    const val STRATEGY_VERSION = "PLAN-POOL-40-V1"

    val ALL: List<PlanDefinition> = listOf(
        bin("S-FREQ-010", "大小10期频率", "大小", "FREQ", 10),
        bin("S-FREQ-020", "大小20期频率", "大小", "FREQ", 20),
        bin("S-FREQ-050", "大小50期频率", "大小", "FREQ", 50),
        bin("S-EWMA", "大小EWMA", "大小", "EWMA", 30),
        bin("S-MKV1", "大小一阶转移", "大小", "MKV1", 50),
        bin("S-MULTI", "大小多周期融合", "大小", "MSF", 100),
        bin("D-FREQ-010", "单双10期频率", "单双", "FREQ", 10),
        bin("D-FREQ-020", "单双20期频率", "单双", "FREQ", 20),
        bin("D-FREQ-050", "单双50期频率", "单双", "FREQ", 50),
        bin("D-EWMA", "单双EWMA", "单双", "EWMA", 30),
        bin("D-MKV1", "单双一阶转移", "单双", "MKV1", 50),
        bin("D-MULTI", "单双多周期融合", "单双", "MSF", 100),
        position("P1-FREQ-010", "位置-冠军10期频率", "冠军", 10),
        position("P1-EWMA", "位置-冠军EWMA", "冠军", 30, "EWMA"),
        position("P1-MKV1", "位置-冠军一阶转移", "冠军", 50, "MKV1"),
        position("P2-FREQ-010", "位置-亚军10期频率", "亚军", 10),
        position("P2-EWMA", "位置-亚军EWMA", "亚军", 30, "EWMA"),
        position("P2-MKV1", "位置-亚军一阶转移", "亚军", 50, "MKV1"),
        position("P3-FREQ-010", "位置-第3期频率", "第3", 10),
        position("P3-EWMA", "位置-第3EWMA", "第3", 30, "EWMA"),
        position("P3-MKV1", "位置-第3一阶转移", "第3", 50, "MKV1"),
        zone("Z-FREQ-010", "区间10期频率", 10),
        zone("Z-FREQ-020", "区间20期频率", 20),
        zone("Z-FREQ-050", "区间50期频率", 50),
        zone("Z-FREQ-100", "区间100期频率", 100),
        zone("Z-EWMA", "区间EWMA", 40, "EWMA"),
        zone("Z-MULTI", "区间多周期融合", 100, "MSF"),
        num("N-FREQ-010", "号码10期频率", 10),
        num("N-FREQ-020", "号码20期频率", 20),
        num("N-FREQ-050", "号码50期频率", 50),
        num("N-FREQ-100", "号码100期频率", 100),
        num("N-FREQ-200", "号码200期频率", 200),
        num("N-FREQ-500", "号码500期频率", 500),
        num("N-EWMA", "号码EWMA", 50, "EWMA"),
        num("N-OMIT", "号码遗漏", 80, "OMIT"),
        num("N-CHOT", "号码冷热", 50, "CHOT"),
        num("N-MULTI", "号码多周期融合", 100, "MSF"),
        struct("T-REPEAT", "重号结构", 30, "STRUCT"),
        struct("T-CONSEC", "连号结构", 30, "STRUCT"),
        struct("T-TAIL", "尾数结构", 50, "STRUCT"),
        struct("T-CHOT", "冷热结构", 50, "CHOT"),
        struct("T-ODD", "奇偶结构", 50, "FREQ"),
        struct("T-MULTI", "综合结构", 80, "MSF"),
        ai("AI-STAT", "AI统计分析", "STAT"),
        ai("AI-STRUCT", "AI结构分析", "STRUCT"),
        ai("AI-FILTER", "AI号码筛选", "FILTER"),
        ai("AI-EVAL", "AI策略评估", "EVAL"),
        ai("AI-ANOM", "AI异常检测", "ANOM"),
        ai("AI-SYNTH", "AI综合判断", "SYNTH"),
    )

    private fun bin(id: String, name: String, cat: String, algo: String, w: Int) =
        PlanDefinition(id, name, cat, algo, w, outputFormat = PlanOutputFormat.DIRECTION, hitCriteria = PlanHitCriteria.DIRECTION_MATCH, participateConsensus = true)

    private fun position(id: String, name: String, position: String, w: Int, algo: String = "FREQ") =
        PlanDefinition(id, name, "位置-$position", algo, w, outputFormat = PlanOutputFormat.NUMBER_SCORES, hitCriteria = PlanHitCriteria.TOP20_HIT, participateConsensus = true, participateCombo = false, baselineValue = 0.1, weightCap = 1.0)

    private fun zone(id: String, name: String, w: Int, algo: String = "FREQ") =
        PlanDefinition(id, name, "区间", algo, w, outputFormat = PlanOutputFormat.ZONE_DISTRIBUTION, hitCriteria = PlanHitCriteria.ZONE_DISTANCE, participateConsensus = true, participateCombo = true, baselineValue = 0.25, weightCap = 0.8)

    private fun num(id: String, name: String, w: Int, algo: String = "FREQ") =
        PlanDefinition(id, name, "号码", algo, w, outputFormat = PlanOutputFormat.NUMBER_SCORES, hitCriteria = PlanHitCriteria.TOP20_HIT, participateConsensus = false, participateCombo = true, baselineValue = 0.25)

    private fun struct(id: String, name: String, w: Int, algo: String) =
        PlanDefinition(id, name, "结构", algo, w, outputFormat = PlanOutputFormat.STRUCTURE_VALUE, hitCriteria = PlanHitCriteria.STRUCTURE_RANGE, participateConsensus = false, participateCombo = true, baselineValue = 0.5, weightCap = 0.5)

    private fun ai(id: String, name: String, algo: String) =
        PlanDefinition(id, name, "AI", algo, 50, outputFormat = PlanOutputFormat.DIRECTION, hitCriteria = PlanHitCriteria.DIRECTION_MATCH, participateConsensus = true, participateCombo = true, baselineValue = 0.5, weightCap = 0.8)
}
