package com.caifenxi.app.ui

import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.caifenxi.app.CaiFenXiApplication
import com.caifenxi.app.domain.engine.AnalysisEngine
import com.caifenxi.app.domain.engine.PredictEngine
import com.caifenxi.app.domain.engine.StatsEngine
import com.caifenxi.app.domain.engine.ConsensusEngine
import com.caifenxi.app.domain.model.AlgoMode
import com.caifenxi.app.domain.model.AlgoResult
import com.caifenxi.app.domain.model.AnalysisBundle
import com.caifenxi.app.domain.model.DrawRecord
import com.caifenxi.app.domain.model.LabRow
import com.caifenxi.app.domain.model.LotteryConfig
import com.caifenxi.app.domain.model.ManualMark
import com.caifenxi.app.domain.model.ModelConsensus
import com.caifenxi.app.domain.model.ConsensusRecord
import com.caifenxi.app.domain.model.ConsensusStats
import com.caifenxi.app.domain.model.BetStats
import com.caifenxi.app.domain.model.BetView
import com.caifenxi.app.domain.model.BotConfig
import com.caifenxi.app.domain.model.PlanDefinition
import com.caifenxi.app.domain.model.PlanPredictionRecord
import com.caifenxi.app.domain.model.PlanRuntime
import com.caifenxi.app.domain.model.PredictionSnapshot
import com.caifenxi.app.domain.model.StatRecord
import com.caifenxi.app.domain.model.WalletView
import com.caifenxi.app.domain.model.StatsSummary
import com.caifenxi.app.domain.model.UserPrefs
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.concurrent.atomic.AtomicBoolean
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 主 ViewModel:首页数据、预测、统计、设置与数据导出。
 * 计划/回测/共识/自定义计划委托给 [PlanViewModel],挂机/下注委托给 [BetViewModel],
 * 三者在 Application 级共享 planEngine / betEngine,保证状态一致。
 */
class MainViewModel : ViewModel() {

    private val app get() = CaiFenXiApplication.instance
    private val repo get() = app.drawRepository
    private val configStore get() = app.configStore
    private val statStore get() = app.statStore
    private val manualStore get() = app.manualStore
    private val consensusStore get() = app.consensusStore
    private val planEngine get() = app.planEngine

    // ---- 子 ViewModel(委托) ----
    val planVM = PlanViewModel()
    val betVM = BetViewModel()

    val prefs = mutableStateOf(configStore.loadPrefs())
    val currentLottery = mutableStateOf(
        LotteryConfig.findByKey(prefs.value.selectedLotteryKey) ?: LotteryConfig.CATALOG.first()
    )
    val currentAlgo = mutableStateOf(AlgoMode.fromId(prefs.value.currentAlgo))
    val history = mutableStateOf<List<DrawRecord>>(emptyList())
    val latest = mutableStateOf<DrawRecord?>(null)
    val loading = mutableStateOf(false)
    val errorMessage = mutableStateOf<String?>(null)
    val prediction = mutableStateOf<PredictionSnapshot?>(null)
    val algoCompare = mutableStateOf<Map<String, List<AlgoResult>>>(emptyMap())
    val statusText = mutableStateOf("")
    val statsSummary = mutableStateOf(StatsSummary())
    val statRecords = mutableStateOf<List<StatRecord>>(emptyList())
    val analysis = mutableStateOf(AnalysisBundle())
    val manualMarks = mutableStateOf<Map<String, ManualMark>>(emptyMap())
    val countdownText = mutableStateOf("--:--")
    val nextIssueText = mutableStateOf("-")

    // ---- 数据导出/备份 ----
    /** 最近一次导出的文件(UI 观察后触发分享) */
    val exportedFile = mutableStateOf<java.io.File?>(null)
    /** 恢复进行中标志 */
    val restoring = mutableStateOf(false)

    // ---- 计划 / 共识(委托 PlanViewModel) ----
    val consensus get() = planVM.consensus
    val planRows get() = planVM.planRows
    val backtestRunning get() = planVM.backtestRunning
    val labRows get() = planVM.labRows
    val planHistory get() = planVM.planHistory
    val selectedPlanHistory get() = planVM.selectedPlanHistory
    val consensusRecords get() = planVM.consensusRecords
    val consensusStats get() = planVM.consensusStats
    val customPlans get() = planVM.customPlans

    // ---- 挂机 / 下注(委托 BetViewModel) ----
    val botConfig get() = betVM.botConfig
    val wallet get() = betVM.wallet
    val betHistory get() = betVM.betHistory
    val betStats get() = betVM.betStats
    val betCurveRevision get() = betVM.betCurveRevision
    val betCurveReset get() = betVM.betCurveReset

    private var refreshJob: Job? = null
    private var countdownJob: Job? = null
    private val loadMutex = Mutex()
    private val loadingGuard = AtomicBoolean(false)
    /** 同步进行中再次请求加载(如切换彩种)时置位,当前任务结束后自动接续 */
    private val pendingReload = AtomicBoolean(false)
    private var failStreak = 0
    private var lastForegroundRefresh = 0L

    init {
        loadData()
        viewModelScope.launch { refreshConsensusStats() }
        refreshBetState()
        startAutoRefreshIfNeeded()
        startCountdown()
    }

    fun selectLottery(config: LotteryConfig) {
        currentLottery.value = config
        val p = prefs.value.copy(selectedLotteryKey = config.key)
        prefs.value = p
        configStore.savePrefs(p)
        loadData()
    }

    fun selectAlgo(mode: AlgoMode) {
        currentAlgo.value = mode
        val p = prefs.value.copy(currentAlgo = mode.id)
        prefs.value = p
        configStore.savePrefs(p)
        viewModelScope.launch {
            if (history.value.isNotEmpty()) runPredictAndPlans(history.value, forceAlgo = mode)
        }
    }

    fun setManualMark(category: String, direction: String) {
        viewModelScope.launch {
            val m = ManualMark(currentLottery.value.key, category, direction)
            manualStore.save(m)
            manualMarks.value = manualStore.load(currentLottery.value.key)
            if (currentAlgo.value == AlgoMode.MANUAL) {
                if (history.value.isNotEmpty()) runPredictAndPlans(history.value, forceAlgo = AlgoMode.MANUAL)
            }
        }
    }

    fun clearManualMarks() {
        viewModelScope.launch {
            manualStore.clear(currentLottery.value.key)
            manualMarks.value = emptyMap()
        }
    }

    fun updatePrefs(transform: (UserPrefs) -> UserPrefs) {
        val p = transform(prefs.value)
        prefs.value = p
        configStore.savePrefs(p)
        if (p.autoRefresh) startAutoRefreshIfNeeded() else stopAutoRefresh()
    }

    /** 前台恢复时轻量刷新,避免卡死与掉线 */
    fun onForeground() {
        val now = System.currentTimeMillis()
        if (now - lastForegroundRefresh < 8_000) return
        lastForegroundRefresh = now
        // 重置可能卡住的 loading
        if (loading.value && !loadingGuard.get()) {
            loading.value = false
        }
        startAutoRefreshIfNeeded()
        startCountdown()
        refreshBetState()
        softRefreshLatest()
    }

    fun softRefreshLatest() {
        viewModelScope.launch {
            try {
                withTimeout(12_000) {
                    val one = app.apiClient.fetchLatest(currentLottery.value)
                    if (one != null) {
                        val exists = history.value.any { it.issue == one.issue }
                        if (!exists) {
                            loadData()
                        } else {
                            statusText.value = "已同步 · 最新 ${one.issue}"
                            failStreak = 0
                        }
                    }
                }
            } catch (_: Exception) {
                failStreak++
                statusText.value = "弱网 · 使用缓存"
            }
        }
    }

    fun loadData() {
        if (!loadingGuard.compareAndSet(false, true)) {
            // 正在同步时(例如切换了彩种)标记待重载,当前任务结束后自动加载新彩种,
            // 修复原实现直接 return 导致「界面已切新彩种、数据仍是旧彩种」的问题
            pendingReload.set(true)
            statusText.value = "同步中,请稍候..."
            return
        }
        viewModelScope.launch {
            loading.value = true
            errorMessage.value = null
            statusText.value = "拉取开奖..."
            // 固定本次加载的彩种,避免加载中途切换彩种造成数据错乱
            val cfg = currentLottery.value
            try {
                withTimeout(45_000) {
                    // 先展示缓存
                    val cached = repo.getLocalHistory(cfg.key)
                    if (cached.isNotEmpty() && cfg.key == currentLottery.value.key) {
                        history.value = cached
                        latest.value = cached.lastOrNull()
                        statusText.value = "缓存 ${cached.size} 期 · 同步中..."
                    }
                    val (rows, source) = repo.fetchAndCacheHistory(cfg)
                    // 加载期间用户已切换彩种:丢弃过期结果(新彩种的加载会接手)
                    if (cfg.key != currentLottery.value.key) return@withTimeout
                    history.value = rows
                    latest.value = rows.lastOrNull()
                    // 只结算新增期号(缓存中已有的期号此前已结算过)。
                    // 原实现对全量历史逐期结算,且每期都全量读写一次 JSON,
                    // 极速类彩种一天上千期,历史越多越卡,是首页卡死的主因。
                    val lastCachedIssue = cached.lastOrNull()?.issue
                    val newRows = if (lastCachedIssue != null) {
                        val idx = rows.indexOfFirst { it.issue == lastCachedIssue }
                        if (idx >= 0) rows.subList(idx + 1, rows.size)
                        else rows.filter {
                            (it.issue.toLongOrNull() ?: -1L) > (lastCachedIssue.toLongOrNull() ?: -1L)
                        }
                    } else rows
                    if (newRows.isNotEmpty()) {
                        StatsEngine.settleWithDraws(statStore, cfg.key, newRows)
                        ConsensusEngine.settleWithDraws(consensusStore, cfg.key, newRows)
                        newRows.forEach {
                            planEngine.settlePendingWithDraw(it, prefs.value.backtestParams)
                            betVM.settleWithDraw(cfg.key, it)
                        }
                        planVM.refreshRuntimeState()
                        betVM.refreshBetState(cfg.key, ::setStatus)
                    }
                    refreshConsensusStats()
                    refreshStats()
                    manualMarks.value = manualStore.load(cfg.key)
                    statusText.value = "分析与预测...($source)"
                    runPredictAndPlans(rows)
                    rebuildAnalysis(rows)
                    statusText.value = "就绪 · ${rows.size} 期 · $source"
                    updateNextIssue(rows)
                }
                failStreak = 0
            } catch (e: Exception) {
                failStreak++
                errorMessage.value = e.message ?: "数据加载失败"
                statusText.value = "失败 · 可继续用缓存"
                // 至少刷新本地共识/战绩
                try { refreshStats(); refreshConsensusStats() } catch (_: Exception) {}
            } finally {
                loading.value = false
                loadingGuard.set(false)
                // 同步期间有新的加载请求(切换彩种/再次点击刷新):立即接续
                if (pendingReload.compareAndSet(true, false)) loadData()
            }
        }
    }

    private fun setStatus(text: String) {
        statusText.value = text
    }

    /** 仅用本地缓存重算分析/预测/计划,不访问网络(首页「仅用缓存重算」入口) */
    fun recomputeFromCache() {
        viewModelScope.launch {
            val rows = history.value
            if (rows.isEmpty()) {
                statusText.value = "暂无缓存数据,请先刷新"
                return@launch
            }
            statusText.value = "本地重算..."
            try {
                withTimeout(30_000) {
                    StatsEngine.backfillFromHistory(statStore, currentLottery.value.key, rows)
                    refreshStats()
                    refreshConsensusStats()
                    runPredictAndPlans(rows)
                    rebuildAnalysis(rows)
                    updateNextIssue(rows)
                    statusText.value = "已用缓存重算 · ${rows.size} 期"
                }
            } catch (e: Exception) {
                errorMessage.value = e.message ?: "本地重算失败"
                statusText.value = "重算失败"
            }
        }
    }

    // ---- 计划 / 共识(委托 PlanViewModel) ----

    fun runBacktest() {
        planVM.runBacktest(
            rows = history.value,
            prefs = prefs.value,
            lotteryKey = currentLottery.value.key,
            onStatus = ::setStatus,
            onError = { errorMessage.value = it }
        )
    }

    suspend fun refreshConsensusStats() {
        planVM.refreshConsensusStats(currentLottery.value.key)
    }

    fun clearConsensusStats() {
        planVM.clearConsensusStats(currentLottery.value.key)
    }

    fun loadPlanDetail(planId: String) {
        planVM.loadPlanDetail(planId)
    }

    fun clearStats() {
        viewModelScope.launch {
            statStore.clear(currentLottery.value.key)
            refreshStats()
        }
    }

    fun backfillStats() {
        viewModelScope.launch {
            StatsEngine.backfillFromHistory(statStore, currentLottery.value.key, history.value)
            refreshStats()
        }
    }

    // ---- 自定义计划(委托 PlanViewModel) ----

    /** 从 Room 加载当前彩种的自定义计划并注入共享 PlanEngine */
    fun loadCustomPlans() {
        planVM.loadCustomPlans(currentLottery.value.key)
    }

    /** 保存(新增或更新)自定义计划 */
    fun saveCustomPlan(plan: com.caifenxi.app.domain.model.CustomPlan) {
        planVM.saveCustomPlan(plan, ::setStatus)
    }

    /** 删除自定义计划 */
    fun deleteCustomPlan(planId: String) {
        planVM.deleteCustomPlan(planId, currentLottery.value.key, ::setStatus)
    }

    /** 启用/停用自定义计划 */
    fun toggleCustomPlan(plan: com.caifenxi.app.domain.model.CustomPlan, enabled: Boolean) {
        planVM.toggleCustomPlan(plan, enabled)
    }

    // ---- 数据导出 / 备份 / 恢复 ----

    /** 导出开奖历史 CSV(可指定彩种;null = 全部) */
    fun exportDrawsCsv(lotteryKey: String? = null) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val file = com.caifenxi.app.data.config.DataExportHelper.exportDrawsCsv(app, app.database, lotteryKey)
                exportedFile.value = file
                statusText.value = "已导出开奖历史:${file.name}"
            } catch (e: Exception) {
                statusText.value = "导出失败:${e.message}"
            }
        }
    }

    /** 导出下注历史 CSV */
    fun exportBetsCsv(lotteryKey: String? = null) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val file = com.caifenxi.app.data.config.DataExportHelper.exportBetsCsv(app, app.database, lotteryKey)
                exportedFile.value = file
                statusText.value = "已导出下注历史:${file.name}"
            } catch (e: Exception) {
                statusText.value = "导出失败:${e.message}"
            }
        }
    }

    /** 导出统计记录 CSV */
    fun exportStatsCsv(lotteryKey: String? = null) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val file = com.caifenxi.app.data.config.DataExportHelper.exportStatsCsv(app, app.database, lotteryKey)
                exportedFile.value = file
                statusText.value = "已导出统计记录:${file.name}"
            } catch (e: Exception) {
                statusText.value = "导出失败:${e.message}"
            }
        }
    }

    /** 导出共识记录 CSV */
    fun exportConsensusCsv(lotteryKey: String? = null) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val file = com.caifenxi.app.data.config.DataExportHelper.exportConsensusCsv(app, app.database, lotteryKey)
                exportedFile.value = file
                statusText.value = "已导出共识记录:${file.name}"
            } catch (e: Exception) {
                statusText.value = "导出失败:${e.message}"
            }
        }
    }

    /** 全量备份(Room 全表 + 用户偏好) */
    fun exportFullBackup() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val prefsJson = Json.encodeToString(prefs.value)
                val file = com.caifenxi.app.data.config.DataExportHelper.exportFullBackup(app, app.database, prefsJson)
                exportedFile.value = file
                statusText.value = "已备份全部数据:${file.name}"
            } catch (e: Exception) {
                statusText.value = "备份失败:${e.message}"
            }
        }
    }

    /** 从备份文件恢复(文件需在应用外部文件目录 export/ 下) */
    fun restoreFromBackup(fileName: String) {
        viewModelScope.launch(Dispatchers.IO) {
            if (restoring.value) return@launch
            restoring.value = true
            try {
                val f = java.io.File(com.caifenxi.app.data.config.DataExportHelper.exportDir(app), fileName)
                if (!f.exists()) {
                    statusText.value = "备份文件不存在:$fileName"
                    return@launch
                }
                val prefsJson = com.caifenxi.app.data.config.DataExportHelper.restoreFullBackup(app.database, f)
                // 恢复用户偏好
                if (prefsJson != null) {
                    val restored = Json { ignoreUnknownKeys = true; encodeDefaults = true }
                        .decodeFromString<com.caifenxi.app.domain.model.UserPrefs>(prefsJson)
                    prefs.value = restored
                    configStore.savePrefs(restored)
                }
                statusText.value = "恢复完成:${f.name}(重启应用后生效)"
            } catch (e: Exception) {
                statusText.value = "恢复失败:${e.message}"
            } finally {
                restoring.value = false
            }
        }
    }

    /** 恢复成功后刷新内存状态 */
    fun reloadAfterRestore() {
        loadData()
        refreshBetState()
        viewModelScope.launch { refreshConsensusStats() }
        loadCustomPlans()
    }

    // ---- 挂机 / 下注(委托 BetViewModel) ----

    /** 从 DB 刷新挂机策略、钱包与下注历史到 UI 状态 */
    fun refreshBetState() {
        betVM.refreshBetState(currentLottery.value.key, ::setStatus)
    }

    /** 重新读取挂机订单、钱包和统计,不删除任何数据。 */
    fun refreshBetOverview() {
        betVM.refreshBetOverview(currentLottery.value.key, ::setStatus)
    }

    /** 清零挂机总览:删除订单、恢复钱包,保留当前挂机策略。 */
    fun resetBetOverview() {
        betVM.resetBetOverview(currentLottery.value.key, ::setStatus)
    }

    /** 重新从现有订单生成收益曲线。 */
    fun refreshBetCurve() {
        betVM.refreshBetCurve(currentLottery.value.key)
    }

    /** 只重置曲线视图状态,不删除订单、钱包或挂机策略。 */
    fun resetBetCurve() {
        betVM.resetBetCurve()
    }

    /** 保存挂机策略 */
    fun saveBotConfig(config: BotConfig) {
        val key = currentLottery.value.key
        betVM.saveBotConfig(config, key, ::setStatus) {
            // 开启挂机后立刻用当前数据跑一轮预测并尝试下单，不必等下一期
            if (config.enabled && history.value.isNotEmpty()) {
                runPredictAndPlans(history.value)
            }
        }
    }

    /** 初始化/重置虚拟账户资金 */
    fun setInitialBalance(amount: Double) {
        betVM.setInitialBalance(amount, currentLottery.value.key, ::setStatus)
    }

    /** 清空下注历史(不影响余额) */
    fun clearBetHistory() {
        betVM.clearBetHistory(currentLottery.value.key)
    }

    // ---- 内部:预测 / 计划 / 挂机链路 ----

    private suspend fun refreshStats() {
        val key = currentLottery.value.key
        statsSummary.value = statStore.summary(key)
        statRecords.value = statStore.loadAll(key).sortedByDescending { it.createdAt }
    }

    private suspend fun rebuildAnalysis(rows: List<DrawRecord>, heavy: Boolean = true) {
        analysis.value = withContext(Dispatchers.Default) {
            AnalysisEngine.build(rows, prefs.value.predictionWindow)
        }
        // 自动刷新时跳过实验室全量回测表，避免每期卡顿
        if (heavy) {
            labRows.value = withContext(Dispatchers.Default) {
                AnalysisEngine.labTable(rows, prefs.value)
            }
        }
    }

    private suspend fun runPredictAndPlans(rows: List<DrawRecord>, forceAlgo: AlgoMode? = null) {
        if (rows.isEmpty()) return
        val cfg = currentLottery.value
        val mode = forceAlgo ?: currentAlgo.value
        val cutoff = rows.last().issue
        // 目标期必须严格晚于已开奖最后一期，避免 nextIssue 误填成本期
        val target = rows.last().nextIssue
            ?.takeIf { it.isNotBlank() && it != cutoff }
            ?: PredictEngine.suggestNextIssue(cutoff)

        var snap = withContext(Dispatchers.Default) {
            PredictEngine.predict(rows, cfg.type, prefs.value, target, cutoff, mode)
        }
        // 手动标记覆盖
        if (mode == AlgoMode.MANUAL) {
            val marks = manualStore.load(cfg.key)
            snap = snap.copy(
                dx = marks["大小"]?.let { snap.dx?.copy(direction = it.direction, algo = "manual", score = 1.0, detail = "手动") } ?: snap.dx,
                ds = marks["单双"]?.let { snap.ds?.copy(direction = it.direction, algo = "manual", score = 1.0, detail = "手动") } ?: snap.ds,
                combo = marks["组合"]?.let { snap.combo?.copy(direction = it.direction, algo = "manual", score = 1.0, detail = "手动") } ?: snap.combo,
                algoTag = "manual"
            )
        }
        // 预测冻结:同目标期已有待开/已结算则不覆盖展示(仍允许算法切换 force)
        val freeze = prefs.value.predFreeze
        val existing = if (freeze) {
            statStore.loadAll(cfg.key).any {
                it.issue == target && it.algoId == mode.id && it.result != "待开"
            }
        } else false
        if (!existing || forceAlgo != null) {
            prediction.value = snap
        }

        if (mode != AlgoMode.COMPARE) {
            StatsEngine.recordPending(statStore, snap, mode.id)
            refreshStats()
        }

        algoCompare.value = withContext(Dispatchers.Default) {
            PredictEngine.compareAll(rows, prefs.value)
        }

        // 计划池:共享 planEngine,状态由 PlanViewModel 同步(等待完成以便挂机使用最新预测)
        val syncResult = planVM.syncAfterPredict(
            rows = rows,
            prefs = prefs.value,
            target = target,
            cutoff = cutoff,
            lotteryKey = cfg.key
        )
        val (cons, _, recent) = syncResult

        // 挂机自动下注:必须用刚算出的 snap（不能用可能被冻结挡住的 prediction.value）
        // 计划预测优先取「目标期」记录，避免历史已结算记录干扰
        val planForBet = recent.filter { it.targetIssue == target && !it.settled }
            .ifEmpty { recent.filter { it.targetIssue == target } }
            .ifEmpty { recent.filter { !it.settled } }
            .ifEmpty { recent }
        val placed = betVM.placeAutoBets(
            lotteryKey = cfg.key,
            targetIssue = target,
            prediction = snap,
            planPredictions = planForBet,
            consensus = cons
        )
        if (placed > 0) {
            statusText.value = "挂机已自动下注 $placed 注 · 第${target}期"
        } else if (betVM.botConfig.value.enabled) {
            // 便于排查：开启挂机却 0 注时给出原因提示
            val why = when {
                cons.isEmpty() && planForBet.isEmpty() && snap.dx == null -> "无可用预测"
                else -> "本源/分类无匹配或本期已下过"
            }
            statusText.value = "挂机未下单($why) · 第${target}期"
        }
        refreshBetState()
    }

    private fun updateNextIssue(rows: List<DrawRecord>) {
        val last = rows.lastOrNull() ?: return
        nextIssueText.value = last.nextIssue
            ?.takeIf { it.isNotBlank() && it != last.issue }
            ?: PredictEngine.suggestNextIssue(last.issue)
    }

    private fun startCountdown() {
        countdownJob?.cancel()
        countdownJob = viewModelScope.launch {
            val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
            while (isActive) {
                val last = latest.value
                val t = last?.drawTime
                if (t != null) {
                    try {
                        // 极速类约 75 秒一期,用上次开奖+75s 估算
                        val base = fmt.parse(t.take(19).replace('T', ' '))
                        if (base != null) {
                            val next = base.time + 75_000
                            val left = next - System.currentTimeMillis()
                            countdownText.value = if (left <= 0) "即将开奖" else {
                                val s = (left / 1000).toInt()
                                "%02d:%02d".format(s / 60, s % 60)
                            }
                        }
                    } catch (_: Exception) {
                        countdownText.value = "--:--"
                    }
                }
                delay(1000)
            }
        }
    }

    private fun startAutoRefreshIfNeeded() {
        stopAutoRefresh()
        if (!prefs.value.autoRefresh) return
        refreshJob = viewModelScope.launch {
            while (isActive) {
                // 失败越多,间隔越长,减轻卡死与封禁风险
                val wait = when {
                    failStreak >= 5 -> 90_000L
                    failStreak >= 2 -> 45_000L
                    else -> 25_000L
                }
                delay(wait)
                // 正在整库加载或手动回测时跳过本轮心跳:
                // 避免与 loadData 并发触发预测/回测(曾导致并发读写崩溃与启动初期闪退)
                if (loadingGuard.get() || backtestRunning.value) continue
                try {
                    withTimeout(15_000) {
                        val one = app.apiClient.fetchLatest(currentLottery.value)
                        if (one != null) {
                            failStreak = 0
                            val curKey = currentLottery.value.key
                            // 彩种切换瞬间的保护:最新开奖与内存历史不属于同一彩种时
                            // 不合并(否则会把 A 彩种的开奖混进 B 彩种的历史),交给 loadData 处理
                            if (one.lotteryKey == curKey &&
                                (history.value.isEmpty() || history.value.lastOrNull()?.lotteryKey == curKey)
                            ) {
                                val exists = history.value.any { it.issue == one.issue }
                                if (!exists) {
                                    val merged = (history.value + one).distinctBy { it.issue }
                                        .sortedBy { it.issue.toLongOrNull() ?: 0L }
                                    history.value = merged
                                    latest.value = one
                                    StatsEngine.settleWithDraw(statStore, currentLottery.value.key, one)
                                    planEngine.settlePendingWithDraw(one, prefs.value.backtestParams)
                                    ConsensusEngine.settleWithDraw(consensusStore, currentLottery.value.key, one)
                                    betVM.settleWithDraw(currentLottery.value.key, one)
                                    planVM.refreshRuntimeState()
                                    betVM.refreshBetState(currentLottery.value.key, ::setStatus)
                                    refreshConsensusStats()
                                    refreshStats()
                                    runPredictAndPlans(merged)
                                    rebuildAnalysis(merged, heavy = false)
                                    updateNextIssue(merged)
                                    statusText.value = "新期 ${one.issue} · 已更新"
                                } else {
                                    statusText.value = "心跳正常 · ${one.issue}"
                                }
                            }
                        }
                    }
                } catch (_: Exception) {
                    failStreak++
                    statusText.value = "后台同步失败($failStreak) · 缓存仍可用"
                }
            }
        }
    }

    private fun stopAutoRefresh() {
        refreshJob?.cancel()
        refreshJob = null
    }

    override fun onCleared() {
        stopAutoRefresh()
        countdownJob?.cancel()
        super.onCleared()
    }
}
