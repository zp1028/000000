package com.caifenxi.app.ui.screens

import android.webkit.JavascriptInterface
import com.caifenxi.app.domain.execution.BetCommand
import com.caifenxi.app.domain.execution.ExecutionResult
import com.caifenxi.app.ui.ExecutorViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * WebView 通信桥（兼容旧 V2 脚手架）。正式执行走 WebViewBetExecutor + WebBetScreen。
 */
class WebExecutorBridge(
    private val viewModel: ExecutorViewModel? = null,
    private val onCommandExecuted: (BetCommand, ExecutionResult) -> Unit = { _, _ -> }
) {
    enum class ExecutionStatus { IDLE, RUNNING, COMPLETED, FAILED }

    data class PredictionResult(
        val lotteryType: String = "",
        val issue: String = "",
        val prediction: String = "",
        val predictionDx: String = "",
        val predictionDs: String = "",
        val amount: Double = 0.0,
        val odds: Double = 0.0
    )

    private val _executionStatus = MutableStateFlow(ExecutionStatus.IDLE)
    val executionStatus: StateFlow<ExecutionStatus> = _executionStatus.asStateFlow()

    private val _executionProgress = MutableStateFlow(0f)
    val executionProgress: StateFlow<Float> = _executionProgress.asStateFlow()

    private val _executionLogs = MutableStateFlow<List<String>>(emptyList())
    val executionLogs: StateFlow<List<String>> = _executionLogs.asStateFlow()

    fun addLog(message: String) {
        _executionLogs.value = (_executionLogs.value + message).takeLast(80)
    }

    fun updateProgress(value: Float) {
        _executionProgress.value = value.coerceIn(0f, 1f)
    }

    fun handleExecutionResult(result: ExecutionResult) {
        _executionStatus.value = if (result.success) ExecutionStatus.COMPLETED else ExecutionStatus.FAILED
        addLog(result.message)
        // 旧桥无完整 BetCommand 上下文时忽略回调细节
    }

    fun setPredictionResult(result: PredictionResult) {
        addLog("已接收预测: ${result.prediction.ifBlank { result.predictionDx + "/" + result.predictionDs }}")
    }

    fun startBetExecution() {
        addLog("请使用底部导航「网页」全屏执行台完成下注")
        _executionStatus.value = ExecutionStatus.IDLE
    }
}

/**
 * JS → Native 接口（兼容旧注入名 Android）。
 * 注意：Kotlin 字符串里 `$count个` 会被解析成标识符 count个，必须写成 ${count}个。
 */
class WebViewInterface(private val bridge: WebExecutorBridge) {

    @JavascriptInterface
    fun onBetResultReceived(success: Boolean, message: String) {
        val result = if (success) {
            ExecutionResult.ok("web_${System.currentTimeMillis()}", message)
        } else {
            ExecutionResult.fail(
                "web_${System.currentTimeMillis()}",
                ExecutionResult.UNKNOWN_RESULT,
                message
            )
        }
        bridge.handleExecutionResult(result)
    }

    @JavascriptInterface
    fun onPageLoaded(url: String) {
        bridge.addLog("网页已加载: $url")
    }

    @JavascriptInterface
    fun onElementFound(elementType: String, count: Int) {
        bridge.addLog("找到${elementType}元素: ${count}个")
        when (elementType) {
            "betButton" -> bridge.updateProgress(0.2f)
            "amountInput" -> bridge.updateProgress(0.4f)
            "submitButton" -> bridge.updateProgress(0.8f)
            "confirmButton" -> bridge.updateProgress(1.0f)
        }
    }

    @JavascriptInterface
    fun onError(error: String) {
        bridge.addLog("网页错误: $error")
    }
}
