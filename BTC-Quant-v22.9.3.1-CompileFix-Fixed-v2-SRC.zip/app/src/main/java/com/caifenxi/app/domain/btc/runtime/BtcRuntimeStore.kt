package com.caifenxi.app.domain.btc.runtime

import android.content.Context
import com.caifenxi.app.domain.btc.paper.PaperTradeLedger

/** Persists runtime control/state only. API secrets are never persisted here. */
class BtcRuntimeStore(context: Context, private val namespace: String = "btc_quant_runtime") {
    val appContext: Context = context.applicationContext
    private val prefs = context.getSharedPreferences(namespace, Context.MODE_PRIVATE)
    private val paperLedger = PaperTradeLedger(context)

    fun paperLedger(): PaperTradeLedger = paperLedger

    fun config(): BtcRuntimeConfig = BtcRuntimeConfig(
        symbol = prefs.getString("symbol", "BTCUSDT") ?: "BTCUSDT",
        timeframe = prefs.getString("timeframe", "5m") ?: "5m",
        runMode = runCatching { BtcRunMode.valueOf(prefs.getString("mode", BtcRunMode.PAPER.name)!!) }
            .getOrDefault(BtcRunMode.PAPER),
        enabled = prefs.getBoolean("enabled", false),
        maxPositionQty = prefs.getString("maxQty", "0.001")?.toDoubleOrNull() ?: 0.001,
        pollSeconds = prefs.getLong("pollSeconds", 20L).coerceIn(10L, 120L),
        liveAutoAuthorized = prefs.getBoolean("liveAutoAuthorized", false),
        maxLeverage = prefs.getInt("maxLeverage", 3).coerceIn(1, 10),
        maxNotionalUsdt = prefs.getString("maxNotional", "100")?.toDoubleOrNull() ?: 100.0,
        maxDailyLossUsdt = prefs.getString("maxDailyLoss", "50")?.toDoubleOrNull() ?: 50.0,
        maxConsecutiveErrors = prefs.getInt("maxConsecutiveErrors", 3).coerceIn(1, 20),
        minOrderIntervalSec = prefs.getLong("minOrderIntervalSec", 60L).coerceIn(10L, 600L),
        requireBracketOrders = prefs.getBoolean("requireBracket", true),
        minProbability = prefs.getString("minProbability", "0.62")?.toDoubleOrNull() ?: 0.62
    )

    fun saveConfig(value: BtcRuntimeConfig) {
        prefs.edit()
            .putString("symbol", value.symbol)
            .putString("timeframe", value.timeframe)
            .putString("mode", value.runMode.name)
            .putBoolean("enabled", value.enabled)
            .putString("maxQty", value.maxPositionQty.toString())
            .putLong("pollSeconds", value.pollSeconds)
            .putBoolean("liveAutoAuthorized", value.liveAutoAuthorized)
            .putInt("maxLeverage", value.maxLeverage)
            .putString("maxNotional", value.maxNotionalUsdt.toString())
            .putString("maxDailyLoss", value.maxDailyLossUsdt.toString())
            .putInt("maxConsecutiveErrors", value.maxConsecutiveErrors)
            .putLong("minOrderIntervalSec", value.minOrderIntervalSec)
            .putBoolean("requireBracket", value.requireBracketOrders)
            .putString("minProbability", value.minProbability.toString())
            .apply()
    }

    fun state(): BtcRuntimeState = BtcRuntimeState(
        status = runCatching {
            BtcRuntimeStatus.valueOf(prefs.getString("status", BtcRuntimeStatus.STOPPED.name)!!)
        }.getOrDefault(BtcRuntimeStatus.STOPPED),
        lastHeartbeatAt = prefs.getLong("heartbeat", 0L),
        lastBarId = prefs.getLong("barId", 0L),
        lastSignal = runCatching {
            com.caifenxi.app.domain.btc.BtcDirection.valueOf(prefs.getString("direction", "FLAT")!!)
        }.getOrDefault(com.caifenxi.app.domain.btc.BtcDirection.FLAT),
        lastOrderClientId = prefs.getString("clientOrderId", null),
        lastError = prefs.getString("error", null),
        killSwitch = prefs.getBoolean("killSwitch", false),
        processedBars = prefs.getLong("processedBars", 0L),
        consecutiveErrors = prefs.getInt("consecutiveErrors", 0),
        lastOrderAt = prefs.getLong("lastOrderAt", 0L),
        lastEquityUsdt = prefs.getString("lastEquityUsdt", "0")?.toDoubleOrNull() ?: 0.0,
        peakEquityUsdt = prefs.getString("peakEquityUsdt", "0")?.toDoubleOrNull() ?: 0.0,
        currentDrawdownPct = prefs.getString("currentDrawdownPct", "0")?.toDoubleOrNull() ?: 0.0
    )

    fun update(transform: (BtcRuntimeState) -> BtcRuntimeState) {
        val s = transform(state())
        prefs.edit()
            .putString("status", s.status.name)
            .putLong("heartbeat", s.lastHeartbeatAt)
            .putLong("barId", s.lastBarId)
            .putString("direction", s.lastSignal?.name ?: "FLAT")
            .apply { s.lastOrderClientId?.let { putString("clientOrderId", it) } ?: remove("clientOrderId") }
            .apply { s.lastError?.let { putString("error", it) } ?: remove("error") }
            .putBoolean("killSwitch", s.killSwitch)
            .putLong("processedBars", s.processedBars)
            .putInt("consecutiveErrors", s.consecutiveErrors)
            .putLong("lastOrderAt", s.lastOrderAt)
            .putString("lastEquityUsdt", s.lastEquityUsdt.toString())
            .putString("peakEquityUsdt", s.peakEquityUsdt.toString())
            .putString("currentDrawdownPct", s.currentDrawdownPct.toString())
            .apply()
    }

    fun setKillSwitch(killed: Boolean) {
        update {
            it.copy(
                killSwitch = killed,
                status = if (killed) BtcRuntimeStatus.KILLED else BtcRuntimeStatus.STOPPED
            )
        }
    }
}
