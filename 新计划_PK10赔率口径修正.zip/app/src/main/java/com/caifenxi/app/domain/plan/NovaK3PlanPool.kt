package com.caifenxi.app.domain.plan

import com.caifenxi.app.domain.model.PlanDefinition
import com.caifenxi.app.domain.model.PlanHitCriteria
import com.caifenxi.app.domain.model.PlanOutputFormat

/**
 * 极速快三专用计划池（与其它彩种隔离）。
 * 玩法：和值大小、三军、鱼虾蟹、长牌（不含二同号）。
 */
object NovaK3PlanPool {
    private val algos = listOf("FREQ", "EWMA", "MKV1", "RHYTHM", "STATE")
    private val windows = listOf(10, 20, 30, 50, 100)

    val ALL: List<PlanDefinition> = buildList {
        for ((i, algo) in algos.withIndex()) {
            val w = windows[i % windows.size]
            add(
                PlanDefinition(
                    planId = "NOVA-K3-SUMDX-$algo",
                    planName = "和值大小·$algo",
                    category = "K3-和值",
                    algorithm = algo,
                    window = w,
                    playType = "和值大小",
                    baselineValue = 0.50,
                    participateConsensus = true
                )
            )
        }
        for (algo in algos.take(3)) {
            add(
                PlanDefinition(
                    planId = "NOVA-K3-SANJUN-$algo",
                    planName = "三军·$algo",
                    category = "K3-三军",
                    algorithm = algo,
                    window = 30,
                    playType = "三军",
                    outputFormat = PlanOutputFormat.NUMBER_SCORES,
                    hitCriteria = PlanHitCriteria.TOP20_HIT,
                    baselineValue = 0.42,
                    participateConsensus = true
                )
            )
            add(
                PlanDefinition(
                    planId = "NOVA-K3-YXX-$algo",
                    planName = "鱼虾蟹·$algo",
                    category = "K3-鱼虾蟹",
                    algorithm = algo,
                    window = 30,
                    playType = "鱼虾蟹",
                    outputFormat = PlanOutputFormat.NUMBER_SCORES,
                    hitCriteria = PlanHitCriteria.TOP20_HIT,
                    baselineValue = 0.42,
                    participateConsensus = true
                )
            )
            add(
                PlanDefinition(
                    planId = "NOVA-K3-CP-$algo",
                    planName = "长牌·$algo",
                    category = "K3-长牌",
                    algorithm = algo,
                    window = 40,
                    playType = "长牌",
                    baselineValue = 0.15,
                    participateConsensus = false
                )
            )
        }
    }

    fun find(planId: String): PlanDefinition? = ALL.find { it.planId == planId }
}
