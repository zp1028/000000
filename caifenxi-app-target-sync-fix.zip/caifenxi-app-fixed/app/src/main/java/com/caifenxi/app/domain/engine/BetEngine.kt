package com.caifenxi.app.domain.engine

import com.caifenxi.app.data.config.StreakCalc
import com.caifenxi.app.data.db.dao.BetDao
import com.caifenxi.app.data.db.entity.BetEntity
import com.caifenxi.app.data.db.entity.BotConfigEntity
import com.caifenxi.app.data.db.entity.WalletEntity
import com.caifenxi.app.domain.model.BetCategory
import com.caifenxi.app.domain.model.BetOdds
import com.caifenxi.app.domain.model.BetSourceType
import com.caifenxi.app.domain.model.BetStats
import com.caifenxi.app.domain.model.CatBetStats
import com.caifenxi.app.domain.model.DrawRecord
import com.caifenxi.app.domain.model.ModelConsensus
import com.caifenxi.app.domain.model.PlanPredictionRecord
import com.caifenxi.app.domain.model.PksPositions
import com.caifenxi.app.domain.model.PredictionSnapshot
import com.caifenxi.app.domain.model.ProfitPoint

/**
 * 模拟下注引擎:下单 + 每期自动结算 + 倍投 + 统计。
 *
 * 倍投规则(各分类独立追踪):
 * - 上一注「中了」→ 本期金额 = min(上期金额 × winMult, 基数 × maxMult)
 * - 上一注「未中」→ 本期金额 = min(上期金额 × lossMult, 基数 × maxMult)
 * - 对/错倍投只持续设置的期数;超过期数后恢复基数。
 * - 一旦结果方向改变,重新按新方向开始计数。
 */
class BetEngine(private val dao: BetDao) {

    companion object {
        const val DEFAULT_INITIAL = 10000.0
    }

    // ---- 内存中追踪各分类上一注结果(lotteryKey -> catName -> lastHit?)----
    private val lastHitMap = mutableMapOf<String, MutableMap<String, Boolean?>>()

    /**
     * 下单诊断结果(便于状态栏说明为何没下单)。
     */
    data class PlaceResult(
        val placed: Int,
        val reason: String,
        val picksSummary: String = ""
    )

    /**
     * 根据挂机策略 + 当前预测,为指定目标期自动下单。
     * @return 本次实际下的注数量
     */
    suspend fun placeAutoBets(
        lotteryKey: String,
        targetIssue: String,
        prediction: PredictionSnapshot?,
        planPredictions: List<PlanPredictionRecord>,
        consensus: List<ModelConsensus>
    ): Int = placeAutoBetsDetailed(
        lotteryKey, targetIssue, prediction, planPredictions, consensus
    ).placed

    /**
     * 带回原因的自动下单,供界面提示「为何没挂上」。
     */
    suspend fun placeAutoBetsDetailed(
        lotteryKey: String,
        targetIssue: String,
        prediction: PredictionSnapshot?,
        planPredictions: List<PlanPredictionRecord>,
        consensus: List<ModelConsensus>
    ): PlaceResult {
        val config = dao.getBotConfig(lotteryKey)
            ?: return PlaceResult(0, "无挂机配置(请到挂机页开启并保存)")
        if (!config.enabled) return PlaceResult(0, "挂机未开启")
        if (config.amount <= 0) return PlaceResult(0, "单注金额为0")
        if (targetIssue.isBlank() || targetIssue == "-") {
            return PlaceResult(0, "目标期无效")
        }

        // 防重:目标期已有「待开」订单则跳过
        if (dao.getPendingBets(lotteryKey, targetIssue).isNotEmpty()) {
            return PlaceResult(0, "目标期 $targetIssue 已有待开单")
        }

        val categories = config.categories.split(",").mapNotNull { BetCategory.fromId(it.trim()) }
        if (categories.isEmpty()) return PlaceResult(0, "未勾选下注分类")

        val picks = resolvePicks(config, prediction, planPredictions, consensus)
        if (picks.isEmpty()) {
            val why = when (BetSourceType.fromId(config.sourceType)) {
                BetSourceType.ALGO ->
                    if (prediction == null) "算法预测为空(未生成)"
                    else "算法预测无可用方向(检查分类是否匹配)"
                BetSourceType.PLAN ->
                    "计划「${config.sourceId}」无预测(计划每期随机换ID时请重选,或已自动兜底仍为空)"
                BetSourceType.CONSENSUS ->
                    "共识预测为空(请打开计划-共识预测页刷新)"
            }
            return PlaceResult(0, why)
        }

        val wallet = dao.getWallet(lotteryKey) ?: ensureWallet(lotteryKey, DEFAULT_INITIAL)
        ensureLastHitFromDb(lotteryKey)
        var balance = wallet.balance
        val initial = wallet.initialBalance
        val catStreaks = lastHitMap.getOrPut(lotteryKey) { mutableMapOf() }
        var placed = 0
        var spent = 0.0
        val pickDesc = picks.entries.joinToString(";") { (k, v) -> "${k.id}:${v.joinToString("/")}" }

        for (cat in categories) {
            val values = picks[cat] ?: continue
            val lastHit = catStreaks[cat.id]
            val prevAmount = getLastAmount(lotteryKey, cat.id)
            val streak = if (lastHit == null) 0 else getRecentStreak(lotteryKey, cat.id, lastHit)
            val currentAmount = calcAmount(
                baseAmount = config.amount,
                lastAmount = prevAmount,
                lastHit = lastHit,
                streak = streak,
                winMult = config.winMult,
                lossMult = config.lossMult,
                winMultPeriods = config.winMultPeriods,
                lossMultPeriods = config.lossMultPeriods,
                maxMult = config.maxMult,
                maxCap = initial * config.maxMult
            ).coerceAtMost((balance - spent).coerceAtLeast(0.0))

            if (currentAmount <= 0 || balance - spent <= 0) {
                if (placed == 0) {
                    return PlaceResult(0, "余额不足(可用 ${"%.1f".format(balance - spent)})", pickDesc)
                }
                break
            }

            val odds = BetOdds.of(cat)
            if ((cat == BetCategory.COMBO || cat == BetCategory.NUMBER) && values.size > 1) {
                if (balance - spent < currentAmount) break
                dao.insertBet(
                    BetEntity(
                        lotteryKey = lotteryKey,
                        issue = targetIssue,
                        sourceType = config.sourceType,
                        sourceId = config.sourceId,
                        category = cat.id,
                        betValue = values.joinToString("/"),
                        amount = currentAmount,
                        odds = odds,
                        status = "待开",
                        profit = 0.0
                    )
                )
                spent += currentAmount
                placed++
            } else {
                for (value in values) {
                    if (balance - spent < currentAmount) break
                    dao.insertBet(
                        BetEntity(
                            lotteryKey = lotteryKey,
                            issue = targetIssue,
                            sourceType = config.sourceType,
                            sourceId = config.sourceId,
                            category = cat.id,
                            betValue = value,
                            amount = currentAmount,
                            odds = odds,
                            status = "待开",
                            profit = 0.0
                        )
                    )
                    spent += currentAmount
                    placed++
                }
            }
        }
        if (spent > 0) {
            dao.upsertWallet(
                wallet.copy(
                    balance = (balance - spent).coerceAtLeast(0.0),
                    updatedAt = System.currentTimeMillis()
                )
            )
        }
        return if (placed > 0) {
            PlaceResult(placed, "已下 $placed 注 · 目标$targetIssue", pickDesc)
        } else {
            PlaceResult(0, "分类与预测方向无交集", pickDesc)
        }
    }

    /**
     * 计算本期下注金额。
     * streak 表示上一期结果方向已经连续出现了多少次。
     * 例如“对了倍投3期”: 第1/2/3个连续命中后的下一注按倍投计算,第4个连续命中后恢复基数。
     */
    private fun calcAmount(
        baseAmount: Double,
        lastAmount: Double,
        lastHit: Boolean?,
        streak: Int,
        winMult: Double,
        lossMult: Double,
        winMultPeriods: Int,
        lossMultPeriods: Int,
        maxMult: Int,
        maxCap: Double
    ): Double {
        if (lastHit == null || streak <= 0) return baseAmount
        val periods = if (lastHit) winMultPeriods else lossMultPeriods
        val mult = if (lastHit) winMult else lossMult
        if (mult <= 1.0 || streak > periods) return baseAmount
        val next = lastAmount * mult
        return next.coerceAtMost(maxCap).coerceAtLeast(baseAmount)
    }

    /** 获取某分类最近一注的金额(用于计算倍投),查 DB 历史记录 */
    private suspend fun getLastAmount(lotteryKey: String, catName: String): Double {
        val bets = dao.getBets(lotteryKey)
        return bets.filter { it.category == catName && it.status != "待开" }
            .maxByOrNull { it.settledAt ?: 0 }?.amount ?: 0.0
    }

    /**
     * 获取最近连续相同结果的期数。
     * 只统计已结算记录,避免把未开奖订单算进倍投周期。
     */
    private suspend fun getRecentStreak(lotteryKey: String, catName: String, targetHit: Boolean): Int {
        val bets = dao.getBets(lotteryKey)
            .filter { it.category == catName && it.status != "待开" }
            .sortedByDescending { it.settledAt ?: it.createdAt }
        var streak = 0
        for (bet in bets) {
            val hit = bet.status == "中"
            if (hit != targetHit) break
            streak++
        }
        return streak
    }

    /**
     * 用一期开奖结果结算所有待开订单,并更新各分类连对/连错追踪。
     */
    suspend fun settleWithDraw(lotteryKey: String, draw: DrawRecord) {
        val pending = dao.getPendingBefore(lotteryKey, draw.issue)
            .plus(dao.getPendingBets(lotteryKey, draw.issue))
            .distinctBy { it.id }
        if (pending.isEmpty()) return

        val wallet = dao.getWallet(lotteryKey) ?: WalletEntity(lotteryKey = lotteryKey)
        var balance = wallet.balance
        var totalProfit = wallet.totalProfit
        var totalBet = wallet.totalBet
        var win = wallet.winCount
        var lose = wallet.loseCount

        val catStreaks = lastHitMap.getOrPut(lotteryKey) { mutableMapOf() }

        // 下单时已扣本金:赢则返还本金+盈利(amount*odds),输则不再加回
        val updated = pending.map { bet ->
            val hit = judge(bet.category, bet.betValue, draw)
            val profit = if (hit) bet.amount * (bet.odds - 1.0) else -bet.amount
            if (hit) {
                balance += bet.amount * bet.odds
            }
            totalProfit += profit
            totalBet += bet.amount
            if (hit) win++ else lose++

            bet.copy(
                status = if (hit) "中" else "未中",
                profit = profit,
                settledAt = System.currentTimeMillis()
            )
        }
        // 倍投方向按分类整体判定:组合/数字位置注为多候选单注(命中任一即对),
        // 大小/单双历史遗留多注也按「该分类本期任一命中即记对」兼容
        pending.groupBy { it.category }.forEach { (cat, bets) ->
            catStreaks[cat] = bets.any { judge(it.category, it.betValue, draw) }
        }
        dao.updateBets(updated)
        dao.upsertWallet(
            wallet.copy(
                balance = balance,
                totalProfit = totalProfit,
                totalBet = totalBet,
                winCount = win,
                loseCount = lose,
                updatedAt = System.currentTimeMillis()
            )
        )
    }

    /**
     * 从 DB 历史计算收益统计 + 对错统计。
     */
    suspend fun getBetStats(lotteryKey: String): BetStats {
        val wallet = dao.getWallet(lotteryKey)
        val bets = dao.getBets(lotteryKey)

        val initial = wallet?.initialBalance ?: DEFAULT_INITIAL
        val balance = wallet?.balance ?: initial
        val totalProfit = wallet?.totalProfit ?: 0.0
        val totalBet = wallet?.totalBet ?: 0.0
        val winCount = wallet?.winCount ?: 0
        val loseCount = wallet?.loseCount ?: 0

        val settled = bets.filter { it.status != "待开" }
        val totalSettled = settled.size

        // 本期(最新期)投入与盈亏 — 期号按数值取最大
        val latestIssue = bets.filter { it.status != "待开" }
            .maxByOrNull { it.issue.toLongOrNull() ?: Long.MIN_VALUE }?.issue ?: ""
        val currentBets = bets.filter { it.issue == latestIssue }
        val currentBetAmount = currentBets.sumOf { it.amount }
        val currentProfit = currentBets.sumOf { it.profit }

        // 按分类统计对错(从历史记录重算,不依赖内存 streak)
        val byCategory = BetCategory.entries.associate { cat ->
            cat.id to buildCatStats(cat.id, bets)
        }

        // 收益曲线:按结算时间升序排列已结算注,逐期累计收益
        val settledChron = settled.sortedBy { it.settledAt ?: Long.MAX_VALUE }
        var running = 0.0
        var peak = 0.0
        var maxDD = 0.0
        var maxDDPct = 0.0
        val curve = mutableListOf<ProfitPoint>()
        settledChron.forEachIndexed { idx, b ->
            running += b.profit
            if (running > peak) peak = running
            val dd = peak - running
            val ddPct = if (peak > 0) dd / peak else 0.0
            if (dd > maxDD) maxDD = dd
            if (ddPct > maxDDPct) maxDDPct = ddPct
            curve.add(
                ProfitPoint(
                    issueIndex = idx,
                    issue = b.issue,
                    cumulativeProfit = running,
                    hit = b.status == "中",
                    drawdown = dd,
                    drawdownPct = ddPct
                )
            )
        }

        // 最长连对/连错(全局,按结算时序)
        var maxHitStreak = 0
        var maxMissStreak = 0
        var curHit = 0
        var curMiss = 0
        settledChron.forEach { b ->
            if (b.status == "中") {
                curHit++; curMiss = 0
                if (curHit > maxHitStreak) maxHitStreak = curHit
            } else {
                curMiss++; curHit = 0
                if (curMiss > maxMissStreak) maxMissStreak = curMiss
            }
        }

        return BetStats(
            initialBalance = initial,
            balance = balance,
            totalProfit = totalProfit,
            totalBet = totalBet,
            profitRate = if (initial > 0) totalProfit / initial else 0.0,
            totalSettled = totalSettled,
            winCount = winCount,
            loseCount = loseCount,
            winRate = if (totalSettled > 0) winCount.toDouble() / totalSettled else 0.0,
            currentBetAmount = currentBetAmount,
            currentProfit = currentProfit,
            byCategory = byCategory,
            profitCurve = curve,
            maxDrawdown = maxDD,
            maxDrawdownPct = maxDDPct,
            peakProfit = peak,
            maxHitStreak = maxHitStreak,
            maxMissStreak = maxMissStreak
        )
    }

    private fun buildCatStats(catName: String, allBets: List<BetEntity>): CatBetStats {
        val catBets = allBets.filter { it.category == catName && it.status != "待开" }
            .sortedBy { it.settledAt ?: Long.MAX_VALUE }

        val hit = catBets.count { it.status == "中" }
        val miss = catBets.size - hit
        val settled = catBets.size

        // 计算连对/连错
        var recent = 0
        var curStreak = 0
        var maxHit = 0
        var maxMiss = 0
        catBets.reversed().forEach { b ->
            val isHit = b.status == "中"
            if (curStreak >= 0) {
                if (isHit) { curStreak++; maxHit = maxOf(maxHit, curStreak) }
                else { curStreak = -1; maxMiss = maxOf(maxMiss, 1) }
            } else {
                if (!isHit) { curStreak--; maxMiss = maxOf(maxMiss, -curStreak) }
                else { curStreak = 1; maxHit = maxOf(maxHit, 1) }
            }
        }
        // recentStreak: 正=连对,负=连错
        recent = curStreak

        // 两期/三期滚动窗口率(与共识口径一致:窗口内至少 1 次中 = 对窗口)
        // 与 hit/miss 同样按注统计;内部按结算时序升序已保证。
        val results = catBets.map { if (it.status == "中") "对" else "错" }
        val (w2, w2Hit, w2Miss) = StreakCalc.windowRates(results, 2)
        val (w3, w3Hit, w3Miss) = StreakCalc.windowRates(results, 3)

        return CatBetStats(
            catName = BetCategory.fromId(catName)?.label ?: catName,
            settled = settled,
            hit = hit,
            miss = miss,
            winRate = if (settled > 0) hit.toDouble() / settled else 0.0,
            profit = catBets.sumOf { it.profit },
            recentStreak = recent,
            maxHitStreak = maxHit,
            maxMissStreak = maxMiss,
            twoWindows = w2,
            twoHitRate = if (w2 > 0) w2Hit.toDouble() / w2 else 0.0,
            twoMissRate = if (w2 > 0) w2Miss.toDouble() / w2 else 0.0,
            threeWindows = w3,
            threeHitRate = if (w3 > 0) w3Hit.toDouble() / w3 else 0.0,
            threeMissRate = if (w3 > 0) w3Miss.toDouble() / w3 else 0.0
        )
    }

    /** 判定一注是否命中。组合/数字位置注可含多候选(以 / 、 , 分隔),命中任一即中 */
    private fun judge(category: String, betValue: String, draw: DrawRecord): Boolean {
        val cands = betValue.split("/", "、", ",").map { it.trim() }.filter { it.isNotEmpty() }
        if (cands.isEmpty()) return false
        return when (BetCategory.fromId(category)) {
            BetCategory.DX -> cands.any { it == draw.dx }
            BetCategory.DS -> cands.any { it == draw.ds }
            BetCategory.COMBO -> cands.any { it == draw.combo }
            BetCategory.NUMBER -> cands.any { cand ->
                val parts = cand.split("=")
                if (parts.size != 2) return@any false
                val posIdx = PksPositions.NAMES.indexOf(parts[0])
                if (posIdx < 0) return@any false
                val num = parts[1].toIntOrNull() ?: return@any false
                draw.numberAt(posIdx) == num
            }
            null -> false
        }
    }

    suspend fun ensureWallet(lotteryKey: String, initialBalance: Double): WalletEntity {
        val existing = dao.getWallet(lotteryKey)
        if (existing != null) return existing
        val w = WalletEntity(lotteryKey = lotteryKey, initialBalance = initialBalance, balance = initialBalance)
        dao.upsertWallet(w)
        return w
    }

    /**
     * 从已结算订单回填各分类最近一次对错,供倍投在进程重启后仍正确延续。
     * 仅在该 lotteryKey 内存缓存为空时执行一次。
     */
    private suspend fun ensureLastHitFromDb(lotteryKey: String) {
        val map = lastHitMap.getOrPut(lotteryKey) { mutableMapOf() }
        if (map.isNotEmpty()) return
        val bets = dao.getBets(lotteryKey)
            .filter { it.status != "待开" }
            .sortedByDescending { it.settledAt ?: it.createdAt }
        for (bet in bets) {
            if (map.containsKey(bet.category)) continue
            map[bet.category] = bet.status == "中"
        }
    }

    /** 清空挂机订单和钱包统计,但保留 bot_config 策略。 */
    suspend fun resetBetOverview(lotteryKey: String, initialBalance: Double = DEFAULT_INITIAL) {
        dao.clearBets(lotteryKey)
        dao.upsertWallet(
            WalletEntity(
                lotteryKey = lotteryKey,
                initialBalance = initialBalance,
                balance = initialBalance,
                updatedAt = System.currentTimeMillis()
            )
        )
        lastHitMap.remove(lotteryKey)
    }

    /**
     * 仅清空订单历史。待开单会把已扣本金退回钱包,避免「清历史吞掉待开本金」。
     */
    suspend fun clearBetsRefundPending(lotteryKey: String) {
        val all = dao.getBets(lotteryKey)
        val pendingAmount = all.filter { it.status == "待开" }.sumOf { it.amount }
        dao.clearBets(lotteryKey)
        lastHitMap.remove(lotteryKey)
        if (pendingAmount > 0) {
            val wallet = dao.getWallet(lotteryKey) ?: return
            dao.upsertWallet(
                wallet.copy(
                    balance = wallet.balance + pendingAmount,
                    updatedAt = System.currentTimeMillis()
                )
            )
        }
    }

    // ---- 来源解析 ----

    /**
     * 解析各分类的下注候选值。
     * 返回 Map<分类, 候选列表>:同一分类可有多个候选(组合 TopN / 位置 TopN / 共识多候选),
     * 每个候选各下一注。空值候选会被忽略。
     */
    private fun resolvePicks(
        config: BotConfigEntity,
        prediction: PredictionSnapshot?,
        planPredictions: List<PlanPredictionRecord>,
        consensus: List<ModelConsensus>
    ): Map<BetCategory, List<String>> {
        return when (BetSourceType.fromId(config.sourceType)) {
            BetSourceType.ALGO -> resolveAlgo(config.numberPosition, prediction)
            BetSourceType.PLAN -> resolvePlan(config.sourceId, planPredictions)
            BetSourceType.CONSENSUS -> resolveConsensus(consensus)
        }
    }

    private fun resolveAlgo(positionIndex: Int, prediction: PredictionSnapshot?): Map<BetCategory, List<String>> {
        if (prediction == null) return emptyMap()
        val map = mutableMapOf<BetCategory, MutableList<String>>()
        prediction.dx?.direction?.let { map.getOrPut(BetCategory.DX) { mutableListOf() }.add(it) }
        prediction.ds?.direction?.let { map.getOrPut(BetCategory.DS) { mutableListOf() }.add(it) }
        prediction.combo?.direction?.let { map.getOrPut(BetCategory.COMBO) { mutableListOf() }.add(it) }
        prediction.positions.getOrNull(positionIndex)?.topNumbers?.firstOrNull()?.number?.let {
            map.getOrPut(BetCategory.NUMBER) { mutableListOf() }.add("${PksPositions.nameAt(positionIndex)}=$it")
        }
        return map
    }

    /**
     * 计划模型来源:按计划类别解析多候选输出(以 / 、 , 分隔)。
     * - 大小/单双: 单候选
     * - 组合: 多候选「大单/大双」全下
     * - 位置-冠军/亚军/第3: 多候选号码 → 「位置=号码」全下
     * - 号码: 无位置信息无法下注,跳过
     */
    private fun resolvePlan(planId: String, planPredictions: List<PlanPredictionRecord>): Map<BetCategory, List<String>> {
        // 精确匹配计划ID;每期随机计划会换 ID,找不到时兜底取任意未结算预测
        val matched = planPredictions.filter { it.planId == planId }
        val pool = when {
            matched.any { !it.settled } -> matched.filter { !it.settled }
            matched.isNotEmpty() -> matched
            planPredictions.any { !it.settled } -> planPredictions.filter { !it.settled }
            else -> planPredictions
        }
        if (pool.isEmpty()) return emptyMap()

        val map = mutableMapOf<BetCategory, MutableList<String>>()
        // 同一分类取一条(优先匹配 planId 的)
        val byCat = pool.groupBy { it.category.ifBlank { "大小" } }
        for ((cat, list) in byCat) {
            val rec = list.firstOrNull { it.planId == planId } ?: list.first()
            val parts = rec.output.split("/", "、", ",").map { it.trim() }.filter { it.isNotEmpty() }
            if (parts.isEmpty()) continue
            when (cat) {
                "大小" -> parts.forEach { if (it == "大" || it == "小") map.getOrPut(BetCategory.DX) { mutableListOf() }.add(it) }
                "单双" -> parts.forEach { if (it == "单" || it == "双") map.getOrPut(BetCategory.DS) { mutableListOf() }.add(it) }
                "组合" -> parts.forEach {
                    if (it in listOf("大单", "大双", "小单", "小双")) {
                        map.getOrPut(BetCategory.COMBO) { mutableListOf() }.add(it)
                    }
                }
                "位置-冠军", "位置-亚军", "位置-第3" -> {
                    val pos = when (cat) {
                        "位置-冠军" -> 0
                        "位置-亚军" -> 1
                        else -> 2
                    }
                    val name = PksPositions.nameAt(pos)
                    parts.forEach { num ->
                        num.toIntOrNull()?.let { map.getOrPut(BetCategory.NUMBER) { mutableListOf() }.add("$name=$it") }
                    }
                }
                else -> parts.forEach { p ->
                    when (p) {
                        in listOf("大单", "大双", "小单", "小双") -> map.getOrPut(BetCategory.COMBO) { mutableListOf() }.add(p)
                        in listOf("大", "小") -> map.getOrPut(BetCategory.DX) { mutableListOf() }.add(p)
                        in listOf("单", "双") -> map.getOrPut(BetCategory.DS) { mutableListOf() }.add(p)
                    }
                }
            }
        }
        return map
    }

    /**
     * 共识来源:大小/单双/组合 + 位置-冠军/亚军/第3 共识均可下注。
     * leadingDirection 可能来自计划的多候选 output(如「大单/大双」「3/5」),
     * 统一按分隔符拆成候选逐注下。
     * 位置共识的候选是号码,映射为「位置=号码」数字注。
     */
    private fun resolveConsensus(consensus: List<ModelConsensus>): Map<BetCategory, List<String>> {
        val map = mutableMapOf<BetCategory, MutableList<String>>()
        consensus.forEach { c ->
            val cands = c.leadingDirection.split("/", "、", ",").map { it.trim() }.filter { it.isNotEmpty() }
            when (c.category) {
                "大小" -> cands.forEach { if (it == "大" || it == "小") map.getOrPut(BetCategory.DX) { mutableListOf() }.add(it) }
                "单双" -> cands.forEach { if (it == "单" || it == "双") map.getOrPut(BetCategory.DS) { mutableListOf() }.add(it) }
                "组合" -> cands.forEach {
                    if (it in listOf("大单", "大双", "小单", "小双")) {
                        map.getOrPut(BetCategory.COMBO) { mutableListOf() }.add(it)
                    }
                }
                "位置-冠军" -> cands.forEach { num -> num.toIntOrNull()?.let { map.getOrPut(BetCategory.NUMBER) { mutableListOf() }.add("冠军=$it") } }
                "位置-亚军" -> cands.forEach { num -> num.toIntOrNull()?.let { map.getOrPut(BetCategory.NUMBER) { mutableListOf() }.add("亚军=$it") } }
                "位置-第3" -> cands.forEach { num -> num.toIntOrNull()?.let { map.getOrPut(BetCategory.NUMBER) { mutableListOf() }.add("第3=$it") } }
            }
        }
        return map
    }
}
