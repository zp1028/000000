package com.caifenxi.app.domain.execution

import kotlinx.coroutines.flow.Flow

/**
 * V2.0 生产级执行仓库
 * 职责：持久化所有 ExecutionTask，支持崩溃恢复和彩种级阻塞
 */
interface ExecutionRepository {

    /** 创建任务，初始状态 CREATED */
    suspend fun create(command: BetCommand): ExecutionTask

    /** CAS 状态流转。返回 true 表示流转成功 */
    suspend fun transition(cmdId: String, from: ExecutionTask.State, to: ExecutionTask.State): Boolean

    /** 查询单个任务 */
    suspend fun findById(cmdId: String): ExecutionTask?

    /** 查询某彩种的所有未终态任务 */
    suspend fun findPendingByLottery(lotteryKey: String): List<ExecutionTask>

    /** 查询所有 UNKNOWN 状态任务（待人工核实） */
    suspend fun findUnknowns(): List<ExecutionTask>

    /** 查询某彩种最后一个成功任务 */
    suspend fun findLastSuccess(lotteryKey: String): ExecutionTask?

    /** 该彩种是否有阻塞中的任务（UNKNOWN 或超时未恢复） */
    suspend fun isLotteryBlocked(lotteryKey: String): Boolean

    /** 标记任务完成（附结果） */
    suspend fun complete(cmdId: String, result: ExecutionResult): Boolean

    /** 标记任务过期 */
    suspend fun expire(cmdId: String): Boolean

    /** 人工确认 UNKNOWN 任务已处理，解除阻塞 */
    suspend fun acknowledgeUnknown(cmdId: String): Boolean

    /** 监听某彩种的任务状态变化 */
    fun observeLotteryTasks(lotteryKey: String): Flow<List<ExecutionTask>>

    /** 监听所有 UNKNOWN 任务 */
    fun observeUnknowns(): Flow<List<ExecutionTask>>
}
