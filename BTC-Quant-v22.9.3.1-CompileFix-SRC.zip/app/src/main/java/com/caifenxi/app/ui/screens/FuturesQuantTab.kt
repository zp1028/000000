package com.caifenxi.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoGraph
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.caifenxi.app.domain.btc.BtcDirection
import com.caifenxi.app.domain.btc.futures.FuturesLogEntry
import com.caifenxi.app.domain.btc.futures.FuturesPosition
import com.caifenxi.app.domain.btc.futures.FuturesQuantConfig
import com.caifenxi.app.domain.btc.futures.FuturesSignal
import com.caifenxi.app.domain.btc.futures.LogLevel
import com.caifenxi.app.domain.btc.futures.MarginMode
import com.caifenxi.app.domain.btc.futures.PositionSide
import com.caifenxi.app.domain.btc.futures.ReconciliationState
import com.caifenxi.app.domain.btc.futures.FuturesOrderReconciler
import com.caifenxi.app.domain.btc.futures.FuturesExecutionState
import com.caifenxi.app.domain.btc.futures.FuturesExecutionSnapshot
import com.caifenxi.app.ui.BtcQuantViewModel
import com.caifenxi.app.ui.theme.CaiTokens
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 合约量化 Tab：币安 U 本位永续合约自动化量化交易
 *
 * 5 大组件：
 * 1. StrategyConfigCard - 策略配置（杠杆/仓位/止损止盈/追踪止损/保证金模式）
 * 2. SignalCard - 当前信号 + 自动开关
 * 3. PositionMonitorCard - 持仓实时监控
 * 4. DailyStatsCard - 日级统计 + 止损止盈进度条
 * 5. ExecutionLogCard - 执行日志
 */
@Composable
fun FuturesQuantTab(viewModel: BtcQuantViewModel) {
    val state by viewModel.state.collectAsState()
    val config by viewModel.futuresConfig.collectAsState()
    val signal by viewModel.futuresSignal.collectAsState()
    val position by viewModel.futuresPosition.collectAsState()
    val exchangeSnapshot by viewModel.futuresExchangeSnapshot.collectAsState()
    val reconciliation by viewModel.futuresReconciliation.collectAsState()
    val orderReconciliation by viewModel.futuresOrderReconciliation.collectAsState()
    val executionSnapshot by viewModel.futuresExecutionSnapshot.collectAsState()
    val dailyStats by viewModel.futuresDailyStats.collectAsState()
    val logEntries by viewModel.futuresLog.collectAsState()
    val autoMode by viewModel.futuresAutoMode.collectAsState()

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
    ) {
        // === 标题 ===
        Row(
            Modifier.fillMaxWidth().padding(24.dp, 18.dp, 24.dp, 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Filled.AutoGraph, contentDescription = null, tint = CaiTokens.Accent)
            Spacer(Modifier.width(8.dp))
            Text("合约量化", style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.weight(1f))
            // Auto mode indicator
            Surface(
                shape = RoundedCornerShape(100.dp),
                color = if (autoMode) CaiTokens.Success.copy(alpha = 0.15f)
                    else MaterialTheme.colorScheme.surfaceVariant
            ) {
                Row(
                    Modifier.padding(12.dp, 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        Modifier.size(8.dp).clip(RoundedCornerShape(50))
                            .background(if (autoMode) CaiTokens.Success else CaiTokens.Muted)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        if (autoMode) "自动运行中" else "手动模式",
                        style = MaterialTheme.typography.labelMedium,
                        color = if (autoMode) CaiTokens.Success else CaiTokens.Muted
                    )
                }
            }
        }

        // 0. 合约终端总览：把策略、持仓、保护单、对账状态放到同一屏首要位置。
        FuturesOverviewCard(
            price = state.markPrice ?: state.candles.lastOrNull()?.close ?: 0.0,
            signal = signal,
            position = position,
            execution = executionSnapshot,
            reconciliation = reconciliation.state,
            autoMode = autoMode,
            dailyPnl = dailyStats.netPnl
        )

        // 1. 策略配置
        StrategyConfigCard(config, viewModel)

        // 2. 当前信号 + 自动开关
        SignalCard(signal, autoMode, config, viewModel)

        // 3. 持仓监控
        PositionMonitorCard(position, exchangeSnapshot, reconciliation, orderReconciliation, state.fundingRate, viewModel)

        // 4. 日级统计
        DailyStatsCard(dailyStats, config)

        // 5. 执行日志
        ExecutionLogCard(logEntries)

        Spacer(Modifier.height(48.dp))
    }
}

@Composable
private fun FuturesOverviewCard(
    price: Double,
    signal: FuturesSignal?,
    position: FuturesPosition,
    execution: FuturesExecutionSnapshot,
    reconciliation: ReconciliationState,
    autoMode: Boolean,
    dailyPnl: Double
) {
    Card(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 5.dp), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(14.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("合约交易终端", fontWeight = FontWeight.Black, fontSize = 16.sp)
                    Text("策略 → 风控 → 下单 → 持仓 → 保护 → 对账", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Surface(shape = RoundedCornerShape(50), color = if (autoMode) CaiTokens.Success.copy(alpha = .14f) else MaterialTheme.colorScheme.surfaceVariant) {
                    Text(if (autoMode) "自动挂机" else "手动", fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 9.dp, vertical = 6.dp))
                }
            }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                FuturesMetric("现价", "%.2f".format(price), Modifier.weight(1f))
                FuturesMetric("信号", signal?.let { if (it.direction == BtcDirection.UP) "做多" else "做空" } ?: "观望", Modifier.weight(1f))
                FuturesMetric("持仓", if (position.isEmpty) "空仓" else "${position.side} %.4f".format(position.quantity), Modifier.weight(1f))
                FuturesMetric("今日盈亏", "%+.2f".format(dailyPnl), Modifier.weight(1f))
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                StateChip("执行", execution.state.name)
                StateChip("对账", reconciliation.name)
                StateChip("止损单", "${execution.slOrderIds.size}")
                StateChip("止盈单", "${execution.tpOrderIds.size}")
                StateChip("杠杆", "${execution.leverage}x")
            }
            if (execution.lastError != null) {
                Text("执行异常：${execution.lastError}", color = MaterialTheme.colorScheme.error, fontSize = 10.sp, modifier = Modifier.padding(top = 7.dp))
            }
        }
    }
}

@Composable
private fun FuturesMetric(label: String, value: String, modifier: Modifier) {
    Column(modifier.background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(8.dp)).padding(8.dp)) {
        Text(label, fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun StateChip(label: String, value: String) {
    Surface(shape = RoundedCornerShape(7.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
        Row(Modifier.padding(horizontal = 7.dp, vertical = 5.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(label, fontSize = 8.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(value, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        }
    }
}

// ==================== 1. 策略配置 ====================

@Composable
private fun StrategyConfigCard(
    config: FuturesQuantConfig,
    viewModel: BtcQuantViewModel
) {
    var leverage by remember(config.leverage) { mutableStateOf(config.leverage.toString()) }
    var positionSize by remember(config.positionSizePct) { mutableStateOf(config.positionSizePct.toString()) }
    var slMult by remember(config.stopLossAtrMult) { mutableStateOf(config.stopLossAtrMult.toString()) }
    var tpMult by remember(config.takeProfitAtrMult) { mutableStateOf(config.takeProfitAtrMult.toString()) }
    var trailingEnabled by remember(config.trailingStopPct) { mutableStateOf(config.trailingStopPct != null) }
    var trailingPct by remember(config.trailingStopPct) { mutableStateOf((config.trailingStopPct ?: 3.0).toString()) }
    var marginIsolated by remember(config.marginMode) { mutableStateOf(config.marginMode == MarginMode.ISOLATED) }
    var minConfidence by remember(config.minConfidence) { mutableStateOf((config.minConfidence * 100).toInt().toString()) }
    var maxDailyLoss by remember(config.maxDailyLossUsdt) { mutableStateOf(config.maxDailyLossUsdt.toInt().toString()) }
    var fundingArb by remember(config.enableFundingArb) { mutableStateOf(config.enableFundingArb) }
    var multiTP by remember(config.enableMultiTakeProfit) { mutableStateOf(config.enableMultiTakeProfit) }

    Card(
        Modifier.fillMaxWidth().padding(16.dp, 8.dp),
        shape = RoundedCornerShape(CaiTokens.RadiusCard),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(20.dp)) {
            Text("策略配置", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(16.dp))

            // 杠杆 & 仓位
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                ConfigInput("杠杆 (x)", leverage, Modifier.weight(1f)) { leverage = it }
                Spacer(Modifier.width(12.dp))
                ConfigInput("仓位 (%)", positionSize, Modifier.weight(1f)) { positionSize = it }
            }
            Spacer(Modifier.height(12.dp))

            // 止损 & 止盈
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                ConfigInput("止损 ATR", slMult, Modifier.weight(1f)) { slMult = it }
                Spacer(Modifier.width(12.dp))
                ConfigInput("止盈 ATR", tpMult, Modifier.weight(1f)) { tpMult = it }
            }
            Spacer(Modifier.height(12.dp))

            // 最低置信度 & 日最大亏损
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                ConfigInput("最低置信 (%)", minConfidence, Modifier.weight(1f)) { minConfidence = it }
                Spacer(Modifier.width(12.dp))
                ConfigInput("日最大亏损 (U)", maxDailyLoss, Modifier.weight(1f)) { maxDailyLoss = it }
            }
            Spacer(Modifier.height(16.dp))

            // 追踪止损开关
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("追踪止损", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                Switch(checked = trailingEnabled, onCheckedChange = {
                    trailingEnabled = it
                    if (!it) trailingPct = "0"
                })
                if (trailingEnabled) {
                    Spacer(Modifier.width(12.dp))
                    ConfigInput("回撤 (%)", trailingPct, Modifier.width(80.dp)) { trailingPct = it }
                }
            }
            Spacer(Modifier.height(8.dp))

            // 保证金模式
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("保证金模式", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                FilterChip(
                    selected = marginIsolated,
                    onClick = { marginIsolated = true },
                    label = { Text("逐仓") }
                )
                Spacer(Modifier.width(8.dp))
                FilterChip(
                    selected = !marginIsolated,
                    onClick = { marginIsolated = false },
                    label = { Text("全仓") }
                )
            }
            Spacer(Modifier.height(8.dp))

            // 资金费率套利 & 多档止盈
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("资金费率套利", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                Switch(checked = fundingArb, onCheckedChange = { fundingArb = it })
            }
            Spacer(Modifier.height(8.dp))
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("多档止盈", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                Switch(checked = multiTP, onCheckedChange = { multiTP = it })
            }
            Spacer(Modifier.height(16.dp))

            // 应用配置按钮
            Button(
                onClick = {
                    viewModel.updateFuturesConfig(
                        leverage = leverage.toIntOrNull()?.coerceIn(1, 125),
                        positionSizePct = positionSize.toDoubleOrNull()?.coerceIn(0.1, 100.0),
                        stopLossAtrMult = slMult.toDoubleOrNull()?.coerceIn(0.5, 10.0),
                        takeProfitAtrMult = tpMult.toDoubleOrNull()?.coerceIn(0.5, 20.0),
                        trailingStopPct = if (trailingEnabled) trailingPct.toDoubleOrNull() else null,
                        trailingStopEnabled = trailingEnabled,
                        marginMode = if (marginIsolated) MarginMode.ISOLATED else MarginMode.CROSSED,
                        minConfidence = (minConfidence.toIntOrNull()?.coerceIn(1, 100) ?: 60) / 100.0,
                        maxDailyLossUsdt = maxDailyLoss.toDoubleOrNull(),
                        enableFundingArb = fundingArb,
                        enableMultiTakeProfit = multiTP
                    )
                },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(CaiTokens.RadiusButton)
            ) { Text("应用配置") }
        }
    }
}

@Composable
private fun ConfigInput(
    label: String,
    value: String,
    modifier: Modifier = Modifier,
    onValueChange: (String) -> Unit
) {
    Column(modifier) {
        Text(label, style = MaterialTheme.typography.labelMedium, color = CaiTokens.Muted)
        Spacer(Modifier.height(4.dp))
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            textStyle = MaterialTheme.typography.bodyMedium
        )
    }
}

// ==================== 2. 信号 + 自动开关 ====================

@Composable
private fun SignalCard(
    signal: FuturesSignal?,
    autoMode: Boolean,
    config: FuturesQuantConfig,
    viewModel: BtcQuantViewModel
) {
    val state by viewModel.state.collectAsState()
    val curConsensus = state.consensus

    Card(
        Modifier.fillMaxWidth().padding(16.dp, 4.dp),
        shape = RoundedCornerShape(CaiTokens.RadiusCard),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(20.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("当前信号", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.weight(1f))
                // 自动模式开关
                Switch(
                    checked = autoMode,
                    onCheckedChange = { viewModel.setFuturesAutoMode(it) },
                    colors = SwitchDefaults.colors(
                        checkedTrackColor = CaiTokens.Success,
                        checkedThumbColor = Color.White
                    )
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    if (autoMode) "自动" else "手动",
                    style = MaterialTheme.typography.labelMedium,
                    color = if (autoMode) CaiTokens.Success else CaiTokens.Muted
                )
            }
            Spacer(Modifier.height(16.dp))

            if (signal == null) {
                // 无信号
                Row(
                    Modifier.fillMaxWidth().padding(16.dp),
                    horizontalArrangement = Arrangement.Center
                ) {
                    val dirText = curConsensus?.direction?.name ?: "无数据"
                    val conf = curConsensus?.let { " (${(it.probability * 100).toInt()}%)" } ?: ""
                    Text(
                        "无交易信号 — 共识: $dirText$conf",
                        style = MaterialTheme.typography.bodyMedium,
                        color = CaiTokens.Muted,
                        textAlign = TextAlign.Center
                    )
                }
            } else {
                // 方向指示
                val isLong = signal.direction == BtcDirection.UP
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        if (isLong) Icons.Filled.TrendingUp else Icons.Filled.TrendingDown,
                        contentDescription = null,
                        tint = if (isLong) CaiTokens.Success else CaiTokens.Danger,
                        modifier = Modifier.size(32.dp)
                    )
                    Spacer(Modifier.width(12.dp))
                    Text(
                        if (isLong) "做多 LONG" else "做空 SHORT",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = if (isLong) CaiTokens.Success else CaiTokens.Danger
                    )
                    Spacer(Modifier.weight(1f))
                    Text(
                        "${(signal.confidence * 100).toInt()}%",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = CaiTokens.Accent
                    )
                }
                Spacer(Modifier.height(16.dp))

                // 信号详情
                SignalMetricRow("入场价", "%.0f".format(signal.entry))
                SignalMetricRow("止损价", "%.0f".format(signal.stopLoss))
                SignalMetricRow("止盈价", "%.0f".format(signal.takeProfit))
                SignalMetricRow("杠杆", "${signal.leverage}x")
                SignalMetricRow("数量", "%.4f BTC".format(signal.quantity))
                SignalMetricRow("保证金", "%.1f USDT".format(signal.margin))
                SignalMetricRow("波动指标 ATR", "%.0f".format(signal.atrValue))
                signal.trailingStopPct?.let {
                    SignalMetricRow("追踪止损", "${it}%")
                }
                Spacer(Modifier.height(8.dp))

                // 信号原因
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant
                ) {
                    Text(
                        signal.reason,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(12.dp, 8.dp)
                    )
                }
                Spacer(Modifier.height(16.dp))

                // 手动开仓按钮（非自动模式时可用）
                if (!autoMode) {
                    Button(
                        onClick = {
                            // 单次手动执行，不开启后台自动模式
                            viewModel.manualFuturesOpen()
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(CaiTokens.RadiusButton),
                        colors = ButtonDefaults.buttonColors(containerColor = CaiTokens.Accent)
                    ) {
                        Icon(Icons.Filled.PlayArrow, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("手动开仓")
                    }
                }
            }
        }
    }
}

@Composable
private fun SignalMetricRow(label: String, value: String) {
    Row(
        Modifier.fillMaxWidth().padding(4.dp, 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = CaiTokens.Muted)
        Text(value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
    }
}

// ==================== 3. 持仓监控 ====================

@Composable
private fun PositionMonitorCard(
    position: FuturesPosition,
    exchangeSnapshot: com.caifenxi.app.domain.btc.futures.ExchangePositionSnapshot?,
    reconciliation: com.caifenxi.app.domain.btc.futures.PositionReconciliation,
    orderReconciliation: FuturesOrderReconciler.Result,
    fundingRate: Double?,
    viewModel: BtcQuantViewModel
) {
    Card(
        Modifier.fillMaxWidth().padding(16.dp, 4.dp),
        shape = RoundedCornerShape(CaiTokens.RadiusCard),
        colors = CardDefaults.cardColors(
            containerColor = if (position.isEmpty) MaterialTheme.colorScheme.surface
                else MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(Modifier.padding(20.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("持仓监控", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.weight(1f))
                Text(
                    when {
                        exchangeSnapshot == null -> "未同步"
                        exchangeSnapshot.isStale -> "同步过期"
                        else -> "交易所已同步"
                    },
                    style = MaterialTheme.typography.labelSmall,
                    color = if (exchangeSnapshot?.isStale == true) CaiTokens.Warning else CaiTokens.Muted
                )
                Spacer(Modifier.width(8.dp))
                OutlinedButton(
                    onClick = { viewModel.syncFuturesExchangePosition() },
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                ) { Text("同步") }
                if (!position.isEmpty) {
                    // 平仓按钮
                    OutlinedButton(
                        onClick = { viewModel.closeFuturesPosition("manual") },
                        shape = RoundedCornerShape(CaiTokens.RadiusButton),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = CaiTokens.Danger)
                    ) {
                        Icon(Icons.Filled.Stop, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("全部平仓")
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                color = when (reconciliation.state) {
                    ReconciliationState.IN_SYNC -> CaiTokens.Success.copy(alpha = 0.10f)
                    ReconciliationState.DRIFT, ReconciliationState.STALE, ReconciliationState.ERROR -> CaiTokens.Warning.copy(alpha = 0.12f)
                    else -> MaterialTheme.colorScheme.surfaceVariant
                }
            ) {
                Row(Modifier.padding(12.dp, 9.dp), verticalAlignment = Alignment.CenterVertically) {
                    val label = when (reconciliation.state) {
                        ReconciliationState.IN_SYNC -> "交易所对账正常"
                        ReconciliationState.DRIFT -> "本地与交易所仓位存在差异"
                        ReconciliationState.STALE -> "交易所仓位数据已过期"
                        ReconciliationState.ERROR -> "交易所仓位同步失败"
                        ReconciliationState.SYNCING -> "正在同步交易所仓位…"
                        ReconciliationState.UNKNOWN -> "等待首次仓位同步"
                    }
                    Text(label, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.weight(1f))
                    if (reconciliation.exchangeQty > 0.0 || reconciliation.localQty > 0.0) {
                        Text("实盘 ${"%.6f".format(reconciliation.exchangeQty)} BTC", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                color = when (orderReconciliation.state) {
                    FuturesOrderReconciler.State.PROTECTED, FuturesOrderReconciler.State.NO_POSITION -> CaiTokens.Success.copy(alpha = 0.08f)
                    FuturesOrderReconciler.State.ERROR, FuturesOrderReconciler.State.ORPHAN_PROTECTION, FuturesOrderReconciler.State.PARTIAL_PROTECTION -> CaiTokens.Warning.copy(alpha = 0.12f)
                    else -> MaterialTheme.colorScheme.surfaceVariant
                }
            ) {
                Column(Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("保护单状态", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.weight(1f))
                        Text(when (orderReconciliation.state) {
                            FuturesOrderReconciler.State.PROTECTED -> "已保护"
                            FuturesOrderReconciler.State.NO_POSITION -> "无持仓"
                            FuturesOrderReconciler.State.PARTIAL_PROTECTION -> "保护不完整"
                            FuturesOrderReconciler.State.ORPHAN_PROTECTION -> "孤儿保护单"
                            FuturesOrderReconciler.State.ERROR -> "同步失败"
                            FuturesOrderReconciler.State.UNKNOWN -> "待同步"
                        }, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "SL ${orderReconciliation.stopOrders.size} · TP ${orderReconciliation.takeProfitOrders.size} · Trailing ${orderReconciliation.trailingOrders.size} · ${orderReconciliation.message}",
                        style = MaterialTheme.typography.labelSmall, color = CaiTokens.Muted
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                color = MaterialTheme.colorScheme.surfaceVariant
            ) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("执行状态", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.weight(1f))
                    Text(when (executionSnapshot.state) {
                        FuturesExecutionState.FLAT -> "空仓"
                        FuturesExecutionState.ENTRY_PENDING -> "开仓等待成交"
                        FuturesExecutionState.OPEN_UNPROTECTED -> "已开仓·未保护"
                        FuturesExecutionState.PROTECTED -> "已开仓·保护完整"
                        FuturesExecutionState.PARTIAL_PROTECTION -> "已开仓·保护不完整"
                        FuturesExecutionState.EXIT_PENDING -> "平仓等待成交"
                        FuturesExecutionState.CLOSED -> "已平仓"
                        FuturesExecutionState.ORPHAN_PROTECTION -> "孤儿保护单"
                        FuturesExecutionState.DRIFT -> "仓位漂移"
                        FuturesExecutionState.STALE -> "数据过期"
                        FuturesExecutionState.ERROR -> "同步错误"
                    }, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.height(8.dp))

            if (position.isEmpty) {
                Text(
                    "无持仓",
                    style = MaterialTheme.typography.bodyMedium,
                    color = CaiTokens.Muted,
                    modifier = Modifier.padding(16.dp).fillMaxWidth(),
                    textAlign = TextAlign.Center
                )
            } else {
                // 方向 & 杠杆
                val isLong = position.side == PositionSide.LONG
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        if (isLong) Icons.Filled.TrendingUp else Icons.Filled.TrendingDown,
                        contentDescription = null,
                        tint = if (isLong) CaiTokens.Success else CaiTokens.Danger
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        "${position.symbol} ${if (isLong) "做多" else "做空"} ${position.leverage}x",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(Modifier.height(12.dp))

                // 盈亏高亮
                val pnlColor = if (position.unrealizedPnl >= 0) CaiTokens.Success else CaiTokens.Danger
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom
                ) {
                    Text("未实现盈亏", style = MaterialTheme.typography.bodyMedium, color = CaiTokens.Muted)
                    Text(
                        "%+.2f USDT (%+.1f%%)".format(position.unrealizedPnl, position.roiPct),
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = pnlColor
                    )
                }
                Spacer(Modifier.height(12.dp))

                // 持仓详情
                val ex = exchangeSnapshot?.risk
                val displayQty = ex?.let { kotlin.math.abs(it.positionAmt) } ?: position.quantity
                val displayEntry = ex?.entryPrice?.takeIf { it > 0.0 } ?: position.entryPrice
                val displayMark = ex?.markPrice?.takeIf { it > 0.0 } ?: position.markPrice
                val displayNotional = ex?.notional?.let { kotlin.math.abs(it) }?.takeIf { it > 0.0 } ?: displayQty * displayMark
                val displayMargin = ex?.isolatedWallet?.takeIf { it > 0.0 } ?: position.margin
                val displayPnl = ex?.unRealizedProfit ?: position.unrealizedPnl
                PosMetricRow("入场价", "%.2f USDT".format(displayEntry))
                PosMetricRow("标记价", "%.2f USDT".format(displayMark))
                PosMetricRow("持仓数量", "%.6f BTC".format(displayQty))
                PosMetricRow("持仓名义", "%.2f USDT".format(displayNotional))
                PosMetricRow("保证金", "%.2f USDT".format(displayMargin))
                PosMetricRow("保证金占用", "%.2f%%".format((displayMargin / displayNotional.coerceAtLeast(0.000001)) * 100))
                PosMetricRow("强平价", if (position.liquidationPrice > 0) "%.2f USDT".format(position.liquidationPrice) else "—")
                position.stopLossPrice?.let { PosMetricRow("止损", "%.0f".format(it)) }
                position.takeProfitPrice?.let { PosMetricRow("止盈", "%.0f".format(it)) }
                fundingRate?.let { PosMetricRow("资金费率", "%.4f%%".format(it * 100)) }

                exchangeSnapshot?.risk?.let { ex ->
                    Spacer(Modifier.height(8.dp))
                    HorizontalDivider()
                    Spacer(Modifier.height(8.dp))
                    Text("交易所真实仓位", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
                    PosMetricRow("交易所方向", ex.sideLabel)
                    PosMetricRow("交易所数量", "%.6f BTC".format(kotlin.math.abs(ex.positionAmt)))
                    PosMetricRow("交易所未实现", "%+.2f USDT".format(ex.unRealizedProfit))
                    PosMetricRow("交易所名义", "%.2f USDT".format(if (ex.notional != 0.0) kotlin.math.abs(ex.notional) else kotlin.math.abs(ex.positionAmt) * ex.markPrice))
                    PosMetricRow("仓位模式", ex.marginType.uppercase())
                    val driftQty = kotlin.math.abs(ex.positionAmt) - position.quantity
                    if (kotlin.math.abs(driftQty) > 0.000001) {
                        Text("⚠ 本地/交易所数量差异：%+.6f BTC".format(driftQty), color = CaiTokens.Warning, style = MaterialTheme.typography.labelSmall)
                    }
                }
                exchangeSnapshot?.let { snap ->
                    Text(
                        "数据源：${snap.source} · ${if (snap.ageMs < 1000) "刚刚" else "${snap.ageMs / 1000}s 前"}",
                        style = MaterialTheme.typography.labelSmall, color = CaiTokens.Muted
                    )
                }

                // 保证金比率预警
                if (position.marginRatio in 0.0..0.20) {
                    Spacer(Modifier.height(8.dp))
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = CaiTokens.Warning.copy(alpha = 0.15f)
                    ) {
                        Row(Modifier.padding(12.dp, 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Warning, contentDescription = null, tint = CaiTokens.Warning)
                            Spacer(Modifier.width(8.dp))
                            Text(
                                "保证金比率偏低 ${"%.1f%%".format(position.marginRatio * 100)}",
                                style = MaterialTheme.typography.labelMedium,
                                color = CaiTokens.Warning
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PosMetricRow(label: String, value: String) {
    Row(
        Modifier.fillMaxWidth().padding(4.dp, 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = CaiTokens.Muted)
        Text(value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
    }
}

// ==================== 4. 日级统计 ====================

@Composable
private fun DailyStatsCard(
    stats: com.caifenxi.app.domain.btc.futures.FuturesDailyStats,
    config: FuturesQuantConfig
) {
    Card(
        Modifier.fillMaxWidth().padding(16.dp, 4.dp),
        shape = RoundedCornerShape(CaiTokens.RadiusCard),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(20.dp)) {
            Text("日级统计 (${stats.date})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(16.dp))

            // 4个核心指标
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                StatMetric("日净盈亏", "%+.1f".format(stats.netPnl),
                    if (stats.netPnl >= 0) CaiTokens.Success else CaiTokens.Danger)
                StatMetric("胜率", "%.0f%%".format(stats.winRate), CaiTokens.Accent)
                StatMetric("交易次数", "${stats.totalTrades}", MaterialTheme.colorScheme.onSurface)
                StatMetric("最大回撤", "%.1f%%".format(stats.maxDrawdown), CaiTokens.Warning)
            }
            Spacer(Modifier.height(16.dp))

            // 止损止盈进度条
            val maxLoss = config.maxDailyLossUsdt
            val profitTarget = maxLoss * 5  // 5:1 止盈目标
            val progress = if (stats.netPnl <= -maxLoss) 0f
                else if (stats.netPnl >= profitTarget) 1f
                else ((stats.netPnl + maxLoss) / (profitTarget + maxLoss)).toFloat().coerceIn(0f, 1f)

            Column {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("止损 -${maxLoss.toInt()}U", style = MaterialTheme.typography.labelSmall, color = CaiTokens.Danger)
                    Text("当前", style = MaterialTheme.typography.labelSmall, color = CaiTokens.Accent)
                    Text("止盈 +${profitTarget.toInt()}U", style = MaterialTheme.typography.labelSmall, color = CaiTokens.Success)
                }
                Spacer(Modifier.height(4.dp))
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                    color = if (stats.netPnl >= 0) CaiTokens.Success else CaiTokens.Danger
                )
            }

            // 连亏 & 止损/止盈命中
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("连亏: ${stats.currentConsecutiveLosses}", style = MaterialTheme.typography.labelMedium,
                    color = if (stats.currentConsecutiveLosses >= 3) CaiTokens.Danger else CaiTokens.Muted)
                Text("SL: ${stats.stopLossHits} / TP: ${stats.takeProfitHits}",
                    style = MaterialTheme.typography.labelMedium, color = CaiTokens.Muted)
                Text("资金费率: %.2fU".format(stats.fundingCost),
                    style = MaterialTheme.typography.labelMedium, color = CaiTokens.Muted)
            }

            // 日亏熔断指示
            if (stats.isStopLossHit) {
                Spacer(Modifier.height(8.dp))
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = CaiTokens.Danger.copy(alpha = 0.15f)
                ) {
                    Row(Modifier.padding(12.dp, 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Warning, contentDescription = null, tint = CaiTokens.Danger)
                        Spacer(Modifier.width(8.dp))
                        Text("日亏熔断已触发", style = MaterialTheme.typography.labelMedium, color = CaiTokens.Danger)
                    }
                }
            }
        }
    }
}

@Composable
private fun StatMetric(label: String, value: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = color)
        Text(label, style = MaterialTheme.typography.labelSmall, color = CaiTokens.Muted)
    }
}

// ==================== 5. 执行日志 ====================

@Composable
private fun ExecutionLogCard(entries: List<FuturesLogEntry>) {
    val timeFmt = remember { SimpleDateFormat("HH:mm:ss", Locale.US) }

    Card(
        Modifier.fillMaxWidth().padding(16.dp, 4.dp),
        shape = RoundedCornerShape(CaiTokens.RadiusCard),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(20.dp)) {
            Text("执行日志", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(12.dp))

            if (entries.isEmpty()) {
                Text(
                    "暂无日志",
                    style = MaterialTheme.typography.bodyMedium,
                    color = CaiTokens.Muted,
                    modifier = Modifier.padding(16.dp).fillMaxWidth(),
                    textAlign = TextAlign.Center
                )
            } else {
                entries.take(30).forEach { entry ->
                    val color = when (entry.level) {
                        LogLevel.SUCCESS -> CaiTokens.Success
                        LogLevel.ERROR -> CaiTokens.Danger
                        LogLevel.WARN -> CaiTokens.Warning
                        LogLevel.INFO -> MaterialTheme.colorScheme.onSurfaceVariant
                    }
                    Row(
                        Modifier.fillMaxWidth().padding(4.dp, 2.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Text(
                            timeFmt.format(Date(entry.timestamp)),
                            style = MaterialTheme.typography.labelSmall,
                            color = CaiTokens.Muted
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            entry.action,
                            style = MaterialTheme.typography.labelSmall,
                            color = color,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            entry.detail,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.weight(1f)
                        )
                        entry.pnl?.let { pnl ->
                            Text(
                                "%+.2f".format(pnl),
                                style = MaterialTheme.typography.labelSmall,
                                color = if (pnl >= 0) CaiTokens.Success else CaiTokens.Danger,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}
