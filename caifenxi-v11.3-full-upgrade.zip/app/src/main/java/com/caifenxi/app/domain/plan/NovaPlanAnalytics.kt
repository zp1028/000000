package com.caifenxi.app.domain.plan

import com.caifenxi.app.domain.model.DrawRecord
import com.caifenxi.app.domain.model.PlanDefinition
import kotlin.math.abs

/** NovaPlan 分析层：严格使用 cutoff 之前的数据，避免回测信息泄漏。 */
object NovaPlanAnalytics {
    data class Result(
        val planId: String,
        val output: String,
        val score: Double,
        val sampleCount: Int,
        val baseline: Double,
        val edge: Double,
        val stability: Double
    )

    data class BacktestReport(
        val planId: String,
        val periods: Int,
        val hits: Int,
        val misses: Int,
        val hitRate: Double,
        val randomBaseline: Double,
        val edge: Double,
        val maxHitStreak: Int,
        val maxMissStreak: Int,
        val stability: Double
    )

    fun predict(plan: PlanDefinition, history: List<DrawRecord>): Result? {
        val data = history.takeLast(plan.window.coerceAtLeast(5))
        if (data.size < 5) return null
        val output = when (plan.algorithm) {
            "STATE" -> state(data)
            "RHYTHM" -> rhythm(data)
            "NETWORK" -> network(data)
            "SIMILAR" -> similar(data)
            "STRUCT" -> structure(data)
            "ANOMALY" -> anomaly(data)
            "CANDIDATE" -> candidates(data)
            "OPTIMIZE" -> candidates(data)
            else -> data.lastOrNull()?.dx ?: ""
        }.ifBlank { return null }
        val baseline = when (plan.outputFormat) {
            com.caifenxi.app.domain.model.PlanOutputFormat.DIRECTION -> 0.50
            com.caifenxi.app.domain.model.PlanOutputFormat.NUMBER_SCORES -> 0.125
            else -> 0.50
        }
        val score = (50.0 + (data.size.coerceAtMost(200) / 200.0) * 10.0).coerceAtMost(60.0)
        return Result(plan.planId, output, score, data.size, baseline, 0.0, 1.0)
    }

    /** walk-forward 回测：每个 target 只使用 target 之前的数据。 */
    fun backtest(plan: PlanDefinition, history: List<DrawRecord>, periods: Int): BacktestReport {
        val n = periods.coerceAtLeast(1).coerceAtMost(history.size - 5)
        val start = (history.size - n).coerceAtLeast(5)
        var hits = 0
        var misses = 0
        var hitStreak = 0
        var missStreak = 0
        var maxHit = 0
        var maxMiss = 0
        val rates = mutableListOf<Double>()
        for (i in start until history.size) {
            val prior = history.subList(0, i)
            val p = predict(plan, prior) ?: continue
            val actual = history[i]
            val hit = when (plan.algorithm) {
                "CANDIDATE", "OPTIMIZE", "NETWORK", "SIMILAR" -> p.output.split('/').any { it.toIntOrNull() in actual.numbers }
                else -> p.output == actual.dx
            }
            if (hit) { hits++; hitStreak++; missStreak = 0; maxHit = maxOf(maxHit, hitStreak) }
            else { misses++; missStreak++; hitStreak = 0; maxMiss = maxOf(maxMiss, missStreak) }
            rates += if (hit) 1.0 else 0.0
        }
        val total = hits + misses
        val rate = if (total == 0) 0.0 else hits.toDouble() / total
        val baseline = when (plan.outputFormat) {
            com.caifenxi.app.domain.model.PlanOutputFormat.NUMBER_SCORES -> 0.125
            else -> 0.50
        }
        val mean = rate
        val variance = if (rates.size < 2) 0.0 else rates.map { (it - mean) * (it - mean) }.average()
        val stability = (1.0 - kotlin.math.sqrt(variance) * 2.0).coerceIn(0.0, 1.0)
        return BacktestReport(plan.planId, total, hits, misses, rate, baseline, rate - baseline, maxHit, maxMiss, stability)
    }

    private fun state(d: List<DrawRecord>): String = d.mapNotNull { it.dx }.takeLast(6).groupingBy { it }.eachCount().maxByOrNull { it.value }?.key ?: ""

    private fun rhythm(d: List<DrawRecord>): String {
        val s = d.mapNotNull { it.dx }
        if (s.size < 4) return ""
        return if (s.takeLast(3).distinct().size == 1) if (s.last() == "大") "小" else "大" else s.groupingBy { it }.eachCount().maxByOrNull { it.value }?.key ?: ""
    }

    private fun network(d: List<DrawRecord>): String {
        val pairs = mutableMapOf<Int, Int>()
        d.takeLast(30).forEach { r -> r.numbers.forEach { n -> pairs[n] = (pairs[n] ?: 0) + 1 } }
        return pairs.entries.sortedByDescending { it.value }.take(10).joinToString("/") { it.key.toString() }
    }

    private fun similar(d: List<DrawRecord>): String {
        val tail = d.takeLast(5).map { it.dx }
        val candidates = d.dropLast(5).windowed(5).mapIndexed { idx, w -> idx to w.map { it.dx } }
        val best = candidates.minByOrNull { (_, w) -> w.zip(tail).count { it.first != it.second } }
        val idx = best?.first ?: return ""
        return d.getOrNull(idx + 5)?.dx ?: ""
    }

    private fun structure(d: List<DrawRecord>): String {
        val last = d.lastOrNull() ?: return ""
        val odd = last.numbers.count { it % 2 != 0 }
        return if (odd >= last.numbers.size / 2.0) "单" else "双"
    }

    private fun anomaly(d: List<DrawRecord>): String {
        val s = d.mapNotNull { it.dx }
        val big = s.count { it == "大" }.toDouble() / s.size
        return if (big > 0.65) "小" else if (big < 0.35) "大" else s.lastOrNull() ?: ""
    }

    private fun candidates(d: List<DrawRecord>): String {
        val counts = mutableMapOf<Int, Int>()
        d.takeLast(50).forEach { r -> r.numbers.forEach { n -> counts[n] = (counts[n] ?: 0) + 1 } }
        return counts.entries.sortedWith(compareByDescending<Map.Entry<Int,Int>> { it.value }.thenBy { it.key }).take(10).joinToString("/") { it.key.toString() }
    }
}
