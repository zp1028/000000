package com.caifenxi.app.domain.btc.runtime

import com.caifenxi.app.domain.btc.TradingSignal
import com.caifenxi.app.domain.btc.broker.PolymarketClobBroker
import kotlin.math.max

/**
 * Final funds/market-constraint gate immediately before a live Polymarket write.
 * It uses current CLOB collateral and market metadata; it never assumes the
 * portfolio benchmark bankroll is the real account balance.
 */
class PolymarketFundingGuard(
    private val minFreeReserve: Double = 1.0,
    private val maxAccountUtilization: Double = 0.95,
    private val cacheMs: Long = 5_000L
) {
    data class Decision(val allowed: Boolean, val reason: String = "", val balance: Double = 0.0, val maxSpend: Double = 0.0)

    private var cachedBalance = Double.NaN
    private var cachedAt = 0L
    private var reservedNotional = 0.0

    suspend fun beforeOrder(
        broker: PolymarketClobBroker,
        signal: TradingSignal.PredictionMarketSignal,
        requestedNotional: Double,
        now: Long = System.currentTimeMillis()
    ): Decision {
        if (requestedNotional <= 0.0) return Decision(false, "订单名义金额必须大于0")
        val balance = if (!cachedBalance.isNaN() && now - cachedAt < cacheMs) cachedBalance else {
            val r = broker.getBalanceAllowance(0).getOrElse { return Decision(false, "无法读取 CLOB 余额：${it.message}") }
            cachedBalance = r.balance
            cachedAt = now
            reservedNotional = 0.0
            r.balance
        }
        if (!balance.isFinite()) return Decision(true, "dry-run funds bypass", balance, requestedNotional)
        val market = broker.getClobMarketInfo(signal.marketId).getOrElse {
            return Decision(false, "无法读取市场执行约束：${it.message}", balance)
        }
        val price = signal.marketPrice.coerceIn(0.000001, 0.999999)
        val shares = requestedNotional / price
        if (market.minimumOrderSize > 0.0 && shares + 1e-9 < market.minimumOrderSize) {
            return Decision(false, "低于市场最小订单量：${market.minimumOrderSize} shares", balance)
        }
        val reserve = max(minFreeReserve, balance * (1.0 - maxAccountUtilization))
        val maxSpend = (balance - reserve - reservedNotional).coerceAtLeast(0.0)
        if (requestedNotional > maxSpend + 1e-9) {
            return Decision(false, "余额不足/超过资金利用上限：余额=${fmt(balance)}，可用=${fmt(maxSpend)}，订单=${fmt(requestedNotional)}", balance, maxSpend)
        }
        reservedNotional += requestedNotional
        return Decision(true, "funds ok", balance, maxSpend)
    }

    /** Release only deterministic failures; successful/indeterminate writes remain reserved until refreshed. */
    fun afterOrder(requestedNotional: Double, success: Boolean, indeterminate: Boolean) {
        if (success) {
            if (cachedBalance.isFinite()) cachedBalance = (cachedBalance - requestedNotional).coerceAtLeast(0.0)
            reservedNotional = (reservedNotional - requestedNotional).coerceAtLeast(0.0)
        } else if (!indeterminate) {
            reservedNotional = (reservedNotional - requestedNotional).coerceAtLeast(0.0)
        }
    }

    fun invalidateCache() { cachedAt = 0L; cachedBalance = Double.NaN; reservedNotional = 0.0 }

    private fun fmt(v: Double) = "%.4f".format(java.util.Locale.US, v)
}
