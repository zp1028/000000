package com.caifenxi.app.domain.btc.broker

import com.caifenxi.app.domain.btc.TradingSignal
import com.caifenxi.app.domain.btc.polymarket.PolymarketUserEventStream
import com.caifenxi.app.domain.btc.polymarket.PolymarketEip712Signer
import com.caifenxi.app.domain.btc.polymarket.PolymarketRepository
import com.caifenxi.app.domain.btc.polymarket.PolymarketProtocolResolver
import com.caifenxi.app.domain.btc.polymarket.PolymarketOrderProtocol
import java.math.BigDecimal
import java.math.RoundingMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.nio.charset.StandardCharsets
import java.util.Base64
import java.util.concurrent.TimeUnit
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

interface EventMarketBroker {
    suspend fun place(signal: TradingSignal.PredictionMarketSignal): BrokerResult
    suspend fun getOrderStatus(orderId: String): BrokerOrderStatus =
        BrokerOrderStatus(false, orderId, "UNKNOWN", 0.0, 0.0, "order status not supported")
    suspend fun cancel(orderId: String): BrokerResult =
        BrokerResult(false, orderId, "LIVE cancel requires authenticated CLOB L2 credentials")
}

data class BrokerResult(
    val ok: Boolean,
    val orderId: String? = null,
    val message: String = "",
    /** True when the venue may have accepted the write but the client cannot know. */
    val indeterminate: Boolean = false,
    val httpCode: Int = 0,
    val retryAfterMs: Long = 0L
)

data class PolymarketPrivateOrder(
    val id: String,
    val status: String,
    val marketId: String,
    val assetId: String,
    val side: String,
    val originalSize: Double,
    val matchedSize: Double,
    val price: Double,
    val outcome: String,
    val createdAt: Long
)

data class PolymarketPrivateTrade(
    val id: String,
    val orderId: String,
    val marketId: String,
    val assetId: String,
    val side: String,
    val size: Double,
    val price: Double,
    val status: String,
    val timestamp: Long,
    val outcome: String,
    val fee: Double = 0.0,
    val maker: Boolean = false
)

data class BrokerOrderStatus(
    val ok: Boolean,
    val orderId: String,
    val status: String,
    val filledSize: Double = 0.0,
    val remainingSize: Double = 0.0,
    val message: String = ""
) {
    val terminal: Boolean
        get() = status.uppercase() in setOf("FILLED", "CANCELED", "CANCELLED", "REJECTED", "EXPIRED")
}

data class PolymarketBalanceAllowance(
    val balance: Double,
    val allowances: Map<String, Double> = emptyMap()
)

data class PolymarketClobMarketInfo(
    val minimumOrderSize: Double,
    val minimumTickSize: Double,
    val makerBaseFeeBps: Int,
    val takerBaseFeeBps: Int,
    val feeRate: Double = 0.0,
    val feeExponent: Int = 0,
    val takerOnly: Boolean = false
)

data class PolymarketBrokerCapabilities(
    val canReadPublicBook: Boolean = true,
    val canPlaceLive: Boolean,
    val canReadPrivateOrders: Boolean,
    val canCancelLive: Boolean,
    val reason: String
)

/**
 * Polymarket CLOB adapter.
 *
 * Public market data is unauthenticated and handled by PolymarketRepository.
 * Private order reads/cancel use current CLOB V2 L2 HMAC authentication.
 * Live order creation remains deliberately gated because it also needs an
 * L1/EIP-712 signed order; API credentials alone are not enough to create it.
 */
class PolymarketClobBroker(
    private val dryRun: Boolean = true,
    private val apiKey: String = "",
    private val apiSecret: String = "",
    private val passphrase: String = "",
    private val address: String = "",
    private val privateKey: String = "",
    private val clobBase: String = "https://clob.polymarket.com",
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()
) : EventMarketBroker {

    private val protocolResolver = PolymarketProtocolResolver(client, clobBase)

    private val hasL2 = apiKey.isNotBlank() && apiSecret.isNotBlank() && passphrase.isNotBlank() && address.isNotBlank()
    private val hasEoaSigner = privateKey.isNotBlank()
    private val signerAddressMatches = runCatching {
        hasEoaSigner && address.isNotBlank() && PolymarketEip712Signer.deriveAddress(privateKey).equals(address, ignoreCase = true)
    }.getOrDefault(false)
    @Volatile private var userStream: PolymarketUserEventStream? = null

    /** Starts the authenticated user channel using the already-configured L2 credentials. */
    fun startUserStream(markets: Collection<String> = emptyList(), listener: PolymarketUserEventStream.Listener): PolymarketUserEventStream? {
        if (!hasL2 || dryRun) return null
        val stream = PolymarketUserEventStream(apiKey, apiSecret, passphrase, client = client)
        userStream = stream
        stream.connect(markets, listener)
        return stream
    }

    fun userStreamPing(): Boolean = userStream?.ping() ?: false

    /**
     * Keeps the authenticated CLOB session alive. The venue documents that
     * missing heartbeats can cause open orders to be canceled.
     */
    suspend fun sendHeartbeat(): BrokerResult = withContext(Dispatchers.IO) {
        if (dryRun) return@withContext BrokerResult(true, null, "dry-run heartbeat")
        if (!hasL2) return@withContext BrokerResult(false, null, capabilities.reason)
        val req = signedRequest("POST", "/heartbeats", null).getOrElse {
            return@withContext BrokerResult(false, null, it.message ?: "heartbeat auth error")
        }
        try {
            client.newCall(req).execute().use { resp ->
                val text = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    return@withContext BrokerResult(false, null, "CLOB heartbeat ${resp.code}: ${text.take(240)}", indeterminate = resp.code >= 500, httpCode = resp.code, retryAfterMs = retryAfterMs(resp.header("Retry-After")))
                }
                BrokerResult(true, null, "heartbeat ok")
            }
        } catch (e: Exception) {
            val unknown = e is java.net.SocketTimeoutException || e is java.net.ConnectException || e is java.io.InterruptedIOException
            BrokerResult(false, null, e.message ?: "heartbeat network error", indeterminate = unknown)
        }
    }

    fun closeUserStream() {
        userStream?.close()
        userStream = null
    }

    val capabilities: PolymarketBrokerCapabilities
        get() = PolymarketBrokerCapabilities(
            canPlaceLive = !dryRun && hasL2 && hasEoaSigner && signerAddressMatches,
            canReadPrivateOrders = !dryRun && hasL2,
            canCancelLive = !dryRun && hasL2,
            reason = when {
                dryRun -> "DRY_RUN"
                !hasL2 -> "缺少 POLY_ADDRESS/API_KEY/SECRET/PASSPHRASE"
                !hasEoaSigner -> "L2 可用；缺少 EOA EIP-712 signer private key"
                !signerAddressMatches -> "EOA private key 与 POLY_ADDRESS 不匹配"
                else -> "L2 + EIP-712 EOA signer 可用；下单前自动探测 CLOB protocol"
            }
        )

    override suspend fun place(signal: TradingSignal.PredictionMarketSignal): BrokerResult = withContext(Dispatchers.IO) {
        if (signal.action != "BUY") return@withContext BrokerResult(false, null, "action=${signal.action}")
        if (dryRun) {
            return@withContext BrokerResult(
                true,
                "POLY-DRY-${signal.marketId.take(8)}",
                "dry-run ${signal.outcome}@${signal.marketPrice} edge=${signal.edge}"
            )
        }
        if (!hasL2) return@withContext BrokerResult(false, null, capabilities.reason)
        if (!hasEoaSigner || !signerAddressMatches) return@withContext BrokerResult(false, null, capabilities.reason)
        val protocol = protocolResolver.resolve()
        if (protocol == PolymarketOrderProtocol.V3) {
            return@withContext BrokerResult(false, null, "CLOB protocol V3 detected: current PredictionMarketSignal is token-backed V2; position-backed V3 order builder is not enabled, so live submission is blocked safely")
        }
        if (protocol == PolymarketOrderProtocol.UNKNOWN) {
            return@withContext BrokerResult(false, null, "unable to resolve CLOB order protocol; live submission blocked")
        }
        if (signal.marketPrice !in 0.000001..0.999999) return@withContext BrokerResult(false, null, "invalid prediction-market price")
        if (signal.positionSize <= 0.0) return@withContext BrokerResult(false, null, "invalid position size")
        try {
            val market = PolymarketRepository(client).marketById(signal.marketId)
                ?: return@withContext BrokerResult(false, null, "market metadata unavailable: ${signal.marketId}")
            val tokenId = when (signal.outcome.uppercase()) {
                "YES", "UP", "BULL", "BULLISH" -> market.yesTokenId
                "NO", "DOWN", "BEAR", "BEARISH" -> market.noTokenId
                else -> return@withContext BrokerResult(false, null, "unsupported outcome=${signal.outcome}")
            }
            if (tokenId.isBlank()) return@withContext BrokerResult(false, null, "missing outcome token id")
            val tick = market.tickSize.coerceIn(0.000001, 0.1)
            val price = (BigDecimal(signal.marketPrice).divide(BigDecimal(tick), 0, RoundingMode.HALF_UP).multiply(BigDecimal(tick)))
                .setScale(6, RoundingMode.DOWN).toDouble().coerceIn(0.000001, 0.999999)
            val budgetUsdc = BigDecimal(signal.positionSize.toString()).setScale(6, RoundingMode.DOWN)
            val shares = budgetUsdc.divide(BigDecimal(price.toString()), 6, RoundingMode.DOWN)
            val makerAmount = budgetUsdc.movePointRight(6).toBigIntegerExact()
            val takerAmount = shares.movePointRight(6).toBigInteger()
            if (takerAmount <= java.math.BigInteger.ZERO) return@withContext BrokerResult(false, null, "position size below token precision")
            val signed = PolymarketEip712Signer.signOrder(
                privateKeyHex = privateKey, maker = address, tokenId = tokenId,
                makerAmount = makerAmount, takerAmount = takerAmount, side = 0,
                signatureType = 0, negRisk = market.negRisk
            )
            val order = JSONObject()
                .put("salt", signed.salt.toLongOrNull() ?: signed.salt)
                .put("maker", signed.maker).put("signer", signed.signer)
                .put("tokenId", signed.tokenId).put("makerAmount", signed.makerAmount).put("takerAmount", signed.takerAmount)
                .put("side", "BUY").put("expiration", signed.expiration.toString())
                .put("signatureType", signed.signatureType).put("timestamp", signed.timestamp.toString())
                .put("metadata", signed.metadata).put("builder", signed.builder).put("signature", signed.signature)
            val body = JSONObject().put("deferExec", false).put("order", order).put("owner", apiKey)
                .put("orderType", "GTC").put("postOnly", false).toString()
            val req = signedRequest("POST", "/order", body).getOrElse {
                return@withContext BrokerResult(false, null, it.message ?: "auth error")
            }
            client.newCall(req).execute().use { resp ->
                val text = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) return@withContext BrokerResult(false, null, "CLOB ${resp.code}: ${text.take(300)}", indeterminate = resp.code >= 500, httpCode = resp.code, retryAfterMs = retryAfterMs(resp.header("Retry-After")))
                val json = runCatching { JSONObject(text) }.getOrNull()
                val orderId = json?.optString("orderID")?.takeIf { it.isNotBlank() } ?: json?.optString("orderId")?.takeIf { it.isNotBlank() }
                BrokerResult(true, orderId, text.take(500).ifBlank { "order accepted" })
            }
        } catch (e: Exception) {
            val msg = e.message ?: "polymarket EIP-712 order error"
            val unknown = e is java.net.SocketTimeoutException || e is java.net.ConnectException || e is java.io.InterruptedIOException
            BrokerResult(false, null, msg, indeterminate = unknown)
        }
    }

    /** Current CLOB V2 collateral balance/allowance. Values are normalized from 1e6 base units. */
    suspend fun getBalanceAllowance(signatureType: Int = 0, tokenId: String? = null): Result<PolymarketBalanceAllowance> = withContext(Dispatchers.IO) {
        if (dryRun) return@withContext Result.success(PolymarketBalanceAllowance(Double.POSITIVE_INFINITY))
        if (!hasL2) return@withContext Result.failure(IllegalStateException(capabilities.reason))
        runCatching {
            val params = buildString {
                append("?asset_type=COLLATERAL&signature_type=").append(signatureType)
                if (!tokenId.isNullOrBlank()) append("&token_id=").append(java.net.URLEncoder.encode(tokenId, "UTF-8"))
            }
            val req = signedRequest("GET", "/balance-allowance$params", null).getOrThrow()
            client.newCall(req).execute().use { resp ->
                val text = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) error("CLOB ${resp.code}: ${text.take(240)}")
                val root = JSONObject(text)
                val data = root.optJSONObject("data") ?: root
                val balanceRaw = data.opt("balance")
                val balance = when (balanceRaw) {
                    is Number -> balanceRaw.toDouble()
                    is String -> balanceRaw.toDoubleOrNull() ?: 0.0
                    else -> 0.0
                } / 1_000_000.0
                val allowances = mutableMapOf<String, Double>()
                data.optJSONObject("allowances")?.let { obj ->
                    obj.keys().forEach { k ->
                        val v = obj.opt(k)
                        val n = when (v) { is Number -> v.toDouble(); is String -> v.toDoubleOrNull() ?: 0.0; else -> 0.0 }
                        allowances[k] = n / 1_000_000.0
                    }
                }
                data.optString("allowance").toDoubleOrNull()?.let { allowances["legacy"] = it / 1_000_000.0 }
                PolymarketBalanceAllowance(balance, allowances)
            }
        }
    }

    /** CLOB-level constraints: minimum order size, tick size and V2 fee parameters. */
    suspend fun getClobMarketInfo(conditionId: String): Result<PolymarketClobMarketInfo> = withContext(Dispatchers.IO) {
        if (conditionId.isBlank()) return@withContext Result.failure(IllegalArgumentException("blank conditionId"))
        runCatching {
            val marketReq = Request.Builder().url(clobBase.trimEnd('/') + "/clob-market/${encodePath(conditionId)}").get().build()
            client.newCall(marketReq).execute().use { resp ->
                val text = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) error("CLOB ${resp.code}: ${text.take(240)}")
                val root = JSONObject(text)
                val data = root.optJSONObject("data") ?: root
                val fee = data.optJSONObject("fd")
                PolymarketClobMarketInfo(
                    minimumOrderSize = data.optDouble("mos", 0.0),
                    minimumTickSize = data.optDouble("mts", 0.0),
                    makerBaseFeeBps = data.optInt("mbf", 0),
                    takerBaseFeeBps = data.optInt("tbf", 0),
                    feeRate = fee?.optDouble("r", 0.0) ?: 0.0,
                    feeExponent = fee?.optInt("e", 0) ?: 0,
                    takerOnly = fee?.optBoolean("to", false) ?: false
                )
            }
        }
    }

    suspend fun listPrivateOrders(limit: Int = 100): Result<List<PolymarketPrivateOrder>> = withContext(Dispatchers.IO) {
        if (dryRun) return@withContext Result.success(emptyList())
        if (!hasL2) return@withContext Result.failure(IllegalStateException(capabilities.reason))
        runCatching {
            val req = signedRequest("GET", "/data/orders", null).getOrThrow()
            client.newCall(req).execute().use { resp ->
                val text = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) error("CLOB ${resp.code}: ${text.take(240)}")
                val root = JSONObject(text)
                val data = root.optJSONArray("data") ?: org.json.JSONArray()
                buildList {
                    for (i in 0 until data.length()) {
                        val o = data.optJSONObject(i) ?: continue
                        add(PolymarketPrivateOrder(
                            id = o.optString("id"),
                            status = o.optString("status").uppercase(),
                            marketId = o.optString("market"),
                            assetId = o.optString("asset_id"),
                            side = o.optString("side").uppercase(),
                            originalSize = firstDouble(o, "original_size", "originalSize", "size"),
                            matchedSize = firstDouble(o, "size_matched", "sizeMatched", "filledSize", "filled"),
                            price = firstDouble(o, "price"),
                            outcome = o.optString("outcome"),
                            createdAt = o.optLong("created_at", 0L)
                        ))
                    }
                }
            }
        }
    }

    suspend fun listPrivateTrades(limit: Int = 100): Result<List<PolymarketPrivateTrade>> = withContext(Dispatchers.IO) {
        if (dryRun) return@withContext Result.success(emptyList())
        if (!hasL2) return@withContext Result.failure(IllegalStateException(capabilities.reason))
        runCatching {
            val req = signedRequest("GET", "/trades", null).getOrThrow()
            client.newCall(req).execute().use { resp ->
                val text = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) error("CLOB ${resp.code}: ${text.take(240)}")
                val root = JSONObject(text)
                val data = root.optJSONArray("data") ?: org.json.JSONArray()
                buildList {
                    for (i in 0 until data.length()) {
                        val o = data.optJSONObject(i) ?: continue
                        add(PolymarketPrivateTrade(
                            id = o.optString("id"),
                            orderId = firstString(o, "taker_order_id", "maker_order_id", "order_id", "orderId"),
                            marketId = o.optString("market"),
                            assetId = o.optString("asset_id"),
                            side = o.optString("side").uppercase(),
                            size = firstDouble(o, "size"),
                            price = firstDouble(o, "price"),
                            status = o.optString("status").uppercase(),
                            timestamp = o.optLong("match_time", o.optLong("last_update", 0L)),
                            outcome = o.optString("outcome"),
                            fee = firstDouble(o, "fee", "fee_amount", "feeAmount"),
                            maker = o.optBoolean("maker", false)
                        ))
                    }
                }
            }
        }
    }

    override suspend fun getOrderStatus(orderId: String): BrokerOrderStatus = withContext(Dispatchers.IO) {
        if (orderId.isBlank()) return@withContext BrokerOrderStatus(false, orderId, "UNKNOWN", message = "blank order id")
        if (dryRun) return@withContext BrokerOrderStatus(true, orderId, "OPEN", message = "dry-run")
        if (!hasL2) return@withContext BrokerOrderStatus(false, orderId, "UNKNOWN", message = capabilities.reason)
        val path = "/order/${encodePath(orderId)}"
        val req = signedRequest("GET", path, null).getOrElse {
            return@withContext BrokerOrderStatus(false, orderId, "UNKNOWN", message = it.message ?: "auth error")
        }
        try {
            client.newCall(req).execute().use { resp ->
                val text = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    return@withContext BrokerOrderStatus(false, orderId, "UNKNOWN", message = "CLOB ${resp.code}: ${text.take(240)}")
                }
                val o = runCatching { JSONObject(text) }.getOrNull()
                    ?: return@withContext BrokerOrderStatus(false, orderId, "UNKNOWN", message = "invalid JSON")
                val status = firstString(o, "status", "orderStatus", "state").uppercase().ifBlank { "UNKNOWN" }
                val filled = firstDouble(o, "size_matched", "sizeMatched", "filledSize", "filled")
                val original = firstDouble(o, "original_size", "originalSize", "size")
                val remaining = firstDouble(o, "remaining_size", "remainingSize", "remaining")
                    .let { if (it > 0.0) it else (original - filled).coerceAtLeast(0.0) }
                BrokerOrderStatus(true, orderId, status, filled, remaining, text.take(300))
            }
        } catch (e: Exception) {
            BrokerOrderStatus(false, orderId, "UNKNOWN", message = e.message ?: "poly order status error")
        }
    }

    override suspend fun cancel(orderId: String): BrokerResult = withContext(Dispatchers.IO) {
        if (orderId.isBlank()) return@withContext BrokerResult(false, orderId, "blank order id")
        if (dryRun) return@withContext BrokerResult(true, orderId, "dry-run cancel")
        if (!hasL2) return@withContext BrokerResult(false, orderId, capabilities.reason)

        val path = "/order"
        // Current CLOB API cancels one order with DELETE /order and a JSON orderID body.
        // Keep the exact endpoint/body pair so the HMAC covers what is sent.
        val body = JSONObject().put("orderID", orderId).toString()
        val req = signedRequest("DELETE", path, body).getOrElse {
            return@withContext BrokerResult(false, orderId, it.message ?: "auth error")
        }
        try {
            client.newCall(req).execute().use { resp ->
                val text = resp.body?.string().orEmpty()
                if (resp.isSuccessful) {
                    BrokerResult(true, orderId, text.take(300).ifBlank { "cancel accepted" })
                } else {
                    BrokerResult(false, orderId, "CLOB ${resp.code}: ${text.take(240)}", httpCode = resp.code, retryAfterMs = retryAfterMs(resp.header("Retry-After")))
                }
            }
        } catch (e: Exception) {
            BrokerResult(false, orderId, e.message ?: "poly cancel error")
        }
    }

    private fun signedRequest(method: String, path: String, body: String?): Result<Request> = runCatching {
        val ts = (System.currentTimeMillis() / 1000L).toString()
        val signature = buildHmacSignature(apiSecret, ts, method, path, body)
        val builder = Request.Builder()
            .url(clobBase.trimEnd('/') + path)
            .header("POLY_ADDRESS", address)
            .header("POLY_SIGNATURE", signature)
            .header("POLY_TIMESTAMP", ts)
            .header("POLY_API_KEY", apiKey)
            .header("POLY_PASSPHRASE", passphrase)
            .header("Accept", "application/json")
        if (body != null) {
            builder.header("Content-Type", "application/json")
                .method(method, body.toRequestBody("application/json".toMediaType()))
        } else {
            builder.method(method, null)
        }
        builder.build()
    }

    companion object {
        fun buildHmacSignature(secret: String, timestamp: String, method: String, requestPath: String, body: String? = null): String {
            val decoded = runCatching { Base64.getDecoder().decode(secret) }.getOrElse { Base64.getUrlDecoder().decode(secret) }
            var message = timestamp + method + requestPath
            if (!body.isNullOrEmpty()) message += body.replace('\'', '"')
            val mac = Mac.getInstance("HmacSHA256")
            mac.init(SecretKeySpec(decoded, "HmacSHA256"))
            return Base64.getUrlEncoder().encodeToString(
                mac.doFinal(message.toByteArray(StandardCharsets.UTF_8))
            )
        }

        private fun retryAfterMs(value: String?): Long {
            val raw = value?.trim().orEmpty()
            if (raw.isBlank()) return 0L
            raw.toLongOrNull()?.let { return it.coerceAtLeast(0L) * 1000L }
            return 0L
        }

        private fun firstString(o: JSONObject, vararg keys: String): String =
            keys.firstNotNullOfOrNull { key -> o.optString(key, "").takeIf { it.isNotBlank() } }.orEmpty()

        private fun firstDouble(o: JSONObject, vararg keys: String): Double =
            keys.firstNotNullOfOrNull { key ->
                when (val v = o.opt(key)) {
                    is Number -> v.toDouble()
                    is String -> v.toDoubleOrNull()
                    else -> null
                }
            } ?: 0.0

        private fun encodePath(value: String): String = java.net.URLEncoder.encode(value, "UTF-8").replace("+", "%20")
    }
}
