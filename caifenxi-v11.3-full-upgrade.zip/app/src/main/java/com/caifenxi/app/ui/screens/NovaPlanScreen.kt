package com.caifenxi.app.ui.screens

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.caifenxi.app.domain.plan.NovaPlanAnalytics
import com.caifenxi.app.domain.plan.NovaPlanPool
import com.caifenxi.app.domain.plan.NovaPlanWorkbench
import com.caifenxi.app.domain.model.PlanDefinition
import com.caifenxi.app.ui.MainViewModel
import com.caifenxi.app.ui.components.CaptionMuted
import com.caifenxi.app.ui.components.GlobalCard
import com.caifenxi.app.ui.components.PrimaryButton
import com.caifenxi.app.ui.theme.CaiTokens
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun NovaPlanScreen(vm: MainViewModel) {
    var page by remember { mutableStateOf("计划库") }
    var group by remember { mutableStateOf("全部") }
    var selectedId by remember { mutableStateOf<String?>(null) }
    var periods by remember { mutableStateOf(200) }
    var arenaRows by remember { mutableStateOf<List<NovaPlanWorkbench.ArenaRow>>(emptyList()) }
    var running by remember { mutableStateOf(false) }
    var explanation by remember { mutableStateOf<NovaPlanWorkbench.Explanation?>(null) }
    var ensemble by remember { mutableStateOf<NovaPlanWorkbench.Ensemble?>(null) }
    val scope = rememberCoroutineScope()
    val history = vm.history.value
    val plans = if (group == "全部") NovaPlanPool.ALL else NovaPlanPool.ALL.filter { it.category == "Nova-$group" }
    val selected = plans.firstOrNull { it.planId == selectedId } ?: NovaPlanPool.ALL.firstOrNull { it.planId == selectedId }

    LazyColumn(Modifier.fillMaxSize().padding(horizontal = CaiTokens.ScreenHPadding, vertical = CaiTokens.S16), verticalArrangement = Arrangement.spacedBy(CaiTokens.S8)) {
        item {
            Text("新计划池", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            CaptionMuted("NovaPlan ${NovaPlanPool.VERSION} · 独立于原计划引擎")
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("计划库", "竞技场", "回测实验室", "计划组合").forEach { p -> FilterChip(selected = page == p, onClick = { page = p }, label = { Text(p) }) }
            }
        }
        when (page) {
            "计划库" -> {
                item {
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        (listOf("全部") + NovaPlanPool.GROUPS).forEach { g -> FilterChip(selected = group == g, onClick = { group = g }, label = { Text(g) }) }
                    }
                }
                item { GlobalCard { Text("计划生成工厂", fontWeight = FontWeight.Bold); CaptionMuted("数据 → 特征 → 计划 → 回测 → 竞技 → 生命周期"); Text("当前 ${plans.size} 个模板，可继续按窗口/周期生成实例。") } }
                selected?.let { plan ->
                    item { PlanSelectedCard(plan, history, onExplain = { explanation = NovaPlanWorkbench.explain(plan, history) }, onUse = { vm.selectCockpitPlan(plan.planId) }) }
                }
                items(plans, key = { it.planId }) { plan ->
                    GlobalCard { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Column(Modifier.weight(1f)) { Text(plan.planName, fontWeight = FontWeight.SemiBold); CaptionMuted("${plan.planId} · ${plan.algorithm} · ${plan.window}期") }; FilterChip(selected = selectedId == plan.planId, onClick = { selectedId = plan.planId }, label = { Text("选择") }) } }
                }
            }
            "竞技场" -> {
                item { ArenaHeader(periods, onPeriods = { periods = it }, running = running, onRun = {
                    scope.launch { running = true; arenaRows = withContext(Dispatchers.Default) { NovaPlanWorkbench.arena(history, periods) }; running = false }
                }) }
                items(arenaRows.take(60), key = { it.plan.planId }) { row ->
                    GlobalCard { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Column(Modifier.weight(1f)) { Text(row.plan.planName, fontWeight = FontWeight.SemiBold); CaptionMuted("${row.plan.planId} · ${row.lifecycle} · 稳定性 ${row.stabilityGrade}"); Text("命中 ${(row.report.hitRate*100).toInt()}%  基准 ${(row.report.randomBaseline*100).toInt()}%  Edge ${(row.report.edge*100).toInt()}%  连错峰值 ${row.report.maxMissStreak}") }; Text("${row.rankScore.toInt()}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) } }
                }
            }
            "回测实验室" -> {
                item { ArenaHeader(periods, onPeriods = { periods = it }, running = running, onRun = {
                    scope.launch { running = true; arenaRows = withContext(Dispatchers.Default) { NovaPlanWorkbench.arena(history, periods) }; running = false }
                }) }
                item { GlobalCard { Text("严格走期回测", fontWeight = FontWeight.Bold); CaptionMuted("每个目标期只读取开奖前数据；不使用未来数据。回测结果仅用于历史表现评估。") } }
                if (selected != null) {
                    item { val report = arenaRows.firstOrNull { it.plan.planId == selected.planId }?.report; GlobalCard { Text("${selected.planName} 回测", fontWeight = FontWeight.Bold); if (report == null) CaptionMuted("先点击开始回测") else { Text("样本 ${report.periods} · 对 ${report.hits} · 错 ${report.misses}"); Text("命中 ${(report.hitRate*100).toInt()}% · 随机基准 ${(report.randomBaseline*100).toInt()}% · Edge ${(report.edge*100).toInt()}%"); Text("最大连中 ${report.maxHitStreak} · 最大连错 ${report.maxMissStreak} · 稳定性 ${(report.stability*100).toInt()}%") } } }
                }
            }
            "计划组合" -> {
                item { GlobalCard { Text("NovaPlan Ensemble", fontWeight = FontWeight.Bold); CaptionMuted("根据竞技场排名自动生成候选计划组合，权重仅反映历史评分，不代表真实中奖概率。"); PrimaryButton("生成组合", onClick = { ensemble = NovaPlanWorkbench.ensemble(arenaRows) }, modifier = Modifier.fillMaxWidth()) } }
                ensemble?.let { e -> item { GlobalCard { Text("当前组合", fontWeight = FontWeight.Bold); e.planIds.forEach { id -> Text("$id · 权重 ${(e.weights[id]!!*100).toInt()}%") } } } }
            }
        }
        explanation?.let { e -> item { GlobalCard(containerColor = MaterialTheme.colorScheme.primaryContainer) { Text("计划解释", fontWeight = FontWeight.Bold); Text(e.title, style = MaterialTheme.typography.titleMedium); CaptionMuted("${e.planId} · 输入窗口 ${e.inputWindow}期 · 输出 ${e.output}"); e.factors.forEach { (name, value) -> Text("$name  ${(value*100).toInt()} / 100") } } } }
    }
}

@Composable private fun PlanSelectedCard(plan: PlanDefinition, history: List<com.caifenxi.app.domain.model.DrawRecord>, onExplain: () -> Unit, onUse: () -> Unit) {
    GlobalCard(containerColor = MaterialTheme.colorScheme.primaryContainer) {
        Text("已选计划", fontWeight = FontWeight.Bold)
        Text(plan.planName, style = MaterialTheme.typography.titleMedium)
        CaptionMuted("${plan.planId} · ${NovaPlanWorkbench.versionLabel(plan)} · ${plan.window}期 · 周期${plan.cyclePeriods}期")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PrimaryButton("用于驾驶舱", onClick = onUse, modifier = Modifier.weight(1f))
            PrimaryButton("查看解释", onClick = onExplain, ghost = true, modifier = Modifier.weight(1f))
        }
    }
}

@Composable private fun ArenaHeader(periods: Int, onPeriods: (Int) -> Unit, running: Boolean, onRun: () -> Unit) {
    GlobalCard { Text("计划竞技场", fontWeight = FontWeight.Bold); CaptionMuted("回测期数可手动调整；排名综合命中率、稳定性、基准 Edge 与连错风险。"); Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) { OutlinedButton(onClick = { onPeriods((periods - 50).coerceAtLeast(20)) }) { Text("−") }; Text("${periods}期", modifier = Modifier.padding(top = 12.dp)); OutlinedButton(onClick = { onPeriods((periods + 50).coerceAtMost(10000)) }) { Text("+") } }; PrimaryButton(if (running) "计算中…" else "开始竞技场回测", onClick = onRun, modifier = Modifier.fillMaxWidth(), enabled = !running) }
}
