package com.caifenxi.app.domain.plan

import com.caifenxi.app.domain.model.LotteryType
import com.caifenxi.app.domain.model.PlanDefinition
import com.caifenxi.app.domain.model.PlanHitCriteria
import com.caifenxi.app.domain.model.PlanOutputFormat

/**
 * 计划池 V2：算法族 × 参数窗口 × 玩法 × 位置。
 *
 * 设计原则：
 * 1. 同一个算法不能靠改名字冒充多个计划；
 * 2. 每个可定位玩法都按 positionIndex 独立建模；
 * 3. 核心池与候选池分开，核心池默认 30 个/玩法/位置；
 * 4. 候选池允许扩展到 200 个/玩法/位置，再通过回测、去重、生命周期晋级。
 */
object PlanPoolV2 {
    private val coreCache = java.util.concurrent.ConcurrentHashMap<LotteryType, List<PlanDefinition>>()
    private val candCache = java.util.concurrent.ConcurrentHashMap<LotteryType, List<PlanDefinition>>()
    private val legacyCache = java.util.concurrent.ConcurrentHashMap<LotteryType, List<PlanDefinition>>()
    const val VERSION = "PLAN-POOL-V2.0"

    /** 20 个算法族；名称只是策略族，具体参数由 window + variant 决定。 */
    val ALGORITHMS = listOf(
        "FREQ", "EWMA", "WMA", "OMIT", "HOTCOLD",
        "STREAK", "TRANSITION", "MARKOV2", "PERIOD", "TREND",
        "REVERSAL", "VOLATILITY", "SIMILAR", "NETWORK", "STRUCT",
        "ANOMALY", "CANDIDATE", "OPTIMIZE", "ENSEMBLE", "ADAPTIVE"
    )

    private val CORE_ALGOS = ALGORITHMS.take(10)
    private val CANDIDATE_WINDOWS = listOf(8, 10, 15, 20, 30, 40, 50, 80, 100, 150)
    private val CORE_WINDOWS = listOf(10, 20, 30)

    private data class Slot(val playType: String, val position: Int = -1, val label: String = "")

    fun core(type: LotteryType): List<PlanDefinition> = coreCache.getOrPut(type) { build(type, CORE_ALGOS, CORE_WINDOWS, "CORE", "NOVA-V2") }
    fun candidates(type: LotteryType): List<PlanDefinition> = candCache.getOrPut(type) { build(type, ALGORITHMS, CANDIDATE_WINDOWS, "CAND", "NOVA-V2") }
    fun legacy(type: LotteryType): List<PlanDefinition> = legacyCache.getOrPut(type) { build(type, CORE_ALGOS, CORE_WINDOWS, "LEGACY", "LEGACY") }

    /** 默认 UI/预测/回测池：每个玩法位置 30 个核心计划。 */
    fun all(type: LotteryType): List<PlanDefinition> = core(type)

    fun find(planId: String): PlanDefinition? = ALL_TYPES.firstOrNull { it.planId == planId }
        ?: LotteryType.entries.filter { it != LotteryType.OTHER }.asSequence().flatMap { candidates(it).asSequence() }.firstOrNull { it.planId == planId }
        ?: LotteryType.entries.filter { it != LotteryType.OTHER }.asSequence().flatMap { legacy(it).asSequence() }.firstOrNull { it.planId == planId }

    val ALL_TYPES: List<PlanDefinition> by lazy {
        LotteryType.entries.filter { it != LotteryType.OTHER }.flatMap { core(it) }
    }

    private fun build(
        type: LotteryType,
        algos: List<String>,
        windows: List<Int>,
        tier: String,
        idPrefix: String
    ): List<PlanDefinition> {
        val slots = slotsFor(type)
        val out = ArrayList<PlanDefinition>()
        slots.forEach { slot ->
            algos.forEachIndexed { ai, algo ->
                windows.forEachIndexed { wi, window ->
                    val idx = ai * windows.size + wi
                    // 核心池严格 30/玩法/位置；候选池可达 200/玩法/位置。
                    if (tier == "CORE" && idx >= 30) return@forEachIndexed
                    val id = "${idPrefix}-${type.name}-${slot.playType}-${slot.position}-${algo}-${window}-$tier"
                    val numberLike = slot.playType in NUMBER_PLAYS
                    val baseline = baseline(slot.playType, type)
                    out += PlanDefinition(
                        planId = id,
                        planName = buildName(slot, algo, window, tier),
                        category = "${type.name}-${slot.playType}",
                        algorithm = algo,
                        window = window,
                        cyclePeriods = 1,
                        playType = slot.playType,
                        positionIndex = slot.position,
                        outputFormat = if (numberLike) PlanOutputFormat.NUMBER_SCORES else PlanOutputFormat.DIRECTION,
                        hitCriteria = if (numberLike) PlanHitCriteria.TOP20_HIT else PlanHitCriteria.DIRECTION_MATCH,
                        baselineValue = baseline,
                        weightCap = if (tier == "CORE") 1.0 else 0.8,
                        participateConsensus = slot.playType in CONSENSUS_PLAYS,
                        participateCombo = slot.playType == "组合",
                        supportedTypes = setOf(type)
                    )
                }
            }
        }
        return out
    }

    private fun buildName(slot: Slot, algo: String, window: Int, tier: String): String {
        val pos = if (slot.position >= 0) "·${slot.label}" else ""
        return "${slot.playType}$pos·$algo·${window}期${if (tier == "CAND") "·候选" else ""}"
    }

    private fun slotsFor(type: LotteryType): List<Slot> = when (type) {
        LotteryType.PKS -> buildList {
            add(Slot("大小")); add(Slot("单双")); add(Slot("组合"))
            val labels = listOf("冠军","亚军","第3","第4","第5","第6","第7","第8","第9","第10")
            labels.forEachIndexed { i, label ->
                add(Slot("名次大小", i, label))
                add(Slot("名次单双", i, label))
                add(Slot("位置", i, label))
            }
        }
        LotteryType.YDH -> buildList {
            // 运动会：每个球的大小、单双、定位独立计算；龙虎按三组位置独立计算。
            val labels = (1..6).map { "第${it}球" }
            labels.forEachIndexed { i, label ->
                add(Slot("球大小", i, label)); add(Slot("球单双", i, label)); add(Slot("定位", i, label))
            }
            add(Slot("大小", 0, "第1球")); add(Slot("单双", 0, "第1球")); add(Slot("组合", 0, "第1球"))
            listOf("1vs6","2vs5","3vs4").forEachIndexed { i, label -> add(Slot("龙虎", i, label)) }
        }
        LotteryType.K3 -> buildList {
            add(Slot("大小")); add(Slot("单双")); add(Slot("组合")); add(Slot("和值"))
            val labels = listOf("第一位","第二位","第三位")
            labels.forEachIndexed { i, label ->
                add(Slot("位大小", i, label)); add(Slot("位单双", i, label)); add(Slot("定位", i, label))
            }
            add(Slot("三军")); add(Slot("鱼虾蟹")); add(Slot("二不同号")); add(Slot("二同号"));
            add(Slot("三不同号")); add(Slot("三连号")); add(Slot("三同号")); add(Slot("长牌"))
        }
        LotteryType.PC28 -> buildList {
            add(Slot("大小")); add(Slot("单双")); add(Slot("组合")); add(Slot("极值"));
            add(Slot("对子")); add(Slot("顺子")); add(Slot("豹子")); add(Slot("数字"))
            val labels = listOf("第一位","第二位","第三位")
            labels.forEachIndexed { i, label ->
                add(Slot("位大小", i, label)); add(Slot("位单双", i, label)); add(Slot("定位", i, label))
            }
        }
        LotteryType.LUCK20 -> listOf(Slot("大小"), Slot("单双"), Slot("组合"), Slot("数字"))
        LotteryType.OTHER -> emptyList()
    }

    private val NUMBER_PLAYS = setOf("数字", "位置", "定位", "三军", "鱼虾蟹", "二不同号", "二同号", "三不同号", "三连号", "三同号", "长牌", "和值")
    private val CONSENSUS_PLAYS = setOf("大小", "单双", "组合", "名次大小", "名次单双", "球大小", "球单双", "龙虎", "位大小", "位单双", "极值", "对子", "顺子", "豹子")

    private fun baseline(play: String, type: LotteryType): Double = when (play) {
        "组合" -> 0.25
        "数字", "定位", "位置", "三军", "鱼虾蟹", "二不同号", "二同号", "三不同号", "三连号", "三同号" -> 0.20
        "长牌" -> 0.15
        "和值" -> if (type == LotteryType.K3) 1.0 / 16.0 else 0.05
        else -> 0.50
    }
}
