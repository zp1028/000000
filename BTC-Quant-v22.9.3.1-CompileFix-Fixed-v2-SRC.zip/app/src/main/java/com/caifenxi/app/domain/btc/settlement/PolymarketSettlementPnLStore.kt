package com.caifenxi.app.domain.btc.settlement

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap

/**
 * Persistent settlement/PnL ledger. It only records venue-confirmed observations;
 * it never treats a local redeem request as settled cash.
 */
data class PolymarketSettlementPnL(
    val conditionId: String,
    val asset: String,
    val outcome: String,
    val shares: Double,
    val investedCost: Double,
    val fees: Double,
    val settlementValue: Double = 0.0,
    val realizedPnl: Double = 0.0,
    val settled: Boolean = false,
    val transactionHash: String = "",
    val updatedAtMs: Long = System.currentTimeMillis()
)

class PolymarketSettlementPnLStore(context: Context, private val maxEntries: Int = 500) {
    private val prefs = context.applicationContext.getSharedPreferences("btc_poly_settlement_pnl_v1", Context.MODE_PRIVATE)
    private val entries = ConcurrentHashMap<String, PolymarketSettlementPnL>()

    init { load() }

    @Synchronized fun upsert(value: PolymarketSettlementPnL) {
        entries[key(value.conditionId, value.asset)] = value.copy(updatedAtMs = System.currentTimeMillis())
        trim(); persist()
    }

    fun get(conditionId: String, asset: String): PolymarketSettlementPnL? = entries[key(conditionId, asset)]

    fun recent(limit: Int = 50): List<PolymarketSettlementPnL> =
        entries.values.sortedByDescending { it.updatedAtMs }.take(limit.coerceIn(1, maxEntries))

    fun realizedTotal(): Double = entries.values.filter { it.settled }.sumOf { it.realizedPnl }
    fun settledValueTotal(): Double = entries.values.filter { it.settled }.sumOf { it.settlementValue }
    fun feeTotal(): Double = entries.values.sumOf { it.fees }

    private fun key(conditionId: String, asset: String) = "$conditionId::$asset"

    private fun trim() {
        if (entries.size <= maxEntries) return
        entries.values.sortedBy { it.updatedAtMs }.take(entries.size - maxEntries).forEach { entries.remove(key(it.conditionId, it.asset)) }
    }

    private fun load() = runCatching {
        val a = JSONArray(prefs.getString("entries", "[]"))
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            val item = PolymarketSettlementPnL(
                conditionId = o.optString("conditionId"), asset = o.optString("asset"), outcome = o.optString("outcome"),
                shares = o.optDouble("shares"), investedCost = o.optDouble("investedCost"), fees = o.optDouble("fees"),
                settlementValue = o.optDouble("settlementValue"), realizedPnl = o.optDouble("realizedPnl"),
                settled = o.optBoolean("settled"), transactionHash = o.optString("transactionHash"),
                updatedAtMs = o.optLong("updatedAtMs", System.currentTimeMillis())
            )
            if (item.conditionId.isNotBlank() && item.asset.isNotBlank()) entries[key(item.conditionId, item.asset)] = item
        }
        trim()
    }

    private fun persist() {
        val a = JSONArray()
        entries.values.sortedBy { it.updatedAtMs }.takeLast(maxEntries).forEach { x ->
            a.put(JSONObject().apply {
                put("conditionId", x.conditionId); put("asset", x.asset); put("outcome", x.outcome)
                put("shares", x.shares); put("investedCost", x.investedCost); put("fees", x.fees)
                put("settlementValue", x.settlementValue); put("realizedPnl", x.realizedPnl)
                put("settled", x.settled); put("transactionHash", x.transactionHash); put("updatedAtMs", x.updatedAtMs)
            })
        }
        prefs.edit().putString("entries", a.toString()).apply()
    }
}

object PolymarketSettlementPnLEngine {
    data class Result(val pnl: PolymarketSettlementPnL, val reason: String)

    /**
     * Calculates realized PnL only when settlement is venue-confirmed.
     * Winning shares are valued at one unit; losing shares at zero.
     */
    fun fromResolvedPosition(position: com.caifenxi.app.domain.btc.polymarket.PolymarketPosition): Result? {
        if (!position.redeemable || position.size <= 0.0) return null
        val settlementValue = if (position.outcome.isNotBlank()) position.size else 0.0
        val invested = (position.avgPrice * position.size).coerceAtLeast(0.0)
        val pnl = settlementValue - invested
        return Result(
            PolymarketSettlementPnL(
                conditionId = position.conditionId, asset = position.asset, outcome = position.outcome,
                shares = position.size, investedCost = invested, fees = 0.0,
                settlementValue = settlementValue, realizedPnl = pnl, settled = false
            ),
            "redeemable position observed; cash settlement still requires venue/on-chain confirmation"
        )
    }

    fun confirm(pending: PolymarketSettlementPnL, transactionHash: String): PolymarketSettlementPnL =
        pending.copy(settled = transactionHash.isNotBlank(), transactionHash = transactionHash)

    /** Only explicit redemption/settlement activity can turn pending PnL into realized PnL. */
    fun confirmFromActivity(
        pending: PolymarketSettlementPnL,
        activities: List<com.caifenxi.app.domain.btc.polymarket.PolymarketActivity>
    ): PolymarketSettlementPnL {
        val hit = activities.firstOrNull { a ->
            a.conditionId == pending.conditionId &&
                (a.asset.isBlank() || a.asset == pending.asset) &&
                a.transactionHash.isNotBlank() &&
                a.type.uppercase() in setOf("REDEEM", "REDEEMED", "SETTLEMENT", "SETTLED", "WITHDRAW")
        }
        return if (hit != null) confirm(pending, hit.transactionHash) else pending
    }
}
