package com.caifenxi.app.domain.btc

import com.caifenxi.app.domain.btc.plan.DynamicWeightEngine
import com.caifenxi.app.domain.btc.plan.BtcPlanRegistry
import com.caifenxi.app.domain.btc.plan.BtcProbabilityCalibrator
import com.caifenxi.app.domain.btc.plan.BtcPlanLifecycleEngine
import com.caifenxi.app.domain.btc.factor.QuantFactorEngine
import com.caifenxi.app.domain.btc.plan.BtcPlanStatus
import com.caifenxi.app.domain.btc.strategy.RegimeFactorStrategyMatrix
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sqrt

/**
 * Rule plan pool → weighted consensus.
 * Optional [deriv] injects P3 funding/OI factors and dynamic weights.
 */
class BtcPlanEngine(
    private val registry: BtcPlanRegistry = BtcPlanRegistry()
) {

    fun evaluate(
        candles: List<BtcCandle>,
        deriv: DerivativesFeatures? = null,
        perf: Map<String, DynamicWeightEngine.PlanPerf> = emptyMap(),
        extraSignals: List<BtcPlanSignal> = emptyList(),
        weightOverrides: Map<String, Double> = emptyMap(),
        enabledPlanIds: Set<String>? = null,
        factorRuntimeWeights: Map<String, Double> = emptyMap(),
        strategyRuntimeWeights: Map<String, Double> = emptyMap()
    ): Pair<List<BtcPlanSignal>, BtcConsensus?> {
        if (candles.size < 80) return emptyList<BtcPlanSignal>() to null
        val close = candles.map { it.close }
        val ema9 = ema(close, 9)
        val ema21 = ema(close, 21)
        val ema50 = ema(close, 50)
        val rsi = rsi(close, 14)
        val macd = ema9.last() - ema21.last()
        val macdBase = max(abs(close.last()) * 0.0001, abs(ema21.last() - ema50.last()))
        val atrPct = atr(candles, 14) / close.last()
        val volRatio = candles.takeLast(20).map { it.volume }.average() /
            candles.dropLast(20).takeLast(80).map { it.volume }.average().coerceAtLeast(1e-9)
        val trendScore = clampSigned((ema9.last() - ema50.last()) / max(close.last() * 0.003, 1e-9))
        val momentumScore = clampSigned((rsi.last() - 50.0) / 18.0 + macd / macdBase * 0.35)
        val structureScore = structureScore(candles)
        val volumeScore = clampSigned((volRatio - 1.0) * 1.4 * trendScore)
        val volatilityScore = clampSigned((atrPct - 0.004) * 120.0 * trendScore)
        val derivativesScore = deriv?.derivativesScore ?: 0.0
        // Quant factor layer is now the common calculation substrate for every plan.
        // The legacy family scores remain as interpretable fallbacks, while factors
        // provide attribution and independent operator inputs to the pool.
        val factorSnapshot = QuantFactorEngine.calculate(candles, deriv, candles.lastOrNull()?.let { "BTCUSDT" } ?: "BTCUSDT")
        val factorTrend = factorSnapshot?.value("TREND-COMPOSITE") ?: trendScore
        val factorMomentum = factorSnapshot?.value("MOMENTUM-COMPOSITE") ?: momentumScore
        val factorStructure = factorSnapshot?.value("DONCHIAN-20") ?: structureScore
        val factorVolume = factorSnapshot?.value("VOLUME-CONFIRM") ?: volumeScore
        val factorVolatility = factorSnapshot?.value("VOLATILITY-REGIME") ?: volatilityScore
        val factorDeriv = factorSnapshot?.value("DERIVATIVES-COMPOSITE") ?: derivativesScore

        val regimeSnapshot = BtcRegimeEngine().detect(candles)
        val regime = regimeSnapshot?.regime ?: MarketRegime.RANGE

        val hierarchyMatrix = RegimeFactorStrategyMatrix()
        val factorQuality = factorSnapshot?.factors?.associate { it.id to abs(it.normalized).coerceIn(0.0, 1.0) }.orEmpty()
        val strategyQuality = registry.enabled().associate { d -> d.id to (perf[d.id]?.winRatePct?.div(100.0) ?: 0.5) }
        val strategyFactors = mapOf(
            "BTC-TURTLE" to listOf("DONCHIAN-20", "DIRECTIONAL-EFFICIENCY-20"),
            "BTC-EMA-TREND" to listOf("TREND-COMPOSITE", "EMA-SLOPE-21", "TREND-PERSISTENCE-30"),
            "BTC-MACD" to listOf("MOMENTUM-COMPOSITE", "RET-5", "RET-20"),
            "BTC-MTF-PULLBACK" to listOf("VWAP-DIST", "TREND-COMPOSITE", "RSI-14", "DIRECTIONAL-EFFICIENCY-20"),
            "BTC-RSI-RANGE" to listOf("PRICE-Z-30", "RSI-14", "RANGE-POSITION-20"),
            "BTC-BB-ATR" to listOf("DONCHIAN-20", "VOLATILITY-REGIME", "CANDLE-STRUCTURE-14", "VOLUME-CONFIRM"),
            "BTC-VWAP-VOLUME" to listOf("VWAP-DIST", "SIGNED-VOLUME-BIAS-20", "VOLUME-TREND-30", "VOLUME-CONFIRM"),
            "BTC-FUNDING-FADE" to listOf("FUNDING-BIAS", "OI-ALIGN", "VOLATILITY-REGIME", "RET-5")
        )
        val researchWeights = factorRuntimeWeights.mapValues { it.value.coerceIn(0.0, 1.0) }
        val effectiveFactorQuality = factorQuality.mapValues { (id, quality) ->
            quality * (researchWeights[id] ?: 1.0)
        }
        val hierarchy = hierarchyMatrix.allocate(regime, effectiveFactorQuality, strategyQuality, strategyFactors)

        val familyScores = mapOf(
            BtcPlanFamily.TREND to factorTrend,
            BtcPlanFamily.MOMENTUM to factorMomentum,
            BtcPlanFamily.STRUCTURE to factorStructure,
            BtcPlanFamily.VOLUME to factorVolume,
            BtcPlanFamily.VOLATILITY to factorVolatility,
            BtcPlanFamily.DERIVATIVES to factorDeriv,
            BtcPlanFamily.AI to 0.0
        )

        // Registry defines what exists; runtime pool config defines what is currently active.
        // This keeps the Strategy page controls connected to the actual consensus engine.
        val baseSignals = registry.enabled()
            .filter { enabledPlanIds == null || it.id in enabledPlanIds }
            .mapNotNull { definition ->
            val familyScore = familyScores[definition.family] ?: return@mapNotNull null
            if (definition.family == BtcPlanFamily.AI && familyScore == 0.0) return@mapNotNull null
            // Each plan now has its own formula. Family is an allocation bucket, not a duplicate signal.
            val score = planSpecificScore(definition.id, familyScore, factorSnapshot, trendScore, structureScore, researchWeights)
            val fit = regimeFit(definition.family, regime, score)
            val lifecycle = perf[definition.id]?.let { BtcPlanLifecycleEngine.evaluate(definition, it) }
            if (lifecycle?.status == BtcPlanStatus.RETIRED) return@mapNotNull null
            val lifecycleMultiplier = when (lifecycle?.status) {
                BtcPlanStatus.PROMOTED -> 1.10
                BtcPlanStatus.ACTIVE -> 1.00
                BtcPlanStatus.WATCH -> 0.80
                BtcPlanStatus.DOWNWEIGHT -> 0.55
                BtcPlanStatus.RETIRED -> 0.0
                null -> 1.00
            }
            val baseWeight = weightOverrides[definition.id]?.coerceIn(0.05, 5.0) ?: definition.baseWeight
            val hierarchyMax = hierarchy.strategyWeights.values.maxOrNull()?.coerceAtLeast(1e-9) ?: 1.0
            val hierarchyMultiplier = 0.85 + 0.30 * ((hierarchy.strategyWeights[definition.id] ?: 0.0) / hierarchyMax).coerceIn(0.0, 1.0)
            val strategyRuntimeMultiplier = (strategyRuntimeWeights[definition.id] ?: 1.0).coerceIn(0.0, 1.0)
            val effectiveBaseWeight = (if (definition.family == BtcPlanFamily.DERIVATIVES && deriv?.fundingExtreme == true) {
                baseWeight * 1.20
            } else baseWeight) * lifecycleMultiplier * hierarchyMultiplier * (0.65 + 0.35 * strategyRuntimeMultiplier)
            val direction = signedDirection(score)
            val confidence = clamp01(abs(score) * 0.85 + fit * 0.15)
            val contribution = score * confidence * effectiveBaseWeight * fit
            BtcPlanSignal(
                planId = definition.id,
                name = definition.name,
                family = definition.family,
                direction = direction,
                rawScore = score,
                confidence = confidence,
                weight = effectiveBaseWeight,
                hitRate = perf[definition.id]?.winRatePct?.div(100.0) ?: 0.5,
                samples = perf[definition.id]?.samples ?: candles.size,
                regimeFit = fit,
                contribution = contribution,
                factorScore = score,
                factorIds = factorSnapshot?.factors?.filter { abs(it.normalized - score) < 0.45 }?.take(5)?.map { it.id } ?: emptyList()
            )
        }

        val weightedSignals = DynamicWeightEngine.apply(baseSignals + extraSignals, regime, deriv, perf)
        val signals = BtcStrategyDiversifier.diversify(weightedSignals)
        val consensus = buildConsensus(signals, regime, trendScore, atrPct)
        return signals to consensus
    }

    private fun planSpecificScore(
        id: String, familyScore: Double, snapshot: QuantFactorEngine.Snapshot?, trend: Double, structure: Double,
        researchWeights: Map<String, Double> = emptyMap()
    ): Double {
        fun f(name: String, fallback: Double = 0.0): Double {
            val raw = snapshot?.value(name) ?: fallback
            return raw * (researchWeights[name] ?: 1.0).coerceIn(0.0, 1.0)
        }
        return when (id) {
            "BTC-TURTLE" -> clampSigned(f("DONCHIAN-20") * 0.65 + f("DIRECTIONAL-EFFICIENCY-20") * 0.35)
            "BTC-EMA-TREND" -> clampSigned(f("TREND-COMPOSITE") * 0.55 + f("EMA-SLOPE-21") * 0.20 + f("TREND-PERSISTENCE-30") * 0.25)
            "BTC-MACD" -> clampSigned(f("MOMENTUM-COMPOSITE") * 0.55 + f("RET-5") * 0.20 + f("RET-20") * 0.25)
            "BTC-MTF-PULLBACK" -> clampSigned(-f("VWAP-DIST") * 0.30 + f("TREND-COMPOSITE") * 0.35 + f("RSI-14") * 0.15 + f("DIRECTIONAL-EFFICIENCY-20") * 0.20)
            "BTC-RSI-RANGE" -> clampSigned(-f("PRICE-Z-30") * 0.45 + -f("RSI-14") * 0.30 + -f("RANGE-POSITION-20") * 0.25)
            "BTC-BB-ATR" -> clampSigned(f("DONCHIAN-20") * 0.45 + f("VOLATILITY-REGIME") * 0.20 + f("CANDLE-STRUCTURE-14") * 0.15 + f("VOLUME-CONFIRM") * 0.20)
            "BTC-VWAP-VOLUME" -> clampSigned(f("VWAP-DIST") * 0.35 + f("SIGNED-VOLUME-BIAS-20") * 0.35 + f("VOLUME-TREND-30") * 0.15 + f("VOLUME-CONFIRM") * 0.15)
            "BTC-FUNDING-FADE" -> clampSigned(-f("FUNDING-BIAS") * 0.55 + f("OI-ALIGN") * 0.20 + -f("VOLATILITY-REGIME") * 0.10 + f("RET-5") * 0.15)
            else -> familyScore
        }
    }

    private fun buildConsensus(
        signals: List<BtcPlanSignal>,
        regime: MarketRegime,
        trendScore: Double,
        atrPct: Double
    ): BtcConsensus {
        var up = 0.0
        var down = 0.0
        var flat = 0.0
        signals.forEach { s ->
            when (s.direction) {
                BtcDirection.UP -> up += abs(s.contribution)
                BtcDirection.DOWN -> down += abs(s.contribution)
                BtcDirection.FLAT -> flat += abs(s.contribution) * 0.5
            }
        }
        val total = (up + down + flat).coerceAtLeast(1e-9)
        val direction = when {
            up > down * 1.15 && up > flat -> BtcDirection.UP
            down > up * 1.15 && down > flat -> BtcDirection.DOWN
            else -> BtcDirection.FLAT
        }
        val strength = when (direction) {
            BtcDirection.UP -> up / total
            BtcDirection.DOWN -> down / total
            BtcDirection.FLAT -> flat / total
        }
        val probability = clamp01(0.5 + (strength - 0.33) * 0.9)
        val calibratedProbability = BtcProbabilityCalibrator.calibrate(probability, direction, signals)
        return BtcConsensus(
            direction = direction,
            probability = calibratedProbability,
            consensusStrength = strength,
            upScore = up / total,
            downScore = down / total,
            flatScore = flat / total,
            regime = regime,
            trendScore = trendScore,
            volatility = atrPct,
            expectedMovePct = atrPct * 100.0 * 1.6,
            riskScore = clamp01(atrPct / 0.02)
        )
    }

    private fun regimeFit(family: BtcPlanFamily, regime: MarketRegime, score: Double): Double {
        val base = when (regime) {
            MarketRegime.TREND_UP, MarketRegime.TREND_DOWN -> when (family) {
                BtcPlanFamily.TREND, BtcPlanFamily.STRUCTURE -> 1.0
                BtcPlanFamily.MOMENTUM -> 0.9
                BtcPlanFamily.DERIVATIVES -> 0.75
                else -> 0.8
            }
            MarketRegime.RANGE -> when (family) {
                BtcPlanFamily.MOMENTUM -> 1.0
                BtcPlanFamily.TREND -> 0.55
                BtcPlanFamily.DERIVATIVES -> 0.7
                else -> 0.75
            }
            MarketRegime.BREAKOUT, MarketRegime.HIGH_VOLATILITY -> when (family) {
                BtcPlanFamily.VOLATILITY, BtcPlanFamily.STRUCTURE -> 1.0
                BtcPlanFamily.DERIVATIVES -> 0.95
                else -> 0.85
            }
        }
        return clamp01(base * (0.65 + abs(score) * 0.35))
    }

    private fun structureScore(candles: List<BtcCandle>): Double {
        val win = candles.takeLast(8)
        val higherHigh = win.zipWithNext().count { it.second.high >= it.first.high }
        val higherLow = win.zipWithNext().count { it.second.low >= it.first.low }
        val lowerHigh = win.zipWithNext().count { it.second.high <= it.first.high }
        val lowerLow = win.zipWithNext().count { it.second.low <= it.first.low }
        val bull = (higherHigh + higherLow).toDouble() / (win.size * 2)
        val bear = (lowerHigh + lowerLow).toDouble() / (win.size * 2)
        return clampSigned((bull - bear) * 2.2)
    }

    private fun ema(values: List<Double>, period: Int): List<Double> {
        val k = 2.0 / (period + 1)
        val out = MutableList(values.size) { 0.0 }
        var prev = values.take(period).average()
        for (i in values.indices) {
            prev = if (i < period - 1) values.take(i + 1).average() else values[i] * k + prev * (1 - k)
            out[i] = prev
        }
        return out
    }

    private fun rsi(values: List<Double>, period: Int): List<Double> {
        val out = MutableList(values.size) { 50.0 }
        if (values.size <= period) return out
        var gain = 0.0
        var loss = 0.0
        for (i in 1..period) {
            val d = values[i] - values[i - 1]
            if (d >= 0) gain += d else loss -= d
        }
        gain /= period; loss /= period
        out[period] = if (loss == 0.0) 100.0 else 100 - 100 / (1 + gain / loss)
        for (i in period + 1 until values.size) {
            val d = values[i] - values[i - 1]
            val g = max(d, 0.0); val l = max(-d, 0.0)
            gain = (gain * (period - 1) + g) / period
            loss = (loss * (period - 1) + l) / period
            out[i] = if (loss == 0.0) 100.0 else 100 - 100 / (1 + gain / loss)
        }
        return out
    }

    private fun atr(c: List<BtcCandle>, period: Int): Double {
        val trs = c.zipWithNext().map { (p, x) ->
            max(x.high - x.low, max(abs(x.high - p.close), abs(x.low - p.close)))
        }
        return trs.takeLast(period).average()
    }

    private fun clampSigned(v: Double) = v.coerceIn(-1.0, 1.0)
}
