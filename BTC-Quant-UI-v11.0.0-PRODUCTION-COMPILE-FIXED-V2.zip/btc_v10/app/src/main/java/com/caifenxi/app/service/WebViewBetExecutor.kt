package com.caifenxi.app.service

import android.os.Handler
import android.os.Looper
import android.webkit.WebSettings
import android.webkit.WebView
import com.caifenxi.app.domain.execution.BetAction
import com.caifenxi.app.domain.execution.BetCommand
import com.caifenxi.app.domain.execution.ExecutionResult
import com.caifenxi.app.domain.execution.GenericSiteAdapter
import com.caifenxi.app.domain.execution.SiteAdapter
import com.caifenxi.app.util.RuntimeLog

/**
 * WebView DOM 执行器：注入通用评分脚本，识别真正的大小单双并点击。
 */
class WebViewBetExecutor {

    private val mainHandler = Handler(Looper.getMainLooper())

    @Volatile
    private var webView: WebView? = null

    @Volatile
    var siteAdapter: SiteAdapter = GenericSiteAdapter

    val isAvailable: Boolean
        get() = webView != null

    fun attachWebView(webView: WebView) {
        initWebView(webView)
    }

    fun initWebView(webView: WebView) {
        this.webView = webView
        mainHandler.post {
            try {
                val s = webView.settings
                s.javaScriptEnabled = true
                s.domStorageEnabled = true
                s.databaseEnabled = true
                s.useWideViewPort = true
                s.loadWithOverviewMode = true
                s.cacheMode = WebSettings.LOAD_DEFAULT
                s.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                val ua = s.userAgentString ?: ""
                if (!ua.contains("Chrome")) {
                    s.userAgentString =
                        "Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                }
                RuntimeLog.info("WebViewBet", "WebView 已挂载并开启 JS")
            } catch (e: Exception) {
                RuntimeLog.warn("WebViewBet", "initWebView: ${e.message}")
            }
        }
    }

    fun clearWebView() {
        webView = null
    }

    fun execute(command: BetCommand, onResult: (ExecutionResult) -> Unit): Boolean {
        val wv = webView
        if (wv == null) {
            onResult(
                ExecutionResult.fail(
                    command.cmdId,
                    ExecutionResult.WEBVIEW_DISCONNECTED,
                    "WebView 未连接，请先打开「内置网页挂机」并加载投注站"
                )
            )
            return false
        }
        if (command.isExpired) {
            onResult(
                ExecutionResult.fail(
                    command.cmdId,
                    ExecutionResult.COMMAND_EXPIRED,
                    "指令已过期"
                )
            )
            return false
        }
        val adapter = siteAdapter
        val js = try {
            adapter.buildInjectScript(command)
        } catch (e: Exception) {
            onResult(
                ExecutionResult.fail(
                    command.cmdId,
                    ExecutionResult.ACTION_FAILED,
                    "构建脚本失败: ${e.message}"
                )
            )
            return false
        }
        val start = System.currentTimeMillis()
        RuntimeLog.info(
            "WebViewBet",
            "执行 cmdId=${command.cmdId} issue=${command.issue} bets=${command.bets.size}"
        )
        val balJs = adapter.balanceSnapshotScript
        mainHandler.post {
            try {
                wv.evaluateJavascript(balJs) { beforeRaw ->
                    val before = unescapeJsResult(beforeRaw).trim().trim('"')
                    RuntimeLog.info("WebViewBet", "余额前=$before cmdId=${command.cmdId}")
                    wv.evaluateJavascript(js) { raw ->
                        val duration = System.currentTimeMillis() - start
                        val unquoted = unescapeJsResult(raw)
                        RuntimeLog.info("WebViewBet", "JS 回执 cmdId=${command.cmdId} raw=${unquoted.take(200)}")
                        val receipt = adapter.parseReceipt(unquoted)
                        wv.evaluateJavascript(balJs) { afterRaw ->
                            val after = unescapeJsResult(afterRaw).trim().trim('"')
                            val dryRun = command.options["dryRun"] == "1" || command.options["dryRun"] == "true"
                            val changed = before.isNotBlank() && after.isNotBlank() && before != after && after != "null" && before != "null"
                            com.caifenxi.app.domain.execution.ExecutionTicketStore.updateStatus(
                                command.cmdId,
                                if (receipt.isSuccess && changed) "SUCCESS" else if (receipt.isSuccess) "CLICKED" else "FAILED",
                                receipt.message,
                                balanceBefore = before,
                                balanceAfter = after
                            )
                            val result = when {
                                receipt.isSuccess && changed ->
                                    ExecutionResult.ok(
                                        command.cmdId,
                                        "点击成功且余额变动 $before→$after · ${receipt.message}",
                                        duration
                                    )
                                receipt.isSuccess && dryRun ->
                                    ExecutionResult.ok(
                                        command.cmdId,
                                        "[dryRun] 已识别点击，未校验余额 · ${receipt.message}",
                                        duration
                                    )
                                receipt.isSuccess && !changed ->
                                    ExecutionResult.fail(
                                        command.cmdId,
                                        ExecutionResult.VERIFY_FAILED,
                                        "已点击但余额未变(可能未成功或重复点) $before→$after · ${receipt.message}",
                                        duration
                                    )
                                receipt.isError ->
                                    ExecutionResult.fail(
                                        command.cmdId,
                                        ExecutionResult.ELEMENT_NOT_FOUND,
                                        receipt.message.ifBlank { "未找到可点控件" },
                                        duration
                                    )
                                else ->
                                    ExecutionResult.unknown(
                                        command.cmdId,
                                        receipt.message.ifBlank { "结果未知" }
                                    )
                            }
                            onResult(result)
                        }
                    }
                }
            } catch (e: Exception) {
                RuntimeLog.error("WebViewBet", "evaluateJavascript 异常: ${e.message}")
                onResult(
                    ExecutionResult.fail(
                        command.cmdId,
                        ExecutionResult.ACTION_FAILED,
                        "执行异常: ${e.message}",
                        System.currentTimeMillis() - start
                    )
                )
            }
        }
        return true
    }

    fun executeWebViewBet(
        dx: String?,
        ds: String?,
        amountText: String?,
        combo: String?,
        predNumbers: List<String> = emptyList(),
        onResult: ((ExecutionResult) -> Unit)? = null
    ): Boolean {
        val bets = buildList {
            if (dx == "大" || dx == "小") {
                add(BetAction(BetAction.CAT_DX, dx))
            }
            if (ds == "单" || ds == "双") {
                add(BetAction(BetAction.CAT_DS, ds))
            }
            if (combo != null) {
                add(BetAction(BetAction.CAT_COMBO, combo))
            }
            predNumbers.forEach {
                add(BetAction(BetAction.CAT_NUMBER, it))
            }
        }
        if (bets.isEmpty()) return false
        val cmd = BetCommand(
            cmdId = "legacy-${System.currentTimeMillis()}",
            lotteryKey = "",
            issue = "",
            bets = bets,
            amountText = amountText
        )
        return execute(cmd) { r -> onResult?.invoke(r) }
    }

    private fun unescapeJsResult(raw: String?): String {
        if (raw.isNullOrBlank() || raw == "null") return ""
        var s = raw.trim()
        if (s.startsWith("\"") && s.endsWith("\"")) {
            s = s.substring(1, s.length - 1)
                .replace("\\\"", "\"")
                .replace("\\\\", "\\")
                .replace("\\n", "\n")
        }
        return s
    }
}
