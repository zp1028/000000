package com.caifenxi.app.domain.btc.hs

import com.caifenxi.app.domain.btc.BtcCandle
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.sqrt

/**
 * 端侧 Logistic 概率模型（v2）
 *
 * 优化点：
 * 1. 标签与合约窗口对齐：预测未来 [horizonBars] 根后的涨跌，而非仅下一根
 * 2. 特征扩展：动量多尺度 + 波动 + 量能 + 微观结构代理
 * 3. 严格时间切分 holdout，不泄漏
 * 4. 简易分桶校准（isotonic 风格），抑制过度自信
 * 5. 按 barId 缓存，避免每次 refresh 全量重训
 * 6. 质量门槛：Brier / hitRate 不达标时输出向 0.5 收缩
 */
class BtcMlProbabilityModel(
    private val epochs: Int = 8,
    private val learningRate: Double = 0.03,
    private val l2: Double = 0.0012,
    private val horizonBars: Int = 1,
    private val config: HsRuntimeConfig = HsRuntimeConfig.Default
) {
    data class Result(
        val probability: Double,
        val samples: Int,
        val brierScore: Double,
        val hitRate: Double,
        val logLoss: Double = 0.693147,
        val modelVersion: String = "ML-LOGISTIC-2.0-HORIZON-CAL",
        val rawProbability: Double = 0.5,
        val cached: Boolean = false
    )

    private data class CacheKey(val lastOpenTime: Long, val size: Int, val horizon: Int)
    private data class CacheVal(val result: Result, val weights: DoubleArray, val bias: Double, val atMs: Long)
    private var cache: Pair<CacheKey, CacheVal>? = null

    fun fitAndPredict(candles: List<BtcCandle>): Result {
        if (candles.size < 60) return Result(0.5, 0, 0.25, 0.0)
        val last = candles.last()
        val key = CacheKey(last.openTime, candles.size, horizonBars)
        val now = System.currentTimeMillis()
        cache?.let { (k, v) ->
            if (k == key && now - v.atMs < config.mlCacheTtlMs) {
                return v.result.copy(cached = true)
            }
        }

        val h = horizonBars.coerceIn(1, 12)
        val rows = ArrayList<Pair<DoubleArray, Double>>(candles.size)
        for (i in 30 until candles.size - h) {
            val x = features(candles, i)
            // 合约窗口对齐：未来 h 根收盘相对当前收盘
            val y = if (candles[i + h].close >= candles[i].close) 1.0 else 0.0
            rows += x to y
        }
        if (rows.size < 25) return Result(0.5, rows.size, 0.25, 0.0)

        val split = (rows.size * 0.80).toInt().coerceIn(20, rows.size - 5)
        val train = rows.subList(0, split)
        val test = rows.subList(split, rows.size)
        val dim = rows.first().first.size
        val w = DoubleArray(dim)
        var b = 0.0
        repeat(epochs.coerceIn(2, 24)) {
            for ((x, y) in train) {
                val p = sigmoid(dot(w, x) + b)
                val err = p - y
                for (j in w.indices) w[j] -= learningRate * (err * x[j] + l2 * w[j])
                b -= learningRate * err
            }
        }

        val rawLatest = sigmoid(dot(w, features(candles, candles.lastIndex)) + b)
        val testPreds = test.map { (x, y) ->
            val p = sigmoid(dot(w, x) + b)
            Triple(p, y, (p >= 0.5) == (y >= 0.5))
        }
        val brier = testPreds.map { (p, y, _) -> (p - y) * (p - y) }.average()
        val hit = testPreds.count { it.third }.toDouble() / test.size
        val logLoss = testPreds.map { (p, y, _) ->
            val pp = p.coerceIn(1e-6, 1.0 - 1e-6)
            -(y * ln(pp) + (1.0 - y) * ln(1.0 - pp))
        }.average()

        // 分桶校准：用 holdout 的 (p,y) 做 8 桶均值映射
        val calibrated = bucketCalibrate(rawLatest, testPreds.map { it.first to it.second })

        // 质量门槛：差模型向 0.5 收缩
        var finalP = calibrated
        if (brier > config.maxBrierScore || hit < config.minModelHitRate) {
            val shrink = 0.45
            finalP = 0.5 + (calibrated - 0.5) * shrink
        }

        val result = Result(
            probability = finalP.coerceIn(0.03, 0.97),
            samples = train.size,
            brierScore = brier.coerceIn(0.0, 1.0),
            hitRate = hit.coerceIn(0.0, 1.0),
            logLoss = logLoss.coerceIn(0.0, 10.0),
            rawProbability = rawLatest.coerceIn(0.03, 0.97)
        )
        cache = key to CacheVal(result, w.copyOf(), b, now)
        return result
    }

    /** 按周期推荐预测视野：5m→1bar, 15m→1bar, 1h 仍 1bar；外部可构造不同 horizon 实例 */
    companion object {
        fun forTimeframe(tf: String, config: HsRuntimeConfig = HsRuntimeConfig.Default): BtcMlProbabilityModel {
            val h = when (tf) {
                "5m" -> 1   // 预测下一根 5m = 5 分钟窗口
                "15m" -> 1
                "1h" -> 1
                else -> 1
            }
            return BtcMlProbabilityModel(horizonBars = h, config = config)
        }
    }

    private fun bucketCalibrate(raw: Double, holdout: List<Pair<Double, Double>>): Double {
        if (holdout.size < 20) return 0.5 + (raw - 0.5) * 0.85
        val nBuckets = 8
        val buckets = Array(nBuckets) { mutableListOf<Double>() }
        holdout.forEach { (p, y) ->
            val idx = ((p * nBuckets).toInt()).coerceIn(0, nBuckets - 1)
            buckets[idx] += y
        }
        val means = buckets.map { b -> if (b.isEmpty()) Double.NaN else b.average() }
        val idx = ((raw * nBuckets).toInt()).coerceIn(0, nBuckets - 1)
        val empirical = means[idx]
        return if (empirical.isNaN()) {
            0.5 + (raw - 0.5) * 0.8
        } else {
            // 混合 raw 与经验频率，避免小样本过拟合
            val n = buckets[idx].size
            val blend = (n / 30.0).coerceIn(0.25, 0.75)
            (raw * (1.0 - blend) + empirical * blend).coerceIn(0.03, 0.97)
        }
    }

    private fun features(c: List<BtcCandle>, i: Int): DoubleArray {
        val cur = c[i]
        val p1 = c[i - 1].close
        val p3 = c[(i - 3).coerceAtLeast(0)].close
        val p5 = c[(i - 5).coerceAtLeast(0)].close
        val p10 = c[(i - 10).coerceAtLeast(0)].close
        val p20 = c[(i - 20).coerceAtLeast(0)].close
        val ema9 = ema(c, i, 9)
        val ema21 = ema(c, i, 21)
        val ema50 = ema(c, i, 50)
        val meanVol = c.subList((i - 19).coerceAtLeast(0), i + 1).map { it.volume }.average().coerceAtLeast(1e-9)
        val rsi = rsi(c, i, 14)
        val atr = atrPct(c, i, 14)
        val ret1 = ((cur.close / p1) - 1.0).coerceIn(-0.1, 0.1) * 10.0
        val ret5 = ((cur.close / p5) - 1.0).coerceIn(-0.2, 0.2) * 5.0
        val ret20 = ((cur.close / p20) - 1.0).coerceIn(-0.4, 0.4) * 2.5
        // 动量加速度
        val momAccel = (((cur.close / p3) - 1.0) - ((p3 / p10) - 1.0)).coerceIn(-0.15, 0.15) * 8.0
        // 收盘位置（在高低区间）
        val range = (cur.high - cur.low).coerceAtLeast(1e-9)
        val closePos = ((cur.close - cur.low) / range).coerceIn(0.0, 1.0) * 2.0 - 1.0
        return doubleArrayOf(
            ret1,
            ret5,
            ret20,
            ((ema9 / ema21) - 1.0).coerceIn(-0.1, 0.1) * 10.0,
            ((ema21 / ema50) - 1.0).coerceIn(-0.12, 0.12) * 8.0,
            ((rsi - 50.0) / 25.0).coerceIn(-2.0, 2.0),
            (atr / 0.01).coerceIn(0.0, 4.0),
            (cur.volume / meanVol - 1.0).coerceIn(-0.9, 3.0) / 2.0,
            ((cur.close - cur.open) / cur.close / 0.01).coerceIn(-3.0, 3.0),
            momAccel,
            closePos,
            // 波动突破：当前 range vs ATR
            ((range / cur.close) / atr.coerceAtLeast(1e-6) - 1.0).coerceIn(-1.5, 2.5) / 2.0
        )
    }

    private fun atrPct(c: List<BtcCandle>, i: Int, period: Int): Double {
        val start = (i - period + 1).coerceAtLeast(1)
        var sum = 0.0
        var n = 0
        for (j in start..i) {
            val tr = maxOf(
                c[j].high - c[j].low,
                kotlin.math.abs(c[j].high - c[j - 1].close),
                kotlin.math.abs(c[j].low - c[j - 1].close)
            )
            sum += tr / c[j].close
            n++
        }
        return if (n == 0) 0.01 else sum / n
    }

    private fun ema(c: List<BtcCandle>, i: Int, period: Int): Double {
        val start = (i - period * 2).coerceAtLeast(0)
        var e = c[start].close
        val k = 2.0 / (period + 1.0)
        for (j in start + 1..i) e = c[j].close * k + e * (1.0 - k)
        return e
    }

    private fun rsi(c: List<BtcCandle>, i: Int, period: Int): Double {
        val start = (i - period).coerceAtLeast(1)
        var gain = 0.0; var loss = 0.0
        for (j in start..i) {
            val d = c[j].close - c[j - 1].close
            if (d >= 0) gain += d else loss -= d
        }
        if (loss <= 1e-12) return 70.0
        return (100.0 - 100.0 / (1.0 + gain / loss)).coerceIn(0.0, 100.0)
    }

    private fun dot(w: DoubleArray, x: DoubleArray): Double {
        var s = 0.0
        val n = minOf(w.size, x.size)
        for (i in 0 until n) s += w[i] * x[i]
        return s
    }

    private fun sigmoid(z: Double): Double = 1.0 / (1.0 + exp(-z.coerceIn(-20.0, 20.0)))
}
