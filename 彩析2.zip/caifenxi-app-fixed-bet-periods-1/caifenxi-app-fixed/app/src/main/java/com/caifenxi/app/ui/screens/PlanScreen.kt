package com.caifenxi.app.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.caifenxi.app.domain.model.PlanDefinition
import com.caifenxi.app.domain.model.PlanPredictionRecord
import com.caifenxi.app.domain.model.PlanRuntime
import com.caifenxi.app.ui.MainViewModel
import com.caifenxi.app.ui.components.CaptionMuted
import com.caifenxi.app.ui.components.GlobalCard
import com.caifenxi.app.ui.components.PrimaryButton
import com.caifenxi.app.ui.theme.CaiTokens
import kotlin.math.roundToInt

private enum class PlanTab(val label: String) {
    CURRENT("本期计划"),
    CONSENSUS_STATS("共识战绩"),
    CONSENSUS_LOG("共识记录"),
    PLAN_STATS("计划战绩"),
    CUSTOM("自定义")
}

@Composable
fun PlanScreen(vm: MainViewModel) {
    val rows = vm.planRows.value
    val consensus = vm.consensus.value
    val pred = vm.prediction.value
    val allHist = vm.planHistory.value
    var tab by remember { mutableStateOf(PlanTab.CURRENT) }
    var expandedId by remember { mutableStateOf<String?>(null) }
    var consensusCat by remember { mutableStateOf("全部") }
    var showCustomEditor by remember { mutableStateOf(false) }
    var editingCustom by remember { mutableStateOf<com.caifenxi.app.domain.model.CustomPlan?>(null) }

    // 首次进入时加载自定义计划
    androidx.compose.runtime.LaunchedEffect(vm.currentLottery.value.key) {
        vm.loadCustomPlans()
    }

    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = CaiTokens.ScreenHPadding)
            .padding(top = CaiTokens.S16)
    ) {
        Text("计划大厅", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        CaptionMuted(pred?.let { "目标第 ${it.targetIssue} 期" } ?: "加载后显示本期计划")
        Spacer(Modifier.height(CaiTokens.S8))
        PrimaryButton(
            text = if (vm.backtestRunning.value) "生成/回测中…" else "重新随机生成并回测",
            onClick = { vm.runBacktest() },
            enabled = !vm.backtestRunning.value,
            modifier = Modifier.fillMaxWidth()
        )
        Row(
            Modifier
                .horizontalScroll(rememberScrollState())
                .padding(vertical = CaiTokens.S12),
            horizontalArrangement = Arrangement.spacedBy(CaiTokens.S8)
        ) {
            PlanTab.entries.forEach { t ->
                FilterChip(
                    selected = tab == t,
                    onClick = { tab = t },
                    label = { Text(t.label) }
                )
            }
        }

        LazyColumn(
            Modifier
                .fillMaxSize()
                .padding(bottom = CaiTokens.ScreenBottom),
            verticalArrangement = Arrangement.spacedBy(CaiTokens.S8)
        ) {
            when (tab) {
                PlanTab.CURRENT -> {
                    items(consensus) { c ->
                        GlobalCard {
                            Text("${c.category} 共识 → ${c.leadingDirection}", fontWeight = FontWeight.Bold)
                            Text("支持 ${(c.supportRatio * 100).roundToInt()}% · ${c.participatingPlans} 计划")
                        }
                    }
                    if (rows.isEmpty()) {
                        item { GlobalCard { Text("暂无计划，请先首页加载或点上方重新生成。") } }
                    } else {
                        items(rows, key = { it.first.planId }) { (def, rt) ->
                            val hist = allHist.filter { it.planId == def.planId }
                            val current = hist.filter { !it.settled }.ifEmpty {
                                hist.filter { it.targetIssue == pred?.targetIssue }
                            }
                            PlanCard(
                                def = def,
                                rt = rt,
                                currentPreds = current,
                                history = emptyList(), // 本期页不堆历史
                                expanded = expandedId == def.planId,
                                showHistory = false,
                                onToggle = {
                                    expandedId = if (expandedId == def.planId) null else def.planId
                                    if (expandedId == def.planId) vm.loadPlanDetail(def.planId)
                                }
                            )
                        }
                    }
                }
                PlanTab.CONSENSUS_STATS -> {
                    item {
                        val cs = vm.consensusStats.value
                        GlobalCard {
                            Text("共识对错率总览", fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(CaiTokens.S12))
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                                StatCell("已结算", "${cs.hit + cs.miss}")
                                StatCell("对", "${cs.hit}", Color(0xFF2E7D32))
                                StatCell("错", "${cs.miss}", Color(0xFFC62828))
                                StatCell(
                                    "对错率",
                                    if (cs.hit + cs.miss == 0) "-" else "${(cs.hitRate * 100).roundToInt()}%",
                                    MaterialTheme.colorScheme.secondary
                                )
                            }
                            if (cs.pending > 0) CaptionMuted("待开 ${cs.pending} 条")
                            Spacer(Modifier.height(CaiTokens.S8))
                            cs.byCategory.forEach { (cat, st) ->
                                val rate = if (st.hit + st.miss == 0) 0 else (st.hit * 100.0 / (st.hit + st.miss)).roundToInt()
                                Text("$cat：对 ${st.hit} / 错 ${st.miss} · 命中率 $rate%", fontWeight = FontWeight.SemiBold)
                                if (st.hit + st.miss > 0) {
                                    LinearProgressIndicator(
                                        progress = { (rate / 100f).coerceIn(0f, 1f) },
                                        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
                                        color = MaterialTheme.colorScheme.secondary
                                    )
                                }
                                val cur = when {
                                    st.recentStreak > 0 -> "当前连对 ${st.recentStreak}"
                                    st.recentStreak < 0 -> "当前连错 ${-st.recentStreak}"
                                    else -> "当前无连续"
                                }
                                CaptionMuted("$cur · 最长连对 ${st.maxHitStreak} · 最长连错 ${st.maxMissStreak}")
                                if (st.twoWindows > 0) {
                                    CaptionMuted(
                                        "两期对 ${(st.twoHitRate * 100).roundToInt()}% · 两期错 ${(st.twoMissRate * 100).roundToInt()}%（${st.twoWindows} 窗口）"
                                    )
                                }
                                if (st.threeWindows > 0) {
                                    CaptionMuted(
                                        "三期对 ${(st.threeHitRate * 100).roundToInt()}% · 三期错 ${(st.threeMissRate * 100).roundToInt()}%（${st.threeWindows} 窗口）"
                                    )
                                }
                                Spacer(Modifier.height(CaiTokens.S4))
                            }
                            Spacer(Modifier.height(CaiTokens.S8))
                            PrimaryButton("清空共识战绩", onClick = { vm.clearConsensusStats() }, ghost = true)
                        }
                    }
                    item {
                        val cs = vm.consensusStats.value
                        GlobalCard {
                            Text("共识连对连错 · 两期/三期对错率", fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(CaiTokens.S12))
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                                StatCell("最长连对", "${cs.maxHitStreak}", Color(0xFF2E7D32))
                                StatCell("最长连错", "${cs.maxMissStreak}", Color(0xFFC62828))
                                StatCell(
                                    "当前连续",
                                    when {
                                        cs.recentStreak > 0 -> "连对${cs.recentStreak}"
                                        cs.recentStreak < 0 -> "连错${-cs.recentStreak}"
                                        else -> "-"
                                    },
                                    if (cs.recentStreak >= 0) Color(0xFF2E7D32) else Color(0xFFC62828)
                                )
                            }
                            Spacer(Modifier.height(CaiTokens.S12))
                            ConsensusWindowRate(
                                title = "两期对错率",
                                hitRate = cs.twoHitRate,
                                missRate = cs.twoMissRate,
                                windows = cs.twoWindows
                            )
                            Spacer(Modifier.height(CaiTokens.S8))
                            ConsensusWindowRate(
                                title = "三期对错率",
                                hitRate = cs.threeHitRate,
                                missRate = cs.threeMissRate,
                                windows = cs.threeWindows
                            )
                            Spacer(Modifier.height(CaiTokens.S4))
                            CaptionMuted("口径：以连续两期为一个窗口，窗口内对一次及以上记「两期对」，两期全错记「两期错」；三期同理。本卡片为全部分类合计，各分类独立明细见上方总览。")
                        }
                    }
                }
                PlanTab.CONSENSUS_LOG -> {
                    val all = vm.consensusRecords.value
                    val cats = listOf("全部") + all.map { it.category }.distinct().sorted()
                    val filtered = all.filter {
                        consensusCat == "全部" || it.category == consensusCat
                    }
                    item {
                        CaptionMuted("共 ${filtered.size} / ${all.size} 条")
                        Row(
                            Modifier.horizontalScroll(rememberScrollState()).padding(vertical = CaiTokens.S8),
                            horizontalArrangement = Arrangement.spacedBy(CaiTokens.S8)
                        ) {
                            cats.forEach { cat ->
                                FilterChip(
                                    selected = consensusCat == cat,
                                    onClick = { consensusCat = cat },
                                    label = { Text(cat) }
                                )
                            }
                        }
                    }
                    if (filtered.isEmpty()) {
                        item { GlobalCard { Text("暂无共识记录") } }
                    } else {
                        items(filtered.take(60), key = { it.id }) { r ->
                            val color = when (r.result) {
                                "对" -> Color(0xFF2E7D32)
                                "错" -> Color(0xFFC62828)
                                else -> Color(0xFFF9A825)
                            }
                            GlobalCard {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Column(Modifier.weight(1f)) {
                                        Text("第 ${r.targetIssue} 期 · ${r.category}", fontWeight = FontWeight.Bold)
                                        Text(
                                            "共识「${r.leadingDirection}」" +
                                                (r.actual?.let { " → 开奖「$it」" } ?: " · 待开奖")
                                        )
                                        CaptionMuted(
                                            "支持度 ${(r.supportRatio * 100).roundToInt()}% · ${r.participatingPlans} 计划"
                                        )
                                    }
                                    Text(r.result, fontWeight = FontWeight.Bold, color = color)
                                }
                            }
                        }
                    }
                }
                PlanTab.PLAN_STATS -> {
                    item {
                        CaptionMuted("各计划累计成功率 · 点开可看历史预测")
                    }
                    if (rows.isEmpty()) {
                        item { GlobalCard { Text("暂无计划数据") } }
                    } else {
                        items(rows, key = { "s-" + it.first.planId }) { (def, rt) ->
                            val hist = allHist.filter { it.planId == def.planId && it.settled }.take(20)
                            PlanCard(
                                def = def,
                                rt = rt,
                                currentPreds = emptyList(),
                                history = hist,
                                expanded = expandedId == "s-" + def.planId,
                                showHistory = true,
                                onToggle = {
                                    val id = "s-" + def.planId
                                    expandedId = if (expandedId == id) null else id
                                    if (expandedId == id) vm.loadPlanDetail(def.planId)
                                }
                            )
                        }
                    }
                }
                PlanTab.CUSTOM -> {
                    item {
                        GlobalCard {
                            Text("自定义计划", fontWeight = FontWeight.Bold)
                            CaptionMuted("按自己的类别/算法/窗口组合规则,参与本期预测与共识;保存后下次回测自动纳入。")
                            Spacer(Modifier.height(CaiTokens.S8))
                            PrimaryButton(
                                text = "新建计划",
                                onClick = {
                                    editingCustom = null
                                    showCustomEditor = true
                                },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                    val customs = vm.customPlans.value
                    if (customs.isEmpty()) {
                        item { GlobalCard { Text("暂无自定义计划,点上方「新建计划」添加。") } }
                    } else {
                        items(customs, key = { it.planId }) { cp ->
                            GlobalCard {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Column(Modifier.weight(1f)) {
                                        Text(cp.planName, fontWeight = FontWeight.Bold)
                                        CaptionMuted(
                                            "${cp.category} · ${cp.algorithm} · 窗${cp.window}" +
                                                if (cp.participateConsensus) " · 参与共识" else " · 不参与共识"
                                        )
                                    }
                                    Text(
                                        if (cp.enabled) "启用" else "停用",
                                        fontWeight = FontWeight.Bold,
                                        color = if (cp.enabled) Color(0xFF2E7D32) else Color(0xFFC62828)
                                    )
                                }
                                Row(
                                    Modifier.padding(top = CaiTokens.S8),
                                    horizontalArrangement = Arrangement.spacedBy(CaiTokens.S8)
                                ) {
                                    androidx.compose.material3.TextButton(onClick = {
                                        editingCustom = cp
                                        showCustomEditor = true
                                    }) { Text("编辑") }
                                    androidx.compose.material3.TextButton(onClick = {
                                        vm.toggleCustomPlan(cp, !cp.enabled)
                                    }) { Text(if (cp.enabled) "停用" else "启用") }
                                    androidx.compose.material3.TextButton(onClick = { vm.deleteCustomPlan(cp.planId) }) {
                                        Text("删除", color = Color(0xFFC62828))
                                    }
                                }
                            }
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(CaiTokens.S24)) }
        }

        if (showCustomEditor) {
            CustomPlanEditor(
                vm = vm,
                initial = editingCustom,
                onDismiss = { showCustomEditor = false },
                onSave = { plan ->
                    vm.saveCustomPlan(plan)
                    showCustomEditor = false
                }
            )
        }
    }
}

@Composable
private fun CustomPlanEditor(
    vm: MainViewModel,
    initial: com.caifenxi.app.domain.model.CustomPlan?,
    onDismiss: () -> Unit,
    onSave: (com.caifenxi.app.domain.model.CustomPlan) -> Unit
) {
    val lotteryKey = vm.currentLottery.value.key
    var name by remember { mutableStateOf(initial?.planName ?: "") }
    var category by remember { mutableStateOf(initial?.category ?: "大小") }
    var algorithm by remember { mutableStateOf(initial?.algorithm ?: "FREQ") }
    var window by remember { mutableStateOf((initial?.window ?: 30).toString()) }
    var consensusOn by remember { mutableStateOf(initial?.participateConsensus ?: true) }
    val categories = listOf("大小", "单双", "组合", "号码", "位置-冠军", "位置-亚军", "位置-第3")
    val algorithms = listOf("FREQ", "EWMA", "MKV1", "MSF")

    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "新建计划" else "编辑计划") },
        text = {
            Column {
                androidx.compose.material3.OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("计划名称") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(CaiTokens.S8))
                Text("类别", style = MaterialTheme.typography.labelMedium)
                Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = CaiTokens.S4)) {
                    categories.forEach { c ->
                        FilterChip(
                            selected = category == c,
                            onClick = { category = c },
                            label = { Text(c) },
                            modifier = Modifier.padding(end = CaiTokens.S4)
                        )
                    }
                }
                Spacer(Modifier.height(CaiTokens.S8))
                Text("算法", style = MaterialTheme.typography.labelMedium)
                Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = CaiTokens.S4)) {
                    algorithms.forEach { a ->
                        FilterChip(
                            selected = algorithm == a,
                            onClick = { algorithm = a },
                            label = { Text(a) },
                            modifier = Modifier.padding(end = CaiTokens.S4)
                        )
                    }
                }
                Spacer(Modifier.height(CaiTokens.S8))
                androidx.compose.material3.OutlinedTextField(
                    value = window,
                    onValueChange = { window = it.filter { ch -> ch.isDigit() }.take(4) },
                    label = { Text("窗口期数(≥5)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Spacer(Modifier.height(CaiTokens.S4))
                Row(Modifier.fillMaxWidth(), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Text("参与共识", modifier = Modifier.weight(1f))
                    androidx.compose.material3.Switch(
                        checked = consensusOn,
                        onCheckedChange = { consensusOn = it }
                    )
                }
            }
        },
        confirmButton = {
            androidx.compose.material3.TextButton(
                enabled = name.isNotBlank() && (window.toIntOrNull() ?: 0) >= 5,
                onClick = {
                    val win = (window.toIntOrNull() ?: 30).coerceAtLeast(5)
                    val now = System.currentTimeMillis()
                    val plan = initial?.copy(
                        planName = name.trim(),
                        category = category,
                        algorithm = algorithm,
                        window = win,
                        participateConsensus = consensusOn,
                        updatedAt = now
                    ) ?: com.caifenxi.app.domain.model.CustomPlan(
                        planId = com.caifenxi.app.domain.model.CustomPlan.ID_PREFIX +
                            lotteryKey + "-" + now.toString(16),
                        lotteryKey = lotteryKey,
                        planName = name.trim(),
                        category = category,
                        algorithm = algorithm,
                        window = win,
                        participateConsensus = consensusOn
                    )
                    onSave(plan)
                }
            ) { Text("保存") }
        },
        dismissButton = {
            androidx.compose.material3.TextButton(onClick = onDismiss) { Text("取消") }
        }
    )
}

@Composable
private fun StatCell(label: String, value: String, color: Color = Color.Unspecified) {
    Column(horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally) {
        Text(
            value,
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.titleMedium,
            color = if (color == Color.Unspecified) MaterialTheme.colorScheme.onSurface else color
        )
        CaptionMuted(label)
    }
}

@Composable
private fun ConsensusWindowRate(title: String, hitRate: Double, missRate: Double, windows: Int) {
    Column(Modifier.padding(vertical = 4.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text("样本窗口 $windows 个")
        }
        Spacer(Modifier.height(CaiTokens.S4))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("窗口内至少对 1 次", color = Color(0xFF2E7D32), fontSize = 13.sp)
            Text(
                if (windows > 0) "${(hitRate * 100).roundToInt()}%" else "-",
                fontWeight = FontWeight.Bold,
                color = Color(0xFF2E7D32),
                fontSize = 13.sp
            )
        }
        LinearProgressIndicator(
            progress = { hitRate.toFloat().coerceIn(0f, 1f) },
            modifier = Modifier.fillMaxWidth(),
            color = Color(0xFF2E7D32)
        )
        Spacer(Modifier.height(CaiTokens.S4))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("窗口内全错", color = Color(0xFFC62828), fontSize = 13.sp)
            Text(
                if (windows > 0) "${(missRate * 100).roundToInt()}%" else "-",
                fontWeight = FontWeight.Bold,
                color = Color(0xFFC62828),
                fontSize = 13.sp
            )
        }
        LinearProgressIndicator(
            progress = { missRate.toFloat().coerceIn(0f, 1f) },
            modifier = Modifier.fillMaxWidth(),
            color = Color(0xFFC62828)
        )
    }
}

@Composable
private fun PlanCard(
    def: PlanDefinition,
    rt: PlanRuntime,
    currentPreds: List<PlanPredictionRecord>,
    history: List<PlanPredictionRecord>,
    expanded: Boolean,
    showHistory: Boolean,
    onToggle: () -> Unit
) {
    GlobalCard(onClick = onToggle) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column(Modifier.weight(1f)) {
                Text(def.planName, fontWeight = FontWeight.Bold)
                CaptionMuted("${def.category} · ${def.algorithm} · 窗${def.window}")
                val curOut = currentPreds.firstOrNull()?.output ?: rt.lastPrediction
                if (curOut != null && !showHistory) {
                    Text(
                        "当期：${curOut}" + (currentPreds.firstOrNull()?.targetIssue?.let { " → 第${it}期" } ?: ""),
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.secondary
                    )
                }
            }
            Column(horizontalAlignment = androidx.compose.ui.Alignment.End) {
                Text(rt.hitRatePercent, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
                CaptionMuted(if (expanded) "收起" else "详情")
            }
        }
        if (rt.sampleCount > 0) {
            LinearProgressIndicator(
                progress = { rt.hitRate.toFloat().coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth().padding(top = CaiTokens.S4),
                color = MaterialTheme.colorScheme.secondary
            )
        }
        AnimatedVisibility(visible = expanded) {
            Column(Modifier.padding(top = CaiTokens.S12)) {
                DetailLine("ID", def.planId)
                DetailLine("参数", "${def.category}/${def.algorithm}/窗${def.window}")
                DetailLine("战绩", "对 ${rt.hitCount}/${rt.sampleCount} · ${rt.hitRatePercent}")
                if (!showHistory) {
                    Text("当期预测", fontWeight = FontWeight.SemiBold)
                    val cur = currentPreds.ifEmpty {
                        rt.lastPrediction?.let {
                            listOf(
                                PlanPredictionRecord(
                                    planId = def.planId, lotteryKey = "",
                                    targetIssue = rt.lastTargetIssue ?: "-", cutoffIssue = "-",
                                    output = it, scoreAtPredict = rt.score, weightAtPredict = rt.weight,
                                    planName = def.planName, category = def.category
                                )
                            )
                        } ?: emptyList()
                    }
                    if (cur.isEmpty()) CaptionMuted("暂无")
                    else cur.forEach { rec ->
                        Text("第${rec.targetIssue}期 → ${rec.output}", fontWeight = FontWeight.Medium)
                    }
                }
                if (showHistory) {
                    Text("历史预测与结果", fontWeight = FontWeight.SemiBold)
                    if (history.isEmpty()) CaptionMuted("尚无已结算历史")
                    else history.forEach { rec ->
                        val tag = when (rec.hit) { true -> "对"; false -> "错"; null -> "—" }
                        val color = when (rec.hit) {
                            true -> Color(0xFF2E7D32)
                            false -> Color(0xFFC62828)
                            null -> MaterialTheme.colorScheme.onSurfaceVariant
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("第${rec.targetIssue}期 「${rec.output}」")
                            Text(tag, fontWeight = FontWeight.Bold, color = color)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DetailLine(k: String, v: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(k, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(v, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
    }
}
