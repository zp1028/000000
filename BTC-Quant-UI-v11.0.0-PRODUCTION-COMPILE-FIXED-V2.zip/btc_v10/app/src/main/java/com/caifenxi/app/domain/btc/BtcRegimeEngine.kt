package com.caifenxi.app.domain.btc

import kotlin.math.abs
import kotlin.math.max

/** Market regime classifier kept independent from the plan engine for reuse by UI/backtest/runtime. */
class BtcRegimeEngine {
    data class Snapshot(
        val regime: MarketRegime,
        val trendScore: Double,
        val volatilityPct: Double,
        val volumeRatio: Double
    )

    fun detect(candles: List<BtcCandle>): Snapshot? {
        if (candles.size < 60) return null
        val closes = candles.map { it.close }
        val emaFast = ema(closes, 9)
        val emaSlow = ema(closes, 50)
        val last = closes.last().coerceAtLeast(1e-9)
        val trend = ((emaFast.last() - emaSlow.last()) / (last * 0.003)).coerceIn(-1.0, 1.0)
        val atrPct = atr(candles, 14) / last
        val recentVolume = candles.takeLast(20).map { it.volume }.average()
        val baselineVolume = candles.dropLast(20).takeLast(80).map { it.volume }.average().coerceAtLeast(1e-9)
        val vr = recentVolume / baselineVolume
        val structure = structure(candles)
        val regime = when {
            atrPct >= 0.012 -> MarketRegime.HIGH_VOLATILITY
            abs(structure) >= 0.70 && vr >= 1.25 -> MarketRegime.BREAKOUT
            abs(trend) >= 0.65 -> if (trend > 0) MarketRegime.TREND_UP else MarketRegime.TREND_DOWN
            else -> MarketRegime.RANGE
        }
        return Snapshot(regime, trend, atrPct, vr)
    }

    private fun structure(c: List<BtcCandle>): Double {
        val w = c.takeLast(8)
        var bull = 0
        var bear = 0
        w.zipWithNext().forEach { (a, b) ->
            if (b.high >= a.high) bull++
            if (b.low >= a.low) bull++
            if (b.high <= a.high) bear++
            if (b.low <= a.low) bear++
        }
        return ((bull - bear).toDouble() / max(1, (w.size - 1) * 2) * 2.2).coerceIn(-1.0, 1.0)
    }

    private fun ema(values: List<Double>, period: Int): List<Double> {
        val k = 2.0 / (period + 1)
        var prev = values.take(period).average()
        return values.mapIndexed { i, v ->
            if (i >= period - 1) prev = v * k + prev * (1 - k)
            prev
        }
    }

    private fun atr(c: List<BtcCandle>, period: Int): Double = c.zipWithNext()
        .map { (p, x) -> max(x.high - x.low, max(abs(x.high - p.close), abs(x.low - p.close))) }
        .takeLast(period).average()
}
