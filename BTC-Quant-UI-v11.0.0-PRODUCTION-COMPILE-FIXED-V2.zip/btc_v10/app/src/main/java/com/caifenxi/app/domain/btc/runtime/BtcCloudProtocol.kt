package com.caifenxi.app.domain.btc.runtime

import kotlinx.serialization.Serializable

/** Cloud-ready control plane contract. It carries control/state, never exchange secrets. */
@Serializable
data class BtcHeartbeat(
    val nodeId: String,
    val status: String,
    val symbol: String,
    val timeframe: String,
    val lastBarId: Long,
    val lastHeartbeatAt: Long,
    val killSwitch: Boolean
)

@Serializable
data class BtcRemoteCommand(
    val commandId: String,
    val action: String,
    val issuedAt: Long,
    val expiresAt: Long,
    val reason: String? = null
)

interface BtcControlPlane {
    suspend fun heartbeat(heartbeat: BtcHeartbeat)
    suspend fun pullCommands(nodeId: String): List<BtcRemoteCommand>
    suspend fun ack(commandId: String, success: Boolean, message: String? = null)
}

object NoopBtcControlPlane : BtcControlPlane {
    override suspend fun heartbeat(heartbeat: BtcHeartbeat) = Unit
    override suspend fun pullCommands(nodeId: String): List<BtcRemoteCommand> = emptyList()
    override suspend fun ack(commandId: String, success: Boolean, message: String?) = Unit
}
