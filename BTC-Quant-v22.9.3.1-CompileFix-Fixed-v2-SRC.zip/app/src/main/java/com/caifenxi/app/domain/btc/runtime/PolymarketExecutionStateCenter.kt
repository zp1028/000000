package com.caifenxi.app.domain.btc.runtime

import com.caifenxi.app.domain.btc.broker.PolymarketClobBroker
import com.caifenxi.app.domain.btc.broker.PolymarketPrivateOrder
import com.caifenxi.app.domain.btc.broker.PolymarketPrivateTrade

/**
 * Single source of truth for the local execution lifecycle of Polymarket orders.
 * REST is authoritative; websocket events are treated as acceleration only.
 */
class PolymarketExecutionStateCenter(
    private val store: PolymarketOrderLifecycleStore
) {
    fun recordSubmitted(
        executionId: String,
        decisionId: String,
        orderId: String,
        marketId: String,
        outcome: String,
        price: Double,
        size: Double
    ) {
        store.upsert(
            PolymarketOrderLifecycle(
                executionId = executionId,
                decisionId = decisionId,
                orderId = orderId,
                marketId = marketId,
                outcome = outcome,
                requestedPrice = price,
                requestedSize = size,
                stage = PolymarketOrderStage.OPEN,
                remainingSize = size,
                lastMessage = "venue accepted order"
            )
        )
    }

    fun recordRejected(executionId: String, decisionId: String, orderId: String, marketId: String, outcome: String, price: Double, size: Double, message: String) {
        store.upsert(PolymarketOrderLifecycle(executionId, decisionId, orderId, marketId, outcome, price, size, PolymarketOrderStage.REJECTED, lastMessage = message))
    }

    fun recordIndeterminate(executionId: String, decisionId: String, orderId: String, marketId: String, outcome: String, price: Double, size: Double, message: String) {
        store.upsert(PolymarketOrderLifecycle(executionId, decisionId, orderId.ifBlank { executionId }, marketId, outcome, price, size, PolymarketOrderStage.ERROR, remainingSize = size, lastMessage = "INDETERMINATE: $message"))
    }

    fun reconcile(orders: List<PolymarketPrivateOrder>, trades: List<PolymarketPrivateTrade>) {
        store.recent(300).forEach { local ->
            if (local.orderId.isBlank()) return@forEach
            val remote = orders.firstOrNull { it.id.equals(local.orderId, ignoreCase = true) }
            val orderTrades = trades.filter {
                it.orderId.equals(local.orderId, ignoreCase = true) ||
                    it.id.equals(local.orderId, ignoreCase = true)
            }
            val matched = remote?.matchedSize ?: orderTrades.sumOf { it.size }
            val grossCost = orderTrades.sumOf { it.size.coerceAtLeast(0.0) * it.price.coerceAtLeast(0.0) }
            val fees = orderTrades.sumOf { it.fee.coerceAtLeast(0.0) }
            val avgFill = if (matched > 0.0) grossCost / matched else local.avgFillPrice
            val netCost = grossCost + fees
            val requested = local.requestedSize.coerceAtLeast(0.0)
            // Local requestedSize is quote/notional in our execution layer. The venue order store
            // is normalized to shares, so only use remote matched state for lifecycle transitions.
            val stage = when {
                remote == null && matched > 0.0 -> PolymarketOrderStage.FILLED
                remote == null && local.stage == PolymarketOrderStage.ERROR -> PolymarketOrderStage.UNKNOWN
                remote == null -> PolymarketOrderStage.UNKNOWN
                remote.status.contains("CANCEL", true) -> PolymarketOrderStage.CANCELED
                remote.status.contains("REJECT", true) -> PolymarketOrderStage.REJECTED
                remote.status.contains("EXPIRE", true) -> PolymarketOrderStage.EXPIRED
                remote.matchedSize > 0.0 && remote.originalSize > 0.0 && remote.matchedSize + 1e-9 >= remote.originalSize -> PolymarketOrderStage.FILLED
                remote.matchedSize > 0.0 -> PolymarketOrderStage.PARTIAL
                remote.status.contains("LIVE", true) || remote.status.contains("OPEN", true) -> PolymarketOrderStage.OPEN
                else -> PolymarketOrderStage.UNKNOWN
            }
            val remaining = if (remote != null && remote.originalSize > 0.0) {
                (remote.originalSize - remote.matchedSize).coerceAtLeast(0.0)
            } else local.remainingSize
            store.upsert(local.copy(
                stage = stage,
                filledSize = matched,
                remainingSize = remaining,
                avgFillPrice = avgFill,
                grossFillCost = if (grossCost > 0.0) grossCost else local.grossFillCost,
                fees = if (fees > 0.0) fees else local.fees,
                netFillCost = if (netCost > 0.0) netCost else local.netFillCost,
                lastMessage = "reconciled from REST trades/orders",
                updatedAt = System.currentTimeMillis()
            ))
        }
    }

    suspend fun reconcileLive(broker: PolymarketClobBroker) {
        val orders = broker.listPrivateOrders().getOrDefault(emptyList())
        val trades = broker.listPrivateTrades().getOrDefault(emptyList())
        reconcile(orders, trades)
    }
}
