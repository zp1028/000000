package com.caifenxi.app.domain.engine

import com.caifenxi.app.domain.model.PlanPredictionRecord
import com.caifenxi.app.domain.model.PlanRuntime
import kotlin.math.abs

/**
 * 数据异常检测：用于排查「胜率长期固定」「样本不增长」「全计划同结果」等问题。
 * 纯函数，不依赖 UI / 数据库。
 */
object DataAnomalyDetector {

    data class Anomaly(
        val code: String,
        val severity: Severity,
        val message: String
    )

    enum class Severity { INFO, WARN, CRITICAL }

    data class Report(
        val anomalies: List<Anomaly>,
        val checkedAt: Long = System.currentTimeMillis()
    ) {
        val hasCritical: Boolean get() = anomalies.any { it.severity == Severity.CRITICAL }
        val hasWarn: Boolean get() = anomalies.any { it.severity == Severity.WARN }
        val isClean: Boolean get() = anomalies.isEmpty()
    }

    /**
     * @param settledPreds 已结算预测（建议按时间/期号排序）
     * @param runtimes 计划运行时
     * @param stuckWindow 连续多少期指标不变视为异常
     */
    fun scan(
        settledPreds: List<PlanPredictionRecord>,
        runtimes: List<PlanRuntime>,
        stuckWindow: Int = 20
    ): Report {
        val out = mutableListOf<Anomaly>()
        if (settledPreds.isEmpty() && runtimes.isEmpty()) {
            return Report(emptyList())
        }

        // 1) 胜率长期固定：多计划 hitRate 完全相同且样本>0
        val rates = runtimes.filter { it.sampleCount >= stuckWindow }
            .map { "%.4f".format(it.hitRate) }
        if (rates.size >= 5) {
            val dominant = rates.groupingBy { it }.eachCount().maxByOrNull { it.value }
            if (dominant != null && dominant.value >= rates.size * 0.8) {
                out += Anomaly(
                    "HIT_RATE_STUCK",
                    Severity.CRITICAL,
                    "⚠ 数据异常：约 ${dominant.value}/${rates.size} 个计划胜率长期固定为 ${"%.1f".format(dominant.key.toDoubleOrNull()?.times(100) ?: 0.0)}%"
                )
            }
        }

        // 2) 样本数量不增长：存在 sampleCount>0 但最近 settled 窗口内该计划无新记录
        val recentIssues = settledPreds.map { it.targetIssue }.distinct().takeLast(stuckWindow).toSet()
        if (recentIssues.size >= stuckWindow / 2) {
            val activeIds = settledPreds.filter { it.targetIssue in recentIssues }.map { it.planId }.toSet()
            val stagnant = runtimes.filter { it.sampleCount >= 10 && it.planId !in activeIds }
            if (stagnant.size >= 3) {
                out += Anomaly(
                    "SAMPLE_STALE",
                    Severity.WARN,
                    "⚠ 数据异常：${stagnant.size} 个计划样本数疑似未随新期增长（近期 ${recentIssues.size} 期内无新结算）"
                )
            }
        }

        // 3) 所有计划同一期完全相同输出
        settledPreds.groupBy { it.targetIssue }.forEach { (issue, list) ->
            if (list.size >= 8) {
                val outs = list.map { it.output }.distinct()
                if (outs.size == 1) {
                    out += Anomaly(
                        "IDENTICAL_OUTPUT",
                        Severity.WARN,
                        "⚠ 数据异常：第 $issue 期全部 ${list.size} 个计划输出完全相同（${outs.first()}）"
                    )
                }
            }
        }

        // 4) 两期/三期率若能从 streak 推，这里用连错极端：多个计划 maxConsecutiveMiss 异常同步
        val missCaps = runtimes.filter { it.sampleCount >= stuckWindow }.map { it.maxConsecutiveMiss }
        if (missCaps.size >= 5 && missCaps.distinct().size == 1 && missCaps.first() > 0) {
            out += Anomaly(
                "STREAK_SYNC",
                Severity.INFO,
                "数据提示：多计划最大连错完全一致（${missCaps.first()}），请确认回测是否重复写入"
            )
        }

        // 5) 目标期异常：非数字/空/乱序跳跃过大（仅提示）
        val issues = settledPreds.mapNotNull { it.targetIssue.toLongOrNull() }.sorted()
        if (issues.size >= 3) {
            val gaps = issues.zipWithNext { a, b -> b - a }.filter { it > 0 }
            val medianGap = gaps.sorted().let { if (it.isEmpty()) 1L else it[it.size / 2] }.coerceAtLeast(1L)
            val huge = gaps.count { it > medianGap * 50 }
            if (huge >= 3) {
                out += Anomaly(
                    "ISSUE_GAP",
                    Severity.WARN,
                    "⚠ 数据异常：目标期号出现 $huge 处异常跳跃，请检查开奖同步"
                )
            }
        }

        // 6) 权重/评分全贴同一值
        val scores = runtimes.filter { it.sampleCount >= 10 }.map { "%.2f".format(it.score) }
        if (scores.size >= 8) {
            val dom = scores.groupingBy { it }.eachCount().maxByOrNull { it.value }
            if (dom != null && dom.value >= scores.size * 0.9 && abs(dom.key.toDoubleOrNull() ?: 50.0 - 50.0) < 0.01) {
                out += Anomaly(
                    "SCORE_FLAT",
                    Severity.WARN,
                    "⚠ 数据异常：绝大多数计划评分卡在 ${dom.key}，动态评分可能未生效"
                )
            }
        }

        return Report(out.distinctBy { it.code + it.message })
    }
}
