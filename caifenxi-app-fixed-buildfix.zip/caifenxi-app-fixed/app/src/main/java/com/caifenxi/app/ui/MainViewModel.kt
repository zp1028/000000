package com.caifenxi.app.ui

import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.caifenxi.app.CaiFenXiApplication
import com.caifenxi.app.domain.engine.AnalysisEngine
import com.caifenxi.app.domain.engine.PredictEngine
import com.caifenxi.app.domain.engine.StatsEngine
import com.caifenxi.app.domain.engine.ConsensusEngine
import com.caifenxi.app.domain.model.AlgoMode
import com.caifenxi.app.domain.model.AlgoResult
import com.caifenxi.app.domain.model.AnalysisBundle
import com.caifenxi.app.domain.model.DrawRecord
import com.caifenxi.app.domain.model.LabRow
import com.caifenxi.app.domain.model.LotteryConfig
import com.caifenxi.app.domain.model.ManualMark
import com.caifenxi.app.domain.model.ModelConsensus
import com.caifenxi.app.domain.model.ConsensusRecord
import com.caifenxi.app.domain.model.ConsensusStats
import com.caifenxi.app.domain.model.BetCategory
import com.caifenxi.app.domain.model.BetStats
import com.caifenxi.app.domain.model.BetView
import com.caifenxi.app.domain.model.BotConfig
import com.caifenxi.app.domain.model.PlanDefinition
import com.caifenxi.app.domain.model.PlanPredictionRecord
import com.caifenxi.app.domain.model.PlanRuntime
import com.caifenxi.app.domain.model.PredictionSnapshot
import com.caifenxi.app.domain.model.StatRecord
import com.caifenxi.app.domain.model.WalletView
import com.caifenxi.app.domain.model.StatsSummary
import com.caifenxi.app.domain.model.UserPrefs
import com.caifenxi.app.domain.plan.PlanEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.concurrent.atomic.AtomicBoolean
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainViewModel : ViewModel() {

    private val app get() = CaiFenXiApplication.instance
    private val repo get() = app.drawRepository
    private val configStore get() = app.configStore
    private val statStore get() = app.statStore
    private val manualStore get() = app.manualStore
    private val consensusStore get() = app.consensusStore
    private val planEngine = PlanEngine()
    private val betEngine get() = app.betEngine
    private val betDao get() = app.database.betDao()

    val prefs = mutableStateOf(configStore.loadPrefs())
    val currentLottery = mutableStateOf(
        LotteryConfig.findByKey(prefs.value.selectedLotteryKey) ?: LotteryConfig.CATALOG.first()
    )
    val currentAlgo = mutableStateOf(AlgoMode.fromId(prefs.value.currentAlgo))
    val history = mutableStateOf<List<DrawRecord>>(emptyList())
    val latest = mutableStateOf<DrawRecord?>(null)
    val loading = mutableStateOf(false)
    val errorMessage = mutableStateOf<String?>(null)
    val prediction = mutableStateOf<PredictionSnapshot?>(null)
    val algoCompare = mutableStateOf<Map<String, List<AlgoResult>>>(emptyMap())
    val consensus = mutableStateOf<List<ModelConsensus>>(emptyList())
    val planRows = mutableStateOf<List<Pair<PlanDefinition, PlanRuntime>>>(emptyList())
    val backtestRunning = mutableStateOf(false)
    val statusText = mutableStateOf("")
    val statsSummary = mutableStateOf(StatsSummary())
    val statRecords = mutableStateOf<List<StatRecord>>(emptyList())
    val analysis = mutableStateOf(AnalysisBundle())
    val labRows = mutableStateOf<List<LabRow>>(emptyList())
    val planHistory = mutableStateOf<List<PlanPredictionRecord>>(emptyList())
    val selectedPlanHistory = mutableStateOf<List<PlanPredictionRecord>>(emptyList())
    val consensusRecords = mutableStateOf<List<ConsensusRecord>>(emptyList())
    val consensusStats = mutableStateOf(ConsensusStats())
    val manualMarks = mutableStateOf<Map<String, ManualMark>>(emptyMap())
    val countdownText = mutableStateOf("--:--")
    val nextIssueText = mutableStateOf("-")

    // ---- 模拟下注状态 ----
    val botConfig = mutableStateOf(BotConfig())
    val wallet = mutableStateOf(WalletView())
    val betHistory = mutableStateOf<List<BetView>>(emptyList())
    val betStats = mutableStateOf(BetStats())

    private var refreshJob: Job? = null
    private var countdownJob: Job? = null
    private val loadMutex = Mutex()
    private val loadingGuard = AtomicBoolean(false)
    /** 同步进行中再次请求加载（如切换彩种）时置位，当前任务结束后自动接续 */
    private val pendingReload = AtomicBoolean(false)
    private var failStreak = 0
    private var lastForegroundRefresh = 0L

    init {
        loadData()
        refreshConsensusStats()
        refreshBetState()
        startAutoRefreshIfNeeded()
        startCountdown()
    }

    fun selectLottery(config: LotteryConfig) {
        currentLottery.value = config
        val p = prefs.value.copy(selectedLotteryKey = config.key)
        prefs.value = p
        configStore.savePrefs(p)
        loadData()
    }

    fun selectAlgo(mode: AlgoMode) {
        currentAlgo.value = mode
        val p = prefs.value.copy(currentAlgo = mode.id)
        prefs.value = p
        configStore.savePrefs(p)
        viewModelScope.launch {
            if (history.value.isNotEmpty()) runPredictAndPlans(history.value, forceAlgo = mode)
        }
    }

    fun setManualMark(category: String, direction: String) {
        val m = ManualMark(currentLottery.value.key, category, direction)
        manualStore.save(m)
        manualMarks.value = manualStore.load(currentLottery.value.key)
        if (currentAlgo.value == AlgoMode.MANUAL) {
            viewModelScope.launch {
                if (history.value.isNotEmpty()) runPredictAndPlans(history.value, forceAlgo = AlgoMode.MANUAL)
            }
        }
    }

    fun clearManualMarks() {
        manualStore.clear(currentLottery.value.key)
        manualMarks.value = emptyMap()
    }

    fun updatePrefs(transform: (UserPrefs) -> UserPrefs) {
        val p = transform(prefs.value)
        prefs.value = p
        configStore.savePrefs(p)
        if (p.autoRefresh) startAutoRefreshIfNeeded() else stopAutoRefresh()
    }

    /** 前台恢复时轻量刷新，避免卡死与掉线 */
    fun onForeground() {
        val now = System.currentTimeMillis()
        if (now - lastForegroundRefresh < 8_000) return
        lastForegroundRefresh = now
        // 重置可能卡住的 loading
        if (loading.value && !loadingGuard.get()) {
            loading.value = false
        }
        startAutoRefreshIfNeeded()
        startCountdown()
        refreshBetState()
        softRefreshLatest()
    }

    fun softRefreshLatest() {
        viewModelScope.launch {
            try {
                withTimeout(12_000) {
                    val one = app.apiClient.fetchLatest(currentLottery.value)
                    if (one != null) {
                        val exists = history.value.any { it.issue == one.issue }
                        if (!exists) {
                            loadData()
                        } else {
                            statusText.value = "已同步 · 最新 ${one.issue}"
                            failStreak = 0
                        }
                    }
                }
            } catch (_: Exception) {
                failStreak++
                statusText.value = "弱网 · 使用缓存"
            }
        }
    }

    fun loadData() {
        if (!loadingGuard.compareAndSet(false, true)) {
            // 正在同步时（例如切换了彩种）标记待重载，当前任务结束后自动加载新彩种，
            // 修复原实现直接 return 导致「界面已切新彩种、数据仍是旧彩种」的问题
            pendingReload.set(true)
            statusText.value = "同步中，请稍候…"
            return
        }
        viewModelScope.launch {
            loading.value = true
            errorMessage.value = null
            statusText.value = "拉取开奖…"
            // 固定本次加载的彩种，避免加载中途切换彩种造成数据错乱
            val cfg = currentLottery.value
            try {
                withTimeout(45_000) {
                // 先展示缓存
                val cached = repo.getLocalHistory(cfg.key)
                if (cached.isNotEmpty() && cfg.key == currentLottery.value.key) {
                    history.value = cached
                    latest.value = cached.lastOrNull()
                    statusText.value = "缓存 ${cached.size} 期 · 同步中…"
                }
                val (rows, source) = repo.fetchAndCacheHistory(cfg, days = 5)
                // 加载期间用户已切换彩种：丢弃过期结果（新彩种的加载会接手）
                if (cfg.key != currentLottery.value.key) return@withTimeout
                history.value = rows
                latest.value = rows.lastOrNull()
                // 只结算新增期号（缓存中已有的期号此前已结算过）。
                // 原实现对全量历史逐期结算，且每期都全量读写一次 JSON，
                // 极速类彩种一天上千期，历史越多越卡，是首页卡死的主因。
                val lastCachedIssue = cached.lastOrNull()?.issue
                val newRows = if (lastCachedIssue != null) {
                    val idx = rows.indexOfFirst { it.issue == lastCachedIssue }
                    if (idx >= 0) rows.subList(idx + 1, rows.size)
                    else rows.filter {
                        (it.issue.toLongOrNull() ?: -1L) > (lastCachedIssue.toLongOrNull() ?: -1L)
                    }
                } else rows
                if (newRows.isNotEmpty()) {
                    StatsEngine.settleWithDraws(statStore, cfg.key, newRows)
                    ConsensusEngine.settleWithDraws(consensusStore, cfg.key, newRows)
                    newRows.forEach {
                        planEngine.settlePendingWithDraw(it)
                        betEngine.settleWithDraw(cfg.key, it)
                    }
                }
                refreshConsensusStats()
                refreshStats()
                manualMarks.value = manualStore.load(cfg.key)
                statusText.value = "分析与预测…（$source）"
                runPredictAndPlans(rows)
                rebuildAnalysis(rows)
                statusText.value = "就绪 · ${rows.size} 期 · $source"
                updateNextIssue(rows)
                }
                failStreak = 0
            } catch (e: Exception) {
                failStreak++
                errorMessage.value = e.message ?: "数据加载失败"
                statusText.value = "失败 · 可继续用缓存"
                // 至少刷新本地共识/战绩
                try { refreshStats(); refreshConsensusStats() } catch (_: Exception) {}
            } finally {
                loading.value = false
                loadingGuard.set(false)
                // 同步期间有新的加载请求（切换彩种/再次点击刷新）：立即接续
                if (pendingReload.compareAndSet(true, false)) loadData()
            }
        }
    }

    /** 仅用本地缓存重算分析/预测/计划，不访问网络（首页「仅用缓存重算」入口） */
    fun recomputeFromCache() {
        viewModelScope.launch {
            val rows = history.value
            if (rows.isEmpty()) {
                statusText.value = "暂无缓存数据，请先刷新"
                return@launch
            }
            statusText.value = "本地重算…"
            try {
                withTimeout(30_000) {
                    StatsEngine.backfillFromHistory(statStore, currentLottery.value.key, rows)
                    refreshStats()
                    refreshConsensusStats()
                    runPredictAndPlans(rows)
                    rebuildAnalysis(rows)
                    updateNextIssue(rows)
                    statusText.value = "已用缓存重算 · ${rows.size} 期"
                }
            } catch (e: Exception) {
                errorMessage.value = e.message ?: "本地重算失败"
                statusText.value = "重算失败"
            }
        }
    }

    fun runBacktest() {
        viewModelScope.launch {
            val rows = history.value
            if (rows.size < 40) {
                errorMessage.value = "历史不足，至少约 40 期再回测"
                return@launch
            }
            backtestRunning.value = true
            statusText.value = "回测中…"
            try {
                withContext(Dispatchers.Default) {
                    // 手动「重新滚动验证」：先清零旧战绩，再全量回测一次，
                    // 保证各计划样本数与历史预测不重复累加
                    planEngine.clearCareer()
                    planEngine.backtest(rows, prefs.value, minWarm = 30, forceFull = true)
                }
                val target = PredictEngine.suggestNextIssue(rows.lastOrNull()?.issue)
                val cutoff = rows.last().issue
                // 强制为本期目标重新随机生成计划
                val preds = withContext(Dispatchers.Default) {
                    planEngine.generateRandomPlansForIssue(target, count = prefs.value.planPoolCount.coerceIn(4, 30), force = true)
                    planEngine.predictForNext(rows, prefs.value, target, cutoff)
                }
                planRows.value = planEngine.getRuntimes()
                planHistory.value = planEngine.getAllRecentPredictions(100)
                consensus.value = planEngine.consensus(currentLottery.value.key, target, preds)
                ConsensusEngine.recordPending(consensusStore, currentLottery.value.key, target, consensus.value)
                refreshConsensusStats()
                labRows.value = withContext(Dispatchers.Default) {
                    AnalysisEngine.labTable(rows, prefs.value)
                }
                statusText.value = "已随机生成 ${planRows.value.size} 条计划 · 回测完成"
            } catch (e: Exception) {
                errorMessage.value = e.message
            } finally {
                backtestRunning.value = false
            }
        }
    }

    fun refreshConsensusStats() {
        val key = currentLottery.value.key
        consensusRecords.value = consensusStore.loadAll(key).sortedByDescending { it.createdAt }
        consensusStats.value = consensusStore.stats(key)
    }

    fun clearConsensusStats() {
        consensusStore.clear(currentLottery.value.key)
        refreshConsensusStats()
    }

    fun loadPlanDetail(planId: String) {
        // 后台线程读取（回测持锁期间避免阻塞主线程）
        viewModelScope.launch(Dispatchers.Default) {
            val result = planEngine.getPredictionHistory(planId, 40)
            selectedPlanHistory.value = result
        }
    }

    fun clearStats() {
        statStore.clear(currentLottery.value.key)
        refreshStats()
    }

    fun backfillStats() {
        StatsEngine.backfillFromHistory(statStore, currentLottery.value.key, history.value)
        refreshStats()
    }

    private fun refreshStats() {
        val key = currentLottery.value.key
        statsSummary.value = statStore.summary(key)
        statRecords.value = statStore.loadAll(key).sortedByDescending { it.createdAt }
    }

    private suspend fun rebuildAnalysis(rows: List<DrawRecord>) {
        analysis.value = withContext(Dispatchers.Default) {
            AnalysisEngine.build(rows, prefs.value.predictionWindow)
        }
        labRows.value = withContext(Dispatchers.Default) {
            AnalysisEngine.labTable(rows, prefs.value)
        }
    }

    private suspend fun runPredictAndPlans(rows: List<DrawRecord>, forceAlgo: AlgoMode? = null) {
        if (rows.isEmpty()) return
        val cfg = currentLottery.value
        val mode = forceAlgo ?: currentAlgo.value
        val cutoff = rows.last().issue
        val target = rows.last().nextIssue?.takeIf { it.isNotBlank() }
            ?: PredictEngine.suggestNextIssue(cutoff)

        var snap = withContext(Dispatchers.Default) {
            PredictEngine.predict(rows, cfg.type, prefs.value, target, cutoff, mode)
        }
        // 手动标记覆盖
        if (mode == AlgoMode.MANUAL) {
            val marks = manualStore.load(cfg.key)
            snap = snap.copy(
                dx = marks["大小"]?.let { snap.dx?.copy(direction = it.direction, algo = "manual", score = 1.0, detail = "手动") } ?: snap.dx,
                ds = marks["单双"]?.let { snap.ds?.copy(direction = it.direction, algo = "manual", score = 1.0, detail = "手动") } ?: snap.ds,
                combo = marks["组合"]?.let { snap.combo?.copy(direction = it.direction, algo = "manual", score = 1.0, detail = "手动") } ?: snap.combo,
                algoTag = "manual"
            )
        }
        // 预测冻结：同目标期已有待开/已结算则不覆盖展示（仍允许算法切换 force）
        val freeze = prefs.value.predFreeze
        val existing = if (freeze) {
            statStore.loadAll(cfg.key).any {
                it.issue == target && it.algoId == mode.id && it.result != "待开"
            }
        } else false
        if (!existing || forceAlgo != null) {
            prediction.value = snap
        }

        if (mode != AlgoMode.COMPARE) {
            StatsEngine.recordPending(statStore, snap, mode.id)
            refreshStats()
        }

        algoCompare.value = withContext(Dispatchers.Default) {
            PredictEngine.compareAll(rows, prefs.value)
        }

        withContext(Dispatchers.Default) {
            if (rows.size >= 40) planEngine.backtest(rows, prefs.value, minWarm = 30)
            val preds = planEngine.predictForNext(rows, prefs.value, target, cutoff)
            consensus.value = planEngine.consensus(cfg.key, target, preds)
            ConsensusEngine.recordPending(consensusStore, cfg.key, target, consensus.value)
            refreshConsensusStats()
            planRows.value = planEngine.getRuntimes()
            planHistory.value = planEngine.getAllRecentPredictions(100)
        }

        // 挂机自动下注:用最新预测结果,为下一期自动下单
        val placed = betEngine.placeAutoBets(
            lotteryKey = cfg.key,
            targetIssue = target,
            prediction = prediction.value,
            planPredictions = planHistory.value,
            consensus = consensus.value
        )
        if (placed > 0) {
            statusText.value = "挂机已自动下注 $placed 注 · 第${target}期"
        }
        refreshBetState()
    }

    private fun updateNextIssue(rows: List<DrawRecord>) {
        val last = rows.lastOrNull() ?: return
        nextIssueText.value = last.nextIssue?.takeIf { it.isNotBlank() }
            ?: PredictEngine.suggestNextIssue(last.issue)
    }

    private fun startCountdown() {
        countdownJob?.cancel()
        countdownJob = viewModelScope.launch {
            val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
            while (isActive) {
                val last = latest.value
                val t = last?.drawTime
                if (t != null) {
                    try {
                        // 极速类约 75 秒一期，用上次开奖+75s 估算
                        val base = fmt.parse(t.take(19).replace('T', ' '))
                        if (base != null) {
                            val next = base.time + 75_000
                            val left = next - System.currentTimeMillis()
                            countdownText.value = if (left <= 0) "即将开奖" else {
                                val s = (left / 1000).toInt()
                                "%02d:%02d".format(s / 60, s % 60)
                            }
                        }
                    } catch (_: Exception) {
                        countdownText.value = "--:--"
                    }
                }
                delay(1000)
            }
        }
    }

    private fun startAutoRefreshIfNeeded() {
        stopAutoRefresh()
        if (!prefs.value.autoRefresh) return
        refreshJob = viewModelScope.launch {
            while (isActive) {
                // 失败越多，间隔越长，减轻卡死与封禁风险
                val wait = when {
                    failStreak >= 5 -> 90_000L
                    failStreak >= 2 -> 45_000L
                    else -> 25_000L
                }
                delay(wait)
                // 正在整库加载或手动回测时跳过本轮心跳：
                // 避免与 loadData 并发触发预测/回测（曾导致并发读写崩溃与启动初期闪退）
                if (loadingGuard.get() || backtestRunning.value) continue
                try {
                    withTimeout(15_000) {
                        val one = app.apiClient.fetchLatest(currentLottery.value)
                        if (one != null) {
                            failStreak = 0
                            val curKey = currentLottery.value.key
                            // 彩种切换瞬间的保护：最新开奖与内存历史不属于同一彩种时
                            // 不合并（否则会把 A 彩种的开奖混进 B 彩种的历史），交给 loadData 处理
                            if (one.lotteryKey == curKey &&
                                (history.value.isEmpty() || history.value.lastOrNull()?.lotteryKey == curKey)
                            ) {
                                val exists = history.value.any { it.issue == one.issue }
                                if (!exists) {
                                    val merged = (history.value + one).distinctBy { it.issue }
                                        .sortedBy { it.issue.toLongOrNull() ?: 0L }
                                    history.value = merged
                                    latest.value = one
                                    StatsEngine.settleWithDraw(statStore, currentLottery.value.key, one)
                                    planEngine.settlePendingWithDraw(one)
                                    ConsensusEngine.settleWithDraw(consensusStore, currentLottery.value.key, one)
                                    betEngine.settleWithDraw(currentLottery.value.key, one)
                                    planHistory.value = planEngine.getAllRecentPredictions(80)
                                    planRows.value = planEngine.getRuntimes()
                                    refreshConsensusStats()
                                    refreshStats()
                                    runPredictAndPlans(merged)
                                    rebuildAnalysis(merged)
                                    updateNextIssue(merged)
                                    statusText.value = "新期 ${one.issue} · 已更新"
                                } else {
                                    statusText.value = "心跳正常 · ${one.issue}"
                                }
                            }
                        }
                    }
                } catch (_: Exception) {
                    failStreak++
                    statusText.value = "后台同步失败($failStreak) · 缓存仍可用"
                }
            }
        }
    }

    private fun stopAutoRefresh() {
        refreshJob?.cancel()
        refreshJob = null
    }

    // ---- 模拟下注 / 挂机操作 ----

    /** 从 DB 刷新挂机策略、钱包与下注历史到 UI 状态 */
    fun refreshBetState() {
        viewModelScope.launch {
            val key = currentLottery.value.key
            val cfg = betDao.getBotConfig(key)
            botConfig.value = cfg?.let {
                BotConfig(
                    enabled = it.enabled,
                    sourceType = it.sourceType,
                    sourceId = it.sourceId,
                    categories = it.categories.split(",").map { c -> c.trim() }.filter { c -> c.isNotEmpty() }.toSet(),
                    numberPosition = it.numberPosition,
                    amount = it.amount,
                    winMult = it.winMult,
                    lossMult = it.lossMult,
                    maxMult = it.maxMult
                )
            } ?: BotConfig()

            val w = betDao.getWallet(key)
            wallet.value = w?.let {
                WalletView(
                    initialBalance = it.initialBalance,
                    balance = it.balance,
                    totalProfit = it.totalProfit,
                    totalBet = it.totalBet,
                    winCount = it.winCount,
                    loseCount = it.loseCount
                )
            } ?: WalletView()

            val bets = betDao.getBets(key)
            betHistory.value = bets.map { b ->
                BetView(
                    id = b.id,
                    issue = b.issue,
                    sourceLabel = b.sourceId,
                    category = b.category,
                    betValue = b.betValue,
                    amount = b.amount,
                    odds = b.odds,
                    status = b.status,
                    profit = b.profit,
                    createdAt = b.createdAt,
                    settledAt = b.settledAt
                )
            }

            // 刷新统计数据
            betStats.value = betEngine.getBetStats(key)
        }
    }

    /** 保存挂机策略 */
    fun saveBotConfig(config: BotConfig) {
        viewModelScope.launch {
            val key = currentLottery.value.key
            betDao.upsertBotConfig(
                com.caifenxi.app.data.db.entity.BotConfigEntity(
                    lotteryKey = key,
                    enabled = config.enabled,
                    sourceType = config.sourceType,
                    sourceId = config.sourceId,
                    categories = config.categories.sorted().joinToString(","),
                    numberPosition = config.numberPosition,
                    amount = config.amount,
                    winMult = config.winMult.coerceIn(1.0, 10.0),
                    lossMult = config.lossMult.coerceIn(1.0, 10.0),
                    maxMult = config.maxMult.coerceIn(1, 20)
                )
            )
            botConfig.value = config
            statusText.value = if (config.enabled) "挂机已开启" else "挂机已暂停"
        }
    }

    /** 初始化/重置虚拟账户资金 */
    fun setInitialBalance(amount: Double) {
        viewModelScope.launch {
            val key = currentLottery.value.key
            betEngine.ensureWallet(key, amount)
            refreshBetState()
            statusText.value = "初始资金已设为 $amount"
        }
    }

    /** 清空下注历史(不影响余额) */
    fun clearBetHistory() {
        viewModelScope.launch {
            betDao.clearBets(currentLottery.value.key)
            refreshBetState()
        }
    }

    override fun onCleared() {
        stopAutoRefresh()
        countdownJob?.cancel()
        super.onCleared()
    }
}
