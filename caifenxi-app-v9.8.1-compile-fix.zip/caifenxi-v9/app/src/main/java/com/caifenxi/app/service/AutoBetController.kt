package com.caifenxi.app.service

import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.text.TextUtils
import com.caifenxi.app.CaiFenXiApplication
import com.caifenxi.app.domain.model.UserPrefs
import com.caifenxi.app.util.RuntimeLog

/**
 * 真实自动点击控制器。
 * - 读取内部预测（与悬浮窗同源逻辑）
 * - 按期号去重，避免同一期重复点击
 * - 通过无障碍服务执行点击
 */
object AutoBetController {

    private const val PREFS = "auto_bet_runtime"
    private const val KEY_LAST_ISSUE = "last_bet_issue"
    private const val KEY_LAST_LOTTERY = "last_bet_lottery"

    /** 是否已开启系统无障碍服务 */
    fun isAccessibilityEnabled(context: Context): Boolean {
        val expected = context.packageName + "/" + AutoBetAccessibilityService::class.java.canonicalName
        val enabled = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val splitter = TextUtils.SimpleStringSplitter(':')
        splitter.setString(enabled)
        while (splitter.hasNext()) {
            if (splitter.next().equals(expected, ignoreCase = true)) return true
        }
        return false
    }

    fun openAccessibilitySettings(context: Context) {
        try {
            context.startActivity(
                Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (_: Exception) {
            try {
                context.startActivity(
                    Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (_: Exception) {
            }
        }
    }

    /**
     * 预测 READY 时调用。根据 UserPrefs 决定是否真实点击第三方页面。
     */
    fun onPredictionReady(context: Context, snap: FloatingSnapshot) {
        val app = try {
            CaiFenXiApplication.instance
        } catch (_: Exception) {
            return
        }
        val prefs = app.configStore.loadPrefs()
        if (!prefs.autoClickEnabled) return
        if (snap.status != "READY") return
        if (snap.targetIssue.isBlank() || snap.targetIssue == "-") return

        // 期号 + 彩种 去重
        val sp = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val lastIssue = sp.getString(KEY_LAST_ISSUE, "")
        val lastLottery = sp.getString(KEY_LAST_LOTTERY, "")
        if (snap.targetIssue == lastIssue && snap.lotteryKey == lastLottery) {
            RuntimeLog.info("AutoBet", "期号 ${snap.targetIssue} 已点击过，跳过")
            return
        }

        if (!isAccessibilityEnabled(context)) {
            RuntimeLog.warn("AutoBet", "无障碍服务未开启，跳过自动点击")
            return
        }
        val service = AutoBetAccessibilityService.instance
        if (service == null) {
            RuntimeLog.warn("AutoBet", "无障碍服务实例为空，跳过")
            return
        }

        val (dx, ds) = resolvePrediction(prefs, snap)
        if (dx.isNullOrBlank() && ds.isNullOrBlank()) {
            RuntimeLog.info("AutoBet", "无有效大小/单双预测，跳过")
            return
        }

        // 按用户配置过滤类别
        val doDx = prefs.autoClickDx && !dx.isNullOrBlank()
        val doDs = prefs.autoClickDs && !ds.isNullOrBlank()
        if (!doDx && !doDs) return

        RuntimeLog.info(
            "AutoBet",
            "执行自动点击 期号=${snap.targetIssue} 大小=${if (doDx) dx else "-"} 单双=${if (doDs) ds else "-"}"
        )

        service.performBet(
            dx = if (doDx) dx else null,
            ds = if (doDs) ds else null,
            clickDelayMs = prefs.autoClickDelayMs.coerceIn(100L, 3000L)
        )

        sp.edit()
            .putString(KEY_LAST_ISSUE, snap.targetIssue)
            .putString(KEY_LAST_LOTTERY, snap.lotteryKey)
            .apply()
    }

    /**
     * 与悬浮窗完全一致的预测解析逻辑。
     */
    fun resolvePrediction(prefs: UserPrefs, snap: FloatingSnapshot): Pair<String?, String?> {
        val selectedDxId = prefs.floatingDxPlanId.ifBlank { prefs.floatingPlanId }
        val selectedDsId = prefs.floatingDsPlanId.ifBlank { prefs.floatingPlanId }
        val dxPlan = snap.plans.firstOrNull { it.planId == selectedDxId && !it.dx.isNullOrBlank() }
        val dsPlan = snap.plans.firstOrNull { it.planId == selectedDsId && !it.ds.isNullOrBlank() }

        val consensusDx = snap.consensusDx?.takeIf { it == "大" || it == "小" }
        val consensusDs = snap.consensusDs?.takeIf { it == "单" || it == "双" }
        val algoDx = snap.algoDx?.takeIf { it == "大" || it == "小" }
        val algoDs = snap.algoDs?.takeIf { it == "单" || it == "双" }

        var dx: String? = null
        var ds: String? = null

        when (prefs.floatingSource) {
            "plan" -> {
                dx = dxPlan?.dx?.split("/", "、", ",")?.firstOrNull { it == "大" || it == "小" }
                ds = dsPlan?.ds?.split("/", "、", ",")?.firstOrNull { it == "单" || it == "双" }
                if (dx == null) dx = consensusDx ?: algoDx
                if (ds == null) ds = consensusDs ?: algoDs
            }
            "algo" -> {
                dx = algoDx ?: consensusDx
                ds = algoDs ?: consensusDs
            }
            else -> {
                dx = consensusDx ?: algoDx
                ds = consensusDs ?: algoDs
            }
        }
        return dx to ds
    }

    /** 手动立即尝试一次（设置页按钮用） */
    fun tryNow(context: Context) {
        val snap = FloatingOverlayStore.loadLastReady(context)
            ?: FloatingOverlayStore.load(context)
        if (snap == null) {
            RuntimeLog.warn("AutoBet", "当前无可用预测快照")
            return
        }
        // 手动触发时允许同期待重试：临时清去重
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .remove(KEY_LAST_ISSUE)
            .remove(KEY_LAST_LOTTERY)
            .apply()
        onPredictionReady(context, snap.copy(status = "READY"))
    }
}
