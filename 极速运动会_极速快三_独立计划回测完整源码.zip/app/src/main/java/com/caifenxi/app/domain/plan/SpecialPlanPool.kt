package com.caifenxi.app.domain.plan

import com.caifenxi.app.domain.model.PlanDefinition
import com.caifenxi.app.domain.model.PlanHitCriteria
import com.caifenxi.app.domain.model.PlanOutputFormat

/** 独立新彩种计划池：每个彩种、每个玩法使用自己的计划定义与统计命名空间。 */
object SpecialPlanPool {
    private val algos = listOf("STATE","RHYTHM","NETWORK","SIMILAR","STRUCT","ANOMALY","CANDIDATE","OPTIMIZE")

    private fun plan(id: String, name: String, lotteryKey: String, play: String, algorithm: String, window: Int, pos: Int = -1, baseline: Double): PlanDefinition =
        PlanDefinition(
            planId = "SPECIAL-$lotteryKey-$id",
            planName = name,
            category = "${lotteryKey}|$play",
            algorithm = algorithm,
            window = window,
            playType = play,
            positionIndex = pos,
            outputFormat = if (play == "定位号码" || play == "定位大小" || play == "定位单双" || play == "龙虎" || play == "三军" || play == "鱼虾蟹" || play == "长牌") PlanOutputFormat.DIRECTION else PlanOutputFormat.DIRECTION,
            hitCriteria = PlanHitCriteria.DIRECTION_MATCH,
            participateConsensus = true,
            participateCombo = false,
            baselineValue = baseline
        )

    private fun buildSports(): List<PlanDefinition> {
        val out = mutableListOf<PlanDefinition>()
        for (pos in 0..5) {
            val p = pos + 1
            algos.forEachIndexed { i, a ->
                val w = listOf(10,20,30,50,100,200,500)[i % 7]
                out += plan("S$p-DX-${i+1}", "第${p}球大小·${a}", "10075", "定位大小", a, w, pos, .5)
                out += plan("S$p-DS-${i+1}", "第${p}球单双·${a}", "10075", "定位单双", a, w, pos, .5)
                out += plan("S$p-N-${i+1}", "第${p}球定位号码·${a}", "10075", "定位号码", a, w, pos, 1.0/6.0)
            }
        }
        listOf(0 to 5, 1 to 4, 2 to 3).forEachIndexed { pair, (a,b) ->
            algos.forEachIndexed { i, algo ->
                out += plan("L${pair+1}-${i+1}", "${pair+1}球龙虎·${algo}", "10075", "龙虎", algo, listOf(10,20,30,50,100,200,500)[i%7], a, .5)
            }
        }
        return out
    }

    private fun buildK3(): List<PlanDefinition> {
        val out = mutableListOf<PlanDefinition>()
        val plays = listOf("三军" to 1.0/3.0, "和值大小" to .5, "鱼虾蟹" to 1.0/3.0, "长牌" to 1.0/15.0)
        plays.forEach { (play, base) ->
            algos.forEachIndexed { i, algo ->
                out += plan("K3-${play.hashCode()}-${i+1}", "$play·${algo}", "10073", play, algo, listOf(10,20,30,50,100,200,500)[i%7], -1, base)
            }
        }
        return out
    }

    val SPORTS: List<PlanDefinition> = buildSports()
    val K3: List<PlanDefinition> = buildK3()
    val ALL: List<PlanDefinition> = SPORTS + K3

    fun forLottery(lotteryKey: String): List<PlanDefinition> = when (lotteryKey) {
        "10075" -> SPORTS
        "10073" -> K3
        else -> emptyList()
    }
}
