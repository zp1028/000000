package com.caifenxi.app.domain.btc.portfolio

import com.caifenxi.app.domain.btc.BtcDirection
import com.caifenxi.app.domain.btc.BtcRegimeEngine
import com.caifenxi.app.domain.btc.MarketRegime

/** Deterministic regime-aware multiplier. Research may tune the table later; runtime never invents a weight. */
object AdaptiveRegimeWeightEngine {
    data class Result(val regime: MarketRegime, val confidence: Double, val multiplier: Double, val reason: String)

    fun classify(snapshot: BtcRegimeEngine.Snapshot?): Result {
        if (snapshot == null) return Result(MarketRegime.RANGE, 0.0, 0.75, "regime样本不足，降风险")
        val trendConfidence = kotlin.math.abs(snapshot.trendScore).coerceIn(0.0, 1.0)
        val volConfidence = ((snapshot.volatilityPct / 0.012).coerceIn(0.0, 1.0))
        val confidence = when (snapshot.regime) {
            MarketRegime.BREAKOUT -> (0.55 * trendConfidence + 0.45 * volConfidence).coerceIn(0.0, 1.0)
            MarketRegime.HIGH_VOLATILITY -> volConfidence
            MarketRegime.TREND_UP, MarketRegime.TREND_DOWN -> trendConfidence
            MarketRegime.RANGE -> (1.0 - trendConfidence).coerceIn(0.0, 1.0)
        }
        val multiplier = when (snapshot.regime) {
            MarketRegime.BREAKOUT -> 1.05
            MarketRegime.TREND_UP, MarketRegime.TREND_DOWN -> 1.00
            MarketRegime.RANGE -> 0.82
            MarketRegime.HIGH_VOLATILITY -> 0.60
        }
        return Result(snapshot.regime, confidence, multiplier, "${snapshot.regime}; trend=${"%.2f".format(snapshot.trendScore)} vol=${"%.2f%%".format(snapshot.volatilityPct * 100)}")
    }

    fun strategyMultiplier(strategyId: String, direction: BtcDirection, regime: MarketRegime): Double {
        val momentum = strategyId.contains("MOMENTUM") || strategyId.contains("TREND") || strategyId.contains("BINANCE")
        val meanRevert = strategyId.contains("MEAN-REVERT") || strategyId.contains("CONVERGENCE") || strategyId.contains("CONTRARIAN")
        return when (regime) {
            MarketRegime.BREAKOUT -> if (momentum) 1.12 else if (meanRevert) 0.72 else 1.0
            MarketRegime.TREND_UP -> if (momentum && direction == BtcDirection.UP) 1.08 else if (meanRevert) 0.82 else 1.0
            MarketRegime.TREND_DOWN -> if (momentum && direction == BtcDirection.DOWN) 1.08 else if (meanRevert) 0.82 else 1.0
            MarketRegime.RANGE -> if (meanRevert) 1.08 else if (momentum) 0.82 else 1.0
            MarketRegime.HIGH_VOLATILITY -> if (meanRevert) 0.88 else 0.72
        }
    }
}
