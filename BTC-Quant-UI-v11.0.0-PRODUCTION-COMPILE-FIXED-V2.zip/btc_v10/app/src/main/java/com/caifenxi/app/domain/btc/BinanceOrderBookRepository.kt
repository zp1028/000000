package com.caifenxi.app.domain.btc

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import java.util.concurrent.TimeUnit

/** Real Binance futures order-book snapshot. No candle-volume simulation is used. */
class BinanceOrderBookRepository(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()
) {
    data class Level(val price: Double, val quantity: Double)
    data class Snapshot(
        val symbol: String,
        val bids: List<Level>,
        val asks: List<Level>,
        val lastUpdateId: Long,
        val fetchedAt: Long = System.currentTimeMillis()
    ) {
        val bestBid: Double? get() = bids.maxByOrNull { it.price }?.price
        val bestAsk: Double? get() = asks.minByOrNull { it.price }?.price
        val mid: Double? get() = bestBid?.let { b -> bestAsk?.let { a -> (a + b) / 2.0 } }
        val spread: Double get() = bestBid?.let { b -> bestAsk?.let { a -> (a - b).coerceAtLeast(0.0) } } ?: 0.0
        val bidDepth: Double get() = bids.take(20).sumOf { it.price * it.quantity }
        val askDepth: Double get() = asks.take(20).sumOf { it.price * it.quantity }
        val imbalance: Double
            get() = if (bidDepth + askDepth <= 0.0) 0.0 else (bidDepth - askDepth) / (bidDepth + askDepth)
        val microPrice: Double?
            get() {
                val bid = bids.maxByOrNull { it.price } ?: return bestAsk
                val ask = asks.minByOrNull { it.price } ?: return bestBid
                val total = bid.quantity + ask.quantity
                return if (total > 0.0) (ask.price * bid.quantity + bid.price * ask.quantity) / total else (bid.price + ask.price) / 2.0
            }
    }

    suspend fun snapshot(symbol: String = "BTCUSDT", limit: Int = 100): Snapshot? = withContext(Dispatchers.IO) {
        val safe = limit.coerceIn(5, 1000)
        val bases = listOf("https://fapi.binance.com", "https://testnet.binancefuture.com")
        for (base in bases) {
            try {
                val req = Request.Builder().url("$base/fapi/v1/depth?symbol=${symbol.uppercase()}&limit=$safe").get().build()
                client.newCall(req).execute().use { response ->
                    if (!response.isSuccessful) error("HTTP ${response.code}")
                    val body = response.body?.string().orEmpty()
                    val obj = org.json.JSONObject(body)
                    fun parse(key: String): List<Level> {
                        val arr = obj.optJSONArray(key) ?: JSONArray()
                        return buildList {
                            for (i in 0 until arr.length()) {
                                val row = arr.optJSONArray(i) ?: continue
                                val p = row.optString(0).toDoubleOrNull() ?: continue
                                val q = row.optString(1).toDoubleOrNull() ?: continue
                                if (p > 0.0 && q > 0.0 && p.isFinite() && q.isFinite()) add(Level(p, q))
                            }
                        }
                    }
                    return@withContext Snapshot(symbol.uppercase(), parse("bids"), parse("asks"), obj.optLong("lastUpdateId"))
                }
            } catch (_: Exception) { }
        }
        null
    }
}
