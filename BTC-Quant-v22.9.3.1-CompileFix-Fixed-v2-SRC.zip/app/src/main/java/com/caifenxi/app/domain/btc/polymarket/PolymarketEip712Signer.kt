package com.caifenxi.app.domain.btc.polymarket

import java.math.BigInteger
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.SecureRandom
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/** Pure Kotlin/Java EIP-712 V2 signer for EOA CLOB orders (signatureType=0).
 * No network, wallet SDK or external signing service is required.
 */
object PolymarketEip712Signer {
    private val N = BigInteger("FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141",16)
    private val P = BigInteger("FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEFFFFFC2F",16)
    private val GX = BigInteger("79BE667EF9DCBBAC55A06295CE870B07029BFCDB2DCE28D959F2815B16F81798",16)
    private val GY = BigInteger("483ADA7726A3C4655DA4FBFC0E1108A8FD17B448A68554199C47D08FFB10D4B8",16)
    private const val DOMAIN = "EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)"
    private const val ORDER = "Order(uint256 salt,address maker,address signer,uint256 tokenId,uint256 makerAmount,uint256 takerAmount,uint8 side,uint8 signatureType,uint256 timestamp,bytes32 metadata,bytes32 builder)"
    // V2 exchange contracts, Polygon mainnet.
    const val EXCHANGE_V2 = "E111180000d2663C0091e4f400237545B87B996B"
    const val NEG_RISK_EXCHANGE_V2 = "e2222d279d744050d28e00520010520000310F59"

    data class SignedOrder(
        val salt: String, val maker: String, val signer: String, val taker: String,
        val tokenId: String, val makerAmount: String, val takerAmount: String,
        val side: Int, val signatureType: Int, val timestamp: Long,
        val metadata: String, val builder: String, val expiration: Long,
        val signature: String
    )

    fun deriveAddress(privateKeyHex: String): String {
        val d = parsePrivate(privateKeyHex)
        val q = multiply(Point(GX,GY), d) ?: error("invalid private key")
        val pub = bytes32(q.x) + bytes32(q.y)
        return "0x" + hex(Keccak256.digest(pub)).takeLast(40)
    }

    /** L1 ClobAuth EIP-712 signature used only for EOA API-key create/derive.
     * ClobAuth stays on domain version 1 even when the exchange order protocol is V2.
     */
    fun signClobAuth(
        privateKeyHex: String,
        timestampSeconds: Long,
        nonce: BigInteger = BigInteger.ZERO,
        chainId: Long = 137L
    ): String {
        val privateKey = parsePrivate(privateKeyHex)
        val signer = deriveAddress(privateKeyHex)
        val domainType = "EIP712Domain(string name,string version,uint256 chainId)"
        val authType = "ClobAuth(address address,string timestamp,uint256 nonce,string message)"
        val domainHash = keccak(
            hexToBytes(Keccak256.digest(domainType.toByteArray()).let(::hex)) +
                hexToBytes(Keccak256.digest("ClobAuthDomain".toByteArray()).let(::hex)) +
                hexToBytes(Keccak256.digest("1".toByteArray()).let(::hex)) +
                uint(BigInteger.valueOf(chainId))
        )
        val message = "This message attests that I control the given wallet"
        val structHash = keccak(
            hexToBytes(Keccak256.digest(authType.toByteArray()).let(::hex)) +
                addressWord(signer) +
                hexToBytes(Keccak256.digest(timestampSeconds.toString().toByteArray()).let(::hex)) +
                uint(nonce) +
                hexToBytes(Keccak256.digest(message.toByteArray()).let(::hex))
        )
        val digest = keccak(byteArrayOf(0x19, 0x01) + domainHash + structHash)
        return "0x" + hex(signDigest(privateKey, digest))
    }

    fun signOrder(
        privateKeyHex: String,
        maker: String,
        tokenId: String,
        makerAmount: BigInteger,
        takerAmount: BigInteger,
        side: Int,
        signatureType: Int = 0,
        timestampMs: Long = System.currentTimeMillis(),
        metadata: String = "0x" + "00".repeat(32),
        builder: String = "0x" + "00".repeat(32),
        expiration: Long = 0L,
        negRisk: Boolean = false,
        salt: BigInteger = randomSalt()
    ): SignedOrder {
        require(signatureType == 0) { "v18.7 EOA signer only; POLY_1271 requires ERC-7739/1271 wallet flow" }
        val address = deriveAddress(privateKeyHex)
        require(address.equals(maker, true)) { "private key address does not match maker" }
        val verifying = if (negRisk) NEG_RISK_EXCHANGE_V2 else EXCHANGE_V2
        val domainHash = keccak(
            hexToBytes(Keccak256.digest(DOMAIN.toByteArray(Charsets.UTF_8)).let(::hex)) +
            hexToBytes(Keccak256.digest("Polymarket CTF Exchange".toByteArray()).let(::hex)) +
            hexToBytes(Keccak256.digest("2".toByteArray()).let(::hex)) +
            uint(BigInteger.valueOf(137)) + addressWord(verifying)
        )
        val structHash = keccak(
            hexToBytes(Keccak256.digest(ORDER.toByteArray()).let(::hex)) +
            uint(salt) + addressWord(maker) + addressWord(maker) +
            uint(parseUint(tokenId)) + uint(makerAmount) + uint(takerAmount) + uint(BigInteger.valueOf(side.toLong())) +
            uint(BigInteger.valueOf(signatureType.toLong())) + uint(BigInteger.valueOf(timestampMs)) +
            bytes32(hexToBytes(metadata)) + bytes32(hexToBytes(builder))
        )
        val digest = keccak(byteArrayOf(0x19,0x01) + domainHash + structHash)
        val sig = signDigest(parsePrivate(privateKeyHex), digest)
        return SignedOrder(
            salt = salt.toString(), maker = maker, signer = maker,
            taker = "0x0000000000000000000000000000000000000000", tokenId = tokenId,
            makerAmount = makerAmount.toString(), takerAmount = takerAmount.toString(), side = side,
            signatureType = signatureType, timestamp = timestampMs,
            metadata = normalizeBytes32(metadata), builder = normalizeBytes32(builder), expiration = expiration,
            signature = "0x" + hex(sig)
        )
    }

    private data class Point(val x: BigInteger, val y: BigInteger)
    private fun add(a: Point?, b: Point?): Point? {
        if (a == null) return b; if (b == null) return a
        if (a.x == b.x && a.y != b.y) return null
        val m = if (a == b) a.x.multiply(a.x).multiply(BigInteger.valueOf(3)).multiply(a.y.multiply(BigInteger.TWO).modInverse(P)).mod(P)
        else b.y.subtract(a.y).multiply(b.x.subtract(a.x).mod(P).modInverse(P)).mod(P)
        val x = m.multiply(m).subtract(a.x).subtract(b.x).mod(P)
        val y = m.multiply(a.x.subtract(x)).subtract(a.y).mod(P)
        return Point(x,y)
    }
    private fun multiply(p: Point, k0: BigInteger): Point? {
        var k=k0; var r:Point?=null; var a:Point?=p
        while(k.signum()>0){ if(k.testBit(0)) r=add(r,a); a=add(a,a); k=k.shiftRight(1) }
        return r
    }

    private fun signDigest(d: BigInteger, hash: ByteArray): ByteArray {
        var k = rfc6979(d, hash); var rec = 0
        while(true){
            val rPoint=multiply(Point(GX,GY),k)!!; var r=rPoint.x.mod(N)
            if(r.signum()==0){k=k.add(BigInteger.ONE).mod(N);continue}
            var s=k.modInverse(N).multiply(BigInteger(1,hash).add(r.multiply(d))).mod(N)
            if(s.signum()==0){k=k.add(BigInteger.ONE).mod(N);continue}
            rec=(if(rPoint.y.testBit(0))1 else 0) + if(rPoint.x>=N)2 else 0
            if(s>N.shiftRight(1)){s=N.subtract(s);rec=rec xor 1}
            val out=ByteArray(65); bytes32(r).copyInto(out,0); bytes32(s).copyInto(out,32); out[64]=(27+rec).toByte(); return out
        }
    }
    private fun rfc6979(d:BigInteger,h:ByteArray):BigInteger{
        val x=bytes32(d); val bh=bytes32(BigInteger(1,h)); var v=ByteArray(32){1}; var k=ByteArray(32)
        fun mac(key:ByteArray,vararg parts:ByteArray):ByteArray{val m=Mac.getInstance("HmacSHA256");m.init(SecretKeySpec(key,"HmacSHA256"));parts.forEach(m::update);return m.doFinal()}
        k=mac(k,v,byteArrayOf(0),x,bh); v=mac(k,v); k=mac(k,v,byteArrayOf(1),x,bh); v=mac(k,v)
        while(true){v=mac(k,v);val z=BigInteger(1,v);if(z >= BigInteger.ONE && z < N)return z;k=mac(k,v,byteArrayOf(0));v=mac(k,v)}
    }
    private fun parsePrivate(s:String)=BigInteger(s.removePrefix("0x"),16).also{require(it >= BigInteger.ONE && it < N){"invalid private key"}}
    private fun parseUint(s:String)=BigInteger(s.removePrefix("0x"),16)
    private fun randomSalt():BigInteger=BigInteger(256,SecureRandom()).mod(N)
    private fun addressWord(a:String)=ByteArray(12){0}+hexToBytes(a)
    private fun uint(v:BigInteger)=bytes32(v)
    private fun bytes32(v:BigInteger):ByteArray{val raw=v.toByteArray();val out=ByteArray(32);val src=if(raw.size>32)raw.copyOfRange(raw.size-32,raw.size) else raw;src.copyInto(out,32-src.size);return out}
    private fun bytes32(b:ByteArray):ByteArray{require(b.size<=32);val o=ByteArray(32);b.copyInto(o,32-b.size);return o}
    private fun normalizeBytes32(s:String)="0x"+hex(bytes32(hexToBytes(s)))
    private fun keccak(b:ByteArray)=Keccak256.digest(b)
    private fun hex(b:ByteArray)=b.joinToString(""){"%02x".format(it)}
    private fun hexToBytes(s:String):ByteArray{val x=s.removePrefix("0x");require(x.length%2==0);return ByteArray(x.length/2){x.substring(it*2,it*2+2).toInt(16).toByte()}}

    private object Keccak256 {
        private val RC=longArrayOf(0x0000000000000001UL.toLong(),0x0000000000008082UL.toLong(),0x800000000000808AUL.toLong(),0x8000000080008000UL.toLong(),0x000000000000808BUL.toLong(),0x0000000080000001UL.toLong(),0x8000000080008081UL.toLong(),0x8000000000008009UL.toLong(),0x000000000000008AUL.toLong(),0x0000000000000088UL.toLong(),0x0000000080008009UL.toLong(),0x000000008000000AUL.toLong(),0x000000008000808BUL.toLong(),0x800000000000008BUL.toLong(),0x8000000000008089UL.toLong(),0x8000000000008003UL.toLong(),0x8000000000008002UL.toLong(),0x8000000000000080UL.toLong(),0x000000000000800AUL.toLong(),0x800000008000000AUL.toLong(),0x8000000080008081UL.toLong(),0x8000000000008080UL.toLong(),0x0000000080000001UL.toLong(),0x8000000080008008UL.toLong())
        private val R=intArrayOf(0,1,62,28,27,36,44,6,55,20,3,10,43,25,39,41,45,15,21,8,18,2,61,56,14)
        fun digest(input:ByteArray):ByteArray{val rate=136;val p=java.io.ByteArrayOutputStream();p.write(input);p.write(1);while(p.size()%rate!=rate-1)p.write(0);p.write(0x80);val a=LongArray(25);val data=p.toByteArray();for(off in data.indices step rate){for(i in 0 until rate/8)a[i] = a[i] xor ByteBuffer.wrap(data,off+i*8,8).order(ByteOrder.LITTLE_ENDIAN).long;permute(a)};val out=ByteArray(32);for(i in 0 until 32)out[i]=(a[i/8] ushr ((i%8)*8)).toByte();return out}
        private fun permute(a:LongArray){val b=LongArray(25);val c=LongArray(5);val d=LongArray(5);repeat(24){for(x in 0..4)c[x]=a[x] xor a[x+5] xor a[x+10] xor a[x+15] xor a[x+20];for(x in 0..4)d[x]=c[(x+4)%5] xor java.lang.Long.rotateLeft(c[(x+1)%5],1);for(i in 0..24)a[i]=a[i] xor d[i%5];for(x in 0..4)for(y in 0..4){val i=x+5*y;val j=y+5*((2*x+3*y)%5);b[j]=java.lang.Long.rotateLeft(a[i],R[i])};for(x in 0..4)for(y in 0..4)a[x+5*y]=b[x+5*y] xor (b[(x+1)%5+5*y].inv() and b[(x+2)%5+5*y]);a[0]=a[0] xor RC[it]}}
    }
}
