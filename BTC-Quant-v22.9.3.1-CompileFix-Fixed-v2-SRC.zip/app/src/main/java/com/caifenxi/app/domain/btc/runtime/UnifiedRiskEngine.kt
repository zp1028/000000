package com.caifenxi.app.domain.btc.runtime

/** Single last-mile risk decision. UNKNOWN is never executable. */
enum class UnifiedRiskStatus { ALLOW, BLOCK, UNKNOWN }

data class UnifiedRiskInput(
    /** Optional execution-mode binding. When supplied, TradingCore requires an exact match. */
    val mode: TradingMode? = null,
    val symbol: String,
    val equityUsdt: Double,
    val dailyPnlUsdt: Double,
    val drawdownPct: Double,
    val requestedNotionalUsdt: Double,
    val currentPositionQty: Double = 0.0,
    val requestedQty: Double = 0.0,
    /** Signed position delta: BUY/long is positive, SELL/short is negative. */
    val positionDeltaQty: Double? = null,
    val maxOrderNotionalUsdt: Double = 1_000.0,
    val maxDailyLossUsdt: Double = 500.0,
    val maxDrawdownPct: Double = 10.0,
    val maxPositionQty: Double = Double.MAX_VALUE,
    val executionHealthy: Boolean = true,
    val reconciliationHealthy: Boolean = true,
    val killSwitch: Boolean = false
)

data class UnifiedRiskDecision(
    val status: UnifiedRiskStatus,
    val reason: String,
    val riskUsedUsdt: Double = 0.0
) {
    val allowed: Boolean get() = status == UnifiedRiskStatus.ALLOW
}

class UnifiedRiskEngine {
    fun evaluate(input: UnifiedRiskInput): UnifiedRiskDecision {
        if (!input.executionHealthy || !input.reconciliationHealthy) {
            return UnifiedRiskDecision(UnifiedRiskStatus.UNKNOWN, "执行健康状态未知或对账未完成")
        }
        if (input.killSwitch) return UnifiedRiskDecision(UnifiedRiskStatus.BLOCK, "全局熔断")
        if (input.equityUsdt <= 0.0) return UnifiedRiskDecision(UnifiedRiskStatus.UNKNOWN, "账户权益无效")
        if (input.requestedQty <= 0.0 || input.requestedNotionalUsdt <= 0.0) {
            return UnifiedRiskDecision(UnifiedRiskStatus.BLOCK, "订单数量或名义价值无效")
        }
        if (input.dailyPnlUsdt <= -input.maxDailyLossUsdt) {
            return UnifiedRiskDecision(UnifiedRiskStatus.BLOCK, "达到日亏损限制")
        }
        if (input.drawdownPct >= input.maxDrawdownPct) {
            return UnifiedRiskDecision(UnifiedRiskStatus.BLOCK, "达到最大回撤限制")
        }
        if (input.requestedNotionalUsdt > input.maxOrderNotionalUsdt) {
            return UnifiedRiskDecision(UnifiedRiskStatus.BLOCK, "单笔名义价值超过限制", input.requestedNotionalUsdt)
        }
        val projectedPositionQty = input.currentPositionQty + (input.positionDeltaQty ?: input.requestedQty)
        if (kotlin.math.abs(projectedPositionQty) > input.maxPositionQty) {
            return UnifiedRiskDecision(UnifiedRiskStatus.BLOCK, "持仓数量超过限制")
        }
        return UnifiedRiskDecision(UnifiedRiskStatus.ALLOW, "统一风控通过", input.requestedNotionalUsdt)
    }
}
