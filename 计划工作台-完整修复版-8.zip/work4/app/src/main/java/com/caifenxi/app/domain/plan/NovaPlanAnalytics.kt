package com.caifenxi.app.domain.plan

import com.caifenxi.app.domain.engine.PredictEngine
import com.caifenxi.app.domain.model.AlgoMode
import com.caifenxi.app.domain.model.UserPrefs

import com.caifenxi.app.domain.model.DrawRecord
import com.caifenxi.app.domain.model.BetOdds
import com.caifenxi.app.domain.model.LotteryBetRules
import com.caifenxi.app.domain.model.LotteryConfig
import com.caifenxi.app.domain.model.LotteryType
import com.caifenxi.app.domain.model.PlanDefinition
import com.caifenxi.app.data.config.StreakCalc
import kotlin.math.abs
import kotlin.math.pow
import kotlin.math.sqrt

/** NovaPlan 分析层：严格使用 cutoff 之前的数据，避免回测信息泄漏。 */
object NovaPlanAnalytics {
    data class Result(
        val planId: String,
        val output: String,
        val score: Double,
        val sampleCount: Int,
        val baseline: Double,
        val edge: Double,
        val stability: Double
    )

    data class StageReport(
        val stage: Int,
        val periods: Int,
        val hits: Int,
        val misses: Int,
        val hitRate: Double,
        val randomBaseline: Double,
        val edge: Double,
        val maxHitStreak: Int,
        val maxMissStreak: Int,
        val stability: Double
    )

    data class ChartPoint(
        val issue: String,
        val prediction: String,
        val hit: Boolean,
        val stake: Double,
        val periodProfit: Double,
        val cumulativeProfit: Double,
        val peakProfit: Double,
        val troughProfit: Double,
        val drawdown: Double,
        val hitRate: Double
    )

    data class ChartReport(
        val plan: PlanDefinition,
        val periods: Int,
        val stake: Double,
        val points: List<ChartPoint>,
        val hits: Int,
        val misses: Int,
        val totalStake: Double,
        val netProfit: Double,
        val hitRate: Double,
        /** 回测过程中累计对错率的最高值（0~1） */
        val maxHitRate: Double = 0.0,
        /** 回测过程中累计对错率的最低值（0~1） */
        val minHitRate: Double = 0.0,
        val maxHitStreak: Int,
        val maxMissStreak: Int,
        val maxDrawdown: Double,
        val maxPeak: Double,
        val minTrough: Double,
        val currentTrend: String,
        val positionPercent: Double,
        val distanceFromPeak: Double,
        val reboundFromTrough: Double,
        /** 过关斩将（过三关）统计：每次命中后将返还额全部投入下一关。 */
        val guanguanEnabled: Boolean = false,
        val guanguanTarget: Int = 3,
        val guanguanCompleted: Int = 0,
        val guanguanCurrentLevel: Int = 0,
        val guanguanMaxLevel: Int = 0
    )

    data class BacktestReport(
        val planId: String,
        val periods: Int,
        val hits: Int,
        val misses: Int,
        val hitRate: Double,
        val randomBaseline: Double,
        val edge: Double,
        val maxHitStreak: Int,
        val maxMissStreak: Int,
        val stability: Double,
        val stages: Map<Int, StageReport> = emptyMap(),
        /** 与计划引擎/历史页面一致：连续两期/三期滚动窗口统计。 */
        val twoWindows: Int = 0,
        val twoHitWindows: Int = 0,
        val twoMissWindows: Int = 0,
        val twoHitRate: Double = 0.0,
        val twoMissRate: Double = 0.0,
        val threeWindows: Int = 0,
        val threeHitWindows: Int = 0,
        val threeMissWindows: Int = 0,
        val threeHitRate: Double = 0.0,
        val threeMissRate: Double = 0.0
    )

    fun predict(plan: PlanDefinition, history: List<DrawRecord>, outputCount: Int? = null): Result? {
        val data = history.takeLast(plan.window.coerceAtLeast(5))
        if (data.size < 5) return null
        val output = when (plan.playType) {
            "大小", "和值大小" -> directionOutput(plan, data, data.mapNotNull { it.dx }, "大", "小")
            "单双", "和值单双" -> directionOutput(plan, data, data.mapNotNull { it.ds }, "单", "双")
            "组合" -> {
                val type = LotteryConfig.findByKey(data.lastOrNull()?.lotteryKey.orEmpty())?.type
                if (type == LotteryType.YDH) {
                    val seq = data.mapNotNull { r ->
                        val n = r.numbers.getOrNull(0)?.takeIf { it in 1..6 } ?: return@mapNotNull null
                        LotteryBetRules.ydhBallDx(n) + LotteryBetRules.ydhBallDs(n)
                    }
                    topLabels(plan, seq, listOf("大单", "大双", "小单", "小双"), outputCount ?: 3)
                } else comboOutput(plan, data, outputCount ?: 3)
            }
            "数字" -> {
                val type = LotteryConfig.findByKey(data.lastOrNull()?.lotteryKey.orEmpty())?.type
                if (type == LotteryType.PC28) topLabels(plan, data.mapNotNull { it.sum?.toString() }, (0..27).map { it.toString() }, outputCount ?: 3)
                else numberOutput(plan, data, null, outputCount ?: 3)
            }
            "位置" -> numberOutput(plan, data, plan.positionIndex.coerceIn(0, 9), outputCount ?: 3)
            // PK10 名次大小/单双（飞艇/赛车等）：1～5 小、6～10 大
            "名次大小" -> {
                val idx = plan.positionIndex.coerceIn(0, 9)
                val seq = data.mapNotNull { rec ->
                    rec.numbers.getOrNull(idx)?.takeIf { it in 1..10 }?.let { LotteryBetRules.pksRankDx(it) }
                }
                directionOutput(plan, data, seq, "大", "小")
            }
            "名次单双" -> {
                val idx = plan.positionIndex.coerceIn(0, 9)
                val seq = data.mapNotNull { rec ->
                    rec.numbers.getOrNull(idx)?.takeIf { it in 1..10 }?.let { LotteryBetRules.pksRankDs(it) }
                }
                directionOutput(plan, data, seq, "单", "双")
            }
            // 运动会：指定球大小/单双
            "球大小" -> {
                val idx = plan.positionIndex.coerceIn(0, 5)
                val seq = data.mapNotNull { rec ->
                    rec.numbers.getOrNull(idx)?.takeIf { it in 1..6 }?.let { LotteryBetRules.ydhBallDx(it) }
                }
                directionOutput(plan, data, seq, "大", "小")
            }
            "球单双" -> {
                val idx = plan.positionIndex.coerceIn(0, 5)
                val seq = data.mapNotNull { rec ->
                    rec.numbers.getOrNull(idx)?.takeIf { it in 1..6 }?.let { LotteryBetRules.ydhBallDs(it) }
                }
                directionOutput(plan, data, seq, "单", "双")
            }
            "龙虎" -> {
                val pair = plan.positionIndex.coerceIn(0, 2)
                val seq = data.mapNotNull { rec ->
                    if (rec.numbers.size < 6) null else LotteryBetRules.ydhDragonTiger(rec.numbers, pair)
                }
                directionOutput(plan, data, seq, "龙", "虎")
            }
            "定位" -> numberOutput(plan, data, plan.positionIndex.coerceIn(0, 5), outputCount ?: 1)
            // 快三
            "三军", "鱼虾蟹" -> k3PointsOutput(plan, data, outputCount ?: 2)
            "长牌" -> k3ChangPaiOutput(plan, data)
            "和值" -> topLabels(plan, data.mapNotNull { it.sum?.toString() }, (3..18).map { it.toString() }, outputCount ?: 3)
            "位大小" -> positionDirectionOutput(plan, data, "大小")
            "位单双" -> positionDirectionOutput(plan, data, "单双")
            "极值" -> topLabels(plan, data.mapNotNull { pc28Extreme(it.numbers) }, listOf("极小", "极大", "普通"), outputCount ?: 1)
            "对子" -> topLabels(plan, data.mapNotNull { pc28Shape(it.numbers) }.filter { it == "对子" }, listOf("对子"), 1)
            "顺子" -> topLabels(plan, data.mapNotNull { pc28Shape(it.numbers) }.filter { it == "顺子" }, listOf("顺子"), 1)
            "豹子" -> topLabels(plan, data.mapNotNull { pc28Shape(it.numbers) }.filter { it == "豹子" }, listOf("豹子"), 1)
            "二不同号" -> k3PatternOutput(plan, data, "二不同号", outputCount ?: 3)
            "二同号" -> k3PatternOutput(plan, data, "二同号", outputCount ?: 2)
            "三不同号" -> k3PatternOutput(plan, data, "三不同号", outputCount ?: 3)
            "三连号" -> k3PatternOutput(plan, data, "三连号", outputCount ?: 2)
            "三同号" -> k3PatternOutput(plan, data, "三同号", outputCount ?: 2)
            else -> data.lastOrNull()?.dx.orEmpty()
        }.ifBlank { return null }
        val baseline = plan.baselineValue
        val sampleFactor = (data.size.coerceAtMost(200) / 200.0)
        val confidence = algorithmConfidence(plan.algorithm, data, plan.playType)
        val score = (45.0 + sampleFactor * 15.0 + confidence * 20.0).coerceIn(40.0, 85.0)
        return Result(plan.planId, output, score, data.size, baseline, confidence - 0.5, confidence.coerceIn(0.2, 1.0))
    }

    private fun algorithmConfidence(algo: String, data: List<DrawRecord>, playType: String): Double {
        val seq = when (playType) {
            "大小", "和值大小" -> data.mapNotNull { it.dx }
            "单双", "和值单双" -> data.mapNotNull { it.ds }
            "组合" -> data.mapNotNull { it.combo }
            else -> emptyList()
        }
        if (seq.size < 4) return 0.45
        val last = seq.last()
        val share = seq.count { it == last }.toDouble() / seq.size
        return when (algo) {
            "STATE", "FREQ" -> share.coerceIn(0.35, 0.85)
            "EWMA", "WMA", "TREND" -> (0.48 + kotlin.math.abs(share - 0.5) * 0.8).coerceIn(0.40, 0.82)
            "OMIT", "PERIOD" -> (0.52 + (1.0 - share) * 0.12).coerceIn(0.42, 0.75)
            "STREAK", "REVERSAL", "VOLATILITY" -> 0.56
            "TRANSITION", "MARKOV2" -> 0.58
            "HOTCOLD" -> 0.55
            "ENSEMBLE", "ADAPTIVE" -> 0.62
            "RHYTHM" -> if (seq.takeLast(3).distinct().size == 1) 0.72 else 0.48
            "ANOMALY" -> if (share > 0.62 || share < 0.38) 0.70 else 0.42
            "SIMILAR" -> 0.55
            "NETWORK" -> 0.58
            "STRUCT" -> 0.52
            "CANDIDATE" -> 0.50
            "OPTIMIZE" -> 0.54
            "EXPERIENCE" -> 0.60
            "PATTERN" -> 0.58
            "FUSION" -> 0.62
            else -> 0.50
        }
    }

    /**
     * walk-forward 回测：每个 target 只使用 target 之前的数据。
     * 执行周期 cyclePeriods=N：一次预测锁定后续 N 期，N 期内任意一期命中即计为中（常见多期计划口径）。
     * 步进也为 N，避免与一期回测完全同一组样本导致胜率不变。
     * 注意：仅服务新计划页，不写入计划引擎 careerStats。
     */
    fun backtest(plan: PlanDefinition, history: List<DrawRecord>, periods: Int): BacktestReport {
        val cycle = plan.cyclePeriods.coerceIn(1, 20)
        val n = periods.coerceAtLeast(1).coerceAtMost((history.size - 5).coerceAtLeast(1))
        val start = (history.size - n).coerceAtLeast(5)
        var hits = 0
        var misses = 0
        var hitStreak = 0
        var missStreak = 0
        var maxHit = 0
        var maxMiss = 0
        val rates = mutableListOf<Double>()
        var i = start
        while (i < history.size) {
            val prior = history.subList(0, i)
            val p = predict(plan, prior)
            if (p == null) {
                i += 1
                continue
            }
            val end = (i + cycle).coerceAtMost(history.size)
            // N 期内任一期命中 → 中；全部未中 → 错
            var hit = false
            for (j in i until end) {
                if (evaluate(plan, p.output, history[j])) {
                    hit = true
                    break
                }
            }
            if (hit) {
                hits++; hitStreak++; missStreak = 0; maxHit = maxOf(maxHit, hitStreak)
            } else {
                misses++; missStreak++; hitStreak = 0; maxMiss = maxOf(maxMiss, missStreak)
            }
            rates += if (hit) 1.0 else 0.0
            i += cycle
        }
        val total = hits + misses
        val rate = if (total == 0) 0.0 else hits.toDouble() / total
        // 多期计划随机基准随周期提升（近似 1-(1-p)^N）
        val singleBaseline = plan.baselineValue.coerceIn(0.01, 0.99)
        val baseline = if (cycle <= 1) singleBaseline else (1.0 - (1.0 - singleBaseline).pow(cycle))
        val mean = rate
        val variance = if (rates.size < 2) 0.0 else rates.map { (it - mean) * (it - mean) }.average()
        val stability = (1.0 - sqrt(variance) * 2.0).coerceIn(0.0, 1.0)
        val stages = (1..cycle.coerceAtMost(3)).associateWith { stage ->
            stageBacktest(plan, history, periods, stage)
        }
        // 注意：两期/三期不是“第二期/第三期预测”，而是与其他页面完全一致的滚动窗口口径：
        // 连续窗口内至少命中一次 = 对窗口；窗口内全部未命中 = 错窗口。
        val (w2, w2Hit, w2Miss) = StreakCalc.windowRates(rates.map { if (it > 0.5) "对" else "错" }, 2)
        val (w3, w3Hit, w3Miss) = StreakCalc.windowRates(rates.map { if (it > 0.5) "对" else "错" }, 3)
        return BacktestReport(
            plan.planId, total, hits, misses, rate, baseline, rate - baseline, maxHit, maxMiss, stability, stages,
            twoWindows = w2, twoHitWindows = w2Hit, twoMissWindows = w2Miss,
            twoHitRate = if (w2 > 0) w2Hit.toDouble() / w2 else 0.0,
            twoMissRate = if (w2 > 0) w2Miss.toDouble() / w2 else 0.0,
            threeWindows = w3, threeHitWindows = w3Hit, threeMissWindows = w3Miss,
            threeHitRate = if (w3 > 0) w3Hit.toDouble() / w3 else 0.0,
            threeMissRate = if (w3 > 0) w3Miss.toDouble() / w3 else 0.0
        )
    }

    /**
     * 图表回测：输出每个回测单元的累计收益、峰谷、回撤与趋势数据。
     * 仅用于历史统计分析；单注金额只影响理论盈亏，不改变预测结果。
     * 收益口径：命中 +stake，未命中 -stake（等额盈亏基准）。
     */
    fun chartBacktest(
        plan: PlanDefinition,
        history: List<DrawRecord>,
        periods: Int,
        stake: Double,
        stage: Int = 1,
        /** false=正投；true=反投（方向取反后结算） */
        invert: Boolean = false,
        /** 二期/三期内未中后的倍投倍数；组合默认 4，其它默认 2 */
        stageMult: Double = 2.0,
        /** 组合/数字输出条数，与设置 comboPredCount / positionTopN 对齐 */
        outputCount: Int? = null,
        /** 过关斩将：命中后把本关实际返还额全部投入下一关（组合按1:4，其它按实际赔率）；任一关错则本轮结束并从基础注重新开始。 */
        guanguan: Boolean = false,
        /** 目标关数，限制1~10。 */
        guanguanTarget: Int = 3
    ): ChartReport {
        // 严格 walk-forward：按期号升序，以最新已开奖期为终点。
        // 一期：每期独立预测、独立结算；胜率=中期数/总期数。
        // 二期/三期：一次预测锁定，最多追 stage 期；未中倍投；任一期中则本轮「中」，全挂则本轮「挂」。
        // 胜率=中轮数/总轮数（竞品常见口径）。轮与轮不重叠（步进 stage）。
        val ordered = history.sortedWith(compareBy<DrawRecord> { it.issue.toLongOrNull() ?: Long.MIN_VALUE }.thenBy { it.issue })
        val selectedStage = stage.coerceIn(1, 3)
        val targetGuan = guanguanTarget.coerceIn(1, 10)
        // 组合二/三期：固定 4 倍递进（本金→4本→16本…）；其它玩法默认 2 倍
        val mult = when {
            plan.playType == "组合" && selectedStage >= 2 -> 4.0
            else -> stageMult.coerceAtLeast(1.0)
        }
        val amount = stake.coerceAtLeast(0.0)
        val topN = outputCount
        val points = mutableListOf<ChartPoint>()
        var cumulative = 0.0
        var peak = 0.0
        var trough = 0.0
        var hits = 0
        var misses = 0
        var hitStreak = 0
        var missStreak = 0
        var maxHit = 0
        var maxMiss = 0
        var actualTotalStake = 0.0
        var guanStake = amount
        var guanLevel = 0
        var guanCompleted = 0
        var guanMaxLevel = 0
        val maxPoints = periods.coerceAtLeast(1)

        fun legsCount(raw: String): Int {
            val parts = raw.removePrefix("反:").split("/", "、", ",").map { it.trim() }.filter { it.isNotEmpty() }
            return when (plan.playType) {
                "组合" -> parts.count { it in listOf("大单", "大双", "小单", "小双") }.coerceAtLeast(1)
                "数字", "位置", "定位", "三军", "鱼虾蟹" -> parts.size.coerceAtLeast(1)
                "长牌" -> parts.size.coerceAtLeast(1)
                else -> 1
            }
        }
        fun pushPoint(issue: String, out: String, hit: Boolean, unitStake: Double, countInRate: Boolean = true) {
            val lotKey = ordered.firstOrNull()?.lotteryKey.orEmpty()
            val n = legsCount(out)
            // 多注：成本 = n × 单注；组合 1:4 减成本；数字/定位中一注赢赔率、其余注亏本
            // 过关斩将：命中后把本关「实际返还额」全部投入下一关；任一关错则本轮结束并从基础注重新开始。
            // 组合使用真实 1:4 返还（COMBO_RETURN），其它玩法按实际赔率（约 1.98≈2 倍）。
            val periodProfit = if (guanguan) {
                val cost = unitStake * n
                actualTotalStake += cost
                if (hit) {
                    val grossReturn = when (plan.playType) {
                        "组合" -> unitStake * BetOdds.COMBO_RETURN  // 只中一口按 1:4 返还
                        "数字", "位置", "定位", "三军", "鱼虾蟹", "长牌" -> {
                            val odds = BetOdds.forPlay(plan.playType, out, lotKey)
                            // 中一注赢赔率，其余注亏本 → 返还 = 中奖注返还 + 未中注 0
                            unitStake * odds
                        }
                        else -> {
                            val odds = BetOdds.forPlay(plan.playType, out, lotKey)
                            unitStake * odds
                        }
                    }
                    val profit = grossReturn - cost
                    guanLevel += 1
                    guanMaxLevel = maxOf(guanMaxLevel, guanLevel)
                    // 下一关单注 = 本关总返还 / n，使下一关总成本 = 本关总返还（全部滚入）
                    guanStake = if (n > 0) (grossReturn / n).coerceAtLeast(0.0) else grossReturn
                    if (guanLevel >= targetGuan) {
                        guanCompleted += 1
                        guanLevel = 0
                        guanStake = amount
                    }
                    profit
                } else {
                    guanLevel = 0
                    guanStake = amount
                    -cost
                }
            } else when (plan.playType) {
                "组合" -> BetOdds.comboProfit(unitStake, n, hit)
                "数字", "位置", "定位", "三军", "鱼虾蟹", "长牌" -> {
                    val odds = BetOdds.forPlay(plan.playType, out, lotKey)
                    val cost = unitStake * n
                    if (!hit) -cost else unitStake * (odds - 1.0) - unitStake * (n - 1)
                }
                else -> {
                    val odds = BetOdds.forPlay(plan.playType, out, lotKey)
                    if (hit) unitStake * (odds - 1.0) else -unitStake
                }
            }
            if (!guanguan) actualTotalStake += unitStake * n
            cumulative += periodProfit
            peak = maxOf(peak, cumulative)
            trough = minOf(trough, cumulative)
            if (countInRate) {
                if (hit) {
                    hits++; hitStreak++; missStreak = 0; maxHit = maxOf(maxHit, hitStreak)
                } else {
                    misses++; missStreak++; hitStreak = 0; maxMiss = maxOf(maxMiss, missStreak)
                }
            }
            val total = hits + misses
            points += ChartPoint(
                issue = issue,
                prediction = if (invert) "反:$out" else out,
                hit = hit,
                stake = unitStake * n,
                periodProfit = periodProfit,
                cumulativeProfit = cumulative,
                peakProfit = peak,
                troughProfit = trough,
                drawdown = peak - cumulative,
                hitRate = if (total == 0) 0.0 else hits.toDouble() / total
            )
        }

        if (guanguan || selectedStage <= 1) {
            val availableTargets = (ordered.size - 5).coerceAtLeast(0)
            val targetCount = maxPoints.coerceAtMost(availableTargets)
            val firstPredictionIndex = (ordered.size - targetCount).coerceAtLeast(5)
            for (i in firstPredictionIndex until ordered.size) {
                if (points.size >= maxPoints) break
                val prediction = predict(plan, ordered.subList(0, i), topN) ?: continue
                val out = if (invert) invertPrediction(plan.playType, prediction.output) else prediction.output
                val hit = evaluateWithInvert(plan, out, ordered[i], invert)
                pushPoint(ordered[i].issue, out, hit, if (guanguan) guanStake else amount)
            }
        } else {
            // 二期/三期「轮」口径（与主流计划 App 一致）：
            // 一次预测锁定后最多追 selectedStage 期；任一期中 → 本轮记「中」；全挂 → 本轮记「挂」。
            // 胜率 = 中轮 / 总轮，不再把每一注拆成独立胜负（否则会与一期几乎相同，看起来像算错）。
            // 历史曲线仍按每期 push 点（不计入 hits/misses），资金倍投逻辑不变。
            val lastStart = (ordered.size - selectedStage).coerceAtLeast(5)
            val approxCycles = (maxPoints + selectedStage - 1) / selectedStage
            var i = (ordered.size - approxCycles * selectedStage).coerceAtLeast(5)
            while (i <= lastStart && (hits + misses) < maxPoints) {
                val prediction = predict(plan, ordered.subList(0, i), topN)
                if (prediction == null) {
                    i += 1
                    continue
                }
                val out = if (invert) invertPrediction(plan.playType, prediction.output) else prediction.output
                var unitStake = amount
                var roundHit = false
                for (k in 0 until selectedStage) {
                    val targetIndex = i + k
                    if (targetIndex >= ordered.size) break
                    val hit = evaluateWithInvert(plan, out, ordered[targetIndex], invert)
                    // 期点入库但不计入胜率分子分母
                    pushPoint(ordered[targetIndex].issue, out, hit, unitStake, countInRate = false)
                    if (hit) {
                        roundHit = true
                        break
                    }
                    unitStake *= mult
                }
                if (roundHit) {
                    hits++; hitStreak++; missStreak = 0; maxHit = maxOf(maxHit, hitStreak)
                } else {
                    misses++; missStreak++; hitStreak = 0; maxMiss = maxOf(maxMiss, missStreak)
                }
                // 同步最后一点的 hitRate 展示为轮胜率
                if (points.isNotEmpty()) {
                    val totalR = hits + misses
                    val last = points.last()
                    points[points.lastIndex] = last.copy(
                        hitRate = if (totalR == 0) 0.0 else hits.toDouble() / totalR
                    )
                }
                i += selectedStage
            }
        }

        val maxPeak = points.maxOfOrNull { it.cumulativeProfit } ?: 0.0
        val minTrough = points.minOfOrNull { it.cumulativeProfit } ?: 0.0
        val current = points.lastOrNull()?.cumulativeProfit ?: 0.0
        val range = (maxPeak - minTrough).coerceAtLeast(0.0)
        var runningPeak = 0.0
        var observedMaxDrawdown = 0.0
        points.forEach { point ->
            runningPeak = maxOf(runningPeak, point.cumulativeProfit)
            observedMaxDrawdown = maxOf(observedMaxDrawdown, runningPeak - point.cumulativeProfit)
        }
        val position = if (range <= 0.0) 50.0 else ((current - minTrough) / range * 100.0).coerceIn(0.0, 100.0)
        val distancePeak = maxPeak - current
        val rebound = current - minTrough
        val nearHigh = range > 0.0 && position >= 70.0
        val nearLow = range > 0.0 && position <= 30.0
        val previousMax = if (points.size > 1) points.dropLast(1).maxOfOrNull { it.cumulativeProfit } ?: current else current
        val previousMin = if (points.size > 1) points.dropLast(1).minOfOrNull { it.cumulativeProfit } ?: current else current
        val trend = when {
            points.isEmpty() -> "暂无数据"
            points.size > 1 && current > previousMax -> "↑ 创新高"
            points.size > 1 && current < previousMin -> "↓ 创新低"
            nearHigh && distancePeak > 0 -> "↓ 高位回落"
            nearHigh -> "→ 高位震荡"
            nearLow && rebound > 0 -> "↑ 低位反弹"
            nearLow -> "→ 低位震荡"
            points.size >= 2 && current > points[points.lastIndex - 1].cumulativeProfit -> "↑ 上升趋势"
            points.size >= 2 && current < points[points.lastIndex - 1].cumulativeProfit -> "↓ 下降趋势"
            else -> "→ 横盘震荡"
        }
        val rateSeries = points.map { it.hitRate }
        val maxHr = rateSeries.maxOrNull() ?: 0.0
        val minHr = rateSeries.minOrNull() ?: 0.0
        val displayPlan = if (invert) plan.copy(
            planId = plan.planId + "-REV",
            planName = plan.planName + "·反投"
        ) else plan.copy(planName = plan.planName + "·正投")
        return ChartReport(
            plan = displayPlan, periods = points.size, stake = amount, points = points, hits = hits, misses = misses,
            totalStake = actualTotalStake, netProfit = cumulative,
            hitRate = if (hits + misses == 0) 0.0 else hits.toDouble() / (hits + misses),
            maxHitRate = maxHr, minHitRate = minHr,
            maxHitStreak = maxHit, maxMissStreak = maxMiss,
            maxDrawdown = observedMaxDrawdown, maxPeak = maxPeak, minTrough = minTrough,
            currentTrend = trend, positionPercent = position, distanceFromPeak = distancePeak, reboundFromTrough = rebound,
            guanguanEnabled = guanguan, guanguanTarget = targetGuan, guanguanCompleted = guanCompleted,
            guanguanCurrentLevel = guanLevel, guanguanMaxLevel = guanMaxLevel
        )
    }

    /**
     * 共识来源历史回测：按目标期聚合大小/单双/组合等共识记录，
     * 一期一计；该期所有已保存共识分类均命中才记为“对”。只取最新已结算期向前的连续样本。
     */
    /**
     * 共识回测：按「大小 / 单双 / 组合」分类分别结算（一期一类一计），
     * 不再要求同一期所有分类全对才算对。
     * @param categories 为空时默认三类都回测；可只传需要的分类。
     */
    fun chartBacktestConsensus(
        sourceLabel: String,
        records: List<com.caifenxi.app.domain.model.ConsensusRecord>,
        periods: Int,
        stake: Double,
        categories: List<String> = listOf("大小", "单双", "组合"),
        invert: Boolean = false,
        guanguan: Boolean = false,
        guanguanTarget: Int = 3
    ): List<ChartReport> {
        val want = categories.map { it.trim() }.filter { it.isNotEmpty() }.ifEmpty { listOf("大小", "单双", "组合") }
        return want.mapNotNull { cat -> chartBacktestConsensusCategory(sourceLabel, records, periods, stake, cat, invert, guanguan, guanguanTarget) }
    }

    /** 单分类共识回测：只使用该 category 的已结算记录，按期号从最新往前取 periods 期。 */
    fun chartBacktestConsensusCategory(
        sourceLabel: String,
        records: List<com.caifenxi.app.domain.model.ConsensusRecord>,
        periods: Int,
        stake: Double,
        category: String,
        invert: Boolean = false,
        guanguan: Boolean = false,
        guanguanTarget: Int = 3
    ): ChartReport? {
        val settled = records
            .filter { it.category == category && (it.result == "对" || it.result == "错") }
            .sortedWith(
                compareBy<com.caifenxi.app.domain.model.ConsensusRecord> {
                    it.targetIssue.toLongOrNull() ?: Long.MIN_VALUE
                }.thenBy { it.targetIssue }.thenBy { it.createdAt }
            )
            .let { list ->
                // 同一期同一分类若有多条，取最新一条
                list.groupBy { it.targetIssue }
                    .mapValues { (_, rows) -> rows.maxByOrNull { it.settledAt ?: it.createdAt }!! }
                    .values
                    .sortedWith(
                        compareBy<com.caifenxi.app.domain.model.ConsensusRecord> {
                            it.targetIssue.toLongOrNull() ?: Long.MIN_VALUE
                        }.thenBy { it.targetIssue }
                    )
                    .takeLast(periods.coerceAtLeast(1))
            }
        if (settled.isEmpty()) return null
        val amount = stake.coerceAtLeast(0.0)
        val targetGuan = guanguanTarget.coerceIn(1, 10)
        var cumulative = 0.0
        var peak = 0.0
        var trough = 0.0
        var hits = 0
        var misses = 0
        var hitStreak = 0
        var missStreak = 0
        var maxHit = 0
        var maxMiss = 0
        var actualTotalStake = 0.0
        var guanStake = amount
        var guanLevel = 0
        var guanCompleted = 0
        var guanMaxLevel = 0
        val points = settled.map { row ->
            val baseHit = row.result == "对"
            val hit = if (invert) !baseHit else baseHit
            val shownPred = if (invert) {
                "反:" + invertPrediction(category, row.leadingDirection)
            } else {
                "${row.category}:${row.leadingDirection}"
            }
            val predForOdds = if (invert) invertPrediction(category, row.leadingDirection) else row.leadingDirection
            val isCombo = category == "组合" || category.contains("组合")
            val n = if (isCombo) {
                predForOdds.split("/", "、", ",")
                    .map { it.trim() }.count { it in listOf("大单", "大双", "小单", "小双") }
                    .coerceAtLeast(1)
            } else 1
            val unit = if (guanguan) guanStake else amount
            val cost = unit * n
            val rowStake = cost
            val profit = if (guanguan) {
                actualTotalStake += cost
                if (hit) {
                    val grossReturn = if (isCombo) {
                        unit * BetOdds.COMBO_RETURN
                    } else {
                        val odds = BetOdds.forPlay(category, predForOdds, "")
                        unit * odds
                    }
                    val p = grossReturn - cost
                    guanLevel += 1
                    guanMaxLevel = maxOf(guanMaxLevel, guanLevel)
                    // 下一关单注 = 本关总返还 / n，总成本 = 本关总返还（全部滚入）
                    guanStake = if (n > 0) (grossReturn / n).coerceAtLeast(0.0) else grossReturn
                    if (guanLevel >= targetGuan) {
                        guanCompleted += 1
                        guanLevel = 0
                        guanStake = amount
                    }
                    p
                } else {
                    guanLevel = 0
                    guanStake = amount
                    -cost
                }
            } else if (isCombo) {
                BetOdds.comboProfit(amount, n, hit)
            } else {
                val odds = BetOdds.forPlay(category, predForOdds, "")
                if (hit) amount * (odds - 1.0) else -amount
            }
            if (!guanguan) actualTotalStake += amount * n
            cumulative += profit
            peak = maxOf(peak, cumulative)
            trough = minOf(trough, cumulative)
            if (hit) {
                hits++; hitStreak++; missStreak = 0; maxHit = maxOf(maxHit, hitStreak)
            } else {
                misses++; missStreak++; hitStreak = 0; maxMiss = maxOf(maxMiss, missStreak)
            }
            val total = hits + misses
            ChartPoint(
                issue = row.targetIssue,
                prediction = shownPred,
                hit = hit,
                stake = rowStake,
                periodProfit = profit,
                cumulativeProfit = cumulative,
                peakProfit = peak,
                troughProfit = trough,
                drawdown = peak - cumulative,
                hitRate = if (total == 0) 0.0 else hits.toDouble() / total
            )
        }
        val maxPeak = points.maxOfOrNull { it.cumulativeProfit } ?: 0.0
        val minTrough = points.minOfOrNull { it.cumulativeProfit } ?: 0.0
        val current = points.lastOrNull()?.cumulativeProfit ?: 0.0
        val range = (maxPeak - minTrough).coerceAtLeast(0.0)
        val position = if (range == 0.0) 50.0 else ((current - minTrough) / range * 100.0).coerceIn(0.0, 100.0)
        val previousMax = points.dropLast(1).maxOfOrNull { it.cumulativeProfit } ?: current
        val previousMin = points.dropLast(1).minOfOrNull { it.cumulativeProfit } ?: current
        val trend = when {
            points.size > 1 && current > previousMax -> "↑ 创新高"
            points.size > 1 && current < previousMin -> "↓ 创新低"
            points.size > 1 && current > points[points.lastIndex - 1].cumulativeProfit -> "↑ 上升趋势"
            points.size > 1 && current < points[points.lastIndex - 1].cumulativeProfit -> "↓ 下降趋势"
            else -> "→ 横盘震荡"
        }
        val plan = PlanDefinition(
            planId = "CONSENSUS-$category-$sourceLabel" + if (invert) "-REV" else "",
            planName = "$sourceLabel·$category" + if (invert) "·反投" else "·正投",
            category = "共识",
            algorithm = "CONSENSUS",
            window = points.size.coerceAtLeast(1),
            playType = category,
            baselineValue = if (category == "组合") 0.25 else 0.50
        )
        val rateSeries = points.map { it.hitRate }
        return ChartReport(
            plan = plan,
            periods = points.size,
            stake = amount,
            points = points,
            hits = hits,
            misses = misses,
            totalStake = actualTotalStake,
            netProfit = cumulative,
            hitRate = if (hits + misses == 0) 0.0 else hits.toDouble() / (hits + misses),
            maxHitRate = rateSeries.maxOrNull() ?: 0.0,
            minHitRate = rateSeries.minOrNull() ?: 0.0,
            maxHitStreak = maxHit,
            maxMissStreak = maxMiss,
            maxDrawdown = points.maxOfOrNull { it.drawdown } ?: 0.0,
            maxPeak = maxPeak,
            minTrough = minTrough,
            currentTrend = trend,
            positionPercent = position,
            distanceFromPeak = maxPeak - current,
            reboundFromTrough = current - minTrough,
            guanguanEnabled = guanguan, guanguanTarget = targetGuan, guanguanCompleted = guanCompleted,
            guanguanCurrentLevel = guanLevel, guanguanMaxLevel = guanMaxLevel
        )
    }


    /**
     * 单独统计首期/二期/三期。每一期都以同一条“预测锁定”作为起点，
     * 只结算该期对应的开奖结果，不把其它期的结果混入。
     */
    fun stageBacktest(plan: PlanDefinition, history: List<DrawRecord>, periods: Int, stage: Int): StageReport {
        val s = stage.coerceIn(1, 3)
        val n = periods.coerceAtLeast(1).coerceAtMost((history.size - 5 - (s - 1)).coerceAtLeast(1))
        val start = (history.size - n - (s - 1)).coerceAtLeast(5)
        var hits = 0
        var misses = 0
        var hitStreak = 0
        var missStreak = 0
        var maxHit = 0
        var maxMiss = 0
        val rates = mutableListOf<Double>()
        for (i in start until history.size) {
            val target = i + s - 1
            if (target >= history.size) break
            val p = predict(plan, history.subList(0, i)) ?: continue
            val hit = evaluate(plan, p.output, history[target])
            if (hit) {
                hits++; hitStreak++; missStreak = 0; maxHit = maxOf(maxHit, hitStreak)
            } else {
                misses++; missStreak++; hitStreak = 0; maxMiss = maxOf(maxMiss, missStreak)
            }
            rates += if (hit) 1.0 else 0.0
        }
        val total = hits + misses
        val rate = if (total == 0) 0.0 else hits.toDouble() / total
        val baseline = plan.baselineValue.coerceIn(0.01, 0.99)
        val mean = rate
        val variance = if (rates.size < 2) 0.0 else rates.map { (it - mean) * (it - mean) }.average()
        val stability = (1.0 - sqrt(variance) * 2.0).coerceIn(0.0, 1.0)
        return StageReport(s, total, hits, misses, rate, baseline, rate - baseline, maxHit, maxMiss, stability)
    }

    /** 数字/位置反投：预测文案不变，对错取反；方向类已在 invertPrediction 翻转文案。 */
    private fun evaluateWithInvert(
        plan: PlanDefinition,
        output: String,
        actual: DrawRecord,
        invert: Boolean
    ): Boolean {
        val base = evaluate(plan, output, actual)
        return if (invert && plan.playType in listOf("数字", "位置", "定位", "三军", "鱼虾蟹", "长牌")) !base else base
    }

    /** 正投/反投：对方向类预测取反（大小、单双、组合候选）。 */
    fun invertPrediction(playType: String, output: String): String {
        if (output.isBlank()) return output
        return when (playType) {
            "大小", "和值大小", "球大小", "名次大小" -> output.split("/", "、", ",", " ").map { it.trim() }.filter { it.isNotEmpty() }
                .joinToString("/") {
                    when (it) {
                        "大" -> "小"
                        "小" -> "大"
                        else -> it
                    }
                }
            "单双", "球单双", "名次单双" -> output.split("/", "、", ",", " ").map { it.trim() }.filter { it.isNotEmpty() }
                .joinToString("/") {
                    when (it) {
                        "单" -> "双"
                        "双" -> "单"
                        else -> it
                    }
                }
            "组合" -> output.split("/", "、", ",", " ").map { it.trim() }.filter { it.isNotEmpty() }
                .joinToString("/") { token ->
                    token.map { c ->
                        when (c) {
                            '大' -> '小'
                            '小' -> '大'
                            '单' -> '双'
                            '双' -> '单'
                            else -> c
                        }
                    }.joinToString("")
                }
            "球大小", "和值大小" -> output.split("/", "、", ",").map { it.trim() }.filter { it.isNotEmpty() }
                .joinToString("/") { if (it == "大") "小" else if (it == "小") "大" else it }
            // 名次大小/单双已在上方与大小/单双合并处理
            "球单双" -> output.split("/", "、", ",").map { it.trim() }.filter { it.isNotEmpty() }
                .joinToString("/") { if (it == "单") "双" else if (it == "双") "单" else it }
            "龙虎" -> output.split("/", "、", ",").map { it.trim() }.filter { it.isNotEmpty() }
                .joinToString("/") { if (it == "龙") "虎" else if (it == "虎") "龙" else it }
            else -> output // 定位/三军等反投由 evaluateWithInvert 对错取反
        }.ifBlank { output }
    }

    private fun evaluate(plan: PlanDefinition, output: String, actual: DrawRecord): Boolean {
        val parts = output.split("/", "、", ",").map { it.trim() }.filter { it.isNotEmpty() }
        return when (plan.playType) {
            "大小", "和值大小" -> parts.any { it == actual.dx }
            "单双" -> parts.any { it == actual.ds }
            "组合" -> parts.any { it == actual.combo }
            "数字" -> {
                val type = LotteryConfig.findByKey(actual.lotteryKey)?.type
                if (type == LotteryType.PC28) parts.any { it.toIntOrNull() == actual.sum }
                else parts.any { it.toIntOrNull()?.let { n -> n in actual.numbers } == true }
            }
            "位置", "定位" -> {
                if (actual.numbers.isEmpty()) return false
                val index = plan.positionIndex.coerceIn(0, actual.numbers.lastIndex)
                val n = actual.numbers.getOrNull(index) ?: return false
                parts.any { it.toIntOrNull() == n }
            }
            "名次大小" -> {
                val idx = plan.positionIndex.coerceIn(0, 9)
                val n = actual.numbers.getOrNull(idx) ?: return false
                parts.any { it == LotteryBetRules.pksRankDx(n) }
            }
            "名次单双" -> {
                val idx = plan.positionIndex.coerceIn(0, 9)
                val n = actual.numbers.getOrNull(idx) ?: return false
                parts.any { it == LotteryBetRules.pksRankDs(n) }
            }
            "球大小" -> {
                val idx = plan.positionIndex.coerceIn(0, 5)
                val ball = actual.numbers.getOrNull(idx) ?: return false
                parts.any { it == LotteryBetRules.ydhBallDx(ball) }
            }
            "球单双" -> {
                val idx = plan.positionIndex.coerceIn(0, 5)
                val ball = actual.numbers.getOrNull(idx) ?: return false
                parts.any { it == LotteryBetRules.ydhBallDs(ball) }
            }
            "龙虎" -> {
                val dt = LotteryBetRules.ydhDragonTiger(actual.numbers, plan.positionIndex.coerceIn(0, 2))
                    ?: return false // 相等不中
                parts.any { it == dt }
            }
            "三军", "鱼虾蟹" -> parts.any { it.toIntOrNull()?.let { n -> LotteryBetRules.k3SanJunHit(actual.numbers, n) } == true }
            "长牌" -> {
                parts.any { token ->
                    val ab = token.split("-", "/").mapNotNull { it.trim().toIntOrNull() }
                    ab.size >= 2 && LotteryBetRules.k3ChangPaiHit(actual.numbers, ab[0], ab[1])
                }
            }
            "和值" -> parts.any { it.toIntOrNull() == actual.sum }
            "位大小" -> {
                val n = actual.numbers.getOrNull(plan.positionIndex.coerceIn(0, actual.numbers.lastIndex)) ?: return false
                val type = LotteryConfig.findByKey(actual.lotteryKey)?.type
                val big = when (type) {
                    LotteryType.YDH, LotteryType.K3 -> n >= 4
                    LotteryType.PKS -> n >= 6
                    else -> n >= 5
                }
                parts.any { it == if (big) "大" else "小" }
            }
            "位单双" -> {
                val n = actual.numbers.getOrNull(plan.positionIndex.coerceIn(0, actual.numbers.lastIndex)) ?: return false
                parts.any { it == if (n % 2 == 1) "单" else "双" }
            }
            "极值" -> parts.any { it == pc28Extreme(actual.numbers) }
            "对子", "顺子", "豹子" -> parts.any { it == pc28Shape(actual.numbers) }
            "二不同号", "二同号", "三不同号", "三连号", "三同号" -> parts.any { it == k3Pattern(actual.numbers, plan.playType) }
            else -> false
        }
    }


    private fun positionDirectionOutput(plan: PlanDefinition, data: List<DrawRecord>, mode: String): String {
        val idx = plan.positionIndex.coerceAtLeast(0)
        val seq = data.mapNotNull { rec ->
            val n = rec.numbers.getOrNull(idx) ?: return@mapNotNull null
            val type = LotteryConfig.findByKey(rec.lotteryKey)?.type
            when {
                mode == "大小" && type == LotteryType.YDH -> if (n >= 4) "大" else "小"
                mode == "大小" && type == LotteryType.K3 -> if (n >= 4) "大" else "小"
                mode == "大小" && type == LotteryType.PKS -> if (n >= 6) "大" else "小"
                mode == "大小" -> if (n >= 5) "大" else "小"
                mode == "单双" -> if (n % 2 == 1) "单" else "双"
                else -> null
            }
        }
        val labels = if (mode == "大小") listOf("大", "小") else listOf("单", "双")
        return directionOutput(plan, data, seq, labels[0], labels[1])
    }

    private fun pc28Extreme(numbers: List<Int>): String? {
        if (numbers.size < 3 || numbers.any { it !in 0..9 }) return null
        return when (numbers.take(3).sum()) {
            in 0..5 -> "极小"
            in 22..27 -> "极大"
            else -> "普通"
        }
    }

    private fun pc28Shape(numbers: List<Int>): String? {
        if (numbers.size < 3 || numbers.any { it !in 0..9 }) return null
        val n = numbers.take(3).sorted()
        return when {
            n[0] == n[1] && n[1] == n[2] -> "豹子"
            n[0] == n[1] || n[1] == n[2] -> "对子"
            n[0] + 1 == n[1] && n[1] + 1 == n[2] -> "顺子"
            else -> "杂六"
        }
    }

    private fun k3PatternOutput(plan: PlanDefinition, data: List<DrawRecord>, type: String, topN: Int): String {
        val labels = data.mapNotNull { k3Pattern(it.numbers, type) }
        if (labels.isEmpty()) return ""
        val counts = labels.groupingBy { it }.eachCount()
        return counts.entries.sortedWith(
            compareByDescending<Map.Entry<String, Int>> { it.value }.thenBy { saltTie(it.key, planSalt(plan)) }
        ).take(topN.coerceAtLeast(1)).joinToString("/") { it.key }
    }

    private fun k3Pattern(numbers: List<Int>, type: String): String? {
        if (numbers.size < 3 || numbers.any { it !in 1..6 }) return null
        val n = numbers.take(3).sorted()
        return when (type) {
            "二不同号" -> if (n.distinct().size >= 2) "${n[0]}-${n[1]}" else null
            "二同号" -> if (n[0] == n[1]) "${n[0]}-${n[0]}" else if (n[1] == n[2]) "${n[1]}-${n[1]}" else null
            "三不同号" -> if (n.distinct().size == 3) n.joinToString("") else null
            "三连号" -> if (n[0] + 1 == n[1] && n[1] + 1 == n[2]) n.joinToString("") else null
            "三同号" -> if (n[0] == n[2]) n[0].toString() + n[0] + n[0] else null
            else -> null
        }
    }

    /** 快三三军/鱼虾蟹：输出 TopN 点数（合并为一注时由条数决定） */
    private fun k3PointsOutput(plan: PlanDefinition, data: List<DrawRecord>, topN: Int): String {
        val n = topN.coerceIn(1, 6)
        val freq = IntArray(7)
        data.forEach { rec ->
            rec.numbers.filter { it in 1..6 }.forEach { freq[it]++ }
        }
        // 简单频率 + 计划盐
        val ranked = (1..6).sortedWith(
            compareByDescending<Int> { freq[it] }
                .thenBy { (it * 17 + plan.planId.hashCode()).and(0x7fffffff) % 6 }
        )
        return ranked.take(n).joinToString("/")
    }

    /** 长牌：选一对不同点数（频率高且不同） */
    private fun k3ChangPaiOutput(plan: PlanDefinition, data: List<DrawRecord>): String {
        val freq = IntArray(7)
        data.forEach { rec ->
            rec.numbers.filter { it in 1..6 }.forEach { freq[it]++ }
        }
        val ranked = (1..6).sortedByDescending { freq[it] }
        if (ranked.size < 2) return "1-2"
        val a = ranked[0]
        val b = ranked.firstOrNull { it != a } ?: ((a % 6) + 1)
        return "$a-$b"
    }

    private fun directionOutput(
        plan: PlanDefinition,
        data: List<DrawRecord>,
        seq: List<String>,
        a: String,
        b: String
    ): String {
        if (seq.isEmpty()) return ""
        // 每计划独立回看长度与 tie-break，避免同算法+同玩法输出完全一致
        val lookback = planLookback(plan)
        val salt = planSalt(plan)
        // 经验学习 / 形态匹配：走预测引擎正式算法，与预测页/挂机同源
        when (plan.algorithm) {
            "EXPERIENCE" -> return PredictEngine.predictLabel(
                seq, listOf(a, b), UserPrefs(predictionWindow = plan.window.coerceIn(20, 500)), AlgoMode.EXPERIENCE
            )
            "PATTERN" -> return PredictEngine.predictLabel(
                seq, listOf(a, b), UserPrefs(predictionWindow = plan.window.coerceIn(20, 500)), AlgoMode.PATTERN
            )
            "FUSION" -> return PredictEngine.predictLabel(
                seq, listOf(a, b), UserPrefs(predictionWindow = plan.window.coerceIn(20, 500)), AlgoMode.FUSION
            )
        }
        return when (plan.algorithm) {
            "FREQ", "STATE" -> state(seq, lookback, salt)
            "EWMA" -> ewmaDirection(seq, a, b, lookback)
            "WMA" -> wmaDirection(seq, a, b, lookback)
            "OMIT", "YILOU" -> omitDirection(seq, a, b, lookback)
            "HOTCOLD" -> hotColdDirection(seq, a, b, lookback, salt)
            "STREAK", "CHANGLOONG" -> streakDirection(seq, a, b, salt)
            "TRANSITION" -> transitionDirection(seq, a, b, lookback, salt)
            "MARKOV2" -> markov2Direction(seq, a, b, lookback, salt)
            "PERIOD", "DINGBAN" -> periodDirection(seq, a, b, lookback, salt)
            "TREND" -> trendDirection(seq, a, b, lookback)
            "REVERSAL", "FANZHU" -> reversalDirection(seq, a, b, salt)
            "VOLATILITY" -> volatilityDirection(seq, a, b, lookback, salt)
            "RHYTHM" -> rhythm(seq, a, b, lookback, salt)
            "SIMILAR" -> similarDirection(seq, lookback, salt)
            "NETWORK" -> network(seq, a, b, lookback, salt)
            "STRUCT" -> struct(seq, a, b, lookback, salt)
            "ANOMALY" -> anomaly(seq, a, b, lookback, salt)
            "CANDIDATE" -> candidate(seq, a, b, lookback, salt)
            "OPTIMIZE" -> optimize(seq, a, b, lookback, salt)
            "ENSEMBLE" -> ensembleDirection(seq, a, b, lookback, salt)
            "ADAPTIVE" -> adaptiveDirection(seq, a, b, lookback, salt)
            // —— 主流计划 App 常见口径 ——
            "LUZHU" -> luzhuDirection(seq, a, b, salt)          // 路珠：跟当前一路/长龙
            "GENZHU" -> genzhuDirection(seq, a, b, salt)        // 连中跟，连挂反
            "SHUANGZHU" -> zhuFanDirection(seq, a, b, 2)        // 双珠后反向（✔✘✘后）
            "SANZHU" -> zhuFanDirection(seq, a, b, 3)            // 三珠后反向
            "YILOU_BU" -> omitDirection(seq, a, b, lookback)    // 遗漏回补
            "SHA_RE" -> shaReDirection(seq, a, b, lookback)     // 杀热：压近期少的一侧
            else -> state(seq, lookback, salt)
        }
    }

    private fun planLookback(plan: PlanDefinition): Int {
        val base = plan.window.coerceIn(5, 80)
        // 算法与 planId 微调，拉开同窗口计划差异
        val adj = (kotlin.math.abs(plan.planId.hashCode()) % 7) - 3
        return (base / 2 + adj).coerceIn(4, base)
    }

    private fun planSalt(plan: PlanDefinition): Int =
        kotlin.math.abs(plan.planId.hashCode() * 31 + plan.window * 17 + plan.algorithm.hashCode())

    private fun topLabels(plan: PlanDefinition, seq: List<String>, labels: List<String>, topN: Int): String {
        if (seq.isEmpty()) return ""
        val n = topN.coerceIn(1, labels.size)
        val lookback = planLookback(plan)
        val sample = seq.takeLast(lookback.coerceAtLeast(4))
        val counts = sample.groupingBy { it }.eachCount()
        fun score(label: String): Double {
            val c = counts[label] ?: 0
            return (when (plan.algorithm) {
                "EWMA" -> sample.asReversed().foldIndexed(0.0) { i, acc, v -> acc + if (v == label) 0.88.pow(i + 1) else 0.0 }
                "WMA", "TREND" -> sample.foldIndexed(0.0) { i, acc, v -> acc + if (v == label) i + 1.0 else 0.0 }
                "OMIT" -> -c.toDouble()
                "HOTCOLD" -> {
                    val half = (sample.size / 2).coerceAtLeast(1); val short = sample.takeLast(half).count { it == label }; short * 0.7 + c * 0.3
                }
                "STREAK", "REVERSAL" -> if (sample.lastOrNull() == label) c.toDouble() + 2.0 else c.toDouble()
                "TRANSITION", "MARKOV2" -> {
                    val last = sample.lastOrNull(); sample.zipWithNext().count { it.first == last && it.second == label }.toDouble()
                }
                "ANOMALY" -> kotlin.math.abs(c.toDouble() - sample.size.toDouble() / labels.size.toDouble())
                "CANDIDATE", "OPTIMIZE" -> c.toDouble() * 0.8 + (kotlin.math.abs(label.hashCode()) % 7) * 0.02
                else -> c.toDouble()
            }).toDouble()
        }
        return labels.sortedWith(compareByDescending<String> { score(it) }.thenBy { saltTie(it, planSalt(plan)) }).take(n).joinToString("/")
    }

    private fun comboOutput(plan: PlanDefinition, data: List<DrawRecord>, topN: Int): String {
        val lookback = planLookback(plan)
        val salt = planSalt(plan)
        val seq = data.mapNotNull { it.combo }.takeLast(lookback.coerceAtLeast(8))
        if (seq.isEmpty()) return ""
        val n = topN.coerceIn(1, 4)
        val comboLabels = listOf("大单", "大双", "小单", "小双")
        if (plan.algorithm == "EXPERIENCE" || plan.algorithm == "PATTERN" || plan.algorithm == "FUSION") {
            val mode = when (plan.algorithm) {
                "PATTERN" -> AlgoMode.PATTERN
                "FUSION" -> AlgoMode.FUSION
                else -> AlgoMode.EXPERIENCE
            }
            val prefs = UserPrefs(predictionWindow = plan.window.coerceIn(20, 500), comboPredCount = n)
            return PredictEngine.predictTopLabels(seq, comboLabels, prefs, mode, n).joinToString("/")
        }
        val counts = seq.groupingBy { it }.eachCount()
        val ranked = when (plan.algorithm) {
            "RHYTHM" -> {
                if (seq.size >= 3 && seq.takeLast(3).distinct().size == 1) {
                    counts.entries.sortedWith(compareBy<Map.Entry<String, Int>> { it.value }.thenBy { saltTie(it.key, salt) }).map { it.key }
                } else {
                    counts.entries.sortedWith(compareByDescending<Map.Entry<String, Int>> { it.value }.thenBy { saltTie(it.key, salt) }).map { it.key }
                }
            }
            "ANOMALY" -> {
                val avg = counts.values.average()
                counts.entries.sortedWith(
                    compareByDescending<Map.Entry<String, Int>> { kotlin.math.abs(it.value - avg) }
                        .thenBy { saltTie(it.key, salt) }
                ).map { it.key }
            }
            "NETWORK", "STRUCT" -> {
                val last = seq.last()
                val nextCounts = mutableMapOf<String, Int>()
                for (i in 1 until seq.size) {
                    if (seq[i - 1] == last) nextCounts[seq[i]] = (nextCounts[seq[i]] ?: 0) + 1
                }
                if (nextCounts.isNotEmpty()) {
                    nextCounts.entries.sortedByDescending { it.value }.map { it.key } +
                        counts.keys.filter { it !in nextCounts }.sortedBy { saltTie(it, salt) }
                } else {
                    counts.entries.sortedByDescending { it.value }.map { it.key }
                }
            }
            "CANDIDATE", "OPTIMIZE" -> {
                val hot = counts.entries.sortedWith(
                    compareByDescending<Map.Entry<String, Int>> { it.value }.thenBy { saltTie(it.key, salt) }
                ).map { it.key }
                // 按 salt 旋转起点，同热度下不同计划取不同组合顺序
                if (hot.isEmpty()) hot else {
                    val rot = salt % hot.size
                    hot.drop(rot) + hot.take(rot)
                }
            }
            else -> counts.entries.sortedWith(
                compareByDescending<Map.Entry<String, Int>> { it.value }.thenBy { saltTie(it.key, salt) }
            ).map { it.key }
        }
        return ranked.distinct().take(n).joinToString("/")
    }

    private fun saltTie(key: String, salt: Int): Int =
        kotlin.math.abs(key.hashCode() xor salt)

    private fun numberOutput(plan: PlanDefinition, data: List<DrawRecord>, position: Int?, topN: Int): String {
        val salt = planSalt(plan)
        val counts = mutableMapOf<Int, Double>()
        data.forEachIndexed { index, row ->
            val nums = if (position == null) row.numbers else listOfNotNull(row.numberAt(position))
            val progress = index.toDouble() / data.size.coerceAtLeast(1)
            val decay = when (plan.algorithm) {
                "RHYTHM" -> 0.6 + progress * 1.0
                "EWMA" -> 0.45 + progress * 1.5
                "WMA", "TREND" -> 0.5 + progress * 1.2
                "OMIT", "PERIOD" -> 1.2 - progress * 0.4
                "HOTCOLD" -> 0.8 + progress * 0.7
                "STREAK", "REVERSAL" -> 0.7 + progress * 0.8
                "TRANSITION", "MARKOV2" -> 0.9 + progress * 0.6
                "ENSEMBLE", "ADAPTIVE" -> 0.85 + progress * 0.9
                "ANOMALY" -> 1.2 - progress * 0.5
                "SIMILAR", "NETWORK" -> 0.7 + progress * 0.9
                "STRUCT" -> if (index >= data.size - 5) 1.4 else 0.8
                "CANDIDATE" -> 1.0 + (salt % 5) * 0.02
                "OPTIMIZE" -> 0.9 + progress * 0.4
                else -> 1.0
            }
            nums.forEach { n -> counts[n] = (counts[n] ?: 0.0) + decay }
        }
        if (counts.isEmpty()) return ""
        val ranked = when (plan.algorithm) {
            "ANOMALY" -> {
                val avg = counts.values.average()
                counts.entries.sortedWith(
                    compareByDescending<Map.Entry<Int, Double>> { kotlin.math.abs(it.value - avg) }
                        .thenBy { saltTie(it.key.toString(), salt) }
                )
            }
            "OPTIMIZE", "CANDIDATE" -> {
                val hot = counts.entries.sortedByDescending { it.value }
                val cold = counts.entries.sortedBy { it.value }
                val mixed = mutableListOf<Map.Entry<Int, Double>>()
                for (i in 0 until maxOf(hot.size, cold.size)) {
                    if (i < hot.size) mixed += hot[i]
                    if (i < cold.size && cold[i].key != hot.getOrNull(i)?.key) mixed += cold[i]
                }
                val list = mixed.distinctBy { it.key }
                val rot = if (list.isEmpty()) 0 else salt % list.size
                list.drop(rot) + list.take(rot)
            }
            else -> counts.entries.sortedWith(
                compareByDescending<Map.Entry<Int, Double>> { it.value }.thenBy { saltTie(it.key.toString(), salt) }
            )
        }
        return ranked.take(topN.coerceIn(1, 10)).joinToString("/") { it.key.toString() }
    }

    private fun ewmaDirection(seq: List<String>, a: String, b: String, lookback: Int): String {
        val slice = seq.takeLast(lookback.coerceAtLeast(4))
        var wa = 0.0; var wb = 0.0
        var w = 1.0
        slice.asReversed().forEach { if (it == a) wa += w else if (it == b) wb += w; w *= 0.88 }
        return if (wa >= wb) a else b
    }

    private fun wmaDirection(seq: List<String>, a: String, b: String, lookback: Int): String {
        val slice = seq.takeLast(lookback.coerceAtLeast(4))
        var wa = 0; var wb = 0
        slice.forEachIndexed { i, v -> if (v == a) wa += i + 1 else if (v == b) wb += i + 1 }
        return if (wa >= wb) a else b
    }

    private fun omitDirection(seq: List<String>, a: String, b: String, lookback: Int): String {
        val slice = seq.takeLast(lookback.coerceAtLeast(6))
        val ca = slice.count { it == a }; val cb = slice.count { it == b }
        return if (ca <= cb) a else b
    }

    private fun hotColdDirection(seq: List<String>, a: String, b: String, lookback: Int, salt: Int): String {
        val short = seq.takeLast((lookback / 2).coerceAtLeast(4))
        val long = seq.takeLast(lookback.coerceAtLeast(8))
        val sa = short.count { it == a }.toDouble() / short.size.coerceAtLeast(1)
        val sb = short.count { it == b }.toDouble() / short.size.coerceAtLeast(1)
        val la = long.count { it == a }.toDouble() / long.size.coerceAtLeast(1)
        val lb = long.count { it == b }.toDouble() / long.size.coerceAtLeast(1)
        val scoreA = sa * 0.7 + la * 0.3
        val scoreB = sb * 0.7 + lb * 0.3
        return if (kotlin.math.abs(scoreA - scoreB) < 0.03) if (salt % 2 == 0) a else b else if (scoreA > scoreB) a else b
    }

    private fun streakDirection(seq: List<String>, a: String, b: String, salt: Int): String {
        if (seq.isEmpty()) return a
        val last = seq.last()
        var n = 1
        for (i in seq.lastIndex - 1 downTo 0) { if (seq[i] == last) n++ else break }
        val threshold = 2 + salt % 3
        return if (n >= threshold) last else state(seq, 8, salt)
    }

    private fun transitionDirection(seq: List<String>, a: String, b: String, lookback: Int, salt: Int): String {
        val slice = seq.takeLast(lookback.coerceAtLeast(8))
        if (slice.size < 2) return state(seq, lookback, salt)
        val last = slice.last(); val ca = slice.zipWithNext().count { it.first == last && it.second == a }; val cb = slice.zipWithNext().count { it.first == last && it.second == b }
        return when { ca > cb -> a; cb > ca -> b; else -> if (salt % 2 == 0) a else b }
    }

    private fun markov2Direction(seq: List<String>, a: String, b: String, lookback: Int, salt: Int): String {
        if (seq.size < 3) return transitionDirection(seq, a, b, lookback, salt)
        val slice = seq.takeLast(lookback.coerceAtLeast(10)); val p1 = slice[slice.lastIndex - 1]; val p2 = slice.last()
        var ca = 0; var cb = 0
        for (i in 2 until slice.size) if (slice[i-2] == p1 && slice[i-1] == p2) { if (slice[i] == a) ca++ else if (slice[i] == b) cb++ }
        return when { ca > cb -> a; cb > ca -> b; else -> transitionDirection(seq, a, b, lookback, salt) }
    }

    private fun periodDirection(seq: List<String>, a: String, b: String, lookback: Int, salt: Int): String {
        fun avgGap(x: String): Double { val pos = seq.mapIndexedNotNull { i, v -> if (v == x) i else null }.takeLast(lookback.coerceAtLeast(8)); if (pos.size < 2) return 999.0; return pos.zipWithNext().map { it.second - it.first }.average() }
        val ga = avgGap(a); val gb = avgGap(b); val lastA = seq.indexOfLast { it == a }; val lastB = seq.indexOfLast { it == b }
        val overdueA = if (lastA < 0) 999.0 else (seq.lastIndex - lastA) / ga.coerceAtLeast(1.0)
        val overdueB = if (lastB < 0) 999.0 else (seq.lastIndex - lastB) / gb.coerceAtLeast(1.0)
        return if (overdueA >= overdueB) a else b
    }

    private fun trendDirection(seq: List<String>, a: String, b: String, lookback: Int): String {
        val slice = seq.takeLast(lookback.coerceAtLeast(8)); val half = (slice.size / 2).coerceAtLeast(2)
        val firstA = slice.take(half).count { it == a }; val lastA = slice.takeLast(half).count { it == a }
        return if (lastA >= firstA) a else b
    }

    private fun reversalDirection(seq: List<String>, a: String, b: String, salt: Int): String {
        if (seq.isEmpty()) return a
        val last = seq.last(); var n = 1
        for (i in seq.lastIndex - 1 downTo 0) { if (seq[i] == last) n++ else break }
        return if (n >= 2 + salt % 2) if (last == a) b else a else last
    }

    private fun volatilityDirection(seq: List<String>, a: String, b: String, lookback: Int, salt: Int): String {
        val slice = seq.takeLast(lookback.coerceAtLeast(8)); val switches = slice.zipWithNext().count { it.first != it.second }.toDouble() / (slice.size - 1).coerceAtLeast(1)
        return if (switches >= 0.58) { if (seq.last() == a) b else a } else state(seq, lookback, salt)
    }

    private fun ensembleDirection(seq: List<String>, a: String, b: String, lookback: Int, salt: Int): String {
        val votes = listOf(ewmaDirection(seq,a,b,lookback), transitionDirection(seq,a,b,lookback,salt), trendDirection(seq,a,b,lookback), reversalDirection(seq,a,b,salt))
        return if (votes.count { it == a } >= votes.count { it == b }) a else b
    }

    private fun adaptiveDirection(seq: List<String>, a: String, b: String, lookback: Int, salt: Int): String {
        val slice = seq.takeLast(lookback.coerceAtLeast(8)); val switches = slice.zipWithNext().count { it.first != it.second }.toDouble() / (slice.size - 1).coerceAtLeast(1)
        return when {
            switches > 0.62 -> reversalDirection(seq,a,b,salt)
            switches < 0.35 -> streakDirection(seq,a,b,salt)
            else -> ensembleDirection(seq,a,b,lookback,salt)
        }
    }


    /** 路珠：当前连续侧继续跟（长龙跟踪）；刚切换则跟新侧 */
    private fun luzhuDirection(seq: List<String>, a: String, b: String, salt: Int): String {
        if (seq.isEmpty()) return if (salt % 2 == 0) a else b
        val last = seq.last()
        var n = 0
        for (i in seq.indices.reversed()) {
            if (seq[i] == last) n++ else break
        }
        // 长龙(≥3)继续跟；短龙可按 salt 决定跟或切
        return if (n >= 3 || salt % 3 != 0) last else if (last == a) b else a
    }

    /** 连中跟、连挂反：最近连续命中含义用结果序列本身近似——同侧连续当「连中跟」 */
    private fun genzhuDirection(seq: List<String>, a: String, b: String, salt: Int): String {
        if (seq.isEmpty()) return a
        val last = seq.last()
        var n = 0
        for (i in seq.indices.reversed()) {
            if (seq[i] == last) n++ else break
        }
        // 连续 ≥2 跟；连续挂感（盐控制阈值）则反
        return if (n >= 2) last else if (salt % 2 == 0) (if (last == a) b else a) else last
    }

    /** N 珠后反向：当前连续恰好 ≥N 则出反向，否则跟最后一侧 */
    private fun zhuFanDirection(seq: List<String>, a: String, b: String, zhu: Int): String {
        if (seq.isEmpty()) return a
        val last = seq.last()
        var n = 0
        for (i in seq.indices.reversed()) {
            if (seq[i] == last) n++ else break
        }
        return if (n >= zhu) (if (last == a) b else a) else last
    }

    /** 杀热：压 lookback 内出现次数更少的一侧 */
    private fun shaReDirection(seq: List<String>, a: String, b: String, lookback: Int): String {
        val slice = seq.takeLast(lookback.coerceAtLeast(4))
        val ca = slice.count { it == a }
        val cb = slice.count { it == b }
        return if (ca <= cb) a else b
    }

    private fun state(seq: List<String>, lookback: Int = 8, salt: Int = 0): String {
        val slice = seq.takeLast(lookback.coerceIn(3, seq.size.coerceAtLeast(3)))
        val counts = slice.groupingBy { it }.eachCount()
        // 平票时用 salt 打破，避免全池同一结果
        return counts.maxWithOrNull(
            compareBy<Map.Entry<String, Int>> { it.value }.thenBy { -saltTie(it.key, salt) }
        )?.key.orEmpty()
    }

    private fun rhythm(seq: List<String>, a: String, b: String, lookback: Int, salt: Int): String {
        if (seq.size < 4) return state(seq, lookback, salt)
        val streak = 2 + (salt % 3) // 2～4 连出触发反转，计划间不同
        return if (seq.takeLast(streak).distinct().size == 1) {
            if (seq.last() == a) b else a
        } else state(seq, lookback, salt)
    }

    private fun anomaly(seq: List<String>, a: String, b: String, lookback: Int, salt: Int): String {
        val slice = seq.takeLast(lookback.coerceAtLeast(6))
        val pA = slice.count { it == a }.toDouble() / slice.size.coerceAtLeast(1)
        val hi = 0.58 + (salt % 5) * 0.02
        val lo = 0.42 - (salt % 5) * 0.02
        return when {
            pA > hi -> b
            pA < lo -> a
            else -> state(seq, lookback, salt)
        }
    }

    private fun similarDirection(seq: List<String>, lookback: Int, salt: Int): String {
        val pattern = 4 + (salt % 3) // 4～6 期形态
        if (seq.size < pattern * 2) return state(seq, lookback, salt)
        val tail = seq.takeLast(pattern)
        val candidates = seq.dropLast(pattern).windowed(pattern)
        if (candidates.isEmpty()) return state(seq, lookback, salt)
        // 取最相似的第 (salt%3)+1 个匹配，避免全选同一个历史段
        val ranked = candidates.mapIndexed { idx, w ->
            idx to w.zip(tail).count { it.first != it.second }
        }.sortedWith(compareBy<Pair<Int, Int>> { it.second }.thenBy { (it.first + salt) % 97 })
        val pick = ranked.getOrNull(salt % ranked.size.coerceAtMost(3)) ?: ranked.first()
        return seq.getOrNull(pick.first + pattern) ?: state(seq, lookback, salt)
    }

    private fun network(seq: List<String>, a: String, b: String, lookback: Int, salt: Int): String {
        val slice = seq.takeLast(lookback.coerceAtLeast(6))
        if (slice.size < 6) return state(seq, lookback, salt)
        val last = slice.last()
        val next = mutableMapOf<String, Int>()
        for (i in 1 until slice.size) {
            if (slice[i - 1] == last) next[slice[i]] = (next[slice[i]] ?: 0) + 1
        }
        return next.maxWithOrNull(
            compareBy<Map.Entry<String, Int>> { it.value }.thenBy { -saltTie(it.key, salt) }
        )?.key ?: state(seq, lookback, salt)
    }

    private fun struct(seq: List<String>, a: String, b: String, lookback: Int, salt: Int): String {
        if (seq.size < 6) return state(seq, lookback, salt)
        val n = (5 + salt % 4).coerceAtMost(seq.size) // 5～8
        val tail = seq.takeLast(n)
        var switches = 0
        for (i in 1 until tail.size) if (tail[i] != tail[i - 1]) switches++
        val threshold = 2 + (salt % 3)
        return if (switches >= threshold) {
            if (seq.last() == a) b else a
        } else state(seq, lookback, salt)
    }

    private fun candidate(seq: List<String>, a: String, b: String, lookback: Int, salt: Int): String {
        if (seq.size < 5) return state(seq, lookback, salt)
        val counts = seq.takeLast(lookback.coerceIn(8, 30)).groupingBy { it }.eachCount()
        val ordered = counts.entries.sortedWith(
            compareByDescending<Map.Entry<String, Int>> { it.value }.thenBy { saltTie(it.key, salt) }
        )
        val top = ordered.firstOrNull()?.key ?: return state(seq, lookback, salt)
        val second = ordered.getOrNull(1)?.key
        // salt 偶数偏热，奇数在接近时选次热
        return if (second != null && (counts[second] ?: 0) * 2 >= (counts[top] ?: 0) && salt % 2 == 1) second else top
    }

    private fun optimize(seq: List<String>, a: String, b: String, lookback: Int, salt: Int): String {
        if (seq.size < 6) return state(seq, lookback, salt)
        val shortN = 3 + (salt % 4)
        val short = seq.takeLast(shortN).groupingBy { it }.eachCount()
            .maxWithOrNull(compareBy<Map.Entry<String, Int>> { it.value }.thenBy { -saltTie(it.key, salt) })?.key
        val transfer = network(seq, a, b, lookback, salt)
        return when {
            short != null && short == transfer -> short
            salt % 3 == 0 -> transfer.ifBlank { short.orEmpty() }.ifBlank { state(seq, lookback, salt) }
            else -> short.orEmpty().ifBlank { transfer }.ifBlank { state(seq, lookback, salt) }
        }
    }
}
