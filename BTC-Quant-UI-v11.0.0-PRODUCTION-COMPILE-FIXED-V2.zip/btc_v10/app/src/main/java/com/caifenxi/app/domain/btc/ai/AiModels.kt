package com.caifenxi.app.domain.btc.ai

import com.caifenxi.app.domain.btc.BtcDirection
import org.json.JSONArray
import org.json.JSONObject

/**
 * Forced JSON contract for any LLM / local brain output.
 * Invalid JSON => discarded, never traded.
 */
data class AiPlanCandidate(
    val barId: Long,
    val direction: BtcDirection,
    val confidence: Double,
    val expectedMovePct: Double,
    val reasons: List<String>,
    val invalidIf: List<String>,
    val suggestedSizePct: Double,
    val newsBias: Double,
    val source: String = "rules-brain",
    val rawJson: String = ""
) {
    val isTradableCandidate: Boolean
        get() = direction != BtcDirection.FLAT && confidence >= 0.55
}

object AiJsonParser {
    fun parse(json: String, fallbackBarId: Long = 0L): AiPlanCandidate? {
        return try {
            val o = JSONObject(json.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim())
            val dir = when (o.optString("direction", "skip").lowercase()) {
                "up", "long", "buy" -> BtcDirection.UP
                "down", "short", "sell" -> BtcDirection.DOWN
                else -> BtcDirection.FLAT
            }
            val reasons = o.optJSONArray("reasons").toStringList()
            val invalid = o.optJSONArray("invalidIf").toStringList()
            AiPlanCandidate(
                barId = o.optLong("barId", fallbackBarId),
                direction = dir,
                confidence = o.optDouble("confidence", 0.0).coerceIn(0.0, 1.0),
                expectedMovePct = o.optDouble("expectedMovePct", 0.0),
                reasons = reasons,
                invalidIf = invalid,
                suggestedSizePct = o.optDouble("suggestedSizePct", 0.25).coerceIn(0.0, 2.0),
                newsBias = o.optDouble("newsBias", 0.0).coerceIn(-1.0, 1.0),
                source = o.optString("source", "llm"),
                rawJson = json
            )
        } catch (_: Exception) {
            null
        }
    }

    private fun JSONArray?.toStringList(): List<String> {
        if (this == null) return emptyList()
        return buildList {
            for (i in 0 until length()) add(optString(i))
        }
    }
}
