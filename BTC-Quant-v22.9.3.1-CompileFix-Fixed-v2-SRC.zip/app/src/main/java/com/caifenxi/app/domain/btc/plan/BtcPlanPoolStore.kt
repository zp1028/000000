package com.caifenxi.app.domain.btc.plan

import android.content.Context

/** Persistent shared plan-pool configuration used by both UI and unattended runtime. */
class BtcPlanPoolStore(context: Context) {
    data class Config(
        val enabledPlans: Set<String> = DEFAULT_ENABLED,
        val weightOverrides: Map<String, Double> = emptyMap()
    )

    private val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun load(): Config {
        val enabled = prefs.getStringSet("enabled", DEFAULT_ENABLED)?.toSet() ?: DEFAULT_ENABLED
        val weights = prefs.all.filterKeys { it.startsWith("w:") }.mapNotNull { (key, value) ->
            val v = when (value) {
                is Float -> value.toDouble()
                is Double -> value
                is Int -> value.toDouble()
                else -> null
            }
            v?.let { key.removePrefix("w:") to it }
        }.toMap()
        return Config(enabled, weights)
    }

    @Synchronized fun save(config: Config) {
        prefs.edit().clear().putStringSet("enabled", config.enabledPlans).apply {
            config.weightOverrides.forEach { (id, weight) -> putFloat("w:$id", weight.coerceIn(0.05, 5.0).toFloat()) }
        }.apply()
    }

    companion object {
        private const val PREFS = "btc_quant_plan_pool_v2"
        val DEFAULT_ENABLED: Set<String> = setOf(
            "BTC-TURTLE", "BTC-EMA-TREND", "BTC-MACD", "BTC-MTF-PULLBACK",
            "BTC-RSI-RANGE", "BTC-BB-ATR", "BTC-VWAP-VOLUME", "BTC-FUNDING-FADE"
        )
    }
}
