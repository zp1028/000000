package com.caifenxi.app.domain.btc.hs

import com.caifenxi.app.domain.btc.BtcDirection
import com.caifenxi.app.domain.btc.MarketRegime
import com.caifenxi.app.domain.btc.polymarket.PolyBookLevel
import com.caifenxi.app.domain.btc.polymarket.PolyMarket

/**
 * HS 量化核心数据模型 —— 对齐截图 / 视频中的 p_hat · edge · kelly · Bayes 粒子
 */
data class TimeframePhat(
    val timeframe: String,          // "5m" | "15m" | "1h"
    val pHat: Double,               // 模型上涨概率 [0,1]
    val edgeAsk: Double,            // 相对市场 ask 的 edge
    val edgeBid: Double,
    val kelly: Double,              // 全凯利分数
    val halfKelly: Double,
    val bucket: Double,             // 仓位 bucket 建议
    val spread: Double,
    val alpha: Double,              // 超额收益 alpha 估计
    val depthBid: Double,
    val depthAsk: Double,
    val trigger: Double,            // Bayes 触发强度
    val regime: MarketRegime,
    val mlProbability: Double = 0.5,
    val mlSamples: Int = 0,
    val mlModelVersion: String = "ML-LOGISTIC-1.1-WF",
    val brierScore: Double = 0.25,
    val modelHitRate: Double = 0.0,
    val marketYes: Double = 0.5,
    val bestBid: Double? = null,
    val bestAsk: Double? = null,
    val netEdge: Double = 0.0,
    val costEstimate: Double = 0.0,
    val liquidityScore: Double = 0.0,
    val positionMultiplier: Double = 0.0,
    val action: String = "NO_TRADE",
    val opportunityScore: Double = 0.0,
    val dataQualityScore: Double = 0.0
)


data class HsPolymarketPanel(
    val timeframe: String,
    val market: PolyMarket,
    val yesBids: List<PolyBookLevel> = emptyList(),
    val yesAsks: List<PolyBookLevel> = emptyList(),
    val noBids: List<PolyBookLevel> = emptyList(),
    val noAsks: List<PolyBookLevel> = emptyList(),
    val fetchedAt: Long = System.currentTimeMillis()
) {
    val yesBid: Double? get() = yesBids.maxByOrNull { it.price }?.price
    val yesAsk: Double? get() = yesAsks.minByOrNull { it.price }?.price
    val noBid: Double? get() = noBids.maxByOrNull { it.price }?.price
    val noAsk: Double? get() = noAsks.minByOrNull { it.price }?.price
    val yesBookLive: Boolean get() = yesBids.isNotEmpty() || yesAsks.isNotEmpty()
    val noBookLive: Boolean get() = noBids.isNotEmpty() || noAsks.isNotEmpty()
    val bookLive: Boolean get() = yesBookLive && noBookLive
}

data class HsPredictionSnapshot(
    val symbol: String = "BTCUSDT",
    val updatedAt: Long = System.currentTimeMillis(),
    val markPrice: Double = 0.0,
    val chainlinkPrice: Double = 0.0,
    /** 多周期 p_hat */
    val tf5m: TimeframePhat,
    val tf15m: TimeframePhat,
    val tf1h: TimeframePhat,
    /** 账户 / 风控（可由纸交易/CLOB 注入） */
    val balance: Double = 0.0,
    val available: Double = 0.0,
    val openNotional: Double = 0.0,
    val todayPnl: Double = 0.0,
    val pnl30d: Double = 0.0,
    val maxDrawdownPct: Double = 0.0,
    /** Bayes 粒子摘要 */
    val bayesTrigger: Double = 0.0,
    val bayesMean: Double = 0.5,
    val bayesStd: Double = 0.12,
    val particleCount: Int = 64,
    /** 真实粒子列表（供 UI 粒子场绘制，归一化坐标由 UI 映射） */
    val particles: List<BayesParticle> = emptyList(),
    /** 综合 edge */
    val aggregateEdge: Double = 0.0,
    val primaryDirection: BtcDirection = BtcDirection.FLAT,
    val primaryPhat: Double = 0.5,
    val newsScore: Double = 0.0,
    val systemsOnline: Boolean = true,
    val apiLiveSamples: String = "0/0",
    val engineLog: List<String> = emptyList(),
    val dataMode: String = "LIVE",
    val dataFreshnessMs: Long = 0L,
    val binanceDepthBid: Double = 0.0,
    val binanceDepthAsk: Double = 0.0,
    val binanceDepthImbalance: Double = 0.0,
    val binanceMicroPrice: Double = 0.0,
    val binanceSpread: Double = 0.0,
    val polymarketBookLive: Boolean = false,
    val oracleLive: Boolean = false,
    val oracleUpdatedAt: Long = 0L,
    val phatHistory: Map<String, List<Double>> = emptyMap(),
    val edgeHistory: List<Double> = emptyList(),
    val opportunityScore: Double = 0.0,
    val dataQualityScore: Double = 0.0,
    val dataQuality: HsDataQualityEngine.Snapshot? = null,
    val decisionExplanation: HsDecisionExplanation? = null,
    val modelLab: HsModelLab.Report? = null,
    val modelLabByTimeframe: Map<String, HsModelLab.Report> = emptyMap(),
    val modelWeights: Map<String, Double> = emptyMap(),
    val shadowStats: HsShadowTradingStore.Stats = HsShadowTradingStore.Stats(0, 0, 0.0, 0.0, 0.0, 0.0),
    val positionSizing: HsOpportunitySizing.Result = HsOpportunitySizing.Result(0.0, 0.0, 0.0, "等待实时数据"),
    val modelLifecycle: HsModelLifecycle.Report? = null,
    val attribution: HsAttributionEngine.Attribution = HsAttributionEngine.Attribution(0,0,0.0,0.0,0.0,0.0,0.0,0.0),
    val snapshotId: String = "",
    val snapshotHistory: List<HsSnapshotStore.Record> = emptyList(),
    val polymarketPanels: Map<String, HsPolymarketPanel> = emptyMap()
) {
    fun phatFor(tf: String): TimeframePhat = when (tf) {
        "5m" -> tf5m
        "1h" -> tf1h
        else -> tf15m
    }
}

data class BayesParticle(
    val weight: Double,
    val state: Double,       // 隐含上涨概率状态
    val velocity: Double     // 状态漂移速度
)

data class BayesParticleFieldState(
    val particles: List<BayesParticle>,
    val mean: Double,
    val std: Double,
    val trigger: Double,
    val effectiveSampleSize: Double
)
