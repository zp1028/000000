package com.caifenxi.app.domain.btc.polymarket

data class PolyMarket(
    val conditionId: String,
    val question: String,
    val slug: String,
    val description: String = "",
    val priceToBeat: Double? = null,
    val startDateMs: Long? = null,
    val yesTokenId: String,
    val noTokenId: String,
    val yesPrice: Double,
    val noPrice: Double,
    val endDateMs: Long?,
    val closed: Boolean,
    val enableOrderBook: Boolean,
    val negRisk: Boolean = false,
    /** Resolved outcome when Gamma exposes a terminal market result. YES/NO or null while unresolved. */
    val resolvedOutcome: String? = null,
    val tickSize: Double = 0.01,
    val minOrderSize: Double = 1.0
)

data class PolyBookLevel(val price: Double, val size: Double)

data class PolyOrderBook(
    val tokenId: String,
    val bids: List<PolyBookLevel>,
    val asks: List<PolyBookLevel>,
    val tickSize: Double,
    val minOrderSize: Double,
    val negRisk: Boolean
) {
    val bestBid: Double? get() = bids.maxByOrNull { it.price }?.price
    val bestAsk: Double? get() = asks.minByOrNull { it.price }?.price
    val mid: Double?
        get() {
            val b = bestBid; val a = bestAsk
            return if (b != null && a != null) (b + a) / 2.0 else a ?: b
        }
    val spread: Double
        get() {
            val b = bestBid; val a = bestAsk
            return if (b != null && a != null) (a - b).coerceAtLeast(0.0) else 1.0
        }
    val bidDepth: Double get() = bids.sumOf { it.size.coerceAtLeast(0.0) }
    val askDepth: Double get() = asks.sumOf { it.size.coerceAtLeast(0.0) }
    val depthImbalance: Double
        get() = ((bidDepth - askDepth) / (bidDepth + askDepth).coerceAtLeast(1e-12)).coerceIn(-1.0, 1.0)
    val microPrice: Double?
        get() {
            val b = bestBid ?: return bestAsk
            val a = bestAsk ?: return b
            val bs = bids.filter { it.price >= b - tickSize * 2 }.sumOf { it.size }.coerceAtLeast(1e-12)
            val asz = asks.filter { it.price <= a + tickSize * 2 }.sumOf { it.size }.coerceAtLeast(1e-12)
            return (a * bs + b * asz) / (bs + asz)
        }
    fun executableVwap(side: String, requestedSize: Double): Double? {
        if (requestedSize <= 0.0) return null
        val levels = if (side.equals("BUY", true)) asks.sortedBy { it.price } else bids.sortedByDescending { it.price }
        var remain = requestedSize; var cost = 0.0
        for (l in levels) { val take = minOf(remain, l.size); cost += take * l.price; remain -= take; if (remain <= 1e-12) break }
        return if (remain > 1e-12) null else cost / requestedSize
    }
}

data class PolyEdgeOpportunity(
    val market: PolyMarket,
    val outcome: String, // YES / NO
    val tokenId: String,
    val marketP: Double,
    val modelP: Double,
    val tradePrice: Double,
    val edge: Double,
    val ev: Double,
    val spread: Double,
    val liquidityScore: Double,
    val timeToResolutionSec: Long,
    val action: String, // BUY / NO_TRADE
    val reason: String
)
