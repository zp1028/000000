package com.caifenxi.app.domain.btc.polymarket.strategy

import kotlin.math.abs

/** Portfolio allocator: fractional Kelly + edge/cost + correlation concentration controls. */
object PolymarketPortfolioAllocator {
    data class Allocation(val signal: PolymarketStrategyPool.Signal, val kelly: Double, val riskFraction: Double, val notional: Double, val reason: String)

    fun allocate(
        candidates: List<PolymarketStrategyPool.Signal>,
        bankroll: Double,
        maxPortfolioRisk: Double = 0.02,
        maxMarketRisk: Double = 0.0075,
        maxStrategyRisk: Double = 0.006,
        correlation: Map<Pair<String,String>,Double> = emptyMap(),
        kellyFraction: Double = 0.25
    ): List<Allocation> {
        if (bankroll <= 0.0) return emptyList()
        val ranked = candidates.filter { it.marketPrice in 0.001..0.999 && it.modelProbability in 0.001..0.999 }
            .sortedByDescending { it.score }
        val out = mutableListOf<Allocation>(); var used = 0.0
        for (s in ranked) {
            if (used >= maxPortfolioRisk) break
            val p = s.modelProbability.coerceIn(0.001,0.999); val price = s.marketPrice
            val b = (1.0 - price) / price
            val k = ((p*b - (1.0-p)) / b).coerceAtLeast(0.0)
            val raw = (k * kellyFraction * (s.liquidity * 0.5 + 0.5)).coerceAtMost(maxMarketRisk)
            val corr = out.maxOfOrNull { abs(correlation[it.signal.strategyId to s.strategyId] ?: correlation[s.strategyId to it.signal.strategyId] ?: 0.0) } ?: 0.0
            val penalty = PolymarketStrategyCorrelationEngine.redundancyPenalty(corr)
            val risk = (raw * penalty).coerceAtMost(maxStrategyRisk).coerceAtMost(maxPortfolioRisk - used)
            if (risk <= 0.0001) continue
            out += Allocation(s, k, risk, bankroll*risk, "Kelly=${"%.3f".format(k)} corr=${"%.2f".format(corr)} risk=${"%.2f%%".format(risk*100)}")
            used += risk
        }
        return out
    }
}
