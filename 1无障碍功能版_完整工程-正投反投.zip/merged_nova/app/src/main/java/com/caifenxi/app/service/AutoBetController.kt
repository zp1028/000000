package com.caifenxi.app.service

import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.text.TextUtils
import com.caifenxi.app.CaiFenXiApplication
import com.caifenxi.app.domain.model.BetSourceType
import com.caifenxi.app.domain.model.UserPrefs
import com.caifenxi.app.util.RuntimeLog
import kotlinx.coroutines.runBlocking

/**
 * 真实自动点击控制器。
 * - 读取内部预测（与悬浮窗同源逻辑）
 * - 按期号去重，避免同一期重复点击
 * - 通过无障碍服务执行点击
 * - 仅在点击成功后写入去重标记，失败可在挂起窗口内重试；超时后可再次自动提交
 */
object AutoBetController {

    private const val PREFS = "auto_bet_runtime"
    private const val KEY_LAST_ISSUE = "last_bet_issue"
    private const val KEY_LAST_LOTTERY = "last_bet_lottery"
    private const val KEY_LAST_HIT = "last_bet_hit"
    private const val KEY_CHASE_USED = "chase_used"
    /** 最近一次实际点击的预测（开奖后与实际大小单双比对） */
    private const val KEY_LAST_PRED_ISSUE = "last_pred_issue"
    private const val KEY_LAST_PRED_LOTTERY = "last_pred_lottery"
    private const val KEY_LAST_PRED_DX = "last_pred_dx"
    private const val KEY_LAST_PRED_DS = "last_pred_ds"
    /** 进行中的期号（已提交但尚未成功），防止 READY 回调风暴重复提交 */
    private const val KEY_INFLIGHT_ISSUE = "inflight_bet_issue"
    private const val KEY_INFLIGHT_LOTTERY = "inflight_bet_lottery"
    private const val KEY_INFLIGHT_AT = "inflight_bet_at"
    /** 略大于无障碍服务挂起上限 45s，超时后允许同一期再次自动提交 */
    private const val INFLIGHT_TTL_MS = 50_000L

    /**
     * 供悬浮窗展示：上期对错 + 本期将点的金额数字。
     */
    data class AmountStrategyInfo(
        /** null=未知, true=对, false=错 */
        val lastHit: Boolean?,
        val lastHitLabel: String,
        val chaseUsed: Boolean,
        val nextAmountText: String?,
        val nextAmountKind: String,
        val lastPredIssue: String,
        val lastPredDx: String,
        val lastPredDs: String
    )

    /** 是否已开启系统无障碍服务 */
    fun isAccessibilityEnabled(context: Context): Boolean {
        val expected = context.packageName + "/" + AutoBetAccessibilityService::class.java.canonicalName
        val enabled = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val splitter = TextUtils.SimpleStringSplitter(':')
        splitter.setString(enabled)
        while (splitter.hasNext()) {
            val item = splitter.next()
            if (item.equals(expected, ignoreCase = true)) return true
            // 部分 ROM 用简写组件名
            if (item.contains(context.packageName, ignoreCase = true) &&
                item.contains("AutoBetAccessibilityService", ignoreCase = true)
            ) {
                return true
            }
        }
        return false
    }

    fun openAccessibilitySettings(context: Context) {
        try {
            context.startActivity(
                Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (_: Exception) {
            try {
                context.startActivity(
                    Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (_: Exception) {
            }
        }
    }

    /**
     * 预测 READY 时调用。根据 UserPrefs 决定是否真实点击第三方页面。
     */
    fun onPredictionReady(context: Context, snap: FloatingSnapshot, force: Boolean = false) {
        val app = try {
            CaiFenXiApplication.instance
        } catch (_: Exception) {
            return
        }
        val prefs = app.configStore.loadPrefs()
        // force=true：悬浮窗「开始」手动触发，不依赖自动开关
        if (!force && !prefs.autoClickEnabled) return
        if (!force && snap.status != "READY") return
        if (force && snap.status != "READY" && snap.status != "CALCULATING") {
            // 手动时允许用最后一份快照
        } else if (!force && snap.status != "READY") return
        if (snap.targetIssue.isBlank() || snap.targetIssue == "-") return

        val sp = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val lastIssue = sp.getString(KEY_LAST_ISSUE, "")
        val lastLottery = sp.getString(KEY_LAST_LOTTERY, "")
        // 已成功执行过的期号：跳过（手动 force 时由 tryNow 先清标记）
        if (snap.targetIssue == lastIssue && snap.lotteryKey == lastLottery) {
            RuntimeLog.info("AutoBet", "期号 ${snap.targetIssue} 已成功点击过，跳过")
            return
        }

        // 进行中且未超时：避免 READY 风暴重复提交；超时后允许失败重试
        if (!force) {
            val inflightIssue = sp.getString(KEY_INFLIGHT_ISSUE, "")
            val inflightLottery = sp.getString(KEY_INFLIGHT_LOTTERY, "")
            val inflightAt = sp.getLong(KEY_INFLIGHT_AT, 0L)
            val inflightAlive = inflightAt > 0L &&
                System.currentTimeMillis() - inflightAt < INFLIGHT_TTL_MS
            if (inflightAlive &&
                snap.targetIssue == inflightIssue &&
                snap.lotteryKey == inflightLottery
            ) {
                RuntimeLog.info("AutoBet", "期号 ${snap.targetIssue} 正在执行/挂起中，跳过重复提交")
                return
            }
            if (!inflightAlive && inflightIssue?.isNotBlank() == true) {
                // 过期 inflight 清理，允许失败后重试
                clearInflight(context)
            }
        }

        if (!isAccessibilityEnabled(context)) {
            RuntimeLog.warn("AutoBet", "无障碍服务未开启，跳过自动点击（请到系统设置开启「彩析」）")
            return
        }
        val service = AutoBetAccessibilityService.instance
        if (service == null) {
            RuntimeLog.warn("AutoBet", "无障碍服务实例为空：开关已开但进程未连上，请关闭再打开一次服务")
            return
        }

        if (prefs.autoClickSimulateOnly) {
            RuntimeLog.info("AutoBet", "仅模拟模式，跳过真实点击")
            return
        }

        val (rawDx, rawDs) = resolvePrediction(prefs, snap)
        val reverse = isReverseBetMode(prefs)
        val dx = if (reverse) invertDx(rawDx) else rawDx
        val ds = if (reverse) invertDs(rawDs) else rawDs
        val postActions = com.caifenxi.app.domain.model.AutoClickPostActionsCodec.decode(prefs.autoClickPostActionsJson)
        val wantCombo = postActions.any { it.enabled && it.type == com.caifenxi.app.domain.model.AutoClickPostAction.TYPE_COMBO }
        val wantNums = postActions.any { it.enabled && it.type == com.caifenxi.app.domain.model.AutoClickPostAction.TYPE_PRED_NUMBERS }
        val wantText = postActions.any { it.enabled && it.type == com.caifenxi.app.domain.model.AutoClickPostAction.TYPE_TEXT && it.text.isNotBlank() }
        val rawCombo = if (wantCombo) resolveCombo(snap, prefs) else null
        val combo = if (reverse) invertCombo(rawCombo) else rawCombo
        val predNumbers = if (wantNums) resolvePredNumbers(snap) else emptyList()

        val doDx = prefs.autoClickDx && prefs.autoExecClickDxDs && !dx.isNullOrBlank()
        val doDs = prefs.autoClickDs && prefs.autoExecClickDxDs && !ds.isNullOrBlank()
        val amountText = resolveAmountText(context, prefs, applyChaseSideEffect = true)
        if (!doDx && !doDs && amountText.isNullOrBlank() && combo.isNullOrBlank() && predNumbers.isEmpty() && !wantText) {
            RuntimeLog.info("AutoBet", "无有效可点击目标，跳过")
            return
        }

        val modeLabel = if (reverse) "反投" else "正投"
        RuntimeLog.info(
            "AutoBet",
            "提交自动执行[$modeLabel] 期号=${snap.targetIssue} 大小=${if (doDx) dx else "-"} 单双=${if (doDs) ds else "-"} 金额=${amountText ?: "-"} 组合=${combo ?: "-"} 号码=$predNumbers"
        )

        markInflight(context, snap.targetIssue, snap.lotteryKey)
        // 记录实际点击方向（反投时已取反），供上期对错 / 倍投判断
        rememberPrediction(
            context,
            issue = snap.targetIssue,
            lotteryKey = snap.lotteryKey,
            dx = if (doDx) dx else null,
            ds = if (doDs) ds else null
        )

        service.performBet(
            dx = if (doDx) dx else null,
            ds = if (doDs) ds else null,
            clickDelayMs = prefs.autoClickDelayMs.coerceIn(100L, 3000L),
            amountText = amountText,
            targetIssue = snap.targetIssue,
            lotteryKey = snap.lotteryKey,
            combo = combo,
            predNumbers = predNumbers
        )
    }

    /**
     * 根据上一期对错解析本期要点击的金额数字：
     * - 上一期对 / 未知 → 复原数字（autoInputBaseAmount）
     * - 上一期错且尚未追投 → 倍投数字（autoInputMultAmount），并标记已追投 1 期
     * - 已追投过 → 恢复复原数字并清除追投标记
     * 返回值交给无障碍服务在界面数字键盘上逐位点击，不再 SET_TEXT。
     *
     * @param applyChaseSideEffect true 时会写入 chase_used（真实执行路径）；预览路径传 false。
     */
    private fun resolveAmountText(
        context: Context,
        prefs: UserPrefs,
        applyChaseSideEffect: Boolean
    ): String? {
        if (!prefs.autoInputEnabled) return null
        val sp = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val lastHit = sp.getString(KEY_LAST_HIT, null)
        val chaseUsed = sp.getBoolean(KEY_CHASE_USED, false)
        val base = prefs.autoInputBaseAmount
        val mult = prefs.autoInputMultAmount
        return when {
            lastHit == "0" && !chaseUsed -> {
                if (applyChaseSideEffect) sp.edit().putBoolean(KEY_CHASE_USED, true).apply()
                formatAmount(mult)
            }
            else -> {
                if (applyChaseSideEffect && chaseUsed) {
                    sp.edit().putBoolean(KEY_CHASE_USED, false).apply()
                }
                formatAmount(base)
            }
        }
    }

    private fun formatAmount(v: Double): String {
        return if (v == v.toLong().toDouble()) v.toLong().toString() else "%.2f".format(v)
    }

    private fun rememberPrediction(
        context: Context,
        issue: String,
        lotteryKey: String,
        dx: String?,
        ds: String?
    ) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_LAST_PRED_ISSUE, issue)
            .putString(KEY_LAST_PRED_LOTTERY, lotteryKey)
            .putString(KEY_LAST_PRED_DX, dx.orEmpty())
            .putString(KEY_LAST_PRED_DS, ds.orEmpty())
            .apply()
        RuntimeLog.info("AutoBet", "记录本期点击预测 issue=$issue dx=${dx ?: "-"} ds=${ds ?: "-"}")
    }

    /** 外部在结算后调用：记录上一期对错，供下一期金额策略使用 */
    fun recordLastHit(context: Context, hit: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_LAST_HIT, if (hit) "1" else "0")
            .apply()
        RuntimeLog.info("AutoBet", "记录上期结果 hit=$hit")
    }

    /**
     * 用开奖结果与「最近一次无障碍点击的预测」比对，写入上期对错。
     * 优先于挂机注单结算：只要点过大小/单双就会判定，不依赖内部是否下过单。
     *
     * 判定规则：已点击的方向全部与开奖一致才算「对」；任一不符算「错」。
     * 若期号对不上或没有记录过预测，则不改动已有 hit 状态。
     */
    fun recordHitFromDraw(
        context: Context,
        lotteryKey: String,
        issue: String,
        actualDx: String?,
        actualDs: String?
    ) {
        val sp = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val predIssue = sp.getString(KEY_LAST_PRED_ISSUE, null) ?: return
        val predLottery = sp.getString(KEY_LAST_PRED_LOTTERY, null)
        if (predIssue != issue) return
        if (!predLottery.isNullOrBlank() && predLottery != lotteryKey) return

        val predDx = sp.getString(KEY_LAST_PRED_DX, "").orEmpty()
        val predDs = sp.getString(KEY_LAST_PRED_DS, "").orEmpty()
        var checked = false
        var ok = true
        if (predDx == "大" || predDx == "小") {
            checked = true
            if (actualDx.isNullOrBlank() || actualDx != predDx) ok = false
        }
        if (predDs == "单" || predDs == "双") {
            checked = true
            if (actualDs.isNullOrBlank() || actualDs != predDs) ok = false
        }
        if (!checked) {
            RuntimeLog.info("AutoBet", "开奖比对跳过：无有效点击方向 issue=$issue")
            return
        }
        recordLastHit(context, ok)
        RuntimeLog.info(
            "AutoBet",
            "开奖比对 issue=$issue pred=$predDx/$predDs actual=${actualDx ?: "-"}/${actualDs ?: "-"} => ${if (ok) "对" else "错"}"
        )
    }

    /** 读取当前金额策略状态（悬浮窗展示用，不改 chase 标记） */
    fun getAmountStrategyInfo(context: Context, prefs: UserPrefs): AmountStrategyInfo {
        val sp = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val hitRaw = sp.getString(KEY_LAST_HIT, null)
        val lastHit = when (hitRaw) {
            "1" -> true
            "0" -> false
            else -> null
        }
        val chaseUsed = sp.getBoolean(KEY_CHASE_USED, false)
        val nextAmount = resolveAmountText(context, prefs, applyChaseSideEffect = false)
        val kind = when {
            !prefs.autoInputEnabled -> "未启用"
            hitRaw == "0" && !chaseUsed -> "倍投"
            else -> "复原"
        }
        return AmountStrategyInfo(
            lastHit = lastHit,
            lastHitLabel = when (lastHit) {
                true -> "对"
                false -> "错"
                null -> "未知"
            },
            chaseUsed = chaseUsed,
            nextAmountText = nextAmount,
            nextAmountKind = kind,
            lastPredIssue = sp.getString(KEY_LAST_PRED_ISSUE, "") ?: "",
            lastPredDx = sp.getString(KEY_LAST_PRED_DX, "") ?: "",
            lastPredDs = sp.getString(KEY_LAST_PRED_DS, "") ?: ""
        )
    }

    fun clearChaseState(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_CHASE_USED, false)
            .apply()
    }

    /**
     * 无障碍流水线执行成功后回调：写入「本期已成功」去重标记，并清除 inflight。
     * 之后同一期自动路径不再提交；手动 tryNow 可强制重试。
     */
    fun notifyBetSucceeded(context: Context, issue: String, lotteryKey: String) {
        if (issue.isBlank() || issue == "-") return
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_LAST_ISSUE, issue)
            .putString(KEY_LAST_LOTTERY, lotteryKey)
            .remove(KEY_INFLIGHT_ISSUE)
            .remove(KEY_INFLIGHT_LOTTERY)
            .remove(KEY_INFLIGHT_AT)
            .apply()
        RuntimeLog.info("AutoBet", "执行成功，已记入去重 期号=$issue 彩种=$lotteryKey")
    }

    /**
     * 挂起超时或明确失败时回调：清除 inflight，允许同一期再次自动提交。
     * 不写入 LAST_ISSUE，因此不算「已成功」。
     */
    fun notifyBetFailedOrTimedOut(context: Context, issue: String?, lotteryKey: String?, reason: String?) {
        val sp = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val inflightIssue = sp.getString(KEY_INFLIGHT_ISSUE, "")
        if (!issue.isNullOrBlank() && inflightIssue != issue) {
            // 非当前 inflight，忽略（避免旧任务误清）
            return
        }
        clearInflight(context)
        RuntimeLog.info(
            "AutoBet",
            "执行未成功，已清除进行中标记 期号=${issue ?: "-"} reason=${reason ?: "-"}，允许重试"
        )
    }

    private fun markInflight(context: Context, issue: String, lotteryKey: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_INFLIGHT_ISSUE, issue)
            .putString(KEY_INFLIGHT_LOTTERY, lotteryKey)
            .putLong(KEY_INFLIGHT_AT, System.currentTimeMillis())
            .apply()
    }

    private fun clearInflight(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .remove(KEY_INFLIGHT_ISSUE)
            .remove(KEY_INFLIGHT_LOTTERY)
            .remove(KEY_INFLIGHT_AT)
            .apply()
    }

    /** 是否反投模式 */
    fun isReverseBetMode(prefs: UserPrefs): Boolean =
        prefs.autoClickBetMode.equals("reverse", ignoreCase = true)

    fun betModeLabel(prefs: UserPrefs): String =
        if (isReverseBetMode(prefs)) "反投" else "正投"

    /** 大小取反：大↔小 */
    fun invertDx(dx: String?): String? = when (dx?.trim()) {
        "大" -> "小"
        "小" -> "大"
        else -> dx
    }

    /** 单双取反：单↔双 */
    fun invertDs(ds: String?): String? = when (ds?.trim()) {
        "单" -> "双"
        "双" -> "单"
        else -> ds
    }

    /**
     * 组合取反：大单↔小双、大双↔小单。
     * 即大小与单双同时取反。
     */
    fun invertCombo(combo: String?): String? = when (combo?.trim()) {
        "大单" -> "小双"
        "大双" -> "小单"
        "小单" -> "大双"
        "小双" -> "大单"
        else -> combo
    }

    /**
     * 解析实际要点击的方向（已按正投/反投处理）。
     * 面板展示与真实点击共用，避免显示与点击不一致。
     */
    fun resolveClickTargets(prefs: UserPrefs, snap: FloatingSnapshot): Triple<String?, String?, String?> {
        val (rawDx, rawDs) = resolvePrediction(prefs, snap)
        val rawCombo = resolveCombo(snap, prefs)
        return if (isReverseBetMode(prefs)) {
            Triple(invertDx(rawDx), invertDs(rawDs), invertCombo(rawCombo))
        } else {
            Triple(rawDx, rawDs, rawCombo)
        }
    }

    /**
     * 与悬浮窗完全一致的预测解析逻辑。
     */
    fun resolveCombo(snap: FloatingSnapshot, prefs: UserPrefs? = null): String? {
        val preferNova = prefs?.autoClickFollowBetSource == true && run {
            val bot = try { loadBotSource(CaiFenXiApplication.instance, snap.lotteryKey) } catch (_: Exception) { null }
            bot != null && BetSourceType.fromId(bot.first) == BetSourceType.NOVA_CONSENSUS
        }
        val candidates = if (preferNova) {
            listOf(snap.novaConsensusCombo, snap.consensusCombo, snap.algoCombo)
        } else {
            listOf(snap.consensusCombo, snap.novaConsensusCombo, snap.algoCombo)
        }
        for (c in candidates) {
            val t = c?.trim()
            if (t in listOf("大单", "大双", "小单", "小双")) return t
        }
        return null
    }

    fun resolvePredNumbers(snap: FloatingSnapshot): List<String> {
        return snap.predNumbers.orEmpty()
            .split(",", "、", "/", " ")
            .map { it.trim() }
            .filter { it.toIntOrNull() != null }
            .distinct()
            .take(20)
    }

    /** 读取当前彩种挂机 Bot 配置的来源类型与 sourceId（同步，失败返回 null） */
    fun loadBotSource(context: Context, lotteryKey: String): Pair<String, String>? {
        if (lotteryKey.isBlank()) return null
        return try {
            runBlocking {
                val cfg = CaiFenXiApplication.instance.database.betDao().getBotConfig(lotteryKey)
                if (cfg == null) null else cfg.sourceType to cfg.sourceId
            }
        } catch (_: Exception) {
            null
        }
    }

    /** 当前无障碍将使用的来源说明（设置页展示） */
    fun describeClickSource(context: Context, prefs: UserPrefs, lotteryKey: String): String {
        if (prefs.autoClickFollowBetSource) {
            val src = loadBotSource(context, lotteryKey)
            if (src != null) {
                val type = BetSourceType.fromId(src.first)
                return "跟随挂机：${type.label}" + if (src.second.isNotBlank() && type in listOf(BetSourceType.PLAN, BetSourceType.NOVA)) "（${src.second}）" else ""
            }
            return "跟随挂机：暂无 Bot 配置，回退悬浮窗"
        }
        return when (prefs.floatingSource) {
            "plan" -> "悬浮窗·指定计划"
            "algo" -> "悬浮窗·算法/驾驶舱"
            else -> "悬浮窗·共识"
        }
    }

    fun resolvePrediction(prefs: UserPrefs, snap: FloatingSnapshot): Pair<String?, String?> {
        val consensusDx = snap.consensusDx?.takeIf { it == "大" || it == "小" }
        val consensusDs = snap.consensusDs?.takeIf { it == "单" || it == "双" }
        val algoDx = snap.algoDx?.takeIf { it == "大" || it == "小" }
        val algoDs = snap.algoDs?.takeIf { it == "单" || it == "双" }
        val novaDx = snap.novaConsensusDx?.takeIf { it == "大" || it == "小" }
        val novaDs = snap.novaConsensusDs?.takeIf { it == "单" || it == "双" }

        if (prefs.autoClickFollowBetSource) {
            val bot = try {
                loadBotSource(CaiFenXiApplication.instance, snap.lotteryKey)
            } catch (_: Exception) {
                null
            }
            if (bot != null) {
                val (sourceType, sourceId) = bot
                return resolveByBetSource(sourceType, sourceId, snap, consensusDx, consensusDs, algoDx, algoDs, novaDx, novaDs)
            }
        }

        val selectedDxId = prefs.floatingDxPlanId.ifBlank { prefs.floatingPlanId }
        val selectedDsId = prefs.floatingDsPlanId.ifBlank { prefs.floatingPlanId }
        val dxPlan = snap.plans.firstOrNull { it.planId == selectedDxId && !it.dx.isNullOrBlank() }
        val dsPlan = snap.plans.firstOrNull { it.planId == selectedDsId && !it.ds.isNullOrBlank() }

        var dx: String? = null
        var ds: String? = null

        when (prefs.floatingSource) {
            "plan" -> {
                dx = dxPlan?.dx?.split("/", "、", ",")?.firstOrNull { it == "大" || it == "小" }
                ds = dsPlan?.ds?.split("/", "、", ",")?.firstOrNull { it == "单" || it == "双" }
                if (dx == null) dx = consensusDx ?: algoDx
                if (ds == null) ds = consensusDs ?: algoDs
            }
            "algo" -> {
                dx = algoDx ?: consensusDx
                ds = algoDs ?: consensusDs
            }
            else -> {
                dx = consensusDx ?: algoDx
                ds = consensusDs ?: algoDs
            }
        }
        return dx to ds
    }

    private fun resolveByBetSource(
        sourceType: String,
        sourceId: String,
        snap: FloatingSnapshot,
        consensusDx: String?,
        consensusDs: String?,
        algoDx: String?,
        algoDs: String?,
        novaDx: String?,
        novaDs: String?
    ): Pair<String?, String?> {
        fun fromPlan(planId: String): Pair<String?, String?> {
            val dx = snap.plans.firstOrNull { it.planId == planId && !it.dx.isNullOrBlank() }
                ?.dx?.split("/", "、", ",")?.firstOrNull { it == "大" || it == "小" }
            val ds = snap.plans.firstOrNull { it.planId == planId && !it.ds.isNullOrBlank() }
                ?.ds?.split("/", "、", ",")?.firstOrNull { it == "单" || it == "双" }
            return dx to ds
        }
        return when (BetSourceType.fromId(sourceType)) {
            BetSourceType.COCKPIT, BetSourceType.ALGO ->
                (algoDx ?: consensusDx) to (algoDs ?: consensusDs)
            BetSourceType.CONSENSUS ->
                (consensusDx ?: algoDx) to (consensusDs ?: algoDs)
            BetSourceType.NOVA_CONSENSUS ->
                (novaDx ?: consensusDx ?: algoDx) to (novaDs ?: consensusDs ?: algoDs)
            BetSourceType.PLAN, BetSourceType.NOVA -> {
                val (dx, ds) = fromPlan(sourceId)
                (dx ?: consensusDx ?: algoDx) to (ds ?: consensusDs ?: algoDs)
            }
            BetSourceType.AUTO_BEST -> {
                // 快照无战绩时优先共识再算法
                (consensusDx ?: algoDx) to (consensusDs ?: algoDs)
            }
        }
    }

    /** 手动立即尝试一次（设置页按钮用） */
    fun tryNow(context: Context) {
        val snap = FloatingOverlayStore.loadLastReady(context)
            ?: FloatingOverlayStore.load(context)
        if (snap == null) {
            RuntimeLog.warn("AutoBet", "当前无可用预测快照")
            return
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .remove(KEY_LAST_ISSUE)
            .remove(KEY_LAST_LOTTERY)
            .remove(KEY_INFLIGHT_ISSUE)
            .remove(KEY_INFLIGHT_LOTTERY)
            .remove(KEY_INFLIGHT_AT)
            .apply()
        onPredictionReady(context, snap.copy(status = "READY"), force = true)
    }
}
