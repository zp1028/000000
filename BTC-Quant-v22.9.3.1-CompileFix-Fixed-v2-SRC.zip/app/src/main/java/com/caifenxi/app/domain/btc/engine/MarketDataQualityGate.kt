package com.caifenxi.app.domain.btc.engine

import kotlin.math.abs

/**
 * Deterministic pre-trade data gate shared by every execution engine.
 * A signal is never allowed to bypass stale/invalid market data checks.
 */
data class MarketDataQuality(
    val sampleCount: Int,
    val latestTimestampMs: Long,
    val nowMs: Long,
    val maxAgeMs: Long,
    val price: Double,
    val previousPrice: Double?,
    val source: String = "BINANCE"
) {
    val ageMs: Long get() = (nowMs - latestTimestampMs).coerceAtLeast(0L)
    val priceValid: Boolean get() = price.isFinite() && price > 0.0
    val previousValid: Boolean get() = previousPrice == null || (previousPrice.isFinite() && previousPrice > 0.0)
    val timestampValid: Boolean get() = latestTimestampMs > 0L && latestTimestampMs <= nowMs + 5_000L
    val fresh: Boolean get() = ageMs <= maxAgeMs
    val priceJumpValid: Boolean
        get() = previousPrice?.let { abs(price / it - 1.0) <= 0.25 } ?: true
    val ok: Boolean get() = sampleCount >= 80 && priceValid && previousValid && timestampValid && fresh && priceJumpValid

    fun reason(): String = when {
        sampleCount < 80 -> "K线样本不足"
        !priceValid -> "最新价格无效"
        !previousValid -> "前值价格无效"
        !timestampValid -> "数据时间戳异常"
        !fresh -> "行情过期 ${ageMs}ms"
        !priceJumpValid -> "价格跳变异常"
        else -> "OK"
    }
}

object MarketDataQualityGate {
    fun evaluate(
        sampleCount: Int,
        latestTimestampMs: Long,
        price: Double,
        previousPrice: Double?,
        nowMs: Long = System.currentTimeMillis(),
        maxAgeMs: Long = 30_000L,
        source: String = "BINANCE"
    ): MarketDataQuality = MarketDataQuality(
        sampleCount = sampleCount,
        latestTimestampMs = latestTimestampMs,
        nowMs = nowMs,
        maxAgeMs = maxAgeMs,
        price = price,
        previousPrice = previousPrice,
        source = source
    )
}
