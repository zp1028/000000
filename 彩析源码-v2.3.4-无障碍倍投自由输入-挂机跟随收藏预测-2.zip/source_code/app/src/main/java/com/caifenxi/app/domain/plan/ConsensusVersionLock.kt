package com.caifenxi.app.domain.plan

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference

/**
 * 共识版本锁定：挂机/执行链路启动时锁定当前共识策略版本，
 * 运行过程中修改排行榜、参与上限不会偷偷改变正在执行的策略。
 * 只有「停止 → 更新策略 → 重新启动」才切换。
 */
object ConsensusVersionLock {

    data class LockedSession(
        val version: String,
        val lotteryKey: String,
        val consensusLimit: Int,
        val participatingPlanIds: List<String>,
        val lockedAt: Long = System.currentTimeMillis(),
        val note: String = ""
    )

    private val seq = AtomicInteger(0)
    private val currentVersion = AtomicReference("")
    private val lockedSession = AtomicReference<LockedSession?>(null)

    /** 生成新版本号：Nova共识 Vyyyy-MM-dd NNN */
    fun mintVersion(now: Long = System.currentTimeMillis()): String {
        val day = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(now))
        val n = seq.incrementAndGet().coerceAtLeast(1)
        val v = "Nova共识 V$day ${n.toString().padStart(3, '0')}"
        currentVersion.set(v)
        return v
    }

    fun peekVersion(): String {
        val cur = currentVersion.get()
        if (cur.isNotBlank()) return cur
        return mintVersion()
    }

    /** 挂机启动时锁定 */
    fun lockForHang(
        lotteryKey: String,
        consensusLimit: Int,
        participatingPlanIds: List<String>,
        note: String = ""
    ): LockedSession {
        val version = peekVersion().ifBlank { mintVersion() }
        val session = LockedSession(
            version = version,
            lotteryKey = lotteryKey,
            consensusLimit = consensusLimit,
            participatingPlanIds = participatingPlanIds.distinct(),
            note = note
        )
        lockedSession.set(session)
        return session
    }

    fun isLocked(): Boolean = lockedSession.get() != null

    fun currentLock(): LockedSession? = lockedSession.get()

    /** 停止挂机时解锁，允许下次启动使用新策略 */
    fun unlock() {
        lockedSession.set(null)
    }

    /**
     * 若已锁定：返回锁定会话中的 limit / planIds，调用方应使用它们做共识，而不是最新 UI 配置。
     * 未锁定：返回 null，使用当前配置。
     */
    fun activeConstraint(): LockedSession? = lockedSession.get()
}
