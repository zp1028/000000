package com.caifenxi.app.domain.plan

import com.caifenxi.app.domain.model.DrawRecord
import com.caifenxi.app.domain.model.ModelConsensus
import com.caifenxi.app.domain.model.PlanDefinition
import com.caifenxi.app.domain.model.PlanHitCriteria
import com.caifenxi.app.domain.model.PlanOutputFormat
import com.caifenxi.app.domain.model.PlanPredictionRecord
import com.caifenxi.app.domain.model.PlanRuntime
import com.caifenxi.app.domain.model.PlanTrendPoint
import com.caifenxi.app.domain.model.PlanStatus
import com.caifenxi.app.domain.model.UserPrefs
import kotlin.math.min
import kotlinx.coroutines.CancellationException

/**
 * 计划引擎:
 * - 每期自动随机生成一批预测计划(基于模板池)
 * - 支持用户自定义计划(CustomPlan)参与预测与共识
 * - 结算后累计每个计划的对错成功率
 *
 * 线程安全修复:historyPreds/careerStats/runtimes 等共享可变状态原来会被
 * loadData、自动刷新、切换算法等多个协程并发读写(各自在 Default 线程池
 * 执行回测/预测/结算),并发时抛 ConcurrentModificationException 或损坏
 * HashMap,表现为「卡死→闪退」。所有公开方法加 @Synchronized 串行化。
 */
class PlanEngine {

    companion object {
        /** 单次回测最多处理的历史期数:极速类彩种一天上千期,全量回测会导致主链路卡死 */
        const val DEFAULT_BACKTEST_PERIODS = 500
        const val MAX_BACKTEST_PERIODS = Int.MAX_VALUE
        /** 取消检查的周期(期数) */
        private const val CANCEL_CHECK_EVERY = 10
    }

    private val runtimes = mutableMapOf<String, PlanRuntime>()
    /** 模板 planId → 累计统计(跨期保留成功率) */
    private val careerStats = mutableMapOf<String, PlanRuntime>()
    private val historyPreds = mutableListOf<PlanPredictionRecord>()
    /** 每个计划最近 120 个结算点的评分/权重趋势，内存缓存，不参与预测计算。 */
    private val trendHistory = mutableMapOf<String, MutableList<PlanTrendPoint>>()
    /** 当前期随机激活的计划定义 */
    private var activePlans: List<PlanDefinition> = emptyList()
    /** 用户自定义计划(持久化自 Room,参与预测/共识) */
    private var customPlans: List<PlanDefinition> = emptyList()
    private var lastGenIssue: String = ""
    /** 增量回测游标:记录已回测到的彩种与期号,避免每次刷新全量重算、战绩重复累加 */
    private var backtestLotteryKey: String = ""
    private var lastBacktestIssue: String = ""

    /** 注入用户自定义计划;在每期生成与回测时并入 activePlans */
    @Synchronized
    fun setCustomPlans(plans: List<PlanDefinition>) {
        customPlans = plans
        customPlans.forEach { def ->
            if (!careerStats.containsKey(def.planId)) {
                careerStats[def.planId] = PlanRuntime(planId = def.planId)
            }
        }
    }

    @Synchronized
    fun getCustomPlans(): List<PlanDefinition> = customPlans.toList()

    fun ensureCareerFromPool() {
        synchronized(this) {
            (PlanPool.ALL + NovaPlanPool.ALL).forEach { def ->
                if (!careerStats.containsKey(def.planId)) {
                    careerStats[def.planId] = PlanRuntime(planId = def.planId)
                }
            }
        }
    }

    /**
     * 按用户勾选的计划池激活当期计划(不再每期随机)。
     * selectedPlanIds 为空时:模板池前 planPoolCount 条 + 全部自定义。
     */
    @Synchronized
    fun activatePlansForIssue(
        targetIssue: String,
        prefs: UserPrefs,
        force: Boolean = false
    ): List<PlanDefinition> {
        if (!force && lastGenIssue == targetIssue && activePlans.isNotEmpty()) {
            return activePlans
        }
        val pool = resolvePoolPlans(prefs)
        activePlans = pool.map { it.copy(seedIssue = targetIssue, randomGenerated = false) }
        lastGenIssue = targetIssue
        activePlans.forEach { def ->
            runtimes[def.planId] = careerStats[def.planId] ?: PlanRuntime(planId = def.planId)
        }
        return activePlans
    }

    /** 兼容旧调用名 → 固定计划池激活 */
    @Synchronized
    fun generateRandomPlansForIssue(
        targetIssue: String,
        count: Int = 12,
        force: Boolean = false
    ): List<PlanDefinition> {
        // count 仅作兜底 prefs 使用;真正池子由 setCustomPlans + selectedPlanIds 决定
        val fakePrefs = UserPrefs(planPoolCount = count)
        return activatePlansForIssue(targetIssue, fakePrefs, force)
    }

    /**
     * 解析计划池定义列表(不改 activePlans)。
     * 优先用户勾选 ID;否则模板前 N + 自定义。
     */
    private fun resolvePoolPlans(prefs: UserPrefs): List<PlanDefinition> {
        ensureCareerFromPool()
        val customs = customPlans
        val selected = prefs.selectedPlanIds
        val list = if (selected.isNotEmpty()) {
            selected.mapNotNull { id ->
                PlanPool.ALL.find { it.planId == id }
                    ?: NovaPlanPool.ALL.find { it.planId == id }
                    ?: customs.find { it.planId == id }
            }
        } else {
            (PlanPool.ALL.take(prefs.planPoolCount.coerceIn(4, 40)) + customs)
        }.distinctBy { it.planId }
        list.forEach { def ->
            if (!careerStats.containsKey(def.planId)) {
                careerStats[def.planId] = PlanRuntime(planId = def.planId)
            }
        }
        return list
    }

    @Synchronized
    fun getActivePlans(): List<PlanDefinition> = activePlans.toList()

    @Synchronized
    fun getRuntimes(): List<Pair<PlanDefinition, PlanRuntime>> {
        ensureCareerFromPool()
        val defs = if (activePlans.isNotEmpty()) activePlans else PlanPool.ALL + NovaPlanPool.ALL + customPlans
        return defs.map { def ->
            val rt = careerStats[def.planId] ?: runtimes[def.planId] ?: PlanRuntime(def.planId)
            def to rt
        }.sortedWith(
            compareByDescending<Pair<PlanDefinition, PlanRuntime>> { it.second.sampleCount >= 20 }
                .thenByDescending { it.second.score }
                .thenByDescending { it.second.hitRate }
                .thenByDescending { it.second.sampleCount }
        )
    }

    /** 某计划的预测历史(含当期与已结算) */
    @Synchronized
    fun getPredictionHistory(planId: String, limit: Int = 30): List<PlanPredictionRecord> =
        historyPreds.filter { it.planId == planId }.takeLast(limit).reversed()

    /** 当期(未结算)全部计划预测 */
    @Synchronized
    fun getCurrentPredictions(targetIssue: String): List<PlanPredictionRecord> =
        historyPreds.filter { it.targetIssue == targetIssue && !it.settled }
            .ifEmpty {
                emptyList()
            }

    @Synchronized
    fun getAllRecentPredictions(limit: Int = 80): List<PlanPredictionRecord> =
        historyPreds.takeLast(limit).reversed()

    @Synchronized
    fun getTrend(planId: String, limit: Int = 120): List<PlanTrendPoint> =
        trendHistory[planId].orEmpty().takeLast(limit).toList()

    @Synchronized
    fun getAllTrends(limitPerPlan: Int = 60): Map<String, List<PlanTrendPoint>> =
        trendHistory.mapValues { it.value.takeLast(limitPerPlan).toList() }

    @Synchronized
    fun clearTrendHistory() { trendHistory.clear() }

    @Synchronized
    fun getCareerLeaderboard(): List<Pair<PlanDefinition, PlanRuntime>> {
        ensureCareerFromPool()
        return (PlanPool.ALL + NovaPlanPool.ALL + customPlans).map { it to (careerStats[it.planId] ?: PlanRuntime(it.planId)) }
            .sortedWith(
                compareByDescending<Pair<PlanDefinition, PlanRuntime>> { it.second.sampleCount >= 20 }
                    .thenByDescending { it.second.score }
                    .thenByDescending { it.second.hitRate }
                    .thenByDescending { it.second.sampleCount }
            )
    }

    /**
     * 回测。默认增量:只回测上次回测之后的新期号。
     *
     * 修复点:
     * 1) 原实现每次调用都对全量历史回测,且每次都把已结算记录重复 add 进
     *    historyPreds 并重复调用 updateRuntime —— 刷新几次后样本数成倍虚增、
     *    计划历史大量重复,且 CPU 空转严重。改为增量后每次只算新增期号。
     * 2) 原实现 predictAll 已写入一条未结算记录,backtest 再 add 一条结算副本,
     *    同一计划同一期留下两条记录(其中一条永远"待开"成为脏数据)。
     *    现在添加结算记录前先移除同 planId+期号 的旧记录。
     * 3) 回测窗口由调用方指定，不再把500期作为硬上限；500期仅为默认窗口
     *    (cancellationCheck 返回 true 时抛 CancellationException),
     *    避免极速类彩种全量回测拖垮主链路、堆积卡死。
     *
     * @param forceFull true 时从头全量重算(用于手动「重新滚动验证」)
     * @param timeLimitMs 限时(毫秒):超时即保存进度正常返回,剩余期数下次增量续跑。
     *                    用于后台增量回测,避免单次持锁过久阻塞心跳/在线预测;
     *                    手动全量回测传 null 表示不限时。
     * @param cancellationCheck 每 CANCEL_CHECK_EVERY 期检查一次,返回 true 即取消
     *                          (必须放最后,供调用方 trailing lambda 绑定)
     */
    @Synchronized
    fun backtest(
        history: List<DrawRecord>,
        prefs: UserPrefs,
        minWarm: Int = 30,
        forceFull: Boolean = false,
        timeLimitMs: Long? = null,
        requestedPeriods: Int? = null,
        cancellationCheck: (() -> Boolean)? = null
    ) {
        ensureCareerFromPool()
        if (history.size < minWarm + 5) return
        val lotteryKey = history.firstOrNull()?.lotteryKey ?: return
        if (forceFull || lotteryKey != backtestLotteryKey) {
            backtestLotteryKey = lotteryKey
            lastBacktestIssue = ""
        }
        // 增量起点:上次回测到的期号之后
        var start = minWarm
        if (lastBacktestIssue.isNotBlank()) {
            val idx = history.indexOfFirst { it.issue == lastBacktestIssue }
            start = if (idx >= 0) idx + 1 else minWarm
        }
        // 回测窗口可调：null=从最早可用样本开始；否则取最近 requestedPeriods 期。
        // 500 只是默认值，不再是硬上限。
        val window = requestedPeriods?.takeIf { it > 0 } ?: DEFAULT_BACKTEST_PERIODS
        val maxStart = (history.size - window).coerceAtLeast(minWarm)
        start = start.coerceAtLeast(maxStart)
        if (start >= history.size) return
        val deadline = timeLimitMs?.let { System.currentTimeMillis() + it }
        var i = start.coerceAtLeast(minWarm)
        while (i < history.size) {
            if (cancellationCheck != null && i % CANCEL_CHECK_EVERY == 0 && cancellationCheck()) {
                // 取消前先推进游标:已回测到 i-1 期,下次从该期之后续跑,
                // 避免被取消后 lastBacktestIssue 仍为空导致无限全量重跑(锁被长期占用)
                if (i > start) lastBacktestIssue = history[i - 1].issue
                throw CancellationException("backtest cancelled at index $i")
            }
            // 限时保护:超时即保存进度返回,剩余期数下次增量续跑
            if (deadline != null && System.currentTimeMillis() > deadline) {
                if (i > start) lastBacktestIssue = history[i - 1].issue
                return
            }
            val cutoff = history.subList(0, i)
            val actual = history[i]
            // 固定计划池回测(用户勾选/默认模板),不写全局 activePlans
            val plans = resolvePoolPlans(prefs)
            val preds = predictAll(cutoff, prefs, actual.issue, cutoff.last().issue, plans)
            preds.forEach { rec ->
                val hit = evaluateHit(rec, actual)
                val settled = rec.copy(settled = true, hit = hit, settledAt = System.currentTimeMillis())
                // 先移除同计划同期号的旧记录(含 predictAll 刚写入的未结算记录),避免重复
                historyPreds.removeAll { it.planId == rec.planId && it.targetIssue == rec.targetIssue }
                historyPreds.add(settled)
                updateRuntime(settled, prefs.backtestParams)
            }
            i++
        }
        lastBacktestIssue = history.last().issue
    }

    @Synchronized
    fun clearCareer() {
        careerStats.clear()
        runtimes.clear()
        historyPreds.clear()
        trendHistory.clear()
        activePlans = emptyList()
        lastGenIssue = ""
        backtestLotteryKey = ""
        lastBacktestIssue = ""
    }

    @Synchronized
    fun predictForNext(
        history: List<DrawRecord>,
        prefs: UserPrefs,
        targetIssue: String,
        cutoffIssue: String
    ): List<PlanPredictionRecord> {
        activatePlansForIssue(targetIssue, prefs, force = false)
        return predictAll(history, prefs, targetIssue, cutoffIssue)
    }

    /**
     * @param comboTopN 组合共识输出候选数,与设置 comboPredCount 同步
     */
    @Synchronized
    fun consensus(
        lotteryKey: String,
        targetIssue: String,
        preds: List<PlanPredictionRecord>,
        comboTopN: Int = 2
    ): List<ModelConsensus> {
        val byCat = preds.groupBy { it.category.ifBlank { planCategory(it.planId) } }
        return listOf("大小", "单双", "组合", "位置-冠军", "位置-亚军", "位置-第3").mapNotNull { cat ->
            val list = byCat[cat] ?: return@mapNotNull null
            val weightSum = mutableMapOf<String, Double>()
            var totalW = 0.0
            list.forEach { rec ->
                val rt = careerStats[rec.planId] ?: runtimes[rec.planId] ?: return@forEach
                if (rt.status == PlanStatus.ELIMINATED) return@forEach
                val wr = if (rt.sampleCount >= 5) 0.5 + rt.hitRate * 0.5 else 0.5
                // V9.6 动态趋势加权：趋势只做温和修正，不改变原始回测评分。
                // 近期评分持续上升给予最多 +12% 加成，持续下降最多 -12%。
                // 样本不足时自动收缩，避免短期偶然连中导致权重失控。
                val trendBoost = trendWeightBoost(rec.planId, rt.sampleCount)
                val w = (rt.weight * wr * trendBoost).coerceIn(0.05, 1.5)
                val cands = rec.output.split("/", "、", ",").map { it.trim() }.filter { it.isNotEmpty() }
                if (cands.isEmpty()) return@forEach
                val share = w / cands.size
                cands.forEach { cand -> weightSum[cand] = (weightSum[cand] ?: 0.0) + share }
                totalW += w
            }
            if (totalW <= 0) return@mapNotNull null
            // 大小/单双:只保留单一方向,禁止对冲;组合/位置按设置条数
            val takeN = when (cat) {
                "大小", "单双" -> 1
                "组合" -> comboTopN.coerceIn(1, 4)
                else -> comboTopN.coerceIn(1, 4)
            }
            val top = weightSum.entries.sortedByDescending { it.value }.take(takeN)
            if (top.isEmpty()) return@mapNotNull null
            val leading = top.first()
            val ratio = leading.value / totalW
            val second = top.getOrNull(1)?.value ?: 0.0
            val disagreement = if (leading.value > 0) second / leading.value else 1.0
            ModelConsensus(
                lotteryKey = lotteryKey,
                targetIssue = targetIssue,
                category = cat,
                leadingDirection = top.joinToString("/") { it.key },
                supportRatio = ratio,
                disagreement = disagreement,
                participatingPlans = list.size,
                detail = weightSum.mapValues { it.value / totalW }
            )
        }
    }

    private fun predictAll(
        history: List<DrawRecord>,
        prefs: UserPrefs,
        targetIssue: String,
        cutoffIssue: String,
        plans: List<PlanDefinition>? = null
    ): List<PlanPredictionRecord> {
        val defs = plans ?: if (activePlans.isNotEmpty()) activePlans else {
            activatePlansForIssue(targetIssue, prefs, true)
            activePlans
        }
        return defs.mapNotNull { def ->
            val out = runPlan(def, history, prefs) ?: return@mapNotNull null
            val rt = careerStats[def.planId] ?: PlanRuntime(def.planId)
            val rec = PlanPredictionRecord(
                planId = def.planId,
                lotteryKey = history.lastOrNull()?.lotteryKey ?: "",
                targetIssue = targetIssue,
                cutoffIssue = cutoffIssue,
                output = out,
                scoreAtPredict = rt.score,
                weightAtPredict = rt.weight,
                planName = def.planName,
                category = def.category
            )
            // 记录当期预测(同 plan+issue 替换未结算)
            historyPreds.removeAll { it.planId == def.planId && it.targetIssue == targetIssue && !it.settled }
            historyPreds.add(rec)
            // 不再按5000条硬截断。持久化层/分页查询负责控制内存与UI读取量。
            // 同步 lastPrediction
            val updated = rt.copy(lastPrediction = out, lastTargetIssue = targetIssue)
            careerStats[def.planId] = updated
            runtimes[def.planId] = updated
            rec
        }
    }

    private fun runPlan(def: PlanDefinition, history: List<DrawRecord>, prefs: UserPrefs): String? {
        val slice = history.takeLast(def.window.coerceAtLeast(5).coerceAtMost(history.size))
        if (slice.size < 3) return null
        // 组合/号码输出条数跟随设置中的预测数量
        val comboN = prefs.comboPredCount.coerceIn(1, 4)
        val numN = prefs.positionTopN.coerceIn(1, 10).coerceAtLeast(prefs.zuheTopN.coerceIn(1, 10))
        if (def.planId.startsWith("NOVA-")) {
            return NovaPlanAnalytics.predict(def, slice)?.output
        }
        return when (def.category) {
            "大小" -> majority(slice.mapNotNull { it.dx }, def, prefs)
            "单双" -> majority(slice.mapNotNull { it.ds }, def, prefs)
            "组合" -> topMajors(slice.mapNotNull { it.combo }, def, prefs, comboN)
            "区间", "结构", "AI" -> topMajors(slice.mapNotNull { it.combo }, def, prefs, comboN)
            "号码" -> {
                val cnt = mutableMapOf<Int, Int>()
                slice.forEach { r -> r.numbers.forEach { n -> cnt[n] = (cnt[n] ?: 0) + 1 } }
                cnt.entries.sortedByDescending { it.value }.take(numN)
                    .joinToString("/") { it.key.toString() }
                    .ifBlank { null }
            }
            "位置-冠军", "位置-亚军", "位置-第3" -> {
                val position = when (def.category) {
                    "位置-冠军" -> 0
                    "位置-亚军" -> 1
                    else -> 2
                }
                val seq = slice.mapNotNull { it.numbers.getOrNull(position)?.toString() }
                topMajors(seq, def, prefs, numN)
            }
            else -> majority(slice.mapNotNull { it.dx }, def, prefs)
        }
    }

    /** 多候选输出,用 / 连接,数量由设置决定 */
    private fun topMajors(seq: List<String>, def: PlanDefinition, prefs: UserPrefs, topN: Int): String? {
        if (seq.isEmpty()) return null
        val scores = when (def.algorithm) {
            "EWMA" -> {
                val alpha = prefs.ewmaAlpha.toDouble()
                val labels = seq.distinct()
                val ewma = labels.associateWith { 0.0 }.toMutableMap()
                seq.forEach { x ->
                    labels.forEach { lab ->
                        val t = if (lab == x) 1.0 else 0.0
                        ewma[lab] = alpha * t + (1 - alpha) * (ewma[lab] ?: 0.0)
                    }
                }
                ewma
            }
            "MKV1" -> {
                if (seq.size < 2) return majority(seq, def, prefs)
                val last = seq.last()
                val next = mutableMapOf<String, Double>()
                for (i in 1 until seq.size) {
                    if (seq[i - 1] == last) next[seq[i]] = (next[seq[i]] ?: 0.0) + 1.0
                }
                if (next.isEmpty()) seq.groupingBy { it }.eachCount().mapValues { it.value.toDouble() }
                else next
            }
            else -> seq.groupingBy { it }.eachCount().mapValues { it.value.toDouble() }
        }
        return scores.entries.sortedByDescending { it.value }.take(topN.coerceAtLeast(1))
            .joinToString("/") { it.key }
            .ifBlank { null }
    }

    private fun majority(seq: List<String>, def: PlanDefinition, prefs: UserPrefs): String? {
        if (seq.isEmpty()) return null
        return when (def.algorithm) {
            "EWMA" -> {
                val alpha = prefs.ewmaAlpha.toDouble()
                val labels = seq.distinct()
                val ewma = labels.associateWith { 0.0 }.toMutableMap()
                seq.forEach { x ->
                    labels.forEach { lab ->
                        val t = if (lab == x) 1.0 else 0.0
                        ewma[lab] = alpha * t + (1 - alpha) * (ewma[lab] ?: 0.0)
                    }
                }
                ewma.maxByOrNull { it.value }?.key
            }
            "MKV1" -> {
                if (seq.size < 2) return seq.groupingBy { it }.eachCount().maxByOrNull { it.value }?.key
                val last = seq.last()
                val next = mutableMapOf<String, Int>()
                for (i in 1 until seq.size) {
                    if (seq[i - 1] == last) next[seq[i]] = (next[seq[i]] ?: 0) + 1
                }
                next.maxByOrNull { it.value }?.key
                    ?: seq.groupingBy { it }.eachCount().maxByOrNull { it.value }?.key
            }
            else -> seq.groupingBy { it }.eachCount().maxByOrNull { it.value }?.key
        }
    }

    /** 新开奖结算计划预测 */
    @Synchronized
    fun settlePendingWithDraw(draw: DrawRecord, params: com.caifenxi.app.domain.model.BacktestParams = com.caifenxi.app.domain.model.BacktestParams()) {
        val pending = historyPreds.filter { !it.settled && issueReached(it.targetIssue, draw.issue) }
        pending.forEach { rec ->
            val hit = evaluateHit(rec, draw)
            val settled = rec.copy(settled = true, hit = hit, settledAt = System.currentTimeMillis())
            val idx = historyPreds.indexOfFirst {
                it.planId == rec.planId && it.targetIssue == rec.targetIssue && !it.settled
            }
            if (idx >= 0) historyPreds[idx] = settled else historyPreds.add(settled)
            updateRuntime(settled, params)
        }
    }

    private fun issueReached(predIssue: String, drawIssue: String): Boolean {
        if (predIssue == drawIssue) return true
        val a = predIssue.toLongOrNull()
        val b = drawIssue.toLongOrNull()
        return a != null && b != null && a <= b
    }

    private fun evaluateHit(rec: PlanPredictionRecord, actual: DrawRecord): Boolean {
        val cat = rec.category.ifBlank { planCategory(rec.planId) }
        val parts = rec.output.split("/", "、", ",").map { it.trim() }.filter { it.isNotEmpty() }
        return when (cat) {
            "大小" -> parts.any { it == actual.dx } || rec.output == actual.dx
            "单双" -> parts.any { it == actual.ds } || rec.output == actual.ds
            "组合", "区间", "结构", "AI" -> {
                val a = actual.combo ?: return false
                // 多候选:开奖落在候选中即对
                parts.any { it == a }
            }
            "号码" -> {
                // 多号码:任一预测号码出现在开奖号码中即对
                parts.any { it.toIntOrNull()?.let { n -> n in actual.numbers } == true }
            }
            "位置-冠军", "位置-亚军", "位置-第3" -> {
                val position = when (cat) {
                    "位置-冠军" -> 0
                    "位置-亚军" -> 1
                    else -> 2
                }
                val actualNumber = actual.numberAt(position)
                parts.any { it.toIntOrNull() == actualNumber }
            }
            else -> parts.any { it == actual.dx || it == actual.ds || it == actual.combo }
        }
    }

    /**
     * V9.4 计划评分闭环:
     * - 近期10/中期50/长期200期滚动表现共同决定分数
     * - 样本可信度抑制小样本冲高
     * - 与基准线比较,记录 baselineEdge
     * - 记录最大连中/最大连错
     * - 权重每次最多变化 ±15%,避免单期结果造成剧烈跳变
     */
    private fun updateRuntime(
        rec: PlanPredictionRecord,
        params: com.caifenxi.app.domain.model.BacktestParams = com.caifenxi.app.domain.model.BacktestParams()
    ) {
        val prev = careerStats[rec.planId] ?: PlanRuntime(planId = rec.planId)
        val hit = rec.hit == true
        val sample = prev.sampleCount + 1
        val hits = prev.hitCount + if (hit) 1 else 0
        val miss = if (hit) 0 else prev.consecutiveMiss + 1
        val streakHit = if (hit) prev.consecutiveHit + 1 else 0
        val maxMiss = maxOf(prev.maxConsecutiveMiss, miss)
        val maxHit = maxOf(prev.maxConsecutiveHit, streakHit)

        val settled = historyPreds
            .asSequence()
            .filter { it.planId == rec.planId && it.settled && it.hit != null }
            .toList()
        fun rollingRate(n: Int): Double {
            val tail = settled.takeLast(n)
            return if (tail.isEmpty()) 0.0 else tail.count { it.hit == true }.toDouble() / tail.size
        }
        val recent10 = rollingRate(10)
        val recent50 = rollingRate(50)
        val recent200 = rollingRate(200)
        val hitRate = hits.toDouble() / sample
        val baseline = (PlanPool.ALL + customPlans).firstOrNull { it.planId == rec.planId }?.baselineValue ?: 0.50
        val baselineEdge = hitRate - baseline

        // 近期30% + 中期25% + 长期20% + 稳定性10% + 样本可信度10% + 基准优势5%
        val stability = (1.0 - kotlin.math.abs(recent10 - recent50)).coerceIn(0.0, 1.0)
        val sampleConfidence = (sample / 100.0).coerceIn(0.0, 1.0)
        var score = (
            recent10 * 30.0 +
                recent50 * 25.0 +
                recent200 * 20.0 +
                stability * 10.0 +
                sampleConfidence * 10.0 +
                ((baselineEdge + 0.10) / 0.20).coerceIn(0.0, 1.0) * 5.0
            )
        if (miss >= params.streakPenaltyStart) {
            score -= params.streak * (miss - params.streakPenaltyStart + 1) * 0.15
        }
        score = score.coerceIn(0.0, 100.0)

        val rawWeight = (0.5 + (score - 50.0) / 100.0).coerceIn(0.35, 1.15)
        val minWeight = (prev.weight * 0.85).coerceAtLeast(0.35)
        val maxWeight = (prev.weight * 1.15).coerceAtMost(1.15)
        val weight = rawWeight.coerceIn(minWeight, maxWeight)
        val weightDelta = weight - prev.weight

        val status = when {
            miss >= 12 && sample >= 30 -> PlanStatus.DEMOTED
            sample >= 100 && hitRate < baseline - 0.08 -> PlanStatus.ELIMINATED
            score >= params.promoteThreshold && sample >= 50 -> PlanStatus.PROMOTED
            else -> PlanStatus.ACTIVE
        }

        val updated = prev.copy(
            weight = weight,
            score = score,
            sampleCount = sample,
            hitCount = hits,
            consecutiveMiss = miss,
            consecutiveHit = streakHit,
            maxConsecutiveMiss = maxMiss,
            maxConsecutiveHit = maxHit,
            recent10Rate = recent10,
            recent50Rate = recent50,
            recent200Rate = recent200,
            baselineEdge = baselineEdge,
            weightDelta = weightDelta,
            status = status,
            lastPrediction = rec.output,
            lastTargetIssue = rec.targetIssue
        )
        careerStats[rec.planId] = updated
        runtimes[rec.planId] = updated
        val trend = trendHistory.getOrPut(rec.planId) { mutableListOf() }
        trend.add(
            PlanTrendPoint(
                issue = rec.targetIssue,
                planId = rec.planId,
                score = updated.score,
                weight = updated.weight,
                hitRate = updated.hitRate,
                sampleCount = updated.sampleCount
            )
        )
        if (trend.size > 120) trend.subList(0, trend.size - 120).clear()
    }

    /**
     * V9.6 趋势权重修正。
     * 只比较最近趋势点与较早趋势点的平均评分，避免单点噪声。
     * 返回值范围 0.88..1.12；样本越少，修正越弱。
     */
    @Synchronized
    private fun trendWeightBoost(planId: String, sampleCount: Int): Double {
        if (sampleCount < 20) return 1.0
        val points = trendHistory[planId].orEmpty().takeLast(12)
        if (points.size < 6) return 1.0
        val half = points.size / 2
        val early = points.take(half).map { it.score }.average()
        val recent = points.takeLast(half).map { it.score }.average()
        val delta = (recent - early).coerceIn(-15.0, 15.0)
        val sampleFactor = ((sampleCount - 20) / 80.0).coerceIn(0.25, 1.0)
        return (1.0 + (delta / 15.0) * 0.12 * sampleFactor).coerceIn(0.88, 1.12)
    }

    private fun planCategory(planId: String): String =
        activePlans.find { it.planId == planId }?.category
            ?: PlanPool.ALL.find { it.planId == planId }?.category
            ?: customPlans.find { it.planId == planId }?.category
            ?: ""
}
