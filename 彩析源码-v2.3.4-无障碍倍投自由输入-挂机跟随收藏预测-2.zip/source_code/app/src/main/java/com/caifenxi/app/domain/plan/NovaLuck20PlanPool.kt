package com.caifenxi.app.domain.plan

import com.caifenxi.app.domain.model.LotteryType
import com.caifenxi.app.domain.model.PlanDefinition

/** 幸运20/快乐8类：总和两面、组合、号码计划。 */
object NovaLuck20PlanPool {
    val ALL: List<PlanDefinition> get() = PlanPoolV2.all(LotteryType.LUCK20)
    val CANDIDATES: List<PlanDefinition> get() = PlanPoolV2.candidates(LotteryType.LUCK20)
    fun find(planId: String): PlanDefinition? = PlanPoolV2.find(planId)
}
