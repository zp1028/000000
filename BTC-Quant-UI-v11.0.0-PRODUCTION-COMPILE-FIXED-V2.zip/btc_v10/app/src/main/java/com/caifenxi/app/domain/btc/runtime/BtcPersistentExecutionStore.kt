package com.caifenxi.app.domain.btc.runtime

import android.content.Context

/** Persistent idempotency ledger so a process restart cannot immediately duplicate a bar execution. */
class BtcPersistentExecutionStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("btc_execution_ledger", Context.MODE_PRIVATE)

    fun claim(decisionId: String, now: Long = System.currentTimeMillis(), ttlMs: Long = 48L * 60L * 60L * 1000L): Boolean {
        synchronized(this) {
            val previous = prefs.getLong(decisionId, 0L)
            if (previous > 0L && now - previous < ttlMs) return false
            prefs.edit().putLong(decisionId, now).apply()
            return true
        }
    }

    fun clear(decisionId: String) { prefs.edit().remove(decisionId).apply() }
}
