package com.caifenxi.app.service

import android.content.Context
import android.graphics.Color as AndroidColor
import android.graphics.PixelFormat
import android.os.Build
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import com.caifenxi.app.CaiFenXiApplication

/**
 * 悬浮窗只读显示器。
 * 重点：
 * 1. 只接受已落盘的统一快照，不自行计算预测。
 * 2. 更新时复用 TextView，不 removeAllViews，避免刷新闪烁/卡顿。
 * 3. CALCULATING 时继续显示上一份 READY 结果，并标记“同步中”，不把旧结果套到新期号。
 * 4. 服务重启/Activity 退出不依赖 Activity 生命周期。
 */
class FloatingOverlayController(private val context: Context) {
    private val appContext = context.applicationContext
    private val wm = appContext.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var root: LinearLayout? = null
    private var params: WindowManager.LayoutParams? = null
    private var textViews: MutableList<TextView> = mutableListOf()

    @Synchronized
    fun refresh(prefs: com.caifenxi.app.domain.model.UserPrefs) {
        if (!prefs.floatingEnabled || !Settings.canDrawOverlays(appContext)) {
            hide()
            return
        }
        val current = FloatingOverlayStore.load(appContext)
        if (current == null) return
        val display = if (current.status == "CALCULATING") {
            FloatingOverlayStore.loadLastReady(appContext) ?: current
        } else current
        ensureView(prefs)
        render(prefs, display, current)
    }

    @Synchronized
    fun hide() {
        val v = root ?: return
        try { if (v.isAttachedToWindow) wm.removeViewImmediate(v) } catch (_: Exception) {}
        root = null
        params = null
        textViews.clear()
    }

    /** 服务销毁时不主动 remove，避免系统/厂商短暂回收服务导致悬浮窗跟着消失。 */
    fun keepOnServiceDestroy() {
        // WindowManager 会随应用进程生命周期统一清理；服务重启后复用同一快照重新绑定。
    }

    private fun ensureView(prefs: com.caifenxi.app.domain.model.UserPrefs) {
        val existing = root
        if (existing != null && existing.isAttachedToWindow) return
        root = null
        params = null
        textViews.clear()

        val lp = WindowManager.LayoutParams(
            dp(245), WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = prefs.floatingX
            y = prefs.floatingY
        }
        val box = LinearLayout(appContext).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(9), dp(12), dp(9))
            setBackgroundColor(AndroidColor.argb(225, 25, 25, 25))
            elevation = dp(8).toFloat()
        }
        box.setOnTouchListener(DragTouchListener(lp))
        try {
            wm.addView(box, lp)
            root = box
            params = lp
        } catch (_: Exception) {
            root = null
            params = null
        }
    }

    private fun render(
        prefs: com.caifenxi.app.domain.model.UserPrefs,
        snap: FloatingSnapshot,
        current: FloatingSnapshot
    ) {
        val box = root ?: return
        if (!box.isAttachedToWindow) return
        box.alpha = prefs.floatingOpacity

        val selectedDxId = prefs.floatingDxPlanId.ifBlank { prefs.floatingPlanId }
        val selectedDsId = prefs.floatingDsPlanId.ifBlank { prefs.floatingPlanId }
        val dxPlan = snap.plans.firstOrNull { it.planId == selectedDxId && !it.dx.isNullOrBlank() }
        val dsPlan = snap.plans.firstOrNull { it.planId == selectedDsId && !it.ds.isNullOrBlank() }

        val consensusDx = snap.consensusDx?.takeIf { it == "大" || it == "小" }
        val consensusDs = snap.consensusDs?.takeIf { it == "单" || it == "双" }
        val algoDx = snap.algoDx?.takeIf { it == "大" || it == "小" }
        val algoDs = snap.algoDs?.takeIf { it == "单" || it == "双" }

        var dx: String? = null
        var ds: String? = null
        var sourceName = "共识"
        var detail: String? = null

        when (prefs.floatingSource) {
            "plan" -> {
                // 大小、单双分别取各自计划；缺一项时只对缺失项安全回退，不再把整个计划判定为不可用。
                dx = dxPlan?.dx?.split("/", "、", ",")?.firstOrNull { it == "大" || it == "小" }
                ds = dsPlan?.ds?.split("/", "、", ",")?.firstOrNull { it == "单" || it == "双" }
                if (dx == null) dx = consensusDx ?: algoDx
                if (ds == null) ds = consensusDs ?: algoDs
                sourceName = "指定计划"
                val dxName = dxPlan?.planName ?: "共识兜底"
                val dsName = dsPlan?.planName ?: "共识兜底"
                detail = "大小：$dxName / 单双：$dsName"
            }
            "algo" -> {
                dx = algoDx ?: consensusDx
                ds = algoDs ?: consensusDs
                sourceName = "当前算法"
            }
            else -> {
                dx = consensusDx ?: algoDx
                ds = consensusDs ?: algoDs
                sourceName = if (consensusDx != null && consensusDs != null) "共识" else "共识兜底"
            }
        }

        val target = snap.targetIssue
        val issueReady = target != "-" && snap.latestIssue != "-" &&
            (isNextIssue(snap.latestIssue, target) || snap.latestIssue.toLongOrNull() == null)
        val predictionReady = issueReady && !dx.isNullOrBlank() && !ds.isNullOrBlank() && current.status != "CALCULATING"

        val status = when {
            current.status == "CALCULATING" -> "同步中 · 预测计算"
            !issueReady -> "同步中 · 期号校验"
            predictionReady -> "待开 · 同步正常"
            else -> "同步中 · 等待预测"
        }

        val lines = listOf(
            LineData(snap.lotteryName, true, false),
            LineData("第${target}期：${if (predictionReady) dx else "预测更新中..."}", true, false),
            LineData("第${target}期：${if (predictionReady) ds else "预测更新中..."}", true, false),
            LineData("来源：$sourceName", false, false),
            detail?.let { LineData(it, false, true) },
            LineData("状态：$status", false, false)
        ).filterNotNull()

        // 固定复用 View，只更新文本/样式，避免 removeAllViews 导致悬浮窗闪烁或卡顿。
        while (textViews.size < lines.size) {
            val tv = TextView(appContext).apply { setTextColor(AndroidColor.WHITE) }
            box.addView(tv)
            textViews.add(tv)
        }
        while (textViews.size > lines.size) {
            box.removeViewAt(box.childCount - 1)
            textViews.removeAt(textViews.lastIndex)
        }
        lines.forEachIndexed { i, line ->
            textViews[i].apply {
                text = line.text
                textSize = if (line.small) (prefs.floatingTextSize - 1f).coerceAtLeast(10f) else prefs.floatingTextSize
                setTypeface(typeface, if (line.bold) android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL)
                setPadding(0, dp(if (line.small) 1 else 2), 0, dp(1))
            }
        }
    }

    private data class LineData(val text: String, val bold: Boolean, val small: Boolean)

    private fun isNextIssue(latest: String, target: String): Boolean {
        val a = latest.toLongOrNull()
        val b = target.toLongOrNull()
        return if (a != null && b != null) b == a + 1L else true
    }

    private fun dp(v: Int) = (v * appContext.resources.displayMetrics.density).toInt()

    private inner class DragTouchListener(private val lp: WindowManager.LayoutParams) : View.OnTouchListener {
        private var downX = 0f
        private var downY = 0f
        private var startX = 0
        private var startY = 0
        private var lastUpAt = 0L

        override fun onTouch(v: View, event: MotionEvent): Boolean {
            val prefs = CaiFenXiApplication.instance.configStore.loadPrefs()
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX; downY = event.rawY
                    startX = lp.x; startY = lp.y
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!prefs.floatingDraggable) return true
                    lp.x = startX + (event.rawX - downX).toInt()
                    lp.y = startY + (event.rawY - downY).toInt()
                    try { wm.updateViewLayout(v, lp) } catch (_: Exception) {}
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    val now = System.currentTimeMillis()
                    if (now - lastUpAt < 320L) {
                        try { wm.removeViewImmediate(v) } catch (_: Exception) {}
                        root = null
                        params = null
                        textViews.clear()
                        lastUpAt = 0L
                        return true
                    }
                    lastUpAt = now
                    if (prefs.floatingDraggable) {
                        CaiFenXiApplication.instance.configStore.savePrefs(
                            prefs.copy(floatingX = lp.x, floatingY = lp.y)
                        )
                    }
                    return true
                }
            }
            return false
        }
    }
}
