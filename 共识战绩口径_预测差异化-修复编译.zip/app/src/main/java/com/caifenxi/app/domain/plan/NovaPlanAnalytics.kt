package com.caifenxi.app.domain.plan

import com.caifenxi.app.domain.model.DrawRecord
import com.caifenxi.app.domain.model.PlanDefinition
import com.caifenxi.app.data.config.StreakCalc
import kotlin.math.abs
import kotlin.math.pow
import kotlin.math.sqrt

/** NovaPlan 分析层：严格使用 cutoff 之前的数据，避免回测信息泄漏。 */
object NovaPlanAnalytics {
    data class Result(
        val planId: String,
        val output: String,
        val score: Double,
        val sampleCount: Int,
        val baseline: Double,
        val edge: Double,
        val stability: Double
    )

    data class StageReport(
        val stage: Int,
        val periods: Int,
        val hits: Int,
        val misses: Int,
        val hitRate: Double,
        val randomBaseline: Double,
        val edge: Double,
        val maxHitStreak: Int,
        val maxMissStreak: Int,
        val stability: Double
    )

    data class BacktestReport(
        val planId: String,
        val periods: Int,
        val hits: Int,
        val misses: Int,
        val hitRate: Double,
        val randomBaseline: Double,
        val edge: Double,
        val maxHitStreak: Int,
        val maxMissStreak: Int,
        val stability: Double,
        val stages: Map<Int, StageReport> = emptyMap(),
        /** 与计划引擎/历史页面一致：连续两期/三期滚动窗口统计。 */
        val twoWindows: Int = 0,
        val twoHitWindows: Int = 0,
        val twoMissWindows: Int = 0,
        val twoHitRate: Double = 0.0,
        val twoMissRate: Double = 0.0,
        val threeWindows: Int = 0,
        val threeHitWindows: Int = 0,
        val threeMissWindows: Int = 0,
        val threeHitRate: Double = 0.0,
        val threeMissRate: Double = 0.0
    )

    fun predict(plan: PlanDefinition, history: List<DrawRecord>, outputCount: Int? = null): Result? {
        val data = history.takeLast(plan.window.coerceAtLeast(5))
        if (data.size < 5) return null
        val output = when (plan.playType) {
            "大小" -> directionOutput(plan, data, data.mapNotNull { it.dx }, "大", "小")
            "单双" -> directionOutput(plan, data, data.mapNotNull { it.ds }, "单", "双")
            "组合" -> comboOutput(plan, data, outputCount ?: 3)
            "数字" -> numberOutput(plan, data, null, outputCount ?: 3)
            "位置" -> numberOutput(plan, data, plan.positionIndex.coerceIn(0, 9), outputCount ?: 3)
            else -> data.lastOrNull()?.dx.orEmpty()
        }.ifBlank { return null }
        val baseline = plan.baselineValue
        val sampleFactor = (data.size.coerceAtMost(200) / 200.0)
        val confidence = algorithmConfidence(plan.algorithm, data, plan.playType)
        val score = (45.0 + sampleFactor * 15.0 + confidence * 20.0).coerceIn(40.0, 85.0)
        return Result(plan.planId, output, score, data.size, baseline, confidence - 0.5, confidence.coerceIn(0.2, 1.0))
    }

    private fun algorithmConfidence(algo: String, data: List<DrawRecord>, playType: String): Double {
        val seq = when (playType) {
            "大小" -> data.mapNotNull { it.dx }
            "单双" -> data.mapNotNull { it.ds }
            "组合" -> data.mapNotNull { it.combo }
            else -> emptyList()
        }
        if (seq.size < 4) return 0.45
        val last = seq.last()
        val share = seq.count { it == last }.toDouble() / seq.size
        return when (algo) {
            "STATE" -> share.coerceIn(0.35, 0.85)
            "RHYTHM" -> if (seq.takeLast(3).distinct().size == 1) 0.72 else 0.48
            "ANOMALY" -> if (share > 0.62 || share < 0.38) 0.70 else 0.42
            "SIMILAR" -> 0.55
            "NETWORK" -> 0.58
            "STRUCT" -> 0.52
            "CANDIDATE" -> 0.50
            "OPTIMIZE" -> 0.54
            else -> 0.50
        }
    }

    /**
     * walk-forward 回测：每个 target 只使用 target 之前的数据。
     * 执行周期 cyclePeriods=N：一次预测锁定后续 N 期，N 期内任意一期命中即计为中（常见多期计划口径）。
     * 步进也为 N，避免与一期回测完全同一组样本导致胜率不变。
     * 注意：仅服务新计划页，不写入计划引擎 careerStats。
     */
    fun backtest(plan: PlanDefinition, history: List<DrawRecord>, periods: Int): BacktestReport {
        val cycle = plan.cyclePeriods.coerceIn(1, 20)
        val n = periods.coerceAtLeast(1).coerceAtMost((history.size - 5).coerceAtLeast(1))
        val start = (history.size - n).coerceAtLeast(5)
        var hits = 0
        var misses = 0
        var hitStreak = 0
        var missStreak = 0
        var maxHit = 0
        var maxMiss = 0
        val rates = mutableListOf<Double>()
        var i = start
        while (i < history.size) {
            val prior = history.subList(0, i)
            val p = predict(plan, prior)
            if (p == null) {
                i += 1
                continue
            }
            val end = (i + cycle).coerceAtMost(history.size)
            // N 期内任一期命中 → 中；全部未中 → 错
            var hit = false
            for (j in i until end) {
                if (evaluate(plan, p.output, history[j])) {
                    hit = true
                    break
                }
            }
            if (hit) {
                hits++; hitStreak++; missStreak = 0; maxHit = maxOf(maxHit, hitStreak)
            } else {
                misses++; missStreak++; hitStreak = 0; maxMiss = maxOf(maxMiss, missStreak)
            }
            rates += if (hit) 1.0 else 0.0
            i += cycle
        }
        val total = hits + misses
        val rate = if (total == 0) 0.0 else hits.toDouble() / total
        // 多期计划随机基准随周期提升（近似 1-(1-p)^N）
        val singleBaseline = plan.baselineValue.coerceIn(0.01, 0.99)
        val baseline = if (cycle <= 1) singleBaseline else (1.0 - (1.0 - singleBaseline).pow(cycle))
        val mean = rate
        val variance = if (rates.size < 2) 0.0 else rates.map { (it - mean) * (it - mean) }.average()
        val stability = (1.0 - sqrt(variance) * 2.0).coerceIn(0.0, 1.0)
        val stages = (1..cycle.coerceAtMost(3)).associateWith { stage ->
            stageBacktest(plan, history, periods, stage)
        }
        // 注意：两期/三期不是“第二期/第三期预测”，而是与其他页面完全一致的滚动窗口口径：
        // 连续窗口内至少命中一次 = 对窗口；窗口内全部未命中 = 错窗口。
        val (w2, w2Hit, w2Miss) = StreakCalc.windowRates(rates.map { if (it > 0.5) "对" else "错" }, 2)
        val (w3, w3Hit, w3Miss) = StreakCalc.windowRates(rates.map { if (it > 0.5) "对" else "错" }, 3)
        return BacktestReport(
            plan.planId, total, hits, misses, rate, baseline, rate - baseline, maxHit, maxMiss, stability, stages,
            twoWindows = w2, twoHitWindows = w2Hit, twoMissWindows = w2Miss,
            twoHitRate = if (w2 > 0) w2Hit.toDouble() / w2 else 0.0,
            twoMissRate = if (w2 > 0) w2Miss.toDouble() / w2 else 0.0,
            threeWindows = w3, threeHitWindows = w3Hit, threeMissWindows = w3Miss,
            threeHitRate = if (w3 > 0) w3Hit.toDouble() / w3 else 0.0,
            threeMissRate = if (w3 > 0) w3Miss.toDouble() / w3 else 0.0
        )
    }

    /**
     * 单独统计首期/二期/三期。每一期都以同一条“预测锁定”作为起点，
     * 只结算该期对应的开奖结果，不把其它期的结果混入。
     */
    fun stageBacktest(plan: PlanDefinition, history: List<DrawRecord>, periods: Int, stage: Int): StageReport {
        val s = stage.coerceIn(1, 3)
        val n = periods.coerceAtLeast(1).coerceAtMost((history.size - 5 - (s - 1)).coerceAtLeast(1))
        val start = (history.size - n - (s - 1)).coerceAtLeast(5)
        var hits = 0
        var misses = 0
        var hitStreak = 0
        var missStreak = 0
        var maxHit = 0
        var maxMiss = 0
        val rates = mutableListOf<Double>()
        for (i in start until history.size) {
            val target = i + s - 1
            if (target >= history.size) break
            val p = predict(plan, history.subList(0, i)) ?: continue
            val hit = evaluate(plan, p.output, history[target])
            if (hit) {
                hits++; hitStreak++; missStreak = 0; maxHit = maxOf(maxHit, hitStreak)
            } else {
                misses++; missStreak++; hitStreak = 0; maxMiss = maxOf(maxMiss, missStreak)
            }
            rates += if (hit) 1.0 else 0.0
        }
        val total = hits + misses
        val rate = if (total == 0) 0.0 else hits.toDouble() / total
        val baseline = plan.baselineValue.coerceIn(0.01, 0.99)
        val mean = rate
        val variance = if (rates.size < 2) 0.0 else rates.map { (it - mean) * (it - mean) }.average()
        val stability = (1.0 - sqrt(variance) * 2.0).coerceIn(0.0, 1.0)
        return StageReport(s, total, hits, misses, rate, baseline, rate - baseline, maxHit, maxMiss, stability)
    }

    private fun evaluate(plan: PlanDefinition, output: String, actual: DrawRecord): Boolean {
        val parts = output.split("/", "、", ",").map { it.trim() }.filter { it.isNotEmpty() }
        return when (plan.playType) {
            "大小" -> parts.any { it == actual.dx }
            "单双" -> parts.any { it == actual.ds }
            "组合" -> parts.any { it == actual.combo }
            "数字" -> parts.any { it.toIntOrNull()?.let { n -> n in actual.numbers } == true }
            "位置" -> {
                if (actual.numbers.isEmpty()) return false
                val index = plan.positionIndex.coerceIn(0, actual.numbers.lastIndex)
                val n = actual.numberAt(index)
                parts.any { it.toIntOrNull() == n }
            }
            else -> false
        }
    }

    private fun directionOutput(
        plan: PlanDefinition,
        data: List<DrawRecord>,
        seq: List<String>,
        a: String,
        b: String
    ): String {
        if (seq.isEmpty()) return ""
        // 每计划独立回看长度与 tie-break，避免同算法+同玩法输出完全一致
        val lookback = planLookback(plan)
        val salt = planSalt(plan)
        return when (plan.algorithm) {
            "RHYTHM" -> rhythm(seq, a, b, lookback, salt)
            "SIMILAR" -> similarDirection(seq, lookback, salt)
            "ANOMALY" -> anomaly(seq, a, b, lookback, salt)
            "NETWORK" -> network(seq, a, b, lookback, salt)
            "STRUCT" -> struct(seq, a, b, lookback, salt)
            "CANDIDATE" -> candidate(seq, a, b, lookback, salt)
            "OPTIMIZE" -> optimize(seq, a, b, lookback, salt)
            "STATE" -> state(seq, lookback, salt)
            else -> state(seq, lookback, salt)
        }
    }

    private fun planLookback(plan: PlanDefinition): Int {
        val base = plan.window.coerceIn(5, 80)
        // 算法与 planId 微调，拉开同窗口计划差异
        val adj = (kotlin.math.abs(plan.planId.hashCode()) % 7) - 3
        return (base / 2 + adj).coerceIn(4, base)
    }

    private fun planSalt(plan: PlanDefinition): Int =
        kotlin.math.abs(plan.planId.hashCode() * 31 + plan.window * 17 + plan.algorithm.hashCode())

    private fun comboOutput(plan: PlanDefinition, data: List<DrawRecord>, topN: Int): String {
        val lookback = planLookback(plan)
        val salt = planSalt(plan)
        val seq = data.mapNotNull { it.combo }.takeLast(lookback.coerceAtLeast(8))
        if (seq.isEmpty()) return ""
        val counts = seq.groupingBy { it }.eachCount()
        val n = topN.coerceIn(1, 4)
        val ranked = when (plan.algorithm) {
            "RHYTHM" -> {
                if (seq.size >= 3 && seq.takeLast(3).distinct().size == 1) {
                    counts.entries.sortedWith(compareBy<Map.Entry<String, Int>> { it.value }.thenBy { saltTie(it.key, salt) }).map { it.key }
                } else {
                    counts.entries.sortedWith(compareByDescending<Map.Entry<String, Int>> { it.value }.thenBy { saltTie(it.key, salt) }).map { it.key }
                }
            }
            "ANOMALY" -> {
                val avg = counts.values.average()
                counts.entries.sortedWith(
                    compareByDescending<Map.Entry<String, Int>> { kotlin.math.abs(it.value - avg) }
                        .thenBy { saltTie(it.key, salt) }
                ).map { it.key }
            }
            "NETWORK", "STRUCT" -> {
                val last = seq.last()
                val nextCounts = mutableMapOf<String, Int>()
                for (i in 1 until seq.size) {
                    if (seq[i - 1] == last) nextCounts[seq[i]] = (nextCounts[seq[i]] ?: 0) + 1
                }
                if (nextCounts.isNotEmpty()) {
                    nextCounts.entries.sortedByDescending { it.value }.map { it.key } +
                        counts.keys.filter { it !in nextCounts }.sortedBy { saltTie(it, salt) }
                } else {
                    counts.entries.sortedByDescending { it.value }.map { it.key }
                }
            }
            "CANDIDATE", "OPTIMIZE" -> {
                val hot = counts.entries.sortedWith(
                    compareByDescending<Map.Entry<String, Int>> { it.value }.thenBy { saltTie(it.key, salt) }
                ).map { it.key }
                // 按 salt 旋转起点，同热度下不同计划取不同组合顺序
                if (hot.isEmpty()) hot else {
                    val rot = salt % hot.size
                    hot.drop(rot) + hot.take(rot)
                }
            }
            else -> counts.entries.sortedWith(
                compareByDescending<Map.Entry<String, Int>> { it.value }.thenBy { saltTie(it.key, salt) }
            ).map { it.key }
        }
        return ranked.distinct().take(n).joinToString("/")
    }

    private fun saltTie(key: String, salt: Int): Int =
        kotlin.math.abs(key.hashCode() xor salt)

    private fun numberOutput(plan: PlanDefinition, data: List<DrawRecord>, position: Int?, topN: Int): String {
        val salt = planSalt(plan)
        val counts = mutableMapOf<Int, Double>()
        data.forEachIndexed { index, row ->
            val nums = if (position == null) row.numbers else listOfNotNull(row.numberAt(position))
            val progress = index.toDouble() / data.size.coerceAtLeast(1)
            val decay = when (plan.algorithm) {
                "RHYTHM" -> 0.6 + progress * 1.0
                "ANOMALY" -> 1.2 - progress * 0.5
                "SIMILAR", "NETWORK" -> 0.7 + progress * 0.9
                "STRUCT" -> if (index >= data.size - 5) 1.4 else 0.8
                "CANDIDATE" -> 1.0 + (salt % 5) * 0.02
                "OPTIMIZE" -> 0.9 + progress * 0.4
                else -> 1.0
            }
            nums.forEach { n -> counts[n] = (counts[n] ?: 0.0) + decay }
        }
        if (counts.isEmpty()) return ""
        val ranked = when (plan.algorithm) {
            "ANOMALY" -> {
                val avg = counts.values.average()
                counts.entries.sortedWith(
                    compareByDescending<Map.Entry<Int, Double>> { kotlin.math.abs(it.value - avg) }
                        .thenBy { saltTie(it.key.toString(), salt) }
                )
            }
            "OPTIMIZE", "CANDIDATE" -> {
                val hot = counts.entries.sortedByDescending { it.value }
                val cold = counts.entries.sortedBy { it.value }
                val mixed = mutableListOf<Map.Entry<Int, Double>>()
                for (i in 0 until maxOf(hot.size, cold.size)) {
                    if (i < hot.size) mixed += hot[i]
                    if (i < cold.size && cold[i].key != hot.getOrNull(i)?.key) mixed += cold[i]
                }
                val list = mixed.distinctBy { it.key }
                val rot = if (list.isEmpty()) 0 else salt % list.size
                list.drop(rot) + list.take(rot)
            }
            else -> counts.entries.sortedWith(
                compareByDescending<Map.Entry<Int, Double>> { it.value }.thenBy { saltTie(it.key.toString(), salt) }
            )
        }
        return ranked.take(topN.coerceIn(1, 10)).joinToString("/") { it.key.toString() }
    }

    private fun state(seq: List<String>, lookback: Int = 8, salt: Int = 0): String {
        val slice = seq.takeLast(lookback.coerceIn(3, seq.size.coerceAtLeast(3)))
        val counts = slice.groupingBy { it }.eachCount()
        // 平票时用 salt 打破，避免全池同一结果
        return counts.maxWithOrNull(
            compareBy<Map.Entry<String, Int>> { it.value }.thenBy { -saltTie(it.key, salt) }
        )?.key.orEmpty()
    }

    private fun rhythm(seq: List<String>, a: String, b: String, lookback: Int, salt: Int): String {
        if (seq.size < 4) return state(seq, lookback, salt)
        val streak = 2 + (salt % 3) // 2～4 连出触发反转，计划间不同
        return if (seq.takeLast(streak).distinct().size == 1) {
            if (seq.last() == a) b else a
        } else state(seq, lookback, salt)
    }

    private fun anomaly(seq: List<String>, a: String, b: String, lookback: Int, salt: Int): String {
        val slice = seq.takeLast(lookback.coerceAtLeast(6))
        val pA = slice.count { it == a }.toDouble() / slice.size.coerceAtLeast(1)
        val hi = 0.58 + (salt % 5) * 0.02
        val lo = 0.42 - (salt % 5) * 0.02
        return when {
            pA > hi -> b
            pA < lo -> a
            else -> state(seq, lookback, salt)
        }
    }

    private fun similarDirection(seq: List<String>, lookback: Int, salt: Int): String {
        val pattern = 4 + (salt % 3) // 4～6 期形态
        if (seq.size < pattern * 2) return state(seq, lookback, salt)
        val tail = seq.takeLast(pattern)
        val candidates = seq.dropLast(pattern).windowed(pattern)
        if (candidates.isEmpty()) return state(seq, lookback, salt)
        // 取最相似的第 (salt%3)+1 个匹配，避免全选同一个历史段
        val ranked = candidates.mapIndexed { idx, w ->
            idx to w.zip(tail).count { it.first != it.second }
        }.sortedWith(compareBy<Pair<Int, Int>> { it.second }.thenBy { (it.first + salt) % 97 })
        val pick = ranked.getOrNull(salt % ranked.size.coerceAtMost(3)) ?: ranked.first()
        return seq.getOrNull(pick.first + pattern) ?: state(seq, lookback, salt)
    }

    private fun network(seq: List<String>, a: String, b: String, lookback: Int, salt: Int): String {
        val slice = seq.takeLast(lookback.coerceAtLeast(6))
        if (slice.size < 6) return state(seq, lookback, salt)
        val last = slice.last()
        val next = mutableMapOf<String, Int>()
        for (i in 1 until slice.size) {
            if (slice[i - 1] == last) next[slice[i]] = (next[slice[i]] ?: 0) + 1
        }
        return next.maxWithOrNull(
            compareBy<Map.Entry<String, Int>> { it.value }.thenBy { -saltTie(it.key, salt) }
        )?.key ?: state(seq, lookback, salt)
    }

    private fun struct(seq: List<String>, a: String, b: String, lookback: Int, salt: Int): String {
        if (seq.size < 6) return state(seq, lookback, salt)
        val n = (5 + salt % 4).coerceAtMost(seq.size) // 5～8
        val tail = seq.takeLast(n)
        var switches = 0
        for (i in 1 until tail.size) if (tail[i] != tail[i - 1]) switches++
        val threshold = 2 + (salt % 3)
        return if (switches >= threshold) {
            if (seq.last() == a) b else a
        } else state(seq, lookback, salt)
    }

    private fun candidate(seq: List<String>, a: String, b: String, lookback: Int, salt: Int): String {
        if (seq.size < 5) return state(seq, lookback, salt)
        val counts = seq.takeLast(lookback.coerceIn(8, 30)).groupingBy { it }.eachCount()
        val ordered = counts.entries.sortedWith(
            compareByDescending<Map.Entry<String, Int>> { it.value }.thenBy { saltTie(it.key, salt) }
        )
        val top = ordered.firstOrNull()?.key ?: return state(seq, lookback, salt)
        val second = ordered.getOrNull(1)?.key
        // salt 偶数偏热，奇数在接近时选次热
        return if (second != null && (counts[second] ?: 0) * 2 >= (counts[top] ?: 0) && salt % 2 == 1) second else top
    }

    private fun optimize(seq: List<String>, a: String, b: String, lookback: Int, salt: Int): String {
        if (seq.size < 6) return state(seq, lookback, salt)
        val shortN = 3 + (salt % 4)
        val short = seq.takeLast(shortN).groupingBy { it }.eachCount()
            .maxWithOrNull(compareBy<Map.Entry<String, Int>> { it.value }.thenBy { -saltTie(it.key, salt) })?.key
        val transfer = network(seq, a, b, lookback, salt)
        return when {
            short != null && short == transfer -> short
            salt % 3 == 0 -> transfer.ifBlank { short.orEmpty() }.ifBlank { state(seq, lookback, salt) }
            else -> short.orEmpty().ifBlank { transfer }.ifBlank { state(seq, lookback, salt) }
        }
    }
}
