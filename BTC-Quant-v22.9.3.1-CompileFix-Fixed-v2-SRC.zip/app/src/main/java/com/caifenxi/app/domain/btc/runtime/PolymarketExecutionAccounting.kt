package com.caifenxi.app.domain.btc.runtime

/**
 * Derived execution accounting from reconciled fills. Values are quote-currency
 * amounts unless explicitly described as shares.
 */
data class PolymarketExecutionAccounting(
    val orderId: String,
    val sharesFilled: Double,
    val averageFillPrice: Double,
    val grossCost: Double,
    val fees: Double,
    val netCost: Double,
    val markPrice: Double = 0.0
) {
    val marketValue: Double get() = sharesFilled * markPrice.coerceAtLeast(0.0)
    val unrealizedPnl: Double get() = marketValue - netCost
}

object PolymarketExecutionAccountingEngine {
    fun fromLifecycle(lifecycle: PolymarketOrderLifecycle, markPrice: Double = 0.0): PolymarketExecutionAccounting =
        PolymarketExecutionAccounting(
            orderId = lifecycle.orderId,
            sharesFilled = lifecycle.filledSize.coerceAtLeast(0.0),
            averageFillPrice = lifecycle.avgFillPrice.coerceAtLeast(0.0),
            grossCost = lifecycle.grossFillCost.coerceAtLeast(0.0),
            fees = lifecycle.fees.coerceAtLeast(0.0),
            netCost = lifecycle.netFillCost.coerceAtLeast(lifecycle.grossFillCost).coerceAtLeast(0.0),
            markPrice = markPrice
        )
}
