package com.caifenxi.app.ui.screens

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Circle
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import kotlinx.coroutines.delay
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import com.caifenxi.app.domain.btc.BtcDirection
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.caifenxi.app.domain.btc.hs.BayesParticle
import com.caifenxi.app.domain.btc.BinanceOrderBookRepository
import com.caifenxi.app.domain.btc.hs.HsPredictionSnapshot
import com.caifenxi.app.domain.btc.hs.TimeframePhat
import com.caifenxi.app.ui.BtcQuantViewModel
import com.caifenxi.app.ui.components.CandlestickChart
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

/**
 * HS PREDICTION ENGINE 看板 —— 算法 + UI 全量对齐截图/视频
 */
@Composable
fun DashboardTab(viewModel: BtcQuantViewModel) {
    val state by viewModel.state.collectAsState()
    val exec by viewModel.executionStatus.collectAsState()
    val hs = state.hsSnapshot
    // 与 ViewModel 的 timeframe 保持同步，避免本地 state 与引擎脱节导致“切周期无反应”
    var timeframe by remember { mutableStateOf(state.timeframe.ifBlank { "15m" }) }
    LaunchedEffect(state.timeframe) {
        if (state.timeframe.isNotBlank() && state.timeframe != timeframe) {
            timeframe = state.timeframe
        }
    }

    val bg = Color(0xFF0A0A0F)
    val cardBg = Color(0xFF12121A)
    val border = Color(0xFF1E1E2A)
    val green = Color(0xFF00E676)
    val red = Color(0xFFFF5252)
    val cyan = Color(0xFF00E5FF)
    val muted = Color(0xFF6B7280)
    val textPrimary = Color(0xFFE5E7EB)

    val balance = hs?.balance ?: 0.0
    val available = hs?.available ?: 0.0
    val openNotional = hs?.openNotional ?: 0.0
    val todayPnl = hs?.todayPnl ?: 0.0
    val pnl30d = hs?.pnl30d ?: 0.0
    val maxDd = hs?.maxDrawdownPct ?: 0.0
    val p5 = hs?.tf5m?.pHat ?: 0.5
    val p15 = hs?.tf15m?.pHat ?: 0.5
    val p1h = hs?.tf1h?.pHat ?: 0.5
    val edge = (hs?.aggregateEdge ?: 0.0) * 100
    val trigger = hs?.bayesTrigger ?: 0.0
    val logs = hs?.engineLog ?: emptyList()

    Column(
        Modifier.fillMaxSize().background(bg).verticalScroll(rememberScrollState())
    ) {
        HsTopBar(
            updatedAt = hs?.updatedAt ?: state.updatedAt,
            edge = edge,
            dataMode = hs?.dataMode ?: "离线",
            onRefresh = { viewModel.refresh(timeframe = timeframe) },
            textPrimary = textPrimary, muted = muted, green = green
        )

        // 数据状态条（避免空白时无反馈）
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                when {
                    state.loading -> "正在加载行情…"
                    state.isDemoMode -> "演示数据（离线可看完整看板）"
                    hs == null -> "暂无数据，请点刷新或加载演示"
                    else -> "真实/缓存行情 · ${state.symbol} ${state.timeframe}"
                },
                color = if (state.isDemoMode || hs == null) Color(0xFFFFD54F) else green,
                fontSize = 11.sp,
                modifier = Modifier.weight(1f)
            )
            OutlinedButton(onClick = { viewModel.refresh(timeframe = timeframe) }, contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)) {
                Text("刷新", fontSize = 11.sp)
            }
            OutlinedButton(onClick = { viewModel.loadDemo(timeframe = timeframe) }, contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)) {
                Text("演示", fontSize = 11.sp)
            }
        }
        state.error?.takeIf { it.isNotBlank() }?.let { err ->
            Text(err, color = red, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 10.dp, vertical = 2.dp))
        }

        CurrentTradeConclusion(hs, cardBg, border, textPrimary, muted, green, red, cyan)

        QuantFactorMatrixCard(state.quantFactors)

        // 执行门控状态条
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 2.dp)
                .background(cardBg, RoundedCornerShape(8.dp))
                .padding(horizontal = 10.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            val liveOk = hs?.dataQuality?.liveTradeAllowed == true
            val kill = exec.killSwitch
            Text(
                when {
                    kill -> "熔断已开启"
                    !liveOk -> "风控拦截"
                    else -> "风控放行"
                },
                color = when {
                    kill -> red
                    !liveOk -> red
                    else -> green
                },
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
            Text(
                exec.lastVerdictReason?.take(42) ?: (hs?.dataQuality?.blockReasons?.firstOrNull() ?: "就绪"),
                color = muted,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                maxLines = 1
            )
        }

        Row(
            Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("周期", color = muted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
            listOf("5m", "15m", "1h").forEach { tf ->
                FilterChip(
                    selected = timeframe == tf,
                    onClick = {
                        timeframe = tf
                        viewModel.refresh(timeframe = tf)
                    },
                    label = { Text(tf, fontSize = 10.sp, fontFamily = FontFamily.Monospace) },
                    modifier = Modifier.height(30.dp)
                )
            }
        }

        LiveMarketSection(
            candles = state.candles,
            symbol = state.symbol,
            timeframe = state.timeframe,
            price = state.livePrice?.takeIf { it > 0.0 } ?: hs?.markPrice?.takeIf { it > 0.0 } ?: (state.markPrice ?: 0.0),
            fundingRate = state.fundingRate,
            oiChangePct = state.oiChangePct,
            isDemo = state.isDemoMode,
            cardBg = cardBg, border = border, green = green, red = red, muted = muted, textPrimary = textPrimary
        )

        LiveMarketStatusStrip(
            status = state.liveStreamStatus,
            detail = state.liveStreamDetail,
            livePrice = state.livePrice,
            livePriceAt = state.livePriceAt,
            liveDepth = state.liveDepth,
            muted = muted,
            green = green,
            red = red,
            cardBg = cardBg,
            border = border,
            textPrimary = textPrimary
        )

        LiveDepthLadder(
            depth = state.liveDepth,
            cardBg = cardBg,
            border = border,
            textPrimary = textPrimary,
            muted = muted,
            green = green,
            red = red
        )

        RealtimeMarketPulse(
            points = state.realtimeMarketTimeline,
            cardBg = cardBg,
            border = border,
            textPrimary = textPrimary,
            muted = muted,
            green = green,
            red = red,
            cyan = cyan
        )

        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(10.dp, 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            MetricCard("总权益", "$${fmtMoney(balance)}", "现金 + 当前持仓价值", textPrimary, muted, cardBg, border)
            MetricCard("可用", "$${fmtMoney(available)}", "可用现金余额", textPrimary, muted, cardBg, border)
            MetricCard("持仓名义", "$${fmtMoney(openNotional)}", "当前持仓名义价值", textPrimary, muted, cardBg, border)
            MetricCard("今日盈亏", "${if (todayPnl >= 0) "+" else ""}$${fmtMoney(todayPnl)}", "持仓浮动盈亏", green, muted, cardBg, border, if (todayPnl >= 0) green else red)
            MetricCard("30日盈亏", "${if (pnl30d >= 0) "+" else ""}$${fmtMoney(pnl30d)}", "已平仓累计", green, muted, cardBg, border, if (pnl30d >= 0) green else red)
            MetricCard("最大回撤", if (hs == null) "—" else "${"%.1f".format(maxDd)}%", if (hs?.dataMode == "PAPER") "模拟账户" else "账户快照", if (hs == null) muted else red, muted, cardBg, border, if (hs == null) muted else red)
        }

        PolymarketTerminalPanel(
            panel = hs?.polymarketPanels?.get("5m"),
            currentPrice = state.livePrice?.takeIf { it > 0.0 } ?: hs?.markPrice ?: 0.0,
            priceHistory = state.polymarketYesHistory,
            cardBg = cardBg, border = border, textPrimary = textPrimary,
            muted = muted, green = green, red = red, cyan = cyan
        )

        Column(Modifier.padding(horizontal = 10.dp, vertical = 4.dp)) {
            SectionLabel("BTC深度 / 预测市场盘口", muted)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                DepthFromPhat(hs?.tf5m, "5m", p5, cardBg, border, green, red, textPrimary, muted)
                DepthFromPhat(hs?.tf15m, "15m", p15, cardBg, border, green, red, textPrimary, muted)
                DepthFromPhat(hs?.tf1h, "1h", p1h, cardBg, border, green, red, textPrimary, muted)
            }
        }

        Row(
            Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 4.dp).height(140.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Column(Modifier.weight(1.4f)) {
                SectionLabel("优势 + 点差", muted)
                EdgeSpreadChart(
                    Modifier.fillMaxWidth().height(110.dp).background(cardBg, RoundedCornerShape(8.dp))
                        .border(1.dp, border, RoundedCornerShape(8.dp)).padding(8.dp),
                    green, cyan, muted, hs?.edgeHistory.orEmpty()
                )
            }
            Column(Modifier.weight(0.9f)) {
                SectionLabel("上涨概率 / 卖价 / 点差分析", muted)
                KellyPhatTable(hs?.tf5m, hs?.tf15m, p5, p15, cardBg, border, textPrimary, muted, green)
            }
        }

        SectionLabel("贝叶斯粒子场", muted, Modifier.padding(start = 10.dp, top = 6.dp))
        BayesParticleField(
            Modifier.fillMaxWidth().height(200.dp).padding(horizontal = 10.dp)
                .background(Color(0xFF08080C), RoundedCornerShape(8.dp))
                .border(1.dp, border, RoundedCornerShape(8.dp)),
            trigger = trigger,
            particles = hs?.particles.orEmpty(),
            bayesMean = hs?.bayesMean ?: 0.5,
            cyan = cyan, green = green, muted = muted
        )

        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatusChip("active 5m", green)
            StatusChip("p_hat ${"%.3f".format(p5)}", cyan)
            StatusChip("depth ${if (hs == null) "—" else "%,.2f".format(hs.tf5m.depthBid)}", muted)
            StatusChip("news ${"%.2f".format(hs?.newsScore ?: 0.0)}", muted)
            StatusChip("depth ${"%+.3f".format(hs?.binanceDepthImbalance ?: 0.0)}", muted)
            StatusChip("POLY ${if (hs?.polymarketBookLive == true) "LIVE" else "OFF"}", if (hs?.polymarketBookLive == true) green else muted)
            StatusChip("ORACLE ${if (hs?.oracleLive == true) "LIVE" else "OFF"}", if (hs?.oracleLive == true) green else muted)
            StatusChip("${hs?.tf15m?.action ?: "NO_DATA"}", if (hs?.tf15m?.action?.startsWith("BUY") == true) green else Color(0xFFFFAB00))
        }

        HsOpportunityPanel(
            hs = hs,
            cardBg = cardBg,
            border = border,
            textPrimary = textPrimary,
            muted = muted,
            green = green,
            red = red
        )

        Row(
            Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 4.dp).height(160.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Column(
                Modifier.weight(1f).fillMaxHeight().background(cardBg, RoundedCornerShape(8.dp))
                    .border(1.dp, border, RoundedCornerShape(8.dp)).padding(8.dp)
            ) {
                SectionLabel("引擎日志", muted)
                logs.takeLast(6).forEach { line ->
                    Text(
                        line,
                        color = if (line.contains("PHAT") || line.contains("BAYES") || line.contains("SYNC")) green else textPrimary,
                        fontSize = 9.sp, fontFamily = FontFamily.Monospace,
                        maxLines = 1, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(vertical = 1.dp)
                    )
                }
            }
            Column(
                Modifier.weight(1.2f).fillMaxHeight().background(cardBg, RoundedCornerShape(8.dp))
                    .border(1.dp, border, RoundedCornerShape(8.dp)).padding(8.dp)
            ) {
                SectionLabel(
                    "PHAT PROBABILITY   5m ${"%.1f".format(p5 * 100)}% · 15m ${"%.1f".format(p15 * 100)}% · 1h ${"%.1f".format(p1h * 100)}%",
                    muted
                )
                PhatProbabilityChart(Modifier.fillMaxSize(), hs?.phatHistory ?: emptyMap(), green, cyan, Color(0xFFEF5350))
            }
            Column(
                Modifier.weight(0.85f).fillMaxHeight().background(cardBg, RoundedCornerShape(8.dp))
                    .border(1.dp, border, RoundedCornerShape(8.dp)).padding(8.dp)
            ) {
                SectionLabel("机器人状态", muted)
                BotStatusPanel(balance, available, p5, p15, p1h, hs, textPrimary, muted, green, red)
            }
        }

        Text(
            "反正整个高频系统做下来 · HS Prediction Engine · ML p_hat · Bayes Particle · ½Kelly · GLM/GPT/FABLE5",
            color = muted, fontSize = 10.sp,
            modifier = Modifier.fillMaxWidth().padding(12.dp), textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun CurrentTradeConclusion(
    hs: HsPredictionSnapshot?, cardBg: Color, border: Color,
    textPrimary: Color, muted: Color, green: Color, red: Color, cyan: Color
) {
    val tf = hs?.phatFor("15m")
    val edge = tf?.netEdge ?: hs?.aggregateEdge ?: 0.0
    val opp = tf?.opportunityScore ?: hs?.opportunityScore ?: 0.0
    val quality = tf?.dataQualityScore ?: hs?.dataQualityScore ?: 0.0
    val allowed = hs?.dataQuality?.liveTradeAllowed == true
    val action = when {
        hs == null -> "WAIT / NO DATA"
        !allowed -> "BLOCK / RISK GATE"
        opp < 0.60 || edge <= 0.0 -> "WAIT / EDGE TOO LOW"
        hs.primaryDirection == BtcDirection.UP -> "LONG / READY"
        hs.primaryDirection == BtcDirection.DOWN -> "SHORT / READY"
        else -> "WAIT / FLAT"
    }
    val actionColor = when {
        action.startsWith("BLOCK") -> red
        action.contains("READY") -> if (hs?.primaryDirection == BtcDirection.DOWN) red else green
        else -> cyan
    }
    Column(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 5.dp)
        .background(cardBg, RoundedCornerShape(10.dp))
        .border(1.dp, border, RoundedCornerShape(10.dp)).padding(10.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("CURRENT TRADE CONCLUSION", color = muted, fontSize = 8.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                Text(action, color = actionColor, fontSize = 17.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Black)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text("${hs?.primaryDirection?.name ?: "FLAT"} · p ${"%.1f".format((hs?.primaryPhat ?: .5) * 100)}%", color = textPrimary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                Text("edge %+.2f%% · opp %.0f%%".format(edge * 100, opp * 100), color = if (edge > 0) green else muted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
            }
        }
        Spacer(Modifier.height(7.dp))
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            StatusChip("15m p_hat %.3f".format(tf?.pHat ?: .5), cyan)
            StatusChip("cost %.2f%%".format((tf?.costEstimate ?: 0.0) * 100), muted)
            StatusChip("quality %.0f%%".format(quality * 100), if (quality >= .8) green else red)
            StatusChip("${hs?.dataFreshnessMs?.let { "${it / 1000}s" } ?: "—"} age", muted)
        }
    }
}

@Composable
private fun DepthFromPhat(
    tf: TimeframePhat?,
    label: String,
    fallbackP: Double,
    cardBg: Color, border: Color, green: Color, red: Color, textPrimary: Color, muted: Color
) {
    val p = tf?.pHat ?: fallbackP
    val bid = tf?.bestBid
    val ask = tf?.bestAsk
    val alpha = tf?.alpha ?: 0.0
    val spread = tf?.spread ?: 0.0
    Column(
        Modifier.width(110.dp).background(cardBg, RoundedCornerShape(6.dp))
            .border(1.dp, border, RoundedCornerShape(6.dp)).padding(8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(label, color = textPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Spacer(Modifier.weight(1f))
            Text("关注", color = muted, fontSize = 8.sp)
        }
        Text("比特币涨或跌", color = muted, fontSize = 8.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Spacer(Modifier.height(4.dp))
        LinearProgressIndicator(
            progress = { p.toFloat() },
            modifier = Modifier.fillMaxWidth().height(4.dp),
            color = if (p > 0.5) green else red,
            trackColor = Color(0xFF1E1E2A)
        )
        Spacer(Modifier.height(4.dp))
        Text("p_hat ${"%.3f".format(p)}", color = textPrimary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
        Text("bid ${bid?.let { "%.3f".format(it) } ?: "—"}  ask ${ask?.let { "%.3f".format(it) } ?: "—"}", color = textPrimary, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
        Text("spread ${"%.3f".format(spread)}  netEdge ${"%+.3f".format(tf?.netEdge ?: 0.0)}", color = muted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
        Text("depth ${"%.0f".format(tf?.depthBid ?: 0.0)}/${"%.0f".format(tf?.depthAsk ?: 0.0)}", color = muted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
    }
}

@Composable
private fun KellyPhatTable(
    tf5: TimeframePhat?, tf15: TimeframePhat?,
    p5: Double, p15: Double,
    cardBg: Color, border: Color, textPrimary: Color, muted: Color, green: Color
) {
    Column(
        Modifier.fillMaxSize().background(cardBg, RoundedCornerShape(8.dp))
            .border(1.dp, border, RoundedCornerShape(8.dp)).padding(8.dp)
    ) {
        Text("CLASSIC_HIGH_P_HAT_INTERP", color = muted, fontSize = 8.sp)
        Spacer(Modifier.height(4.dp))
        TfRow("5m", tf5?.pHat ?: p5, tf5?.edgeAsk ?: 0.0, tf5?.kelly ?: 0.0, tf5?.bucket ?: 0.0, textPrimary, muted, green)
        Spacer(Modifier.height(6.dp))
        TfRow("15m", tf15?.pHat ?: p15, tf15?.edgeAsk ?: 0.0, tf15?.kelly ?: 0.0, tf15?.bucket ?: 0.0, textPrimary, muted, green)
    }
}

@Composable
private fun TfRow(label: String, pHat: Double, edgeAsk: Double, kelly: Double, bucket: Double, textPrimary: Color, muted: Color, green: Color) {
    Row(Modifier.fillMaxWidth()) {
        Text(label, color = textPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(28.dp))
        Text("p_hat", color = muted, fontSize = 9.sp, modifier = Modifier.width(36.dp))
        Text("%.3f".format(pHat), color = green, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.width(40.dp))
        Text("edgeAsk", color = muted, fontSize = 9.sp, modifier = Modifier.width(42.dp))
        Text("%+.3f".format(edgeAsk), color = green, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
    }
    Row(Modifier.fillMaxWidth()) {
        Spacer(Modifier.width(28.dp))
        Text("kelly", color = muted, fontSize = 9.sp, modifier = Modifier.width(36.dp))
        Text("%.3f".format(kelly), color = textPrimary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.width(40.dp))
        Text("bucket", color = muted, fontSize = 9.sp, modifier = Modifier.width(42.dp))
        Text("%.2f".format(bucket), color = textPrimary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
    }
}

@Composable
private fun HsOpportunityPanel(
    hs: HsPredictionSnapshot?,
    cardBg: Color, border: Color, textPrimary: Color, muted: Color, green: Color, red: Color
) {
    val explanation = hs?.decisionExplanation
    val score = hs?.opportunityScore ?: 0.0
    val quality = hs?.dataQualityScore ?: 0.0
    Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 3.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Column(
            Modifier.weight(1.1f).background(cardBg, RoundedCornerShape(8.dp)).border(1.dp, border, RoundedCornerShape(8.dp)).padding(10.dp)
        ) {
            SectionLabel("OPPORTUNITY / DECISION", muted)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(explanation?.decision ?: "NO_DATA", color = if (score >= .70) green else muted, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Spacer(Modifier.width(8.dp))
                Text(explanation?.direction ?: "—", color = textPrimary, fontSize = 12.sp)
                Spacer(Modifier.weight(1f))
                Text("${"%.0f".format(score * 100)}/100", color = textPrimary, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
            }
            Text(explanation?.headline ?: "等待真实市场数据", color = muted, fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(5.dp))
            LinearProgressIndicator(progress = { score.toFloat() }, modifier = Modifier.fillMaxWidth().height(4.dp), color = if (score >= .70) green else muted, trackColor = border)
            Spacer(Modifier.height(5.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("DATA ${"%.0f%%".format(quality * 100)}", color = if (quality >= .80) green else red, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                Text("EDGE ${"%+.2f%%".format((hs?.aggregateEdge ?: 0.0) * 100)}", color = textPrimary, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                Text("${hs?.tf15m?.action ?: "NO_DATA"}", color = muted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
            }
        }
        Column(
            Modifier.weight(1f).background(cardBg, RoundedCornerShape(8.dp)).border(1.dp, border, RoundedCornerShape(8.dp)).padding(10.dp)
        ) {
            SectionLabel("WHY / RISK", muted)
            (explanation?.reasons ?: listOf("暂无可解释信号")).take(3).forEach {
                Text("✓ $it", color = green, fontSize = 8.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            (explanation?.risks ?: emptyList()).take(2).forEach {
                Text("! $it", color = red, fontSize = 8.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
private fun HsTopBar(updatedAt: Long, edge: Double, dataMode: String, onRefresh: () -> Unit, textPrimary: Color, muted: Color, green: Color) {
    // 数据年龄：每秒刷新一次，一眼分清“没刷新”和“数值本来就没变”
    var tick by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            tick = System.currentTimeMillis()
            delay(1000L)
        }
    }
    val ageMs = if (updatedAt > 0L) (tick - updatedAt).coerceAtLeast(0L) else 0L
    val ageColor = when {
        updatedAt == 0L -> muted
        ageMs > 120_000L -> Color(0xFFFF5252)
        ageMs > 60_000L -> Color(0xFFFFAB00)
        else -> muted
    }
    val ageText = if (updatedAt == 0L) "无快照" else ageLabel(ageMs)
    Row(
        Modifier.fillMaxWidth().background(Color(0xFF0D0D14)).horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(28.dp).background(Color(0xFF1A1A2E), RoundedCornerShape(6.dp)), contentAlignment = Alignment.Center) {
            Text("H", color = green, fontWeight = FontWeight.Black, fontSize = 16.sp)
        }
        Spacer(Modifier.width(10.dp))
        Column {
            Text("HS PREDICTION ENGINE  //  BTC 5m / 15m / 1h", color = textPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            // 外层 Row 已经是横向滚动，这里不能再叠 horizontalScroll（会拿到 ∞ 宽度约束直接崩）
            Row {
                listOf("总览", "市场", "交易记录", "接入", "管理", "文档").forEachIndexed { i, t ->
                    Text(t, color = if (i == 0) green else muted, fontSize = 11.sp, maxLines = 1, softWrap = false, modifier = Modifier.padding(end = 10.dp))
                }
            }
        }
        Text("UPDATED ${if (updatedAt == 0L) "—" else fmtDashboardTime(updatedAt)} · $ageText", color = ageColor, fontSize = 10.sp, maxLines = 1, softWrap = false)
        Spacer(Modifier.width(8.dp))
        Box(Modifier.background(Color(0xFF0A2A1A), RoundedCornerShape(4.dp)).padding(horizontal = 6.dp, vertical = 2.dp)) {
            Text(dataMode, color = if (dataMode == "LIVE_ACCOUNT") green else muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.width(6.dp))
        Text("EDGE +${"%.1f".format(edge)}%", color = green, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, softWrap = false)
        Spacer(Modifier.width(6.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.Circle, null, tint = green, modifier = Modifier.size(8.dp))
            Spacer(Modifier.width(3.dp))
            Text(if (dataMode == "LIVE_ACCOUNT") "LIVE" else dataMode, color = if (dataMode == "LIVE_ACCOUNT") green else muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        IconButton(onClick = onRefresh, modifier = Modifier.size(32.dp)) {
            Icon(Icons.Filled.Refresh, "刷新", tint = muted, modifier = Modifier.size(16.dp))
        }
    }
}

@Composable
private fun LiveMarketSection(
    candles: List<com.caifenxi.app.domain.btc.BtcCandle>,
    symbol: String,
    timeframe: String,
    price: Double,
    fundingRate: Double?,
    oiChangePct: Double?,
    isDemo: Boolean,
    cardBg: Color, border: Color, green: Color, red: Color, muted: Color, textPrimary: Color
) {
    val last = candles.lastOrNull()
    val prev = candles.getOrNull(candles.size - 2)
    val lastPx = price.takeIf { it > 0.0 } ?: last?.close ?: 0.0
    val chgPct = if (prev != null && prev.close > 0.0 && last != null) (last.close - prev.close) / prev.close * 100.0 else 0.0
    val recent = candles.takeLast(24)
    val hi = recent.maxOfOrNull { it.high } ?: 0.0
    val lo = recent.minOfOrNull { it.low } ?: 0.0
    val up = chgPct >= 0
    Column(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 4.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            SectionLabel("BTC 实时行情 · $symbol $timeframe", muted)
            Spacer(Modifier.weight(1f))
            StatusChip(if (isDemo) "DEMO" else "LIVE", if (isDemo) Color(0xFFFFD54F) else green)
        }
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(bottom = 4.dp),
            verticalAlignment = Alignment.Bottom,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                "$${"%,.2f".format(lastPx)}",
                color = textPrimary, fontSize = 22.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace,
                maxLines = 1, softWrap = false
            )
            Text(
                "%+.2f%%".format(chgPct),
                color = if (up) green else red, fontSize = 13.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace,
                maxLines = 1, softWrap = false
            )
            Text("H ${"%,.2f".format(hi)}", color = muted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, maxLines = 1, softWrap = false)
            Text("L ${"%,.2f".format(lo)}", color = muted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, maxLines = 1, softWrap = false)
            Text("资金费率 ${fundingRate?.let { "%+.4f%%".format(it * 100) } ?: "—"}", color = muted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, maxLines = 1, softWrap = false)
            Text("OI ${oiChangePct?.let { "%+.2f%%".format(it) } ?: "—"}", color = muted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, maxLines = 1, softWrap = false)
        }
        CandlestickChart(
            candles = candles.takeLast(120),
            modifier = Modifier.fillMaxWidth(),
            upColor = green, downColor = red
        )
    }
}

@Composable
private fun LiveMarketStatusStrip(
    status: String,
    detail: String?,
    livePrice: Double?,
    livePriceAt: Long,
    liveDepth: BinanceOrderBookRepository.Snapshot?,
    muted: Color,
    green: Color,
    red: Color,
    cardBg: Color,
    border: Color,
    textPrimary: Color
) {
    val now by produceState(System.currentTimeMillis()) {
        while (true) {
            value = System.currentTimeMillis()
            kotlinx.coroutines.delay(1000L)
        }
    }
    val age = if (livePriceAt > 0L) ((now - livePriceAt).coerceAtLeast(0L) / 1000L) else -1L
    val live = status == "LIVE" && age in 0..5
    val bid = liveDepth?.bestBid
    val ask = liveDepth?.bestAsk
    val spread = liveDepth?.spread
    val imbalance = liveDepth?.imbalance
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 2.dp)
            .background(cardBg, RoundedCornerShape(8.dp))
            .border(1.dp, border, RoundedCornerShape(8.dp)).padding(horizontal = 9.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(9.dp)
    ) {
        StatusChip(if (live) "WS LIVE" else status, if (live) green else red)
        Text("${livePrice?.let { "%,.2f".format(it) } ?: "—"}", color = textPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
        Text(if (age >= 0) "${age}s" else "—", color = muted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
        Text("B ${bid?.let { "%.2f".format(it) } ?: "—"}", color = green, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
        Text("A ${ask?.let { "%.2f".format(it) } ?: "—"}", color = red, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
        Text("spr ${spread?.let { "%.2f".format(it) } ?: "—"}", color = muted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
        Text("imb ${imbalance?.let { "%+.3f".format(it) } ?: "—"}", color = muted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
        detail?.takeIf { it.isNotBlank() }?.let { Text(it, color = muted, fontSize = 8.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) }
    }
}

@Composable
private fun LiveDepthLadder(
    depth: BinanceOrderBookRepository.Snapshot?,
    cardBg: Color,
    border: Color,
    textPrimary: Color,
    muted: Color,
    green: Color,
    red: Color
) {
    val bids = depth?.bids.orEmpty().sortedByDescending { it.price }.take(5)
    val asks = depth?.asks.orEmpty().sortedBy { it.price }.take(5)
    val maxQty = (bids + asks).maxOfOrNull { it.quantity } ?: 0.0
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 2.dp)
            .background(cardBg, RoundedCornerShape(8.dp))
            .border(1.dp, border, RoundedCornerShape(8.dp)).padding(8.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("LIVE ORDER BOOK · TOP 5", color = muted, fontSize = 8.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            Text("imb ${depth?.imbalance?.let { "%+.3f".format(it) } ?: "—"}", color = muted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
        }
        if (depth == null || (bids.isEmpty() && asks.isEmpty())) {
            Text("等待 WebSocket 盘口…", color = muted, fontSize = 9.sp, modifier = Modifier.padding(vertical = 7.dp))
        } else {
            val rows = maxOf(bids.size, asks.size)
            repeat(rows) { i ->
                Row(Modifier.fillMaxWidth().height(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    val a = asks.getOrNull(i)
                    val b = bids.getOrNull(i)
                    DepthCell(a, red, maxQty, textPrimary, Modifier.weight(1f), alignEnd = false)
                    Text("${i + 1}", color = muted, fontSize = 7.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.width(22.dp), textAlign = TextAlign.Center)
                    DepthCell(b, green, maxQty, textPrimary, Modifier.weight(1f), alignEnd = true)
                }
            }
        }
    }
}

@Composable
private fun DepthCell(
    level: BinanceOrderBookRepository.Level?,
    accent: Color,
    maxQty: Double,
    textPrimary: Color,
    modifier: Modifier,
    alignEnd: Boolean
) {
    Row(modifier, verticalAlignment = Alignment.CenterVertically) {
        val px = level?.price?.let { "%,.2f".format(it) } ?: "—"
        val qty = level?.quantity ?: 0.0
        Text(px, color = textPrimary, fontSize = 8.sp, fontFamily = FontFamily.Monospace, textAlign = if (alignEnd) TextAlign.End else TextAlign.Start, modifier = Modifier.weight(1f))
        Box(Modifier.width(46.dp).height(5.dp).background(Color(0xFF1A1A22), RoundedCornerShape(3.dp))) {
            if (qty > 0.0 && maxQty > 0.0) {
                Box(Modifier.fillMaxWidth((qty / maxQty).coerceIn(0.04, 1.0).toFloat()).fillMaxHeight().background(accent.copy(alpha = 0.55f), RoundedCornerShape(3.dp)))
            }
        }
        Text(if (level == null) "—" else "%.3f".format(qty), color = accent, fontSize = 8.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.width(48.dp), textAlign = if (alignEnd) TextAlign.End else TextAlign.Start)
    }
}

@Composable
private fun RealtimeMarketPulse(
    points: List<com.caifenxi.app.domain.btc.RealtimeMarketPoint>,
    cardBg: Color,
    border: Color,
    textPrimary: Color,
    muted: Color,
    green: Color,
    red: Color,
    cyan: Color
) {
    val series = points.takeLast(120)
    val priceSeries = series.map { it.price }.filter { it > 0.0 && it.isFinite() }
    val last = series.lastOrNull()
    val first = series.firstOrNull()
    val movePct = if (first != null && first.price > 0.0) (last!!.price / first.price - 1.0) * 100.0 else 0.0
    val pulse = rememberInfiniteTransition(label = "market-pulse")
    val phase by pulse.animateFloat(0f, 1f, infiniteRepeatable(tween(1400), RepeatMode.Restart), label = "pulse-phase")

    Column(
        Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 3.dp)
            .background(cardBg, RoundedCornerShape(8.dp))
            .border(1.dp, border, RoundedCornerShape(8.dp)).padding(8.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("REALTIME MARKET PULSE · WS EVENT TIMELINE", color = muted, fontSize = 8.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            Text("${series.size} pts", color = muted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
            Spacer(Modifier.width(8.dp))
            Text("%+.3f%%".format(movePct), color = if (movePct >= 0) green else red, fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(5.dp))
        Box(Modifier.fillMaxWidth().height(104.dp).background(Color(0xFF0D0D13), RoundedCornerShape(6.dp))) {
            Canvas(Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height
                for (i in 1..4) drawLine(Color(0xFF1A1A24), Offset(0f, h * i / 5f), Offset(w, h * i / 5f), 1f)
                if (priceSeries.size >= 2) {
                    val mn = priceSeries.minOrNull() ?: 0.0
                    val mx = priceSeries.maxOrNull() ?: mn
                    val span = (mx - mn).coerceAtLeast(max(abs(mn) * 0.00005, 0.01))
                    val path = Path()
                    series.forEachIndexed { i, point ->
                        if (point.price <= 0.0) return@forEachIndexed
                        val x = if (series.lastIndex == 0) w else w * i / series.lastIndex.toFloat()
                        val y = h * (1f - ((point.price - mn) / span).toFloat().coerceIn(0f, 1f) * 0.82f - 0.09f)
                        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                    }
                    drawPath(path, if (movePct >= 0) green else red, style = Stroke(2f, cap = StrokeCap.Round))
                    val lastPoint = series.last()
                    val ly = h * (1f - ((lastPoint.price - mn) / span).toFloat().coerceIn(0f, 1f) * 0.82f - 0.09f)
                    drawCircle(cyan.copy(alpha = 0.35f + 0.35f * phase), 4f + 3f * phase, Offset(w, ly))
                    drawCircle(cyan, 2.8f, Offset(w, ly))
                } else {
                    drawLine(muted.copy(alpha = 0.35f), Offset(0f, h / 2f), Offset(w, h / 2f), 1f)
                }
                // 底部盘口失衡柱：仍使用真实 depth event，不生成随机值。
                if (series.size >= 2) {
                    val base = h - 4f
                    val barW = (w / series.size.toFloat()).coerceAtLeast(1f)
                    series.forEachIndexed { i, point ->
                        val v = point.imbalance.coerceIn(-1.0, 1.0).toFloat()
                        val barH = abs(v) * 13f
                        val x = i * barW + barW * 0.15f
                        val top = if (v >= 0f) base - barH else base
                        drawRect(if (v >= 0f) green.copy(alpha = 0.38f) else red.copy(alpha = 0.38f), Offset(x, top), Size((barW * 0.7f).coerceAtLeast(1f), barH))
                    }
                }
            }
            Row(Modifier.align(Alignment.TopStart).padding(4.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                Text(last?.price?.let { "$${"%,.2f".format(it)}" } ?: "—", color = textPrimary, fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                Text("spr ${last?.spread?.let { "%.2f".format(it) } ?: "—"}", color = cyan, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                Text("imb ${last?.imbalance?.let { "%+.3f".format(it) } ?: "—"}", color = muted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
            }
        }
        Text(
            if (last == null) "等待真实 WebSocket 事件…" else "时间轴：${fmtDashboardTime(last.eventTime)} · 每 250ms 最多记录 1 点 · 底部柱=盘口 imbalance",
            color = muted, fontSize = 7.sp, fontFamily = FontFamily.Monospace,
            modifier = Modifier.padding(top = 4.dp)
        )
    }
}

@Composable
private fun MetricCard(title: String, value: String, subtitle: String, textPrimary: Color, muted: Color, cardBg: Color, border: Color, valueColor: Color = textPrimary) {
    Column(Modifier.width(130.dp).background(cardBg, RoundedCornerShape(8.dp)).border(1.dp, border, RoundedCornerShape(8.dp)).padding(10.dp)) {
        Text(title, color = muted, fontSize = 9.sp, fontWeight = FontWeight.Medium, letterSpacing = 0.5.sp)
        Text(value, color = valueColor, fontSize = 18.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        Text(subtitle, color = muted, fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun EdgeSpreadChart(modifier: Modifier, green: Color, cyan: Color, muted: Color, edgeHistory: List<Double>) {
    val series = edgeHistory.takeLast(60)
    val mn = series.minOrNull() ?: 0.0
    val mx = series.maxOrNull() ?: 0.0
    val flat = series.size >= 2 && (mx - mn) < 1e-9
    val transition = rememberInfiniteTransition(label = "edge-live")
    val phase by transition.animateFloat(0f, 1f, infiniteRepeatable(tween(1800), RepeatMode.Restart), label = "edge-phase")
    Box(modifier) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width; val h = size.height
            for (i in 1..4) drawLine(Color(0xFF1A1A28), Offset(0f, h * i / 5), Offset(w, h * i / 5), 1f)
            fun path(pts: List<Float>, c: Color, sw: Float) {
                val p = Path()
                pts.forEachIndexed { i, v ->
                    val x = w * i / (pts.size - 1); val y = h * (1f - v)
                    if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
                }
                drawPath(p, c, style = Stroke(sw, cap = StrokeCap.Round))
            }
            if (series.size >= 2) {
                // 自适应归一化：按最近 60 点的 min/max 展开；全等（edge 恒为 0）时给最小可视带宽
                val span = if (mx - mn > 1e-9) (mx - mn) else max(abs(mx) * 0.02, 0.002)
                val pts = series.map { (((it - mn) / span) * 0.76 + 0.12).coerceIn(0.05, 0.95).toFloat() }
                path(pts, green, 2f)
            }
            drawLine(Color(0xFF333344), Offset(0f, h * 0.5f), Offset(w, h * 0.5f), 1f)
            if (series.size >= 2) {
                val sx = w * phase
                drawLine(cyan.copy(alpha = 0.22f), Offset(sx, 0f), Offset(sx, h), 1f)
                val span2 = if (mx - mn > 1e-9) mx - mn else max(abs(mx) * 0.02, 0.002)
                val lastY = h * (1f - (((series.last() - mn) / span2) * 0.76 + 0.12).coerceIn(0.05, 0.95)).toFloat()
                drawCircle(green.copy(alpha = 0.55f + 0.35f * phase), 3f + 2f * phase, Offset(w, lastY))
            }
        }
        when {
            series.isEmpty() -> Text("edge 数据积累中 · 0/2 点", color = muted, fontSize = 9.sp, modifier = Modifier.align(Alignment.Center))
            series.size == 1 -> Text("edge 数据积累中 · 1/2 点", color = muted, fontSize = 9.sp, modifier = Modifier.align(Alignment.Center))
            flat -> Text("edge ${"%+.4f".format(mx)} 恒定（无可成交盘口）", color = muted, fontSize = 9.sp, modifier = Modifier.align(Alignment.Center))
            else -> {
                Text("max ${"%+.4f".format(mx)}", color = muted, fontSize = 8.sp, modifier = Modifier.align(Alignment.TopEnd).padding(3.dp))
                Text("min ${"%+.4f".format(mn)}", color = muted, fontSize = 8.sp, modifier = Modifier.align(Alignment.BottomEnd).padding(3.dp))
            }
        }
    }
}

@Composable
private fun BayesParticleField(
    modifier: Modifier,
    trigger: Double,
    particles: List<BayesParticle>,
    bayesMean: Double,
    cyan: Color,
    green: Color,
    muted: Color
) {
    // 真实粒子：x = state（上涨概率），y 由 weight+velocity 映射；无数据时轻微抖动兜底
    val pts = remember(particles, bayesMean) {
        if (particles.isNotEmpty()) {
            particles.mapIndexed { i, p ->
                val nx = p.state.toFloat().coerceIn(0.02f, 0.98f)
                val ny = (0.5 + (p.velocity * 2.5) + ((i % 7) - 3) * 0.04).toFloat().coerceIn(0.08f, 0.92f)
                val a = (0.25f + p.weight.toFloat() * particles.size * 0.55f).coerceIn(0.15f, 0.95f)
                Triple(nx, ny, a)
            }
        } else emptyList()
    }
    val transition = rememberInfiniteTransition(label = "bayes-live")
    val phase by transition.animateFloat(0f, 1f, infiniteRepeatable(tween(2400), RepeatMode.Reverse), label = "bayes-phase")
    Box(modifier) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width; val h = size.height
            // 以 bayesMean 为中心的径向辉光
            val cx = (bayesMean.toFloat().coerceIn(0.15f, 0.85f)) * w
            drawCircle(
                Brush.radialGradient(
                    listOf(Color(0xFF0A2A2A).copy(alpha = 0.45f), Color.Transparent),
                    Offset(cx, h * 0.45f),
                    w * 0.32f
                ),
                w * 0.32f,
                Offset(cx, h * 0.45f)
            )
            // 粒子点：半径与透明度都设下界，保证小权重时肉眼可见（原 ~2px/0.19 透明度在白底上几乎不可见）
            pts.forEach { (nx, ny, a) ->
                val r = 3.2f + a * 3.3f
                val alpha = (0.45f + a * 0.50f).coerceIn(0.45f, 0.95f)
                val drift = sin((phase * 6.28318f) + nx * 4f) * 2.2f
                drawCircle(cyan.copy(alpha = alpha), r, Offset(nx * w + drift, ny * h))
                drawCircle(Color(0xFF0A2A33), r, Offset(nx * w + drift, ny * h), style = Stroke(1f))
            }
            // 高权重点（weight 前 15%）用绿色标出（加描边，保证可见）
            val top = if (particles.isNotEmpty()) {
                particles.sortedByDescending { it.weight }.take((particles.size * 0.15).toInt().coerceAtLeast(3))
            } else emptyList()
            top.forEachIndexed { i, p ->
                val x = p.state.toFloat().coerceIn(0.05f, 0.95f) * w
                val y = (0.42f + (i % 5) * 0.03f) * h
                drawCircle(green.copy(alpha = 0.95f), 5.0f, Offset(x, y))
                drawCircle(green, 5.0f, Offset(x, y), style = Stroke(1.2f))
            }
        }
        if (pts.isEmpty()) Text("NO LIVE PARTICLES", color = muted, fontSize = 10.sp, modifier = Modifier.align(Alignment.Center))
        Text("BAYES", color = green, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.Center).offset(y = (-8).dp))
        Text("trigger +${"%.1f".format(trigger)}", color = cyan, fontSize = 10.sp, modifier = Modifier.align(Alignment.Center).offset(y = 10.dp))
        Text("mean ${"%.3f".format(bayesMean)}", color = muted, fontSize = 9.sp, modifier = Modifier.align(Alignment.TopEnd).padding(12.dp))
        Text("n=${particles.size.coerceAtLeast(pts.size)}", color = muted, fontSize = 9.sp, modifier = Modifier.align(Alignment.CenterEnd).padding(12.dp))
        Text("5m p_hat", color = muted, fontSize = 9.sp, modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 12.dp))
    }
}

@Composable
private fun PhatProbabilityChart(modifier: Modifier, history: Map<String, List<Double>>, green: Color, cyan: Color, red: Color) {
    val transition = rememberInfiniteTransition(label = "phat-live")
    val phase by transition.animateFloat(0f, 1f, infiniteRepeatable(tween(2200), RepeatMode.Restart), label = "phat-phase")
    Canvas(modifier) {
        val w = size.width; val h = size.height
        fun line(pts: List<Double>, c: Color) {
            if (pts.size < 2) return
            val p = Path()
            pts.forEachIndexed { i, v ->
                val x = w * i / (pts.size - 1f); val y = h * (1f - v.coerceIn(0.0, 1.0).toFloat())
                if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
            }
            drawPath(p, c, style = Stroke(1.8f, cap = StrokeCap.Round))
        }
        line(history["5m"].orEmpty(), green)
        line(history["15m"].orEmpty(), cyan)
        line(history["1h"].orEmpty(), red.copy(alpha = 0.8f))
        drawLine(Color.White.copy(alpha = 0.04f), Offset(0f, h * 0.5f), Offset(w, h * 0.5f), 1f)
        if (history.values.any { it.size >= 2 }) {
            val x = w * phase
            drawLine(cyan.copy(alpha = 0.20f), Offset(x, 0f), Offset(x, h), 1f)
            history.forEach { (_, values) ->
                values.lastOrNull()?.let { v -> drawCircle(Color.White.copy(alpha = 0.72f), 2.5f, Offset(w, h * (1f - v.coerceIn(0.0, 1.0).toFloat()))) }
            }
        }
    }
}

@Composable
private fun BotStatusPanel(
    balance: Double,
    available: Double,
    p5: Double,
    p15: Double,
    p1h: Double,
    hs: HsPredictionSnapshot?,
    textPrimary: Color,
    muted: Color,
    green: Color,
    red: Color
) {
    Column {
        listOf(
            "Balance" to "$${fmtMoney(balance)}",
            "Available" to "$${fmtMoney(available)}",
            "Trade Volume" to if (hs == null) "—" else "$${fmtMoney(hs.binanceDepthBid + hs.binanceDepthAsk)}",
            "DATA" to (hs?.dataMode ?: "离线"),
            "5m p_hat" to "${"%.3f".format(p5)} (${(p5 * 100).toInt()}%)",
            "15m p_hat" to "${"%.3f".format(p15)} (${(p15 * 100).toInt()}%)",
            "1h p_hat" to "${"%.3f".format(p1h)} (${(p1h * 100).toInt()}%)"
        ).forEach { (k, v) ->
            Row(Modifier.fillMaxWidth().padding(vertical = 1.dp)) {
                Text(k, color = muted, fontSize = 9.sp, modifier = Modifier.weight(1f))
                Text(v, color = if (k.contains("p_hat") || k.contains("API")) green else textPrimary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
            }
        }
        Spacer(Modifier.height(4.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(if (hs?.systemsOnline == true) "SYSTEMS ONLINE" else "SYSTEMS DEGRADED", color = muted, fontSize = 8.sp)
            Spacer(Modifier.weight(1f))
            Text(if (hs?.systemsOnline == true) "ON" else "OFF", color = if (hs?.systemsOnline == true) green else red, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable private fun SectionLabel(text: String, color: Color, modifier: Modifier = Modifier) {
    Text(text, color = color, fontSize = 9.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.8.sp, modifier = modifier.padding(bottom = 4.dp))
}

@Composable private fun StatusChip(text: String, color: Color) {
    Box(Modifier.background(color.copy(alpha = 0.12f), RoundedCornerShape(4.dp)).border(1.dp, color.copy(alpha = 0.3f), RoundedCornerShape(4.dp)).padding(horizontal = 8.dp, vertical = 3.dp)) {
        Text(text, color = color, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
    }
}

private fun fmtMoney(v: Double): String = "%,.0f".format(v)
private fun fmtDashboardTime(ts: Long): String =
    java.text.SimpleDateFormat("yyyy/MM/dd HH:mm:ss", java.util.Locale.US).format(java.util.Date(ts))

/** 数据年龄文案：让“没刷新”和“数值本来就没变”一眼可分 */
private fun ageLabel(ms: Long): String = when {
    ms < 1500L -> "刚刚"
    ms < 60_000L -> "${ms / 1000} 秒前"
    ms < 3_600_000L -> "${ms / 60_000} 分钟前"
    else -> "${ms / 3_600_000} 小时前"
}


@Composable
private fun PolymarketTerminalPanel(
    panel: com.caifenxi.app.domain.btc.hs.HsPolymarketPanel?,
    currentPrice: Double,
    priceHistory: List<Double> = emptyList(),
    cardBg: Color,
    border: Color,
    textPrimary: Color,
    muted: Color,
    green: Color,
    red: Color,
    cyan: Color
) {
    if (panel == null) {
        Column(
            Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 5.dp)
                .background(cardBg, RoundedCornerShape(8.dp))
                .border(1.dp, border, RoundedCornerShape(8.dp)).padding(10.dp)
        ) {
            SectionLabel("预测市场 / BTC 5分钟涨跌", muted)
            Text("暂无活跃的5分钟市场", color = muted, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
            Text("未发现符合条件的实时市场；不会用本地数据冒充 Polymarket。", color = muted, fontSize = 10.sp)
        }
        return
    }

    var clock by remember(panel.market.conditionId) { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(panel.market.conditionId, panel.market.endDateMs) {
        while (true) {
            clock = System.currentTimeMillis()
            delay(1000L)
        }
    }
    val remaining = ((panel.market.endDateMs ?: clock) - clock).coerceAtLeast(0L)
    val mins = remaining / 60_000L
    val secs = (remaining / 1_000L) % 60L
    val yes = panel.market.yesPrice.coerceIn(0.0, 1.0)
    val no = panel.market.noPrice.coerceIn(0.0, 1.0)
    val yesAsk = panel.yesAsk
    val noAsk = panel.noAsk
    val yesBid = panel.yesBid
    val noBid = panel.noBid

    Column(
        Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 5.dp)
            .background(cardBg, RoundedCornerShape(8.dp))
            .border(1.dp, border, RoundedCornerShape(8.dp)).padding(10.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("POLYMARKET", color = textPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text("BTC UP OR DOWN 5M", color = cyan, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
            }
            Text("%02d:%02d".format(mins, secs), color = if (remaining < 30_000L) red else green, fontSize = 16.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
        }
        Text(panel.market.question, color = muted, fontSize = 10.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 5.dp))
        PolymarketMiniChart(priceHistory, yes, Modifier.fillMaxWidth().height(72.dp).padding(top = 5.dp), green, red, muted)

        Row(Modifier.fillMaxWidth().padding(top = 9.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TerminalPriceBox("PRICE TO BEAT", panel.market.priceToBeat, textPrimary, muted, Modifier.weight(1f))
            TerminalPriceBox("CURRENT BTC", currentPrice.takeIf { it > 0.0 }, textPrimary, muted, Modifier.weight(1f))
            TerminalPriceBox("DELTA", panel.market.priceToBeat?.let { currentPrice - it }, if ((panel.market.priceToBeat ?: currentPrice) <= currentPrice) green else red, muted, Modifier.weight(1f), signed = true)
        }

        Row(Modifier.fillMaxWidth().padding(top = 9.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            OutcomeQuote("UP", yes, yesBid, yesAsk, green, cardBg, border, textPrimary, muted, Modifier.weight(1f))
            OutcomeQuote("DOWN", no, noBid, noAsk, red, cardBg, border, textPrimary, muted, Modifier.weight(1f))
        }

        Text("ORDER BOOK", color = muted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.padding(top = 9.dp))
        Row(Modifier.fillMaxWidth().padding(top = 3.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            BookMiniColumn("UP BIDS", panel.yesBids.sortedByDescending { it.price }.take(3), green, textPrimary, muted, Modifier.weight(1f))
            BookMiniColumn("UP ASKS", panel.yesAsks.sortedBy { it.price }.take(3), red, textPrimary, muted, Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            BookMiniColumn("DOWN BIDS", panel.noBids.sortedByDescending { it.price }.take(3), green, textPrimary, muted, Modifier.weight(1f))
            BookMiniColumn("DOWN ASKS", panel.noAsks.sortedBy { it.price }.take(3), red, textPrimary, muted, Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            StatusChip(if (panel.bookLive) "CLOB LIVE" else "CLOB PARTIAL", if (panel.bookLive) green else muted)
            Spacer(Modifier.weight(1f))
            Text("snapshot ${panel.fetchedAt}", color = muted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
        }
    }
}

@Composable
private fun PolymarketMiniChart(
    history: List<Double>,
    current: Double,
    modifier: Modifier,
    green: Color,
    red: Color,
    muted: Color
) {
    val values = (history + current).filter { it.isFinite() }.takeLast(60)
    Box(modifier.background(Color(0xFF0D0D13), RoundedCornerShape(6.dp))) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width; val h = size.height
            for (i in 1..3) drawLine(Color(0xFF1A1A24), Offset(0f, h * i / 4f), Offset(w, h * i / 4f), 1f)
            if (values.size >= 2) {
                val minV = values.minOrNull() ?: 0.0
                val maxV = values.maxOrNull() ?: 1.0
                val span = (maxV - minV).coerceAtLeast(0.005)
                val path = Path()
                values.forEachIndexed { i, v ->
                    val x = w * i / (values.lastIndex.toFloat())
                    val y = h * (1f - ((v - minV) / span).toFloat().coerceIn(0f, 1f))
                    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                val rising = values.last() >= values.first()
                drawPath(path, if (rising) green else red, style = Stroke(1.7f, cap = StrokeCap.Round))
                val lastY = h * (1f - ((values.last() - minV) / span).toFloat().coerceIn(0f, 1f))
                drawCircle(if (rising) green else red, 3f, Offset(w, lastY))
            } else {
                drawLine(muted.copy(alpha = 0.35f), Offset(0f, h / 2f), Offset(w, h / 2f), 1f)
            }
        }
        Text("YES PRICE HISTORY · ${"%.0f".format(current * 100)}¢", color = muted, fontSize = 7.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.align(Alignment.TopStart).padding(4.dp))
    }
}

@Composable
private fun TerminalPriceBox(title: String, value: Double?, valueColor: Color, muted: Color, modifier: Modifier, signed: Boolean = false) {
    Column(modifier.background(Color(0xFF0D0D13), RoundedCornerShape(6.dp)).padding(7.dp)) {
        Text(title, color = muted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
        Text(value?.let { if (signed) "%+.2f".format(it) else "$${"%,.2f".format(it)}" } ?: "—", color = valueColor, fontSize = 12.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun OutcomeQuote(title: String, probability: Double, bid: Double?, ask: Double?, accent: Color, cardBg: Color, border: Color, textPrimary: Color, muted: Color, modifier: Modifier) {
    Column(modifier.background(cardBg, RoundedCornerShape(6.dp)).border(1.dp, border, RoundedCornerShape(6.dp)).padding(8.dp)) {
        Text(title, color = accent, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        Text("${"%.0f".format(probability * 100)}¢", color = textPrimary, fontSize = 18.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
        Text("B ${bid?.let { "%.3f".format(it) } ?: "—"}  A ${ask?.let { "%.3f".format(it) } ?: "—"}", color = muted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
    }
}

@Composable
private fun BookMiniColumn(title: String, levels: List<com.caifenxi.app.domain.btc.polymarket.PolyBookLevel>, accent: Color, textPrimary: Color, muted: Color, modifier: Modifier) {
    Column(modifier) {
        Text(title, color = accent, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
        levels.forEach { level ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("%.3f".format(level.price), color = textPrimary, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                Text("%.1f".format(level.size), color = muted, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
            }
        }
        if (levels.isEmpty()) Text("—", color = muted, fontSize = 8.sp)
    }
}
