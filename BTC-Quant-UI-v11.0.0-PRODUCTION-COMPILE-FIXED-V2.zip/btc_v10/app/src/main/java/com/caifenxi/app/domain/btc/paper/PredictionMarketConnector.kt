package com.caifenxi.app.domain.btc.paper

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * 预测市场对接层 — Polymarket + Binance
 *
 * 职责：
 * - 查询 Polymarket 活跃 BTC 预测市场，获取 Yes/No 赔率、流动性
 * - 查询 Binance BTC 实时价格（作为本地二元期权的价格快照源）
 * - 统一封装为 MarketOdds 供引擎和 UI 使用
 *
 * Polymarket: 价格 0~1（如 0.55 = 55% 概率），赔率 = 1/price
 * Binance: 直接用现货/合约价格做本地快照，赔率由引擎配置
 */
class PredictionMarketConnector(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()
) {
    private val polymarketBase = "https://clob.polymarket.com"
    private val binanceBase = "https://api.binance.com"

    // === Polymarket ===

    /**
     * 查询 Polymarket 上与 BTC 价格涨跌相关的活跃预测市场。
     *
     * Polymarket CLOB API: GET /markets
     * 响应是数组，每个 market 含 conditionId, question, outcomes, prices 等。
     */
    suspend fun fetchPolymarketBtcMarkets(): List<MarketOdds> = withContext(Dispatchers.IO) {
        runCatching {
            // 搜索包含 Bitcoin/BTC 且与价格涨跌相关的市场
            val url = "$polymarketBase/markets"
            val arr = getJsonArray(url)
            val results = mutableListOf<MarketOdds>()

            for (i in 0 until arr.length()) {
                val market = arr.optJSONObject(i) ?: continue
                val question = market.optString("question", "").lowercase()

                // 筛选 BTC 价格相关的预测市场
                val isBtcRelated = question.contains("bitcoin") ||
                    question.contains("btc") ||
                    question.contains("crypto")

                if (!isBtcRelated) continue

                // 解析 Yes/No 价格
                val tokens = market.optJSONArray("tokens")
                val yesPrice: Double
                val noPrice: Double
                val yesTokenId: String
                var noTokenId: String

                if (tokens != null && tokens.length() >= 2) {
                    val yesToken = tokens.optJSONObject(0)
                    val noToken = tokens.optJSONObject(1)
                    yesPrice = yesToken?.optString("price", "0.5")?.toDoubleOrNull() ?: 0.5
                    noPrice = noToken?.optString("price", "0.5")?.toDoubleOrNull() ?: 0.5
                    yesTokenId = yesToken?.optString("token_id", "") ?: ""
                    noTokenId = noToken?.optString("token_id", "") ?: ""
                } else {
                    // 回退：尝试从 outcomes/prices 解析
                    val prices = market.optJSONArray("outcomePrices")
                    yesPrice = parsePriceAt(prices, 0)
                    noPrice = parsePriceAt(prices, 1)
                    yesTokenId = ""
                    noTokenId = ""
                }

                val conditionId = market.optString("condition_id", market.optString("conditionId", ""))
                val endTime = market.optLong("end_date_iso", 0L)
                val endTimeMs = parseIsoToMs(market.optString("endDate", market.optString("end_date_iso", "")))
                val liquidity = market.optString("liquidity", "0").toDoubleOrNull() ?: 0.0
                val volume24h = market.optString("volume24hr", market.optString("volume", "0"))
                    .toDoubleOrNull() ?: 0.0
                val closed = market.optBoolean("closed", false)

                results.add(
                    MarketOdds(
                        platform = "POLYMARKET",
                        marketId = conditionId,
                        question = market.optString("question", "BTC Prediction"),
                        yesOdds = MarketOdds.priceToOdds(yesPrice),
                        noOdds = MarketOdds.priceToOdds(noPrice),
                        yesPrice = yesPrice,
                        noPrice = noPrice,
                        liquidity = liquidity,
                        volume24h = volume24h,
                        endTime = endTimeMs,
                        resolved = closed
                    )
                )
            }

            results
        }.getOrElse { emptyList() }
    }

    /**
     * 获取单个 Polymarket 市场的最新赔率。
     */
    suspend fun fetchPolymarketMarket(marketId: String): MarketOdds? = withContext(Dispatchers.IO) {
        runCatching {
            val url = "$polymarketBase/markets/$marketId"
            val obj = getJsonObject(url)

            val tokens = obj.optJSONArray("tokens")
            val yesPrice: Double
            val noPrice: Double

            if (tokens != null && tokens.length() >= 2) {
                yesPrice = tokens.optJSONObject(0)?.optString("price", "0.5")?.toDoubleOrNull() ?: 0.5
                noPrice = tokens.optJSONObject(1)?.optString("price", "0.5")?.toDoubleOrNull() ?: 0.5
            } else {
                val prices = obj.optJSONArray("outcomePrices")
                yesPrice = parsePriceAt(prices, 0)
                noPrice = parsePriceAt(prices, 1)
            }

            MarketOdds(
                platform = "POLYMARKET",
                marketId = marketId,
                question = obj.optString("question", "BTC Prediction"),
                yesOdds = MarketOdds.priceToOdds(yesPrice),
                noOdds = MarketOdds.priceToOdds(noPrice),
                yesPrice = yesPrice,
                noPrice = noPrice,
                liquidity = obj.optString("liquidity", "0").toDoubleOrNull() ?: 0.0,
                volume24h = obj.optString("volume24hr", obj.optString("volume", "0"))
                    .toDoubleOrNull() ?: 0.0,
                endTime = parseIsoToMs(obj.optString("endDate", obj.optString("end_date_iso", ""))),
                resolved = obj.optBoolean("closed", false)
            )
        }.getOrNull()
    }

    // === Binance ===

    /**
     * 获取 Binance BTC 现货实时价格（作为本地二元期权的价格快照源）。
     *
     * GET /api/v3/ticker/price?symbol=BTCUSDT
     */
    suspend fun fetchBinanceBtcPrice(symbol: String = "BTCUSDT"): Double = withContext(Dispatchers.IO) {
        runCatching {
            val url = "$binanceBase/api/v3/ticker/price?symbol=$symbol"
            val obj = getJsonObject(url)
            obj.optString("price", "0").toDoubleOrNull() ?: 0.0
        }.getOrElse { 0.0 }
    }

    /**
     * 获取 Binance BTC 合约标记价格（更高精度）。
     *
     * GET /fapi/v1/premiumIndex?symbol=BTCUSDT
     */
    suspend fun fetchBinanceMarkPrice(symbol: String = "BTCUSDT"): Double = withContext(Dispatchers.IO) {
        val bases = listOf("https://fapi.binance.com", "https://api.binance.com", "https://testnet.binancefuture.com")
        for (base in bases) {
            val price = runCatching {
                val url = "$base/fapi/v1/premiumIndex?symbol=$symbol"
                val obj = getJsonObject(url)
                obj.optString("markPrice", "0").toDoubleOrNull() ?: 0.0
            }.getOrNull()
            if (price != null && price > 0.0) return@withContext price
        }
        return@withContext 0.0
    }

    /**
     * 构建一个本地 Binance 二元期权市场（不依赖 Polymarket，用引擎默认赔率）。
     *
     * @param currentPrice 当前 BTC 价格
     * @param roundEndTime 周期结束时间
     * @param defaultOdds 默认赔率
     */
    fun buildBinanceLocalMarket(
        currentPrice: Double,
        roundEndTime: Long,
        defaultOdds: Double = 1.9
    ): MarketOdds {
        // 根据当前价格相对开窗的偏离微调赔率（偏离越大，反方向赔率越高）
        // 这是一个简化的赔率模型：价格越偏离 50/50，优势方赔率越低
        return MarketOdds(
            platform = "BINANCE",
            marketId = "BTC-5MIN-${roundEndTime / 300_000}",
            question = "BTC 5min Up or Down? (Open: %.2f)".format(currentPrice),
            yesOdds = defaultOdds,
            noOdds = defaultOdds,
            yesPrice = MarketOdds.oddsToPrice(defaultOdds),
            noPrice = MarketOdds.oddsToPrice(defaultOdds),
            liquidity = Double.MAX_VALUE,  // 本地引擎无流动性限制
            volume24h = 0.0,
            endTime = roundEndTime,
            resolved = false
        )
    }

    /**
     * 批量查询：同时获取 Polymarket 市场列表和 Binance 价格。
     * 用于 UI 刷新时一次性加载。
     */
    suspend fun fetchAllMarkets(
        btcSymbol: String = "BTCUSDT",
        currentRoundEnd: Long = 0L
    ): AllMarketsResult = withContext(Dispatchers.IO) {
        val polyMarkets = fetchPolymarketBtcMarkets()
        val binancePrice = fetchBinanceMarkPrice(btcSymbol)
        val binanceLocal = buildBinanceLocalMarket(binancePrice, currentRoundEnd)

        AllMarketsResult(
            polymarketMarkets = polyMarkets,
            binancePrice = binancePrice,
            binanceLocalMarket = binanceLocal,
            timestamp = System.currentTimeMillis()
        )
    }

    // === Polymarket 下单 ===

    /**
     * 在 Polymarket 提交真实限价单（买入 YES 或 NO 份额）。
     *
     * Polymarket CLOB API: POST /order
     * 需要完整的 L2 认证（API Key + HMAC 签名）。
     * dryRun=true 时本地模拟，不发送真实请求。
     *
     * @param request 下单请求
     * @param apiKey Polymarket API Key
     * @param apiSecret Polymarket API Secret（用于 HMAC 签名）
     * @param passphrase Polymarket Passphrase
     * @param dryRun true=本地模拟，false=发送真实请求
     * @return PolymarketOrderResult
     */
    suspend fun placePolymarketOrder(
        request: PolymarketOrderRequest,
        apiKey: String,
        apiSecret: String,
        passphrase: String,
        dryRun: Boolean = true
    ): PolymarketOrderResult = withContext(Dispatchers.IO) {
        // Dry run: 本地模拟成功
        if (dryRun || apiKey.isBlank()) {
            return@withContext PolymarketOrderResult(
                success = true,
                orderId = "POLY-DRY-${System.currentTimeMillis()}",
                status = "DRY_RUN",
                rawResponse = "dry-run: ${request.side} ${request.size} shares @ ${request.price} (token=${request.tokenId.take(8)}...)",
                error = null
            )
        }

        runCatching {
            val timestamp = System.currentTimeMillis() / 1000
            val body = JSONObject()
                .put("tokenID", request.tokenId)
                .put("price", request.price)
                .put("size", request.size)
                .put("side", request.side)
                .put("feeRateBps", request.feeRateBps)
                .put("nonce", request.nonce)
                .put("expiration", request.expiration)
                .put("type", request.orderType)
                .toString()

            // HMAC-SHA256 签名（L2 auth）
            val signature = hmacSha256(body, apiSecret)

            val req = Request.Builder()
                .url("$polymarketBase/order")
                .post(body.toRequestBody(JSON_MEDIA))
                .header("Content-Type", "application/json")
                .header("POLY_API_KEY", apiKey)
                .header("POLY_SIGNATURE", signature)
                .header("POLY_TIMESTAMP", timestamp.toString())
                .apply {
                    if (passphrase.isNotBlank()) header("POLY_PASSPHRASE", passphrase)
                }
                .build()

            client.newCall(req).execute().use { resp ->
                val text = resp.body?.string().orEmpty()
                if (resp.isSuccessful) {
                    val id = runCatching {
                        JSONObject(text).optString("orderID")
                    }.getOrNull()
                    PolymarketOrderResult(
                        success = true,
                        orderId = id,
                        status = "OK",
                        rawResponse = text.take(500),
                        error = null
                    )
                } else {
                    PolymarketOrderResult(
                        success = false,
                        orderId = null,
                        status = "HTTP_${resp.code}",
                        rawResponse = text.take(500),
                        error = "Polymarket CLOB ${resp.code}: ${text.take(240)}"
                    )
                }
            }
        }.getOrElse { e ->
            PolymarketOrderResult(
                success = false,
                orderId = null,
                status = "ERROR",
                rawResponse = null,
                error = e.message ?: "Polymarket place order error"
            )
        }
    }

    // === Binance 下单 ===

    /**
     * 在 Binance 提交真实订单（现货市价买卖 BTC，作为二元期权方向代理）。
     *
     * Binance Spot API: POST /api/v3/order
     * 需要 HMAC-SHA256 签名（API Key + Secret）。
     * testnet=true 使用测试网。
     *
     * 注意：Binance 无原生二元期权，此处用现货市价单做方向代理。
     * 本地二元期权引擎仍按价格快照结算，Binance 现货单用于真实资金敞口。
     * 亏损上限 = 下注本金（由引擎控制，不在 Binance 侧引入杠杆）。
     *
     * @param request 下单请求
     * @param apiKey Binance API Key
     * @param apiSecret Binance API Secret
     * @param testnet true=测试网，false=主网
     * @return BinanceOrderResult
     */
    suspend fun placeBinanceOrder(
        request: BinanceOrderRequest,
        apiKey: String,
        apiSecret: String,
        testnet: Boolean = true
    ): BinanceOrderResult = withContext(Dispatchers.IO) {
        if (apiKey.isBlank() || apiSecret.isBlank()) {
            return@withContext BinanceOrderResult(
                success = false,
                orderId = null,
                status = "NO_KEY",
                error = "Binance API Key/Secret 未配置"
            )
        }

        runCatching {
            val baseUrl = if (testnet) "https://testnet.binance.vision" else binanceBase
            val timestamp = System.currentTimeMillis()

            // 构建查询参数（按字母序排列）
            val params = LinkedHashMap<String, String>()
            params["symbol"] = request.symbol
            params["side"] = request.side
            params["type"] = request.orderType
            params["quantity"] = formatQuantity(request.quantity)
            if (request.orderType == "LIMIT") {
                params["timeInForce"] = "GTC"
                params["price"] = formatQuantity(request.price)
            }
            params["recvWindow"] = "5000"
            params["timestamp"] = timestamp.toString()

            val queryString = params.entries.joinToString("&") { "${it.key}=${it.value}" }
            val signature = hmacSha256(queryString, apiSecret)
            val fullUrl = "$baseUrl/api/v3/order?$queryString&signature=$signature"

            val req = Request.Builder()
                .url(fullUrl)
                .post("".toRequestBody(JSON_MEDIA))
                .header("X-MBX-APIKEY", apiKey)
                .header("Content-Type", "application/json")
                .build()

            client.newCall(req).execute().use { resp ->
                val text = resp.body?.string().orEmpty()
                if (resp.isSuccessful) {
                    val json = JSONObject(text)
                    BinanceOrderResult(
                        success = true,
                        orderId = json.optLong("orderId", 0L),
                        status = json.optString("status", "UNKNOWN"),
                        executedQty = json.optString("executedQty", "0").toDoubleOrNull() ?: 0.0,
                        avgPrice = json.optString("cummulativeQuoteQty", "0").toDoubleOrNull()
                            ?.let { q -> if (request.quantity > 0) q / request.quantity else 0.0 } ?: 0.0,
                        rawResponse = text.take(500),
                        error = null
                    )
                } else {
                    BinanceOrderResult(
                        success = false,
                        orderId = null,
                        status = "HTTP_${resp.code}",
                        error = "Binance ${resp.code}: ${text.take(240)}"
                    )
                }
            }
        }.getOrElse { e ->
            BinanceOrderResult(
                success = false,
                orderId = null,
                status = "ERROR",
                error = e.message ?: "Binance place order error"
            )
        }
    }

    /**
     * 查询 Binance 账户余额（用于确认下单前资金充足）。
     */
    suspend fun fetchBinanceAccountBalance(
        apiKey: String,
        apiSecret: String,
        testnet: Boolean = true,
        asset: String = "USDT"
    ): Double = withContext(Dispatchers.IO) {
        if (apiKey.isBlank() || apiSecret.isBlank()) return@withContext 0.0

        runCatching {
            val baseUrl = if (testnet) "https://testnet.binance.vision" else binanceBase
            val timestamp = System.currentTimeMillis()
            val queryString = "recvWindow=5000&timestamp=$timestamp"
            val signature = hmacSha256(queryString, apiSecret)
            val fullUrl = "$baseUrl/api/v3/account?$queryString&signature=$signature"

            val req = Request.Builder()
                .url(fullUrl)
                .get()
                .header("X-MBX-APIKEY", apiKey)
                .build()

            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@withContext 0.0
                val json = JSONObject(resp.body?.string().orEmpty())
                val balances = json.optJSONArray("balances") ?: return@withContext 0.0
                for (i in 0 until balances.length()) {
                    val bal = balances.optJSONObject(i) ?: continue
                    if (bal.optString("asset") == asset) {
                        return@withContext bal.optString("free", "0").toDoubleOrNull() ?: 0.0
                    }
                }
                0.0
            }
        }.getOrElse { 0.0 }
    }

    // === Helpers ===

    private fun getJsonObject(url: String): JSONObject {
        val req = Request.Builder().url(url).get().build()
        client.newCall(req).execute().use { resp ->
            val body = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) error("HTTP ${resp.code}: ${body.take(200)}")
            return JSONObject(body)
        }
    }

    private fun getJsonArray(url: String): JSONArray {
        val req = Request.Builder().url(url).get().build()
        client.newCall(req).execute().use { resp ->
            val body = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) error("HTTP ${resp.code}: ${body.take(200)}")
            return JSONArray(body)
        }
    }

    private fun parsePriceAt(arr: JSONArray?, index: Int): Double {
        if (arr == null || index >= arr.length()) return 0.5
        val v = arr.opt(index)
        return when (v) {
            is String -> v.toDoubleOrNull() ?: 0.5
            is Number -> v.toDouble()
            else -> 0.5
        }
    }

    private fun parseIsoToMs(iso: String): Long {
        if (iso.isBlank()) return 0L
        return runCatching {
            // Polymarket 用 ISO 8601 格式如 "2024-01-15T14:30:00Z"
            val cleaned = iso.replace("Z", "+0000").replace("T", " ")
            java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ssZ").parse(cleaned)?.time ?: 0L
        }.getOrElse { 0L }
    }

    /** HMAC-SHA256 签名（用于 Polymarket L2 auth 和 Binance API 签名） */
    private fun hmacSha256(data: String, secret: String): String {
        val mac = javax.crypto.Mac.getInstance("HmacSHA256")
        val keySpec = javax.crypto.spec.SecretKeySpec(secret.toByteArray(Charsets.UTF_8), "HmacSHA256")
        mac.init(keySpec)
        val bytes = mac.doFinal(data.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }

    /** 格式化数量为 Binance 要求的精度 */
    private fun formatQuantity(value: Double): String {
        return if (value >= 1.0) "%.3f".format(value)
        else "%.6f".format(value)
    }

    companion object {
        private val JSON_MEDIA = "application/json".toMediaType()
    }
}

/** 批量查询结果 */
data class AllMarketsResult(
    val polymarketMarkets: List<MarketOdds>,
    val binancePrice: Double,
    val binanceLocalMarket: MarketOdds,
    val timestamp: Long
) {
    /** 所有可用市场（Polymarket + 本地 Binance） */
    val allMarkets: List<MarketOdds> get() = polymarketMarkets + binanceLocalMarket
}

/** Polymarket 下单请求 */
data class PolymarketOrderRequest(
    val tokenId: String,         // YES/NO outcome token ID
    val side: String,            // BUY
    val price: Double,           // 份额价格（0~1，如 0.55）
    val size: Double,            // 份额数量（= amount / price）
    val feeRateBps: Int = 0,     // 手续费率（基点）
    val nonce: Long = System.currentTimeMillis(),
    val expiration: Long = 0,   // 0 = 不过期
    val orderType: String = "GTC" // GTC / FOK / GTD
) {
    /** 下注金额（USDT）= price x size */
    val amount: Double get() = price * size
}

/** Polymarket 下单结果 */
data class PolymarketOrderResult(
    val success: Boolean,
    val orderId: String? = null,
    val status: String,
    val rawResponse: String? = null,
    val error: String? = null
)

/** Binance 下单请求 */
data class BinanceOrderRequest(
    val symbol: String = "BTCUSDT",
    val side: String,            // BUY / SELL
    val quantity: Double,        // BTC 数量
    val price: Double = 0.0,     // 限价单价格（市价单忽略）
    val orderType: String = "MARKET"  // MARKET / LIMIT
)

/** Binance 下单结果 */
data class BinanceOrderResult(
    val success: Boolean,
    val orderId: Long? = null,
    val status: String,
    val executedQty: Double = 0.0,
    val avgPrice: Double = 0.0,
    val rawResponse: String? = null,
    val error: String? = null
)
