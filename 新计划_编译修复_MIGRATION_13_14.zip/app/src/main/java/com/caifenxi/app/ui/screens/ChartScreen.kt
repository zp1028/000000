package com.caifenxi.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.caifenxi.app.domain.plan.AlgoChartPlans
import com.caifenxi.app.domain.plan.NovaPlanAnalytics
import com.caifenxi.app.domain.plan.NovaPlanPool
import com.caifenxi.app.domain.plan.PlanPool
import com.caifenxi.app.ui.MainViewModel
import com.caifenxi.app.ui.components.CaptionMuted
import com.caifenxi.app.ui.components.GlobalCard
import com.caifenxi.app.ui.components.PrimaryButton
import com.caifenxi.app.ui.theme.CaiTokens
import kotlin.math.roundToInt
import kotlinx.coroutines.delay

@Composable
fun ChartScreen(vm: MainViewModel) {
    // 筛选/选项在 PlanViewModel，切 Tab 再回来不丢失；仅弹窗详情用页面本地状态
    var chartDetail by remember { mutableStateOf<NovaPlanAnalytics.ChartPoint?>(null) }
    val planVM = vm.planVM
    var chartPeriods by planVM.chartPeriods
    var chartStakeText by planVM.chartStakeText
    var chartSelectedIds by planVM.chartSelectedIds
    var chartSource by planVM.chartSource
    var chartMode by planVM.chartMode
    var plansExpanded by planVM.chartPlansExpanded
    var playFilter by planVM.chartPlayFilter
    var autoRefresh by planVM.chartAutoRefresh
    var chartBetInvert by planVM.chartBetInvert

    val history = vm.history.value
    val custom = vm.customPlans.value.map { it.toDefinition() }.filter { it.planId.startsWith("NOVA-CUSTOM-") }
    val novaPlans = (NovaPlanPool.ALL + custom).distinctBy { it.planId }
    val sourcePlansAll = when (chartSource) {
        "原计划池" -> PlanPool.ALL
        "自定义计划" -> custom
        "经验学习" -> AlgoChartPlans.EXPERIENCE
        "形态匹配" -> AlgoChartPlans.PATTERN
        "智能融合" -> AlgoChartPlans.FUSION
        "原共识", "新共识" -> emptyList()
        else -> novaPlans
    }.distinctBy { it.planId }
    val sourcePlans = if (playFilter == "全部") {
        sourcePlansAll
    } else {
        sourcePlansAll.filter { it.playType == playFilter }
    }
    val consensusCategories = when (playFilter) {
        "大小", "单双", "组合" -> listOf(playFilter)
        else -> listOf("大小", "单双", "组合")
    }
    val consensusRecords = if (chartSource == "原共识") vm.planVM.consensusRecords.value else vm.planVM.novaConsensusRecords.value
    val reports = vm.planVM.novaChartReports.value
    val running = vm.planVM.novaChartRunning.value
    val stage = vm.planVM.novaChartStage.value

    fun runBacktest() {
        val stake = chartStakeText.toDoubleOrNull() ?: 10.0
        when (chartSource) {
            "原共识" -> vm.planVM.runConsensusChartBacktest(
                "原计划引擎共识", vm.planVM.consensusRecords.value, chartPeriods, stake, consensusCategories, chartBetInvert
            )
            "新共识" -> vm.planVM.runConsensusChartBacktest(
                "新计划池共识", vm.planVM.novaConsensusRecords.value, chartPeriods, stake, consensusCategories, chartBetInvert
            )
            else -> {
                val selected = sourcePlans.filter { it.planId in chartSelectedIds }.ifEmpty { sourcePlans.take(1) }
                val comboN = vm.prefs.value.comboPredCount.coerceIn(1, 4)
                val numN = vm.prefs.value.positionTopN.coerceIn(1, 10)
                vm.planVM.runNovaChartBacktest(history, selected, chartPeriods, stake, chartBetInvert, comboN, numN)
            }
        }
    }

    // 自动重算：防抖，避免连点参数时叠多个重任务；改参数会取消上一次图表 Job
    LaunchedEffect(autoRefresh, chartSource, chartPeriods, stage, chartSelectedIds.joinToString(), chartStakeText, playFilter, chartBetInvert) {
        if (!autoRefresh) return@LaunchedEffect
        delay(450)
        val canRun = when (chartSource) {
            "原共识", "新共识" -> consensusRecords.isNotEmpty()
            else -> history.size >= 6 && sourcePlans.isNotEmpty()
        }
        if (canRun) runBacktest()
    }

    if (chartDetail != null) {
        val pt = chartDetail!!
        AlertDialog(
            onDismissRequest = { chartDetail = null },
            confirmButton = { TextButton(onClick = { chartDetail = null }) { Text("关闭") } },
            title = { Text("回测节点详情") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("期号：${pt.issue}")
                    Text("预测：${pt.prediction}")
                    Text("方向：${if (chartBetInvert) "反投" else "正投"}")
                    Text("结果：${if (pt.hit) "对" else "错"}")
                    Text("单期盈亏：${chartFmtMoney(pt.periodProfit)}")
                    Text("累计盈亏：${chartFmtMoney(pt.cumulativeProfit)}")
                    Text("当时对错率：${"%.2f".format(pt.hitRate * 100)}%")
                    Text("相对50%：${chartFmtMoney((pt.hitRate - 0.5) * 100)} 百分点")
                    Text("回撤：${chartFmtMoney(pt.drawdown)}")
                }
            }
        )
    }

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = CaiTokens.ScreenHPadding, vertical = CaiTokens.S12),
        verticalArrangement = Arrangement.spacedBy(CaiTokens.S8),
        contentPadding = PaddingValues(bottom = CaiTokens.ScreenBottom)
    ) {
        item {
            Text("📊 图表回测", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            CaptionMuted("绿涨红跌 · 赔率计盈亏(大2.2/小1.79/单1.79/双2.2) · 组合二/三期4倍投 · 对错率50%零轴")
        }

        item {
            GlobalCard {
                Text("回测设置", fontWeight = FontWeight.Bold)
                ChartFilterLine(
                    "回测来源",
                    listOf("新计划池", "原计划池", "自定义计划", "经验学习", "形态匹配", "智能融合", "原共识", "新共识"),
                    chartSource
                ) { chartSource = it; chartSelectedIds = emptyList() }
                ChartFilterLine(
                    "图表",
                    listOf("累计收益", "单期盈亏", "对错率", "命中率", "涨跌趋势", "回撤"),
                    chartMode
                ) { chartMode = it }
                ChartFilterLine(
                    "回测",
                    listOf(100, 200, 500, 1000, 2000, 5000).map { "${it}期" },
                    "${chartPeriods}期"
                ) { chartPeriods = it.removeSuffix("期").toInt() }
                ChartFilterLine(
                    "计算口径",
                    listOf("一期", "两期", "三期"),
                    when (stage.coerceIn(1, 3)) {
                        2 -> "两期"
                        3 -> "三期"
                        else -> "一期"
                    }
                ) { v ->
                    vm.planVM.novaChartStage.value = when (v) {
                        "两期" -> 2
                        "三期" -> 3
                        else -> 1
                    }
                }
                ChartFilterLine(
                    "投注方向",
                    listOf("正投", "反投"),
                    if (chartBetInvert) "反投" else "正投"
                ) { v -> chartBetInvert = (v == "反投") }
                CaptionMuted(if (chartBetInvert) "反投：大小/单双/组合方向取反后结算" else "正投：按预测方向原样结算")
                if (chartSource in listOf("原共识", "新共识")) {
                    ChartFilterLine(
                        "共识分类",
                        listOf("全部", "大小", "单双", "组合"),
                        playFilter.let { if (it in listOf("全部", "大小", "单双", "组合")) it else "全部" }
                    ) { playFilter = it }
                    CaptionMuted("共识按分类分别回测：大小/单双/组合各一条曲线；选「全部」则三类一起对比。")
                } else if (chartSource !in listOf("经验学习", "形态匹配", "智能融合")) {
                    ChartFilterLine(
                        "玩法筛选",
                        listOf("全部", "大小", "单双", "组合", "数字", "位置"),
                        playFilter
                    ) { playFilter = it; chartSelectedIds = emptyList() }
                }

                Row(
                    Modifier.fillMaxWidth().padding(top = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("自动更新图表", fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    Switch(checked = autoRefresh, onCheckedChange = { autoRefresh = it })
                }
                CaptionMuted(if (autoRefresh) "改参数后自动重算（回测中不会重复触发）" else "改参数后需手动点「开始回测」")

                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("选择具体计划（最多5个）", fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    TextButton(onClick = { plansExpanded = !plansExpanded }) {
                        Text(if (plansExpanded) "收起 ▲" else "展开 ▼")
                    }
                }

                if (plansExpanded) {
                    TextField(
                        value = chartStakeText,
                        onValueChange = { value ->
                            chartStakeText = value.filter { c -> c.isDigit() || c == '.' }.take(10)
                        },
                        label = { Text("回测单注金额") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    if (chartSource == "原共识" || chartSource == "新共识") {
                        val byCat = listOf("大小", "单双", "组合").associateWith { cat ->
                            consensusRecords.count { it.category == cat && (it.result == "对" || it.result == "错") }
                        }
                        CaptionMuted(
                            "已结算：大小 ${byCat["大小"]} · 单双 ${byCat["单双"]} · 组合 ${byCat["组合"]}（分类独立回测）"
                        )
                    } else if (sourcePlans.isEmpty()) {
                        CaptionMuted("该来源暂无可回测计划（可换筛选或来源）")
                    }
                    sourcePlans.forEach { p ->
                        val checked = p.planId in chartSelectedIds
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clickable {
                                    chartSelectedIds = if (checked) {
                                        chartSelectedIds - p.planId
                                    } else {
                                        (chartSelectedIds + p.planId).distinct().take(5)
                                    }
                                },
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = checked,
                                onCheckedChange = { on ->
                                    chartSelectedIds = if (on) {
                                        (chartSelectedIds + p.planId).distinct().take(5)
                                    } else {
                                        chartSelectedIds - p.planId
                                    }
                                }
                            )
                            Column(Modifier.weight(1f)) {
                                Text(
                                    p.planName,
                                    fontSize = 13.sp,
                                    fontWeight = if (checked) FontWeight.Bold else FontWeight.Normal
                                )
                                CaptionMuted("${p.playType} · ${p.algorithm} · ${p.window}期")
                            }
                        }
                    }
                }

                val canRun = !running && (
                    if (chartSource == "原共识" || chartSource == "新共识") consensusRecords.isNotEmpty()
                    else history.size >= 6 && sourcePlans.isNotEmpty()
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PrimaryButton(
                        if (running) "正在回测…" else "开始回测 / 更新图表",
                        { runBacktest() },
                        Modifier.weight(1f),
                        enabled = canRun
                    )
                    OutlinedButton(
                        onClick = { vm.planVM.clearNovaChart(); chartDetail = null },
                        modifier = Modifier.weight(0.55f)
                    ) { Text("重置图表") }
                }
                if (!canRun && !running) {
                    CaptionMuted(
                        when {
                            chartSource in listOf("原共识", "新共识") && consensusRecords.isEmpty() ->
                                "暂无已结算共识，无法回测"
                            history.size < 6 -> "历史不足 6 期，无法回测"
                            sourcePlans.isEmpty() -> "无可选计划"
                            else -> ""
                        }
                    )
                }
            }
        }

        item {
            GlobalCard {
                Text("共识预测来源", fontWeight = FontWeight.Bold)
                CaptionMuted("原/新共识回测：大小、单双、组合分类分别一期一计（不再要求三类全对）。")
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    val legacyCount = vm.planVM.consensusRecords.value.count { it.result == "对" || it.result == "错" }
                    val novaCount = vm.planVM.novaConsensusRecords.value.count { it.result == "对" || it.result == "错" }
                    AssistChip(onClick = {}, label = { Text("原共识 · 已结算 $legacyCount") })
                    AssistChip(onClick = {}, label = { Text("新共识 · 已结算 $novaCount") })
                }
            }
        }

        if (reports.isEmpty()) {
            item {
                GlobalCard {
                    Text("暂无曲线", fontWeight = FontWeight.Bold)
                    CaptionMuted("请选择来源与计划后点击「开始回测」。对错率模式以 50% 为零轴，显示累计对错率起伏。")
                }
            }
        } else {
            item {
                GlobalCard {
                    Text(
                        if (reports.size == 1) "回测曲线 · $chartMode" else "计划对比曲线 · $chartMode",
                        fontWeight = FontWeight.Bold
                    )
                    CaptionMuted(
                        when (chartMode) {
                            "对错率" -> "零轴=50%对错率；曲线在上方表示优于随机，下方表示劣于随机"
                            "累计收益" -> "绿涨红跌 · 黄虚线最大回撤 · 色带连对/连错"
                            else -> "双指缩放、拖动查看细节；点击曲线查看节点"
                        }
                    )
                    ChartCurve(reports, chartMode) { chartDetail = it }
                    // 多计划图例
                    if (reports.size > 1) {
                        Spacer(Modifier.height(6.dp))
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            reports.forEachIndexed { idx, r ->
                                val c = chartSeriesColor(idx)
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Surface(color = c, modifier = Modifier.size(10.dp), shape = MaterialTheme.shapes.extraSmall) {}
                                    Spacer(Modifier.width(4.dp))
                                    Text(r.plan.planName, fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }

            item {
                GlobalCard {
                    Text("回测统计", fontWeight = FontWeight.Bold)
                    reports.forEach { r ->
                        Text(r.plan.planName, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 6.dp))
                        Text(
                            "${r.periods}期 · 对 ${r.hits} / 错 ${r.misses} · 对错率 ${(r.hitRate * 100).roundToInt()}% · 单注 ${chartFmtMoney(r.stake)}"
                        )
                        Text(
                            "最高对错率 ${(r.maxHitRate * 100).roundToInt()}% · 最低对错率 ${(r.minHitRate * 100).roundToInt()}% · 相对50% ${"%.1f".format((r.hitRate - 0.5) * 100)}pt"
                        )
                        Text(
                            "总投入 ${chartFmtMoney(r.totalStake)} · 净收益 ${chartFmtMoney(r.netProfit)} · 最大回撤 ${chartFmtMoney(r.maxDrawdown)}"
                        )
                        CaptionMuted(
                            "最高点 ${chartFmtMoney(r.maxPeak)} · 最低点 ${chartFmtMoney(r.minTrough)} · 最大连对 ${r.maxHitStreak} · 最大连错 ${r.maxMissStreak}"
                        )
                        // 分段：最近 50/100/200
                        val segs = listOf(50, 100, 200)
                        segs.forEach { n ->
                            val tail = r.points.takeLast(n)
                            if (tail.isNotEmpty()) {
                                val h = tail.count { it.hit }
                                val rate = h.toDouble() / tail.size
                                val profit = tail.sumOf { it.periodProfit }
                                CaptionMuted(
                                    "近${tail.size}期：对错率 ${(rate * 100).roundToInt()}% · 盈亏 ${chartFmtMoney(profit)}"
                                )
                            }
                        }
                    }
                }
            }

            item {
                GlobalCard {
                    Text("涨跌趋势分析", fontWeight = FontWeight.Bold)
                    reports.forEach { r ->
                        Text("${r.plan.planName}：${r.currentTrend}", fontWeight = FontWeight.SemiBold)
                        CaptionMuted(
                            "最高点 ${chartFmtMoney(r.maxPeak)} · 最低点 ${chartFmtMoney(r.minTrough)} · 当前 ${chartFmtMoney(r.points.lastOrNull()?.cumulativeProfit ?: 0.0)}"
                        )
                        CaptionMuted(
                            "距最高点 ${chartFmtMoney(r.distanceFromPeak)} · 从最低点反弹 ${chartFmtMoney(r.reboundFromTrough)} · 位置 ${"%.1f".format(r.positionPercent)}%"
                        )
                    }
                }
            }

            if (reports.size >= 2) {
                item {
                    GlobalCard {
                        Text("计划对比分析", fontWeight = FontWeight.Bold)
                        reports.sortedByDescending { it.netProfit }.forEachIndexed { idx, r ->
                            Text("${idx + 1}. ${r.plan.planName}", fontWeight = FontWeight.SemiBold)
                            Text(
                                "对错率 ${(r.hitRate * 100).roundToInt()}%（高 ${(r.maxHitRate * 100).roundToInt()}% / 低 ${(r.minHitRate * 100).roundToInt()}%） · 净收益 ${chartFmtMoney(r.netProfit)} · 回撤 ${chartFmtMoney(r.maxDrawdown)}",
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }

            item {
                GlobalCard {
                    Text("图表分析报告", fontWeight = FontWeight.Bold)
                    reports.forEach { r ->
                        val cur = r.points.lastOrNull()?.cumulativeProfit ?: 0.0
                        val dir = when {
                            r.netProfit > 0 -> "累计收益为正"
                            r.netProfit < 0 -> "累计收益为负"
                            else -> "累计收益持平"
                        }
                        val rateDir = when {
                            r.hitRate > 0.5 -> "对错率高于随机50%"
                            r.hitRate < 0.5 -> "对错率低于随机50%"
                            else -> "对错率接近随机50%"
                        }
                        Text(r.plan.planName, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 6.dp))
                        Text("整体：$dir；回测 ${r.periods} 个单元，对错率 ${(r.hitRate * 100).roundToInt()}%，$rateDir。")
                        Text(
                            "对错率区间：最高 ${(r.maxHitRate * 100).roundToInt()}% · 最低 ${(r.minHitRate * 100).roundToInt()}% · 终值 ${(r.hitRate * 100).roundToInt()}%。"
                        )
                        Text("收益：总投入 ${chartFmtMoney(r.totalStake)}，净收益 ${chartFmtMoney(r.netProfit)}，最高 ${chartFmtMoney(r.maxPeak)}，最低 ${chartFmtMoney(r.minTrough)}。")
                        Text("趋势：${r.currentTrend}；当前 ${chartFmtMoney(cur)}，最大回撤 ${chartFmtMoney(r.maxDrawdown)}。")
                        Text("风险：最大连对 ${r.maxHitStreak}，最大连错 ${r.maxMissStreak}。")
                    }
                }
            }

            item {
                GlobalCard {
                    Text("完整回测明细", fontWeight = FontWeight.Bold)
                    CaptionMuted("按计划/分类分开展示；玩法列显示大小·单双·组合等，避免误读成全部是大小")
                    reports.forEach { r ->
                        val play = r.plan.playType.ifBlank { "—" }
                        val dir = if (chartBetInvert) "反投" else "正投"
                        Text(
                            "${r.plan.planName} · $play · $dir",
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(top = 6.dp)
                        )
                        // 限制条数 + key，减轻滑动卡顿
                        r.points.asReversed().take(40).forEach { pt ->
                            Row(
                                Modifier.fillMaxWidth().padding(vertical = 2.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    "${pt.issue} · [$play] ${pt.prediction} · ${if (pt.hit) "对" else "错"} · ${(pt.hitRate * 100).roundToInt()}%",
                                    fontSize = 11.sp,
                                    modifier = Modifier.weight(1f)
                                )
                                Text(chartFmtMoney(pt.periodProfit), fontSize = 11.sp, modifier = Modifier.width(70.dp))
                                Text(chartFmtMoney(pt.cumulativeProfit), fontSize = 11.sp, modifier = Modifier.width(80.dp))
                            }
                        }
                        if (r.points.size > 40) CaptionMuted("仅显示最近 40 条，共 ${r.points.size} 条 · $play")
                    }
                }
            }
        }
    }
}
