package com.caifenxi.app.domain.btc.backtest

import com.caifenxi.app.domain.btc.BtcDirection

enum class BacktestEntryMode { NEXT_BAR_OPEN, SAME_BAR_CLOSE }

enum class BacktestRange(val days: Int, val label: String) {
    ONE(1, "1天"), THREE(3, "3天"), SEVEN(7, "7天"), FOURTEEN(14, "14天"),
    THIRTY(30, "30天"), SIXTY(60, "60天"), NINETY(90, "90天"), CUSTOM(0, "自定义")
}

data class BacktestConfig(
    val range: BacktestRange = BacktestRange.THIRTY,
    val customStartTimeMs: Long? = null,
    val customEndTimeMs: Long? = null,
    val initialEquity: Double = 10_000.0,
    val riskPerTradePct: Double = 0.50,
    val feeRatePct: Double = 0.04,
    val makerFeeRatePct: Double = 0.02,
    val useMakerFee: Boolean = false,
    val slippagePct: Double = 0.02,
    val fundingPer8hPct: Double = 0.01,
    val barsPerFunding: Int = 32,
    val maxHoldingBars: Int = 12,
    val walkForwardTrainBars: Int = 300,
    val walkForwardTestBars: Int = 100,
    val spreadPct: Double = 0.01,
    val latencyBars: Int = 0,
    val entryMode: BacktestEntryMode = BacktestEntryMode.NEXT_BAR_OPEN,
    val maxNotionalPct: Double = 100.0,
    val partialFillRatio: Double = 1.0,
    /** Freqtrade-style protection: block new entries after a losing trade. */
    val cooldownBarsAfterLoss: Int = 0,
    /** Stop the run for the remainder of the current UTC day after this loss. */
    val maxDailyLossPct: Double = 0.0,
    /** Global portfolio drawdown protection. 0 disables the protection. */
    val maxDrawdownPct: Double = 0.0,
    val maxConsecutiveLosses: Int = 0,
    val allowLong: Boolean = true,
    val allowShort: Boolean = true
)

data class MonteCarloSummary(
    val runs: Int,
    val medianReturnPct: Double,
    val p05ReturnPct: Double,
    val p95ReturnPct: Double,
    val medianMaxDrawdownPct: Double,
    val probabilityOfLossPct: Double
)

data class BacktestTrade(
    val barId: Long,
    val direction: BtcDirection,
    val entry: Double,
    val exit: Double,
    val stopLoss: Double,
    val takeProfit: Double,
    val pnlPct: Double,
    val pnlCash: Double,
    val holdingBars: Int,
    val mfePct: Double,
    val maePct: Double,
    val reason: String,
    val feePct: Double = 0.0,
    val fundingPct: Double = 0.0,
    val slippagePct: Double = 0.0,
    val notional: Double = 0.0,
    val entryBarId: Long = barId,
    val exitBarId: Long = barId
)

data class BacktestResult(
    val planId: String,
    val trades: List<BacktestTrade>,
    val equityCurve: List<Double>,
    val totalReturnPct: Double,
    val winRatePct: Double,
    val profitFactor: Double,
    val maxDrawdownPct: Double,
    val averagePnlPct: Double,
    val averageHoldingBars: Double,
    val averageMfePct: Double,
    val averageMaePct: Double,
    val sampleSize: Int,
    val inSample: Boolean = false,
    val totalFundingPct: Double = 0.0,
    val totalFeePct: Double = 0.0,
    val sharpe: Double = 0.0,
    val sortino: Double = 0.0,
    val calmar: Double = 0.0,
    val expectancyCash: Double = 0.0,
    val payoffRatio: Double = 0.0,
    val protectionBlocks: Int = 0,
    val exposureBarPct: Double = 0.0,
    val maxConsecutiveLosses: Int = 0
)

data class PlanAttribution(
    val planId: String,
    val trades: Int,
    val netReturnPct: Double,
    val fundingDragPct: Double,
    val feeDragPct: Double,
    val profitFactor: Double,
    val maxDrawdownPct: Double
)

data class BacktestOptimizationResult(
    val config: BacktestConfig,
    val result: BacktestResult,
    val objectiveScore: Double
)
