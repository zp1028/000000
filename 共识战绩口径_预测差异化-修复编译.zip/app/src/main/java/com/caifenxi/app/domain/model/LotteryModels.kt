package com.caifenxi.app.domain.model

import kotlinx.serialization.Serializable

/**
 * 彩种类型（与原 JS adapters 对齐）
 */
enum class LotteryType {
    /** PK拾 / 飞艇 / 赛车：10 个位置，号码 1-10 */
    PKS,
    /** 快乐8 / 幸运20：20 个号码，范围 1-80 */
    LUCK20
}

/**
 * 彩种配置（对应原 LOTTERY_CATALOG）
 */
@Serializable
data class LotteryConfig(
    val key: String,          // API code，如 "10037"
    val name: String,         // 显示名
    val type: LotteryType,
    val code: Int,
    /** 开奖间隔(毫秒),用于倒计时估算;极速类约 75s,常规类更长 */
    val periodMs: Long = 75_000L
) {
    companion object {
        val CATALOG = listOf(
            LotteryConfig("10001", "北京PK10", LotteryType.PKS, 10001, 20 * 60_000L),
            LotteryConfig("10012", "澳洲幸运10", LotteryType.PKS, 10012, 5 * 60_000L),
            LotteryConfig("10035", "极速飞艇", LotteryType.PKS, 10035, 75_000L),
            LotteryConfig("10037", "极速赛车", LotteryType.PKS, 10037, 75_000L),
            LotteryConfig("10057", "幸运飞艇", LotteryType.PKS, 10057, 5 * 60_000L),
            LotteryConfig("10058", "SG飞艇", LotteryType.PKS, 10058, 5 * 60_000L),
            LotteryConfig("10013", "澳洲幸运20", LotteryType.LUCK20, 10013, 5 * 60_000L),
            LotteryConfig("10014", "北京快乐8", LotteryType.LUCK20, 10014, 5 * 60_000L),
            LotteryConfig("10047", "台湾宾果", LotteryType.LUCK20, 10047, 5 * 60_000L),
            LotteryConfig("10054", "极速快乐8", LotteryType.LUCK20, 10054, 75_000L),
        )

        fun findByKey(key: String): LotteryConfig? = CATALOG.find { it.key == key }
    }
}

/**
 * 单期开奖记录（统一模型，兼容 PKS 与 LUCK20）
 */
@Serializable
data class DrawRecord(
    val lotteryKey: String,       // 彩种 key
    val issue: String,            // 期号
    val drawTime: String,         // 开奖时间原文
    val numbers: List<Int>,       // 开奖号码列表
    val sum: Int? = null,         // 和值（LUCK20 常用）
    val dx: String? = null,       // 大小："大" / "小"
    val ds: String? = null,       // 单双："单" / "双"
    val combo: String? = null,    // 组合："大单" 等
    val extra: Int? = null,       // 附加号（若有）
    val nextIssue: String? = null // 下期期号（API 有时会给）
) {
    /** 位置名（PKS 用） */
    fun positionName(index: Int): String = when (index) {
        0 -> "冠军"
        1 -> "亚军"
        else -> "第${index + 1}"
    }

    fun numberAt(index: Int): Int? = numbers.getOrNull(index)
}

/**
 * 大小 / 单双 方向
 */
enum class Direction(val label: String) {
    BIG("大"),
    SMALL("小"),
    ODD("单"),
    EVEN("双");

    companion object {
        fun fromDx(s: String?): Direction? = when (s) {
            "大" -> BIG
            "小" -> SMALL
            else -> null
        }
        fun fromDs(s: String?): Direction? = when (s) {
            "单" -> ODD
            "双" -> EVEN
            else -> null
        }
    }
}

/**
 * 预测类别
 */
enum class PredictCategory {
    DX,      // 大小
    DS,      // 单双
    COMBO,   // 组合（大小+单双）
    ZONE,    // 区间
    NUMBER,  // 号码
    POSITION,// 位置（PKS）
    STRUCT   // 结构
}

/**
 * 单次预测结果（方向类）
 */
@Serializable
data class DirectionPrediction(
    val category: PredictCategory,
    val direction: String,          // "大"/"小"/"单"/"双"/"大单" 等
    val score: Double = 0.0,        // 模型支持度 / 相对评分（非真实概率）
    val algo: String = "",          // 算法名
    val detail: String = ""
)

/**
 * 号码评分预测（热力图用）
 */
@Serializable
data class NumberScore(
    val number: Int,
    val score: Double,
    val rank: Int = 0
)

/**
 * 位置预测（每个位置 TopN 号码）
 */
@Serializable
data class PositionPrediction(
    val positionIndex: Int,
    val positionName: String,
    val topNumbers: List<NumberScore>,
    val algo: String = "",
    val detail: String = ""
)

/**
 * 一轮完整预测快照（对应一期，可冻结）
 */
@Serializable
data class PredictionSnapshot(
    val lotteryKey: String,
    val targetIssue: String,        // 预测的目标期号
    val cutoffIssue: String,        // 截止已开奖期号
    val createdAt: Long,
    val frozen: Boolean = false,
    val dx: DirectionPrediction? = null,
    val ds: DirectionPrediction? = null,
    val combo: DirectionPrediction? = null,
    /** 组合预测多候选（按支持度排序） */
    val comboList: List<DirectionPrediction> = emptyList(),
    val numberScores: List<NumberScore> = emptyList(),
    val positions: List<PositionPrediction> = emptyList(),
    /** 用户选择的算法（实验室最优/多算法对比等，用于界面展示） */
    val algoTag: String = "experience",
    /** 实际选用的底层算法（实验室最优会动态挑选 experience/pattern/fusion） */
    val resolvedAlgo: String = ""
)

/**
 * 用户偏好（对应原 UserPrefs）
 */
@Serializable
data class UserPrefs(
    val predictionWindow: Int = 100,
    val positionTopN: Int = 3,
    val zuheTopN: Int = 3,
    /** 组合预测输出条数(同步到首页组合候选与共识组合) */
    val comboPredCount: Int = 3,
    /** 计划池默认容量(未手动勾选时取模板前 N 条) */
    val planPoolCount: Int = 12,
    /**
     * 共识/回测使用的计划池 ID 列表。
     * 空 = 使用模板池前 planPoolCount 条 + 全部自定义计划(不再每期随机)。
     */
    val selectedPlanIds: List<String> = emptyList(),
    val ewmaEnabled: Boolean = true,
    val ewmaAlpha: Float = 0.25f,
    val ewmaWeightTemperature: Float = 0.08f,
    val trendBoostEnabled: Boolean = true,
    val sensitivityMode: String = "balanced", // simple / balanced / pro
    val momentumStrength: Float = 0.5f,
    val antiHerdStrength: Float = 0.3f,
    val streakDecayEnabled: Boolean = true,
    val autoRefresh: Boolean = true,
    val darkMode: Boolean = false,
    val themeMode: String = "system", // system | light | dark
    val predFreeze: Boolean = true,
    val selectedLotteryKey: String = "10037",
    val aiApiKey: String = "",
    val currentAlgo: String = "experience",
    /** 驾驶舱精确指定的计划ID；为空时使用当前算法/计划池。 */
    val cockpitPlanId: String = "",
    /** 上次非空驾驶舱计划，切算法后可恢复 */
    val lastCockpitPlanId: String = "",
    /** 驾驶舱指定计划的执行周期：1/2/3…期。 */
    val cockpitPlanCyclePeriods: Int = 1,
    /** 悬浮窗：只读显示统一预测快照。source=consensus / plan / algo */
    val floatingEnabled: Boolean = false,
    val floatingSource: String = "consensus",
    /** 悬浮窗指定计划：大小与单双分别选择，兼容旧版 floatingPlanId */
    val floatingPlanId: String = "",
    val floatingDxPlanId: String = "",
    val floatingDsPlanId: String = "",
    val floatingOpacity: Float = 0.92f,
    val floatingTextSize: Float = 13f,
    val floatingX: Int = 18,
    val floatingY: Int = 120,
    val floatingDraggable: Boolean = true,
    /** 悬浮窗显示模式：full / mini / hidden */
    val floatingMode: String = "full",
    /** 半隐身图标透明度 */
    val floatingMiniOpacity: Float = 0.42f,
    /** 半隐身图标大小 dp */
    val floatingMiniSize: Int = 42,
    /** 展开后无操作自动缩小秒数，0=不自动缩小 */
    val floatingAutoCollapseSeconds: Int = 5,
    /** 松手后自动吸附左右边缘 */
    val floatingEdgeSnap: Boolean = true,
    /**
     * 真实自动点击（无障碍）：在第三方页面自动点「大/小/单/双」。
     * 需用户在系统设置中开启「彩析自动点击」无障碍服务。
     */
    val autoClickEnabled: Boolean = false,
    /** 是否自动点击大小 */
    val autoClickDx: Boolean = true,
    /** 是否自动点击单双 */
    val autoClickDs: Boolean = true,
    /**
     * 无障碍投注方向：正投 / 反投。
     * - forward（正投）：按预测原文点击（大→大、单→单、大单→大单）
     * - reverse（反投）：按预测取反点击（大→小、单→双、大单→小双）
     */
    val autoClickBetMode: String = "forward",
    /** 大小与单双两次点击间隔（毫秒） */
    val autoClickDelayMs: Long = 400L,
    /** 无障碍控制悬浮窗（第三方页面点「开始」触发识别点击） */
    val autoClickPanelEnabled: Boolean = false,
    val autoClickPanelX: Int = 18,
    val autoClickPanelY: Int = 360,
    /**
     * 点击区域限制（相对屏幕比例 0f～1f）。
     * 开启后只点击中心点落在该矩形内的节点，避免全屏乱点。
     */
    val autoClickRegionEnabled: Boolean = false,
    val autoClickRegionLeft: Float = 0f,
    val autoClickRegionTop: Float = 0f,
    val autoClickRegionRight: Float = 1f,
    val autoClickRegionBottom: Float = 1f,
    /** 点击时在屏幕上显示红点反馈 */
    val autoClickShowFeedback: Boolean = true,

    /**
     * 数字键盘区域（相对屏幕 0～1 归一化坐标）。
     * 点击大小单双后，只在此矩形内识别并逐位点击 0-9 / 小数点按钮。
     */
    val autoInputRegionEnabled: Boolean = false,
    val autoInputRegionLeft: Float = 0f,
    val autoInputRegionTop: Float = 0f,
    val autoInputRegionRight: Float = 1f,
    val autoInputRegionBottom: Float = 1f,
    /** 框选时记录的屏幕宽高，便于分辨率变化时提示 */
    val autoInputRegionScreenW: Int = 0,
    val autoInputRegionScreenH: Int = 0,
    val autoClickRegionScreenW: Int = 0,
    val autoClickRegionScreenH: Int = 0,

    /**
     * 自动点击数字（复原 / 倍投）
     * 上一期对 → 复原数字；上一期错 → 倍投数字；追投最多 1 期，之后无论对错恢复复原数字。
     * 金额在第三方页面数字键盘上逐位点击，不依赖无障碍文本输入。
     */
    val autoInputEnabled: Boolean = false,
    /** 复原数字（上期对 / 未知 / 追投结束后使用） */
    val autoInputBaseAmount: Double = 10.0,
    /** 倍投数字（上期错且本轮尚未追投时使用） */
    val autoInputMultAmount: Double = 20.0,
    /** 追投最多次数，固定为 1 */
    val autoInputChaseMax: Int = 1,

    /** 执行顺序开关 */
    val autoExecClickDxDs: Boolean = true,
    /** 识别数字键盘区域 */
    val autoExecFindInput: Boolean = true,
    /** 逐位点击数字 */
    val autoExecTypeAmount: Boolean = true,
    val autoExecVerifyInput: Boolean = true,

    /**
     * 后续可编排动作 JSON（组合 / 预测数字 / 自定义文案）。
     * 顺序即执行顺序；大小单双与倍投数字固定在前，不受此列表影响。
     */
    val autoClickPostActionsJson: String = "[]",
    /** 连续失败多少次后自动暂停真实点击（0=不限制） */
    val autoClickFailStopCount: Int = 3,
    /** 点数字前是否尝试点删除/清除（默认关） */
    val autoClickClearBeforeDigits: Boolean = false,
    /** 仅模拟：强制不发起真实点击 */
    val autoClickSimulateOnly: Boolean = false,
    /**
     * 无障碍点击预测来源跟随挂机 Bot 配置（驾驶舱/共识/新计划共识/指定计划等）。
     * 开启后不再单独用悬浮窗 floatingSource，与挂机页选择保持一致。
     */
    val autoClickFollowBetSource: Boolean = true,

    /** 回测评分权重(可配置) */
    val backtestParams: BacktestParams = BacktestParams()
)

/**
 * API 配置
 */
object ApiConfig {
    const val PRIMARY_BASE = "https://api.api68.com"
    const val ALT_BASE = "https://api.api16868.com"
    const val TIMEOUT_MS = 10_000L
    const val RETRIES = 2
    const val DEFAULT_HISTORY_DAYS = 7
    /**
     * 预测/分析使用的工作窗口期数。
     * 本地可累积数千期,全量加载会超时显示「缓存 N 条同步失败」。
     * 超出部分仍保存在数据库,仅不参与当次计算。
     */
    const val WORKING_HISTORY_LIMIT = 1500
}
