package com.caifenxi.app.data.db.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.caifenxi.app.data.db.entity.BetEntity
import com.caifenxi.app.data.db.entity.BotConfigEntity
import com.caifenxi.app.data.db.entity.WalletEntity

@Dao
interface BetDao {

    // ---- 挂机策略 ----
    @Query("SELECT * FROM bot_config WHERE lotteryKey = :key")
    suspend fun getBotConfig(key: String): BotConfigEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertBotConfig(config: BotConfigEntity)

    // ---- 钱包 ----
    @Query("SELECT * FROM wallet WHERE lotteryKey = :key")
    suspend fun getWallet(key: String): WalletEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertWallet(wallet: WalletEntity)

    // ---- 下注订单 ----
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBet(bet: BetEntity)

    @Query("SELECT * FROM bets WHERE lotteryKey = :key ORDER BY createdAt DESC")
    suspend fun getBets(key: String): List<BetEntity>

    @Query("SELECT * FROM bets WHERE lotteryKey = :key AND issue = :issue AND status = '待开'")
    suspend fun getPendingBets(key: String, issue: String): List<BetEntity>

    @Query("SELECT * FROM bets WHERE lotteryKey = :key AND issue < :issue AND status = '待开'")
    suspend fun getPendingBefore(key: String, issue: String): List<BetEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun updateBets(bets: List<BetEntity>)

    @Query("DELETE FROM bets WHERE lotteryKey = :key")
    suspend fun clearBets(key: String)
}
