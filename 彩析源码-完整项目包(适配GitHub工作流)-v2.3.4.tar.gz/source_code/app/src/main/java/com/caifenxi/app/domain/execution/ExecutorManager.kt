package com.caifenxi.app.domain.execution

import com.caifenxi.app.util.RuntimeLog

/**
 * 执行器统一管理器。
 *
 * 支持两种执行方式：
 *  - webview（内置网页执行器）
 *  - accessibility（原无障碍执行器）
 *
 * 预测/计划/倍投/一期二期三期逻辑完全不在此处；
 * 只负责把 BetCommand 交给合适的 Executor，并统一回收 ExecutionResult。
 */
object ExecutorManager {

    private val executors = LinkedHashMap<String, Executor>()

    @Volatile
    private var mode: String = "auto"

    /** 注册执行器（App 启动时调用） */
    fun register(executor: Executor) {
        if (executor.id.isBlank()) return
        executors[executor.id] = executor
        RuntimeLog.info("Execution", "注册执行器 ${executor.id}")
    }

    /** 注销执行器（服务销毁时调用） */
    fun unregister(executorId: String) {
        if (executors.remove(executorId) != null) {
            RuntimeLog.info("Execution", "注销执行器 $executorId")
        }
    }

    fun setMode(newMode: String) {
        mode = newMode
    }

    fun getMode(): String = mode

    /** 自动选择可用执行器 */
    fun pick(): Executor? {
        when (mode) {
            "webview" -> return executors["webview"]?.takeIf { it.isAvailable }
            "accessibility" -> return executors["accessibility"]?.takeIf { it.isAvailable }
        }
        // auto：优先内置网页，其次无障碍
        executors["webview"]?.takeIf { it.isAvailable }?.let { return it }
        return executors["accessibility"]?.takeIf { it.isAvailable }
    }

    fun pickOrNull(): Executor? = pick()

    /**
     * 执行统一指令。
     * @return true 表示已受理；false 表示当前没有可用执行器（任务保持 WAITING_EXECUTOR）。
     */
    fun execute(command: BetCommand, onResult: (ExecutionResult) -> Unit): Boolean {
        val executor = pick() ?: run {
            RuntimeLog.warn("Execution", "无可用执行器 cmdId=${command.cmdId}，任务挂起等待")
            return false
        }
        RuntimeLog.info(
            "Execution",
            "分配执行器 ${executor.id} cmdId=${command.cmdId} 彩种=${command.lotteryKey} 期号=${command.issue}"
        )
        return executor.execute(command) { result ->
            RuntimeLog.info(
                "Execution",
                "执行器 ${executor.id} 返回 cmdId=${result.cmdId} success=${result.success} ${result.message}"
            )
            onResult(result)
        }
    }

    fun isAvailable(executorId: String): Boolean =
        executors[executorId]?.isAvailable == true

    fun availableExecutorIds(): List<String> = executors.values.filter { it.isAvailable }.map { it.id }

    fun queryState(cmdId: String): ExecutionResult? {
        for (e in executors.values) {
            e.queryState(cmdId)?.let { return it }
        }
        return null
    }

    fun cancel(cmdId: String) {
        executors.values.forEach { it.cancel(cmdId) }
    }

    fun clear() {
        executors.clear()
    }
}
