package com.caifenxi.app.domain.btc.plan

import kotlin.math.ln

/** Outcome-based calibration metrics for research/backtest reports. */
object BtcProbabilityMetrics {
    data class Report(val samples: Int, val brierScore: Double, val logLoss: Double, val calibrationError: Double)

    fun evaluate(samples: List<Pair<Double, Boolean>>, bins: Int = 10): Report {
        if (samples.isEmpty()) return Report(0, 0.0, 0.0, 0.0)
        val brier = samples.map { (p, y) ->
            val target = if (y) 1.0 else 0.0
            (p.coerceIn(1e-6, 1 - 1e-6) - target) * (p.coerceIn(1e-6, 1 - 1e-6) - target)
        }.average()
        val logLoss = samples.map { (p, y) ->
            val q = p.coerceIn(1e-6, 1 - 1e-6)
            if (y) -ln(q) else -ln(1 - q)
        }.average()
        val ece = (0 until bins).mapNotNull { b ->
            val low = b.toDouble() / bins
            val high = (b + 1).toDouble() / bins
            val bucket = samples.filter { (p, _) -> p >= low && (p < high || b == bins - 1) }
            if (bucket.isEmpty()) null else {
                val avgP = bucket.map { it.first }.average()
                val avgY = bucket.count { it.second }.toDouble() / bucket.size
                bucket.size.toDouble() / samples.size * kotlin.math.abs(avgP - avgY)
            }
        }.sum()
        return Report(samples.size, brier, logLoss, ece)
    }
}
