package com.caifenxi.app.domain.plan

import com.caifenxi.app.domain.model.PlanDefinition

/** PK10/飞艇/赛车 Nova 核心计划池：每个玩法、每个名次位置独立 30 计划。 */
object NovaPlanPool {
    const val VERSION = PlanPoolV2.VERSION
    val ALL: List<PlanDefinition> get() = PlanPoolV2.all(com.caifenxi.app.domain.model.LotteryType.PKS)
    val CANDIDATES: List<PlanDefinition> get() = PlanPoolV2.candidates(com.caifenxi.app.domain.model.LotteryType.PKS)
    val GROUPS: List<String> = listOf("冠亚和", "名次大小", "名次单双", "定位号码", "组合")
    val PLAY_TYPES: List<String> = listOf("大小", "单双", "组合", "名次大小", "名次单双", "位置")
    val CYCLE_OPTIONS: List<Int> = listOf(1, 2, 3, 5, 10, 20)
    fun meta(plan: PlanDefinition): Meta = Meta(plan.playType, plan.positionIndex, positionLabel(plan.positionIndex))
    data class Meta(val playType: String, val positionIndex: Int = -1, val positionLabel: String = "")
    fun find(planId: String): PlanDefinition? = PlanPoolV2.find(planId)
    private fun positionLabel(i: Int) = when (i) { 0 -> "冠军"; 1 -> "亚军"; in 2..9 -> "第${i+1}"; else -> "" }
}
