package com.caifenxi.app.domain.btc.runtime

import kotlin.math.abs

/** Converts factor health statistics into a bounded runtime trust score. */
object FactorQualityEngine {
    data class Input(val missingRate: Double, val outlierRate: Double, val stability: Double, val distributionShift: Double, val ic: Double, val icir: Double)
    data class Output(val quality: FactorQuality, val multiplier: Double, val status: Status)
    enum class Status { DISABLED, DEGRADED, NORMAL, STRONG }

    fun evaluate(x: Input): Output {
        val icQuality = (abs(x.ic) / 0.05).coerceIn(0.0, 1.0)
        val q = FactorQuality(x.missingRate, x.outlierRate, x.stability, x.distributionShift, x.icir)
        val score = (q.score * 0.75 + icQuality * 0.25).coerceIn(0.0, 1.0)
        val normalized = q.copy(stability = score)
        val m = when { score < .30 -> 0.0; score < .50 -> .5; score < .70 -> .8; else -> 1.0 }
        val status = when { m == 0.0 -> Status.DISABLED; m < 1.0 -> Status.DEGRADED; score >= .82 -> Status.STRONG; else -> Status.NORMAL }
        return Output(normalized, m, status)
    }
}
