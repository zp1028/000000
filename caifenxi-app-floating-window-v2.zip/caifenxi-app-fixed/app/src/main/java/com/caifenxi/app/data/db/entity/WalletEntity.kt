package com.caifenxi.app.data.db.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

/**
 * 虚拟账户(每彩种一条)。
 */
@Entity(tableName = "wallet")
@Serializable
data class WalletEntity(
    @PrimaryKey val lotteryKey: String,
    val initialBalance: Double = 10000.0,   // 初始资金(可自定义)
    val balance: Double = 10000.0,          // 当前余额
    val totalProfit: Double = 0.0,          // 累计盈亏
    val totalBet: Double = 0.0,             // 累计投注本金
    val winCount: Int = 0,
    val loseCount: Int = 0,
    val updatedAt: Long = System.currentTimeMillis()
)
