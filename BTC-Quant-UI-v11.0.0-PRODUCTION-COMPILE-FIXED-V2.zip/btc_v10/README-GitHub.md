# BTC Quant GitHub 构建指南

## 环境
- JDK 17
- Android SDK 35 / Build Tools 35.0.0
- Gradle 8.9
- minSdk 24

## Debug
GitHub Actions → **BTC Quant Build APK**。工作流通过 `gradle/actions/setup-gradle@v4` 提供 Gradle 8.9，然后执行 `assembleDebug`。

## Release
GitHub Actions → **BTC Quant Release APK**。配置签名 Secrets 后可生成签名 APK；未配置签名密钥时生成 unsigned release artifact。

## 数据
运行时不会使用截图中的固定账户数字。没有真实 API/CLOB/Oracle 数据时会明确显示 PAPER/OFFLINE/UNAVAILABLE。
