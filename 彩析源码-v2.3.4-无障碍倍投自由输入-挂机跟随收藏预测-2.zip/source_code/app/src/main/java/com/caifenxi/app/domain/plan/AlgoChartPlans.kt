package com.caifenxi.app.domain.plan

import com.caifenxi.app.domain.model.PlanDefinition
import com.caifenxi.app.domain.model.PlanHitCriteria
import com.caifenxi.app.domain.model.PlanOutputFormat

/**
 * 图表页专用：经验学习 / 形态匹配模型（与预测引擎 AlgoMode 对齐）。
 * 作为回测来源可选计划，不进入 Nova 计划池。
 */
object AlgoChartPlans {

    private fun plan(
        id: String,
        name: String,
        algo: String,
        playType: String,
        baseline: Double
    ): PlanDefinition = PlanDefinition(
        planId = id,
        planName = name,
        category = "算法模型",
        algorithm = algo,
        window = 100,
        cyclePeriods = 1,
        playType = playType,
        positionIndex = -1,
        outputFormat = PlanOutputFormat.DIRECTION,
        hitCriteria = PlanHitCriteria.DIRECTION_MATCH,
        baselineValue = baseline,
        participateConsensus = false,
        participateCombo = playType == "组合"
    )

    val EXPERIENCE: List<PlanDefinition> = listOf(
        plan("ALGO-EXP-DX", "经验学习·大小", "EXPERIENCE", "大小", 0.50),
        plan("ALGO-EXP-DS", "经验学习·单双", "EXPERIENCE", "单双", 0.50),
        plan("ALGO-EXP-COMBO", "经验学习·组合", "EXPERIENCE", "组合", 0.25)
    )

    val PATTERN: List<PlanDefinition> = listOf(
        plan("ALGO-PAT-DX", "形态匹配·大小", "PATTERN", "大小", 0.50),
        plan("ALGO-PAT-DS", "形态匹配·单双", "PATTERN", "单双", 0.50),
        plan("ALGO-PAT-COMBO", "形态匹配·组合", "PATTERN", "组合", 0.25)
    )

    val FUSION: List<PlanDefinition> = listOf(
        plan("ALGO-FUS-DX", "智能融合·大小", "FUSION", "大小", 0.50),
        plan("ALGO-FUS-DS", "智能融合·单双", "FUSION", "单双", 0.50),
        plan("ALGO-FUS-COMBO", "智能融合·组合", "FUSION", "组合", 0.25)
    )
}
