package com.caifenxi.app.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import com.caifenxi.app.domain.plan.PlanPool
import com.caifenxi.app.ui.MainViewModel
import com.caifenxi.app.ui.components.CaptionMuted
import com.caifenxi.app.ui.components.GlobalCard
import com.caifenxi.app.ui.components.PrimaryButton
import com.caifenxi.app.ui.components.SectionTitle
import com.caifenxi.app.ui.theme.CaiTokens
import kotlin.math.roundToInt

@Composable
fun LabScreen(vm: MainViewModel) {
    val lab = vm.labRows.value
    val plans = vm.planRows.value
    val selectedIds = vm.prefs.value.selectedPlanIds.toSet()
    var expandedId by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        Modifier
            .fillMaxSize()
            .padding(horizontal = CaiTokens.ScreenHPadding, vertical = CaiTokens.S16)
            .padding(bottom = CaiTokens.ScreenBottom)
    ) {
        item {
            Text("模型实验室", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            CaptionMuted("滚动验证 · 点开计划可看历史战绩与当期预测 · 可加入共识计划池")
            Spacer(Modifier.height(CaiTokens.S8))
            PrimaryButton(
                if (vm.backtestRunning.value) "验证中…" else "重新滚动验证",
                onClick = { vm.runBacktest() },
                enabled = !vm.backtestRunning.value,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(CaiTokens.S12))
            SectionTitle("算法排行（大小/单双）")
        }
        if (lab.isEmpty()) {
            item { GlobalCard { Text("数据不足或未回测。请先首页加载，再点重新验证。") } }
        } else {
            items(lab, key = { it.name + it.algo + it.window }) { row ->
                GlobalCard {
                    Text(row.name, fontWeight = FontWeight.Bold)
                    CaptionMuted(
                        "${row.algo} · 窗${row.window} · n=${row.sample} · 命中${row.hits} · " +
                            "率${(row.hitRate * 100).roundToInt()}% · 分${"%.1f".format(row.score)}"
                    )
                    if (row.sample > 0) {
                        LinearProgressIndicator(
                            progress = { row.hitRate.toFloat().coerceIn(0f, 1f) },
                            modifier = Modifier.fillMaxWidth().padding(top = CaiTokens.S4),
                            color = MaterialTheme.colorScheme.secondary
                        )
                    }
                }
            }
        }
        item {
            Spacer(Modifier.height(CaiTokens.S16))
            SectionTitle("完整计划池（点开看战绩/当期）")
            CaptionMuted("点「加入池」后参与共识与回测；池内计划可在计划页移除。")
        }
        items(PlanPool.ALL, key = { it.planId }) { def ->
            val rt = plans.find { it.first.planId == def.planId }?.second
            val expanded = expandedId == def.planId
            val inPool = selectedIds.isEmpty() || def.planId in selectedIds
            GlobalCard(onClick = {
                expandedId = if (expanded) null else def.planId
                if (expandedId == def.planId) vm.loadPlanDetail(def.planId)
            }) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(Modifier.weight(1f)) {
                        Text(def.planName, fontWeight = FontWeight.Bold)
                        CaptionMuted("${def.category} · ${def.algorithm} · 窗${def.window}")
                        val cur = rt?.lastPrediction
                        if (!cur.isNullOrBlank()) {
                            Text(
                                "当期：${cur}" + (rt?.lastTargetIssue?.let { " → 第${it}期" } ?: ""),
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.secondary
                            )
                        }
                    }
                    Column {
                        Text(
                            rt?.hitRatePercent ?: "-",
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.secondary
                        )
                        CaptionMuted(if (expanded) "收起" else "详情")
                    }
                }
                if ((rt?.sampleCount ?: 0) > 0) {
                    LinearProgressIndicator(
                        progress = { (rt?.hitRate ?: 0.0).toFloat().coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth().padding(top = CaiTokens.S4),
                        color = MaterialTheme.colorScheme.secondary
                    )
                }
                Row(
                    Modifier.fillMaxWidth().padding(top = CaiTokens.S8),
                    horizontalArrangement = Arrangement.spacedBy(CaiTokens.S8)
                ) {
                    FilterChip(
                        selected = inPool && selectedIds.isNotEmpty(),
                        onClick = {
                            if (def.planId in selectedIds) {
                                vm.removePlanFromPool(def.planId)
                            } else {
                                vm.addPlanToPool(def.planId)
                            }
                        },
                        label = {
                            Text(
                                when {
                                    selectedIds.isEmpty() -> "默认在池"
                                    def.planId in selectedIds -> "移出池"
                                    else -> "加入池"
                                }
                            )
                        }
                    )
                }
                AnimatedVisibility(visible = expanded) {
                    Column(Modifier.padding(top = CaiTokens.S12)) {
                        CaptionMuted("对 ${rt?.hitCount ?: 0}/${rt?.sampleCount ?: 0}")
                        Text("历史战绩", fontWeight = FontWeight.SemiBold)
                        val hist = vm.planVM.selectedPlanHistory.value
                            .filter { it.planId == def.planId }
                        if (hist.isEmpty()) {
                            CaptionMuted("尚无已结算记录，请先回测")
                        } else {
                            hist.take(20).forEach { rec ->
                                val tag = when (rec.hit) {
                                    true -> "对"
                                    false -> "错"
                                    null -> "—"
                                }
                                val color = when (rec.hit) {
                                    true -> Color(0xFF2E7D32)
                                    false -> Color(0xFFC62828)
                                    null -> MaterialTheme.colorScheme.onSurfaceVariant
                                }
                                Row(
                                    Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("第${rec.targetIssue}期 「${rec.output}」")
                                    Text(tag, fontWeight = FontWeight.Bold, color = color)
                                }
                            }
                        }
                    }
                }
            }
        }
        item { Spacer(Modifier.height(CaiTokens.S24)) }
    }
}
