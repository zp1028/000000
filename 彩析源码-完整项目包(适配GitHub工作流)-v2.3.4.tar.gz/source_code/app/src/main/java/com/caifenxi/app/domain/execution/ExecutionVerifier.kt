package com.caifenxi.app.domain.execution

import com.caifenxi.app.util.RuntimeLog

/**
 * 执行校验器（ActionResult ≠ ExecutionResult）。
 *
 * 动作成功（点了大小/单双/金额/确认）只产生 [ActionResult]；
 * 最终页面状态（期号未跳变 + 关键动作全部成功 + 可选的页面验证）通过后才能归为 SUCCESS。
 */
class ExecutionVerifier {

    /**
     * 汇总动作结果 → 最终结果。
     *
     * @param expectedIssue 执行前记录的目标期号（用于执行后二次验证页面是否跳期）
     * @param readCurrentIssue 重新读取页面当前期号；null 表示无法读取（交由调用方决定）
     */
    fun verify(
        cmdId: String,
        expectedIssue: String,
        actionResults: List<ActionResult>,
        readCurrentIssue: (() -> String?)? = null,
        extraOk: Boolean = true
    ): ExecutionResult {
        val start = System.currentTimeMillis()
        val actionSuccess = actionResults.isNotEmpty() && actionResults.all { it.success }
        if (actionResults.isEmpty()) {
            RuntimeLog.warn("Execution", "校验失败 cmdId=$cmdId：无任何动作结果")
            return ExecutionResult.fail(
                cmdId,
                ExecutionResult.ELEMENT_NOT_FOUND,
                "无任何动作成功",
                start
            )
        }
        if (!actionSuccess) {
            val failed = actionResults.filter { !it.success }
            RuntimeLog.warn(
                "Execution",
                "校验失败 cmdId=$cmdId：动作未全部成功 ${failed.joinToString { "${it.category}:${it.value}" }}"
            )
            return ExecutionResult.fail(
                cmdId,
                ExecutionResult.ACTION_FAILED,
                "部分动作失败：${failed.joinToString { "${it.category}->${it.value}" }}",
                start
            )
        }
        // 执行后二次验证期号：若页面已跳期，说明可能下到新期，结果进入 UNKNOWN（交状态确认）
        if (readCurrentIssue != null && expectedIssue.isNotBlank()) {
            val currentIssue = readCurrentIssue()
            if (currentIssue != null && currentIssue.isNotBlank()) {
                if (currentIssue.trim() != expectedIssue.trim()) {
                    RuntimeLog.warn(
                        "Execution",
                        "校验 cmdId=$cmdId：页面期号已从 $expectedIssue 变到 $currentIssue，进入 UNKNOWN"
                    )
                    return ExecutionResult.unknown(
                        cmdId,
                        "页面期号跳变($expectedIssue→$currentIssue)，结果待确认"
                    )
                }
            } else {
                // 页面不可读：保守进入 UNKNOWN，避免把可能已执行的任务直接判失败
                return ExecutionResult.unknown(cmdId, "执行后无法读取页面期号，结果待确认")
            }
        }
        if (!extraOk) {
            return ExecutionResult.unknown(cmdId, "执行后附加校验未通过，结果待确认")
        }
        val duration = System.currentTimeMillis() - start
        return ExecutionResult.ok(cmdId, "页面状态确认，执行成功", duration).copy(
            actionResults = actionResults
        )
    }

    /**
     * 把一组动作结果标记为 UNKNOWN（超时/断线恢复后无法确认时用）。
     */
    fun unknown(cmdId: String, actionResults: List<ActionResult>, message: String): ExecutionResult =
        ExecutionResult.unknown(cmdId, message).copy(actionResults = actionResults)
}
