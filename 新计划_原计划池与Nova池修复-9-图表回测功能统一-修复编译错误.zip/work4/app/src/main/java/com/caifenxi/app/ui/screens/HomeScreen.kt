package com.caifenxi.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.caifenxi.app.domain.model.AlgoMode
import com.caifenxi.app.domain.model.LotteryConfig
import com.caifenxi.app.domain.plan.PlanPool
import com.caifenxi.app.domain.plan.NovaPlanPool
import com.caifenxi.app.domain.model.LotteryBetRules
import com.caifenxi.app.domain.model.LotteryPlayCatalog
import com.caifenxi.app.ui.MainViewModel
import com.caifenxi.app.ui.components.AccentTag
import com.caifenxi.app.ui.components.AlgoSelector
import com.caifenxi.app.ui.components.CaptionMuted
import com.caifenxi.app.ui.components.PredictionHeroCard
import com.caifenxi.app.ui.components.PageHeader
import com.caifenxi.app.ui.components.EmptyStateBlock
import com.caifenxi.app.ui.components.GlobalCard
import com.caifenxi.app.ui.components.PrimaryButton
import com.caifenxi.app.ui.components.ScreenContainer
import com.caifenxi.app.ui.components.SectionTitle
import com.caifenxi.app.ui.theme.CaiTokens
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(vm: MainViewModel) {
    val lottery = vm.currentLottery.value
    val latest = vm.latest.value
    val history = vm.history.value
    val loading = vm.loading.value
    val error = vm.errorMessage.value
    val consensus = vm.consensus.value
    val pred = vm.prediction.value
    val summary = vm.statsSummary.value
    val algo = vm.currentAlgo.value
    val countdown = vm.countdownText.value
    val nextIssue = vm.nextIssueText.value

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = CaiTokens.ScreenHPadding, vertical = CaiTokens.S16)
            .padding(bottom = CaiTokens.ScreenBottom)
    ) {
        PageHeader(
            title = "彩析",
            lotteryName = lottery.name,
            playSummary = LotteryPlayCatalog.summaryText(lottery.type),
            subtitle = "统计可视化与策略回测 · 非中奖保证"
        )
        Spacer(Modifier.height(CaiTokens.S12))

        GlobalCard(containerColor = MaterialTheme.colorScheme.secondaryContainer) {
            Text(
                "开奖为随机事件，历史无法预测未来。「共识/评分」是模型加权支持度与相对评分，不是真实中奖概率。请理性对待。",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSecondaryContainer
            )
        }

        Spacer(Modifier.height(CaiTokens.S16))

        var expanded by remember { mutableStateOf(false) }
        ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
            TextField(
                value = lottery.name,
                onValueChange = {},
                readOnly = true,
                label = { Text("当前彩种") },
                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
                modifier = Modifier.menuAnchor().fillMaxWidth(),
                shape = RoundedCornerShape(CaiTokens.RadiusIcon),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = MaterialTheme.colorScheme.surface,
                    unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                    focusedIndicatorColor = MaterialTheme.colorScheme.secondary
                )
            )
            ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                val ordered = LotteryConfig.orderedCatalog(vm.prefs.value.favoriteLotteryKeys)
                ordered.forEach { item ->
                    val rule = LotteryBetRules.profileOf(item).ruleLabel
                    val isFav = item.key in vm.prefs.value.favoriteLotteryKeys
                    DropdownMenuItem(
                        text = { Text("${if (isFav) "★ " else ""}${item.name}（${rule}）") },
                        onClick = {
                            vm.selectLottery(item)
                            expanded = false
                        }
                    )
                }
            }
        }
        val betProfile = LotteryBetRules.profileOf(lottery)
        CaptionMuted("下注口径：${betProfile.ruleLabel} · ${betProfile.dxThresholdText} · ${betProfile.dsRuleText}")
        CaptionMuted("开放玩法：${LotteryPlayCatalog.summaryText(lottery.type)}")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            val favs = vm.prefs.value.favoriteLotteryKeys
            val pinned = lottery.key in favs
            TextButton(onClick = {
                val next = if (pinned) favs.filter { it != lottery.key }
                else (listOf(lottery.key) + favs.filter { it != lottery.key })
                vm.updatePrefs { it.copy(favoriteLotteryKeys = next) }
            }) { Text(if (pinned) "取消常用" else "设为常用置顶") }
            if (favs.size >= 2 && pinned) {
                TextButton(onClick = {
                    val idx = favs.indexOf(lottery.key)
                    if (idx > 0) {
                        val m = favs.toMutableList()
                        val tmp = m[idx - 1]
                        m[idx - 1] = m[idx]
                        m[idx] = tmp
                        vm.updatePrefs { it.copy(favoriteLotteryKeys = m) }
                    }
                }) { Text("常用上移") }
            }
        }

        Spacer(Modifier.height(CaiTokens.S8))
        // 驾驶舱主卡片：下期预测一屏扫读
        val pred = vm.prediction.value
        val heroTarget = vm.nextIssueText.value
        if (history.isEmpty()) {
            EmptyStateBlock(
                title = "暂无开奖数据",
                subtitle = "请先同步开奖，再查看预测与挂机",
                actionLabel = "立即同步",
                onAction = { vm.loadData() }
            )
        } else {
            PredictionHeroCard(
                targetIssue = heroTarget,
                dx = pred?.dx?.direction,
                ds = pred?.ds?.direction,
                combo = pred?.combo?.direction ?: pred?.comboList?.firstOrNull()?.direction,
                extraLines = listOfNotNull(
                    pred?.algoTag?.let { "算法标签：$it" },
                    vm.prefs.value.cockpitPlanId.takeIf { it.isNotBlank() }?.let { "驾驶舱计划：$it" }
                ),
                footer = "玩法：" + LotteryPlayCatalog.summaryText(lottery.type)
            )
        }

        Spacer(Modifier.height(CaiTokens.S8))
        SectionTitle("算法模式")
        AlgoSelector(selected = algo, onSelect = { vm.selectAlgo(it) })

        var planMenuExpanded by remember { mutableStateOf(false) }
        val cockpitPlanId = vm.prefs.value.cockpitPlanId
        val cockpitPlanName = if (cockpitPlanId.isBlank()) "跟随算法/计划池"
        else (vm.planRows.value.firstOrNull { it.first.planId == cockpitPlanId }?.first?.planName
            ?: PlanPool.ALL.firstOrNull { it.planId == cockpitPlanId }?.planName
            ?: NovaPlanPool.ALL.firstOrNull { it.planId == cockpitPlanId }?.planName
            ?: cockpitPlanId)
        Text("驾驶舱指定计划", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
        ExposedDropdownMenuBox(expanded = planMenuExpanded, onExpandedChange = { planMenuExpanded = it }) {
            TextField(
                value = cockpitPlanName,
                onValueChange = {},
                readOnly = true,
                label = { Text("精确到具体计划") },
                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(planMenuExpanded) },
                modifier = Modifier.menuAnchor().fillMaxWidth(),
                shape = RoundedCornerShape(CaiTokens.RadiusIcon),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = MaterialTheme.colorScheme.surface,
                    unfocusedContainerColor = MaterialTheme.colorScheme.surface
                )
            )
            ExposedDropdownMenu(expanded = planMenuExpanded, onDismissRequest = { planMenuExpanded = false }) {
                DropdownMenuItem(
                    text = { Text("跟随算法/计划池") },
                    onClick = { vm.selectCockpitPlan(""); planMenuExpanded = false }
                )
                PlanPool.ALL.forEach { def ->
                    DropdownMenuItem(
                        text = { Text("原计划 · ${def.planId} · ${def.planName}") },
                        onClick = { vm.selectCockpitPlan(def.planId); planMenuExpanded = false }
                    )
                }
                NovaPlanPool.ALL.forEach { def ->
                    DropdownMenuItem(
                        text = { Text("新计划 · ${def.playType}${if (def.positionIndex >= 0) "·${NovaPlanPool.meta(def).positionLabel}" else ""} · ${def.planId}") },
                        onClick = { vm.selectCockpitPlan(def.planId); planMenuExpanded = false }
                    )
                }
                vm.customPlans.value.forEach { def ->
                    DropdownMenuItem(
                        text = { Text("${def.planId} · ${def.planName}") },
                        onClick = { vm.selectCockpitPlan(def.planId); planMenuExpanded = false }
                    )
                }
            }
        }
        CaptionMuted(if (cockpitPlanId.isBlank()) "当前驾驶舱按上方算法模式运行" else "当前已锁定：$cockpitPlanId · 周期${vm.prefs.value.cockpitPlanCyclePeriods}期 · 预测/挂机/悬浮窗可联动使用")
        CaptionMuted(vm.statusText.value)

        if (loading && history.isEmpty()) {
            Box(Modifier.fillMaxWidth().padding(CaiTokens.S32), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = MaterialTheme.colorScheme.secondary)
            }
            return
        }

        if (error != null && history.isEmpty()) {
            GlobalCard {
                Text("数据加载失败", fontWeight = FontWeight.Bold)
                Text(error, style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(CaiTokens.S8))
                PrimaryButton("重新加载", onClick = { vm.loadData() })
            }
            Spacer(Modifier.height(CaiTokens.S12))
        }

        Spacer(Modifier.height(CaiTokens.S12))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(CaiTokens.S8)) {
            MiniStat("期数", "${history.size}", Modifier.weight(1f))
            MiniStat("最新", latest?.issue ?: "-", Modifier.weight(1f))
            MiniStat(
                "命中率",
                if (summary.hit + summary.miss == 0) "-" else "${(summary.hitRate * 100).roundToInt()}%",
                Modifier.weight(1f)
            )
        }

        Spacer(Modifier.height(CaiTokens.S16))
        GlobalCard(containerColor = MaterialTheme.colorScheme.surface) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                Text("下期 第 $nextIssue 期", fontWeight = FontWeight.SemiBold)
                Text(
                    countdown,
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.secondary
                )
                CaptionMuted("估算倒计时 · 以接口时间校准更佳")
            }
        }

        Spacer(Modifier.height(CaiTokens.S16))
        // V9.1 实时驾驶舱：只依赖当前内存状态，避免点击刷新时整页重新拉取。
        val topPlan = vm.planRows.value
            .filter { it.second.sampleCount > 0 }
            .maxWithOrNull(compareBy<Pair<com.caifenxi.app.domain.model.PlanDefinition, com.caifenxi.app.domain.model.PlanRuntime>> { it.second.score }
                .thenBy { it.second.hitRate })
        val cAvg = if (consensus.isEmpty()) 0.0 else consensus.map { it.supportRatio }.average()
        val cDis = if (consensus.isEmpty()) 0.0 else consensus.map { it.disagreement }.average()
        val betStats = vm.betStats.value

        GlobalCard(containerColor = MaterialTheme.colorScheme.surfaceVariant) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("实时驾驶舱", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(
                    if (loading) "同步中" else "本地状态",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.secondary
                )
            }
            Spacer(Modifier.height(CaiTokens.S8))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(CaiTokens.S8)) {
                DashboardMetric("目标期", nextIssue, Modifier.weight(1f))
                DashboardMetric("共识支持", if (consensus.isEmpty()) "-" else "${(cAvg * 100).roundToInt()}%", Modifier.weight(1f))
                DashboardMetric("分歧", if (consensus.isEmpty()) "-" else "${(cDis * 100).roundToInt()}%", Modifier.weight(1f))
            }
            Spacer(Modifier.height(CaiTokens.S8))
            if (topPlan != null) {
                Text("领先计划", style = MaterialTheme.typography.labelMedium)
                Text(
                    "${topPlan.first.planName} · ${topPlan.first.category} · ${topPlan.second.hitRatePercent} · ${topPlan.second.score.roundToInt()}分",
                    fontWeight = FontWeight.SemiBold
                )
            } else {
                CaptionMuted("计划样本积累后显示领先计划")
            }
            Spacer(Modifier.height(CaiTokens.S8))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                CaptionMuted("模拟统计")
                Text(
                    "${betStats.totalSettled}期 · ${betStats.totalProfit.let { if (it >= 0) "+%.2f".format(it) else "%.2f".format(it) }} · 胜率 ${(betStats.winRate * 100).roundToInt()}%",
                    style = MaterialTheme.typography.labelMedium
                )
            }
            Spacer(Modifier.height(CaiTokens.S8))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(CaiTokens.S8)) {
                PrimaryButton("只更新预测", onClick = { vm.recomputeFromCache() }, ghost = true, modifier = Modifier.weight(1f))
                PrimaryButton("只更新统计", onClick = { vm.refreshBetOverview() }, ghost = true, modifier = Modifier.weight(1f))
            }
        }

        Spacer(Modifier.height(CaiTokens.S16))
        GlobalCard {
            Text("实时开奖", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(CaiTokens.S8))
            if (latest == null) {
                CaptionMuted("暂无数据")
            } else {
                Text("第 ${latest.issue} 期", fontWeight = FontWeight.Medium)
                CaptionMuted(latest.drawTime.take(19))
                Spacer(Modifier.height(CaiTokens.S8))
                NumberBalls(latest.numbers)
                Spacer(Modifier.height(CaiTokens.S8))
                Row(horizontalArrangement = Arrangement.spacedBy(CaiTokens.S8)) {
                    latest.dx?.let { AccentTag(it) }
                    latest.ds?.let { AccentTag(it) }
                    latest.combo?.let { AccentTag(it) }
                }
            }
        }

        Spacer(Modifier.height(CaiTokens.S16))
        GlobalCard(containerColor = MaterialTheme.colorScheme.primaryContainer) {
            Text("策略驾驶舱", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(CaiTokens.S8))
            if (pred == null) {
                CaptionMuted("加载后显示预测与共识")
            } else {
                val algoLabel = buildString {
                    append(AlgoMode.fromId(pred.algoTag).label)
                    if (pred.resolvedAlgo.isNotBlank() && pred.resolvedAlgo != pred.algoTag) {
                        append(" · 实际采用 ${AlgoMode.fromId(pred.resolvedAlgo).label}")
                    }
                }
                CaptionMuted("目标 ${pred.targetIssue} · $algoLabel")
                Spacer(Modifier.height(CaiTokens.S8))
                val betTitles = LotteryBetRules.categoryTitles(vm.currentLottery.value.key)
                pred.dx?.let { PredLine(betTitles.first, it.direction, it.score) }
                pred.ds?.let { PredLine(betTitles.second, it.direction, it.score) }
                pred.combo?.let { PredLine(betTitles.third, it.direction, it.score) }
                consensus.forEach { c ->
                    Spacer(Modifier.height(CaiTokens.S4))
                    Text(
                        "共识 ${c.category}→${c.leadingDirection} ${(c.supportRatio * 100).roundToInt()}%",
                        style = MaterialTheme.typography.labelMedium
                    )
                    LinearProgressIndicator(
                        progress = { c.supportRatio.toFloat() },
                        modifier = Modifier.fillMaxWidth(),
                        color = MaterialTheme.colorScheme.secondary
                    )
                }
            }
        }

        Spacer(Modifier.height(CaiTokens.S16))
        PrimaryButton("刷新数据与预测", onClick = { vm.loadData() }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(CaiTokens.S16))
        // 历史战绩前置：首页固定展示，不再藏在“更多”中。
        GlobalCard(containerColor = MaterialTheme.colorScheme.surfaceVariant) {
            Text("历史战绩", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(CaiTokens.S8))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                CaptionMuted("已结算 ${summary.hit + summary.miss} 期")
                Text(
                    if (summary.hit + summary.miss == 0) "-" else "${(summary.hitRate * 100).roundToInt()}%",
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(Modifier.height(CaiTokens.S4))
            CaptionMuted(when {
                summary.recentStreak > 0 -> "当前连对 ${summary.recentStreak} · 最大连对 ${summary.maxHitStreak}"
                summary.recentStreak < 0 -> "当前连错 ${-summary.recentStreak} · 最大连错 ${summary.maxMissStreak}"
                else -> "暂无连续结果 · 最大连对 ${summary.maxHitStreak} · 最大连错 ${summary.maxMissStreak}"
            })
            Spacer(Modifier.height(CaiTokens.S8))
            vm.statRecords.value.takeLast(5).asReversed().forEach { r ->
                Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(r.issue, style = MaterialTheme.typography.labelMedium)
                    Text("${r.category} · ${r.lean} → ${r.actual ?: "待开"}", style = MaterialTheme.typography.labelMedium)
                    Text(r.result, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.height(CaiTokens.S8))
            CaptionMuted("完整历史可在“战绩”页面分页查看，历史数量不以500期为上限。")
        }

        Spacer(Modifier.height(CaiTokens.S8))
        // 原实现误调用 loadData()（仍走网络），改为纯本地重算
        PrimaryButton("仅用缓存重算", onClick = { vm.recomputeFromCache() }, ghost = true, modifier = Modifier.fillMaxWidth())
    }
}

@Composable
private fun DashboardMetric(label: String, value: String, modifier: Modifier = Modifier) {
    GlobalCard(modifier = modifier) {
        Text(value, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
        CaptionMuted(label)
    }
}

@Composable
private fun MiniStat(label: String, value: String, modifier: Modifier = Modifier) {
    GlobalCard(modifier = modifier) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
            Text(value, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
            CaptionMuted(label)
        }
    }
}

@Composable
private fun PredLine(title: String, dir: String, score: Double) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("$title  ", style = MaterialTheme.typography.bodyMedium)
        Text(dir, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
        Spacer(Modifier.weight(1f))
        Text("${(score * 100).roundToInt()}%", style = MaterialTheme.typography.labelMedium)
    }
}

@Composable
private fun NumberBalls(nums: List<Int>) {
    Column(verticalArrangement = Arrangement.spacedBy(CaiTokens.S4)) {
        nums.chunked(10).forEach { row ->
            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(CaiTokens.S4)
            ) {
                row.forEach { n ->
                    Box(
                        Modifier
                            .clip(RoundedCornerShape(CaiTokens.RadiusIcon))
                            .background(MaterialTheme.colorScheme.secondary)
                            .padding(horizontal = CaiTokens.S8, vertical = CaiTokens.S4)
                    ) {
                        Text(
                            n.toString().padStart(2, '0'),
                            color = MaterialTheme.colorScheme.onSecondary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }
    }
}
