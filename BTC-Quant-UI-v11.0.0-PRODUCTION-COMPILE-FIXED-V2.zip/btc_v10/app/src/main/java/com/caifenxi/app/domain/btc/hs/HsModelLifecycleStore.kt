package com.caifenxi.app.domain.btc.hs

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Persists the latest lifecycle state for inspection and restart continuity. */
class HsModelLifecycleStore(context: Context? = null) {
    private val prefs = context?.applicationContext?.getSharedPreferences("btc_hs_model_lifecycle_v1", Context.MODE_PRIVATE)
    @Synchronized fun save(report: HsModelLifecycle.Report) {
        val p=prefs?:return; val a=JSONArray()
        report.states.forEach { s -> a.put(JSONObject().apply { put("id",s.modelId); put("status",s.status.name); put("score",s.score); put("drift",s.drift); put("reason",s.reason) }) }
        p.edit().putLong("at",report.generatedAt).putString("states",a.toString()).apply()
    }
    @Synchronized fun load(): HsModelLifecycle.Report? {
        val p=prefs?:return null
        val raw=p.getString("states",null) ?: return null
        return runCatching {
            val a=JSONArray(raw); val rows=buildList { for(i in 0 until a.length()) { val o=a.getJSONObject(i); add(HsModelLifecycle.State(o.getString("id"),HsModelLifecycle.Status.valueOf(o.getString("status")),o.getDouble("score"),o.getDouble("drift"),o.getString("reason"))) } }
            HsModelLifecycle.Report(p.getLong("at",0L),rows,rows.filter{it.status==HsModelLifecycle.Status.ACTIVE}.map{it.modelId})
        }.getOrNull()
    }
}
