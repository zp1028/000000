package com.caifenxi.app.domain.btc.hs

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.ArrayDeque

/** Persistent model lineage ledger: prediction -> observed bar -> realized outcome. */
class ModelLineageStore(context: Context?, private val maxRecords:Int = 4000) {
    private val prefs = context?.applicationContext?.getSharedPreferences("btc_model_lineage_v1", Context.MODE_PRIVATE)
    private val pending = ArrayDeque<ModelLineageEngine.Observation>()
    private val feedback = ArrayDeque<ModelLineageEngine.Feedback>()

    init { restore() }

    @Synchronized fun record(o: ModelLineageEngine.Observation) {
        if (pending.any { it.id == o.id }) return
        pending.addLast(o)
        while (pending.size > maxRecords) pending.removeFirst()
        persist()
    }

    /** Resolve observations whose target bar is now known. */
    @Synchronized fun resolveThrough(timeframe:String, currentBarId:Long, actualUp:(Long)->Boolean, nowMs:Long=System.currentTimeMillis()):Int {
        if (pending.isEmpty()) return 0
        val resolved = ArrayList<ModelLineageEngine.Observation>()
        pending.forEach { o ->
            if (o.timeframe == timeframe && currentBarId >= o.barId + o.horizon) resolved += o
        }
        if (resolved.isEmpty()) return 0
        resolved.forEach { o ->
            val yBar = o.barId + o.horizon
            val f = ModelLineageEngine.resolve(o, actualUp(yBar), nowMs)
            feedback.addLast(f)
            pending.remove(o)
        }
        while (feedback.size > maxRecords) feedback.removeFirst()
        persist()
        return resolved.size
    }

    @Synchronized fun pendingCount(tf:String?=null):Int = if(tf==null) pending.size else pending.count{it.timeframe==tf}
    @Synchronized fun feedbackCount(modelId:String?=null, tf:String?=null):Int = feedback.count { (modelId==null || it.modelId==modelId) && (tf==null || it.timeframe==tf) }
    @Synchronized fun metrics(modelId:String, tf:String): Triple<Double,Double,Int> {
        val rows=feedback.filter{it.modelId==modelId && it.timeframe==tf}.takeLast(120)
        if(rows.isEmpty()) return Triple(.25,0.0,0)
        return Triple(rows.map{it.brier}.average(), rows.count{it.correct}.toDouble()/rows.size, rows.size)
    }
    @Synchronized fun drift(modelId:String, tf:String):Double {
        val rows=feedback.filter{it.modelId==modelId && it.timeframe==tf}
        if(rows.size<20)return 0.0
        return ModelLineageEngine.drift(rows.takeLast(20), rows.dropLast(20).takeLast(100))
    }
    @Synchronized fun pendingSnapshot():List<ModelLineageEngine.Observation> = pending.toList()

    private fun persist() {
        val p=prefs?:return
        val pa=JSONArray(); pending.forEach { o -> pa.put(JSONObject().apply {
            put("id",o.id);put("modelId",o.modelId);put("tf",o.timeframe);put("h",o.horizon);put("fv",o.featureVersion);put("cutoff",o.datasetCutoffMs);put("p",o.predictedUp);put("bar",o.barId);put("at",o.createdAtMs)
        }) }
        val fa=JSONArray(); feedback.forEach { f -> fa.put(JSONObject().apply {
            put("id",f.observationId);put("modelId",f.modelId);put("tf",f.timeframe);put("p",f.predictedUp);put("y",f.actualUp);put("b",f.brier);put("ok",f.correct);put("at",f.resolvedAtMs)
        }) }
        p.edit().putString("pending",pa.toString()).putString("feedback",fa.toString()).apply()
    }
    private fun restore() { val p=prefs?:return
        runCatching { val a=JSONArray(p.getString("pending","[]")); for(i in 0 until a.length()){val o=a.getJSONObject(i);pending.addLast(ModelLineageEngine.Observation(o.getString("id"),o.getString("modelId"),o.getString("tf"),o.getInt("h"),o.getString("fv"),o.getLong("cutoff"),o.getDouble("p"),o.getLong("bar"),o.getLong("at")))} }
        runCatching { val a=JSONArray(p.getString("feedback","[]")); for(i in 0 until a.length()){val o=a.getJSONObject(i);feedback.addLast(ModelLineageEngine.Feedback(o.getString("id"),o.getString("modelId"),o.getString("tf"),o.getDouble("p"),o.getBoolean("y"),o.getDouble("b"),o.getBoolean("ok"),o.getLong("at")))} }
        while(pending.size>maxRecords)pending.removeFirst();while(feedback.size>maxRecords)feedback.removeFirst()
    }
}
