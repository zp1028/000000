package com.caifenxi.app.domain.btc

import kotlin.math.abs
import kotlin.math.sqrt

/**
 * Builds point-in-time derivatives features from historical series.
 * Never looks ahead of [barTime].
 */
object DerivativesFeatureEngine {

    fun build(
        barTime: Long,
        close: Double,
        prevClose: Double?,
        fundingHistory: List<FundingPoint>,
        oiHistory: List<OpenInterestPoint>,
        snapshot: BtcDerivativesSnapshot? = null
    ): DerivativesFeatures {
        val fundingUpTo = fundingHistory.filter { it.fundingTime <= barTime }
        val oiUpTo = oiHistory.filter { it.timestamp <= barTime }

        val lastFunding = fundingUpTo.lastOrNull()?.fundingRate
            ?: snapshot?.fundingRate
            ?: 0.0
        val rates = fundingUpTo.takeLast(30).map { it.fundingRate }
        val mean = rates.averageOrZero()
        val std = rates.stdevOrZero().coerceAtLeast(1e-8)
        val z = ((lastFunding - mean) / std).coerceIn(-4.0, 4.0)
        val extreme = abs(z) >= 1.8 || abs(lastFunding) >= 0.0003
        // High positive funding → longs pay shorts → crowd long → fade toward DOWN
        val fundingBias = (-z / 3.0).coerceIn(-1.0, 1.0)

        val lastOi = oiUpTo.lastOrNull()?.sumOpenInterest ?: snapshot?.openInterest ?: 0.0
        val prevOi = oiUpTo.dropLast(1).lastOrNull()?.sumOpenInterest
        val oiChangePct = if (prevOi != null && prevOi > 0) {
            ((lastOi - prevOi) / prevOi * 100.0).coerceIn(-20.0, 20.0)
        } else 0.0
        val oiWindow = oiUpTo.takeLast(12).map { it.sumOpenInterest }
        val oiTrend = when {
            oiWindow.size < 4 -> 0.0
            else -> {
                val first = oiWindow.first()
                if (first <= 0) 0.0 else ((oiWindow.last() - first) / first * 8.0).coerceIn(-1.0, 1.0)
            }
        }
        val priceChg = if (prevClose != null && prevClose > 0) (close - prevClose) / prevClose else 0.0
        // Align: price↑+oi↑ trend confirm; price↑+oi↓ weak short-cover rally
        val priceOiAlign = when {
            priceChg > 0 && oiChangePct > 0 -> 0.6
            priceChg < 0 && oiChangePct > 0 -> -0.6
            priceChg > 0 && oiChangePct < 0 -> -0.25
            priceChg < 0 && oiChangePct < 0 -> 0.25
            else -> 0.0
        }
        val derivScore = (fundingBias * 0.55 + priceOiAlign * 0.35 + oiTrend * 0.10)
            .coerceIn(-1.0, 1.0)

        return DerivativesFeatures(
            barTime = barTime,
            fundingRate = lastFunding,
            fundingZScore = z,
            fundingExtreme = extreme,
            fundingBias = fundingBias,
            oi = lastOi,
            oiChangePct = oiChangePct,
            oiTrend = oiTrend,
            priceOiAlign = priceOiAlign,
            derivativesScore = derivScore
        )
    }

    private fun List<Double>.averageOrZero() = if (isEmpty()) 0.0 else average()
    private fun List<Double>.stdevOrZero(): Double {
        if (size < 2) return 0.0
        val m = average()
        return sqrt(map { (it - m) * (it - m) }.average())
    }
}
