package com.caifenxi.app.domain.btc.plan

import com.caifenxi.app.domain.btc.BtcDirection
import com.caifenxi.app.domain.btc.BtcPlanSignal
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.ln

/**
 * 概率校准器（v2）
 * - 共识收缩 + Platt
 * - 可选历史 (p, outcome) 分桶微调
 * - 输出统一 0–1，硬区间 0.50–0.85（方向明确时）
 */
object BtcProbabilityCalibrator {

    @Volatile private var plattA: Double = 1.15
    @Volatile private var plattB: Double = 0.0
    @Volatile private var bucketMeans: DoubleArray? = null

    fun calibrate(
        baseProbability: Double,
        direction: BtcDirection,
        signals: List<BtcPlanSignal>
    ): Double {
        if (direction == BtcDirection.FLAT || signals.isEmpty()) {
            return baseProbability.coerceIn(0.50, 0.72)
        }

        val agreeing = signals.filter { it.direction == direction }
        val weighted = agreeing.sumOf { abs(it.contribution) }
        val total = signals.sumOf { abs(it.contribution) }.coerceAtLeast(1e-9)
        val agreement = (weighted / total).coerceIn(0.0, 1.0)

        val shrunk = 0.5 + (baseProbability - 0.5) * 0.62 + (agreement - 0.5) * 0.18
        val z = logit(shrunk.coerceIn(0.02, 0.98))
        var calibrated = sigmoid(plattA * z + plattB)

        // 分桶经验校正（若已 fit）
        bucketMeans?.let { means ->
            val idx = ((calibrated * means.size).toInt()).coerceIn(0, means.size - 1)
            val emp = means[idx]
            if (!emp.isNaN()) {
                calibrated = calibrated * 0.55 + emp * 0.45
            }
        }

        val sampleFactor = (signals.size / 12.0).coerceIn(0.55, 1.0)
        val finalP = 0.5 + (calibrated - 0.5) * sampleFactor
        return finalP.coerceIn(0.50, 0.85)
    }

    /** 从历史 (p_raw, outcome) 拟合 Platt + 分桶 */
    fun fitFromHistory(pairs: List<Pair<Double, Boolean>>) {
        if (pairs.size < 30) return
        val meanP = pairs.map { it.first }.average()
        val meanY = pairs.map { if (it.second) 1.0 else 0.0 }.average()
        plattB = logit(meanY.coerceIn(0.05, 0.95)) - plattA * logit(meanP.coerceIn(0.05, 0.95))
        val nBuckets = 8
        val buckets = Array(nBuckets) { mutableListOf<Double>() }
        pairs.forEach { (p, y) ->
            val idx = ((p.coerceIn(0.0, 0.999) * nBuckets).toInt()).coerceIn(0, nBuckets - 1)
            buckets[idx] += if (y) 1.0 else 0.0
        }
        bucketMeans = DoubleArray(nBuckets) { i ->
            val b = buckets[i]
            if (b.isEmpty()) Double.NaN else b.average()
        }
    }

    fun fitPlatt(pairs: List<Pair<Double, Boolean>>): Pair<Double, Double> {
        fitFromHistory(pairs)
        return plattA to plattB
    }

    private fun logit(p: Double): Double {
        val x = p.coerceIn(1e-6, 1 - 1e-6)
        return ln(x / (1 - x))
    }

    private fun sigmoid(z: Double): Double = 1.0 / (1.0 + exp(-z.coerceIn(-20.0, 20.0)))
}
