package com.caifenxi.app.domain.execution

import org.json.JSONObject

/**
 * Agent 编排层：统一感知、模型决策、策略校验和结果记录。
 * 本类不持有任何下注/支付执行器，只产生结构化 Dry-Run 决策。
 */
class AiAgentOrchestrator(private val client: LlmClient) {
    data class Observation(
        val target: String,
        val screenSummary: String = "",
        val accessibilitySummary: String = "",
        val domSummary: String = ""
    )

    data class Decision(
        val action: AiAgentBrain.ProposedAction?,
        val allowed: Boolean,
        val message: String,
        val latencyMs: Long
    )

    suspend fun decide(observation: Observation): Decision {
        if (!AiAgentPolicy.isAllowedTarget(observation.target)) {
            return Decision(null, false, AiAgentPolicy.reason(observation.target), 0)
        }
        val prompt = LlmPrompt(
            system = """
                You are a UI automation planning model. Return JSON only.
                You may identify UI targets and propose harmless Dry-Run actions.
                Never propose payment, purchase, transfer, withdrawal, deposit, betting,
                order submission, or other financial/transaction actions.
                Schema: {type,target,text,x,y,confidence,reason}
                type must be CLICK, TYPE, SCROLL, WAIT, FINISH, or FAIL.
            """.trimIndent(),
            userText = "Target=${observation.target}\nScreen=${observation.screenSummary.take(4000)}\nAccessibility=${observation.accessibilitySummary.take(4000)}\nDOM=${observation.domSummary.take(4000)}",
            imageBase64 = ""
        )
        val response = client.chat(prompt)
        return when (response) {
            is LlmResponse.Success -> parse(response.content, response.durationMs)
            is LlmResponse.Error -> Decision(null, false, response.message, response.durationMs)
        }
    }

    private fun parse(text: String, latency: Long): Decision = try {
        val clean = text.trim().removePrefix("```").removePrefix("json").removeSuffix("```").trim()
        val o = JSONObject(clean)
        val type = runCatching { AiAgentBrain.ActionType.valueOf(o.optString("type", "FAIL").uppercase()) }
            .getOrDefault(AiAgentBrain.ActionType.FAIL)
        val confidence = o.optDouble("confidence", 0.0).toFloat().coerceIn(0f, 1f)
        val action = AiAgentBrain.ProposedAction(
            type = type,
            target = o.optString("target"),
            text = o.optString("text"),
            x = o.optDouble("x", 0.0).toFloat(),
            y = o.optDouble("y", 0.0).toFloat(),
            confidence = confidence,
            reason = o.optString("reason")
        )
        val allowed = type != AiAgentBrain.ActionType.FAIL &&
            AiAgentPolicy.isAllowedTarget(action.target) &&
            confidence >= 0.70f
        Decision(action.takeIf { allowed }, allowed, if (allowed) "候选动作通过 Dry-Run 校验" else "动作未通过策略或置信度校验", latency)
    } catch (e: Exception) {
        Decision(null, false, "AI JSON 解析失败: ${e.message}", latency)
    }
}
