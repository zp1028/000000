package com.caifenxi.app.domain.engine

import com.caifenxi.app.data.config.StreakCalc
import com.caifenxi.app.data.db.dao.BetDao
import com.caifenxi.app.data.db.entity.BetEntity
import com.caifenxi.app.data.db.entity.BotConfigEntity
import com.caifenxi.app.data.db.entity.WalletEntity
import com.caifenxi.app.domain.model.BetCategory
import com.caifenxi.app.domain.model.BetOdds
import com.caifenxi.app.domain.model.LotteryConfig
import com.caifenxi.app.domain.model.LotteryType
import com.caifenxi.app.domain.model.BetSourceType
import com.caifenxi.app.domain.model.BetStats
import com.caifenxi.app.domain.model.CatBetStats
import com.caifenxi.app.domain.model.DrawRecord
import com.caifenxi.app.domain.model.ModelConsensus
import com.caifenxi.app.domain.model.PlanPredictionRecord
import com.caifenxi.app.domain.model.PksPositions
import com.caifenxi.app.domain.model.PredictionSnapshot
import com.caifenxi.app.domain.model.ProfitPoint
import com.caifenxi.app.domain.plan.NovaPlanPool
import com.caifenxi.app.domain.plan.LotteryPlanPools
import com.caifenxi.app.domain.plan.NovaYdhPlanPool
import com.caifenxi.app.domain.plan.NovaK3PlanPool
import com.caifenxi.app.domain.plan.NovaPlanAnalytics
import com.caifenxi.app.domain.plan.PlanPool
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * 模拟下注引擎:下单 + 每期自动结算 + 倍投 + 统计。
 *
 * 倍投规则(各分类独立追踪,按「期」计数而非按注):
 * - 上一期「中了」→ 本期金额 = min(上期金额 × winMult, 基数 × maxMult)
 * - 上一期「未中」→ 本期金额 = min(上期金额 × lossMult, 基数 × maxMult)
 * - 对/错倍投只持续设置的期数;超过期数后恢复基数。
 * - 一旦结果方向改变,重新按新方向开始计数。
 */
class BetEngine(private val dao: BetDao) {

    companion object {
        const val DEFAULT_INITIAL = 10000.0
    }

    // ---- 内存中追踪各分类上一注结果(lotteryKey -> catName -> lastHit?)----
    private val lastHitMap = mutableMapOf<String, MutableMap<String, Boolean?>>()
    /** 同彩种下单互斥,避免 UI 心跳与 Service 并发各下一遍 */
    private val placeMutex = Mutex()

    /**
     * 下单诊断结果(便于状态栏说明为何没下单)。
     */
    data class PlaceResult(
        val placed: Int,
        val reason: String,
        val picksSummary: String = ""
    )

    /**
     * 根据挂机策略 + 当前预测,为指定目标期自动下单。
     * @return 本次实际下的注数量
     */
    suspend fun placeAutoBets(
        lotteryKey: String,
        targetIssue: String,
        prediction: PredictionSnapshot?,
        planPredictions: List<PlanPredictionRecord>,
        consensus: List<ModelConsensus>,
        history: List<DrawRecord> = emptyList()
    ): Int = placeAutoBetsDetailed(
        lotteryKey, targetIssue, prediction, planPredictions, consensus, history
    ).placed

    /**
     * 带回原因的自动下单,供界面提示「为何没挂上」。
     * 全程互斥,防止心跳/Service/手动同时触发导致同一目标期下两遍。
     * @param history 滚动预测开启时用于图表同款现算（从最新往前）
     */
    suspend fun placeAutoBetsDetailed(
        lotteryKey: String,
        targetIssue: String,
        prediction: PredictionSnapshot?,
        planPredictions: List<PlanPredictionRecord>,
        consensus: List<ModelConsensus>,
        history: List<DrawRecord> = emptyList()
    ): PlaceResult = placeMutex.withLock {
        val config = dao.getBotConfig(lotteryKey)
            ?: return@withLock PlaceResult(0, "无挂机配置(请到挂机页开启并保存)")
        if (!config.enabled) return@withLock PlaceResult(0, "挂机未开启")
        if (config.amount <= 0) return@withLock PlaceResult(0, "单注金额为0")
        if (targetIssue.isBlank() || targetIssue == "-") {
            return@withLock PlaceResult(0, "目标期无效")
        }

        // 防重:目标期已有「待开」订单则跳过
        if (dao.getPendingBets(lotteryKey, targetIssue).isNotEmpty()) {
            return@withLock PlaceResult(0, "目标期 $targetIssue 已有待开单")
        }

        val categories = config.categories.split(",").mapNotNull { BetCategory.fromId(it.trim()) }
        if (categories.isEmpty()) return@withLock PlaceResult(0, "未勾选下注分类")

        val picksRaw = resolvePicks(config, prediction, planPredictions, consensus, history)
        // 滚动现算结果已按 rolling 内反投处理；非滚动仍用 betMode 反投
        val picks = if (!config.rollingPredict && config.betMode.equals("reverse", ignoreCase = true)) {
            invertPicks(picksRaw)
        } else {
            picksRaw
        }
        if (picks.isEmpty()) {
            val why = when (BetSourceType.fromId(config.sourceType)) {
                BetSourceType.COCKPIT, BetSourceType.ALGO ->
                    if (prediction == null) "算法预测为空(未生成)"
                    else "算法预测无可用方向(检查分类是否匹配)"
                BetSourceType.PLAN, BetSourceType.NOVA, BetSourceType.FAVORITE ->
                    "计划「${config.sourceId}」无预测(请确认计划已在工作台生成/回测并与目标期一致；也可开启滚动现算用图表同款现算)"
                BetSourceType.AUTO_BEST ->
                    "竞技场暂无可用计划预测"
                BetSourceType.CONSENSUS ->
                    "共识预测为空(请打开计划-共识预测页刷新)"
                BetSourceType.NOVA_CONSENSUS ->
                    "新计划共识为空(请打开新计划页-共识预测刷新)"
            }
            return@withLock PlaceResult(0, why)
        }

        val wallet = dao.getWallet(lotteryKey) ?: ensureWallet(lotteryKey, DEFAULT_INITIAL)
        ensureLastHitFromDb(lotteryKey)
        var balance = wallet.balance
        val initial = wallet.initialBalance
        val catStreaks = lastHitMap.getOrPut(lotteryKey) { mutableMapOf() }
        var placed = 0
        var spent = 0.0
        val pickDesc = picks.entries.joinToString(";") { (k, v) -> "${k.id}:${v.joinToString("/")}" }

        for (cat in categories) {
            val values = picks[cat]?.distinct()?.filter { it.isNotBlank() } ?: continue
            if (values.isEmpty()) continue
            val lastHit = catStreaks[cat.id]
            val prevAmount = getLastAmount(lotteryKey, cat.id).let { if (it > 0) it else config.amount }
            val streak = if (lastHit == null) 0 else getRecentStreak(lotteryKey, cat.id, lastHit)
            // 二期/三期：与工作台轮次一致；若用户未自定义 lossMultPeriods(<=1)，按口径自动延长轮内倍投期数
            val stage = config.rollingStage.coerceIn(1, 3)
            val effectiveLossPeriods =
                if (stage > 1 && config.lossMultPeriods <= 1) (stage - 1).coerceAtLeast(1)
                else config.lossMultPeriods
            val currentAmount = calcAmount(
                baseAmount = config.amount,
                lastAmount = prevAmount,
                lastHit = lastHit,
                streak = streak,
                winMult = config.winMult,
                lossMult = config.lossMult,
                winMultPeriods = config.winMultPeriods,
                lossMultPeriods = effectiveLossPeriods,
                maxMult = config.maxMult,
                maxCap = initial * config.maxMult.coerceAtLeast(1)
            ).coerceAtMost((balance - spent).coerceAtLeast(0.0))

            if (currentAmount <= 0 || balance - spent <= 0) {
                if (placed == 0) {
                    return@withLock PlaceResult(0, "余额不足(可用 ${"%.1f".format(balance - spent)})", pickDesc)
                }
                break
            }

            // 组合/数字:多候选合并为一注;组合赔率随覆盖数变化
            if (cat == BetCategory.COMBO) {
                // 一口单注 currentAmount；n 口总成本 n×单注；返还按 1:4 单口（4×单注），再减成本
                val n = values.size.coerceAtLeast(1)
                val totalCost = currentAmount * n
                if (balance - spent < totalCost) break
                val odds = BetOdds.resolveForBet(BetCategory.COMBO, values, lotteryKey)
                dao.insertBet(
                    BetEntity(
                        lotteryKey = lotteryKey,
                        issue = targetIssue,
                        sourceType = config.sourceType,
                        sourceId = config.sourceId,
                        category = cat.id,
                        betValue = values.joinToString("/"),
                        amount = totalCost,
                        odds = odds,
                        status = "待开",
                        profit = 0.0
                    )
                )
                spent += totalCost
                placed++
            } else if (cat == BetCategory.NUMBER && values.size > 1) {
                // 快乐8/定位等多码：每码一注成本，总成本 = n × 单注；命中口径与结算用展示赔率对齐
                val n = values.size.coerceAtLeast(1)
                val totalCost = currentAmount * n
                if (balance - spent < totalCost) break
                dao.insertBet(
                    BetEntity(
                        lotteryKey = lotteryKey,
                        issue = targetIssue,
                        sourceType = config.sourceType,
                        sourceId = config.sourceId,
                        category = cat.id,
                        betValue = values.joinToString("/"),
                        amount = totalCost,
                        odds = BetOdds.resolveForBet(BetCategory.NUMBER, values, lotteryKey),
                        status = "待开",
                        profit = 0.0
                    )
                )
                spent += totalCost
                placed++
            } else {
                // 大小/单双:每方向一注
                for (value in values) {
                    val playHint = value.substringBefore(":", "").takeIf { ":" in value }.orEmpty()
                    val bare = value.substringAfter(":").takeIf { ":" in value } ?: value
                    val odds = BetOdds.resolveForBet(cat, listOf(bare), lotteryKey, playHint)
                    if (balance - spent < currentAmount) break
                    dao.insertBet(
                        BetEntity(
                            lotteryKey = lotteryKey,
                            issue = targetIssue,
                            sourceType = config.sourceType,
                            sourceId = config.sourceId,
                            category = cat.id,
                            betValue = bare,
                            amount = currentAmount,
                            odds = odds,
                            status = "待开",
                            profit = 0.0
                        )
                    )
                    spent += currentAmount
                    placed++
                }
            }
        }
        if (spent > 0) {
            dao.upsertWallet(
                wallet.copy(
                    balance = (balance - spent).coerceAtLeast(0.0),
                    updatedAt = System.currentTimeMillis()
                )
            )
        }
        if (placed > 0) {
            // 供无障碍「跟随挂机」只点下单结果，不读悬浮窗原预测
            try {
                fun bareDir(v: String): String = v.substringAfter(":").takeIf { ":" in v } ?: v
                val dx = picks[BetCategory.DX]?.map { bareDir(it) }?.firstOrNull { it == "大" || it == "小" }
                val ds = picks[BetCategory.DS]?.map { bareDir(it) }?.firstOrNull { it == "单" || it == "双" }
                val combo = picks[BetCategory.COMBO]?.joinToString("/")
                com.caifenxi.app.service.AutoBetController.recordPlacedPicks(
                    context = com.caifenxi.app.CaiFenXiApplication.instance,
                    lotteryKey = lotteryKey,
                    targetIssue = targetIssue,
                    dx = dx,
                    ds = ds,
                    combo = combo
                )
                // 下单缓存写入后衔接无障碍（跟随挂机时避免点到 READY 时的旧方向）
                com.caifenxi.app.service.AutoBetController.onHangUpPlaced(
                    context = com.caifenxi.app.CaiFenXiApplication.instance,
                    lotteryKey = lotteryKey,
                    targetIssue = targetIssue
                )
            } catch (_: Exception) {
            }
            return@withLock PlaceResult(placed, "已下 $placed 注 · 目标$targetIssue", pickDesc)
        }
        return@withLock PlaceResult(0, "分类与预测方向无交集", pickDesc)
    }

    /**
     * 计算本期下注金额。
     * streak 表示上一期结果方向已经连续出现了多少次。
     * 例如“对了倍投3期”: 第1/2/3个连续命中后的下一注按倍投计算,第4个连续命中后恢复基数。
     */
    private fun calcAmount(
        baseAmount: Double,
        lastAmount: Double,
        lastHit: Boolean?,
        streak: Int,
        winMult: Double,
        lossMult: Double,
        winMultPeriods: Int,
        lossMultPeriods: Int,
        maxMult: Int,
        maxCap: Double
    ): Double {
        if (lastHit == null || streak <= 0) return baseAmount
        val periods = if (lastHit) winMultPeriods else lossMultPeriods
        val mult = if (lastHit) winMult else lossMult
        if (mult <= 1.0 || streak > periods) return baseAmount
        val next = lastAmount * mult
        return next.coerceAtMost(maxCap).coerceAtLeast(baseAmount)
    }

    /** 获取某分类「上一期」金额(同期货数合并取合计,用于倍投基数) */
    private suspend fun getLastAmount(lotteryKey: String, catName: String): Double {
        val settled = dao.getBets(lotteryKey)
            .filter { it.category == catName && it.status != "待开" }
        if (settled.isEmpty()) return 0.0
        val lastIssue = settled.maxByOrNull {
            it.issue.toLongOrNull() ?: Long.MIN_VALUE
        }?.issue ?: return 0.0
        return settled.filter { it.issue == lastIssue }.sumOf { it.amount }
    }

    /**
     * 获取最近连续相同结果的「期数」(按期号聚合,同一期多注只算一期)。
     */
    private suspend fun getRecentStreak(lotteryKey: String, catName: String, targetHit: Boolean): Int {
        val settled = dao.getBets(lotteryKey)
            .filter { it.category == catName && it.status != "待开" }
        if (settled.isEmpty()) return 0
        // 期号降序:同一期任一中 → 该期记中
        val byIssue = settled.groupBy { it.issue }
            .map { (issue, list) ->
                val issueNum = issue.toLongOrNull() ?: Long.MIN_VALUE
                val hit = list.any { it.status == "中" }
                issueNum to hit
            }
            .sortedByDescending { it.first }
        var streak = 0
        for ((_, hit) in byIssue) {
            if (hit != targetHit) break
            streak++
        }
        return streak
    }

    /**
     * 用一期开奖结果结算所有待开订单,并更新各分类连对/连错追踪。
     */
    suspend fun settleWithDraw(lotteryKey: String, draw: DrawRecord) {
        val pending = dao.getPendingBefore(lotteryKey, draw.issue)
            .plus(dao.getPendingBets(lotteryKey, draw.issue))
            .distinctBy { it.id }
        if (pending.isEmpty()) return

        val wallet = dao.getWallet(lotteryKey) ?: WalletEntity(lotteryKey = lotteryKey)
        var balance = wallet.balance
        var totalProfit = wallet.totalProfit
        var totalBet = wallet.totalBet
        var win = wallet.winCount
        var lose = wallet.loseCount

        val catStreaks = lastHitMap.getOrPut(lotteryKey) { mutableMapOf() }

        // 下单时已扣本金:赢则返还本金+盈利(amount*odds),输则不再加回
        val updated = pending.map { bet ->
            val hit = judge(bet.category, bet.betValue, draw)
            val profit = if (hit) bet.amount * (bet.odds - 1.0) else -bet.amount
            if (hit) {
                balance += bet.amount * bet.odds
            }
            totalProfit += profit
            totalBet += bet.amount
            if (hit) win++ else lose++

            bet.copy(
                status = if (hit) "中" else "未中",
                profit = profit,
                settledAt = System.currentTimeMillis()
            )
        }
        // 倍投方向按分类整体判定:组合/数字位置注为多候选单注(命中任一即对),
        // 大小/单双历史遗留多注也按「该分类本期任一命中即记对」兼容
        pending.groupBy { it.category }.forEach { (cat, bets) ->
            catStreaks[cat] = bets.any { judge(it.category, it.betValue, draw) }
        }
        dao.updateBets(updated)
        dao.upsertWallet(
            wallet.copy(
                balance = balance,
                totalProfit = totalProfit,
                totalBet = totalBet,
                winCount = win,
                loseCount = lose,
                updatedAt = System.currentTimeMillis()
            )
        )
    }

    /**
     * 从 DB 历史计算收益统计 + 对错统计。
     */
    suspend fun getBetStats(lotteryKey: String): BetStats {
        val wallet = dao.getWallet(lotteryKey)
        val bets = dao.getBets(lotteryKey)

        val initial = wallet?.initialBalance ?: DEFAULT_INITIAL
        val balance = wallet?.balance ?: initial
        val totalProfit = wallet?.totalProfit ?: 0.0
        val totalBet = wallet?.totalBet ?: 0.0
        val winCount = wallet?.winCount ?: 0
        val loseCount = wallet?.loseCount ?: 0

        val settled = bets.filter { it.status != "待开" }
        val totalSettled = settled.size

        // 本期(最新期)投入与盈亏 — 期号按数值取最大
        val latestIssue = bets.filter { it.status != "待开" }
            .maxByOrNull { it.issue.toLongOrNull() ?: Long.MIN_VALUE }?.issue ?: ""
        val currentBets = bets.filter { it.issue == latestIssue }
        val currentBetAmount = currentBets.sumOf { it.amount }
        val currentProfit = currentBets.sumOf { it.profit }

        // 按分类统计对错(从历史记录重算,不依赖内存 streak)
        val byCategory = BetCategory.entries.associate { cat ->
            cat.id to buildCatStats(cat.id, bets)
        }

        // 收益曲线:按期号聚合(同期货数合并),避免一注一个点导致曲线挤成一团/看似空白
        val issueOrder = settled
            .groupBy { it.issue }
            .map { (issue, list) ->
                val num = issue.toLongOrNull() ?: Long.MIN_VALUE
                val profit = list.sumOf { it.profit }
                val hit = list.any { it.status == "中" }
                Triple(num, issue, profit to hit)
            }
            .sortedBy { it.first }
        var running = 0.0
        var peak = 0.0
        var maxDD = 0.0
        var maxDDPct = 0.0
        val curve = mutableListOf<ProfitPoint>()
        issueOrder.forEachIndexed { idx, (_, issue, pair) ->
            val (profit, hit) = pair
            running += profit
            if (running > peak) peak = running
            val dd = peak - running
            val ddPct = if (peak > 0) dd / peak else 0.0
            if (dd > maxDD) maxDD = dd
            if (ddPct > maxDDPct) maxDDPct = ddPct
            curve.add(
                ProfitPoint(
                    issueIndex = idx,
                    issue = issue,
                    cumulativeProfit = running,
                    hit = hit,
                    drawdown = dd,
                    drawdownPct = ddPct
                )
            )
        }

        // 最长连对/连错(按期)
        var maxHitStreak = 0
        var maxMissStreak = 0
        var curHit = 0
        var curMiss = 0
        issueOrder.forEach { (_, _, pair) ->
            if (pair.second) {
                curHit++; curMiss = 0
                if (curHit > maxHitStreak) maxHitStreak = curHit
            } else {
                curMiss++; curHit = 0
                if (curMiss > maxMissStreak) maxMissStreak = curMiss
            }
        }

        return BetStats(
            initialBalance = initial,
            balance = balance,
            totalProfit = totalProfit,
            totalBet = totalBet,
            profitRate = if (initial > 0) totalProfit / initial else 0.0,
            totalSettled = totalSettled,
            winCount = winCount,
            loseCount = loseCount,
            winRate = if (totalSettled > 0) winCount.toDouble() / totalSettled else 0.0,
            currentBetAmount = currentBetAmount,
            currentProfit = currentProfit,
            byCategory = byCategory,
            profitCurve = curve,
            maxDrawdown = maxDD,
            maxDrawdownPct = maxDDPct,
            peakProfit = peak,
            maxHitStreak = maxHitStreak,
            maxMissStreak = maxMissStreak
        )
    }

    private fun buildCatStats(catName: String, allBets: List<BetEntity>): CatBetStats {
        val catBets = allBets.filter { it.category == catName && it.status != "待开" }
            .sortedBy { it.settledAt ?: Long.MAX_VALUE }

        val hit = catBets.count { it.status == "中" }
        val miss = catBets.size - hit
        val settled = catBets.size

        // 计算连对/连错
        var recent = 0
        var curStreak = 0
        var maxHit = 0
        var maxMiss = 0
        catBets.reversed().forEach { b ->
            val isHit = b.status == "中"
            if (curStreak >= 0) {
                if (isHit) { curStreak++; maxHit = maxOf(maxHit, curStreak) }
                else { curStreak = -1; maxMiss = maxOf(maxMiss, 1) }
            } else {
                if (!isHit) { curStreak--; maxMiss = maxOf(maxMiss, -curStreak) }
                else { curStreak = 1; maxHit = maxOf(maxHit, 1) }
            }
        }
        // recentStreak: 正=连对,负=连错
        recent = curStreak

        // 两期/三期滚动窗口率(与共识口径一致:窗口内至少 1 次中 = 对窗口)
        // 与 hit/miss 同样按注统计;内部按结算时序升序已保证。
        val results = catBets.map { if (it.status == "中") "对" else "错" }
        val (w2, w2Hit, w2Miss) = StreakCalc.windowRates(results, 2)
        val (w3, w3Hit, w3Miss) = StreakCalc.windowRates(results, 3)

        return CatBetStats(
            catName = BetCategory.fromId(catName)?.label ?: catName,
            settled = settled,
            hit = hit,
            miss = miss,
            winRate = if (settled > 0) hit.toDouble() / settled else 0.0,
            profit = catBets.sumOf { it.profit },
            recentStreak = recent,
            maxHitStreak = maxHit,
            maxMissStreak = maxMiss,
            twoWindows = w2,
            twoHitRate = if (w2 > 0) w2Hit.toDouble() / w2 else 0.0,
            twoMissRate = if (w2 > 0) w2Miss.toDouble() / w2 else 0.0,
            threeWindows = w3,
            threeHitRate = if (w3 > 0) w3Hit.toDouble() / w3 else 0.0,
            threeMissRate = if (w3 > 0) w3Miss.toDouble() / w3 else 0.0
        )
    }

    /** 判定一注是否命中。组合/数字位置注可含多候选(以 / 、 , 分隔),命中任一即中 */
    private fun judge(category: String, betValue: String, draw: DrawRecord): Boolean {
        val cands = betValue.split("/", "、", ",").map { it.trim() }.filter { it.isNotEmpty() }
        if (cands.isEmpty()) return false
        return when (BetCategory.fromId(category)) {
            BetCategory.DX -> cands.any { it == draw.dx }
            BetCategory.DS -> cands.any { it == draw.ds }
            BetCategory.COMBO -> cands.any { it == draw.combo }
            BetCategory.NUMBER -> cands.any { cand ->
                val parts = cand.split("=")
                when {
                    // 快乐8 任选：格式「任选号码=12」或纯数字，与开奖任一号码相同即中
                    parts.size == 2 && (parts[0] == "任选号码" || parts[0] == "号码池") -> {
                        val num = parts[1].toIntOrNull() ?: return@any false
                        draw.numbers.any { it == num }
                    }
                    parts.size == 1 -> {
                        val num = parts[0].toIntOrNull() ?: return@any false
                        draw.numbers.any { it == num }
                    }
                    parts.size == 2 -> {
                        val posIdx = PksPositions.NAMES.indexOf(parts[0])
                        if (posIdx < 0) {
                            // 未知位置名：回落为任选号码口径
                            val num = parts[1].toIntOrNull() ?: return@any false
                            draw.numbers.any { it == num }
                        } else {
                            val num = parts[1].toIntOrNull() ?: return@any false
                            draw.numberAt(posIdx) == num
                        }
                    }
                    else -> false
                }
            }
            null -> false
        }
    }

    suspend fun ensureWallet(lotteryKey: String, initialBalance: Double): WalletEntity {
        val existing = dao.getWallet(lotteryKey)
        if (existing != null) return existing
        val w = WalletEntity(lotteryKey = lotteryKey, initialBalance = initialBalance, balance = initialBalance)
        dao.upsertWallet(w)
        return w
    }

    /**
     * 从已结算订单回填各分类最近一次对错,供倍投在进程重启后仍正确延续。
     * 仅在该 lotteryKey 内存缓存为空时执行一次。
     */
    private suspend fun ensureLastHitFromDb(lotteryKey: String) {
        val map = lastHitMap.getOrPut(lotteryKey) { mutableMapOf() }
        if (map.isNotEmpty()) return
        val bets = dao.getBets(lotteryKey)
            .filter { it.status != "待开" }
            .sortedByDescending { it.settledAt ?: it.createdAt }
        for (bet in bets) {
            if (map.containsKey(bet.category)) continue
            map[bet.category] = bet.status == "中"
        }
    }

    /** 清空挂机订单和钱包统计,但保留 bot_config 策略。 */
    suspend fun resetBetOverview(lotteryKey: String, initialBalance: Double = DEFAULT_INITIAL) {
        dao.clearBets(lotteryKey)
        dao.upsertWallet(
            WalletEntity(
                lotteryKey = lotteryKey,
                initialBalance = initialBalance,
                balance = initialBalance,
                updatedAt = System.currentTimeMillis()
            )
        )
        lastHitMap.remove(lotteryKey)
    }

    /**
     * 仅清空订单历史。待开单会把已扣本金退回钱包,避免「清历史吞掉待开本金」。
     */
    suspend fun clearBetsRefundPending(lotteryKey: String) {
        val all = dao.getBets(lotteryKey)
        val pendingAmount = all.filter { it.status == "待开" }.sumOf { it.amount }
        dao.clearBets(lotteryKey)
        lastHitMap.remove(lotteryKey)
        if (pendingAmount > 0) {
            val wallet = dao.getWallet(lotteryKey) ?: return
            dao.upsertWallet(
                wallet.copy(
                    balance = wallet.balance + pendingAmount,
                    updatedAt = System.currentTimeMillis()
                )
            )
        }
    }

    // ---- 来源解析 ----

    /** 反投：大小/单双/组合取反；数字（位置号码）保持不变 */
    private fun invertPicks(picks: Map<BetCategory, List<String>>): Map<BetCategory, List<String>> {
        if (picks.isEmpty()) return picks
        val out = mutableMapOf<BetCategory, List<String>>()
        for ((cat, values) in picks) {
            out[cat] = when (cat) {
                BetCategory.DX -> values.map { v ->
                    when (v.trim()) {
                        "大" -> "小"
                        "小" -> "大"
                        else -> v
                    }
                }
                BetCategory.DS -> values.map { v ->
                    when (v.trim()) {
                        "单" -> "双"
                        "双" -> "单"
                        else -> v
                    }
                }
                BetCategory.COMBO -> values.map { v ->
                    when (v.trim()) {
                        "大单" -> "小双"
                        "大双" -> "小单"
                        "小单" -> "大双"
                        "小双" -> "大单"
                        else -> v
                    }
                }
                BetCategory.NUMBER -> values // 号码不取反
            }
        }
        return out
    }

    /**
     * 解析各分类的下注候选值。
     * 返回 Map<分类, 候选列表>:同一分类可有多个候选(组合 TopN / 位置 TopN / 共识多候选),
     * 每个候选各下一注。空值候选会被忽略。
     */
    private fun resolvePicks(
        config: BotConfigEntity,
        prediction: PredictionSnapshot?,
        planPredictions: List<PlanPredictionRecord>,
        consensus: List<ModelConsensus>,
        history: List<DrawRecord> = emptyList()
    ): Map<BetCategory, List<String>> {
        return when (BetSourceType.fromId(config.sourceType)) {
            BetSourceType.COCKPIT, BetSourceType.ALGO -> resolveAlgo(config.numberPosition, prediction)
            BetSourceType.PLAN, BetSourceType.NOVA, BetSourceType.FAVORITE -> {
                val multi = listOf(config.sourceIdDx, config.sourceIdDs, config.sourceIdCombo)
                    .map { it.ifBlank { config.sourceId } }
                    .distinct()
                    .size > 1
                // 多计划 或 用户主动开启滚动：用图表同款现算
                // 收藏计划不再强制滚动，可直接跟随工作台/引擎已生成的计划预测
                if ((config.rollingPredict || multi) && history.size >= 6) {
                    resolveRollingMulti(config, history)
                } else {
                    resolvePlanMulti(config, planPredictions)
                }
            }
            BetSourceType.AUTO_BEST -> {
                val bestId = planPredictions
                    .filter { !it.settled }
                    .groupBy { it.planId }
                    .maxByOrNull { (_, records) -> records.maxOfOrNull { it.scoreAtPredict } ?: Double.NEGATIVE_INFINITY }
                    ?.key
                if (bestId.isNullOrBlank()) emptyMap() else resolvePlan(bestId, planPredictions)
            }
            // 计划引擎共识 / 新计划共识：解析逻辑相同，数据列表由调用方传入对应独立源
            BetSourceType.CONSENSUS, BetSourceType.NOVA_CONSENSUS -> resolveConsensus(consensus)
        }
    }

    private fun resolveAlgo(positionIndex: Int, prediction: PredictionSnapshot?): Map<BetCategory, List<String>> {
        if (prediction == null) return emptyMap()
        val map = mutableMapOf<BetCategory, MutableList<String>>()
        prediction.dx?.direction?.let { map.getOrPut(BetCategory.DX) { mutableListOf() }.add(it) }
        prediction.ds?.direction?.let { map.getOrPut(BetCategory.DS) { mutableListOf() }.add(it) }
        prediction.combo?.direction?.let { map.getOrPut(BetCategory.COMBO) { mutableListOf() }.add(it) }
        val pos = prediction.positions.getOrNull(positionIndex) ?: prediction.positions.firstOrNull()
        if (pos != null) {
            val name = pos.positionName
            if (name == "任选号码" || name == "号码池") {
                // 快乐8：TopN 全部作为任选候选（每号一注或合并一注由上层决定）
                pos.topNumbers.forEach { ns ->
                    map.getOrPut(BetCategory.NUMBER) { mutableListOf() }.add("任选号码=${ns.number}")
                }
            } else {
                pos.topNumbers.firstOrNull()?.number?.let {
                    map.getOrPut(BetCategory.NUMBER) { mutableListOf() }.add("${PksPositions.nameAt(pos.positionIndex)}=$it")
                }
            }
        }
        return map
    }

    /**
     * 计划模型来源:按计划类别解析多候选输出(以 / 、 , 分隔)。
     * - 大小/单双: 单候选
     * - 组合: 多候选「大单/大双」全下
     * - 位置-冠军/亚军/第3: 多候选号码 → 「位置=号码」全下
     * - 号码: 无位置信息无法下注,跳过
     */

    private fun resolvePlanMulti(
        config: BotConfigEntity,
        planPredictions: List<PlanPredictionRecord>
    ): Map<BetCategory, List<String>> {
        val dxId = config.sourceIdDx.ifBlank { config.sourceId }
        val dsId = config.sourceIdDs.ifBlank { config.sourceId }
        val comboId = config.sourceIdCombo.ifBlank { config.sourceId }
        if (dxId == dsId && dsId == comboId) {
            return resolvePlan(config.sourceId, planPredictions)
        }
        val map = mutableMapOf<BetCategory, MutableList<String>>()
        fun take(id: String, only: BetCategory) {
            if (id.isBlank()) return
            resolvePlan(id, planPredictions)[only]?.let { v ->
                map.getOrPut(only) { mutableListOf() }.addAll(v)
            }
        }
        take(dxId, BetCategory.DX)
        take(dsId, BetCategory.DS)
        take(comboId, BetCategory.COMBO)
        return map.mapValues { (_, v) -> v.distinct() }
    }

    private fun resolveRollingMulti(
        config: BotConfigEntity,
        history: List<DrawRecord>
    ): Map<BetCategory, List<String>> {
        val dxId = config.sourceIdDx.ifBlank { config.sourceId }
        val dsId = config.sourceIdDs.ifBlank { config.sourceId }
        val comboId = config.sourceIdCombo.ifBlank { config.sourceId }
        if (dxId == dsId && dsId == comboId) {
            return resolveRollingPlan(config, history)
        }
        val map = mutableMapOf<BetCategory, MutableList<String>>()
        fun take(id: String, only: BetCategory) {
            if (id.isBlank()) return
            val cfg = config.copy(sourceId = id)
            resolveRollingPlan(cfg, history)[only]?.let { v ->
                map.getOrPut(only) { mutableListOf() }.addAll(v)
            }
        }
        take(dxId, BetCategory.DX)
        take(dsId, BetCategory.DS)
        take(comboId, BetCategory.COMBO)
        return map.mapValues { (_, v) -> v.distinct() }
    }

    /**
     * 图表同款滚动现算：NovaPlanAnalytics.predict + 可选反投。
     * 方向与工作台「下一期」现算一致；一期/二期/三期口径由 config.rollingStage 决定轮次追号与倍投期数，
     * 不必开启滚动也能在挂机页切换口径并跟随工作台已有预测（非滚动走 resolvePlanMulti）。
     */
    private fun resolveRollingPlan(
        config: BotConfigEntity,
        history: List<DrawRecord>
    ): Map<BetCategory, List<String>> {
        val planId = config.sourceId
        // 按 lotteryKey 校验，拒绝跨彩种计划
        val type = LotteryConfig.findByKey(config.lotteryKey)?.type
        val plan = (
            if (type != null) {
                LotteryPlanPools.find(planId, type)
                    ?: LotteryPlanPools.findAny(planId)?.takeIf { LotteryPlanPools.belongsTo(it, type) }
            } else {
                LotteryPlanPools.findAny(planId)
            }
        ) ?: return emptyMap()
        val ordered = history.sortedWith(
            compareBy<DrawRecord> { it.issue.toLongOrNull() ?: Long.MIN_VALUE }.thenBy { it.issue }
        )
        val pred = NovaPlanAnalytics.predict(plan, ordered) ?: return emptyMap()
        val invert = config.betMode.equals("reverse", ignoreCase = true)
        val out = if (invert) NovaPlanAnalytics.invertPrediction(plan.playType, pred.output) else pred.output
        val parts = out.split("/", "、", ",").map { it.trim() }.filter { it.isNotEmpty() }
        val map = mutableMapOf<BetCategory, MutableList<String>>()
        when (plan.playType) {
            "名次大小" -> parts.firstOrNull { it == "大" || it == "小" }?.let {
                map[BetCategory.DX] = mutableListOf("名次大小:$it")
            }
            "名次单双" -> parts.firstOrNull { it == "单" || it == "双" }?.let {
                map[BetCategory.DS] = mutableListOf("名次单双:$it")
            }
            "大小", "和值大小", "球大小" -> parts.firstOrNull { it == "大" || it == "小" }?.let {
                map[BetCategory.DX] = mutableListOf(it)
            }
            "单双", "球单双" -> parts.firstOrNull { it == "单" || it == "双" }?.let {
                map[BetCategory.DS] = mutableListOf(it)
            }
            "龙虎" -> parts.firstOrNull { it == "龙" || it == "虎" }?.let {
                // 暂用组合槽承载龙虎（挂机分类勾选「组合」时生效）
                map[BetCategory.COMBO] = mutableListOf(it)
            }
            "组合" -> {
                val combos = parts.filter { it in listOf("大单", "大双", "小单", "小双") }.distinct()
                if (combos.isNotEmpty()) map[BetCategory.COMBO] = combos.toMutableList()
            }
            "位置", "数字", "定位", "三军", "鱼虾蟹" -> {
                val nums = parts.mapNotNull { it.toIntOrNull() }.distinct()
                if (nums.isNotEmpty()) {
                    val posName = when (plan.playType) {
                        "定位" -> "第${plan.positionIndex.coerceIn(0, 5) + 1}球"
                        "位置" -> PksPositions.nameAt(plan.positionIndex.coerceIn(0, 9))
                        "三军", "鱼虾蟹" -> "三军"
                        else -> PksPositions.nameAt(config.numberPosition.coerceIn(0, 9))
                    }
                    map[BetCategory.NUMBER] = nums.map { "$posName=$it" }.toMutableList()
                }
            }
            "长牌" -> {
                if (parts.isNotEmpty()) map[BetCategory.NUMBER] = parts.map { "长牌=$it" }.toMutableList()
            }
        }
        return map
    }

    private fun resolvePlan(planId: String, planPredictions: List<PlanPredictionRecord>): Map<BetCategory, List<String>> {
        // 精确匹配计划ID;每期随机计划会换 ID,找不到时兜底取任意未结算预测
        val matched = planPredictions.filter { it.planId == planId }
        val pool = when {
            matched.any { !it.settled } -> matched.filter { !it.settled }
            matched.isNotEmpty() -> matched
            planPredictions.any { !it.settled } -> planPredictions.filter { !it.settled }
            else -> planPredictions
        }
        if (pool.isEmpty()) return emptyMap()

        val map = mutableMapOf<BetCategory, MutableList<String>>()
        // Nova 精确计划：根据 playType/position 元数据解析，保证“新计划池 → 挂机”真正闭环。
        val nova = NovaPlanPool.find(planId)
        if (nova != null) {
            val rec = pool.firstOrNull { it.planId == planId } ?: pool.firstOrNull()
            if (rec != null) {
                val parts = rec.output.split("/", "、", ",").map { it.trim() }.filter { it.isNotEmpty() }
                when (nova.playType) {
                    "大小" -> parts.firstOrNull { it == "大" || it == "小" }?.let { map[BetCategory.DX] = mutableListOf(it) }
                    "单双" -> parts.firstOrNull { it == "单" || it == "双" }?.let { map[BetCategory.DS] = mutableListOf(it) }
                    "组合" -> parts.filter { it in listOf("大单", "大双", "小单", "小双") }.distinct().take(4).let { if (it.isNotEmpty()) map[BetCategory.COMBO] = it.toMutableList() }
                    "位置" -> {
                        val pos = nova.positionIndex.coerceIn(0, PksPositions.NAMES.lastIndex)
                        val name = PksPositions.nameAt(pos)
                        val nums = parts.mapNotNull { it.toIntOrNull() }.distinct()
                        if (nums.isNotEmpty()) map[BetCategory.NUMBER] = nums.map { "$name=$it" }.toMutableList()
                    }
                    "数字" -> {
                        // 数字计划没有固定位置；仅当挂机已选择位置时下注该位置的候选。
                        val pos = PksPositions.nameAt(0)
                        val nums = parts.mapNotNull { it.toIntOrNull() }.distinct()
                        if (nums.isNotEmpty()) map[BetCategory.NUMBER] = nums.map { "$pos=$it" }.toMutableList()
                    }
                }
            }
            if (map.isNotEmpty()) return map
        }
        // 同一分类取一条(优先匹配 planId 的)
        val byCat = pool.groupBy { it.category.ifBlank { "大小" } }
        for ((cat, list) in byCat) {
            val rec = list.firstOrNull { it.planId == planId } ?: list.first()
            val parts = rec.output.split("/", "、", ",").map { it.trim() }.filter { it.isNotEmpty() }
            if (parts.isEmpty()) continue
            when (cat) {
                "大小" -> {
                    val dir = parts.firstOrNull { it == "大" || it == "小" }
                    if (dir != null) map[BetCategory.DX] = mutableListOf(dir)
                }
                "单双" -> {
                    val dir = parts.firstOrNull { it == "单" || it == "双" }
                    if (dir != null) map[BetCategory.DS] = mutableListOf(dir)
                }
                "组合" -> parts.forEach {
                    if (it in listOf("大单", "大双", "小单", "小双")) {
                        map.getOrPut(BetCategory.COMBO) { mutableListOf() }.add(it)
                    }
                }
                "位置-冠军", "位置-亚军", "位置-第3" -> {
                    val pos = when (cat) {
                        "位置-冠军" -> 0
                        "位置-亚军" -> 1
                        else -> 2
                    }
                    val name = PksPositions.nameAt(pos)
                    parts.forEach { num ->
                        num.toIntOrNull()?.let { map.getOrPut(BetCategory.NUMBER) { mutableListOf() }.add("$name=$it") }
                    }
                }
                else -> parts.forEach { p ->
                    when (p) {
                        in listOf("大单", "大双", "小单", "小双") -> map.getOrPut(BetCategory.COMBO) { mutableListOf() }.add(p)
                        in listOf("大", "小") -> map.getOrPut(BetCategory.DX) { mutableListOf() }.add(p)
                        in listOf("单", "双") -> map.getOrPut(BetCategory.DS) { mutableListOf() }.add(p)
                    }
                }
            }
        }
        return map
    }

    /**
     * 共识来源。
     * - 大小/单双:只取该分类一条共识的主方向(禁止同时下大+小 / 单+双,否则必中、倍投失效)
     * - 组合:可多候选合并一注,赔率按覆盖数递减
     * - 位置:多号码合并为数字注
     */
    private fun resolveConsensus(consensus: List<ModelConsensus>): Map<BetCategory, List<String>> {
        val map = mutableMapOf<BetCategory, MutableList<String>>()
        // 每个分类只处理第一条共识(已是加权领先方向)
        val byCat = consensus.groupBy { it.category }
        for ((cat, list) in byCat) {
            val c = list.first()
            val cands = c.leadingDirection.split("/", "、", ",")
                .map { it.trim() }.filter { it.isNotEmpty() }
            when (cat) {
                "大小" -> {
                    val dir = cands.firstOrNull { it == "大" || it == "小" } ?: continue
                    map[BetCategory.DX] = mutableListOf(dir)
                }
                "单双" -> {
                    val dir = cands.firstOrNull { it == "单" || it == "双" } ?: continue
                    map[BetCategory.DS] = mutableListOf(dir)
                }
                "组合" -> {
                    val vals = cands.filter { it in listOf("大单", "大双", "小单", "小双") }.distinct()
                    if (vals.isNotEmpty()) map[BetCategory.COMBO] = vals.toMutableList()
                }
                "位置-冠军" -> {
                    val vals = cands.mapNotNull { n -> n.toIntOrNull()?.let { "冠军=$it" } }.distinct()
                    if (vals.isNotEmpty()) map[BetCategory.NUMBER] = vals.toMutableList()
                }
                "位置-亚军" -> {
                    val vals = cands.mapNotNull { n -> n.toIntOrNull()?.let { "亚军=$it" } }.distinct()
                    if (vals.isNotEmpty()) {
                        map.getOrPut(BetCategory.NUMBER) { mutableListOf() }.addAll(vals)
                    }
                }
                "位置-第3" -> {
                    val vals = cands.mapNotNull { n -> n.toIntOrNull()?.let { "第3=$it" } }.distinct()
                    if (vals.isNotEmpty()) {
                        map.getOrPut(BetCategory.NUMBER) { mutableListOf() }.addAll(vals)
                    }
                }
            }
        }
        return map
    }
}
