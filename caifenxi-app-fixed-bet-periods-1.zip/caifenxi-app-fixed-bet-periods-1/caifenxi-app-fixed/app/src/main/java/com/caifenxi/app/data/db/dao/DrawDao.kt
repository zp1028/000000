package com.caifenxi.app.data.db.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.caifenxi.app.data.db.entity.DrawEntity

@Dao
interface DrawDao {
    @Query("SELECT * FROM draws WHERE lotteryKey = :key ORDER BY issue ASC")
    suspend fun getByLottery(key: String): List<DrawEntity>

    @Query("SELECT * FROM draws ORDER BY lotteryKey ASC, issue ASC")
    suspend fun getAll(): List<DrawEntity>

    @Query("SELECT * FROM draws WHERE lotteryKey = :key ORDER BY issue DESC LIMIT 1")
    suspend fun getLatest(key: String): DrawEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(items: List<DrawEntity>)

    @Query("DELETE FROM draws WHERE lotteryKey = :key")
    suspend fun clearLottery(key: String)

    @Query("DELETE FROM draws")
    suspend fun deleteAll()
}
