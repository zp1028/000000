#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if command -v gradle >/dev/null 2>&1; then
  gradle --no-daemon assembleDebug
elif [ -f gradle/wrapper/gradle-wrapper.jar ]; then
  chmod +x ./gradlew
  ./gradlew --no-daemon assembleDebug
else
  echo "ERROR: Gradle 8.9 is required. No system gradle and no Gradle Wrapper JAR found."
  echo "Use the GitHub Actions workflow or install Gradle 8.9 locally."
  exit 2
fi
echo "APK: app/build/outputs/apk/debug/app-debug.apk"
