package com.caifenxi.app.domain.btc.factor

import kotlin.math.abs
import kotlin.math.sqrt

/**
 * Factor research layer: IC/ICIR/decay/correlation and regime-conditioned weights.
 * Designed for expanding/walk-forward research; callers supply PIT factor snapshots and
 * future returns, so this class never manufactures future data.
 */
object QuantFactorResearchV2 {
    data class Observation(val factorId: String, val value: Double, val forwardReturn: Double, val regime: String = "ALL", val barTime: Long = 0L)
    data class Metric(val factorId: String, val regime: String, val samples: Int, val ic: Double, val icir: Double, val hitRate: Double, val decay: List<Double>)
    data class PairCorrelation(val left: String, val right: String, val correlation: Double)
    data class ResearchReport(val metrics: List<Metric>, val correlations: List<PairCorrelation>, val orthogonalWeights: Map<String, Double>)

    fun report(observations: List<Observation>, factorIds: List<String>, decayHorizons: List<Int> = listOf(1,3,6,12,24)): ResearchReport {
        val metrics = factorIds.flatMap { id ->
            observations.filter { it.factorId == id }.groupBy { it.regime }.map { (regime, rows) ->
                val ic = pearson(rows.map { it.value }, rows.map { it.forwardReturn })
                val hit = if (rows.isEmpty()) 0.0 else rows.count { (it.value >= 0.0) == (it.forwardReturn >= 0.0) }.toDouble() / rows.size
                val decay = decayHorizons.map { h ->
                    val ordered = rows.sortedBy { it.barTime }
                    if (ordered.size < h + 8) 0.0 else {
                        val paired = ordered.dropLast(h).zip(ordered.drop(h))
                        pearson(paired.map { it.first.value }, paired.map { it.second.forwardReturn })
                    }
                }
                val icir = rollingIcIr(rows, 20)
                Metric(id, regime, rows.size, ic, icir, hit, decay)
            }
        }
        val all = observations.groupBy { it.factorId }
        val correlations = buildList {
            for (i in factorIds.indices) for (j in i + 1 until factorIds.size) {
                val a = all[factorIds[i]].orEmpty().associateBy { it.barTime to it.regime }
                val b = all[factorIds[j]].orEmpty().associateBy { it.barTime to it.regime }
                val keys = a.keys.intersect(b.keys).filter { it.first != 0L }
                if (keys.size >= 8) add(PairCorrelation(factorIds[i], factorIds[j], pearson(keys.map { a[it]!!.value }, keys.map { b[it]!!.value })))
            }
        }
        val weights = orthogonalWeights(metrics, correlations)
        return ResearchReport(metrics, correlations, weights)
    }

    private fun orthogonalWeights(metrics: List<Metric>, correlations: List<PairCorrelation>): Map<String, Double> {
        val base = metrics.filter { it.regime == "ALL" || metrics.none { m -> m.factorId == it.factorId && m.regime == "ALL" } }
            .groupBy { it.factorId }.mapValues { (_, ms) -> ms.maxOfOrNull { abs(it.ic) * (0.5 + it.icir.coerceAtLeast(0.0) * 0.5) } ?: 0.0 }
        return base.mapValues { (id, score) ->
            val redundancy = correlations.filter { it.left == id || it.right == id }.map { abs(it.correlation) }.average().takeIf { !it.isNaN() } ?: 0.0
            (score * (1.0 - redundancy * 0.65)).coerceAtLeast(0.0)
        }.let { m ->
            val s = m.values.sum().coerceAtLeast(1e-9); m.mapValues { it.value / s }
        }
    }

    private fun rollingIcIr(rows: List<Observation>, window: Int): Double {
        if (rows.size < window * 2) return 0.0
        val ics = rows.windowed(window, 1).map { pearson(it.map(Observation::value), it.map(Observation::forwardReturn)) }
        val mean = ics.average(); val sd = sqrt(ics.map { (it - mean) * (it - mean) }.average().coerceAtLeast(1e-12))
        return if (sd == 0.0) 0.0 else mean / sd
    }

    private fun pearson(a: List<Double>, b: List<Double>): Double {
        if (a.size != b.size || a.size < 4) return 0.0
        val ma = a.average(); val mb = b.average()
        val num = a.indices.sumOf { (a[it] - ma) * (b[it] - mb) }
        val da = sqrt(a.sumOf { (it - ma) * (it - ma) }).coerceAtLeast(1e-12)
        val db = sqrt(b.sumOf { (it - mb) * (it - mb) }).coerceAtLeast(1e-12)
        return (num / (da * db)).coerceIn(-1.0, 1.0)
    }
}
