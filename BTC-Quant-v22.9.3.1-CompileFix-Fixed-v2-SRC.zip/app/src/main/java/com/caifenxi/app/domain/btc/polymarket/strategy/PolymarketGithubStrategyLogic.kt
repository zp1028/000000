package com.caifenxi.app.domain.btc.polymarket.strategy

import com.caifenxi.app.domain.btc.BtcDirection

/**
 * Reimplementation of the public strategy rules documented by the referenced
 * GitHub projects. This is not copied source code; it is a native Kotlin
 * strategy-rule layer with explicit provenance.
 */
object PolymarketGithubStrategyLogic {
    data class Config(
        val minBtcDeltaUsd: Double = 20.0,
        val minFavoriteOdds: Double = 0.72,
        val maxEntryOdds: Double = 0.95,
        val minContrarianFavorite: Double = 0.80,
        val maxContrarianUnderdog: Double = 0.35,
        val minMomentumMove: Double = 0.0025,
        val minConvergenceProbability: Double = 0.65,
        val maxConvergenceProbability: Double = 0.96,
        val minEntrySeconds: Long = 45L,
        val maxEntrySeconds: Long = 270L,
        val minSecondsToClose: Long = 15L,
        val maxSpread: Double = 0.04
    )

    data class Context(
        val currentBtc: Double?,
        val priceToBeat: Double?,
        val elapsedSec: Long?,
        val remainingSec: Long?,
        val upPrice: Double,
        val downPrice: Double,
        val btcReturn15m: Double = 0.0,
        val volumeRatio: Double = 1.0,
        val orderbookImbalance: Double = 0.0,
        val spread: Double = 1.0
    )

    data class Decision(
        val direction: BtcDirection,
        val reason: String,
        val ruleScore: Double
    )

    fun entryWindowOpen(ctx: Context, c: Config = Config()): Boolean {
        val elapsed = ctx.elapsedSec ?: return true
        val remaining = ctx.remainingSec
        if (elapsed < c.minEntrySeconds || elapsed > c.maxEntrySeconds) return false
        if (remaining != null && remaining <= c.minSecondsToClose) return false
        return true
    }

    fun btcDelta(ctx: Context): Double? = if (ctx.currentBtc != null && ctx.priceToBeat != null) {
        ctx.currentBtc - ctx.priceToBeat
    } else null

    fun btcMomentum(ctx: Context, c: Config = Config()): Decision? {
        val delta = btcDelta(ctx)
        val d = when {
            delta != null && delta >= c.minBtcDeltaUsd -> BtcDirection.UP
            delta != null && delta <= -c.minBtcDeltaUsd -> BtcDirection.DOWN
            delta != null && delta > 0 && ctx.upPrice >= c.minFavoriteOdds -> BtcDirection.UP
            delta != null && delta < 0 && ctx.downPrice >= c.minFavoriteOdds -> BtcDirection.DOWN
            delta == null && ctx.btcReturn15m >= c.minMomentumMove && ctx.volumeRatio >= 1.0 -> BtcDirection.UP
            delta == null && ctx.btcReturn15m <= -c.minMomentumMove && ctx.volumeRatio >= 1.0 -> BtcDirection.DOWN
            else -> return null
        }
        return Decision(d, "btc_momentum delta=${delta?.let { "%.2f".format(it) } ?: "n/a"} odds=${"%.2f/%.2f".format(ctx.upPrice, ctx.downPrice)}", 1.0)
    }

    fun oddsFavorite(ctx: Context, c: Config = Config()): Decision? = when {
        ctx.upPrice >= c.minFavoriteOdds && ctx.upPrice >= ctx.downPrice -> Decision(BtcDirection.UP, "odds_favorite up=${"%.3f".format(ctx.upPrice)}", 0.9)
        ctx.downPrice >= c.minFavoriteOdds && ctx.downPrice >= ctx.upPrice -> Decision(BtcDirection.DOWN, "odds_favorite down=${"%.3f".format(ctx.downPrice)}", 0.9)
        else -> null
    }

    fun btcAndOdds(ctx: Context, c: Config = Config()): Decision? {
        val delta = btcDelta(ctx) ?: return null
        return when {
            delta >= c.minBtcDeltaUsd && ctx.upPrice >= c.minFavoriteOdds -> Decision(BtcDirection.UP, "btc_and_odds up", 1.0)
            delta <= -c.minBtcDeltaUsd && ctx.downPrice >= c.minFavoriteOdds -> Decision(BtcDirection.DOWN, "btc_and_odds down", 1.0)
            else -> null
        }
    }

    fun btcOrOdds(ctx: Context, c: Config = Config()): Decision? {
        val delta = btcDelta(ctx)
        return when {
            delta != null && delta >= c.minBtcDeltaUsd || ctx.upPrice >= c.minFavoriteOdds && ctx.upPrice >= ctx.downPrice ->
                Decision(BtcDirection.UP, "btc_or_odds up", 0.85)
            delta != null && delta <= -c.minBtcDeltaUsd || ctx.downPrice >= c.minFavoriteOdds && ctx.downPrice >= ctx.upPrice ->
                Decision(BtcDirection.DOWN, "btc_or_odds down", 0.85)
            else -> null
        }
    }

    fun contrarian(ctx: Context, c: Config = Config()): Decision? = when {
        ctx.upPrice >= c.minContrarianFavorite && ctx.downPrice <= c.maxContrarianUnderdog ->
            Decision(BtcDirection.DOWN, "contrarian: fade expensive Up", 0.75)
        ctx.downPrice >= c.minContrarianFavorite && ctx.upPrice <= c.maxContrarianUnderdog ->
            Decision(BtcDirection.UP, "contrarian: fade expensive Down", 0.75)
        else -> null
    }

    fun btcMeanRevert(ctx: Context, c: Config = Config()): Decision? {
        val delta = btcDelta(ctx) ?: return null
        return when {
            delta <= -c.minBtcDeltaUsd -> Decision(BtcDirection.UP, "btc_mean_revert: fade Down", 0.72)
            delta >= c.minBtcDeltaUsd -> Decision(BtcDirection.DOWN, "btc_mean_revert: fade Up", 0.72)
            else -> null
        }
    }

    fun momentum15m(ctx: Context, c: Config = Config()): Decision? = when {
        ctx.btcReturn15m >= c.minMomentumMove && ctx.upPrice >= ctx.downPrice -> Decision(BtcDirection.UP, "momentum 15m + volume=${"%.2f".format(ctx.volumeRatio)}", 0.7)
        ctx.btcReturn15m <= -c.minMomentumMove && ctx.downPrice >= ctx.upPrice -> Decision(BtcDirection.DOWN, "momentum 15m + volume=${"%.2f".format(ctx.volumeRatio)}", 0.7)
        else -> null
    }

    fun highProbabilityConvergence(ctx: Context, c: Config = Config()): Decision? {
        val p = maxOf(ctx.upPrice, ctx.downPrice)
        if (p !in c.minConvergenceProbability..c.maxConvergenceProbability) return null
        if (ctx.spread > c.maxSpread) return null
        return if (ctx.upPrice >= ctx.downPrice) Decision(BtcDirection.UP, "high-probability convergence p=${"%.3f".format(p)}", 0.68)
        else Decision(BtcDirection.DOWN, "high-probability convergence p=${"%.3f".format(p)}", 0.68)
    }

    fun mispricing(yesAsk: Double?, noAsk: Double?): Decision? {
        if (yesAsk == null || noAsk == null) return null
        val dislocation = 1.0 - yesAsk - noAsk
        return when {
            dislocation >= 0.02 && yesAsk <= noAsk -> Decision(BtcDirection.UP, "mispricing YES+NO=${"%.3f".format(yesAsk + noAsk)}", dislocation.coerceAtMost(1.0))
            dislocation >= 0.02 && noAsk < yesAsk -> Decision(BtcDirection.DOWN, "mispricing YES+NO=${"%.3f".format(yesAsk + noAsk)}", dislocation.coerceAtMost(1.0))
            else -> null
        }
    }
}
