package com.caifenxi.app.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.caifenxi.app.data.db.dao.HsFeedbackDao
import com.caifenxi.app.data.db.dao.HsShadowDao
import com.caifenxi.app.data.db.entity.HsFeedbackEntity
import com.caifenxi.app.data.db.entity.HsShadowClosedEntity
import com.caifenxi.app.data.db.entity.HsShadowOpenEntity
import com.caifenxi.app.data.db.entity.PolymarketSnapshotEntity
import com.caifenxi.app.data.db.dao.PolymarketSnapshotDao

/**
 * BTC Quant local store.
 * Only HS feedback / shadow-trading tables remain after legacy lottery cleanup.
 * DB filename remains caifenxi.db for backward compatibility; destructive fallback is removed.
 */
@Database(
    entities = [
        HsFeedbackEntity::class,
        HsShadowOpenEntity::class,
        HsShadowClosedEntity::class,
        PolymarketSnapshotEntity::class
    ],
    version = 20,
    exportSchema = false
)
abstract class CaiDatabase : RoomDatabase() {
    abstract fun hsFeedbackDao(): HsFeedbackDao
    abstract fun hsShadowDao(): HsShadowDao
    abstract fun polymarketSnapshotDao(): PolymarketSnapshotDao

    companion object {
        private val MIGRATION_19_20 = object : Migration(19, 20) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // v20 formalizes the production schema version without changing table layout.
                // No table changes in this migration; keeping data is the important invariant.
            }
        }

        @Volatile
        private var instance: CaiDatabase? = null

        fun getInstance(context: Context): CaiDatabase {
            return instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    CaiDatabase::class.java,
                    "caifenxi.db"
                )
                    // Preserve existing research/feedback data across schema revisions.
                    // v19 -> v20 is metadata-only; future schema changes must ship an explicit migration.
                    .addMigrations(MIGRATION_19_20)
                    .build().also { instance = it }
            }
        }
    }
}
