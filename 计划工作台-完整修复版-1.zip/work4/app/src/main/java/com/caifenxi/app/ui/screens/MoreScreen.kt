package com.caifenxi.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import com.caifenxi.app.ui.MainViewModel
import com.caifenxi.app.ui.components.GlobalCard
import com.caifenxi.app.ui.components.SectionTitle
import com.caifenxi.app.ui.theme.CaiTokens

@Composable
fun MoreScreen(vm: MainViewModel, navController: NavHostController) {
    Column(
        Modifier.fillMaxSize().padding(horizontal = CaiTokens.ScreenHPadding, vertical = CaiTokens.S16)
    ) {
        Text("更多", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(CaiTokens.S16))
        SectionTitle("数据与工具")
        GlobalCard {
            listOf(
                "stats" to "历史战绩",
                "lab" to "实验室",
                "accessibility" to "无障碍跟投",
                "settings" to "设置 / 悬浮窗"
            ).forEach { (route, title) ->
                TextButton(
                    onClick = { navController.navigate(route) },
                    modifier = Modifier.fillMaxWidth()
                ) { Text(title) }
            }
        }
        Spacer(Modifier.height(CaiTokens.S12))
        GlobalCard {
            Text("v10 计划引擎", style = MaterialTheme.typography.titleMedium)
            Text("动态模型竞技、手动计划周期、计划回测、战绩记录与悬浮窗半隐身。", style = MaterialTheme.typography.bodyMedium)
        }
    }
}
