package com.caifenxi.app.service

import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import com.caifenxi.app.CaiFenXiApplication
import com.caifenxi.app.domain.engine.ConsensusEngine
import com.caifenxi.app.domain.engine.PredictEngine
import com.caifenxi.app.domain.engine.StatsEngine
import com.caifenxi.app.domain.model.AlgoMode
import com.caifenxi.app.domain.model.LotteryConfig
import com.caifenxi.app.domain.model.PredictionSnapshot
import com.caifenxi.app.util.AndroidCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.withContext

/**
 * 前台服务：后台保活拉最新开奖。
 * 新期会落库、结算,生成下一期计划/共识,并尝试挂机自动下注。
 */
class DataSyncService : Service() {

    companion object {
        const val ACTION_REFRESH_OVERLAY = "com.caifenxi.app.REFRESH_OVERLAY"
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null
    private var lastIssue: String? = null
    private var failStreak = 0
    private var overlay: FloatingOverlayController? = null
    private var autoBetPanel: AutoBetPanelController? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onTaskRemoved(rootIntent: Intent?) {
        // App 从最近任务划掉时，不关闭后台开奖监听/悬浮窗。
        // START_STICKY 负责系统级重启；这里额外触发一次前台服务重启，降低部分厂商 ROM 的误杀概率。
        try {
            val restart = Intent(applicationContext, DataSyncService::class.java)
            AndroidCompat.startDataSyncService(applicationContext, restart)
        } catch (_: Exception) {}
        super.onTaskRemoved(rootIntent)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = NotificationHelper.buildForeground(this, "正在监听开奖…")
        AndroidCompat.startForegroundCompat(this, 1001, notification)

        // 复用控制器：每次 start 都 new 会导致旧 WindowManager 视图无人 remove，关闭开关后仍留在屏幕上
        if (overlay == null) {
            overlay = FloatingOverlayController(this)
        }
        if (autoBetPanel == null) {
            autoBetPanel = AutoBetPanelController(this)
        }
        try {
            val p0 = CaiFenXiApplication.instance.configStore.loadPrefs()
            overlay?.refresh(p0)
            autoBetPanel?.refresh(p0)
        } catch (_: Exception) {}
        // 预热挂机来源缓存，避免设置页主线程读不到 Bot
        try {
            val key = CaiFenXiApplication.instance.configStore.loadPrefs().selectedLotteryKey
            scope.launch {
                try {
                    val cfg = CaiFenXiApplication.instance.database.betDao().getBotConfig(key)
                    if (cfg != null) {
                        AutoBetController.updateBotSourceCache(key, cfg.sourceType, cfg.sourceId)
                    }
                } catch (_: Exception) {}
            }
        } catch (_: Exception) {}

        // 仅刷新悬浮窗时不打断开奖轮询
        if (intent?.action == ACTION_REFRESH_OVERLAY && job?.isActive == true) {
            return START_STICKY
        }

        job?.cancel()
        job = scope.launch {
            val app = CaiFenXiApplication.instance
            while (isActive) {
                try {
                    val prefs = app.configStore.loadPrefs()
                    val key = prefs.selectedLotteryKey
                    val cfg = LotteryConfig.findByKey(key) ?: LotteryConfig.CATALOG.first()
                    withTimeout(25_000) {
                        val latest = app.apiClient.fetchLatest(cfg)
                        if (latest != null && latest.issue != lastIssue) {
                            app.drawRepository.cacheDraw(latest)
                            StatsEngine.settleWithDraw(app.statStore, key, latest)
                            ConsensusEngine.settleWithDraw(app.consensusStore, key, latest)
                            app.planEngine.settlePendingWithDraw(latest, prefs.backtestParams)
                            app.betEngine.settleWithDraw(key, latest)
                            // 无障碍金额策略：用开奖结果 vs 最近一次点击的预测判定上期对错
                            AutoBetController.recordHitFromDraw(
                                context = this@DataSyncService,
                                lotteryKey = key,
                                issue = latest.issue,
                                actualDx = latest.dx,
                                actualDs = latest.ds
                            )

                            val history = app.drawRepository.getWorkingHistory(key)
                            if (history.isNotEmpty()) {
                                val latestRow = history.maxByOrNull {
                                    it.issue.toLongOrNull() ?: Long.MIN_VALUE
                                } ?: history.last()
                                val cutoff = latestRow.issue
                                val apiNext = latestRow.nextIssue?.takeIf { n ->
                                    n.isNotBlank() && n != cutoff &&
                                        (n.toLongOrNull() ?: 0L) > (cutoff.toLongOrNull() ?: 0L)
                                }
                                // 目标期号必须严格基于“本次刚收到的最新开奖期”计算。
                                // API 偶尔会返回旧/重复 nextIssue，不能让悬浮窗出现“最新期=目标期”。
                                val target = resolveTargetIssue(latest.issue, apiNext ?: PredictEngine.suggestNextIssue(cutoff))
                                // 先把“新期已到、预测尚未就绪”明确发布给悬浮窗。
                                // 这样开奖同步可以立即响应，但绝不会把上一期预测冒充成新期预测。
                                publishFloatingSnapshot(
                                    context = this@DataSyncService,
                                    lotteryName = cfg.name,
                                    lotteryKey = key,
                                    latestIssue = latest.issue,
                                    latestDrawTime = latest.drawTime,
                                    latestDx = latest.dx,
                                    latestDs = latest.ds,
                                    targetIssue = target,
                                    consensus = emptyList(),
                                    predictions = emptyList(),
                                    status = "CALCULATING"
                                )
                                withContext(Dispatchers.Main.immediate) { overlay?.refresh(prefs); autoBetPanel?.refresh(prefs) }

                                // 预测阶段必须保证“最终快照”一定有机会提交。
                                // 任何单个模块异常都不能让悬浮窗永久卡在 CALCULATING。
                                var preds = emptyList<com.caifenxi.app.domain.model.PlanPredictionRecord>()
                                var cons = emptyList<com.caifenxi.app.domain.model.ModelConsensus>()
                                var prediction: PredictionSnapshot? = null
                                try {
                                    // 后台服务也要同步自定义计划，否则“指定计划”在前台能选、
                                    // 但后台快照找不到该计划，会一直回退成“计划不可用”。
                                    val customPlans = app.customPlanDao.getEnabledByLottery(key)
                                        .map { it.toDomain().toDefinition() }
                                    app.planEngine.setCustomPlans(customPlans)

                                    // 悬浮窗指定计划即使没有加入全局计划池，也必须实际参与本次预测。
                                    val floatingPlanIds = listOf(
                                        prefs.floatingDxPlanId.ifBlank { prefs.floatingPlanId },
                                        prefs.floatingDsPlanId
                                    ).filter { it.isNotBlank() }
                                    val predictionPrefs = if (prefs.floatingSource == "plan" && floatingPlanIds.isNotEmpty()) {
                                        prefs.copy(selectedPlanIds = (prefs.selectedPlanIds + floatingPlanIds).distinct())
                                    } else prefs
                                    // 关键修复：悬浮窗选择的计划必须强制重新激活。
                                    // PlanEngine 在同一目标期若已有 activePlans，普通 predictForNext 会复用旧计划池，
                                    // 导致设置页明明选了计划，后台快照却找不到该计划。
                                    // 保存并恢复 activePlans，避免覆盖前台新计划/引擎池上下文
                                    val savedActive = try { app.planEngine.getActivePlans() } catch (_: Exception) { emptyList() }
                                    app.planEngine.activatePlansForIssue(target, predictionPrefs, force = true)
                                    preds = app.planEngine.predictForNext(history, predictionPrefs, target, cutoff)
                                    cons = if (preds.isNotEmpty()) {
                                        app.planEngine.consensus(key, target, preds)
                                    } else emptyList()
                                    // 尽量恢复进入前的计划池
                                    try {
                                        if (savedActive.isNotEmpty()) {
                                            // 用当前 prefs 再激活一次会冲掉 floating 专用池；仅在有保存时用 force 按原 prefs
                                            app.planEngine.activatePlansForIssue(target, prefs, force = true)
                                        }
                                    } catch (_: Exception) {}
                                    if (cons.isNotEmpty()) {
                                        try {
                                            ConsensusEngine.recordPending(app.consensusStore, key, target, cons, poolSource = "LEGACY")
                                        } catch (_: Exception) {
                                            // 持久化失败不阻塞悬浮窗最终快照。
                                        }
                                    }
                                } catch (_: Exception) {
                                    // 计划引擎异常时继续尝试算法预测；READY 快照会根据实际来源决定。
                                }

                                // 算法来源也必须在“最终快照”里准备好，不能先显示旧算法结果。
                                try {
                                    val botCfg = app.database.betDao().getBotConfig(key)
                                    // 算法不仅在用户选择“算法”时计算；当共识/指定计划暂时不可用时，
                                    // 它还承担悬浮窗的安全兜底，避免一直卡在“预测更新中”。
                                    val needAlgoPrediction = prefs.floatingSource == "algo" ||
                                        prefs.floatingSource == "plan" ||
                                        cons.none { it.category == "大小" && !it.leadingDirection.isNullOrBlank() } ||
                                        cons.none { it.category == "单双" && !it.leadingDirection.isNullOrBlank() } ||
                                        botCfg == null || botCfg.sourceType == "algo"
                                    if (needAlgoPrediction) {
                                        val modeId = if (prefs.floatingSource == "algo") {
                                            prefs.currentAlgo
                                        } else {
                                            botCfg?.sourceId ?: prefs.currentAlgo
                                        }
                                        val mode = AlgoMode.fromId(modeId)
                                        prediction = PredictEngine.predict(
                                            history, cfg.type, prefs, target, cutoff, mode
                                        )
                                    }
                                } catch (_: Exception) {
                                    prediction = null
                                }

                                // 只要当前选择的来源已经得到完整的大小+单双，就提交 READY。
                                // 共识偶发为空时，从本期计划结果按简单多数生成临时共识，避免永远停在“更新中”。
                                if (cons.none { it.category == "大小" && !it.leadingDirection.isNullOrBlank() }) {
                                    val dx = majorityDirection(preds, "大小", setOf("大", "小"))
                                    if (dx != null) {
                                        cons = cons.filterNot { it.category == "大小" } +
                                            com.caifenxi.app.domain.model.ModelConsensus(
                                                lotteryKey = key, targetIssue = target, category = "大小",
                                                leadingDirection = dx, supportRatio = 0.0, disagreement = 0.0,
                                                participatingPlans = preds.count { it.category == "大小" }
                                            )
                                    }
                                }
                                if (cons.none { it.category == "单双" && !it.leadingDirection.isNullOrBlank() }) {
                                    val ds = majorityDirection(preds, "单双", setOf("单", "双"))
                                    if (ds != null) {
                                        cons = cons.filterNot { it.category == "单双" } +
                                            com.caifenxi.app.domain.model.ModelConsensus(
                                                lotteryKey = key, targetIssue = target, category = "单双",
                                                leadingDirection = ds, supportRatio = 0.0, disagreement = 0.0,
                                                participatingPlans = preds.count { it.category == "单双" }
                                            )
                                    }
                                }

                                publishFloatingSnapshot(
                                    context = this@DataSyncService,
                                    lotteryName = cfg.name,
                                    lotteryKey = key,
                                    latestIssue = latest.issue,
                                    latestDrawTime = latest.drawTime,
                                    latestDx = latest.dx,
                                    latestDs = latest.ds,
                                    targetIssue = target,
                                    consensus = cons,
                                    predictions = preds,
                                    algoDx = prediction?.dx?.direction,
                                    algoDs = prediction?.ds?.direction,
                                    status = "READY"
                                )
                                withContext(Dispatchers.Main.immediate) { overlay?.refresh(prefs); autoBetPanel?.refresh(prefs) }

                                try {
                                    app.betEngine.placeAutoBets(
                                        lotteryKey = key,
                                        targetIssue = target,
                                        prediction = prediction,
                                        planPredictions = preds,
                                        consensus = cons
                                    )
                                } catch (_: Exception) {
                                    // 挂机失败不能回滚已经提交的悬浮窗预测快照。
                                }
                            }

                            if (lastIssue != null) {
                                val summary = listOfNotNull(latest.dx, latest.ds, latest.combo)
                                    .joinToString(" ") + " " + latest.numbers.take(5).joinToString(",")
                                NotificationHelper.notifyNewDraw(
                                    this@DataSyncService,
                                    latest.issue,
                                    summary
                                )
                            }
                            lastIssue = latest.issue
                            failStreak = 0
                        }
                    }
                } catch (_: Exception) {
                    failStreak++
                }
                val wait = when {
                    failStreak >= 5 -> 90_000L
                    failStreak >= 2 -> 50_000L
                    else -> 40_000L
                }
                try {
                    val latestPrefs = app.configStore.loadPrefs()
                    withContext(Dispatchers.Main.immediate) { overlay?.refresh(latestPrefs); autoBetPanel?.refresh(latestPrefs) }
                } catch (_: Exception) {}
                delay(wait)
            }
        }
        return START_STICKY
    }

    /**
     * 强制保证目标期是最新开奖期之后的一期。
     * API 的 nextIssue 在极速彩种上偶尔会滞后或重复，不能直接信任。
     */
    private fun resolveTargetIssue(latestIssue: String, candidate: String): String {
        val latest = latestIssue.trim()
        val c = candidate.trim()
        val latestNum = latest.toLongOrNull()
        // 数字期号直接 +1，完全绕开 API 偶发返回重复 nextIssue 的问题。
        if (latestNum != null) return (latestNum + 1L).toString()
        if (c.isNotBlank() && c != latest) return c
        return PredictEngine.suggestNextIssue(latest)
    }

    private fun majorityDirection(
        preds: List<com.caifenxi.app.domain.model.PlanPredictionRecord>,
        category: String,
        allowed: Set<String>
    ): String? {
        val counts = mutableMapOf<String, Int>()
        preds.filter { it.category == category }.forEach { rec ->
            rec.output.split("/", "、", ",").map { it.trim() }.forEach { value ->
                if (value in allowed) counts[value] = (counts[value] ?: 0) + 1
            }
        }
        return counts.maxByOrNull { it.value }?.key
    }

    override fun onDestroy() {
        job?.cancel()
        val prefs = try {
            CaiFenXiApplication.instance.configStore.loadPrefs()
        } catch (_: Exception) {
            null
        }
        // 无障碍控制面板：开关仍开着时不 remove，交给 holder，服务重启后接管
        try {
            if (prefs?.autoClickPanelEnabled == true) {
                autoBetPanel?.keepOnServiceDestroy()
            } else {
                autoBetPanel?.hide()
            }
        } catch (_: Exception) {
            try { autoBetPanel?.hide() } catch (_: Exception) {}
        }
        autoBetPanel = null
        // 预测悬浮窗：同理，启用时 keep，关闭时 hide
        try {
            if (prefs?.floatingEnabled == true) {
                overlay?.keepOnServiceDestroy()
            } else {
                overlay?.hide()
            }
        } catch (_: Exception) {
            try { overlay?.hide() } catch (_: Exception) {}
        }
        overlay = null
        super.onDestroy()
    }
}
