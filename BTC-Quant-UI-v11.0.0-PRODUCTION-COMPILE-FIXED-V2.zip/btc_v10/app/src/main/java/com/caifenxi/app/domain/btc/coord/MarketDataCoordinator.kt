package com.caifenxi.app.domain.btc.coord

import com.caifenxi.app.domain.btc.BinanceDerivativesRepository
import com.caifenxi.app.domain.btc.BinanceMarketRepository
import com.caifenxi.app.domain.btc.BinanceOrderBookRepository
import com.caifenxi.app.domain.btc.BtcCandle
import com.caifenxi.app.domain.btc.BtcDemoDataProvider
import com.caifenxi.app.domain.btc.BtcDerivativesSnapshot
import com.caifenxi.app.domain.btc.FundingPoint
import com.caifenxi.app.domain.btc.OpenInterestPoint
import com.caifenxi.app.domain.btc.hs.ChainlinkOracleRepository
import com.caifenxi.app.domain.btc.news.CryptoNewsRepository
import com.caifenxi.app.domain.btc.news.NewsSnapshot
import com.caifenxi.app.domain.btc.polymarket.PolyMarket
import com.caifenxi.app.domain.btc.polymarket.PolymarketRepository
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope

/**
 * 行情数据协调器 —— 从 BtcQuantViewModel 拆出的并行拉取职责。
 */
class MarketDataCoordinator(
    private val marketRepo: BinanceMarketRepository,
    private val derivRepo: BinanceDerivativesRepository,
    private val orderBookRepo: BinanceOrderBookRepository,
    private val newsRepo: CryptoNewsRepository,
    private val polymarketRepo: PolymarketRepository
) {
    data class Bundle(
        val candles5m: List<BtcCandle>,
        val candles15m: List<BtcCandle>,
        val candles1h: List<BtcCandle>,
        val primary: List<BtcCandle>,
        val funding: List<FundingPoint>,
        val oi: List<OpenInterestPoint>,
        val snap: BtcDerivativesSnapshot?,
        val news: NewsSnapshot?,
        val depth: BinanceOrderBookRepository.Snapshot?,
        val oracle: ChainlinkOracleRepository.Snapshot?,
        val polyMarkets: List<PolyMarket>,
        val useDemo: Boolean
    )

    suspend fun loadParallel(
        symbol: String,
        timeframe: String,
        chainlinkRpc: String,
        chainlinkFeed: String
    ): Bundle = coroutineScope {
        val a5 = async { runCatching { marketRepo.loadKlines(symbol, "5m", 300) }.getOrElse { emptyList() } }
        val a15 = async { runCatching { marketRepo.loadKlines(symbol, "15m", 300) }.getOrElse { emptyList() } }
        val a1h = async { runCatching { marketRepo.loadKlines(symbol, "1h", 300) }.getOrElse { emptyList() } }
        val aFund = async { runCatching { derivRepo.fundingHistory(symbol, 100) }.getOrDefault(emptyList()) }
        val aOi = async { runCatching { derivRepo.openInterestHistory(symbol, timeframe, 100) }.getOrDefault(emptyList()) }
        val aSnap = async { runCatching { derivRepo.snapshot(symbol) }.getOrNull() }
        val aNews = async { runCatching { newsRepo.snapshot() }.getOrNull() }
        val aDepth = async { runCatching { orderBookRepo.snapshot(symbol, 100) }.getOrNull() }
        val aOracle = async {
            runCatching { ChainlinkOracleRepository(chainlinkRpc, chainlinkFeed).latest() }.getOrNull()
        }
        val aPoly = async { runCatching { polymarketRepo.searchCryptoMarkets(40) }.getOrDefault(emptyList()) }

        var c5 = a5.await(); var c15 = a15.await(); var c1h = a1h.await()
        var funding = aFund.await(); var oi = aOi.await()
        var snap = aSnap.await(); var news = aNews.await()
        val depth = aDepth.await(); val oracle = aOracle.await(); val poly = aPoly.await()

        val primaryRaw = when (timeframe) {
            "5m" -> c5; "1h" -> c1h; else -> c15
        }.ifEmpty { c15.ifEmpty { c5.ifEmpty { c1h } } }
        val useDemo = primaryRaw.size < 2
        if (useDemo) {
            c5 = BtcDemoDataProvider.generateCandles(symbol, "5m", 300)
            c15 = BtcDemoDataProvider.generateCandles(symbol, "15m", 300)
            c1h = BtcDemoDataProvider.generateCandles(symbol, "1h", 300)
            funding = BtcDemoDataProvider.generateFundingHistory(symbol, 100)
            oi = BtcDemoDataProvider.generateOiHistory(symbol, 100)
            snap = BtcDemoDataProvider.generateDerivativesSnapshot(symbol)
            news = BtcDemoDataProvider.generateNewsSnapshot()
        }
        val primary = when (timeframe) {
            "5m" -> c5; "1h" -> c1h; else -> c15
        }
        Bundle(c5, c15, c1h, primary, funding, oi, snap, news, if (useDemo) null else depth, if (useDemo) null else oracle, poly, useDemo)
    }
}
