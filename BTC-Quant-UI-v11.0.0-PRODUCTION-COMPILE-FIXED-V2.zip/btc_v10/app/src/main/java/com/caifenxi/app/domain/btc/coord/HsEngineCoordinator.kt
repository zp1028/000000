package com.caifenxi.app.domain.btc.coord

import com.caifenxi.app.domain.btc.BtcCandle
import com.caifenxi.app.domain.btc.DerivativesFeatures
import com.caifenxi.app.domain.btc.BinanceOrderBookRepository
import com.caifenxi.app.domain.btc.hs.HsPredictionEngine
import com.caifenxi.app.domain.btc.hs.HsPredictionSnapshot
import com.caifenxi.app.domain.btc.polymarket.PolyMarket
import com.caifenxi.app.domain.btc.polymarket.PolyOrderBook

/** HS 预测引擎协调器 —— 组装账户 + 行情 + 盘口后调用引擎 */
class HsEngineCoordinator(
    private val engine: HsPredictionEngine
) {
    fun evaluate(
        candles5m: List<BtcCandle>,
        candles15m: List<BtcCandle>,
        candles1h: List<BtcCandle>,
        deriv: DerivativesFeatures?,
        marketYes5m: Double,
        marketYes15m: Double,
        marketYes1h: Double,
        paper: PaperAccountCoordinator.Snapshot,
        newsScore: Double,
        markPrice: Double,
        chainlinkPrice: Double,
        binanceOrderBook: BinanceOrderBookRepository.Snapshot?,
        polyBooks: Map<String, PolyOrderBook>,
        polyNoBooks: Map<String, PolyOrderBook>,
        polyMarkets: Map<String, PolyMarket>,
        oracleUpdatedAt: Long,
        oracleLive: Boolean,
        dataMode: String
    ): HsPredictionSnapshot = engine.evaluate(
        candles5m = candles5m,
        candles15m = candles15m,
        candles1h = candles1h,
        deriv = deriv,
        marketYesPrice5m = marketYes5m,
        marketYesPrice15m = marketYes15m,
        marketYesPrice1h = marketYes1h,
        balance = paper.balance,
        available = paper.available,
        openNotional = paper.openNotional,
        todayPnl = paper.todayPnl,
        pnl30d = paper.pnl30d,
        maxDd = paper.maxDrawdownPct,
        newsScore = newsScore,
        markPrice = markPrice,
        chainlinkPrice = chainlinkPrice,
        binanceOrderBook = binanceOrderBook,
        polyBooks = polyBooks,
        polyNoBooks = polyNoBooks,
        polyMarkets = polyMarkets,
        oracleUpdatedAt = oracleUpdatedAt,
        oracleLive = oracleLive,
        dataMode = dataMode
    )
}
