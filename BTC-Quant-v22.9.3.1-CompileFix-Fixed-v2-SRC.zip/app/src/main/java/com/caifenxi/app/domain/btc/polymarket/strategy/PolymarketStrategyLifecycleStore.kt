package com.caifenxi.app.domain.btc.polymarket.strategy

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Persists research-driven Polymarket strategy lifecycle weights for unattended runtime. */
class PolymarketStrategyLifecycleStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun load(): Map<String, PolymarketStrategyLifecycle> {
        val raw = prefs.getString(KEY, null) ?: return emptyMap()
        return runCatching {
            val arr = JSONArray(raw)
            buildMap {
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val id = o.getString("id")
                    val status = runCatching { PolymarketStrategyPool.Status.valueOf(o.optString("status")) }
                        .getOrDefault(PolymarketStrategyPool.Status.CANDIDATE)
                    put(id, PolymarketStrategyLifecycle(id, status, o.optDouble("weight", 1.0), o.optDouble("score", 0.0), o.optString("reason"), o.optLong("updatedAt", 0L)))
                }
            }
        }.getOrDefault(emptyMap())
    }

    @Synchronized fun save(items: Collection<PolymarketStrategyLifecycle>) {
        val arr = JSONArray()
        items.forEach {
            arr.put(JSONObject().apply {
                put("id", it.strategyId)
                put("status", it.status.name)
                put("weight", it.weight)
                put("score", it.score)
                put("reason", it.reason)
                put("updatedAt", it.updatedAtMs)
            })
        }
        prefs.edit().putString(KEY, arr.toString()).apply()
    }

    fun weights(): Map<String, Double> = load()
        .filterValues { it.status != PolymarketStrategyPool.Status.RETIRED }
        .mapValues { it.value.weight.coerceIn(0.10, 2.50) }

    fun retired(): Set<String> = load().filterValues { it.status == PolymarketStrategyPool.Status.RETIRED }.keys

    fun promoteFromResearch(metrics: List<PolymarketStrategyResearchMetric>, nowMs: Long = System.currentTimeMillis()) {
        val current = load().toMutableMap()
        metrics.forEach { m ->
            val status = when {
                m.testSamples < 12 -> PolymarketStrategyPool.Status.CANDIDATE
                m.testProfitFactor >= 1.15 && m.testWinRate >= 0.54 && m.testMaxDrawdown <= 2.5 && m.stability >= 0.65 -> PolymarketStrategyPool.Status.ACTIVE
                m.testProfitFactor >= 1.0 && m.testExpectancy > 0.0 -> PolymarketStrategyPool.Status.SHADOW
                m.testProfitFactor < 0.85 || m.testMaxDrawdown > 5.0 -> PolymarketStrategyPool.Status.DOWNWEIGHT
                else -> PolymarketStrategyPool.Status.CANDIDATE
            }
            val weight = when (status) {
                PolymarketStrategyPool.Status.ACTIVE -> (1.0 + m.score).coerceIn(0.60, 1.75)
                PolymarketStrategyPool.Status.SHADOW -> (0.75 + m.score * 0.5).coerceIn(0.40, 1.20)
                PolymarketStrategyPool.Status.DOWNWEIGHT -> (0.45 + m.score * 0.25).coerceIn(0.15, 0.70)
                else -> 0.50
            }
            current[m.strategyId] = PolymarketStrategyLifecycle(
                m.strategyId, status, weight, m.score,
                "OOS PF=${"%.2f".format(m.testProfitFactor)} WR=${"%.1f%%".format(m.testWinRate * 100)} DD=${"%.2f".format(m.testMaxDrawdown)} cost=${"%.2f%%".format(m.costDrag * 100)}",
                nowMs
            )
        }
        save(current.values)
    }

    companion object { private const val PREFS = "polymarket_strategy_lifecycle_v1"; private const val KEY = "items" }
}
