package com.caifenxi.app.ui.screens

import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import com.caifenxi.app.ui.MainViewModel
import com.caifenxi.app.ui.ExecutorViewModel
import com.caifenxi.app.ui.components.GlobalCard
import com.caifenxi.app.ui.components.PrimaryButton
import com.caifenxi.app.ui.theme.CaiTokens
import com.caifenxi.app.domain.execution.BetCommand
import com.caifenxi.app.domain.execution.ExecutionResult
import kotlinx.coroutines.launch

@Composable
fun WebExecutorScreen(
    mainViewModel: MainViewModel = viewModel(),
    executorViewModel: ExecutorViewModel = viewModel()
) {
    val context = LocalContext.current
    var webView: WebView? = null
    var pageAdapter: WebPageAdapter? = null
    var bridge: WebExecutorBridge? = null
    
    // 预测结果状态
    var predictionResult by remember { mutableStateOf<WebExecutorBridge.PredictionResult?>(null) }
    

    
    // 网页状态
    var webpageUrl by remember { mutableStateOf("") }
    var webpageTitle by remember { mutableStateOf("") }
    var webpageStatus by remember { mutableStateOf("加载中...") }
    
    // 执行进度状态
    var executionProgress by remember { mutableStateOf(0f) }
    var bridgeLogs by remember { mutableStateOf<List<String>>(emptyList()) }
    
    // 初始化桥接器和适配器
    LaunchedEffect(Unit) {
        bridge = WebExecutorBridge(executorViewModel) { command, result ->
            // 处理执行结果
            bridge?.handleExecutionResult(result)
        }
        
        pageAdapter = WebPageAdapter(
            webView = WebView(context),
            onProgressUpdate = { progress ->
                executionProgress = progress
            },
            onElementFound = { type, count ->
                bridge?.addLog("找到$type元素: $count个")
            }
        )
    }

    BackHandler {
        webView?.let { wv ->
            if (wv.canGoBack()) {
                wv.goBack()
            } else {
                // 返回首页
                // todo: 实现导航逻辑
            }
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = CaiTokens.ScreenHPadding, vertical = CaiTokens.S16)
    ) {
        Text("内置网页执行中心", style = MaterialTheme.typography.headlineMedium)
        
        Spacer(Modifier.height(CaiTokens.S16))

        // 状态概览卡片
        GlobalCard {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text("当前网站", fontWeight = FontWeight.Bold)
                    Text(webpageTitle.ifEmpty { "彩析内置执行器" }, color = MaterialTheme.colorScheme.secondary)
                }
                Column {
                    Text("当前彩种", fontWeight = FontWeight.Bold)
                    Text(mainViewModel.currentLottery.value.name, color = MaterialTheme.colorScheme.secondary)
                }
                Column {
                    Text("当前期号", fontWeight = FontWeight.Bold)
                    Text(mainViewModel.nextIssueText.value, color = MaterialTheme.colorScheme.secondary)
                }
            }
            Spacer(Modifier.height(CaiTokens.S8))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text("登录状态", fontWeight = FontWeight.Bold)
                    Text("未登录", color = Color.Red)
                }
                Column {
                    Text("网页状态", fontWeight = FontWeight.Bold)
                    Text(webpageStatus, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Column {
                    Text("执行器状态", fontWeight = FontWeight.Bold)
                    Text(
                        when (executionStatus) {
                            ExecutorViewModel.ExecutorStatus.IDLE -> "待机"
                            ExecutorViewModel.ExecutorStatus.RUNNING -> "执行中"
                            ExecutorViewModel.ExecutorStatus.COMPLETED -> "已完成"
                            ExecutorViewModel.ExecutorStatus.FAILED -> "失败"
                            ExecutorViewModel.ExecutorStatus.CANCELLED -> "已取消"
                        },
                        color = when (executionStatus) {
                            ExecutorViewModel.ExecutorStatus.RUNNING -> MaterialTheme.colorScheme.primary
                            ExecutorViewModel.ExecutorStatus.COMPLETED -> Color.Green
                            ExecutorViewModel.ExecutorStatus.FAILED -> Color.Red
                            else -> MaterialTheme.colorScheme.onSurfaceVariant
                        }
                    )
                }
            }
        }

        Spacer(Modifier.height(CaiTokens.S16))

        // 执行控制面板
        GlobalCard {
            Text("执行控制", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(CaiTokens.S8))
            
            // 预测结果输入区域
            if (predictionResult == null) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(CaiTokens.S8)) {
                    OutlinedTextField(
                        value = "大",
                        onValueChange = { /* todo: 更新预测结果 */ },
                        label = { Text("大小预测") },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = "单",
                        onValueChange = { /* todo: 更新预测结果 */ },
                        label = { Text("单双预测") },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = "10",
                        onValueChange = { /* todo: 更新预测结果 */ },
                        label = { Text("金额") },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
            
            Spacer(Modifier.height(CaiTokens.S8))
            
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(CaiTokens.S8)) {
                PrimaryButton(
                    text = if (predictionResult == null) "设置预测" else "开始执行",
                    enabled = webpageUrl.isNotEmpty() && executionStatus == ExecutorViewModel.ExecutorStatus.IDLE,
                    modifier = Modifier.weight(1f)
                ) {
                    if (predictionResult == null) {
                        // 设置预测结果
                        predictionResult = WebExecutorBridge.PredictionResult(
                            lotteryType = mainViewModel.currentLottery.value.key,
                            issue = mainViewModel.nextIssueText.value,
                            predictionDx = "大",
                            predictionDs = "单",
                            amount = 10.0,
                            odds = 1.95
                        )
                    } else {
                        // 开始执行
                        bridge?.startBetExecution()
                    }
                }
                
                PrimaryButton(
                    text = "停止执行",
                    enabled = executionStatus == ExecutorViewModel.ExecutorStatus.RUNNING,
                    modifier = Modifier.weight(1f)
                ) {
                    bridge?.stopExecution()
                }
                
                PrimaryButton(
                    text = "刷新页面",
                    enabled = true,
                    modifier = Modifier.weight(1f)
                ) {
                    webView?.reload()
                }
            }
        }

        Spacer(Modifier.height(CaiTokens.S16))

        // 当前执行任务
        GlobalCard {
            Text("当前执行任务", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(CaiTokens.S8))
            currentTask?.let { task ->
                Column {
                    Text("任务ID: ${task.taskId}")
                    Text("彩种: ${task.lotteryKey}")
                    Text("期号: ${task.targetIssue}")
                    Text("下注指令: ${task.betCommand}")
                    if (task.betCommand.amount > 0) {
                        Text("金额: ${task.betCommand.amount}")
                    }
                }
            } ?: Text("暂无执行任务", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        Spacer(Modifier.height(CaiTokens.S16))

        // WebView 容器
        GlobalCard {
            AndroidView(
                factory = { ctx ->
                    WebView(ctx).apply {
                        webView = this
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.loadsImagesAutomatically = true
                        
                        webViewClient = object : WebViewClient() {
                            override fun onPageFinished(view: WebView?, url: String?) {
                                webpageUrl = url ?: ""
                                webpageStatus = "已加载"
                                pageAdapter?.initialize()
                                bridge?.addLog("网页加载完成: $url")
                            }
                        }
                        
                        webChromeClient = object : WebChromeClient() {
                            override fun onReceivedTitle(view: WebView?, title: String?) {
                                webpageTitle = title ?: ""
                            }
                        }
                        
                        // 注入JavaScript接口
                        val jsInterface = WebViewInterface(bridge!!)
                        addJavascriptInterface(jsInterface, "Android")
                        
                        // 加载默认页面
                        loadUrl("about:blank")
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(400.dp)
            )
        }

        Spacer(Modifier.height(CaiTokens.S16))

        // 执行进度
        GlobalCard {
            Text("执行进度", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(CaiTokens.S8))
            LinearProgressIndicator(
                progress = executionProgress,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(CaiTokens.S8))
            Text("进度: ${(executionProgress * 100).toInt()}%", 
                 color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        Spacer(Modifier.height(CaiTokens.S16))

        // 执行记录
        GlobalCard {
            Text("执行记录", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(CaiTokens.S8))
            Column {
                if (executorLogs.isEmpty()) {
                    Text("暂无执行记录", color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    executorLogs.forEach { log ->
                        Text(log, color = if (log.contains("成功")) Color.Green else 
                                     if (log.contains("失败")) Color.Red else 
                                     MaterialTheme.colorScheme.onSurfaceVariant,
                             modifier = Modifier.padding(vertical = 2.dp))
                    }
                }
            }
        }

        Spacer(Modifier.height(CaiTokens.S16))

        // 快速操作
        GlobalCard {
            Text("快速操作", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(CaiTokens.S8))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(CaiTokens.S8)) {
                PrimaryButton("清空日志", enabled = true, modifier = Modifier.weight(1f)) {
                    executorViewModel.clearLogs()
                    bridge?.reset()
                }
                PrimaryButton("生成测试任务", enabled = true, modifier = Modifier.weight(1f)) {
                    val testTask = executorViewModel.generateTestTask()
                    executorViewModel.startTask(testTask)
                }
            }
        }
    }
}任务", enabled = true, modifier = Modifier.weight(1f)) {
                    val testTask = executorViewModel.generateTestTask()
                    executorViewModel.startTask(testTask)
                }
            }
        }
    }
}