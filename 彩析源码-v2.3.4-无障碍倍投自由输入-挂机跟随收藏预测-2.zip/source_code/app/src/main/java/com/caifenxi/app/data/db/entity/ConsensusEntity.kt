package com.caifenxi.app.data.db.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.caifenxi.app.domain.model.ConsensusRecord
import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

@Entity(
    tableName = "consensus",
    indices = [
        // 含 poolSource，计划引擎与新计划可同存一期同分类
        Index(value = ["lotteryKey", "targetIssue", "category", "poolSource"], unique = true),
        Index(value = ["lotteryKey", "createdAt"]),
        Index(value = ["lotteryKey", "poolSource"])
    ]
)
@Serializable
data class ConsensusEntity(
    @PrimaryKey val id: String,
    val lotteryKey: String,
    val targetIssue: String,
    val category: String,
    val leadingDirection: String,
    val candidatesJson: String,
    val supportRatio: Double,
    val participatingPlans: Int,
    val actual: String?,
    val result: String,
    val createdAt: Long,
    val settledAt: Long?,
    /** LEGACY=计划引擎 / NOVA=新计划 */
    val poolSource: String = "LEGACY",
    val participatingPlanIds: String = "",
    val consensusVersion: String = ""
) {
    fun toDomain(): ConsensusRecord = ConsensusRecord(
        id = id,
        lotteryKey = lotteryKey,
        targetIssue = targetIssue,
        category = category,
        leadingDirection = leadingDirection,
        candidates = try {
            Json.decodeFromString<List<String>>(candidatesJson)
        } catch (_: Exception) {
            emptyList()
        },
        supportRatio = supportRatio,
        participatingPlans = participatingPlans,
        actual = actual,
        result = result,
        createdAt = createdAt,
        settledAt = settledAt,
        consensusVersion = consensusVersion,
        participatingPlanIds = participatingPlanIds,
        poolSource = poolSource
    )

    companion object {
        fun fromDomain(record: ConsensusRecord): ConsensusEntity = ConsensusEntity(
            id = record.id,
            lotteryKey = record.lotteryKey,
            targetIssue = record.targetIssue,
            category = record.category,
            leadingDirection = record.leadingDirection,
            candidatesJson = Json.encodeToString(record.candidates),
            supportRatio = record.supportRatio,
            participatingPlans = record.participatingPlans,
            actual = record.actual,
            result = record.result,
            createdAt = record.createdAt,
            settledAt = record.settledAt,
            poolSource = record.poolSource.ifBlank { "LEGACY" },
            participatingPlanIds = record.participatingPlanIds,
            consensusVersion = record.consensusVersion
        )
    }
}
