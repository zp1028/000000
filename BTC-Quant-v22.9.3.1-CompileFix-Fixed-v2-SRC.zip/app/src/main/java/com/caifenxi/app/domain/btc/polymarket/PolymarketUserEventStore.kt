package com.caifenxi.app.domain.btc.polymarket

import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

/** Bounded runtime cache used as a realtime observation layer before REST reconciliation. */
class PolymarketUserEventStore(private val maxEvents: Int = 500) {
    sealed class Event(val id: String, val timestampMs: Long) {
        data class Order(val value: PolymarketUserEventStream.UserOrderEvent) : Event(value.id, value.timestampMs)
        data class Trade(val value: PolymarketUserEventStream.UserTradeEvent) : Event(value.id, value.timestampMs)
    }

    private val sequence = AtomicLong(0)
    private val events = ConcurrentHashMap<Long, Event>()

    fun record(event: Event) {
        events[sequence.incrementAndGet()] = event
        trim()
    }

    fun latest(limit: Int = 100): List<Event> = events.entries
        .sortedByDescending { it.key }
        .take(limit.coerceIn(1, maxEvents))
        .map { it.value }

    fun latestOrder(orderId: String): PolymarketUserEventStream.UserOrderEvent? = latest(maxEvents)
        .asSequence()
        .mapNotNull { (it as? Event.Order)?.value }
        .firstOrNull { it.id == orderId }

    fun latestTrade(tradeId: String): PolymarketUserEventStream.UserTradeEvent? = latest(maxEvents)
        .asSequence()
        .mapNotNull { (it as? Event.Trade)?.value }
        .firstOrNull { it.id == tradeId }

    private fun trim() {
        val excess = events.size - maxEvents
        if (excess <= 0) return
        events.keys.sorted().take(excess).forEach { events.remove(it) }
    }
}
