# BTC Quant v10.3 全量优化说明

基于 v10.2 代码审查建议落地，版本标记 **v10.3-ALL-OPTIMIZED**。

## 已落地

### 1. 统一运行时配置 `HsRuntimeConfig`
- fee / latency / minNetEdge / ½Kelly / **单笔硬上限 2%** / 质量门阈值 / ML 缓存 TTL / 日熔断比例
- 全链路（成本、Edge、机会分、仓位）读取同一配置

### 2. ML 概率模型 v2 `BtcMlProbabilityModel`
- 标签：未来 horizon 根收盘方向（与短周期合约窗口一致）
- 特征：12 维（多尺度动量、EMA 结构、RSI、ATR、量能、收盘位置、波动突破）
- 分桶校准 + Brier/hitRate 质量收缩
- **按 barId 缓存**，避免每次 refresh 重训
- **分周期实例** 5m/15m/1h

### 3. 数据质量硬门 `HsDataQualityEngine` v2
- 新增 `liveTradeAllowed` + `blockReasons`
- 多周期时间对齐误差纳入评分
- 质量分 / CLOB / Book / K线 不达标 → 禁止 LIVE

### 4. Executable Edge / Cost
- 配置化 fee、latency、minNetEdge
- 冲击成本非线性（notional/depth）

### 5. 机会评分 v2
- 绑定 `liveTradeAllowed`
- 连续弱信号冷却系数
- 模型 hitRate / Brier 风险提示

### 6. 仓位硬约束
- `StakeSizingEngine` + `HsOpportunitySizing`：默认 **max 2% 净值**、绝对金额上限
- 机会倍率 = 0 时直接不下单

### 7. 多周期时间对齐 `HsTimeAlign`
- 决策时钟 floor 到 5m，计算 align error 喂给质量门

### 8. 概率校准器 v2
- Platt + 可选历史分桶 `fitFromHistory`

### 9. ViewModel refresh 并行化
- K线三周期 / funding / OI / snap / news / depth / oracle / polymarket **async 并行**

## 未在本包做完整 module 拆分的项（工程量大，建议下一迭代）
- 彩票业务物理拆 module（建议 `app-btc` / `app-legacy` product flavor）
- ViewModel 拆成多个（Market / Hs / Paper / Execution）
- SharedPreferences → Room 全迁（反馈/影子已可后续迁）

## 单位约定
- 概率、edge、kelly、fee、quality：**始终 0–1**
- UI 显示时再 `* 100`
