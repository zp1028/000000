package com.caifenxi.app.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.caifenxi.app.data.db.dao.BetDao
import com.caifenxi.app.data.db.dao.ConsensusDao
import com.caifenxi.app.data.db.dao.CustomPlanDao
import com.caifenxi.app.data.db.dao.DrawDao
import com.caifenxi.app.data.db.dao.ManualMarkDao
import com.caifenxi.app.data.db.dao.StatDao
import com.caifenxi.app.data.db.entity.BetEntity
import com.caifenxi.app.data.db.entity.BotConfigEntity
import com.caifenxi.app.data.db.entity.ConsensusEntity
import com.caifenxi.app.data.db.entity.CustomPlanEntity
import com.caifenxi.app.data.db.entity.DrawEntity
import com.caifenxi.app.data.db.entity.ManualMarkEntity
import com.caifenxi.app.data.db.entity.StatEntity
import com.caifenxi.app.data.db.entity.WalletEntity

@Database(
    entities = [
        DrawEntity::class,
        BetEntity::class,
        BotConfigEntity::class,
        WalletEntity::class,
        StatEntity::class,
        ConsensusEntity::class,
        ManualMarkEntity::class,
        CustomPlanEntity::class
    ],
    version = 8,
    exportSchema = false
)
abstract class CaiDatabase : RoomDatabase() {
    abstract fun drawDao(): DrawDao
    abstract fun betDao(): BetDao
    abstract fun statDao(): StatDao
    abstract fun consensusDao(): ConsensusDao
    abstract fun manualMarkDao(): ManualMarkDao
    abstract fun customPlanDao(): CustomPlanDao

    companion object {
        private val MIGRATION_4_5 = object : Migration(4, 5) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // Version 5 formalizes the existing schema without dropping user data.
            }
        }

        private val MIGRATION_5_6 = object : Migration(5, 6) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // Create stats table (索引在 7→8 会纠正为 UNIQUE,此处保持可创建)
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS `stats` (
                        `id` TEXT NOT NULL,
                        `lotteryKey` TEXT NOT NULL,
                        `issue` TEXT NOT NULL,
                        `category` TEXT NOT NULL,
                        `lean` TEXT NOT NULL,
                        `candidatesJson` TEXT NOT NULL,
                        `actual` TEXT,
                        `result` TEXT NOT NULL,
                        `algoId` TEXT NOT NULL,
                        `score` REAL NOT NULL,
                        `matchMode` TEXT NOT NULL,
                        `createdAt` INTEGER NOT NULL,
                        `settledAt` INTEGER,
                        PRIMARY KEY(`id`)
                    )
                """.trimIndent())
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_stats_lotteryKey_issue_category` ON `stats` (`lotteryKey`, `issue`, `category`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_stats_lotteryKey_createdAt` ON `stats` (`lotteryKey`, `createdAt`)")

                // Create consensus table
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS `consensus` (
                        `id` TEXT NOT NULL,
                        `lotteryKey` TEXT NOT NULL,
                        `targetIssue` TEXT NOT NULL,
                        `category` TEXT NOT NULL,
                        `leadingDirection` TEXT NOT NULL,
                        `candidatesJson` TEXT NOT NULL,
                        `supportRatio` REAL NOT NULL,
                        `participatingPlans` INTEGER NOT NULL,
                        `actual` TEXT,
                        `result` TEXT NOT NULL,
                        `createdAt` INTEGER NOT NULL,
                        `settledAt` INTEGER,
                        PRIMARY KEY(`id`)
                    )
                """.trimIndent())
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_consensus_lotteryKey_targetIssue_category` ON `consensus` (`lotteryKey`, `targetIssue`, `category`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_consensus_lotteryKey_createdAt` ON `consensus` (`lotteryKey`, `createdAt`)")

                // Create manual_marks table
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS `manual_marks` (
                        `lotteryKey` TEXT NOT NULL,
                        `category` TEXT NOT NULL,
                        `direction` TEXT NOT NULL,
                        `updatedAt` INTEGER NOT NULL,
                        PRIMARY KEY(`lotteryKey`, `category`)
                    )
                """.trimIndent())
            }
        }

        private val MIGRATION_6_7 = object : Migration(6, 7) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // Create custom_plans table
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS `custom_plans` (
                        `planId` TEXT NOT NULL,
                        `lotteryKey` TEXT NOT NULL,
                        `planName` TEXT NOT NULL,
                        `category` TEXT NOT NULL,
                        `algorithm` TEXT NOT NULL,
                        `window` INTEGER NOT NULL,
                        `outputFormat` TEXT NOT NULL,
                        `hitCriteria` TEXT NOT NULL,
                        `enabled` INTEGER NOT NULL,
                        `participateConsensus` INTEGER NOT NULL,
                        `createdAt` INTEGER NOT NULL,
                        `updatedAt` INTEGER NOT NULL,
                        PRIMARY KEY(`planId`)
                    )
                """.trimIndent())
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_custom_plans_lotteryKey_enabled` ON `custom_plans` (`lotteryKey`, `enabled`)")
            }
        }

        /**
         * 修复 v5→v6 迁移把 unique 索引建成了普通索引,
         * 导致 Room 校验 stats/consensus 失败并弹出「Migration didn't properly handle」。
         * 重建表 + UNIQUE 索引,尽量保留已有数据。
         */
        private val MIGRATION_7_8 = object : Migration(7, 8) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // ---- stats ----
                db.execSQL("DROP INDEX IF EXISTS `index_stats_lotteryKey_issue_category`")
                db.execSQL("DROP INDEX IF EXISTS `index_stats_lotteryKey_createdAt`")
                db.execSQL("ALTER TABLE `stats` RENAME TO `stats_old`")
                db.execSQL("""
                    CREATE TABLE `stats` (
                        `id` TEXT NOT NULL,
                        `lotteryKey` TEXT NOT NULL,
                        `issue` TEXT NOT NULL,
                        `category` TEXT NOT NULL,
                        `lean` TEXT NOT NULL,
                        `candidatesJson` TEXT NOT NULL,
                        `actual` TEXT,
                        `result` TEXT NOT NULL,
                        `algoId` TEXT NOT NULL,
                        `score` REAL NOT NULL,
                        `matchMode` TEXT NOT NULL,
                        `createdAt` INTEGER NOT NULL,
                        `settledAt` INTEGER,
                        PRIMARY KEY(`id`)
                    )
                """.trimIndent())
                db.execSQL("""
                    INSERT OR IGNORE INTO `stats`
                    (`id`,`lotteryKey`,`issue`,`category`,`lean`,`candidatesJson`,`actual`,`result`,`algoId`,`score`,`matchMode`,`createdAt`,`settledAt`)
                    SELECT `id`,`lotteryKey`,`issue`,`category`,`lean`,`candidatesJson`,`actual`,`result`,`algoId`,`score`,`matchMode`,`createdAt`,`settledAt`
                    FROM `stats_old`
                """.trimIndent())
                db.execSQL("DROP TABLE `stats_old`")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_stats_lotteryKey_issue_category` ON `stats` (`lotteryKey`, `issue`, `category`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_stats_lotteryKey_createdAt` ON `stats` (`lotteryKey`, `createdAt`)")

                // ---- consensus ----
                db.execSQL("DROP INDEX IF EXISTS `index_consensus_lotteryKey_targetIssue_category`")
                db.execSQL("DROP INDEX IF EXISTS `index_consensus_lotteryKey_createdAt`")
                db.execSQL("ALTER TABLE `consensus` RENAME TO `consensus_old`")
                db.execSQL("""
                    CREATE TABLE `consensus` (
                        `id` TEXT NOT NULL,
                        `lotteryKey` TEXT NOT NULL,
                        `targetIssue` TEXT NOT NULL,
                        `category` TEXT NOT NULL,
                        `leadingDirection` TEXT NOT NULL,
                        `candidatesJson` TEXT NOT NULL,
                        `supportRatio` REAL NOT NULL,
                        `participatingPlans` INTEGER NOT NULL,
                        `actual` TEXT,
                        `result` TEXT NOT NULL,
                        `createdAt` INTEGER NOT NULL,
                        `settledAt` INTEGER,
                        PRIMARY KEY(`id`)
                    )
                """.trimIndent())
                db.execSQL("""
                    INSERT OR IGNORE INTO `consensus`
                    (`id`,`lotteryKey`,`targetIssue`,`category`,`leadingDirection`,`candidatesJson`,`supportRatio`,`participatingPlans`,`actual`,`result`,`createdAt`,`settledAt`)
                    SELECT `id`,`lotteryKey`,`targetIssue`,`category`,`leadingDirection`,`candidatesJson`,`supportRatio`,`participatingPlans`,`actual`,`result`,`createdAt`,`settledAt`
                    FROM `consensus_old`
                """.trimIndent())
                db.execSQL("DROP TABLE `consensus_old`")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_consensus_lotteryKey_targetIssue_category` ON `consensus` (`lotteryKey`, `targetIssue`, `category`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_consensus_lotteryKey_createdAt` ON `consensus` (`lotteryKey`, `createdAt`)")
            }
        }

        @Volatile private var instance: CaiDatabase? = null

        fun getInstance(context: Context): CaiDatabase {
            return instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    CaiDatabase::class.java,
                    "caifenxi.db"
                )
                    .addMigrations(MIGRATION_4_5, MIGRATION_5_6, MIGRATION_6_7, MIGRATION_7_8)
                    // 无迁移路径的老库自动清库重建,避免启动闪退
                    .fallbackToDestructiveMigration()
                    .build().also { instance = it }
            }
        }
    }
}
