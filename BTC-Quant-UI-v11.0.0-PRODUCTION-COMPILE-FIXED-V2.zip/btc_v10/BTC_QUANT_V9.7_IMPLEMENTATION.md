# BTC Quant v9.7 HS — Replay / Attribution / Settlement

## Completed
- Immutable compact Market Snapshot Store with bounded persistence and duplicate-id protection.
- Decision Center exposes lifecycle, attribution, and recent snapshot replay metadata.
- Opportunity selection now binds timeframe + direction + edge + liquidity + spread + model quality into one candidate; aggregate edge no longer mixes the best edge from one timeframe with pHat/risk metrics from another.
- Polymarket settlement helper accepts only an explicitly closed binary market whose outcome prices resolve to ~1/0; no price inference is used for unresolved markets.
- v9.6 persistent feedback, shadow OPEN/closed ledger, lifecycle store, and audit remain intact.

## Runtime principle
Snapshot replay is audit/research metadata. It does not bypass the execution gate, risk engine, broker mode, or credentials.

## Validation
- ZIP integrity checked with `unzip -t`.
- Full Android APK build remains dependent on a working Gradle 8.9 + Android SDK environment because the source package does not contain `gradle-wrapper.jar`.
