package com.caifenxi.app.domain.model

/**
 * 模拟下注相关模型。
 */

/** 下注来源类型 */
enum class BetSourceType(val id: String, val label: String) {
    COCKPIT("cockpit", "驾驶舱"),
    ALGO("algo", "算法"),
    PLAN("plan", "指定计划"),
    NOVA("nova", "新计划"),
    /** 工作台收藏计划：可直接挂机，默认跟随工作台/引擎计划预测；可选开启滚动现算 */
    FAVORITE("favorite", "收藏计划"),
    AUTO_BEST("auto_best", "竞技场最优"),
    CONSENSUS("consensus", "共识"),
    /** 新计划页独立共识（与计划引擎共识数据分离） */
    NOVA_CONSENSUS("nova_consensus", "新计划共识");

    companion object {
        fun fromId(id: String): BetSourceType = entries.find { it.id == id } ?: ALGO
    }
}

/** 下注分类 */
enum class BetCategory(val id: String, val label: String) {
    DX("大小", "大小"),
    DS("单双", "单双"),
    COMBO("组合", "组合"),
    NUMBER("数字", "数字");

    companion object {
        fun fromId(id: String): BetCategory? = entries.find { it.id == id }
    }
}

/**
 * 赔率配置。
 * 组合:按覆盖的组合种类数(共4种:大单/大双/小单/小双)递减:
 * 1/4 → 3.9, 2/4 → 1.9, 3/4+ → 1.0
 */
object BetOdds {
    /** 默认两倍盘（多数彩种大小单双） */
    const val DX = 1.98
    const val DS = 1.98
    /** 组合：单口返还倍数 1:4（含本金），多口总成本 = n×单注，中奖仍按 4×单注返还再减成本 */
    const val COMBO_RETURN = 4.0
    /** PK10 定位/名次号码直选 */
    const val NUMBER = 9.98
    /** 极速快乐8等 LUCK20：号码任意中 1 赔 4 */
    const val LUCK20_NUMBER = 4.0
    /** 名次大小/单双固定 1.98（与冠亚和不对称盘区分） */
    const val RANK_DX = 1.98
    const val RANK_DS = 1.98
    /** 仅极速飞艇(10035)、极速赛车(10037)「冠亚和」大小单双不对称赔率 */
    const val DX_DA = 2.2
    const val DX_XIAO = 1.79
    const val DS_DAN = 1.79
    const val DS_SHUANG = 2.2
    /** 运动会：大小单双龙虎 1.98，定位 6 */
    const val YDH_DIR = 1.98
    const val YDH_POS = 6.0
    /** 快三 */
    const val K3_DX = 1.98
    const val K3_SANJUN = 1.99
    const val K3_YXX = 1.99
    const val K3_CHANGPAI = 6.0

    private val ASYM_LOT_KEYS = setOf("10035", "10037")

    fun usesAsymDxDs(lotteryKey: String): Boolean = lotteryKey in ASYM_LOT_KEYS

    fun of(category: BetCategory): Double = when (category) {
        BetCategory.DX -> DX
        BetCategory.DS -> DS
        BetCategory.COMBO -> COMBO_RETURN
        BetCategory.NUMBER -> NUMBER
    }

    fun dxOdds(value: String, lotteryKey: String = ""): Double {
        if (!usesAsymDxDs(lotteryKey)) return DX
        return when (value.trim()) {
            "大" -> DX_DA
            "小" -> DX_XIAO
            else -> DX
        }
    }

    fun dsOdds(value: String, lotteryKey: String = ""): Double {
        if (!usesAsymDxDs(lotteryKey)) return DS
        return when (value.trim()) {
            "单" -> DS_DAN
            "双" -> DS_SHUANG
            else -> DS
        }
    }

    /**
     * 组合盈亏（已减成本）：
     * - 一口：投入 stake，中奖返还 4×stake，净利 = 3×stake
     * - n 口：投入 n×stake，中奖仍返还 4×stake（只中一口按 1:4），净利 = 4×stake − n×stake
     * - 未中：−n×stake
     */
    fun comboProfit(unitStake: Double, coverCount: Int, hit: Boolean): Double {
        val n = coverCount.coerceAtLeast(1)
        val cost = unitStake * n
        if (!hit) return -cost
        val ret = unitStake * COMBO_RETURN
        return ret - cost
    }

    /** 组合有效「展示赔率」(用于下单 odds 字段)：净利/单注成本 + 1，便于结算 amount*(odds-1) 近似；多口时用总口径 */
    fun comboDisplayOdds(coverCount: Int): Double {
        val n = coverCount.coerceAtLeast(1)
        // 中奖净利 = 4 - n（相对单注），总投入 n，净/成本 = (4-n)/n，odds = 1 + (4-n)/n = 4/n
        return (COMBO_RETURN / n).coerceAtLeast(1.0)
    }

    /**
     * @param lotteryKey 必须传入，避免彩种规则串用
     * @return 用于 amount*(odds-1) 的赔率；组合请优先用 comboProfit
     */
    fun forPlay(playType: String, prediction: String, lotteryKey: String = ""): Double {
        val raw = prediction.removePrefix("反:").trim()
        val cleaned = raw.substringAfter(":").takeIf { ":" in raw } ?: raw
        val parts = cleaned.split("/", "、", ",").map { it.trim() }.filter { it.isNotEmpty() }
        val type = LotteryConfig.findByKey(lotteryKey)?.type
        return when (type) {
            LotteryType.YDH -> when (playType) {
                "大小", "单双", "球大小", "球单双", "龙虎" -> YDH_DIR
                "定位", "数字", "位置" -> YDH_POS
                else -> YDH_DIR
            }
            LotteryType.K3 -> when (playType) {
                "大小", "和值大小" -> K3_DX
                "三军" -> {
                    // 合并多点：展示赔率随条数下降（近似 1.99/n 的合并口径，保底 1.0）
                    val n = parts.size.coerceAtLeast(1)
                    (K3_SANJUN / n).coerceAtLeast(1.0)
                }
                "鱼虾蟹" -> {
                    val n = parts.size.coerceAtLeast(1)
                    (K3_YXX / n).coerceAtLeast(1.0)
                }
                "长牌" -> K3_CHANGPAI
                else -> K3_DX
            }
            LotteryType.LUCK20 -> when (playType) {
                "大小" -> dxOdds(parts.firstOrNull() ?: "", lotteryKey)
                "单双" -> dsOdds(parts.firstOrNull() ?: "", lotteryKey)
                "组合" -> comboDisplayOdds(
                    parts.count { it in listOf("大单", "大双", "小单", "小双") }.coerceAtLeast(parts.size.coerceAtLeast(1))
                )
                "数字", "位置", "任选" -> LUCK20_NUMBER
                else -> DX
            }
            else -> when (playType) {
                // 冠亚和：飞艇/赛车不对称 2.2 / 1.79
                "大小" -> dxOdds(parts.firstOrNull() ?: "", lotteryKey)
                "单双" -> dsOdds(parts.firstOrNull() ?: "", lotteryKey)
                // 名次大小单双：固定 1.98
                "名次大小" -> RANK_DX
                "名次单双" -> RANK_DS
                "组合" -> comboDisplayOdds(
                    parts.count { it in listOf("大单", "大双", "小单", "小双") }.coerceAtLeast(parts.size.coerceAtLeast(1))
                )
                "数字", "位置" -> if (type == LotteryType.LUCK20) LUCK20_NUMBER else NUMBER
                else -> DX
            }
        }
    }


    /**
     * 挂机下单用：按彩种 + 分类 + 注值解析真实赔率（与图表 forPlay 对齐）。
     */
    fun resolveForBet(
        category: BetCategory,
        values: List<String>,
        lotteryKey: String,
        playType: String = ""
    ): Double {
        val type = LotteryConfig.findByKey(lotteryKey)?.type
        val joined = values.joinToString("/")
        val pt = playType.trim()
        // 名次玩法优先：固定 1.98，不用冠亚和不对称盘
        if (pt == "名次大小") return RANK_DX
        if (pt == "名次单双") return RANK_DS
        return when (category) {
            BetCategory.COMBO -> {
                val n = values.count { it in listOf("大单", "大双", "小单", "小双") }
                    .coerceAtLeast(values.size.coerceAtLeast(1))
                when (type) {
                    LotteryType.YDH -> YDH_DIR
                    else -> comboDisplayOdds(n)
                }
            }
            BetCategory.NUMBER -> {
                val n = values.size.coerceAtLeast(1)
                when (type) {
                    // 快乐8：任意中 1 赔 4；多码时 amount=n×单注，展示赔率=4/n，使 amount*(odds-1)=单注*(4-n)
                    LotteryType.LUCK20 ->
                        if (n <= 1) LUCK20_NUMBER else (LUCK20_NUMBER / n).coerceAtLeast(1.0)
                    LotteryType.YDH -> YDH_POS
                    LotteryType.K3 -> {
                        val j = joined
                        when {
                            j.contains("长牌") -> K3_CHANGPAI
                            j.contains("鱼") || j.contains("虾") || j.contains("蟹") ->
                                (K3_YXX / n).coerceAtLeast(1.0)
                            else -> (K3_SANJUN / n).coerceAtLeast(1.0)
                        }
                    }
                    // PK10 定位 9.98；多码同样按展示赔率折算
                    else ->
                        if (n <= 1) NUMBER else (NUMBER / n).coerceAtLeast(1.0)
                }
            }
            BetCategory.DX -> when (type) {
                LotteryType.YDH -> YDH_DIR
                LotteryType.K3 -> K3_DX
                // 默认按冠亚和：飞艇/赛车 2.2/1.79
                else -> dxOdds(values.firstOrNull() ?: "", lotteryKey)
            }
            BetCategory.DS -> when (type) {
                LotteryType.YDH -> YDH_DIR
                LotteryType.K3 -> K3_DX
                else -> dsOdds(values.firstOrNull() ?: "", lotteryKey)
            }
        }
    }
}

/** PKS 位置名 */
object PksPositions {
    val NAMES = listOf("冠军", "亚军") + (3..10).map { "第${it}" }

    fun nameAt(index: Int): String = NAMES.getOrElse(index) { "第${index + 1}" }
}

/**
 * 挂机策略(UI 层使用,与 BotConfigEntity 对应)。
 */
data class BotConfig(
    val enabled: Boolean = false,
    val sourceType: String = "algo",
    val sourceId: String = "experience",
    /** 大小/单双/组合可分别指定不同计划（挂机）；空则回退 sourceId */
    val sourceIdDx: String = "",
    val sourceIdDs: String = "",
    val sourceIdCombo: String = "",
    val categories: Set<String> = setOf("大小", "单双"),
    val numberPosition: Int = 0,
    val amount: Double = 10.0,
    // 倍投配置(1.0 = 关闭)
    val winMult: Double = 1.0,
    val lossMult: Double = 1.0,
    val winMultPeriods: Int = 1,
    val lossMultPeriods: Int = 1,
    val maxMult: Int = 1,
    /** forward=正投 / reverse=反投（数字不取反） */
    val betMode: String = "forward",
    /**
     * 滚动预测：开启后指定计划/新计划不用引擎缓存结果，
     * 而用与图表相同的 NovaPlanAnalytics.predict 在最新历史上现算。
     */
    val rollingPredict: Boolean = false,
    /** 滚动口径：1=一期 2=二期 3=三期（与图表一致；二/三期挂机金额按轮内倍投由 lossMult 配合） */
    val rollingStage: Int = 1
)

/**
 * 挂机收益与对错统计。
 */
data class BetStats(
    // 收益
    val initialBalance: Double = 10000.0,
    val balance: Double = 10000.0,
    val totalProfit: Double = 0.0,
    val totalBet: Double = 0.0,
    val profitRate: Double = 0.0,          // 累计盈亏 / 初始资金
    // 胜率
    val totalSettled: Int = 0,
    val winCount: Int = 0,
    val loseCount: Int = 0,
    val winRate: Double = 0.0,
    // 本期
    val currentBetAmount: Double = 0.0,    // 本期下注总本金
    val currentProfit: Double = 0.0,       // 本期结算净盈亏
    // 按分类对错
    val byCategory: Map<String, CatBetStats> = emptyMap(),
    // 收益曲线(时序,按结算先后)
    val profitCurve: List<ProfitPoint> = emptyList(),
    // 最大回撤
    val maxDrawdown: Double = 0.0,         // 最大回撤金额(从峰值到谷底)
    val maxDrawdownPct: Double = 0.0,      // 最大回撤百分比
    val peakProfit: Double = 0.0,          // 累计收益峰值
    // 最长连对/连错区间(曲线上标注用)
    val maxHitStreak: Int = 0,             // 最长连对次数
    val maxMissStreak: Int = 0             // 最长连错次数
) {
    val effectiveBalance: Double get() = balance + currentProfit - currentBetAmount
}

data class CatBetStats(
    val catName: String,
    val settled: Int = 0,
    val hit: Int = 0,
    val miss: Int = 0,
    val winRate: Double = 0.0,
    /** 该分类累计盈亏(已结算) */
    val profit: Double = 0.0,
    val recentStreak: Int = 0,              // 正=连对,负=连错
    val maxHitStreak: Int = 0,
    val maxMissStreak: Int = 0,
    /** 两期滚动窗口:窗口内至少 1 次中 = 两期对(按注口径,与 hit/miss 一致) */
    val twoWindows: Int = 0,
    val twoHitRate: Double = 0.0,
    val twoMissRate: Double = 0.0,
    /** 三期滚动窗口:窗口内至少 1 次中 = 三期对 */
    val threeWindows: Int = 0,
    val threeHitRate: Double = 0.0,
    val threeMissRate: Double = 0.0
) {
    val hitRateStr: String
        get() = if (settled == 0) "-" else "%.1f%%".format(winRate * 100)
}

/**
 * 收益曲线数据点(每期结算后一个点)。
 */
data class ProfitPoint(
    val issueIndex: Int,          // 时序索引(0 开始)
    val issue: String,            // 期号
    val cumulativeProfit: Double, // 累计收益
    val hit: Boolean,             // 该期是否命中
    val drawdown: Double,         // 从历史峰值回撤金额
    val drawdownPct: Double       // 回撤百分比
)

/**
 * 钱包视图。
 */
data class WalletView(
    val initialBalance: Double = 10000.0,
    val balance: Double = 10000.0,
    val totalProfit: Double = 0.0,
    val totalBet: Double = 0.0,
    val winCount: Int = 0,
    val loseCount: Int = 0
)

/**
 * 下注订单视图(UI 层使用,与 BetEntity 对应)。
 */
data class BetView(
    val id: Long,
    val issue: String,
    val sourceLabel: String,
    val category: String,
    val betValue: String,
    val amount: Double,
    val odds: Double,
    val status: String,
    val profit: Double,
    val createdAt: Long,
    val settledAt: Long? = null
)
