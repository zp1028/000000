package com.caifenxi.app.domain.btc.polymarket

import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Resolves the exchange protocol exposed by the configured CLOB host.
 * The result is cached briefly so an order tick does not repeatedly probe /version.
 */
class PolymarketProtocolResolver(
    private val client: OkHttpClient,
    private val baseUrl: String
) {
    @Volatile private var cached: Pair<Long, PolymarketOrderProtocol>? = null

    fun resolve(force: Boolean = false): PolymarketOrderProtocol {
        val now = System.currentTimeMillis()
        cached?.takeIf { !force && now - it.first < CACHE_MS }?.let { return it.second }
        val protocol = runCatching {
            val request = Request.Builder().url(baseUrl.trimEnd('/') + "/version").get().build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@runCatching fallbackFromHost()
                val raw = response.body?.string().orEmpty().trim()
                val value = runCatching { JSONObject(raw).optString("version", raw) }.getOrDefault(raw)
                when {
                    value.contains("3") -> PolymarketOrderProtocol.V3
                    value.contains("2") -> PolymarketOrderProtocol.V2
                    value.contains("1") -> PolymarketOrderProtocol.V1
                    else -> fallbackFromHost()
                }
            }
        }.getOrElse { fallbackFromHost() }
        cached = now to protocol
        return protocol
    }

    private fun fallbackFromHost(): PolymarketOrderProtocol = when {
        // Production clob.polymarket.com is CLOB V2 after the April 2026 cutover.
        baseUrl.equals("https://clob.polymarket.com", ignoreCase = true) -> PolymarketOrderProtocol.V2
        baseUrl.contains("clob-v2", ignoreCase = true) -> PolymarketOrderProtocol.V2
        else -> PolymarketOrderProtocol.UNKNOWN
    }

    companion object {
        private const val CACHE_MS = 60_000L
    }
}
