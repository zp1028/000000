package com.caifenxi.app.domain.btc.settlement

/** Venue-neutral settlement/redeem lifecycle. It never claims a redeem occurred until the venue confirms it. */
enum class SettlementStage { OPEN, RESOLVED, REDEEMABLE, REDEEM_SUBMITTING, REDEEMED, MERGEABLE, BLOCKED, ERROR }

data class SettlementPosition(
    val conditionId: String,
    val asset: String,
    val size: Double,
    val redeemable: Boolean,
    val mergeable: Boolean,
    val outcome: String,
    val currentValue: Double = 0.0
)

data class SettlementState(
    val conditionId: String,
    val stage: SettlementStage = SettlementStage.OPEN,
    val redeemableSize: Double = 0.0,
    val mergeableSize: Double = 0.0,
    val lastAction: String = "",
    val lastError: String? = null,
    val updatedAtMs: Long = System.currentTimeMillis()
)

class PolymarketSettlementCoordinator(private val minSize: Double = 1e-9) {
    enum class Action { WAIT, REFRESH, REDEEM, MERGE, VERIFY, BLOCK }
    data class Decision(val state: SettlementState, val action: Action, val reason: String)

    fun observe(state: SettlementState, positions: List<SettlementPosition>, nowMs: Long = System.currentTimeMillis()): Decision {
        val relevant = positions.filter { it.conditionId == state.conditionId && it.size > minSize }
        if (relevant.isEmpty()) {
            return Decision(state.copy(stage = SettlementStage.OPEN, lastAction = "NO_POSITION", updatedAtMs = nowMs), Action.WAIT, "no position")
        }
        val redeem = relevant.filter { it.redeemable }.sumOf { it.size }
        val merge = relevant.filter { it.mergeable }.sumOf { it.size }
        return when {
            redeem > minSize -> Decision(state.copy(stage = SettlementStage.REDEEMABLE, redeemableSize = redeem, mergeableSize = merge, lastAction = "REDEEM_READY", lastError = null, updatedAtMs = nowMs), Action.REDEEM, "redeemable position confirmed")
            merge > minSize -> Decision(state.copy(stage = SettlementStage.MERGEABLE, redeemableSize = redeem, mergeableSize = merge, lastAction = "MERGE_READY", lastError = null, updatedAtMs = nowMs), Action.MERGE, "mergeable position confirmed")
            relevant.any { it.outcome.isBlank() } -> Decision(state.copy(stage = SettlementStage.BLOCKED, lastAction = "MISSING_OUTCOME", lastError = "missing outcome", updatedAtMs = nowMs), Action.BLOCK, "position outcome missing")
            else -> Decision(state.copy(stage = SettlementStage.RESOLVED, redeemableSize = redeem, mergeableSize = merge, lastAction = "RESOLVED_OBSERVED", lastError = null, updatedAtMs = nowMs), Action.VERIFY, "resolved state observed; venue confirmation required")
        }
    }

    fun markRedeemSubmitting(state: SettlementState, nowMs: Long = System.currentTimeMillis()) =
        state.copy(stage = SettlementStage.REDEEM_SUBMITTING, lastAction = "REDEEM_SUBMITTING", updatedAtMs = nowMs)

    fun markRedeemed(state: SettlementState, confirmed: Boolean, message: String = "", nowMs: Long = System.currentTimeMillis()): SettlementState =
        if (confirmed) state.copy(stage = SettlementStage.REDEEMED, redeemableSize = 0.0, lastAction = "REDEEM_CONFIRMED", lastError = null, updatedAtMs = nowMs)
        else state.copy(stage = SettlementStage.ERROR, lastAction = "REDEEM_UNCONFIRMED", lastError = message.ifBlank { "redeem confirmation missing" }, updatedAtMs = nowMs)
}
