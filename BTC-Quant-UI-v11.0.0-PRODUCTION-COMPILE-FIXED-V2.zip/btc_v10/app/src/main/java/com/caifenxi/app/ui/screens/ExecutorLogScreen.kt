package com.caifenxi.app.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.lifecycle.viewmodel.compose.viewModel
import com.caifenxi.app.ui.ExecutorViewModel
import com.caifenxi.app.ui.components.GlobalCard
import com.caifenxi.app.ui.components.PrimaryButton
import com.caifenxi.app.ui.theme.CaiTokens

@Composable
fun ExecutorLogScreen(executorViewModel: ExecutorViewModel = viewModel()) {
    val logs by executorViewModel.executorLogs.collectAsState()
    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = CaiTokens.ScreenHPadding, vertical = CaiTokens.S16)
    ) {
        Text("执行日志", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(CaiTokens.S12))
        PrimaryButton(
            text = "清空",
            onClick = { executorViewModel.clearLogs() }
        )
        Spacer(Modifier.height(CaiTokens.S12))
        GlobalCard {
            Column(
                Modifier
                    .fillMaxWidth()
                    .weight(1f, fill = false)
                    .verticalScroll(rememberScrollState())
            ) {
                Text("全部记录", fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(CaiTokens.S8))
                if (logs.isEmpty()) {
                    Text("暂无日志", color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    logs.forEach {
                        Text(it, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}
