package com.caifenxi.app.ui.screens

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.caifenxi.app.domain.model.BacktestParams
import com.caifenxi.app.service.DataSyncService
import com.caifenxi.app.ui.MainViewModel
import com.caifenxi.app.ui.components.CaptionMuted
import com.caifenxi.app.ui.components.GlobalCard
import com.caifenxi.app.ui.components.PrimaryButton
import com.caifenxi.app.ui.components.SectionTitle
import com.caifenxi.app.ui.theme.CaiTokens
import kotlin.math.roundToInt

@Composable
fun SettingsScreen(vm: MainViewModel) {
    val p = vm.prefs.value
    val context = LocalContext.current

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = CaiTokens.ScreenHPadding, vertical = CaiTokens.S16)
            .padding(bottom = CaiTokens.ScreenBottom)
    ) {
        Text("设置", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(CaiTokens.S16))

        SectionTitle("外观")
        GlobalCard {
            Text("主题", fontWeight = FontWeight.SemiBold)
            Row(Modifier.padding(vertical = CaiTokens.S8)) {
                listOf("system" to "跟随系统", "light" to "浅色", "dark" to "深色").forEach { (k, lab) ->
                    FilterChip(
                        selected = p.themeMode == k,
                        onClick = { vm.updatePrefs { it.copy(themeMode = k, darkMode = k == "dark") } },
                        label = { Text(lab) },
                        modifier = Modifier.padding(end = CaiTokens.S8)
                    )
                }
            }
        }

        SectionTitle("参数档位")
        GlobalCard {
            Row {
                listOf("simple" to "简单", "balanced" to "均衡", "pro" to "专业").forEach { (k, lab) ->
                    FilterChip(
                        selected = p.sensitivityMode == k,
                        onClick = { vm.updatePrefs { it.copy(sensitivityMode = k) } },
                        label = { Text(lab) },
                        modifier = Modifier.padding(end = CaiTokens.S8)
                    )
                }
            }
            CaptionMuted("简单档适合浏览;专业档保留更多参数")
        }

        SectionTitle("预测数量")
        GlobalCard {
            Text("组合预测条数", fontWeight = FontWeight.SemiBold)
            Row(Modifier.padding(vertical = CaiTokens.S8)) {
                listOf(1, 2, 3, 4).forEach { n ->
                    FilterChip(
                        selected = p.comboPredCount == n,
                        onClick = { vm.updatePrefs { it.copy(comboPredCount = n) } },
                        label = { Text("$n 个") },
                        modifier = Modifier.padding(end = CaiTokens.S8)
                    )
                }
            }
            CaptionMuted("主预测与计划池「组合」类计划均输出前 N 个候选;命中任一即对")
            Spacer(Modifier.height(CaiTokens.S8))
            Text("计划池每期生成数量", fontWeight = FontWeight.SemiBold)
            Row(Modifier.padding(vertical = CaiTokens.S8)) {
                listOf(6, 8, 12, 16, 20, 24).forEach { n ->
                    FilterChip(
                        selected = p.planPoolCount == n,
                        onClick = { vm.updatePrefs { it.copy(planPoolCount = n) } },
                        label = { Text("$n") },
                        modifier = Modifier.padding(end = CaiTokens.S8)
                    )
                }
            }
            CaptionMuted("生成条数;组合/号码候选数见上方「组合预测条数」与位置 TopN")
            Spacer(Modifier.height(CaiTokens.S8))
            Text("位置 / 号码预测 TopN", fontWeight = FontWeight.SemiBold)
            Row(Modifier.padding(vertical = CaiTokens.S8)) {
                listOf(1, 2, 3, 5).forEach { n ->
                    FilterChip(
                        selected = p.positionTopN == n,
                        onClick = { vm.updatePrefs { it.copy(positionTopN = n, zuheTopN = n) } },
                        label = { Text("$n") },
                        modifier = Modifier.padding(end = CaiTokens.S8)
                    )
                }
            }
            CaptionMuted("位置预测与计划池「号码」类输出个数")
        }

        SectionTitle("行为")
        GlobalCard {
            SettingSwitch("自动刷新", p.autoRefresh) { v -> vm.updatePrefs { it.copy(autoRefresh = v) } }
            SettingSwitch("EWMA 自适应", p.ewmaEnabled) { v -> vm.updatePrefs { it.copy(ewmaEnabled = v) } }
            SettingSwitch("预测冻结", p.predFreeze) { v -> vm.updatePrefs { it.copy(predFreeze = v) } }
        }

        SectionTitle("回测评分权重")
        GlobalCard {
            val bp = p.backtestParams
            WeightSlider(
                label = "近期命中权重",
                value = bp.recentHit.toFloat(),
                range = 0f..60f,
                step = 1f,
                onChange = { v -> vm.updatePrefs { it.copy(backtestParams = bp.copy(recentHit = v.toDouble())) } }
            )
            WeightSlider(
                label = "样本量权重",
                value = bp.sample.toFloat(),
                range = 0f..30f,
                step = 0.5f,
                onChange = { v -> vm.updatePrefs { it.copy(backtestParams = bp.copy(sample = v.toDouble())) } }
            )
            WeightSlider(
                label = "连错惩罚权重",
                value = bp.streak.toFloat(),
                range = 0f..30f,
                step = 0.5f,
                onChange = { v -> vm.updatePrefs { it.copy(backtestParams = bp.copy(streak = v.toDouble())) } }
            )
            WeightSlider(
                label = "晋级阈值",
                value = bp.promoteThreshold.toFloat(),
                range = 40f..90f,
                step = 1f,
                onChange = { v -> vm.updatePrefs { it.copy(backtestParams = bp.copy(promoteThreshold = v.toDouble())) } }
            )
            WeightSlider(
                label = "连错扣分起点",
                value = bp.streakPenaltyStart.toFloat(),
                range = 1f..10f,
                step = 1f,
                onChange = { v -> vm.updatePrefs { it.copy(backtestParams = bp.copy(streakPenaltyStart = v.toInt())) } }
            )
            Spacer(Modifier.height(CaiTokens.S8))
            PrimaryButton(
                "恢复默认权重",
                ghost = true,
                onClick = { vm.updatePrefs { it.copy(backtestParams = BacktestParams()) } },
                modifier = Modifier.fillMaxWidth()
            )
            CaptionMuted("权重仅在重新回测后生效;连错惩罚按(连错-起点+1)×权重×0.15 扣分")
        }

        Spacer(Modifier.height(CaiTokens.S16))
        PrimaryButton(
            "启动后台开奖监听",
            onClick = { context.startForegroundService(Intent(context, DataSyncService::class.java)) },
            modifier = Modifier.fillMaxWidth()
        )

        SectionTitle("AI(可选)")
        GlobalCard {
            OutlinedTextField(
                value = p.aiApiKey,
                onValueChange = { key -> vm.updatePrefs { it.copy(aiApiKey = key) } },
                label = { Text("API Key") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            CaptionMuted("仅本机保存,留空使用本地规则")
        }

        SectionTitle("数据管理")
        DataManagementCard(vm = vm)

        Spacer(Modifier.height(CaiTokens.S24))
        CaptionMuted("彩析 · 香槟金设计令牌 · 仅供学习研究,请理性购彩")
    }
}

@Composable
private fun DataManagementCard(vm: MainViewModel) {
    val context = LocalContext.current
    val exported = vm.exportedFile.value
    val exportedList = remember { mutableStateOf<List<java.io.File>>(emptyList()) }
    fun refreshList() {
        exportedList.value = com.caifenxi.app.data.config.DataExportHelper.listExports(context)
    }

    // 分享最近一次导出的文件
    LaunchedEffect(exported) {
        val f = exported ?: return@LaunchedEffect
        try {
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", f)
            val share = Intent(Intent.ACTION_SEND).apply {
                type = if (f.name.endsWith(".csv")) "text/csv" else "application/json"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(share, "分享 ${f.name}"))
        } catch (_: Exception) {
            // FileProvider 未就绪时静默失败
        }
        vm.exportedFile.value = null
    }

    // 从文件选择器选择备份 JSON 恢复
    val restorePicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            try {
                val dir = com.caifenxi.app.data.config.DataExportHelper.exportDir(context)
                val target = java.io.File(dir, "restore-backup.json")
                context.contentResolver.openInputStream(uri)?.use { input ->
                    target.outputStream().use { output -> input.copyTo(output) }
                }
                vm.restoreFromBackup(target.name)
            } catch (e: Exception) {
                vm.statusText.value = "读取备份失败:${e.message}"
            }
        }
    }

    GlobalCard {
        Text("数据一致性", fontWeight = FontWeight.SemiBold)
        CaptionMuted("补结算漏网待开战绩/共识/挂机,并补生成下期共识")
        Spacer(Modifier.height(CaiTokens.S8))
        PrimaryButton("一致性校验并修复", onClick = { vm.runConsistencyCheck() }, modifier = Modifier.fillMaxWidth())
    }

    Spacer(Modifier.height(CaiTokens.S8))

    GlobalCard {
        Text("CSV 导出(全部彩种)", fontWeight = FontWeight.SemiBold)
        CaptionMuted("文件保存在应用外部目录 export/,导出后自动弹出分享")
        Spacer(Modifier.height(CaiTokens.S8))
        PrimaryButton("导出开奖历史 CSV", onClick = { vm.exportDrawsCsv() }, ghost = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(CaiTokens.S4))
        PrimaryButton("导出下注历史 CSV", onClick = { vm.exportBetsCsv() }, ghost = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(CaiTokens.S4))
        PrimaryButton("导出统计记录 CSV", onClick = { vm.exportStatsCsv() }, ghost = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(CaiTokens.S4))
        PrimaryButton("导出共识记录 CSV", onClick = { vm.exportConsensusCsv() }, ghost = true, modifier = Modifier.fillMaxWidth())
    }

    Spacer(Modifier.height(CaiTokens.S8))

    GlobalCard {
        Text("全量备份 / 恢复", fontWeight = FontWeight.SemiBold)
        CaptionMuted("备份包含全部彩种的开奖、下注、统计、共识、自定义计划与设置")
        Spacer(Modifier.height(CaiTokens.S8))
        PrimaryButton("导出全量备份(JSON)", onClick = { vm.exportFullBackup() }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(CaiTokens.S8))
        PrimaryButton(
            if (vm.restoring.value) "恢复中..." else "从备份文件恢复",
            onClick = { restorePicker.launch(arrayOf("application/json", "application/octet-stream", "*/*")) },
            enabled = !vm.restoring.value,
            ghost = true,
            modifier = Modifier.fillMaxWidth()
        )
        CaptionMuted("恢复会覆盖当前数据并重建统计,完成后请回到首页刷新(建议先备份)")
        Spacer(Modifier.height(CaiTokens.S8))
        PrimaryButton("查看已导出文件", onClick = { refreshList() }, ghost = true, modifier = Modifier.fillMaxWidth())
        if (exportedList.value.isNotEmpty()) {
            Spacer(Modifier.height(CaiTokens.S8))
            exportedList.value.take(8).forEach { f ->
                CaptionMuted("• ${f.name}(${f.length() / 1024} KB)")
            }
        }
    }
}

@Composable
private fun SettingSwitch(title: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = CaiTokens.S4),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun WeightSlider(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    step: Float,
    onChange: (Float) -> Unit
) {
    Column(Modifier.padding(vertical = CaiTokens.S4)) {
        Row(Modifier.fillMaxWidth()) {
            Text(label, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
            Text(
                if (step >= 1f) "%.0f".format(value) else "%.1f".format(value),
                fontWeight = FontWeight.SemiBold,
                style = MaterialTheme.typography.bodyMedium
            )
        }
        Slider(
            value = value.coerceIn(range),
            onValueChange = { v -> onChange(((v - range.start) / step).roundToInt() * step + range.start) },
            valueRange = range,
            steps = ((range.endInclusive - range.start) / step).toInt().coerceAtLeast(0) - 1
        )
    }
}
