package com.caifenxi.app.ui.screens

import android.webkit.WebView
import com.caifenxi.app.util.RuntimeLog

/**
 * 旧版网页适配器占位。正式站点适配在 domain/execution/GenericSiteAdapter。
 */
class WebPageAdapter(
    private val webView: WebView,
    private val onProgressUpdate: (Float) -> Unit = {},
    private val onElementFound: (String, Int) -> Unit = { _, _ -> }
) {
    enum class WebsiteType {
        UNKNOWN, PK10_BET, K3_BET, PC28_BET, LUCKY20_BET, CUSTOM
    }

    private var websiteType: WebsiteType = WebsiteType.UNKNOWN

    fun initialize() {
        try {
            val bridge = WebExecutorBridge()
            webView.addJavascriptInterface(WebViewInterface(bridge), "Android")
            RuntimeLog.info("WebPageAdapter", "JS 接口已注入（兼容占位）")
        } catch (e: Exception) {
            RuntimeLog.warn("WebPageAdapter", "注入失败: ${e.message}")
        }
        detectWebsiteType()
    }

    private fun detectWebsiteType() {
        websiteType = WebsiteType.UNKNOWN
        onProgressUpdate(0.05f)
        onElementFound("page", 0)
    }

    fun currentType(): WebsiteType = websiteType
}
