package com.caifenxi.app.domain.plan

import com.caifenxi.app.domain.model.LotteryConfig
import com.caifenxi.app.domain.model.LotteryType
import com.caifenxi.app.domain.model.PlanDefinition

/**
 * 彩种 → 计划池 唯一入口，禁止跨彩种混用计划定义。
 */
object LotteryPlanPools {

    fun novaPlansFor(type: LotteryType): List<PlanDefinition> = when (type) {
        LotteryType.YDH -> NovaYdhPlanPool.ALL
        LotteryType.K3 -> NovaK3PlanPool.ALL
        LotteryType.LUCK20 -> NovaLuck20PlanPool.ALL
        LotteryType.PKS -> NovaPlanPool.ALL
        LotteryType.PC28 -> NovaPc28PlanPool.ALL
        LotteryType.OTHER -> emptyList()
    }

    fun novaPlansFor(config: LotteryConfig): List<PlanDefinition> = novaPlansFor(config.type)

    fun find(planId: String, type: LotteryType): PlanDefinition? {
        if (planId.isBlank()) return null
        val hit = findAny(planId) ?: return null
        return hit.takeIf { belongsTo(it, type) }
    }

    fun findAny(planId: String): PlanDefinition? {
        if (planId.isBlank()) return null
        return when {
            planId.startsWith("NOVA-YDH-") -> NovaYdhPlanPool.find(planId)
            planId.startsWith("NOVA-K3-") -> NovaK3PlanPool.find(planId)
            planId.startsWith("NOVA-L20-") -> NovaLuck20PlanPool.find(planId)
            planId.startsWith("NOVA-PC28-") -> NovaPc28PlanPool.find(planId)
            planId.startsWith("NOVA-GEN-") -> null
            planId.startsWith("NOVA-") -> NovaPlanPool.find(planId)
            planId.startsWith("V2-") -> PlanPoolV2.find(planId)
            planId.startsWith("LEGACY-") -> PlanPoolV2.find(planId)
            else -> PlanPool.ALL.find { it.planId == planId }
        }
    }

    fun belongsTo(plan: PlanDefinition, type: LotteryType): Boolean {
        if (plan.supportedTypes.isNotEmpty()) return type in plan.supportedTypes
        if (PlanPool.ALL.any { it.planId == plan.planId }) return true
        val id = plan.planId
        return when (type) {
            LotteryType.YDH -> id.startsWith("NOVA-YDH-") || id.startsWith("NOVA-GEN-YDH")
            LotteryType.K3 -> id.startsWith("NOVA-K3-") || id.startsWith("NOVA-GEN-K3")
            LotteryType.LUCK20 -> id.startsWith("NOVA-L20-") || id.startsWith("NOVA-GEN-LUCK20")
            LotteryType.PKS -> (id.startsWith("NOVA-") && !id.startsWith("NOVA-YDH-") && !id.startsWith("NOVA-K3-") && !id.startsWith("NOVA-L20-") && !id.startsWith("NOVA-GEN-YDH") && !id.startsWith("NOVA-GEN-K3") && !id.startsWith("NOVA-GEN-LUCK20")) || PlanPool.ALL.any { it.planId == id }
            LotteryType.PC28 -> id.startsWith("NOVA-PC28-") || id.startsWith("NOVA-GEN-PC28")
            LotteryType.OTHER -> false
        }
    }

    /**
     * 原计划池是通用方向/号码计划池，不应只在 PKS/幸运20 显示。
     * DrawRecord 会先按当前彩种规则补全 dx/ds/combo，因此原计划可对所有已接入彩种回测。
     */
    fun legacyPlansFor(type: LotteryType): List<PlanDefinition> =
        when (type) {
            LotteryType.OTHER -> emptyList()
            else -> PlanPool.ALL.filter { it.supportedTypes.isEmpty() || type in it.supportedTypes }
        }

    fun defaultNovaId(type: LotteryType): String =
        novaPlansFor(type).firstOrNull()?.planId ?: ""
}
