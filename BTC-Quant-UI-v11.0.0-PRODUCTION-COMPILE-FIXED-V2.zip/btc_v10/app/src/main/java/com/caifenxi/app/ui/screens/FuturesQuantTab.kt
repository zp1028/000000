package com.caifenxi.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoGraph
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.caifenxi.app.domain.btc.BtcDirection
import com.caifenxi.app.domain.btc.futures.FuturesLogEntry
import com.caifenxi.app.domain.btc.futures.FuturesPosition
import com.caifenxi.app.domain.btc.futures.FuturesQuantConfig
import com.caifenxi.app.domain.btc.futures.FuturesSignal
import com.caifenxi.app.domain.btc.futures.LogLevel
import com.caifenxi.app.domain.btc.futures.MarginMode
import com.caifenxi.app.domain.btc.futures.PositionSide
import com.caifenxi.app.ui.BtcQuantViewModel
import com.caifenxi.app.ui.theme.CaiTokens
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 合约量化 Tab：币安 U 本位永续合约自动化量化交易
 *
 * 5 大组件：
 * 1. StrategyConfigCard - 策略配置（杠杆/仓位/止损止盈/追踪止损/保证金模式）
 * 2. SignalCard - 当前信号 + 自动开关
 * 3. PositionMonitorCard - 持仓实时监控
 * 4. DailyStatsCard - 日级统计 + 止损止盈进度条
 * 5. ExecutionLogCard - 执行日志
 */
@Composable
fun FuturesQuantTab(viewModel: BtcQuantViewModel) {
    val state by viewModel.state.collectAsState()
    val config by viewModel.futuresConfig.collectAsState()
    val signal by viewModel.futuresSignal.collectAsState()
    val position by viewModel.futuresPosition.collectAsState()
    val dailyStats by viewModel.futuresDailyStats.collectAsState()
    val logEntries by viewModel.futuresLog.collectAsState()
    val autoMode by viewModel.futuresAutoMode.collectAsState()

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
    ) {
        // === 标题 ===
        Row(
            Modifier.fillMaxWidth().padding(24.dp, 18.dp, 24.dp, 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Filled.AutoGraph, contentDescription = null, tint = CaiTokens.Accent)
            Spacer(Modifier.width(8.dp))
            Text("合约量化", style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.weight(1f))
            // Auto mode indicator
            Surface(
                shape = RoundedCornerShape(100.dp),
                color = if (autoMode) CaiTokens.Success.copy(alpha = 0.15f)
                    else MaterialTheme.colorScheme.surfaceVariant
            ) {
                Row(
                    Modifier.padding(12.dp, 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        Modifier.size(8.dp).clip(RoundedCornerShape(50))
                            .background(if (autoMode) CaiTokens.Success else CaiTokens.Muted)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        if (autoMode) "自动运行中" else "手动模式",
                        style = MaterialTheme.typography.labelMedium,
                        color = if (autoMode) CaiTokens.Success else CaiTokens.Muted
                    )
                }
            }
        }

        // 1. 策略配置
        StrategyConfigCard(config, viewModel)

        // 2. 当前信号 + 自动开关
        SignalCard(signal, autoMode, config, viewModel)

        // 3. 持仓监控
        PositionMonitorCard(position, state.fundingRate, viewModel)

        // 4. 日级统计
        DailyStatsCard(dailyStats, config)

        // 5. 执行日志
        ExecutionLogCard(logEntries)

        Spacer(Modifier.height(48.dp))
    }
}

// ==================== 1. 策略配置 ====================

@Composable
private fun StrategyConfigCard(
    config: FuturesQuantConfig,
    viewModel: BtcQuantViewModel
) {
    var leverage by remember(config.leverage) { mutableStateOf(config.leverage.toString()) }
    var positionSize by remember(config.positionSizePct) { mutableStateOf(config.positionSizePct.toString()) }
    var slMult by remember(config.stopLossAtrMult) { mutableStateOf(config.stopLossAtrMult.toString()) }
    var tpMult by remember(config.takeProfitAtrMult) { mutableStateOf(config.takeProfitAtrMult.toString()) }
    var trailingEnabled by remember(config.trailingStopPct) { mutableStateOf(config.trailingStopPct != null) }
    var trailingPct by remember(config.trailingStopPct) { mutableStateOf((config.trailingStopPct ?: 3.0).toString()) }
    var marginIsolated by remember(config.marginMode) { mutableStateOf(config.marginMode == MarginMode.ISOLATED) }
    var minConfidence by remember(config.minConfidence) { mutableStateOf((config.minConfidence * 100).toInt().toString()) }
    var maxDailyLoss by remember(config.maxDailyLossUsdt) { mutableStateOf(config.maxDailyLossUsdt.toInt().toString()) }
    var fundingArb by remember(config.enableFundingArb) { mutableStateOf(config.enableFundingArb) }
    var multiTP by remember(config.enableMultiTakeProfit) { mutableStateOf(config.enableMultiTakeProfit) }

    Card(
        Modifier.fillMaxWidth().padding(16.dp, 8.dp),
        shape = RoundedCornerShape(CaiTokens.RadiusCard),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(20.dp)) {
            Text("策略配置", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(16.dp))

            // 杠杆 & 仓位
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                ConfigInput("杠杆 (x)", leverage, Modifier.weight(1f)) { leverage = it }
                Spacer(Modifier.width(12.dp))
                ConfigInput("仓位 (%)", positionSize, Modifier.weight(1f)) { positionSize = it }
            }
            Spacer(Modifier.height(12.dp))

            // 止损 & 止盈
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                ConfigInput("止损 ATR", slMult, Modifier.weight(1f)) { slMult = it }
                Spacer(Modifier.width(12.dp))
                ConfigInput("止盈 ATR", tpMult, Modifier.weight(1f)) { tpMult = it }
            }
            Spacer(Modifier.height(12.dp))

            // 最低置信度 & 日最大亏损
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                ConfigInput("最低置信 (%)", minConfidence, Modifier.weight(1f)) { minConfidence = it }
                Spacer(Modifier.width(12.dp))
                ConfigInput("日最大亏损 (U)", maxDailyLoss, Modifier.weight(1f)) { maxDailyLoss = it }
            }
            Spacer(Modifier.height(16.dp))

            // 追踪止损开关
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("追踪止损", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                Switch(checked = trailingEnabled, onCheckedChange = {
                    trailingEnabled = it
                    if (!it) trailingPct = "0"
                })
                if (trailingEnabled) {
                    Spacer(Modifier.width(12.dp))
                    ConfigInput("回撤 (%)", trailingPct, Modifier.width(80.dp)) { trailingPct = it }
                }
            }
            Spacer(Modifier.height(8.dp))

            // 保证金模式
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("保证金模式", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                FilterChip(
                    selected = marginIsolated,
                    onClick = { marginIsolated = true },
                    label = { Text("逐仓") }
                )
                Spacer(Modifier.width(8.dp))
                FilterChip(
                    selected = !marginIsolated,
                    onClick = { marginIsolated = false },
                    label = { Text("全仓") }
                )
            }
            Spacer(Modifier.height(8.dp))

            // 资金费率套利 & 多档止盈
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("资金费率套利", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                Switch(checked = fundingArb, onCheckedChange = { fundingArb = it })
            }
            Spacer(Modifier.height(8.dp))
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("多档止盈", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                Switch(checked = multiTP, onCheckedChange = { multiTP = it })
            }
            Spacer(Modifier.height(16.dp))

            // 应用配置按钮
            Button(
                onClick = {
                    viewModel.updateFuturesConfig(
                        leverage = leverage.toIntOrNull()?.coerceIn(1, 125),
                        positionSizePct = positionSize.toDoubleOrNull()?.coerceIn(0.1, 100.0),
                        stopLossAtrMult = slMult.toDoubleOrNull()?.coerceIn(0.5, 10.0),
                        takeProfitAtrMult = tpMult.toDoubleOrNull()?.coerceIn(0.5, 20.0),
                        trailingStopPct = if (trailingEnabled) trailingPct.toDoubleOrNull() else null,
                        marginMode = if (marginIsolated) MarginMode.ISOLATED else MarginMode.CROSSED,
                        minConfidence = (minConfidence.toIntOrNull()?.coerceIn(1, 100) ?: 60) / 100.0,
                        maxDailyLossUsdt = maxDailyLoss.toDoubleOrNull(),
                        enableFundingArb = fundingArb,
                        enableMultiTakeProfit = multiTP
                    )
                },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(CaiTokens.RadiusButton)
            ) { Text("应用配置") }
        }
    }
}

@Composable
private fun ConfigInput(
    label: String,
    value: String,
    modifier: Modifier = Modifier,
    onValueChange: (String) -> Unit
) {
    Column(modifier) {
        Text(label, style = MaterialTheme.typography.labelMedium, color = CaiTokens.Muted)
        Spacer(Modifier.height(4.dp))
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            textStyle = MaterialTheme.typography.bodyMedium
        )
    }
}

// ==================== 2. 信号 + 自动开关 ====================

@Composable
private fun SignalCard(
    signal: FuturesSignal?,
    autoMode: Boolean,
    config: FuturesQuantConfig,
    viewModel: BtcQuantViewModel
) {
    val state by viewModel.state.collectAsState()
    val curConsensus = state.consensus

    Card(
        Modifier.fillMaxWidth().padding(16.dp, 4.dp),
        shape = RoundedCornerShape(CaiTokens.RadiusCard),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(20.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("当前信号", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.weight(1f))
                // 自动模式开关
                Switch(
                    checked = autoMode,
                    onCheckedChange = { viewModel.setFuturesAutoMode(it) },
                    colors = SwitchDefaults.colors(
                        checkedTrackColor = CaiTokens.Success,
                        checkedThumbColor = Color.White
                    )
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    if (autoMode) "自动" else "手动",
                    style = MaterialTheme.typography.labelMedium,
                    color = if (autoMode) CaiTokens.Success else CaiTokens.Muted
                )
            }
            Spacer(Modifier.height(16.dp))

            if (signal == null) {
                // 无信号
                Row(
                    Modifier.fillMaxWidth().padding(16.dp),
                    horizontalArrangement = Arrangement.Center
                ) {
                    val dirText = curConsensus?.direction?.name ?: "无数据"
                    val conf = curConsensus?.let { " (${(it.probability * 100).toInt()}%)" } ?: ""
                    Text(
                        "无交易信号 — 共识: $dirText$conf",
                        style = MaterialTheme.typography.bodyMedium,
                        color = CaiTokens.Muted,
                        textAlign = TextAlign.Center
                    )
                }
            } else {
                // 方向指示
                val isLong = signal.direction == BtcDirection.UP
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        if (isLong) Icons.Filled.TrendingUp else Icons.Filled.TrendingDown,
                        contentDescription = null,
                        tint = if (isLong) CaiTokens.Success else CaiTokens.Danger,
                        modifier = Modifier.size(32.dp)
                    )
                    Spacer(Modifier.width(12.dp))
                    Text(
                        if (isLong) "做多 LONG" else "做空 SHORT",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = if (isLong) CaiTokens.Success else CaiTokens.Danger
                    )
                    Spacer(Modifier.weight(1f))
                    Text(
                        "${(signal.confidence * 100).toInt()}%",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = CaiTokens.Accent
                    )
                }
                Spacer(Modifier.height(16.dp))

                // 信号详情
                SignalMetricRow("入场价", "%.0f".format(signal.entry))
                SignalMetricRow("止损价", "%.0f".format(signal.stopLoss))
                SignalMetricRow("止盈价", "%.0f".format(signal.takeProfit))
                SignalMetricRow("杠杆", "${signal.leverage}x")
                SignalMetricRow("数量", "%.4f BTC".format(signal.quantity))
                SignalMetricRow("保证金", "%.1f USDT".format(signal.margin))
                SignalMetricRow("ATR", "%.0f".format(signal.atrValue))
                signal.trailingStopPct?.let {
                    SignalMetricRow("追踪止损", "${it}%")
                }
                Spacer(Modifier.height(8.dp))

                // 信号原因
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant
                ) {
                    Text(
                        signal.reason,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(12.dp, 8.dp)
                    )
                }
                Spacer(Modifier.height(16.dp))

                // 手动开仓按钮（非自动模式时可用）
                if (!autoMode) {
                    Button(
                        onClick = {
                            // 手动模式下也能触发开仓
                            viewModel.setFuturesAutoMode(true)
                            viewModel.tickFuturesQuant()
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(CaiTokens.RadiusButton),
                        colors = ButtonDefaults.buttonColors(containerColor = CaiTokens.Accent)
                    ) {
                        Icon(Icons.Filled.PlayArrow, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("手动开仓")
                    }
                }
            }
        }
    }
}

@Composable
private fun SignalMetricRow(label: String, value: String) {
    Row(
        Modifier.fillMaxWidth().padding(4.dp, 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = CaiTokens.Muted)
        Text(value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
    }
}

// ==================== 3. 持仓监控 ====================

@Composable
private fun PositionMonitorCard(
    position: FuturesPosition,
    fundingRate: Double?,
    viewModel: BtcQuantViewModel
) {
    Card(
        Modifier.fillMaxWidth().padding(16.dp, 4.dp),
        shape = RoundedCornerShape(CaiTokens.RadiusCard),
        colors = CardDefaults.cardColors(
            containerColor = if (position.isEmpty) MaterialTheme.colorScheme.surface
                else MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(Modifier.padding(20.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("持仓监控", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.weight(1f))
                if (!position.isEmpty) {
                    // 平仓按钮
                    OutlinedButton(
                        onClick = { viewModel.closeFuturesPosition("manual") },
                        shape = RoundedCornerShape(CaiTokens.RadiusButton),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = CaiTokens.Danger)
                    ) {
                        Icon(Icons.Filled.Stop, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("全部平仓")
                    }
                }
            }
            Spacer(Modifier.height(16.dp))

            if (position.isEmpty) {
                Text(
                    "无持仓",
                    style = MaterialTheme.typography.bodyMedium,
                    color = CaiTokens.Muted,
                    modifier = Modifier.padding(16.dp).fillMaxWidth(),
                    textAlign = TextAlign.Center
                )
            } else {
                // 方向 & 杠杆
                val isLong = position.side == PositionSide.LONG
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        if (isLong) Icons.Filled.TrendingUp else Icons.Filled.TrendingDown,
                        contentDescription = null,
                        tint = if (isLong) CaiTokens.Success else CaiTokens.Danger
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        "${position.symbol} ${if (isLong) "LONG" else "SHORT"} ${position.leverage}x",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(Modifier.height(12.dp))

                // 盈亏高亮
                val pnlColor = if (position.unrealizedPnl >= 0) CaiTokens.Success else CaiTokens.Danger
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom
                ) {
                    Text("未实现盈亏", style = MaterialTheme.typography.bodyMedium, color = CaiTokens.Muted)
                    Text(
                        "%+.2f USDT (%+.1f%%)".format(position.unrealizedPnl, position.roiPct),
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = pnlColor
                    )
                }
                Spacer(Modifier.height(12.dp))

                // 持仓详情
                PosMetricRow("入场价", "%.0f".format(position.entryPrice))
                PosMetricRow("标记价", "%.0f".format(position.markPrice))
                PosMetricRow("数量", "%.4f BTC".format(position.quantity))
                PosMetricRow("保证金", "%.1f USDT".format(position.margin))
                PosMetricRow("保证金比率", "%.1f%%".format(position.marginRatio * 100))
                PosMetricRow("强平价", "%.0f".format(position.liquidationPrice))
                position.stopLossPrice?.let { PosMetricRow("止损", "%.0f".format(it)) }
                position.takeProfitPrice?.let { PosMetricRow("止盈", "%.0f".format(it)) }
                fundingRate?.let { PosMetricRow("资金费率", "%.4f%%".format(it * 100)) }

                // 保证金比率预警
                if (position.marginRatio in 0.0..0.20) {
                    Spacer(Modifier.height(8.dp))
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = CaiTokens.Warning.copy(alpha = 0.15f)
                    ) {
                        Row(Modifier.padding(12.dp, 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Warning, contentDescription = null, tint = CaiTokens.Warning)
                            Spacer(Modifier.width(8.dp))
                            Text(
                                "保证金比率偏低 ${"%.1f%%".format(position.marginRatio * 100)}",
                                style = MaterialTheme.typography.labelMedium,
                                color = CaiTokens.Warning
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PosMetricRow(label: String, value: String) {
    Row(
        Modifier.fillMaxWidth().padding(4.dp, 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = CaiTokens.Muted)
        Text(value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
    }
}

// ==================== 4. 日级统计 ====================

@Composable
private fun DailyStatsCard(
    stats: com.caifenxi.app.domain.btc.futures.FuturesDailyStats,
    config: FuturesQuantConfig
) {
    Card(
        Modifier.fillMaxWidth().padding(16.dp, 4.dp),
        shape = RoundedCornerShape(CaiTokens.RadiusCard),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(20.dp)) {
            Text("日级统计 (${stats.date})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(16.dp))

            // 4个核心指标
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                StatMetric("日净盈亏", "%+.1f".format(stats.netPnl),
                    if (stats.netPnl >= 0) CaiTokens.Success else CaiTokens.Danger)
                StatMetric("胜率", "%.0f%%".format(stats.winRate), CaiTokens.Accent)
                StatMetric("交易次数", "${stats.totalTrades}", MaterialTheme.colorScheme.onSurface)
                StatMetric("最大回撤", "%.1f%%".format(stats.maxDrawdown), CaiTokens.Warning)
            }
            Spacer(Modifier.height(16.dp))

            // 止损止盈进度条
            val maxLoss = config.maxDailyLossUsdt
            val profitTarget = maxLoss * 5  // 5:1 止盈目标
            val progress = if (stats.netPnl <= -maxLoss) 0f
                else if (stats.netPnl >= profitTarget) 1f
                else ((stats.netPnl + maxLoss) / (profitTarget + maxLoss)).toFloat().coerceIn(0f, 1f)

            Column {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("止损 -${maxLoss.toInt()}U", style = MaterialTheme.typography.labelSmall, color = CaiTokens.Danger)
                    Text("当前", style = MaterialTheme.typography.labelSmall, color = CaiTokens.Accent)
                    Text("止盈 +${profitTarget.toInt()}U", style = MaterialTheme.typography.labelSmall, color = CaiTokens.Success)
                }
                Spacer(Modifier.height(4.dp))
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                    color = if (stats.netPnl >= 0) CaiTokens.Success else CaiTokens.Danger
                )
            }

            // 连亏 & 止损/止盈命中
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("连亏: ${stats.currentConsecutiveLosses}", style = MaterialTheme.typography.labelMedium,
                    color = if (stats.currentConsecutiveLosses >= 3) CaiTokens.Danger else CaiTokens.Muted)
                Text("SL: ${stats.stopLossHits} / TP: ${stats.takeProfitHits}",
                    style = MaterialTheme.typography.labelMedium, color = CaiTokens.Muted)
                Text("资金费率: %.2fU".format(stats.fundingCost),
                    style = MaterialTheme.typography.labelMedium, color = CaiTokens.Muted)
            }

            // 日亏熔断指示
            if (stats.isStopLossHit) {
                Spacer(Modifier.height(8.dp))
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = CaiTokens.Danger.copy(alpha = 0.15f)
                ) {
                    Row(Modifier.padding(12.dp, 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Warning, contentDescription = null, tint = CaiTokens.Danger)
                        Spacer(Modifier.width(8.dp))
                        Text("日亏熔断已触发", style = MaterialTheme.typography.labelMedium, color = CaiTokens.Danger)
                    }
                }
            }
        }
    }
}

@Composable
private fun StatMetric(label: String, value: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = color)
        Text(label, style = MaterialTheme.typography.labelSmall, color = CaiTokens.Muted)
    }
}

// ==================== 5. 执行日志 ====================

@Composable
private fun ExecutionLogCard(entries: List<FuturesLogEntry>) {
    val timeFmt = remember { SimpleDateFormat("HH:mm:ss", Locale.US) }

    Card(
        Modifier.fillMaxWidth().padding(16.dp, 4.dp),
        shape = RoundedCornerShape(CaiTokens.RadiusCard),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(20.dp)) {
            Text("执行日志", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(12.dp))

            if (entries.isEmpty()) {
                Text(
                    "暂无日志",
                    style = MaterialTheme.typography.bodyMedium,
                    color = CaiTokens.Muted,
                    modifier = Modifier.padding(16.dp).fillMaxWidth(),
                    textAlign = TextAlign.Center
                )
            } else {
                entries.take(30).forEach { entry ->
                    val color = when (entry.level) {
                        LogLevel.SUCCESS -> CaiTokens.Success
                        LogLevel.ERROR -> CaiTokens.Danger
                        LogLevel.WARN -> CaiTokens.Warning
                        LogLevel.INFO -> MaterialTheme.colorScheme.onSurfaceVariant
                    }
                    Row(
                        Modifier.fillMaxWidth().padding(4.dp, 2.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Text(
                            timeFmt.format(Date(entry.timestamp)),
                            style = MaterialTheme.typography.labelSmall,
                            color = CaiTokens.Muted
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            entry.action,
                            style = MaterialTheme.typography.labelSmall,
                            color = color,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            entry.detail,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.weight(1f)
                        )
                        entry.pnl?.let { pnl ->
                            Text(
                                "%+.2f".format(pnl),
                                style = MaterialTheme.typography.labelSmall,
                                color = if (pnl >= 0) CaiTokens.Success else CaiTokens.Danger,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}
