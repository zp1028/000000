#!/bin/bash
GRADLE_VERSION=8.9
echo "Downloading Gradle wrapper..."
curl -L -o gradle/wrapper/gradle-wrapper.jar https://github.com/gradle/gradle/raw/v${GRADLE_VERSION}/gradle/wrapper/gradle-wrapper.jar
echo "Gradle wrapper downloaded successfully."
