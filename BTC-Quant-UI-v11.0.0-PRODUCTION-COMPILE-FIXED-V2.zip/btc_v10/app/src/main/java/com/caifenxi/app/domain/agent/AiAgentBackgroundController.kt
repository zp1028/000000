package com.caifenxi.app.domain.agent

import android.content.Context
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.caifenxi.app.work.AiAgentBackgroundWorker
import java.util.concurrent.TimeUnit

object AiAgentBackgroundController {
    private const val WORK_NAME = "ai_agent_background_heartbeat"
    fun start(context: Context) {
        val app = context.applicationContext
        AiAgentBackgroundStore(app).setEnabled(true)
        val request = PeriodicWorkRequestBuilder<AiAgentBackgroundWorker>(15, TimeUnit.MINUTES).build()
        WorkManager.getInstance(app).enqueueUniquePeriodicWork(WORK_NAME, ExistingPeriodicWorkPolicy.UPDATE, request)
    }
    fun stop(context: Context) {
        val app = context.applicationContext
        AiAgentBackgroundStore(app).setEnabled(false)
        WorkManager.getInstance(app).cancelUniqueWork(WORK_NAME)
    }
}
