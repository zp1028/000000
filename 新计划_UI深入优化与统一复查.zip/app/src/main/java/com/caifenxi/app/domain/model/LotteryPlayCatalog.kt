package com.caifenxi.app.domain.model

/**
 * 各彩种可下注/可预测玩法目录：计划、图表、挂机、无障碍、文案统一从此取，避免串彩种。
 */
object LotteryPlayCatalog {

    data class Play(
        /** 内部 playType，与 PlanDefinition.playType 对齐 */
        val id: String,
        /** UI 短名 */
        val label: String,
        /** 说明 */
        val desc: String = "",
        /** 是否方向类（大小单双龙虎等） */
        val isDirection: Boolean = true
    )

    fun plays(type: LotteryType): List<Play> = when (type) {
        LotteryType.PKS -> listOf(
            Play("大小", "大小", "冠亚和大小"),
            Play("单双", "单双", "冠亚和单双"),
            Play("组合", "组合", "大单/大双/小单/小双"),
            Play("数字", "数字", "任选号码"),
            Play("位置", "定位", "位置+号码", isDirection = false)
        )
        LotteryType.LUCK20 -> listOf(
            Play("大小", "大小", "和值大小"),
            Play("单双", "单双", "和值单双"),
            Play("组合", "组合", "和值组合"),
            Play("数字", "任选号码", "任意中1赔4", isDirection = false)
        )
        LotteryType.YDH -> listOf(
            Play("球大小", "球大小", "第1～6球：4-6大、1-3小"),
            Play("球单双", "球单双", "1/3/5单、2/4/6双"),
            Play("龙虎", "龙虎", "1vs6、2vs5、3vs4（等不中）"),
            Play("定位", "定位", "第N球直选1-6", isDirection = false)
        )
        LotteryType.K3 -> listOf(
            Play("和值大小", "和值大小", "≥11大、≤10小"),
            Play("三军", "三军", "点数至少出一次", isDirection = false),
            Play("鱼虾蟹", "鱼虾蟹", "同三军映射", isDirection = false),
            Play("长牌", "长牌", "两不同号都出现", isDirection = false)
        )
        LotteryType.PC28 -> listOf(
            Play("和值大小", "和值大小", "待细化"),
            Play("和值单双", "和值单双", "待细化")
        )
        LotteryType.OTHER -> emptyList()
    }

    fun playIds(type: LotteryType): List<String> = plays(type).map { it.id }

    fun labelOf(type: LotteryType, playId: String): String =
        plays(type).find { it.id == playId }?.label ?: playId

    fun summaryText(type: LotteryType): String {
        val list = plays(type)
        if (list.isEmpty()) return "暂无开放玩法"
        return list.joinToString(" · ") { it.label }
    }

    fun filterChipOptions(type: LotteryType): List<String> =
        listOf("全部") + plays(type).map { it.id }
}
