package com.caifenxi.app.domain.plan

import com.caifenxi.app.domain.model.PlanDefinition

/** 加拿大PC28 最小计划池（和值大小/单双） */
object NovaPc28PlanPool {
    private val algos = listOf("FREQ", "EWMA", "MKV1", "RHYTHM")
    val ALL: List<PlanDefinition> = buildList {
        for (algo in algos) {
            add(
                PlanDefinition(
                    planId = "NOVA-PC28-DX-$algo",
                    planName = "和值大小·$algo",
                    category = "PC28-和值",
                    algorithm = algo,
                    window = 30,
                    playType = "和值大小",
                    baselineValue = 0.50
                )
            )
            add(
                PlanDefinition(
                    planId = "NOVA-PC28-DS-$algo",
                    planName = "和值单双·$algo",
                    category = "PC28-和值",
                    algorithm = algo,
                    window = 30,
                    playType = "和值单双",
                    baselineValue = 0.50
                )
            )
        }
    }
    fun find(planId: String): PlanDefinition? = ALL.find { it.planId == planId }
}
