package com.caifenxi.app.domain.btc

import kotlin.math.abs
import com.caifenxi.app.domain.btc.plan.BtcStrategyCorrelationEngine
import com.caifenxi.app.domain.btc.factor.QuantFactorPortfolioEngine

/** Unified decision contract shared by backtest, paper, testnet and live runtime. */
data class BtcDecisionContext(
    val symbol: String,
    val timeframe: String,
    val barId: Long,
    val marketRegime: MarketRegime,
    val probability: Double,
    val direction: BtcDirection,
    val strategyIds: List<String>,
    val strategyWeights: Map<String, Double>,
    val expectedMovePct: Double,
    val riskScore: Double,
    val reason: String,
    val factorPortfolioConfidence: Double = 0.0,
    val factorRiskBudget: Double = 0.0
)

data class BtcTradingDecision(
    val decisionId: String,
    val context: BtcDecisionContext,
    val action: DecisionAction,
    val confidence: Double,
    val createdAt: Long = System.currentTimeMillis()
)

enum class DecisionAction { LONG, SHORT, WAIT, BLOCK }

/**
 * Turns research consensus into one deterministic decision. Execution is deliberately outside this class.
 */
class BtcDecisionPipeline(
    private val minProbability: Double = 0.62,
    private val maxRiskScore: Double = 0.90
) {
    fun build(
        symbol: String,
        timeframe: String,
        candles: List<BtcCandle>,
        plans: List<BtcPlanSignal>,
        consensus: BtcConsensus,
        minProbabilityOverride: Double? = null,
        factorPortfolio: QuantFactorPortfolioEngine.Portfolio? = null
    ): BtcTradingDecision {
        val diversified = BtcStrategyCorrelationEngine.diversify(plans)
        val ids = diversified.filter { it.direction == consensus.direction && it.contribution != 0.0 }
            .sortedByDescending { abs(it.contribution) }
            .take(8)
            .map { it.planId }
        val weights = diversified.associate { it.planId to it.weight }
        val portfolioMismatch = factorPortfolio != null && factorPortfolio.direction != BtcDirection.FLAT && factorPortfolio.direction != consensus.direction
        val adjustedRisk = (consensus.riskScore + if (portfolioMismatch) 0.12 else 0.0).coerceIn(0.0, 1.0)
        val action = when {
            consensus.direction == BtcDirection.FLAT -> DecisionAction.WAIT
            consensus.probability < (minProbabilityOverride ?: minProbability).coerceIn(0.50, 0.99) -> DecisionAction.WAIT
            adjustedRisk >= maxRiskScore -> DecisionAction.BLOCK
            consensus.direction == BtcDirection.UP -> DecisionAction.LONG
            else -> DecisionAction.SHORT
        }
        val decisionId = "$symbol|$timeframe|${candles.lastOrNull()?.openTime ?: 0L}|${action.name}"
        val reason = "regime=${consensus.regime}; probability=${"%.3f".format(consensus.probability)}; risk=${"%.3f".format(adjustedRisk)}; factorConf=${"%.3f".format(factorPortfolio?.confidence ?: 0.0)}; plans=${ids.joinToString(",")}"
        return BtcTradingDecision(
            decisionId = decisionId,
            context = BtcDecisionContext(
                symbol = symbol,
                timeframe = timeframe,
                barId = candles.lastOrNull()?.openTime ?: 0L,
                marketRegime = consensus.regime,
                probability = consensus.probability,
                direction = consensus.direction,
                strategyIds = ids,
                strategyWeights = weights,
                expectedMovePct = consensus.expectedMovePct,
                riskScore = adjustedRisk,
                reason = reason,
                factorPortfolioConfidence = factorPortfolio?.confidence ?: 0.0,
                factorRiskBudget = factorPortfolio?.grossRiskFraction ?: 0.0
            ),
            action = action,
            confidence = consensus.probability
        )
    }
}

/** Compact correlation-aware weighting helper; used after ordinary dynamic weighting. */
object BtcStrategyDiversifier {
    fun diversify(signals: List<BtcPlanSignal>): List<BtcPlanSignal> {
        if (signals.size < 2) return signals
        val kept = mutableListOf<BtcPlanSignal>()
        signals.sortedByDescending { abs(it.contribution) }.forEach { candidate ->
            val duplicateFamily = kept.any { it.family == candidate.family && it.direction == candidate.direction }
            val penalty = if (duplicateFamily) 0.82 else 1.0
            // A family-level proxy avoids pretending we have a full return-correlation matrix before outcomes exist.
            kept += candidate.copy(
                weight = (candidate.weight * penalty).coerceIn(0.15, 2.5),
                contribution = candidate.contribution * penalty
            )
        }
        return kept.sortedByDescending { abs(it.contribution) }
    }
}
