package com.caifenxi.app.domain.btc.portfolio

import com.caifenxi.app.domain.btc.BtcDirection
import com.caifenxi.app.domain.btc.TradingSignal
import kotlin.math.abs

data class PortfolioLimits(
    val maxDailyLossUsdt: Double = 200.0,
    val maxPerpNotionalUsdt: Double = 500.0,
    val maxEventPremiumUsdt: Double = 50.0,
    val maxProbNotionalUsdt: Double = 100.0,
    val maxSameBtcViewUsdt: Double = 400.0,
    val maxOpenOrders: Int = 5
)

data class PortfolioState(
    val dayPnlUsdt: Double = 0.0,
    val perpNotionalUsdt: Double = 0.0,
    val eventPremiumOpenUsdt: Double = 0.0,
    val probNotionalUsdt: Double = 0.0,
    val openOrderCount: Int = 0,
    val netBtcViewUsdt: Double = 0.0 // + long bias, - short bias
)

data class PortfolioDecision(
    val allowed: Boolean,
    val reason: String,
    val adjustedSize: Double? = null
)

/**
 * Cross-engine risk shell: prevents Perp long + Event Higher + YES from unbounded stacking.
 */
class PortfolioRiskEngine(private val limits: PortfolioLimits = PortfolioLimits()) {

    fun authorizePerp(signal: TradingSignal.ContractSignal, state: PortfolioState, markPrice: Double): PortfolioDecision {
        if (state.dayPnlUsdt <= -limits.maxDailyLossUsdt) return deny("日亏熔断")
        if (state.openOrderCount >= limits.maxOpenOrders) return deny("挂单过多")
        val notional = signal.positionSize * markPrice
        if (state.perpNotionalUsdt + notional > limits.maxPerpNotionalUsdt) return deny("永续名义超限")
        val view = viewDelta(signal.direction, notional)
        if (abs(state.netBtcViewUsdt + view) > limits.maxSameBtcViewUsdt) return deny("同向BTC暴露超限")
        return PortfolioDecision(true, "ok", signal.positionSize)
    }

    fun authorizeEvent(signal: TradingSignal.EventContractSignal, state: PortfolioState): PortfolioDecision {
        if (state.dayPnlUsdt <= -limits.maxDailyLossUsdt) return deny("日亏熔断")
        if (state.eventPremiumOpenUsdt + signal.premium > limits.maxEventPremiumUsdt) return deny("事件合约Premium超限")
        val view = viewDelta(signal.direction, signal.premium * 4) // rough exposure proxy
        if (abs(state.netBtcViewUsdt + view) > limits.maxSameBtcViewUsdt) return deny("同向BTC暴露超限")
        return PortfolioDecision(true, "ok")
    }

    fun authorizeProb(signal: TradingSignal.PredictionMarketSignal, state: PortfolioState, sizeUsdt: Double): PortfolioDecision {
        if (state.dayPnlUsdt <= -limits.maxDailyLossUsdt) return deny("日亏熔断")
        if (state.probNotionalUsdt + sizeUsdt > limits.maxProbNotionalUsdt) return deny("预测市名义超限")
        // YES on "BTC up" markets roughly long; NO roughly short — simplified by outcome label
        val view = when (signal.outcome.uppercase()) {
            "YES" -> sizeUsdt
            "NO" -> -sizeUsdt
            else -> 0.0
        }
        if (abs(state.netBtcViewUsdt + view) > limits.maxSameBtcViewUsdt) return deny("同向BTC暴露超限")
        return PortfolioDecision(true, "ok", sizeUsdt)
    }

    private fun viewDelta(dir: BtcDirection, notional: Double): Double = when (dir) {
        BtcDirection.UP -> notional
        BtcDirection.DOWN -> -notional
        BtcDirection.FLAT -> 0.0
    }

    private fun deny(msg: String) = PortfolioDecision(false, msg)
}
