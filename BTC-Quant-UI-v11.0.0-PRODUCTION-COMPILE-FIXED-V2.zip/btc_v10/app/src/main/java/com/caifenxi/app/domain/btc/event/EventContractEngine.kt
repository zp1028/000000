package com.caifenxi.app.domain.btc.event

import com.caifenxi.app.domain.btc.BtcCandle
import com.caifenxi.app.domain.btc.BtcConsensus
import com.caifenxi.app.domain.btc.BtcDirection
import com.caifenxi.app.domain.btc.TradingSignal
import kotlin.math.abs

enum class EventExpiryWindow(val minutes: Int) {
    M10(10), M30(30), H1(60), H4(240), D1(1440)
}

data class EventContractQuote(
    val underlying: String,
    val window: EventExpiryWindow,
    val side: BtcDirection,
    val premiumUsdt: Double,
    val payoutUsdt: Double,
    val impliedPWin: Double
)

/**
 * Binance-style event contract logic (Higher/Lower).
 * Live placement depends on official API availability — broker defaults to PAPER/dry-run.
 */
class EventContractEngine(
    private val minEdge: Double = 0.05,
    private val defaultPremium: Double = 5.0
) {
    fun quote(
        underlying: String,
        window: EventExpiryWindow,
        consensus: BtcConsensus?,
        candles: List<BtcCandle>,
        premium: Double = defaultPremium
    ): EventContractQuote? {
        if (consensus == null || consensus.direction == BtcDirection.FLAT) return null
        val pWin = consensus.probability.coerceIn(0.4, 0.75)
        // Simplified payout display: premium / (1 - margin); real product shows platform payout
        val payout = premium * (1.0 + (pWin - 0.5) * 1.2).coerceAtLeast(1.05)
        return EventContractQuote(
            underlying = underlying,
            window = window,
            side = consensus.direction,
            premiumUsdt = premium,
            payoutUsdt = payout,
            impliedPWin = pWin
        )
    }

    fun edge(quote: EventContractQuote): Double {
        // EV ≈ pWin * payout - premium  (normalized by premium)
        return (quote.impliedPWin * quote.payoutUsdt - quote.premiumUsdt) / quote.premiumUsdt
    }

    fun toSignal(quote: EventContractQuote, windowId: String): TradingSignal.EventContractSignal? {
        val e = edge(quote)
        if (e < minEdge) return null
        return TradingSignal.EventContractSignal(
            venue = "BINANCE_EVENT",
            windowId = windowId,
            underlying = quote.underlying,
            expiry = System.currentTimeMillis() + quote.window.minutes * 60_000L,
            direction = quote.side,
            premium = quote.premiumUsdt,
            pWin = quote.impliedPWin,
            edgeAfterPremium = e,
            action = "BUY"
        )
    }

    /** Align window to candle interval roughly for backtest labeling. */
    fun windowHit(candles: List<BtcCandle>, fromIdx: Int, minutes: Int, side: BtcDirection): Boolean {
        if (fromIdx >= candles.lastIndex) return false
        val start = candles[fromIdx].close
        // approximate bars: assume 5m bars if unknown
        val bars = (minutes / 5).coerceAtLeast(1)
        val endIdx = (fromIdx + bars).coerceAtMost(candles.lastIndex)
        val end = candles[endIdx].close
        return if (side == BtcDirection.UP) end > start else end < start
    }
}
