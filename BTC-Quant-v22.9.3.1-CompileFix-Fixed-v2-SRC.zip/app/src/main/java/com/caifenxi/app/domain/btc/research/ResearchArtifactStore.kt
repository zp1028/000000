package com.caifenxi.app.domain.btc.research

import android.content.Context

/** Small persistent artifact registry; latest artifact is selected only when its cutoff is valid. */
class ResearchArtifactStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("btc_research_artifacts_v1", Context.MODE_PRIVATE)
    fun save(artifact: ResearchArtifact) { prefs.edit().putString("latest", ResearchArtifactCodec.encode(artifact)).apply() }
    fun latest(): ResearchArtifact? = runCatching { prefs.getString("latest", null)?.let(ResearchArtifactCodec::decode) }.getOrNull()
    fun latestBefore(cutoffMs: Long): ResearchArtifact? = latest()?.takeIf { it.datasetCutoffMs <= cutoffMs }
    fun clear() { prefs.edit().remove("latest").apply() }
}
