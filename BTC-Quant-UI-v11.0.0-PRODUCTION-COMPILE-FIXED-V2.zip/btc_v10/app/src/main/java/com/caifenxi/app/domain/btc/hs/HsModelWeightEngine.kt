package com.caifenxi.app.domain.btc.hs

import com.caifenxi.app.domain.btc.MarketRegime

/** Converts holdout/regime performance into conservative model weights. */
object HsModelWeightEngine {
    fun weights(report: HsModelLab.Report, regime: MarketRegime): Map<String, Double> {
        if (report.models.isEmpty()) return emptyMap()
        val raw = report.models.associate { model ->
            val cell = report.regimeMatrix.firstOrNull { it.modelId == model.modelId && it.regime == regime }
            val hit = cell?.hitRate ?: model.hitRate
            val brier = cell?.brier ?: model.brier
            val sampleConfidence = (cell?.samples ?: model.samples).coerceAtMost(100) / 100.0
            val score = (0.55 * hit + 0.45 * (1.0 - brier.coerceIn(0.0, 1.0))) * (0.65 + 0.35 * sampleConfidence)
            model.modelId to score.coerceAtLeast(0.05)
        }
        val sum = raw.values.sum().coerceAtLeast(1e-9)
        return raw.mapValues { (_, v) -> v / sum }
    }
}
