package com.caifenxi.app.domain.btc.futures

import android.content.Context

/** Single persistent source of truth for futures-quant configuration. */
class FuturesQuantConfigStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("btc_futures_quant_config_v1", Context.MODE_PRIVATE)

    fun load(): FuturesQuantConfig = FuturesQuantConfig(
        symbol = prefs.getString("symbol", "BTCUSDT") ?: "BTCUSDT",
        leverage = prefs.getInt("leverage", 3),
        positionSizePct = prefs.getString("positionSizePct", "5.0")?.toDoubleOrNull() ?: 5.0,
        stopLossAtrMult = prefs.getString("stopLossAtrMult", "1.5")?.toDoubleOrNull() ?: 1.5,
        takeProfitAtrMult = prefs.getString("takeProfitAtrMult", "3.0")?.toDoubleOrNull() ?: 3.0,
        trailingStopPct = if (prefs.contains("trailingStopPct")) prefs.getString("trailingStopPct", null)?.toDoubleOrNull() else null,
        marginMode = runCatching { MarginMode.valueOf(prefs.getString("marginMode", MarginMode.ISOLATED.name)!!) }.getOrDefault(MarginMode.ISOLATED),
        autoMode = prefs.getBoolean("autoMode", false),
        minConfidence = prefs.getString("minConfidence", "0.60")?.toDoubleOrNull() ?: 0.60,
        maxDailyLossUsdt = prefs.getString("maxDailyLossUsdt", "200.0")?.toDoubleOrNull() ?: 200.0,
        maxDailyLossPct = prefs.getString("maxDailyLossPct", "2.0")?.toDoubleOrNull() ?: 2.0,
        maxDrawdownPct = prefs.getString("maxDrawdownPct", "8.0")?.toDoubleOrNull() ?: 8.0,
        maxPositions = prefs.getInt("maxPositions", 3),
        maxLeverage = prefs.getInt("maxLeverage", 3),
        enableFundingArb = prefs.getBoolean("enableFundingArb", true),
        enableMultiTakeProfit = prefs.getBoolean("enableMultiTakeProfit", false)
    )

    fun save(c: FuturesQuantConfig) {
        prefs.edit()
            .putString("symbol", c.symbol)
            .putInt("leverage", c.leverage.coerceIn(1, 125))
            .putString("positionSizePct", c.positionSizePct.toString())
            .putString("stopLossAtrMult", c.stopLossAtrMult.toString())
            .putString("takeProfitAtrMult", c.takeProfitAtrMult.toString())
            .apply { if (c.trailingStopPct == null) remove("trailingStopPct") else putString("trailingStopPct", c.trailingStopPct.toString()) }
            .putString("marginMode", c.marginMode.name)
            .putBoolean("autoMode", c.autoMode)
            .putString("minConfidence", c.minConfidence.toString())
            .putString("maxDailyLossUsdt", c.maxDailyLossUsdt.toString())
            .putString("maxDailyLossPct", c.maxDailyLossPct.toString())
            .putString("maxDrawdownPct", c.maxDrawdownPct.toString())
            .putInt("maxPositions", c.maxPositions)
            .putInt("maxLeverage", c.maxLeverage.coerceIn(1, 125))
            .putBoolean("enableFundingArb", c.enableFundingArb)
            .putBoolean("enableMultiTakeProfit", c.enableMultiTakeProfit)
            .putLong("updatedAt", System.currentTimeMillis())
            .apply()
    }
}
