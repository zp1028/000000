package com.caifenxi.app.domain.btc.hs

import kotlin.math.abs

/** Post-trade attribution; intentionally independent from execution permissions. */
object HsAttributionEngine {
    data class Attribution(
        val samples:Int,
        val wins:Int,
        val hitRate:Double,
        val avgReturnPct:Double,
        val avgMfePct:Double,
        val avgMaePct:Double,
        val edgeCaptureRate:Double,
        val directionBias:Double
    )

    fun shadow(rows: List<HsShadowTradingStore.Closed>): Attribution {
        if(rows.isEmpty()) return Attribution(0,0,0.0,0.0,0.0,0.0,0.0,0.0)
        val wins=rows.count{it.outcome}
        val expectedEdge=rows.map{(it.probability-0.5).let{p->abs(p)*2.0}}.average().coerceAtLeast(1e-6)
        val realized=rows.map{abs(it.returnPct)/100.0}.average()
        val capture=(realized/expectedEdge).coerceIn(0.0,2.0)
        val bias=rows.map{if(it.direction.name=="UP") 1.0 else -1.0}.average()
        return Attribution(rows.size,wins,wins.toDouble()/rows.size,rows.map{it.returnPct}.average(),rows.map{it.mfePct}.average(),rows.map{it.maePct}.average(),capture,bias)
    }
}
