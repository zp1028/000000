package com.caifenxi.app.service

import android.content.Context
import android.graphics.Color as AndroidColor
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import com.caifenxi.app.CaiFenXiApplication
import com.caifenxi.app.domain.model.UserPrefs
import com.caifenxi.app.util.RuntimeLog

/**
 * 无障碍控制悬浮窗：挂在任意页面上，点「开始」即对当前屏幕执行一次大小/单双识别点击。
 * 与预测悬浮窗独立，避免拖动冲突；需悬浮窗权限。
 */
class AutoBetPanelController(private val context: Context) {

    private val appContext = context.applicationContext
    private val wm = appContext.getSystemService(Context.WINDOW_SERVICE) as WindowManager

    private var root: LinearLayout? = null
    private var params: WindowManager.LayoutParams? = null
    private var statusTv: TextView? = null
    private var predTv: TextView? = null
    private var hitTv: TextView? = null
    private var amountTv: TextView? = null
    private var armSwitch: Switch? = null
    private var startBtn: Button? = null

    /** 面板内「武装」开关：打开后点开始才真正点第三方；关闭仅预览预测 */
    @Volatile
    var armed: Boolean = true

    @Synchronized
    fun refresh(prefs: UserPrefs) {
        if (!prefs.autoClickPanelEnabled || !Settings.canDrawOverlays(appContext)) {
            hide()
            return
        }
        ensureView(prefs)
        updateContent(prefs)
    }

    @Synchronized
    fun hide() {
        val v = root ?: return
        try {
            if (v.isAttachedToWindow) wm.removeViewImmediate(v)
        } catch (_: Exception) {
        }
        root = null
        params = null
        statusTv = null
        predTv = null
        hitTv = null
        amountTv = null
        armSwitch = null
        startBtn = null
    }

    private fun ensureView(prefs: UserPrefs) {
        val existing = root
        if (existing != null && existing.isAttachedToWindow) return
        root = null
        params = null

        val lp = WindowManager.LayoutParams(
            dp(220),
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                @Suppress("DEPRECATION")
                WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = prefs.autoClickPanelX
            y = prefs.autoClickPanelY
        }

        val box = LinearLayout(appContext).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(8))
            setBackgroundColor(AndroidColor.argb(235, 18, 40, 32))
            elevation = dp(10).toFloat()
        }

        val title = TextView(appContext).apply {
            text = "无障碍点击"
            setTextColor(AndroidColor.WHITE)
            textSize = 13f
            setTypeface(typeface, Typeface.BOLD)
        }
        statusTv = TextView(appContext).apply {
            setTextColor(AndroidColor.argb(220, 180, 220, 180))
            textSize = 11f
            setPadding(0, dp(2), 0, dp(2))
        }
        predTv = TextView(appContext).apply {
            setTextColor(AndroidColor.WHITE)
            textSize = 12f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(2), 0, dp(2))
            maxLines = 3
        }
        hitTv = TextView(appContext).apply {
            setTextColor(AndroidColor.argb(255, 255, 213, 79))
            textSize = 12f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(2), 0, dp(2))
        }
        amountTv = TextView(appContext).apply {
            setTextColor(AndroidColor.argb(255, 129, 212, 250))
            textSize = 12f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(2), 0, dp(4))
        }

        val switchRow = LinearLayout(appContext).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
        }
        val switchLabel = TextView(appContext).apply {
            text = "武装"
            setTextColor(AndroidColor.WHITE)
            textSize = 12f
            setPadding(0, 0, dp(8), 0)
        }
        armSwitch = Switch(appContext).apply {
            isChecked = armed
            setOnCheckedChangeListener { _, checked ->
                armed = checked
                updateContent(CaiFenXiApplication.instance.configStore.loadPrefs())
            }
        }
        switchRow.addView(switchLabel)
        switchRow.addView(armSwitch)

        startBtn = Button(appContext).apply {
            text = "开始"
            textSize = 14f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(AndroidColor.WHITE)
            setBackgroundColor(AndroidColor.rgb(46, 125, 50))
            setPadding(dp(8), dp(6), dp(8), dp(6))
            setOnClickListener { onStartClicked() }
        }

        // 标题区域可拖动；按钮/开关不抢拖动手势
        val dragListener = DragTouchListener(lp)
        title.setOnTouchListener(dragListener)
        statusTv?.setOnTouchListener(dragListener)
        predTv?.setOnTouchListener(dragListener)
        hitTv?.setOnTouchListener(dragListener)
        amountTv?.setOnTouchListener(dragListener)

        box.addView(title)
        box.addView(statusTv)
        box.addView(predTv)
        box.addView(hitTv)
        box.addView(amountTv)
        box.addView(switchRow)
        box.addView(startBtn)

        try {
            wm.addView(box, lp)
            root = box
            params = lp
        } catch (e: Exception) {
            RuntimeLog.warn("AutoBetPanel", "添加悬浮窗失败: ${e.message}")
            root = null
            params = null
        }
    }

    private fun updateContent(prefs: UserPrefs) {
        val a11y = AutoBetController.isAccessibilityEnabled(appContext)
        val running = AutoBetAccessibilityService.isRunning()
        val snap = FloatingOverlayStore.loadLastReady(appContext)
            ?: FloatingOverlayStore.load(appContext)
        val (dx, ds, combo) = if (snap != null) {
            AutoBetController.resolveClickTargets(prefs, snap)
        } else {
            Triple(null, null, null)
        }
        val modeLabel = AutoBetController.betModeLabel(prefs)

        val status = when {
            !a11y -> "请先开启系统无障碍"
            !running -> "无障碍未连接，请重开服务"
            !armed -> "已解除武装 · 不会点击"
            snap == null -> "暂无预测"
            snap.status == "CALCULATING" -> "预测同步中…"
            else -> "就绪 · $modeLabel · 可在投注页点开始"
        }
        statusTv?.text = status

        val dxShow = if (prefs.autoClickDx) (dx ?: "-") else "关"
        val dsShow = if (prefs.autoClickDs) (ds ?: "-") else "关"
        val issue = snap?.targetIssue ?: "-"
        val comboShow = combo ?: "-"
        val numsShow = snap?.let {
            AutoBetController.resolvePredNumbers(it).take(5).joinToString(" ").ifBlank { "-" }
        } ?: "-"
        val srcLabel = try {
            AutoBetController.describeClickSource(appContext, prefs, snap?.lotteryKey.orEmpty())
        } catch (_: Exception) { "" }
        predTv?.text = "[$modeLabel] 第${issue}期  $dxShow/$dsShow\n组合:$comboShow  号:$numsShow\n$srcLabel"

        val strat = AutoBetController.getAmountStrategyInfo(appContext, prefs)
        val hitColor = when (strat.lastHit) {
            true -> AndroidColor.rgb(129, 199, 132)   // 绿
            false -> AndroidColor.rgb(239, 83, 80)    // 红
            null -> AndroidColor.argb(255, 255, 213, 79)
        }
        hitTv?.setTextColor(hitColor)
        val predHint = if (strat.lastPredIssue.isNotBlank()) {
            "（点过第${strat.lastPredIssue}期 ${strat.lastPredDx.ifBlank { "-" }}/${strat.lastPredDs.ifBlank { "-" }}）"
        } else ""
        hitTv?.text = "上期：${strat.lastHitLabel}$predHint"

        if (prefs.autoInputEnabled) {
            val amt = strat.nextAmountText ?: "-"
            amountTv?.text = "本期数字：$amt（${strat.nextAmountKind}）"
            amountTv?.visibility = View.VISIBLE
        } else {
            amountTv?.text = "本期数字：未启用"
            amountTv?.visibility = View.VISIBLE
        }

        startBtn?.isEnabled = a11y && running && armed
        startBtn?.alpha = if (startBtn?.isEnabled == true) 1f else 0.5f
        armSwitch?.isChecked = armed
    }

    private fun onStartClicked() {
        if (!armed) {
            RuntimeLog.warn("AutoBetPanel", "未武装，忽略开始")
            statusTv?.text = "请先打开「武装」"
            return
        }
        if (!AutoBetController.isAccessibilityEnabled(appContext)) {
            statusTv?.text = "请先开启系统无障碍"
            AutoBetController.openAccessibilitySettings(appContext)
            return
        }
        if (!AutoBetAccessibilityService.isRunning()) {
            statusTv?.text = "无障碍未连接"
            return
        }

        statusTv?.text = "正在识别当前屏幕…"
        startBtn?.isEnabled = false
        RuntimeLog.info("AutoBetPanel", "用户点击开始，对当前页面执行识别点击")

        // 手动开始：清去重并立即点当前前台
        AutoBetController.tryNow(appContext)

        // 短暂后刷新状态
        root?.postDelayed({
            try {
                updateContent(CaiFenXiApplication.instance.configStore.loadPrefs())
            } catch (_: Exception) {
            }
        }, 800)
    }

    private fun dp(v: Int): Int =
        (v * appContext.resources.displayMetrics.density).toInt()

    private inner class DragTouchListener(
        private val lp: WindowManager.LayoutParams
    ) : View.OnTouchListener {
        private var downX = 0f
        private var downY = 0f
        private var startX = 0
        private var startY = 0

        override fun onTouch(v: View, event: MotionEvent): Boolean {
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX
                    downY = event.rawY
                    startX = lp.x
                    startY = lp.y
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = startX + (event.rawX - downX).toInt()
                    lp.y = startY + (event.rawY - downY).toInt()
                    try {
                        wm.updateViewLayout(root ?: v, lp)
                    } catch (_: Exception) {
                    }
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    try {
                        val prefs = CaiFenXiApplication.instance.configStore.loadPrefs()
                        CaiFenXiApplication.instance.configStore.savePrefs(
                            prefs.copy(
                                autoClickPanelX = lp.x,
                                autoClickPanelY = lp.y
                            )
                        )
                    } catch (_: Exception) {
                    }
                    return true
                }
            }
            return false
        }
    }
}
