package com.caifenxi.app.data.db.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.Index

/**
 * V2.0 执行任务持久化实体
 */
@Entity(
    tableName = "execution_tasks",
    indices = [
        Index(value = ["lotteryKey", "state"]),
        Index(value = ["state"]),
        Index(value = ["createdAt"])
    ]
)
data class ExecutionTaskEntity(
    @PrimaryKey
    val cmdId: String,

    val lotteryKey: String,
    val issue: String,
    val stage: Int,
    val leg: Int,

    /** CREATED/LOCKED/EXECUTING/VERIFYING/SUCCESS/FAILED/UNKNOWN/EXPIRED */
    val state: String,

    /** BetCommand JSON */
    val commandJson: String,

    /** ExecutionResult JSON（可空） */
    val resultJson: String?,

    /** 重试链：指向被重试的旧 cmdId */
    val retryOf: String?,

    val createdAt: Long,
    val lockedAt: Long?,
    val executedAt: Long?,
    val verifiedAt: Long?,
    val completedAt: Long?
)
