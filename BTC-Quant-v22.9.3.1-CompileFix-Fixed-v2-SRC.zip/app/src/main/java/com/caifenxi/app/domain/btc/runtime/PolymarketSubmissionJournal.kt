package com.caifenxi.app.domain.btc.runtime

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap

/**
 * Restart-safe journal for CLOB writes whose outcome became indeterminate.
 * An unknown write is never retried automatically: it must be reconciled or
 * explicitly resolved first. This prevents timeout/reconnect failures from
 * becoming duplicate orders after the app restarts.
 */
data class PolymarketSubmissionUncertainty(
    val intentKey: String,
    val marketId: String,
    val outcome: String,
    val requestedSize: Double,
    val requestedPrice: Double,
    val orderId: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = createdAt,
    val message: String = ""
)

class PolymarketSubmissionJournal(context: Context, private val maxEntries: Int = 200) {
    private val prefs = context.applicationContext.getSharedPreferences("btc_poly_submission_journal_v1", Context.MODE_PRIVATE)
    private val uncertain = ConcurrentHashMap<String, PolymarketSubmissionUncertainty>()

    init { load() }

    @Synchronized fun markUncertain(item: PolymarketSubmissionUncertainty) {
        uncertain[item.intentKey] = item.copy(updatedAt = System.currentTimeMillis())
        trim()
        persist()
    }

    fun get(intentKey: String): PolymarketSubmissionUncertainty? = uncertain[intentKey]

    fun pending(intentKey: String): Boolean = uncertain.containsKey(intentKey)

    fun recent(limit: Int = 30): List<PolymarketSubmissionUncertainty> =
        uncertain.values.sortedByDescending { it.updatedAt }.take(limit.coerceIn(1, maxEntries))

    @Synchronized fun resolve(intentKey: String) {
        uncertain.remove(intentKey)
        persist()
    }

    @Synchronized fun resolveAll() {
        uncertain.clear()
        persist()
    }

    private fun trim() {
        if (uncertain.size <= maxEntries) return
        uncertain.values.sortedBy { it.updatedAt }
            .take(uncertain.size - maxEntries)
            .forEach { uncertain.remove(it.intentKey) }
    }

    private fun load() = runCatching {
        val a = JSONArray(prefs.getString("items", "[]"))
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            val key = o.optString("intentKey")
            if (key.isBlank()) continue
            uncertain[key] = PolymarketSubmissionUncertainty(
                intentKey = key,
                marketId = o.optString("marketId"),
                outcome = o.optString("outcome"),
                requestedSize = o.optDouble("requestedSize", 0.0),
                requestedPrice = o.optDouble("requestedPrice", 0.0),
                orderId = o.optString("orderId").takeIf { it.isNotBlank() },
                createdAt = o.optLong("createdAt", System.currentTimeMillis()),
                updatedAt = o.optLong("updatedAt", System.currentTimeMillis()),
                message = o.optString("message")
            )
        }
        trim()
    }

    private fun persist() {
        val a = JSONArray()
        uncertain.values.sortedBy { it.updatedAt }.takeLast(maxEntries).forEach { x ->
            a.put(JSONObject().apply {
                put("intentKey", x.intentKey)
                put("marketId", x.marketId)
                put("outcome", x.outcome)
                put("requestedSize", x.requestedSize)
                put("requestedPrice", x.requestedPrice)
                put("orderId", x.orderId ?: "")
                put("createdAt", x.createdAt)
                put("updatedAt", x.updatedAt)
                put("message", x.message)
            })
        }
        prefs.edit().putString("items", a.toString()).apply()
    }
}
