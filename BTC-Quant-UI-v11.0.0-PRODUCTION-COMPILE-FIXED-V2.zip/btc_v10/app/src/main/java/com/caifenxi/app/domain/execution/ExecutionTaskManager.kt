package com.caifenxi.app.domain.execution

import com.caifenxi.app.util.RuntimeLog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

/**
 * 统一执行任务管理器：cmdId 隔离、防重复、明确 FAILED 才重试。
 */
class ExecutionTaskManager(
    private val maxRetry: Int = 3,
    private val retryDelayMs: Long = 5_000L
) {
    private val taskPool = ConcurrentHashMap<String, ExecutionTask>()
    private val keyToCmdIds = ConcurrentHashMap<String, MutableList<String>>()
    private val runningJobs = ConcurrentHashMap<String, Job>()
    private val lock = ExecutionLock()
    private val cmdSeq = AtomicInteger(0)
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    fun submitTask(
        task: ExecutionTask,
        executor: Executor?,
        onResult: (ExecutionResult) -> Unit = {}
    ): Boolean {
        if (task.cmdId.isBlank()) return false
        val exist = taskPool[task.cmdId]
        if (exist != null && !exist.isTerminal) {
            RuntimeLog.warn("Execution", "cmdId=${task.cmdId} 已在执行/未结束，防重复跳过")
            return false
        }
        if (exist != null && exist.status == ExecutionTask.TaskStatus.SUCCESS) {
            RuntimeLog.warn("Execution", "cmdId=${task.cmdId} 已成功，跳过")
            return false
        }
        if (task.expireAt > 0L && System.currentTimeMillis() > task.expireAt) {
            RuntimeLog.warn("Execution", "cmdId=${task.cmdId} 已过期，拒绝执行")
            return false
        }

        taskPool[task.cmdId] = task
        addToKeyIndex(task)
        RuntimeLog.info(
            "Execution",
            "提交任务 cmdId=${task.cmdId} 彩种=${task.lotteryKey} 期号=${task.issue} 次数=${task.retryCount}"
        )

        if (executor == null) {
            RuntimeLog.warn("Execution", "cmdId=${task.cmdId} 无执行器")
            return false
        }
        launchExecute(task, executor, onResult)
        return true
    }

    fun generateCmdId(lotteryKey: String, issue: String): String {
        val seq = cmdSeq.incrementAndGet()
        val ts = System.currentTimeMillis() % 100_000
        return "CMD-${lotteryKey.replace(":", "")}-$issue-$ts-$seq"
    }

    fun createRetry(
        origin: ExecutionTask,
        newCmdId: String,
        executor: Executor?,
        onResult: (ExecutionResult) -> Unit = {}
    ): Boolean {
        if (origin.retryCount + 1 > maxRetry) {
            RuntimeLog.warn("Execution", "cmdId=${origin.cmdId} 重试次数超限($maxRetry)，放弃")
            updateStatus(origin.cmdId, ExecutionTask.TaskStatus.FAILED, lastError = "重试次数超限")
            return false
        }
        val retry = origin.copy(
            cmdId = newCmdId,
            status = ExecutionTask.TaskStatus.CREATED,
            state = ExecutionTask.State.CREATED,
            retryCount = origin.retryCount + 1,
            retryOf = origin.cmdId,
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis(),
            lastError = null,
            result = null
        )
        return submitTask(retry, executor, onResult)
    }

    fun markPublished(cmdId: String) = updateStatus(cmdId, ExecutionTask.TaskStatus.PUBLISHED)
    fun markReceived(cmdId: String) = updateStatus(cmdId, ExecutionTask.TaskStatus.RECEIVED)
    fun markExecuting(cmdId: String) = updateStatus(cmdId, ExecutionTask.TaskStatus.EXECUTING)
    fun markVerifying(cmdId: String) = updateStatus(cmdId, ExecutionTask.TaskStatus.VERIFYING)

    /**
     * 结果回调：
     * SUCCESS → 结束；明确 FAILED → 可重试；UNKNOWN/TIMEOUT → 不盲重试。
     */
    fun onResult(
        result: ExecutionResult,
        executor: Executor?,
        onRetry: (ExecutionResult) -> Unit = {}
    ) {
        val task = taskPool[result.cmdId] ?: return
        runningJobs.remove(result.cmdId)?.let { if (it.isActive) it.cancel() }

        when {
            result.success -> {
                updateStatus(
                    result.cmdId,
                    ExecutionTask.TaskStatus.SUCCESS,
                    result = result
                )
                onRetry(result)
            }
            result.errorType == ExecutionResult.TIMEOUT ||
                result.errorType == ExecutionResult.UNKNOWN_RESULT ||
                result.code == ExecutionResult.ResultCode.UNKNOWN ||
                result.code == ExecutionResult.ResultCode.TIMEOUT -> {
                updateStatus(
                    result.cmdId,
                    ExecutionTask.TaskStatus.UNKNOWN,
                    lastError = result.message,
                    result = result
                )
                // 尝试向执行器二次确认
                executor?.queryState(result.cmdId)?.let { confirmed ->
                    if (confirmed.success) {
                        updateStatus(
                            result.cmdId,
                            ExecutionTask.TaskStatus.SUCCESS,
                            result = confirmed
                        )
                    }
                }
                onRetry(result)
            }
            else -> {
                // 明确失败
                if (task.retryCount < maxRetry && executor != null) {
                    updateStatus(
                        result.cmdId,
                        ExecutionTask.TaskStatus.FAILED,
                        lastError = result.message,
                        result = result
                    )
                    val newCmdId = generateCmdId(task.lotteryKey, task.issue)
                    scope.launch {
                        delay(retryDelayMs)
                        createRetry(task, newCmdId, executor, onRetry)
                    }
                } else {
                    updateStatus(
                        result.cmdId,
                        ExecutionTask.TaskStatus.FAILED,
                        lastError = result.message,
                        result = result
                    )
                    onRetry(result)
                }
            }
        }
    }

    fun handleTimeout(cmdId: String, executor: Executor?) {
        val task = taskPool[cmdId] ?: return
        if (task.isTerminal) return
        updateStatus(cmdId, ExecutionTask.TaskStatus.UNKNOWN, lastError = "执行超时")
        runningJobs.remove(cmdId)?.let { if (it.isActive) it.cancel() }
        executor?.queryState(cmdId)?.let { result ->
            if (result.success) {
                updateStatus(cmdId, ExecutionTask.TaskStatus.SUCCESS, result = result)
            }
        }
    }

    fun cancel(cmdId: String) {
        val task = taskPool[cmdId] ?: return
        if (task.isTerminal) return
        updateStatus(cmdId, ExecutionTask.TaskStatus.CANCELLED, lastError = "用户取消")
        runningJobs.remove(cmdId)?.let { if (it.isActive) it.cancel() }
    }

    fun getTask(cmdId: String): ExecutionTask? = taskPool[cmdId]

    fun getTasks(lotteryKey: String, issue: String): List<ExecutionTask> {
        val ids = keyToCmdIds["$lotteryKey|$issue"] ?: return emptyList()
        return ids.mapNotNull { taskPool[it] }.sortedBy { it.createdAt }
    }

    fun getLatestTask(lotteryKey: String, issue: String): ExecutionTask? =
        getTasks(lotteryKey, issue).lastOrNull()

    fun getAllTasks(): List<ExecutionTask> = taskPool.values.sortedBy { it.createdAt }

    fun cleanup(keepSuccess: Int = 50) {
        val successKept = AtomicInteger(keepSuccess)
        taskPool.entries.removeIf { (_, t) ->
            if (t.status == ExecutionTask.TaskStatus.SUCCESS) {
                if (successKept.getAndDecrement() > 0) return@removeIf false
            }
            t.isTerminal
        }
        keyToCmdIds.entries.removeIf { (_, v) ->
            v.removeIf { cmd -> taskPool[cmd] == null }
            v.isEmpty()
        }
    }

    fun shutdown() {
        scope.cancel()
        runningJobs.clear()
        RuntimeLog.info("Execution", "执行任务管理器已关闭")
    }

    private fun launchExecute(
        task: ExecutionTask,
        executor: Executor,
        onResult: (ExecutionResult) -> Unit
    ) {
        val job = scope.launch {
            lock.withLock(task.lotteryKey, task.issue, task.cmdId) {
                val current = taskPool[task.cmdId] ?: return@withLock
                if (current.isTerminal) return@withLock
                if (current.expireAt > 0L && System.currentTimeMillis() > current.expireAt) {
                    updateStatus(
                        task.cmdId,
                        ExecutionTask.TaskStatus.EXPIRED,
                        lastError = "任务过期"
                    )
                    return@withLock
                }
                updateStatus(task.cmdId, ExecutionTask.TaskStatus.PUBLISHED)
                executor.execute(task.toCommand()) { result ->
                    this@ExecutionTaskManager.onResult(result, executor, onResult)
                }
            }
        }
        runningJobs[task.cmdId] = job
    }

    private fun updateStatus(
        cmdId: String,
        status: ExecutionTask.TaskStatus,
        lastError: String? = null,
        result: ExecutionResult? = null
    ) {
        taskPool[cmdId]?.let { t ->
            taskPool[cmdId] = t.copyState(
                status = status,
                lastError = lastError,
                result = result
            )
            RuntimeLog.info("Execution", "任务状态更新 cmdId=$cmdId ${t.status} -> $status")
        }
    }

    private fun addToKeyIndex(task: ExecutionTask) {
        keyToCmdIds.computeIfAbsent("${task.lotteryKey}|${task.issue}") {
            java.util.concurrent.CopyOnWriteArrayList()
        }.add(task.cmdId)
    }
}

/** ExecutionTask → BetCommand */
fun ExecutionTask.toCommand(): BetCommand = BetCommand(
    cmdId = cmdId,
    lotteryKey = lotteryKey,
    issue = issue,
    stage = stage,
    leg = leg,
    bets = buildList {
        dx?.let { add(BetAction(BetAction.CAT_DX, it)) }
        ds?.let { add(BetAction(BetAction.CAT_DS, it)) }
        combo?.let { add(BetAction(BetAction.CAT_COMBO, it)) }
        predNumbers.forEach { add(BetAction(BetAction.CAT_NUMBER, it)) }
        textActions.forEach { add(BetAction(BetAction.CAT_TEXT, it)) }
    },
    amountText = amountText,
    source = source,
    createdAt = createdAt,
    expireAt = expireAt
)
