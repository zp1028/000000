package com.caifenxi.app.data.config

import android.content.Context
import com.caifenxi.app.domain.model.CategoryStats
import com.caifenxi.app.domain.model.StatRecord
import com.caifenxi.app.domain.model.StatsSummary
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

class StatStore(context: Context) {
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
    private val prefs = context.getSharedPreferences("caifenxi_stats", Context.MODE_PRIVATE)

    fun loadAll(lotteryKey: String? = null): List<StatRecord> {
        val raw = prefs.getString(KEY, null) ?: return emptyList()
        return try {
            val list = json.decodeFromString<List<StatRecord>>(raw)
            if (lotteryKey == null) list else list.filter { it.lotteryKey == lotteryKey }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun saveAll(list: List<StatRecord>) {
        val trimmed = list.takeLast(800)
        prefs.edit().putString(KEY, json.encodeToString(trimmed)).apply()
    }

    fun upsert(record: StatRecord) {
        val list = loadAll().toMutableList()
        val idx = list.indexOfFirst { it.id == record.id }
        if (idx >= 0) list[idx] = record else list.add(record)
        saveAll(list)
    }

    fun clear(lotteryKey: String? = null) {
        if (lotteryKey == null) {
            prefs.edit().remove(KEY).apply()
        } else {
            saveAll(loadAll().filter { it.lotteryKey != lotteryKey })
        }
    }

    fun summary(lotteryKey: String): StatsSummary {
        val all = loadAll(lotteryKey)
        val settled = all.filter { it.result == "对" || it.result == "错" }
        val hit = settled.count { it.result == "对" }
        val miss = settled.count { it.result == "错" }
        val pending = all.count { it.result == "待开" }

        val chrono = StreakCalc.chronoOf(settled, { it.issue }, { it.createdAt }, { it.id })
        val (recent, maxH, maxM) = StreakCalc.streaksOf(chrono.map { it.result })

        // 分组（分类/算法）各自的完整统计：连击 + 两期/三期窗口率
        fun group(key: (StatRecord) -> String): Map<String, CategoryStats> {
            return settled.groupBy(key).mapValues { (_, rows) ->
                val gChrono = StreakCalc.chronoOf(rows, { it.issue }, { it.createdAt }, { it.id })
                StreakCalc.buildCategoryStats(gChrono.map { it.result })
            }
        }

        val results = chrono.map { it.result }
        val (w2, w2Hit, w2Miss) = StreakCalc.windowRates(results, 2)
        val (w3, w3Hit, w3Miss) = StreakCalc.windowRates(results, 3)

        return StatsSummary(
            total = all.size,
            pending = pending,
            hit = hit,
            miss = miss,
            hitRate = if (hit + miss == 0) 0.0 else hit.toDouble() / (hit + miss),
            byCategory = group { it.category },
            byAlgo = group { it.algoId },
            recentStreak = recent,
            maxHitStreak = maxH,
            maxMissStreak = maxM,
            twoWindows = w2,
            twoHitWindows = w2Hit,
            twoMissWindows = w2Miss,
            twoHitRate = if (w2 > 0) w2Hit.toDouble() / w2 else 0.0,
            twoMissRate = if (w2 > 0) w2Miss.toDouble() / w2 else 0.0,
            threeWindows = w3,
            threeHitWindows = w3Hit,
            threeMissWindows = w3Miss,
            threeHitRate = if (w3 > 0) w3Hit.toDouble() / w3 else 0.0,
            threeMissRate = if (w3 > 0) w3Miss.toDouble() / w3 else 0.0
        )
    }

    companion object {
        private const val KEY = "stat_records_json"
    }
}
