package com.caifenxi.app.domain.btc.futures

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Manages a single open futures position in real-time:
 * - Tracks unrealized PnL from mark price updates
 * - Computes margin ratio and liquidation distance
 * - Implements trailing stop logic (updates highest/lowest since entry)
 * - Accumulates funding cost estimates
 * - Triggers emergency close signals when margin ratio is critical
 *
 * This is stateful — one instance per active position.
 * The ViewModel calls [updateMarkPrice] on each tick and checks [shouldEmergencyClose].
 */
class PositionManager(
    private val config: FuturesQuantConfig
) {
    private var position: FuturesPosition = FuturesPosition.empty()
    private var fundingCostAccrued: Double = 0.0
    private var lastFundingRate: Double = 0.0
    private var ticksSinceEntry: Int = 0

    /**
     * Register a newly opened position.
     */
    fun register(
        entryPrice: Double,
        quantity: Double,
        leverage: Int,
        margin: Double,
        liquidationPrice: Double,
        stopLoss: Double?,
        takeProfit: Double?,
        trailingStopPct: Double?,
        side: PositionSide,
        symbol: String,
        openTime: Long
    ) {
        position = FuturesPosition(
            symbol = symbol,
            side = side,
            entryPrice = entryPrice,
            quantity = quantity,
            leverage = leverage,
            margin = margin,
            liquidationPrice = liquidationPrice,
            markPrice = entryPrice,
            unrealizedPnl = 0.0,
            marginRatio = if (quantity > 0.0 && entryPrice > 0.0) margin / (quantity * entryPrice) else 0.0,
            stopLossPrice = stopLoss,
            takeProfitPrice = takeProfit,
            trailingStopPct = trailingStopPct,
            highestSinceEntry = if (side == PositionSide.LONG) entryPrice else null,
            lowestSinceEntry = if (side == PositionSide.SHORT) entryPrice else null,
            openTime = openTime
        )
        fundingCostAccrued = 0.0
        ticksSinceEntry = 0
    }

    /**
     * Update the position with a new mark price (called every tick).
     * Returns the updated position snapshot.
     */
    fun updateMarkPrice(markPrice: Double, fundingRate: Double = 0.0): FuturesPosition {
        if (position.isEmpty) return position

        ticksSinceEntry++
        val isLong = position.side == PositionSide.LONG
        val directionSign = if (isLong) 1.0 else -1.0

        // ── Unrealized PnL ──
        val pnl = (markPrice - position.entryPrice) * position.quantity * directionSign

        // ── Margin ratio ──
        val notional = position.quantity * markPrice
        val marginRatio = if (notional > 0.0) position.margin / notional else 0.0

        // ── Trailing stop: update peak/trough ──
        var newHighest = position.highestSinceEntry
        var newLowest = position.lowestSinceEntry
        if (isLong) {
            newHighest = max(newHighest ?: markPrice, markPrice)
        } else {
            newLowest = min(newLowest ?: markPrice, markPrice)
        }

        // ── Funding cost accumulation (simplified: per-tick estimate) ──
        if (fundingRate != 0.0 && lastFundingRate != fundingRate) {
            val fundingCost = abs(fundingRate) * notional
            val payer = if (fundingRate > 0) isLong else !isLong
            if (payer) fundingCostAccrued += fundingCost * 0.01 // crude per-tick fraction
            lastFundingRate = fundingRate
        }

        position = position.copy(
            markPrice = markPrice,
            unrealizedPnl = pnl,
            marginRatio = marginRatio,
            highestSinceEntry = newHighest,
            lowestSinceEntry = newLowest
        )
        return position
    }

    /**
     * Check if trailing stop has been triggered.
     * For LONG: price dropped from highest by trailingStopPct%
     * For SHORT: price rose from lowest by trailingStopPct%
     *
     * Returns true if trailing stop should trigger a close.
     */
    fun checkTrailingStop(markPrice: Double): Boolean {
        if (position.isEmpty || position.trailingStopPct == null) return false
        val pct = position.trailingStopPct!! / 100.0

        return if (position.side == PositionSide.LONG) {
            val peak = position.highestSinceEntry ?: position.entryPrice
            val drop = (peak - markPrice) / peak
            drop >= pct
        } else {
            val trough = position.lowestSinceEntry ?: position.entryPrice
            val rise = (markPrice - trough) / trough
            rise >= pct
        }
    }

    /**
     * Check if position is in emergency close territory.
     * Returns a reason string if emergency close needed, null otherwise.
     *
     * Triggers:
     * - Margin ratio ≤ 15% → critical margin
     * - Liquidation distance ≤ 5% → imminent liquidation
     * - Trailing stop triggered
     */
    fun shouldEmergencyClose(): String? {
        if (position.isEmpty) return null

        // ── Margin ratio check ──
        if (position.marginRatio in 0.0..0.15) {
            return "保证金比率危急 ${"%.1f%%".format(position.marginRatio * 100)} <= 15%"
        }

        // ── Liquidation distance check ──
        val liqDist = liquidationDistancePct()
        if (liqDist in 0.0..5.0) {
            return "强平距离危急 ${"%.1f%%".format(liqDist)} <= 5%"
        }

        // ── Trailing stop ──
        if (checkTrailingStop(position.markPrice)) {
            return "追踪止损触发 trail=${position.trailingStopPct}%"
        }

        return null
    }

    /**
     * Liquidation distance as percentage of mark price.
     * Returns how far (in %) the mark price is from the liquidation price.
     */
    fun liquidationDistancePct(): Double {
        if (position.isEmpty || position.liquidationPrice <= 0.0 || position.markPrice <= 0.0) {
            return Double.MAX_VALUE
        }
        return abs(position.markPrice - position.liquidationPrice) / position.markPrice * 100.0
    }

    /**
     * Clear the position (after close has been executed).
     */
    fun clear() {
        position = FuturesPosition.empty(position.symbol)
        fundingCostAccrued = 0.0
        ticksSinceEntry = 0
    }

    // ── Accessors ──

    fun current(): FuturesPosition = position
    fun isActive(): Boolean = !position.isEmpty
    fun fundingCost(): Double = fundingCostAccrued
    fun ticksOpen(): Int = ticksSinceEntry

    /**
     * Get a snapshot of all position metrics for UI display.
     */
    fun snapshot(): PositionSnapshot = PositionSnapshot(
        position = position,
        liquidationDistancePct = liquidationDistancePct(),
        fundingCostAccrued = fundingCostAccrued,
        ticksOpen = ticksSinceEntry,
        emergencyReason = shouldEmergencyClose()
    )
}

/**
 * Read-only snapshot of position state for UI/logging.
 */
data class PositionSnapshot(
    val position: FuturesPosition,
    val liquidationDistancePct: Double,
    val fundingCostAccrued: Double,
    val ticksOpen: Int,
    val emergencyReason: String?
) {
    val hasEmergency: Boolean get() = emergencyReason != null
    val pnlRoi: Double get() = position.roiPct
    val isProfitable: Boolean get() = position.unrealizedPnl > 0
}
