package com.caifenxi.app.domain.btc.broker

import com.caifenxi.app.domain.btc.TradingSignal
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.nio.charset.StandardCharsets
import java.util.Base64
import java.util.concurrent.TimeUnit
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

interface EventMarketBroker {
    suspend fun place(signal: TradingSignal.PredictionMarketSignal): BrokerResult
    suspend fun getOrderStatus(orderId: String): BrokerOrderStatus =
        BrokerOrderStatus(false, orderId, "UNKNOWN", 0.0, 0.0, "order status not supported")
    suspend fun cancel(orderId: String): BrokerResult =
        BrokerResult(false, orderId, "LIVE cancel requires authenticated CLOB L2 credentials")
}

data class BrokerResult(
    val ok: Boolean,
    val orderId: String? = null,
    val message: String = ""
)

data class BrokerOrderStatus(
    val ok: Boolean,
    val orderId: String,
    val status: String,
    val filledSize: Double = 0.0,
    val remainingSize: Double = 0.0,
    val message: String = ""
) {
    val terminal: Boolean
        get() = status.uppercase() in setOf("FILLED", "CANCELED", "CANCELLED", "REJECTED", "EXPIRED")
}

data class PolymarketBrokerCapabilities(
    val canReadPublicBook: Boolean = true,
    val canPlaceLive: Boolean,
    val canReadPrivateOrders: Boolean,
    val canCancelLive: Boolean,
    val reason: String
)

/**
 * Polymarket CLOB adapter.
 *
 * Public market data is unauthenticated and handled by PolymarketRepository.
 * Private order reads/cancel use current CLOB V2 L2 HMAC authentication.
 * Live order creation remains deliberately gated because it also needs an
 * L1/EIP-712 signed order; API credentials alone are not enough to create it.
 */
class PolymarketClobBroker(
    private val dryRun: Boolean = true,
    private val apiKey: String = "",
    private val apiSecret: String = "",
    private val passphrase: String = "",
    private val address: String = "",
    private val clobBase: String = "https://clob.polymarket.com",
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()
) : EventMarketBroker {

    private val hasL2 = apiKey.isNotBlank() && apiSecret.isNotBlank() && passphrase.isNotBlank() && address.isNotBlank()

    val capabilities: PolymarketBrokerCapabilities
        get() = PolymarketBrokerCapabilities(
            canPlaceLive = false,
            canReadPrivateOrders = !dryRun && hasL2,
            canCancelLive = !dryRun && hasL2,
            reason = when {
                dryRun -> "DRY_RUN"
                !hasL2 -> "缺少 POLY_ADDRESS/API_KEY/SECRET/PASSPHRASE"
                else -> "L2 可用；LIVE 下单仍需要 EIP-712 L1 order signature"
            }
        )

    override suspend fun place(signal: TradingSignal.PredictionMarketSignal): BrokerResult = withContext(Dispatchers.IO) {
        if (signal.action != "BUY") return@withContext BrokerResult(false, null, "action=${signal.action}")
        if (dryRun) {
            return@withContext BrokerResult(
                true,
                "POLY-DRY-${signal.marketId.take(8)}",
                "dry-run ${signal.outcome}@${signal.marketPrice} edge=${signal.edge}"
            )
        }
        // Never send an unsigned V1-shaped order to production. A real CLOB V2
        // order must contain the EIP-712 signed order object before POST /order.
        BrokerResult(false, null, "LIVE order blocked: EIP-712 L1 order signature/signer is not configured")
    }

    override suspend fun getOrderStatus(orderId: String): BrokerOrderStatus = withContext(Dispatchers.IO) {
        if (orderId.isBlank()) return@withContext BrokerOrderStatus(false, orderId, "UNKNOWN", message = "blank order id")
        if (dryRun) return@withContext BrokerOrderStatus(true, orderId, "OPEN", message = "dry-run")
        if (!hasL2) return@withContext BrokerOrderStatus(false, orderId, "UNKNOWN", message = capabilities.reason)
        val path = "/data/order/${encodePath(orderId)}"
        val req = signedRequest("GET", path, null).getOrElse {
            return@withContext BrokerOrderStatus(false, orderId, "UNKNOWN", message = it.message ?: "auth error")
        }
        try {
            client.newCall(req).execute().use { resp ->
                val text = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    return@withContext BrokerOrderStatus(false, orderId, "UNKNOWN", message = "CLOB ${resp.code}: ${text.take(240)}")
                }
                val o = runCatching { JSONObject(text) }.getOrNull()
                    ?: return@withContext BrokerOrderStatus(false, orderId, "UNKNOWN", message = "invalid JSON")
                val status = firstString(o, "status", "orderStatus", "state").uppercase().ifBlank { "UNKNOWN" }
                val filled = firstDouble(o, "size_matched", "sizeMatched", "filledSize", "filled")
                val original = firstDouble(o, "original_size", "originalSize", "size")
                val remaining = firstDouble(o, "remaining_size", "remainingSize", "remaining")
                    .let { if (it > 0.0) it else (original - filled).coerceAtLeast(0.0) }
                BrokerOrderStatus(true, orderId, status, filled, remaining, text.take(300))
            }
        } catch (e: Exception) {
            BrokerOrderStatus(false, orderId, "UNKNOWN", message = e.message ?: "poly order status error")
        }
    }

    override suspend fun cancel(orderId: String): BrokerResult = withContext(Dispatchers.IO) {
        if (orderId.isBlank()) return@withContext BrokerResult(false, orderId, "blank order id")
        if (dryRun) return@withContext BrokerResult(true, orderId, "dry-run cancel")
        if (!hasL2) return@withContext BrokerResult(false, orderId, capabilities.reason)

        val path = "/order"
        // CLOB V2 cancel payload is signed exactly as serialized here.
        val body = JSONObject().put("orderID", orderId).toString()
        val req = signedRequest("DELETE", path, body).getOrElse {
            return@withContext BrokerResult(false, orderId, it.message ?: "auth error")
        }
        try {
            client.newCall(req).execute().use { resp ->
                val text = resp.body?.string().orEmpty()
                if (resp.isSuccessful) {
                    BrokerResult(true, orderId, text.take(300).ifBlank { "cancel accepted" })
                } else {
                    BrokerResult(false, orderId, "CLOB ${resp.code}: ${text.take(240)}")
                }
            }
        } catch (e: Exception) {
            BrokerResult(false, orderId, e.message ?: "poly cancel error")
        }
    }

    private fun signedRequest(method: String, path: String, body: String?): Result<Request> = runCatching {
        val ts = (System.currentTimeMillis() / 1000L).toString()
        val signature = buildHmacSignature(apiSecret, ts, method, path, body)
        val builder = Request.Builder()
            .url(clobBase.trimEnd('/') + path)
            .header("POLY_ADDRESS", address)
            .header("POLY_SIGNATURE", signature)
            .header("POLY_TIMESTAMP", ts)
            .header("POLY_API_KEY", apiKey)
            .header("POLY_PASSPHRASE", passphrase)
            .header("Accept", "application/json")
        if (body != null) {
            builder.header("Content-Type", "application/json")
                .method(method, body.toRequestBody("application/json".toMediaType()))
        } else {
            builder.method(method, null)
        }
        builder.build()
    }

    companion object {
        fun buildHmacSignature(secret: String, timestamp: String, method: String, requestPath: String, body: String? = null): String {
            val decoded = Base64.getUrlDecoder().decode(secret)
            var message = timestamp + method + requestPath
            if (!body.isNullOrEmpty()) message += body.replace('\'', '"')
            val mac = Mac.getInstance("HmacSHA256")
            mac.init(SecretKeySpec(decoded, "HmacSHA256"))
            return Base64.getUrlEncoder().encodeToString(
                mac.doFinal(message.toByteArray(StandardCharsets.UTF_8))
            )
        }

        private fun firstString(o: JSONObject, vararg keys: String): String =
            keys.firstNotNullOfOrNull { key -> o.optString(key, "").takeIf { it.isNotBlank() } }.orEmpty()

        private fun firstDouble(o: JSONObject, vararg keys: String): Double =
            keys.firstNotNullOfOrNull { key ->
                when (val v = o.opt(key)) {
                    is Number -> v.toDouble()
                    is String -> v.toDoubleOrNull()
                    else -> null
                }
            } ?: 0.0

        private fun encodePath(value: String): String = java.net.URLEncoder.encode(value, "UTF-8").replace("+", "%20")
    }
}
