package com.caifenxi.app.domain.btc.backtest

import com.caifenxi.app.domain.btc.BtcCandle
import com.caifenxi.app.domain.btc.BtcDirection
import com.caifenxi.app.domain.btc.BtcPlanEngine
import com.caifenxi.app.domain.btc.DerivativesFeatureEngine
import com.caifenxi.app.domain.btc.DerivativesFeatures
import com.caifenxi.app.domain.btc.FundingPoint
import com.caifenxi.app.domain.btc.OpenInterestPoint
import com.caifenxi.app.domain.btc.plan.DynamicWeightEngine
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sqrt
import java.util.Calendar
import java.util.TimeZone

/**
 * Event-ordered bar backtester.
 *
 * Design follows the important ideas used by mature open-source engines:
 * signal is produced from information available at bar N, execution defaults
 * to the next bar open, costs are applied once, and protections can block new
 * entries without changing already-open positions.
 */
class BtcBacktestEngine(
    private val signalEngine: BtcPlanEngine = BtcPlanEngine()
) {
    fun run(
        planId: String,
        candles: List<BtcCandle>,
        config: BacktestConfig = BacktestConfig(),
        startIndex: Int = 0,
        endIndex: Int = candles.lastIndex,
        fundingHistory: List<FundingPoint> = emptyList(),
        oiHistory: List<OpenInterestPoint> = emptyList(),
        perf: Map<String, DynamicWeightEngine.PlanPerf> = emptyMap()
    ): BacktestResult {
        val from = max(80, startIndex)
        val to = endIndex.coerceAtMost(candles.lastIndex)
        if (from >= to) return emptyResult(planId, config.initialEquity)

        var equity = config.initialEquity
        var peak = equity
        var maxDd = 0.0
        val curve = mutableListOf(equity)
        val trades = mutableListOf<BacktestTrade>()
        var totalFunding = 0.0
        var totalFee = 0.0
        var cooldownUntil = -1
        var dailyStartEquity = equity
        var currentDay = utcDay(candles[from].openTime)
        var consecutiveLosses = 0
        var maxConsecutiveLossesSeen = 0
        var protectionBlocks = 0
        var exposureBars = 0

        var i = from
        while (i < to) {
            val day = utcDay(candles[i].openTime)
            if (day != currentDay) {
                currentDay = day
                dailyStartEquity = equity
                consecutiveLosses = 0
            }

            val window = candles.subList(0, i + 1)
            val last = window.last()
            val prev = window.getOrNull(window.lastIndex - 1)
            val deriv = if (fundingHistory.isNotEmpty() || oiHistory.isNotEmpty()) {
                DerivativesFeatureEngine.build(
                    barTime = last.openTime,
                    close = last.close,
                    prevClose = prev?.close,
                    fundingHistory = fundingHistory,
                    oiHistory = oiHistory
                )
            } else null
            val (signals, _) = signalEngine.evaluate(window, deriv, perf)
            val signal = signals.firstOrNull { it.planId == planId }
            if (signal == null || signal.direction == BtcDirection.FLAT ||
                (signal.direction == BtcDirection.UP && !config.allowLong) ||
                (signal.direction == BtcDirection.DOWN && !config.allowShort)) {
                curve += equity
                i++
                continue
            }

            val dailyLossPct = if (dailyStartEquity > 0.0) ((dailyStartEquity - equity) / dailyStartEquity) * 100.0 else 0.0
            val globalDd = if (peak > 0.0) ((peak - equity) / peak) * 100.0 else 0.0
            val blocked = i < cooldownUntil ||
                (config.maxDailyLossPct > 0.0 && dailyLossPct >= config.maxDailyLossPct) ||
                (config.maxDrawdownPct > 0.0 && globalDd >= config.maxDrawdownPct) ||
                (config.maxConsecutiveLosses > 0 && consecutiveLosses >= config.maxConsecutiveLosses)
            if (blocked) {
                protectionBlocks++
                curve += equity
                i++
                continue
            }

            val entryIndex = when (config.entryMode) {
                BacktestEntryMode.SAME_BAR_CLOSE -> (i + config.latencyBars).coerceAtMost(to)
                BacktestEntryMode.NEXT_BAR_OPEN -> (i + 1 + config.latencyBars).coerceAtMost(to)
            }
            if (entryIndex > to) break

            val entryRaw = when (config.entryMode) {
                BacktestEntryMode.SAME_BAR_CLOSE -> candles[entryIndex].close
                BacktestEntryMode.NEXT_BAR_OPEN -> candles[entryIndex].open
            }
            val slip = config.slippagePct.coerceAtLeast(0.0) / 100.0
            val spread = config.spreadPct.coerceAtLeast(0.0) / 100.0
            val entry = if (signal.direction == BtcDirection.UP) {
                entryRaw * (1.0 + slip + spread)
            } else {
                entryRaw * (1.0 - slip - spread)
            }
            if (entry <= 0.0) { i++; continue }

            val atrLike = candles.subList((i - 13).coerceAtLeast(0), i + 1)
                .map { it.high - it.low }.average().coerceAtLeast(entry * 0.001)
            val stopDistance = atrLike * 1.5
            val targetDistance = stopDistance * 2.0
            val sl = if (signal.direction == BtcDirection.UP) entry - stopDistance else entry + stopDistance
            val tp = if (signal.direction == BtcDirection.UP) entry + targetDistance else entry - targetDistance
            val riskCash = equity * (config.riskPerTradePct / 100.0)
            val riskPctPrice = (stopDistance / entry).coerceAtLeast(0.0001)
            val notional = minOf(riskCash / riskPctPrice, equity * (config.maxNotionalPct / 100.0)).coerceAtLeast(0.0) *
                config.partialFillRatio.coerceIn(0.1, 1.0)
            if (notional <= 0.0) { i++; continue }

            var exit = entry
            var reason = "TIME"
            var holding = 0
            var mfe = 0.0
            var mae = 0.0
            var done = false
            var exitIndex = entryIndex
            var j = entryIndex
            while (j <= to && holding < config.maxHoldingBars && !done) {
                val c = candles[j]
                val favorable = if (signal.direction == BtcDirection.UP) (c.high - entry) / entry else (entry - c.low) / entry
                val adverse = if (signal.direction == BtcDirection.UP) (entry - c.low) / entry else (c.high - entry) / entry
                mfe = max(mfe, favorable * 100.0)
                mae = max(mae, adverse * 100.0)
                val hitSl = if (signal.direction == BtcDirection.UP) c.low <= sl else c.high >= sl
                val hitTp = if (signal.direction == BtcDirection.UP) c.high >= tp else c.low <= tp
                // Conservative bar-only assumption: if both touch in one candle, SL wins.
                when {
                    hitSl -> { exit = sl; reason = "SL"; done = true }
                    hitTp -> { exit = tp; reason = "TP"; done = true }
                    j >= to || holding + 1 >= config.maxHoldingBars -> { exit = c.close; reason = "TIME"; done = true }
                }
                if (!done) holding++
                exitIndex = j
                j++
            }
            holding = (exitIndex - entryIndex + 1).coerceAtLeast(1)
            if (signal.direction == BtcDirection.UP) exit *= (1.0 - slip - spread) else exit *= (1.0 + slip + spread)

            val grossPct = if (signal.direction == BtcDirection.UP) (exit - entry) / entry * 100.0 else (entry - exit) / entry * 100.0
            val feeRate = if (config.useMakerFee) config.makerFeeRatePct else config.feeRatePct
            val feePct = feeRate * 2.0
            val fundingEvents = max(1, (holding + config.barsPerFunding - 1) / config.barsPerFunding)
            val fundingPoint = fundingAt(fundingHistory, candles.getOrNull(exitIndex)?.openTime ?: last.openTime)
            val fundingPct = if (fundingHistory.isEmpty()) 0.0 else if (signal.direction == BtcDirection.UP) fundingPoint * 100.0 * fundingEvents else -fundingPoint * 100.0 * fundingEvents
            val pnlPct = grossPct - feePct - fundingPct
            val pnlCash = notional * pnlPct / 100.0
            equity += pnlCash
            peak = max(peak, equity)
            maxDd = max(maxDd, if (peak > 0.0) (peak - equity) / peak * 100.0 else 0.0)
            exposureBars += holding
            totalFunding += fundingPct
            totalFee += feePct

            trades += BacktestTrade(
                barId = last.openTime, direction = signal.direction, entry = entry, exit = exit,
                stopLoss = sl, takeProfit = tp, pnlPct = pnlPct, pnlCash = pnlCash,
                holdingBars = holding, mfePct = mfe, maePct = mae, reason = reason,
                feePct = feePct, fundingPct = fundingPct, slippagePct = config.slippagePct * 2.0,
                notional = notional, entryBarId = candles[entryIndex].openTime, exitBarId = candles[exitIndex].openTime
            )
            if (pnlCash < 0.0) {
                consecutiveLosses++
                maxConsecutiveLossesSeen = max(maxConsecutiveLossesSeen, consecutiveLosses)
                cooldownUntil = exitIndex + config.cooldownBarsAfterLoss
            } else {
                consecutiveLosses = 0
            }
            curve += equity
            i = max(i + 1, exitIndex)
        }

        return summarize(planId, config.initialEquity, equity, peak, maxDd, curve, trades, totalFunding, totalFee, protectionBlocks, exposureBars, candles.size, maxConsecutiveLossesSeen)
    }

    fun walkForward(
        planId: String, candles: List<BtcCandle>, config: BacktestConfig = BacktestConfig(),
        fundingHistory: List<FundingPoint> = emptyList(), oiHistory: List<OpenInterestPoint> = emptyList()
    ): List<BacktestResult> {
        val results = mutableListOf<BacktestResult>()
        var trainEnd = max(80, config.walkForwardTrainBars)
        while (trainEnd + config.walkForwardTestBars < candles.size) {
            val testEnd = (trainEnd + config.walkForwardTestBars).coerceAtMost(candles.lastIndex)
            val trainRes = run(planId, candles, config, 0, trainEnd, fundingHistory, oiHistory)
            val perf = DynamicWeightEngine.fromBacktest(listOf(trainRes))
            results += run(planId, candles, config, trainEnd, testEnd, fundingHistory, oiHistory, perf).copy(inSample = false)
            trainEnd += config.walkForwardTestBars
        }
        return results
    }

    fun monteCarlo(result: BacktestResult, runs: Int = 1000, seed: Long = 42L): MonteCarloSummary {
        if (result.trades.isEmpty()) return MonteCarloSummary(0, 0.0, 0.0, 0.0, 0.0, 100.0)
        val rng = java.util.Random(seed)
        val returns = result.trades.map { it.pnlCash }.toDoubleArray()
        val finalReturns = DoubleArray(runs.coerceIn(100, 10_000)); val dds = DoubleArray(finalReturns.size)
        for (r in finalReturns.indices) {
            var eq = 1.0; var peakEq = 1.0; var dd = 0.0
            repeat(returns.size) {
                val x = returns[rng.nextInt(returns.size)] / 10_000.0
                eq *= (1.0 + x).coerceAtLeast(0.01); peakEq = max(peakEq, eq)
                dd = max(dd, if (peakEq > 0) (peakEq - eq) / peakEq * 100.0 else 0.0)
            }
            finalReturns[r] = (eq - 1.0) * 100.0; dds[r] = dd
        }
        finalReturns.sort(); dds.sort()
        fun percentile(a: DoubleArray, p: Double) = a[((a.size - 1) * p).toInt().coerceIn(0, a.lastIndex)]
        return MonteCarloSummary(finalReturns.size, percentile(finalReturns, .5), percentile(finalReturns, .05), percentile(finalReturns, .95), percentile(dds, .5), finalReturns.count { it < 0 } * 100.0 / finalReturns.size)
    }

    fun attribution(results: List<BacktestResult>): List<PlanAttribution> = results.groupBy { it.planId }.map { (id, list) ->
        PlanAttribution(id, list.sumOf { it.sampleSize }, list.sumOf { it.totalReturnPct }, list.sumOf { it.totalFundingPct }, list.sumOf { it.totalFeePct }, list.map { it.profitFactor }.averageOrZero(), list.maxOfOrNull { it.maxDrawdownPct } ?: 0.0)
    }

    private fun summarize(planId: String, initial: Double, equity: Double, peak: Double, maxDd: Double, curve: List<Double>, trades: List<BacktestTrade>, funding: Double, fee: Double, blocks: Int, exposureBars: Int, totalBars: Int, maxConsecLoss: Int): BacktestResult {
        val gp = trades.filter { it.pnlCash > 0 }.sumOf { it.pnlCash }
        val gl = -trades.filter { it.pnlCash < 0 }.sumOf { it.pnlCash }
        val pf = if (gl == 0.0) if (gp > 0) 99.0 else 0.0 else gp / gl
        val rets = trades.map { it.pnlCash / initial }
        val mean = rets.averageOrZero(); val variance = if (rets.size > 1) rets.map { (it - mean) * (it - mean) }.sum() / (rets.size - 1) else 0.0
        val std = sqrt(variance); val downside = rets.filter { it < 0.0 }; val downDev = if (downside.isEmpty()) 0.0 else sqrt(downside.map { it * it }.average())
        val sharpe = if (std > 1e-12) mean / std * sqrt(trades.size.toDouble()) else 0.0
        val sortino = if (downDev > 1e-12) mean / downDev * sqrt(trades.size.toDouble()) else 0.0
        val calmar = if (maxDd > 1e-12) ((equity / initial - 1.0) * 100.0) / maxDd else 0.0
        val wins = trades.filter { it.pnlCash > 0 }; val losses = trades.filter { it.pnlCash < 0 }
        val avgWin = wins.map { it.pnlCash }.averageOrZero(); val avgLoss = -losses.map { it.pnlCash }.averageOrZero()
        return BacktestResult(
            planId, trades, curve, (equity / initial - 1.0) * 100.0,
            if (trades.isEmpty()) 0.0 else wins.size.toDouble() / trades.size * 100.0,
            pf, maxDd, trades.map { it.pnlPct }.averageOrZero(), trades.map { it.holdingBars.toDouble() }.averageOrZero(),
            trades.map { it.mfePct }.averageOrZero(), trades.map { it.maePct }.averageOrZero(), trades.size,
            totalFundingPct = funding, totalFeePct = fee, sharpe = sharpe, sortino = sortino, calmar = calmar,
            expectancyCash = trades.map { it.pnlCash }.averageOrZero(), payoffRatio = if (avgLoss > 1e-12) avgWin / avgLoss else 0.0,
            protectionBlocks = blocks, exposureBarPct = if (totalBars > 0) exposureBars.toDouble() / totalBars * 100.0 else 0.0,
            maxConsecutiveLosses = maxConsecLoss
        )
    }

    private fun fundingAt(history: List<FundingPoint>, time: Long): Double = if (history.isEmpty()) 0.0 else history.lastOrNull { it.fundingTime <= time }?.fundingRate ?: history.last().fundingRate
    private fun utcDay(ms: Long): Int { val c = Calendar.getInstance(TimeZone.getTimeZone("UTC")); c.timeInMillis = ms; return c.get(Calendar.YEAR) * 1000 + c.get(Calendar.DAY_OF_YEAR) }
    private fun emptyResult(planId: String, equity: Double) = BacktestResult(planId, emptyList(), listOf(equity), 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0)
    private fun List<Double>.averageOrZero() = if (isEmpty()) 0.0 else average()
}
