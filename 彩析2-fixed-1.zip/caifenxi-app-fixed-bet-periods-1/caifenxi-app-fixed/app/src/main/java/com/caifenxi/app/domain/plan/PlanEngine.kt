package com.caifenxi.app.domain.plan

import com.caifenxi.app.domain.model.DrawRecord
import com.caifenxi.app.domain.model.ModelConsensus
import com.caifenxi.app.domain.model.PlanDefinition
import com.caifenxi.app.domain.model.PlanHitCriteria
import com.caifenxi.app.domain.model.PlanOutputFormat
import com.caifenxi.app.domain.model.PlanPredictionRecord
import com.caifenxi.app.domain.model.PlanRuntime
import com.caifenxi.app.domain.model.PlanStatus
import com.caifenxi.app.domain.model.UserPrefs
import kotlin.math.min
import kotlin.random.Random

/**
 * 计划引擎:
 * - 每期自动随机生成一批预测计划(基于模板池)
 * - 支持用户自定义计划(CustomPlan)参与预测与共识
 * - 结算后累计每个计划的对错成功率
 *
 * 线程安全修复:historyPreds/careerStats/runtimes 等共享可变状态原来会被
 * loadData、自动刷新、切换算法等多个协程并发读写(各自在 Default 线程池
 * 执行回测/预测/结算),并发时抛 ConcurrentModificationException 或损坏
 * HashMap,表现为「卡死→闪退」。所有公开方法加 @Synchronized 串行化。
 */
class PlanEngine {

    private val runtimes = mutableMapOf<String, PlanRuntime>()
    /** 模板 planId → 累计统计(跨期保留成功率) */
    private val careerStats = mutableMapOf<String, PlanRuntime>()
    private val historyPreds = mutableListOf<PlanPredictionRecord>()
    /** 当前期随机激活的计划定义 */
    private var activePlans: List<PlanDefinition> = emptyList()
    /** 用户自定义计划(持久化自 Room,参与预测/共识) */
    private var customPlans: List<PlanDefinition> = emptyList()
    private var lastGenIssue: String = ""
    /** 增量回测游标:记录已回测到的彩种与期号,避免每次刷新全量重算、战绩重复累加 */
    private var backtestLotteryKey: String = ""
    private var lastBacktestIssue: String = ""

    /** 注入用户自定义计划;在每期生成与回测时并入 activePlans */
    @Synchronized
    fun setCustomPlans(plans: List<PlanDefinition>) {
        customPlans = plans
        customPlans.forEach { def ->
            if (!careerStats.containsKey(def.planId)) {
                careerStats[def.planId] = PlanRuntime(planId = def.planId)
            }
        }
    }

    @Synchronized
    fun getCustomPlans(): List<PlanDefinition> = customPlans.toList()

    fun ensureCareerFromPool() {
        synchronized(this) {
            PlanPool.ALL.forEach { def ->
                if (!careerStats.containsKey(def.planId)) {
                    careerStats[def.planId] = PlanRuntime(planId = def.planId)
                }
            }
        }
    }

    /**
     * 每期随机生成预测计划。
     * @param count 生成本期计划数量,默认 12
     */
    @Synchronized
    fun generateRandomPlansForIssue(
        targetIssue: String,
        count: Int = 12,
        force: Boolean = false
    ): List<PlanDefinition> {
        if (!force && lastGenIssue == targetIssue && activePlans.isNotEmpty()) {
            return activePlans
        }
        ensureCareerFromPool()
        val seed = targetIssue.toLongOrNull() ?: targetIssue.hashCode().toLong()
        val rnd = Random(seed xor System.currentTimeMillis().and(0xFFFF))

        val templates = PlanPool.ALL
        val windows = listOf(5, 8, 10, 15, 20, 30, 50, 80, 100)
        val algos = listOf("FREQ", "EWMA", "MKV1", "MSF")
        // 共识核心类别：必须每期都有足够计划参与，否则共识为空
        // 位置类用于号码/位置共识与挂机数字下注
        val consensusCats = listOf("大小", "单双", "组合", "位置-冠军", "位置-亚军", "位置-第3")

        val generated = mutableListOf<PlanDefinition>()

        fun addRandomPlan(cat: String, index: Int) {
            val algo = algos.random(rnd)
            val win = windows.random(rnd)
            val id = "RND-${targetIssue.takeLast(6)}-$index-$algo$win-$cat"
            if (!careerStats.containsKey(id)) {
                careerStats[id] = PlanRuntime(planId = id)
            }
            val isPos = cat.startsWith("位置-")
            generated.add(
                PlanDefinition(
                    planId = id,
                    planName = when {
                        cat == "组合" -> "随机组合·$algo·${win}窗"
                        isPos -> "随机$cat·$algo·${win}窗"
                        else -> "随机$cat·$algo·${win}窗"
                    },
                    category = cat,
                    algorithm = algo,
                    window = win,
                    outputFormat = if (isPos) PlanOutputFormat.NUMBER_SCORES else PlanOutputFormat.DIRECTION,
                    hitCriteria = if (isPos) PlanHitCriteria.TOP20_HIT else PlanHitCriteria.DIRECTION_MATCH,
                    participateConsensus = true,
                    randomGenerated = true,
                    seedIssue = targetIssue
                )
            )
        }

        // 0) 强制覆盖共识类别：每类至少 2 条（模板优先，不足再补随机）
        var rndIndex = 0
        for (cat in consensusCats) {
            val fromPool = templates.filter { it.category == cat && it.participateConsensus }
                .shuffled(rnd)
                .take(2)
            if (fromPool.isNotEmpty()) {
                generated.addAll(fromPool.map { it.copy(randomGenerated = false, seedIssue = targetIssue) })
            }
            val needCat = 2 - fromPool.size
            repeat(needCat.coerceAtLeast(0)) {
                addRandomPlan(cat, rndIndex++)
            }
        }

        // 1) 从模板池再随机补足
        val already = generated.map { it.planId }.toHashSet()
        val moreTemplates = templates.shuffled(rnd)
            .filter { it.planId !in already }
            .take((count * 2 / 3).coerceAtLeast(4))
        generated.addAll(moreTemplates.map { it.copy(randomGenerated = false, seedIssue = targetIssue) })

        // 2) 再随机「新配方」计划
        val need = (count - generated.size).coerceAtLeast(0)
        repeat(need) { i ->
            addRandomPlan(consensusCats.random(rnd), rndIndex + i)
        }

        // 3) 并入用户自定义计划
        val merged = generated + customPlans
        activePlans = merged.distinctBy { it.planId }.take(count + customPlans.size.coerceAtLeast(0))
        // 兜底：若 take 后仍缺共识类别，强制追加
        for (cat in consensusCats) {
            if (activePlans.none { it.category == cat && it.participateConsensus }) {
                val algo = algos.random(rnd)
                val win = windows.random(rnd)
                val id = "RND-GUARD-${targetIssue.takeLast(6)}-$cat"
                if (!careerStats.containsKey(id)) careerStats[id] = PlanRuntime(planId = id)
                val isPos = cat.startsWith("位置-")
                activePlans = activePlans + PlanDefinition(
                    planId = id,
                    planName = "保底$cat·$algo·${win}窗",
                    category = cat,
                    algorithm = algo,
                    window = win,
                    outputFormat = if (isPos) PlanOutputFormat.NUMBER_SCORES else PlanOutputFormat.DIRECTION,
                    hitCriteria = if (isPos) PlanHitCriteria.TOP20_HIT else PlanHitCriteria.DIRECTION_MATCH,
                    participateConsensus = true,
                    randomGenerated = true,
                    seedIssue = targetIssue
                )
            }
        }
        lastGenIssue = targetIssue
        activePlans.forEach { def ->
            if (!careerStats.containsKey(def.planId)) {
                careerStats[def.planId] = PlanRuntime(planId = def.planId)
            }
            runtimes[def.planId] = careerStats[def.planId] ?: PlanRuntime(planId = def.planId)
        }
        return activePlans
    }

    @Synchronized
    fun getActivePlans(): List<PlanDefinition> = activePlans.toList()

    @Synchronized
    fun getRuntimes(): List<Pair<PlanDefinition, PlanRuntime>> {
        ensureCareerFromPool()
        val defs = if (activePlans.isNotEmpty()) activePlans else PlanPool.ALL + customPlans
        return defs.map { def ->
            val rt = careerStats[def.planId] ?: runtimes[def.planId] ?: PlanRuntime(def.planId)
            def to rt
        }.sortedWith(
            compareByDescending<Pair<PlanDefinition, PlanRuntime>> { it.second.sampleCount > 0 }
                .thenByDescending { it.second.hitRate }
                .thenByDescending { it.second.score }
        )
    }

    /** 某计划的预测历史(含当期与已结算) */
    @Synchronized
    fun getPredictionHistory(planId: String, limit: Int = 30): List<PlanPredictionRecord> =
        historyPreds.filter { it.planId == planId }.takeLast(limit).reversed()

    /** 当期(未结算)全部计划预测 */
    @Synchronized
    fun getCurrentPredictions(targetIssue: String): List<PlanPredictionRecord> =
        historyPreds.filter { it.targetIssue == targetIssue && !it.settled }
            .ifEmpty {
                emptyList()
            }

    @Synchronized
    fun getAllRecentPredictions(limit: Int = 80): List<PlanPredictionRecord> =
        historyPreds.takeLast(limit).reversed()

    @Synchronized
    fun getCareerLeaderboard(): List<Pair<PlanDefinition, PlanRuntime>> {
        ensureCareerFromPool()
        return (PlanPool.ALL + customPlans).map { it to (careerStats[it.planId] ?: PlanRuntime(it.planId)) }
            .sortedByDescending { it.second.hitRate }
    }

    /**
     * 回测。默认增量:只回测上次回测之后的新期号。
     *
     * 修复点:
     * 1) 原实现每次调用都对全量历史回测,且每次都把已结算记录重复 add 进
     *    historyPreds 并重复调用 updateRuntime —— 刷新几次后样本数成倍虚增、
     *    计划历史大量重复,且 CPU 空转严重。改为增量后每次只算新增期号。
     * 2) 原实现 predictAll 已写入一条未结算记录,backtest 再 add 一条结算副本,
     *    同一计划同一期留下两条记录(其中一条永远"待开"成为脏数据)。
     *    现在添加结算记录前先移除同 planId+期号 的旧记录。
     *
     * @param forceFull true 时从头全量重算(用于手动「重新滚动验证」)
     */
    @Synchronized
    fun backtest(history: List<DrawRecord>, prefs: UserPrefs, minWarm: Int = 30, forceFull: Boolean = false) {
        ensureCareerFromPool()
        if (history.size < minWarm + 5) return
        val lotteryKey = history.firstOrNull()?.lotteryKey ?: return
        if (forceFull || lotteryKey != backtestLotteryKey) {
            backtestLotteryKey = lotteryKey
            lastBacktestIssue = ""
        }
        // 增量起点:上次回测到的期号之后
        var start = minWarm
        if (lastBacktestIssue.isNotBlank()) {
            val idx = history.indexOfFirst { it.issue == lastBacktestIssue }
            start = if (idx >= 0) idx + 1 else minWarm
        }
        if (start >= history.size) return
        // 性能：单次最多回测最近 maxSteps 期，避免数千期历史一次算完卡死 UI
        val maxSteps = if (forceFull) 200 else 80
        val from = start.coerceAtLeast(minWarm)
        val effectiveStart = if (history.size - from > maxSteps) history.size - maxSteps else from
        for (i in effectiveStart until history.size) {
            val cutoff = history.subList(0, i)
            val actual = history[i]
            // 回测用较少计划数，降低每期开销
            generateRandomPlansForIssue(actual.issue, count = prefs.planPoolCount.coerceIn(4, 16), force = true)
            val preds = predictAll(cutoff, prefs, actual.issue, cutoff.last().issue)
            preds.forEach { rec ->
                val hit = evaluateHit(rec, actual)
                val settled = rec.copy(settled = true, hit = hit, settledAt = System.currentTimeMillis())
                historyPreds.removeAll { it.planId == rec.planId && it.targetIssue == rec.targetIssue }
                historyPreds.add(settled)
                updateRuntime(settled, prefs.backtestParams)
            }
        }
        lastBacktestIssue = history.last().issue
        if (historyPreds.size > 5000) {
            historyPreds.subList(0, historyPreds.size - 4000).clear()
        }
    }

    @Synchronized
    fun clearCareer() {
        careerStats.clear()
        runtimes.clear()
        historyPreds.clear()
        activePlans = emptyList()
        lastGenIssue = ""
        backtestLotteryKey = ""
        lastBacktestIssue = ""
    }

    @Synchronized
    fun predictForNext(
        history: List<DrawRecord>,
        prefs: UserPrefs,
        targetIssue: String,
        cutoffIssue: String
    ): List<PlanPredictionRecord> {
        generateRandomPlansForIssue(targetIssue, count = prefs.planPoolCount.coerceIn(4, 30), force = false)
        return predictAll(history, prefs, targetIssue, cutoffIssue)
    }

    @Synchronized
    fun consensus(
        lotteryKey: String,
        targetIssue: String,
        preds: List<PlanPredictionRecord>
    ): List<ModelConsensus> {
        // 计划定义索引：用于判断是否参与共识
        val defById = (activePlans + customPlans + PlanPool.ALL).associateBy { it.planId }
        val usable = preds.filter { rec ->
            val out = rec.output.trim()
            if (out.isEmpty()) return@filter false
            val def = defById[rec.planId]
            // 无定义时默认参与；有定义则尊重 participateConsensus
            def == null || def.participateConsensus
        }
        val byCat = usable.groupBy { it.category.ifBlank { planCategory(it.planId) } }
        return listOf("大小", "单双", "组合", "位置-冠军", "位置-亚军", "位置-第3", "号码").mapNotNull { cat ->
            val list = byCat[cat].orEmpty().filter { it.output.isNotBlank() }
            if (list.isEmpty()) return@mapNotNull null
            val weightSum = mutableMapOf<String, Double>()
            var totalW = 0.0
            var used = 0
            list.forEach { rec ->
                val rt = careerStats[rec.planId] ?: runtimes[rec.planId] ?: PlanRuntime(planId = rec.planId)
                // 淘汰计划降权但不完全剔除，避免全员淘汰时共识为空
                val statusFactor = when (rt.status) {
                    PlanStatus.ELIMINATED -> 0.15
                    PlanStatus.DEMOTED -> 0.4
                    PlanStatus.PROMOTED -> 1.2
                    else -> 1.0
                }
                // 成功率越高权重越大；样本不足时给中性权重
                val wr = if (rt.sampleCount >= 5) 0.5 + rt.hitRate * 0.5 else 0.5
                val w = (rt.weight * wr * statusFactor).coerceIn(0.05, 1.8)
                // 多候选（用 / 连接）拆成单方向分别加权，再汇总展示
                val parts = rec.output.split("/", "、", ",")
                    .map { it.trim() }.filter { it.isNotEmpty() }
                    .ifEmpty { listOf(rec.output.trim()) }
                val partW = w / parts.size
                parts.forEach { p ->
                    weightSum[p] = (weightSum[p] ?: 0.0) + partW
                }
                totalW += w
                used++
            }
            if (totalW <= 0 || weightSum.isEmpty()) return@mapNotNull null
            val leading = weightSum.maxByOrNull { it.value } ?: return@mapNotNull null
            val ratio = leading.value / totalW
            val second = weightSum.values.sortedDescending().getOrNull(1) ?: 0.0
            val disagreement = if (leading.value > 0) second / leading.value else 1.0
            // 领先方向：若第二名接近，展示双候选
            val leadingLabel = if (second > 0 && second / leading.value >= 0.85) {
                weightSum.entries.sortedByDescending { it.value }.take(2).joinToString("/") { it.key }
            } else {
                leading.key
            }
            ModelConsensus(
                lotteryKey = lotteryKey,
                targetIssue = targetIssue,
                category = cat,
                leadingDirection = leadingLabel,
                supportRatio = ratio,
                disagreement = disagreement,
                participatingPlans = used,
                detail = weightSum.mapValues { it.value / totalW }
            )
        }
    }

    private fun predictAll(
        history: List<DrawRecord>,
        prefs: UserPrefs,
        targetIssue: String,
        cutoffIssue: String
    ): List<PlanPredictionRecord> {
        val plans = if (activePlans.isNotEmpty()) activePlans else {
            generateRandomPlansForIssue(targetIssue, prefs.planPoolCount.coerceIn(4, 30), true)
            activePlans
        }
        return plans.mapNotNull { def ->
            val out = runPlan(def, history, prefs) ?: return@mapNotNull null
            val rt = careerStats[def.planId] ?: PlanRuntime(def.planId)
            val rec = PlanPredictionRecord(
                planId = def.planId,
                lotteryKey = history.lastOrNull()?.lotteryKey ?: "",
                targetIssue = targetIssue,
                cutoffIssue = cutoffIssue,
                output = out,
                scoreAtPredict = rt.score,
                weightAtPredict = rt.weight,
                planName = def.planName,
                category = def.category
            )
            // 记录当期预测(同 plan+issue 替换未结算)
            historyPreds.removeAll { it.planId == def.planId && it.targetIssue == targetIssue && !it.settled }
            historyPreds.add(rec)
            if (historyPreds.size > 5000) {
                historyPreds.subList(0, historyPreds.size - 4000).clear()
            }
            // 同步 lastPrediction
            careerStats[def.planId] = rt.copy(lastPrediction = out, lastTargetIssue = targetIssue)
            runtimes[def.planId] = careerStats.getValue(def.planId)
            rec
        }
    }

    private fun runPlan(def: PlanDefinition, history: List<DrawRecord>, prefs: UserPrefs): String? {
        val slice = history.takeLast(def.window.coerceAtLeast(5).coerceAtMost(history.size))
        if (slice.size < 3) return null
        // 组合/号码输出条数跟随设置中的预测数量
        val comboN = prefs.comboPredCount.coerceIn(1, 4)
        val numN = prefs.positionTopN.coerceIn(1, 10).coerceAtLeast(prefs.zuheTopN.coerceIn(1, 10))
        return when (def.category) {
            "大小" -> majority(slice.mapNotNull { it.dx }, def, prefs)
            "单双" -> majority(slice.mapNotNull { it.ds }, def, prefs)
            "组合" -> topMajors(slice.mapNotNull { it.combo }, def, prefs, comboN)
            "区间", "结构", "AI" -> topMajors(slice.mapNotNull { it.combo }, def, prefs, comboN)
            "号码" -> {
                val cnt = mutableMapOf<Int, Int>()
                slice.forEach { r -> r.numbers.forEach { n -> cnt[n] = (cnt[n] ?: 0) + 1 } }
                cnt.entries.sortedByDescending { it.value }.take(numN)
                    .joinToString("/") { it.key.toString() }
                    .ifBlank { null }
            }
            "位置-冠军", "位置-亚军", "位置-第3" -> {
                val position = when (def.category) {
                    "位置-冠军" -> 0
                    "位置-亚军" -> 1
                    else -> 2
                }
                val seq = slice.mapNotNull { it.numbers.getOrNull(position)?.toString() }
                topMajors(seq, def, prefs, numN)
            }
            else -> majority(slice.mapNotNull { it.dx }, def, prefs)
        }
    }

    /** 多候选输出,用 / 连接,数量由设置决定 */
    private fun topMajors(seq: List<String>, def: PlanDefinition, prefs: UserPrefs, topN: Int): String? {
        if (seq.isEmpty()) return null
        val scores = when (def.algorithm) {
            "EWMA" -> {
                val alpha = prefs.ewmaAlpha.toDouble()
                val labels = seq.distinct()
                val ewma = labels.associateWith { 0.0 }.toMutableMap()
                seq.forEach { x ->
                    labels.forEach { lab ->
                        val t = if (lab == x) 1.0 else 0.0
                        ewma[lab] = alpha * t + (1 - alpha) * (ewma[lab] ?: 0.0)
                    }
                }
                ewma
            }
            "MKV1" -> {
                if (seq.size < 2) return majority(seq, def, prefs)
                val last = seq.last()
                val next = mutableMapOf<String, Double>()
                for (i in 1 until seq.size) {
                    if (seq[i - 1] == last) next[seq[i]] = (next[seq[i]] ?: 0.0) + 1.0
                }
                if (next.isEmpty()) seq.groupingBy { it }.eachCount().mapValues { it.value.toDouble() }
                else next
            }
            else -> seq.groupingBy { it }.eachCount().mapValues { it.value.toDouble() }
        }
        return scores.entries.sortedByDescending { it.value }.take(topN.coerceAtLeast(1))
            .joinToString("/") { it.key }
            .ifBlank { null }
    }

    private fun majority(seq: List<String>, def: PlanDefinition, prefs: UserPrefs): String? {
        if (seq.isEmpty()) return null
        return when (def.algorithm) {
            "EWMA" -> {
                val alpha = prefs.ewmaAlpha.toDouble()
                val labels = seq.distinct()
                val ewma = labels.associateWith { 0.0 }.toMutableMap()
                seq.forEach { x ->
                    labels.forEach { lab ->
                        val t = if (lab == x) 1.0 else 0.0
                        ewma[lab] = alpha * t + (1 - alpha) * (ewma[lab] ?: 0.0)
                    }
                }
                ewma.maxByOrNull { it.value }?.key
            }
            "MKV1" -> {
                if (seq.size < 2) return seq.groupingBy { it }.eachCount().maxByOrNull { it.value }?.key
                val last = seq.last()
                val next = mutableMapOf<String, Int>()
                for (i in 1 until seq.size) {
                    if (seq[i - 1] == last) next[seq[i]] = (next[seq[i]] ?: 0) + 1
                }
                next.maxByOrNull { it.value }?.key
                    ?: seq.groupingBy { it }.eachCount().maxByOrNull { it.value }?.key
            }
            else -> seq.groupingBy { it }.eachCount().maxByOrNull { it.value }?.key
        }
    }

    /** 新开奖结算计划预测 */
    @Synchronized
    fun settlePendingWithDraw(draw: DrawRecord, params: com.caifenxi.app.domain.model.BacktestParams = com.caifenxi.app.domain.model.BacktestParams()) {
        val pending = historyPreds.filter { !it.settled && issueReached(it.targetIssue, draw.issue) }
        pending.forEach { rec ->
            val hit = evaluateHit(rec, draw)
            val settled = rec.copy(settled = true, hit = hit, settledAt = System.currentTimeMillis())
            val idx = historyPreds.indexOfFirst {
                it.planId == rec.planId && it.targetIssue == rec.targetIssue && !it.settled
            }
            if (idx >= 0) historyPreds[idx] = settled else historyPreds.add(settled)
            updateRuntime(settled, params)
        }
    }

    /** 仅精确匹配期号结算，避免用后期开奖结果错误结算前期预测 */
    private fun issueReached(predIssue: String, drawIssue: String): Boolean =
        predIssue == drawIssue || (
            predIssue.toLongOrNull() != null &&
            drawIssue.toLongOrNull() != null &&
            predIssue.toLongOrNull() == drawIssue.toLongOrNull()
        )


    private fun evaluateHit(rec: PlanPredictionRecord, actual: DrawRecord): Boolean {
        val cat = rec.category.ifBlank { planCategory(rec.planId) }
        val parts = rec.output.split("/", "、", ",").map { it.trim() }.filter { it.isNotEmpty() }
        return when (cat) {
            "大小" -> parts.any { it == actual.dx } || rec.output == actual.dx
            "单双" -> parts.any { it == actual.ds } || rec.output == actual.ds
            "组合", "区间", "结构", "AI" -> {
                val a = actual.combo ?: return false
                // 多候选:开奖落在候选中即对
                parts.any { it == a }
            }
            "号码" -> {
                // 多号码:任一预测号码出现在开奖号码中即对
                parts.any { it.toIntOrNull()?.let { n -> n in actual.numbers } == true }
            }
            "位置-冠军", "位置-亚军", "位置-第3" -> {
                val position = when (cat) {
                    "位置-冠军" -> 0
                    "位置-亚军" -> 1
                    else -> 2
                }
                val actualNumber = actual.numberAt(position)
                parts.any { it.toIntOrNull() == actualNumber }
            }
            else -> parts.any { it == actual.dx || it == actual.ds || it == actual.combo }
        }
    }

    private fun updateRuntime(rec: PlanPredictionRecord, params: com.caifenxi.app.domain.model.BacktestParams = com.caifenxi.app.domain.model.BacktestParams()) {
        val prev = careerStats[rec.planId] ?: PlanRuntime(planId = rec.planId)
        val hit = rec.hit == true
        val sample = prev.sampleCount + 1
        val hits = prev.hitCount + if (hit) 1 else 0
        val miss = if (hit) 0 else prev.consecutiveMiss + 1
        val hitRate = hits.toDouble() / sample

        var score = hitRate * params.recentHit * 2.5
        score += min(sample / 100.0, 1.0) * params.sample
        if (miss >= params.streakPenaltyStart) score -= params.streak * (miss - params.streakPenaltyStart + 1) * 0.15
        score = score.coerceIn(0.0, 100.0)

        var weight = 0.5 + (hitRate - 0.5) * 0.6
        weight = weight.coerceIn(0.35, 1.15)

        val status = when {
            miss >= 12 && sample >= 30 -> PlanStatus.DEMOTED
            sample >= 100 && hitRate < 0.42 -> PlanStatus.ELIMINATED
            score >= params.promoteThreshold && sample >= 50 -> PlanStatus.PROMOTED
            else -> PlanStatus.ACTIVE
        }

        val updated = prev.copy(
            weight = weight,
            score = score,
            sampleCount = sample,
            hitCount = hits,
            consecutiveMiss = miss,
            status = status,
            lastPrediction = rec.output,
            lastTargetIssue = rec.targetIssue
        )
        careerStats[rec.planId] = updated
        runtimes[rec.planId] = updated
    }

    private fun planCategory(planId: String): String =
        activePlans.find { it.planId == planId }?.category
            ?: PlanPool.ALL.find { it.planId == planId }?.category
            ?: customPlans.find { it.planId == planId }?.category
            ?: ""
}
