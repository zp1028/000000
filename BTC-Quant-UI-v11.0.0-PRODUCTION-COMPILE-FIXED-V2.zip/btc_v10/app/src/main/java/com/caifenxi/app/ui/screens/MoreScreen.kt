package com.caifenxi.app.ui.screens

import android.content.pm.PackageManager
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.navigation.NavHostController
import com.caifenxi.app.ui.MainViewModel
import com.caifenxi.app.ui.components.GlobalCard
import com.caifenxi.app.ui.components.SectionTitle
import com.caifenxi.app.ui.theme.CaiTokens

@Composable
fun MoreScreen(vm: MainViewModel, navController: NavHostController) {
    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = CaiTokens.ScreenHPadding, vertical = CaiTokens.S16)
    ) {
        Text("更多", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(CaiTokens.S16))
        SectionTitle("数据与工具")
        GlobalCard {
            listOf(
                "stats" to "历史 / 统计",
                "lab" to "实验室",
                "web_bet" to "内置网页执行",
                "executor_control" to "执行器控制",
                "executor_logs" to "执行日志",
                "ai_settings" to "🧠 AI 大模型设置",
                "ai_agent_lab" to "🤖 AI Agent 大脑实验台",
                "settings" to "设置 / 悬浮窗"
            ).forEach { (route, title) ->
                TextButton(
                    onClick = { navController.navigate(route) },
                    modifier = Modifier.fillMaxWidth()
                ) { Text(title) }
            }
        }
        Spacer(Modifier.height(CaiTokens.S12))
        GlobalCard {
            val ctx = LocalContext.current
            val version = remember {
                try {
                    val pm = ctx.packageManager
                    val info = pm.getPackageInfo(ctx.packageName, 0)
                    val vName = info.versionName ?: ""
                    val vCode = if (android.os.Build.VERSION.SDK_INT >= 28) {
                        info.longVersionCode
                    } else {
                        @Suppress("DEPRECATION")
                        info.versionCode.toLong()
                    }
                    "v$vName ($vCode)"
                } catch (_: PackageManager.NameNotFoundException) {
                    ""
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("彩析", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(version, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.height(CaiTokens.S8))
            Text(
                "走势统计、计划回测、预测共识与跟投记录工具。仅供开奖数据统计与研究，非中奖保证，请理性对待。",
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}
