package com.caifenxi.app.service

import android.content.Context
import android.graphics.Color as AndroidColor
import android.graphics.PixelFormat
import android.os.Build
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import com.caifenxi.app.CaiFenXiApplication
import com.caifenxi.app.domain.model.UserPrefs

/**
 * 悬浮窗只读显示器。
 * - 只在主线程刷新 View
 * - 新开奖计算期间保留上一份 READY 结果，不把旧结果套到新期号
 * - READY 快照原子提交后立即切换
 * - App 页面退出不影响它，只要后台前台服务仍在运行
 */
class FloatingOverlayController(private val context: Context) {
    private val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var root: LinearLayout? = null
    private var params: WindowManager.LayoutParams? = null

    @Synchronized
    fun refresh(prefs: UserPrefs) {
        if (!prefs.floatingEnabled || !android.provider.Settings.canDrawOverlays(context)) {
            hide()
            return
        }
        val current = FloatingOverlayStore.load(context)
        val snap = if (current?.status == "CALCULATING") {
            FloatingOverlayStore.loadLastReady(context) ?: current
        } else current
        if (snap == null) return
        ensureView(prefs)
        render(prefs, snap, current)
    }

    @Synchronized
    fun hide() {
        root?.let {
            try { if (it.isAttachedToWindow) wm.removeViewImmediate(it) } catch (_: Exception) {}
        }
        root = null
        params = null
    }

    private fun ensureView(prefs: UserPrefs) {
        val existing = root
        if (existing != null && existing.isAttachedToWindow) return
        if (existing != null) {
            try { wm.removeViewImmediate(existing) } catch (_: Exception) {}
        }
        root = null
        params = null

        val lp = WindowManager.LayoutParams(
            dp(225), WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = prefs.floatingX
            y = prefs.floatingY
        }
        val box = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(9), dp(12), dp(9))
            setBackgroundColor(AndroidColor.argb(225, 25, 25, 25))
            elevation = dp(8).toFloat()
        }
        box.setOnTouchListener(DragTouchListener(lp))
        try {
            wm.addView(box, lp)
            root = box
            params = lp
        } catch (_: Exception) {
            root = null
            params = null
        }
    }

    private fun render(prefs: UserPrefs, snap: FloatingSnapshot, current: FloatingSnapshot?) {
        val box = root ?: return
        if (!box.isAttachedToWindow) return
        box.alpha = prefs.floatingOpacity
        box.removeAllViews()

        val selectedDxId = prefs.floatingDxPlanId.ifBlank { prefs.floatingPlanId }
        val selectedDsId = prefs.floatingDsPlanId.ifBlank { prefs.floatingPlanId }
        val dxPlan = snap.plans.firstOrNull { it.planId == selectedDxId && !it.dx.isNullOrBlank() }
        val dsPlan = snap.plans.firstOrNull { it.planId == selectedDsId && !it.ds.isNullOrBlank() }

        val consensusReady = !snap.consensusDx.isNullOrBlank() && !snap.consensusDs.isNullOrBlank()
        val algoReady = !snap.algoDx.isNullOrBlank() && !snap.algoDs.isNullOrBlank()
        val planReady = dxPlan != null && dsPlan != null

        val dx: String?
        val ds: String?
        val sourceName: String
        val sourceDetail: String?
        when {
            prefs.floatingSource == "plan" && planReady -> {
                dx = dxPlan?.dx
                ds = dsPlan?.ds
                sourceName = "指定计划"
                sourceDetail = "大小:${dxPlan?.planName} / 单双:${dsPlan?.planName}"
            }
            prefs.floatingSource == "consensus" && consensusReady -> {
                dx = snap.consensusDx
                ds = snap.consensusDs
                sourceName = "共识"
                sourceDetail = null
            }
            prefs.floatingSource == "algo" && algoReady -> {
                dx = snap.algoDx
                ds = snap.algoDs
                sourceName = "当前算法"
                sourceDetail = null
            }
            consensusReady -> {
                dx = snap.consensusDx
                ds = snap.consensusDs
                sourceName = if (prefs.floatingSource == "plan") "共识（指定计划暂不可用）" else "共识"
                sourceDetail = null
            }
            algoReady -> {
                dx = snap.algoDx
                ds = snap.algoDs
                sourceName = if (prefs.floatingSource == "plan") "当前算法（指定计划暂不可用）" else "当前算法"
                sourceDetail = null
            }
            else -> {
                dx = null
                ds = null
                sourceName = when (prefs.floatingSource) {
                    "plan" -> "指定计划"
                    "algo" -> "当前算法"
                    else -> "共识"
                }
                sourceDetail = null
            }
        }

        add(box, snap.lotteryName, true, prefs)
        val currentIsCalculating = current?.status == "CALCULATING"
        val ready = !dx.isNullOrBlank() && !ds.isNullOrBlank() &&
            snap.latestIssue != "-" && snap.targetIssue != "-" &&
            snap.latestIssue != snap.targetIssue && isNextIssue(snap.latestIssue, snap.targetIssue)

        if (ready) {
            add(box, "第${snap.targetIssue}期：$dx", true, prefs)
            add(box, "第${snap.targetIssue}期：$ds", true, prefs)
        } else {
            add(box, "第${snap.targetIssue}期：预测更新中...", true, prefs)
            add(box, "第${snap.targetIssue}期：预测更新中...", true, prefs)
        }

        add(box, "来源：$sourceName", false, prefs)
        sourceDetail?.let { add(box, it, false, prefs, smaller = true) }

        val age = if (snap.updatedAt > 0) System.currentTimeMillis() - snap.updatedAt else Long.MAX_VALUE
        val statusText = when {
            currentIsCalculating && ready -> "同步中 · 等待第${current?.targetIssue ?: "-"}期"
            age > 180_000L -> "数据可能过期"
            ready -> "待开 · 同步正常"
            else -> "预测更新中"
        }
        add(box, "状态：$statusText", false, prefs)
    }

    private fun isNextIssue(latest: String, target: String): Boolean {
        val a = latest.toLongOrNull()
        val b = target.toLongOrNull()
        return if (a != null && b != null) b == a + 1L else true
    }

    private fun add(box: LinearLayout, text: String, bold: Boolean, prefs: UserPrefs, smaller: Boolean = false) {
        box.addView(TextView(context).apply {
            this.text = text
            setTextColor(AndroidColor.WHITE)
            textSize = if (smaller) (prefs.floatingTextSize - 1f).coerceAtLeast(10f) else prefs.floatingTextSize
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, dp(if (smaller) 1 else 2), 0, dp(1))
        })
    }

    private fun dp(v: Int) = (v * context.resources.displayMetrics.density).toInt()

    private inner class DragTouchListener(private val lp: WindowManager.LayoutParams) : View.OnTouchListener {
        private var downX = 0f
        private var downY = 0f
        private var startX = 0
        private var startY = 0
        private var lastUpAt = 0L

        override fun onTouch(v: View, event: MotionEvent): Boolean {
            val prefs = CaiFenXiApplication.instance.configStore.loadPrefs()
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX; downY = event.rawY
                    startX = lp.x; startY = lp.y
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!prefs.floatingDraggable) return true
                    lp.x = startX + (event.rawX - downX).toInt()
                    lp.y = startY + (event.rawY - downY).toInt()
                    try { wm.updateViewLayout(v, lp) } catch (_: Exception) {}
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    val now = System.currentTimeMillis()
                    if (now - lastUpAt < 320L) {
                        // 双击只关闭当前 View，不修改“启用悬浮窗”配置；后台服务下次同步会自动恢复。
                        try { wm.removeViewImmediate(v) } catch (_: Exception) {}
                        root = null
                        params = null
                        lastUpAt = 0L
                        return true
                    }
                    lastUpAt = now
                    if (prefs.floatingDraggable) {
                        CaiFenXiApplication.instance.configStore.savePrefs(
                            prefs.copy(floatingX = lp.x, floatingY = lp.y)
                        )
                    }
                    return true
                }
            }
            return false
        }
    }
}
