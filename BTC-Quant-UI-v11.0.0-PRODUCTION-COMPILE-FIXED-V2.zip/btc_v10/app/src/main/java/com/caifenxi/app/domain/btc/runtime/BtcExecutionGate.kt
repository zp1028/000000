package com.caifenxi.app.domain.btc.runtime

import java.util.concurrent.ConcurrentHashMap

/**
 * In-process idempotency gate. A completed bar may have only one execution claim.
 * Entries are timestamped and periodically pruned so a long-running runtime does not leak memory.
 */
class BtcExecutionGate(private val ttlMillis: Long = 48L * 60L * 60L * 1000L) {
    private val seen = ConcurrentHashMap<String, Long>()

    fun key(planId: String, symbol: String, timeframe: String, barId: Long): String =
        key(symbol, timeframe, barId)

    fun key(symbol: String, timeframe: String, barId: Long): String =
        "$symbol|$timeframe|$barId"

    fun claim(planId: String, symbol: String, timeframe: String, barId: Long): Boolean =
        claimKey(key(symbol, timeframe, barId))

    fun claimBar(symbol: String, timeframe: String, barId: Long): Boolean =
        claimKey(key(symbol, timeframe, barId))

    fun release(key: String) { seen.remove(key) }

    fun size(): Int = seen.size

    private fun claimKey(key: String): Boolean {
        prune()
        return seen.putIfAbsent(key, System.currentTimeMillis()) == null
    }

    private fun prune() {
        val cutoff = System.currentTimeMillis() - ttlMillis
        seen.entries.removeIf { it.value < cutoff }
    }
}
