package com.caifenxi.app.domain.plan

import com.caifenxi.app.domain.engine.PredictEngine
import com.caifenxi.app.domain.model.AlgoMode
import com.caifenxi.app.domain.model.UserPrefs

import com.caifenxi.app.domain.model.DrawRecord
import com.caifenxi.app.domain.model.PlanDefinition
import com.caifenxi.app.data.config.StreakCalc
import kotlin.math.abs
import kotlin.math.pow
import kotlin.math.sqrt

/** NovaPlan 分析层：严格使用 cutoff 之前的数据，避免回测信息泄漏。 */
object NovaPlanAnalytics {
    data class Result(
        val planId: String,
        val output: String,
        val score: Double,
        val sampleCount: Int,
        val baseline: Double,
        val edge: Double,
        val stability: Double
    )

    data class StageReport(
        val stage: Int,
        val periods: Int,
        val hits: Int,
        val misses: Int,
        val hitRate: Double,
        val randomBaseline: Double,
        val edge: Double,
        val maxHitStreak: Int,
        val maxMissStreak: Int,
        val stability: Double
    )

    data class ChartPoint(
        val issue: String,
        val prediction: String,
        val hit: Boolean,
        val stake: Double,
        val periodProfit: Double,
        val cumulativeProfit: Double,
        val peakProfit: Double,
        val troughProfit: Double,
        val drawdown: Double,
        val hitRate: Double
    )

    data class ChartReport(
        val plan: PlanDefinition,
        val periods: Int,
        val stake: Double,
        val points: List<ChartPoint>,
        val hits: Int,
        val misses: Int,
        val totalStake: Double,
        val netProfit: Double,
        val hitRate: Double,
        /** 回测过程中累计对错率的最高值（0~1） */
        val maxHitRate: Double = 0.0,
        /** 回测过程中累计对错率的最低值（0~1） */
        val minHitRate: Double = 0.0,
        val maxHitStreak: Int,
        val maxMissStreak: Int,
        val maxDrawdown: Double,
        val maxPeak: Double,
        val minTrough: Double,
        val currentTrend: String,
        val positionPercent: Double,
        val distanceFromPeak: Double,
        val reboundFromTrough: Double
    )

    data class BacktestReport(
        val planId: String,
        val periods: Int,
        val hits: Int,
        val misses: Int,
        val hitRate: Double,
        val randomBaseline: Double,
        val edge: Double,
        val maxHitStreak: Int,
        val maxMissStreak: Int,
        val stability: Double,
        val stages: Map<Int, StageReport> = emptyMap(),
        /** 与计划引擎/历史页面一致：连续两期/三期滚动窗口统计。 */
        val twoWindows: Int = 0,
        val twoHitWindows: Int = 0,
        val twoMissWindows: Int = 0,
        val twoHitRate: Double = 0.0,
        val twoMissRate: Double = 0.0,
        val threeWindows: Int = 0,
        val threeHitWindows: Int = 0,
        val threeMissWindows: Int = 0,
        val threeHitRate: Double = 0.0,
        val threeMissRate: Double = 0.0
    )

    fun predict(plan: PlanDefinition, history: List<DrawRecord>, outputCount: Int? = null): Result? {
        val data = history.takeLast(plan.window.coerceAtLeast(5))
        if (data.size < 5) return null
        val output = when (plan.playType) {
            "大小" -> directionOutput(plan, data, data.mapNotNull { it.dx }, "大", "小")
            "单双" -> directionOutput(plan, data, data.mapNotNull { it.ds }, "单", "双")
            "组合" -> comboOutput(plan, data, outputCount ?: 3)
            "数字" -> numberOutput(plan, data, null, outputCount ?: 3)
            "位置" -> numberOutput(plan, data, plan.positionIndex.coerceIn(0, 9), outputCount ?: 3)
            else -> data.lastOrNull()?.dx.orEmpty()
        }.ifBlank { return null }
        val baseline = plan.baselineValue
        val sampleFactor = (data.size.coerceAtMost(200) / 200.0)
        val confidence = algorithmConfidence(plan.algorithm, data, plan.playType)
        val score = (45.0 + sampleFactor * 15.0 + confidence * 20.0).coerceIn(40.0, 85.0)
        return Result(plan.planId, output, score, data.size, baseline, confidence - 0.5, confidence.coerceIn(0.2, 1.0))
    }

    private fun algorithmConfidence(algo: String, data: List<DrawRecord>, playType: String): Double {
        val seq = when (playType) {
            "大小" -> data.mapNotNull { it.dx }
            "单双" -> data.mapNotNull { it.ds }
            "组合" -> data.mapNotNull { it.combo }
            else -> emptyList()
        }
        if (seq.size < 4) return 0.45
        val last = seq.last()
        val share = seq.count { it == last }.toDouble() / seq.size
        return when (algo) {
            "STATE" -> share.coerceIn(0.35, 0.85)
            "RHYTHM" -> if (seq.takeLast(3).distinct().size == 1) 0.72 else 0.48
            "ANOMALY" -> if (share > 0.62 || share < 0.38) 0.70 else 0.42
            "SIMILAR" -> 0.55
            "NETWORK" -> 0.58
            "STRUCT" -> 0.52
            "CANDIDATE" -> 0.50
            "OPTIMIZE" -> 0.54
            "EXPERIENCE" -> 0.60
            "PATTERN" -> 0.58
            "FUSION" -> 0.62
            else -> 0.50
        }
    }

    /**
     * walk-forward 回测：每个 target 只使用 target 之前的数据。
     * 执行周期 cyclePeriods=N：一次预测锁定后续 N 期，N 期内任意一期命中即计为中（常见多期计划口径）。
     * 步进也为 N，避免与一期回测完全同一组样本导致胜率不变。
     * 注意：仅服务新计划页，不写入计划引擎 careerStats。
     */
    fun backtest(plan: PlanDefinition, history: List<DrawRecord>, periods: Int): BacktestReport {
        val cycle = plan.cyclePeriods.coerceIn(1, 20)
        val n = periods.coerceAtLeast(1).coerceAtMost((history.size - 5).coerceAtLeast(1))
        val start = (history.size - n).coerceAtLeast(5)
        var hits = 0
        var misses = 0
        var hitStreak = 0
        var missStreak = 0
        var maxHit = 0
        var maxMiss = 0
        val rates = mutableListOf<Double>()
        var i = start
        while (i < history.size) {
            val prior = history.subList(0, i)
            val p = predict(plan, prior)
            if (p == null) {
                i += 1
                continue
            }
            val end = (i + cycle).coerceAtMost(history.size)
            // N 期内任一期命中 → 中；全部未中 → 错
            var hit = false
            for (j in i until end) {
                if (evaluate(plan, p.output, history[j])) {
                    hit = true
                    break
                }
            }
            if (hit) {
                hits++; hitStreak++; missStreak = 0; maxHit = maxOf(maxHit, hitStreak)
            } else {
                misses++; missStreak++; hitStreak = 0; maxMiss = maxOf(maxMiss, missStreak)
            }
            rates += if (hit) 1.0 else 0.0
            i += cycle
        }
        val total = hits + misses
        val rate = if (total == 0) 0.0 else hits.toDouble() / total
        // 多期计划随机基准随周期提升（近似 1-(1-p)^N）
        val singleBaseline = plan.baselineValue.coerceIn(0.01, 0.99)
        val baseline = if (cycle <= 1) singleBaseline else (1.0 - (1.0 - singleBaseline).pow(cycle))
        val mean = rate
        val variance = if (rates.size < 2) 0.0 else rates.map { (it - mean) * (it - mean) }.average()
        val stability = (1.0 - sqrt(variance) * 2.0).coerceIn(0.0, 1.0)
        val stages = (1..cycle.coerceAtMost(3)).associateWith { stage ->
            stageBacktest(plan, history, periods, stage)
        }
        // 注意：两期/三期不是“第二期/第三期预测”，而是与其他页面完全一致的滚动窗口口径：
        // 连续窗口内至少命中一次 = 对窗口；窗口内全部未命中 = 错窗口。
        val (w2, w2Hit, w2Miss) = StreakCalc.windowRates(rates.map { if (it > 0.5) "对" else "错" }, 2)
        val (w3, w3Hit, w3Miss) = StreakCalc.windowRates(rates.map { if (it > 0.5) "对" else "错" }, 3)
        return BacktestReport(
            plan.planId, total, hits, misses, rate, baseline, rate - baseline, maxHit, maxMiss, stability, stages,
            twoWindows = w2, twoHitWindows = w2Hit, twoMissWindows = w2Miss,
            twoHitRate = if (w2 > 0) w2Hit.toDouble() / w2 else 0.0,
            twoMissRate = if (w2 > 0) w2Miss.toDouble() / w2 else 0.0,
            threeWindows = w3, threeHitWindows = w3Hit, threeMissWindows = w3Miss,
            threeHitRate = if (w3 > 0) w3Hit.toDouble() / w3 else 0.0,
            threeMissRate = if (w3 > 0) w3Miss.toDouble() / w3 else 0.0
        )
    }

    /**
     * 图表回测：输出每个回测单元的累计收益、峰谷、回撤与趋势数据。
     * 仅用于历史统计分析；单注金额只影响理论盈亏，不改变预测结果。
     * 收益口径：命中 +stake，未命中 -stake（等额盈亏基准）。
     */
    fun chartBacktest(
        plan: PlanDefinition,
        history: List<DrawRecord>,
        periods: Int,
        stake: Double,
        stage: Int = 1,
        /** false=正投；true=反投（方向取反后结算） */
        invert: Boolean = false
    ): ChartReport {
        // 严格 walk-forward：按期号升序，以最新已开奖期为终点，连续向前取 N 个目标期。
        // 不固定历史区间、不随机抽样；一期/二期/三期只改变结算的目标偏移。
        val ordered = history.sortedWith(compareBy<DrawRecord> { it.issue.toLongOrNull() ?: Long.MIN_VALUE }.thenBy { it.issue })
        val selectedStage = stage.coerceIn(1, 3)
        val availableTargets = (ordered.size - 5 - (selectedStage - 1)).coerceAtLeast(0)
        val targetCount = periods.coerceAtLeast(1).coerceAtMost(availableTargets)
        val firstPredictionIndex = (ordered.size - targetCount - (selectedStage - 1)).coerceAtLeast(5)
        val points = mutableListOf<ChartPoint>()
        var cumulative = 0.0
        var peak = 0.0
        var trough = 0.0
        var hits = 0
        var misses = 0
        var hitStreak = 0
        var missStreak = 0
        var maxHit = 0
        var maxMiss = 0
        val amount = stake.coerceAtLeast(0.0)

        for (i in firstPredictionIndex until ordered.size) {
            val targetIndex = i + selectedStage - 1
            if (targetIndex >= ordered.size) break
            val prediction = predict(plan, ordered.subList(0, i)) ?: continue
            val rawOut = prediction.output
            val out = if (invert) invertPrediction(plan.playType, rawOut) else rawOut
            val hit = evaluate(plan, out, ordered[targetIndex])
            val periodProfit = if (hit) amount else -amount
            cumulative += periodProfit
            peak = maxOf(peak, cumulative)
            trough = minOf(trough, cumulative)
            val drawdown = peak - cumulative
            if (hit) {
                hits++
                hitStreak++
                missStreak = 0
                maxHit = maxOf(maxHit, hitStreak)
            } else {
                misses++
                missStreak++
                hitStreak = 0
                maxMiss = maxOf(maxMiss, missStreak)
            }
            val total = hits + misses
            points += ChartPoint(
                issue = ordered[targetIndex].issue,
                prediction = if (invert) "反:$out" else out,
                hit = hit,
                stake = amount,
                periodProfit = periodProfit,
                cumulativeProfit = cumulative,
                peakProfit = peak,
                troughProfit = trough,
                drawdown = drawdown,
                hitRate = if (total == 0) 0.0 else hits.toDouble() / total
            )
        }

        val maxPeak = points.maxOfOrNull { it.cumulativeProfit } ?: 0.0
        val minTrough = points.minOfOrNull { it.cumulativeProfit } ?: 0.0
        val current = points.lastOrNull()?.cumulativeProfit ?: 0.0
        val range = (maxPeak - minTrough).coerceAtLeast(0.0)
        var runningPeak = 0.0
        var observedMaxDrawdown = 0.0
        points.forEach { point ->
            runningPeak = maxOf(runningPeak, point.cumulativeProfit)
            observedMaxDrawdown = maxOf(observedMaxDrawdown, runningPeak - point.cumulativeProfit)
        }
        val position = if (range <= 0.0) 50.0 else ((current - minTrough) / range * 100.0).coerceIn(0.0, 100.0)
        val distancePeak = maxPeak - current
        val rebound = current - minTrough
        val nearHigh = range > 0.0 && position >= 70.0
        val nearLow = range > 0.0 && position <= 30.0
        val previousMax = if (points.size > 1) points.dropLast(1).maxOfOrNull { it.cumulativeProfit } ?: current else current
        val previousMin = if (points.size > 1) points.dropLast(1).minOfOrNull { it.cumulativeProfit } ?: current else current
        val trend = when {
            points.isEmpty() -> "暂无数据"
            points.size > 1 && current > previousMax -> "↑ 创新高"
            points.size > 1 && current < previousMin -> "↓ 创新低"
            nearHigh && distancePeak > 0 -> "↓ 高位回落"
            nearHigh -> "→ 高位震荡"
            nearLow && rebound > 0 -> "↑ 低位反弹"
            nearLow -> "→ 低位震荡"
            points.size >= 2 && current > points[points.lastIndex - 1].cumulativeProfit -> "↑ 上升趋势"
            points.size >= 2 && current < points[points.lastIndex - 1].cumulativeProfit -> "↓ 下降趋势"
            else -> "→ 横盘震荡"
        }
        val rateSeries = points.map { it.hitRate }
        val maxHr = rateSeries.maxOrNull() ?: 0.0
        val minHr = rateSeries.minOrNull() ?: 0.0
        val displayPlan = if (invert) plan.copy(
            planId = plan.planId + "-REV",
            planName = plan.planName + "·反投"
        ) else plan.copy(planName = plan.planName + "·正投")
        return ChartReport(
            plan = displayPlan, periods = points.size, stake = amount, points = points, hits = hits, misses = misses,
            totalStake = (hits + misses) * amount, netProfit = cumulative,
            hitRate = if (hits + misses == 0) 0.0 else hits.toDouble() / (hits + misses),
            maxHitRate = maxHr, minHitRate = minHr,
            maxHitStreak = maxHit, maxMissStreak = maxMiss,
            maxDrawdown = observedMaxDrawdown, maxPeak = maxPeak, minTrough = minTrough,
            currentTrend = trend, positionPercent = position, distanceFromPeak = distancePeak, reboundFromTrough = rebound
        )
    }

    /**
     * 共识来源历史回测：按目标期聚合大小/单双/组合等共识记录，
     * 一期一计；该期所有已保存共识分类均命中才记为“对”。只取最新已结算期向前的连续样本。
     */
    /**
     * 共识回测：按「大小 / 单双 / 组合」分类分别结算（一期一类一计），
     * 不再要求同一期所有分类全对才算对。
     * @param categories 为空时默认三类都回测；可只传需要的分类。
     */
    fun chartBacktestConsensus(
        sourceLabel: String,
        records: List<com.caifenxi.app.domain.model.ConsensusRecord>,
        periods: Int,
        stake: Double,
        categories: List<String> = listOf("大小", "单双", "组合"),
        invert: Boolean = false
    ): List<ChartReport> {
        val want = categories.map { it.trim() }.filter { it.isNotEmpty() }.ifEmpty { listOf("大小", "单双", "组合") }
        return want.mapNotNull { cat -> chartBacktestConsensusCategory(sourceLabel, records, periods, stake, cat, invert) }
    }

    /** 单分类共识回测：只使用该 category 的已结算记录，按期号从最新往前取 periods 期。 */
    fun chartBacktestConsensusCategory(
        sourceLabel: String,
        records: List<com.caifenxi.app.domain.model.ConsensusRecord>,
        periods: Int,
        stake: Double,
        category: String,
        invert: Boolean = false
    ): ChartReport? {
        val settled = records
            .filter { it.category == category && (it.result == "对" || it.result == "错") }
            .sortedWith(
                compareBy<com.caifenxi.app.domain.model.ConsensusRecord> {
                    it.targetIssue.toLongOrNull() ?: Long.MIN_VALUE
                }.thenBy { it.targetIssue }.thenBy { it.createdAt }
            )
            .let { list ->
                // 同一期同一分类若有多条，取最新一条
                list.groupBy { it.targetIssue }
                    .mapValues { (_, rows) -> rows.maxByOrNull { it.settledAt ?: it.createdAt }!! }
                    .values
                    .sortedWith(
                        compareBy<com.caifenxi.app.domain.model.ConsensusRecord> {
                            it.targetIssue.toLongOrNull() ?: Long.MIN_VALUE
                        }.thenBy { it.targetIssue }
                    )
                    .takeLast(periods.coerceAtLeast(1))
            }
        if (settled.isEmpty()) return null
        val amount = stake.coerceAtLeast(0.0)
        var cumulative = 0.0
        var peak = 0.0
        var trough = 0.0
        var hits = 0
        var misses = 0
        var hitStreak = 0
        var missStreak = 0
        var maxHit = 0
        var maxMiss = 0
        val points = settled.map { row ->
            val baseHit = row.result == "对"
            val hit = if (invert) !baseHit else baseHit
            val shownPred = if (invert) {
                "反:" + invertPrediction(category, row.leadingDirection)
            } else {
                "${row.category}:${row.leadingDirection}"
            }
            val profit = if (hit) amount else -amount
            cumulative += profit
            peak = maxOf(peak, cumulative)
            trough = minOf(trough, cumulative)
            if (hit) {
                hits++; hitStreak++; missStreak = 0; maxHit = maxOf(maxHit, hitStreak)
            } else {
                misses++; missStreak++; hitStreak = 0; maxMiss = maxOf(maxMiss, missStreak)
            }
            val total = hits + misses
            ChartPoint(
                issue = row.targetIssue,
                prediction = shownPred,
                hit = hit,
                stake = amount,
                periodProfit = profit,
                cumulativeProfit = cumulative,
                peakProfit = peak,
                troughProfit = trough,
                drawdown = peak - cumulative,
                hitRate = if (total == 0) 0.0 else hits.toDouble() / total
            )
        }
        val maxPeak = points.maxOfOrNull { it.cumulativeProfit } ?: 0.0
        val minTrough = points.minOfOrNull { it.cumulativeProfit } ?: 0.0
        val current = points.lastOrNull()?.cumulativeProfit ?: 0.0
        val range = (maxPeak - minTrough).coerceAtLeast(0.0)
        val position = if (range == 0.0) 50.0 else ((current - minTrough) / range * 100.0).coerceIn(0.0, 100.0)
        val previousMax = points.dropLast(1).maxOfOrNull { it.cumulativeProfit } ?: current
        val previousMin = points.dropLast(1).minOfOrNull { it.cumulativeProfit } ?: current
        val trend = when {
            points.size > 1 && current > previousMax -> "↑ 创新高"
            points.size > 1 && current < previousMin -> "↓ 创新低"
            points.size > 1 && current > points[points.lastIndex - 1].cumulativeProfit -> "↑ 上升趋势"
            points.size > 1 && current < points[points.lastIndex - 1].cumulativeProfit -> "↓ 下降趋势"
            else -> "→ 横盘震荡"
        }
        val plan = PlanDefinition(
            planId = "CONSENSUS-$category-$sourceLabel" + if (invert) "-REV" else "",
            planName = "$sourceLabel·$category" + if (invert) "·反投" else "·正投",
            category = "共识",
            algorithm = "CONSENSUS",
            window = points.size.coerceAtLeast(1),
            playType = category,
            baselineValue = if (category == "组合") 0.25 else 0.50
        )
        val rateSeries = points.map { it.hitRate }
        return ChartReport(
            plan = plan,
            periods = points.size,
            stake = amount,
            points = points,
            hits = hits,
            misses = misses,
            totalStake = (hits + misses) * amount,
            netProfit = cumulative,
            hitRate = if (hits + misses == 0) 0.0 else hits.toDouble() / (hits + misses),
            maxHitRate = rateSeries.maxOrNull() ?: 0.0,
            minHitRate = rateSeries.minOrNull() ?: 0.0,
            maxHitStreak = maxHit,
            maxMissStreak = maxMiss,
            maxDrawdown = points.maxOfOrNull { it.drawdown } ?: 0.0,
            maxPeak = maxPeak,
            minTrough = minTrough,
            currentTrend = trend,
            positionPercent = position,
            distanceFromPeak = maxPeak - current,
            reboundFromTrough = current - minTrough
        )
    }


    /**
     * 单独统计首期/二期/三期。每一期都以同一条“预测锁定”作为起点，
     * 只结算该期对应的开奖结果，不把其它期的结果混入。
     */
    fun stageBacktest(plan: PlanDefinition, history: List<DrawRecord>, periods: Int, stage: Int): StageReport {
        val s = stage.coerceIn(1, 3)
        val n = periods.coerceAtLeast(1).coerceAtMost((history.size - 5 - (s - 1)).coerceAtLeast(1))
        val start = (history.size - n - (s - 1)).coerceAtLeast(5)
        var hits = 0
        var misses = 0
        var hitStreak = 0
        var missStreak = 0
        var maxHit = 0
        var maxMiss = 0
        val rates = mutableListOf<Double>()
        for (i in start until history.size) {
            val target = i + s - 1
            if (target >= history.size) break
            val p = predict(plan, history.subList(0, i)) ?: continue
            val hit = evaluate(plan, p.output, history[target])
            if (hit) {
                hits++; hitStreak++; missStreak = 0; maxHit = maxOf(maxHit, hitStreak)
            } else {
                misses++; missStreak++; hitStreak = 0; maxMiss = maxOf(maxMiss, missStreak)
            }
            rates += if (hit) 1.0 else 0.0
        }
        val total = hits + misses
        val rate = if (total == 0) 0.0 else hits.toDouble() / total
        val baseline = plan.baselineValue.coerceIn(0.01, 0.99)
        val mean = rate
        val variance = if (rates.size < 2) 0.0 else rates.map { (it - mean) * (it - mean) }.average()
        val stability = (1.0 - sqrt(variance) * 2.0).coerceIn(0.0, 1.0)
        return StageReport(s, total, hits, misses, rate, baseline, rate - baseline, maxHit, maxMiss, stability)
    }

    /** 正投/反投：对方向类预测取反（大小、单双、组合候选）。 */
    fun invertPrediction(playType: String, output: String): String {
        if (output.isBlank()) return output
        return when (playType) {
            "大小" -> output.split("/", "、", ",", " ").map { it.trim() }.filter { it.isNotEmpty() }
                .joinToString("/") {
                    when (it) {
                        "大" -> "小"
                        "小" -> "大"
                        else -> it
                    }
                }
            "单双" -> output.split("/", "、", ",", " ").map { it.trim() }.filter { it.isNotEmpty() }
                .joinToString("/") {
                    when (it) {
                        "单" -> "双"
                        "双" -> "单"
                        else -> it
                    }
                }
            "组合" -> output.split("/", "、", ",", " ").map { it.trim() }.filter { it.isNotEmpty() }
                .joinToString("/") { token ->
                    token.map { c ->
                        when (c) {
                            '大' -> '小'
                            '小' -> '大'
                            '单' -> '双'
                            '双' -> '单'
                            else -> c
                        }
                    }.joinToString("")
                }
            else -> output // 数字/位置反投不改变号码，仅翻转对错见调用方
        }.ifBlank { output }
    }

    private fun evaluate(plan: PlanDefinition, output: String, actual: DrawRecord): Boolean {
        val parts = output.split("/", "、", ",").map { it.trim() }.filter { it.isNotEmpty() }
        return when (plan.playType) {
            "大小" -> parts.any { it == actual.dx }
            "单双" -> parts.any { it == actual.ds }
            "组合" -> parts.any { it == actual.combo }
            "数字" -> parts.any { it.toIntOrNull()?.let { n -> n in actual.numbers } == true }
            "位置" -> {
                if (actual.numbers.isEmpty()) return false
                val index = plan.positionIndex.coerceIn(0, actual.numbers.lastIndex)
                val n = actual.numberAt(index)
                parts.any { it.toIntOrNull() == n }
            }
            else -> false
        }
    }

    private fun directionOutput(
        plan: PlanDefinition,
        data: List<DrawRecord>,
        seq: List<String>,
        a: String,
        b: String
    ): String {
        if (seq.isEmpty()) return ""
        // 每计划独立回看长度与 tie-break，避免同算法+同玩法输出完全一致
        val lookback = planLookback(plan)
        val salt = planSalt(plan)
        // 经验学习 / 形态匹配：走预测引擎正式算法，与预测页/挂机同源
        when (plan.algorithm) {
            "EXPERIENCE" -> return PredictEngine.predictLabel(
                seq, listOf(a, b), UserPrefs(predictionWindow = plan.window.coerceIn(20, 500)), AlgoMode.EXPERIENCE
            )
            "PATTERN" -> return PredictEngine.predictLabel(
                seq, listOf(a, b), UserPrefs(predictionWindow = plan.window.coerceIn(20, 500)), AlgoMode.PATTERN
            )
            "FUSION" -> return PredictEngine.predictLabel(
                seq, listOf(a, b), UserPrefs(predictionWindow = plan.window.coerceIn(20, 500)), AlgoMode.FUSION
            )
        }
        return when (plan.algorithm) {
            "RHYTHM" -> rhythm(seq, a, b, lookback, salt)
            "SIMILAR" -> similarDirection(seq, lookback, salt)
            "ANOMALY" -> anomaly(seq, a, b, lookback, salt)
            "NETWORK" -> network(seq, a, b, lookback, salt)
            "STRUCT" -> struct(seq, a, b, lookback, salt)
            "CANDIDATE" -> candidate(seq, a, b, lookback, salt)
            "OPTIMIZE" -> optimize(seq, a, b, lookback, salt)
            "STATE" -> state(seq, lookback, salt)
            else -> state(seq, lookback, salt)
        }
    }

    private fun planLookback(plan: PlanDefinition): Int {
        val base = plan.window.coerceIn(5, 80)
        // 算法与 planId 微调，拉开同窗口计划差异
        val adj = (kotlin.math.abs(plan.planId.hashCode()) % 7) - 3
        return (base / 2 + adj).coerceIn(4, base)
    }

    private fun planSalt(plan: PlanDefinition): Int =
        kotlin.math.abs(plan.planId.hashCode() * 31 + plan.window * 17 + plan.algorithm.hashCode())

    private fun comboOutput(plan: PlanDefinition, data: List<DrawRecord>, topN: Int): String {
        val lookback = planLookback(plan)
        val salt = planSalt(plan)
        val seq = data.mapNotNull { it.combo }.takeLast(lookback.coerceAtLeast(8))
        if (seq.isEmpty()) return ""
        val n = topN.coerceIn(1, 4)
        val comboLabels = listOf("大单", "大双", "小单", "小双")
        if (plan.algorithm == "EXPERIENCE" || plan.algorithm == "PATTERN" || plan.algorithm == "FUSION") {
            val mode = when (plan.algorithm) {
                "PATTERN" -> AlgoMode.PATTERN
                "FUSION" -> AlgoMode.FUSION
                else -> AlgoMode.EXPERIENCE
            }
            val prefs = UserPrefs(predictionWindow = plan.window.coerceIn(20, 500), comboPredCount = n)
            return PredictEngine.predictTopLabels(seq, comboLabels, prefs, mode, n).joinToString("/")
        }
        val counts = seq.groupingBy { it }.eachCount()
        val ranked = when (plan.algorithm) {
            "RHYTHM" -> {
                if (seq.size >= 3 && seq.takeLast(3).distinct().size == 1) {
                    counts.entries.sortedWith(compareBy<Map.Entry<String, Int>> { it.value }.thenBy { saltTie(it.key, salt) }).map { it.key }
                } else {
                    counts.entries.sortedWith(compareByDescending<Map.Entry<String, Int>> { it.value }.thenBy { saltTie(it.key, salt) }).map { it.key }
                }
            }
            "ANOMALY" -> {
                val avg = counts.values.average()
                counts.entries.sortedWith(
                    compareByDescending<Map.Entry<String, Int>> { kotlin.math.abs(it.value - avg) }
                        .thenBy { saltTie(it.key, salt) }
                ).map { it.key }
            }
            "NETWORK", "STRUCT" -> {
                val last = seq.last()
                val nextCounts = mutableMapOf<String, Int>()
                for (i in 1 until seq.size) {
                    if (seq[i - 1] == last) nextCounts[seq[i]] = (nextCounts[seq[i]] ?: 0) + 1
                }
                if (nextCounts.isNotEmpty()) {
                    nextCounts.entries.sortedByDescending { it.value }.map { it.key } +
                        counts.keys.filter { it !in nextCounts }.sortedBy { saltTie(it, salt) }
                } else {
                    counts.entries.sortedByDescending { it.value }.map { it.key }
                }
            }
            "CANDIDATE", "OPTIMIZE" -> {
                val hot = counts.entries.sortedWith(
                    compareByDescending<Map.Entry<String, Int>> { it.value }.thenBy { saltTie(it.key, salt) }
                ).map { it.key }
                // 按 salt 旋转起点，同热度下不同计划取不同组合顺序
                if (hot.isEmpty()) hot else {
                    val rot = salt % hot.size
                    hot.drop(rot) + hot.take(rot)
                }
            }
            else -> counts.entries.sortedWith(
                compareByDescending<Map.Entry<String, Int>> { it.value }.thenBy { saltTie(it.key, salt) }
            ).map { it.key }
        }
        return ranked.distinct().take(n).joinToString("/")
    }

    private fun saltTie(key: String, salt: Int): Int =
        kotlin.math.abs(key.hashCode() xor salt)

    private fun numberOutput(plan: PlanDefinition, data: List<DrawRecord>, position: Int?, topN: Int): String {
        val salt = planSalt(plan)
        val counts = mutableMapOf<Int, Double>()
        data.forEachIndexed { index, row ->
            val nums = if (position == null) row.numbers else listOfNotNull(row.numberAt(position))
            val progress = index.toDouble() / data.size.coerceAtLeast(1)
            val decay = when (plan.algorithm) {
                "RHYTHM" -> 0.6 + progress * 1.0
                "ANOMALY" -> 1.2 - progress * 0.5
                "SIMILAR", "NETWORK" -> 0.7 + progress * 0.9
                "STRUCT" -> if (index >= data.size - 5) 1.4 else 0.8
                "CANDIDATE" -> 1.0 + (salt % 5) * 0.02
                "OPTIMIZE" -> 0.9 + progress * 0.4
                else -> 1.0
            }
            nums.forEach { n -> counts[n] = (counts[n] ?: 0.0) + decay }
        }
        if (counts.isEmpty()) return ""
        val ranked = when (plan.algorithm) {
            "ANOMALY" -> {
                val avg = counts.values.average()
                counts.entries.sortedWith(
                    compareByDescending<Map.Entry<Int, Double>> { kotlin.math.abs(it.value - avg) }
                        .thenBy { saltTie(it.key.toString(), salt) }
                )
            }
            "OPTIMIZE", "CANDIDATE" -> {
                val hot = counts.entries.sortedByDescending { it.value }
                val cold = counts.entries.sortedBy { it.value }
                val mixed = mutableListOf<Map.Entry<Int, Double>>()
                for (i in 0 until maxOf(hot.size, cold.size)) {
                    if (i < hot.size) mixed += hot[i]
                    if (i < cold.size && cold[i].key != hot.getOrNull(i)?.key) mixed += cold[i]
                }
                val list = mixed.distinctBy { it.key }
                val rot = if (list.isEmpty()) 0 else salt % list.size
                list.drop(rot) + list.take(rot)
            }
            else -> counts.entries.sortedWith(
                compareByDescending<Map.Entry<Int, Double>> { it.value }.thenBy { saltTie(it.key.toString(), salt) }
            )
        }
        return ranked.take(topN.coerceIn(1, 10)).joinToString("/") { it.key.toString() }
    }

    private fun state(seq: List<String>, lookback: Int = 8, salt: Int = 0): String {
        val slice = seq.takeLast(lookback.coerceIn(3, seq.size.coerceAtLeast(3)))
        val counts = slice.groupingBy { it }.eachCount()
        // 平票时用 salt 打破，避免全池同一结果
        return counts.maxWithOrNull(
            compareBy<Map.Entry<String, Int>> { it.value }.thenBy { -saltTie(it.key, salt) }
        )?.key.orEmpty()
    }

    private fun rhythm(seq: List<String>, a: String, b: String, lookback: Int, salt: Int): String {
        if (seq.size < 4) return state(seq, lookback, salt)
        val streak = 2 + (salt % 3) // 2～4 连出触发反转，计划间不同
        return if (seq.takeLast(streak).distinct().size == 1) {
            if (seq.last() == a) b else a
        } else state(seq, lookback, salt)
    }

    private fun anomaly(seq: List<String>, a: String, b: String, lookback: Int, salt: Int): String {
        val slice = seq.takeLast(lookback.coerceAtLeast(6))
        val pA = slice.count { it == a }.toDouble() / slice.size.coerceAtLeast(1)
        val hi = 0.58 + (salt % 5) * 0.02
        val lo = 0.42 - (salt % 5) * 0.02
        return when {
            pA > hi -> b
            pA < lo -> a
            else -> state(seq, lookback, salt)
        }
    }

    private fun similarDirection(seq: List<String>, lookback: Int, salt: Int): String {
        val pattern = 4 + (salt % 3) // 4～6 期形态
        if (seq.size < pattern * 2) return state(seq, lookback, salt)
        val tail = seq.takeLast(pattern)
        val candidates = seq.dropLast(pattern).windowed(pattern)
        if (candidates.isEmpty()) return state(seq, lookback, salt)
        // 取最相似的第 (salt%3)+1 个匹配，避免全选同一个历史段
        val ranked = candidates.mapIndexed { idx, w ->
            idx to w.zip(tail).count { it.first != it.second }
        }.sortedWith(compareBy<Pair<Int, Int>> { it.second }.thenBy { (it.first + salt) % 97 })
        val pick = ranked.getOrNull(salt % ranked.size.coerceAtMost(3)) ?: ranked.first()
        return seq.getOrNull(pick.first + pattern) ?: state(seq, lookback, salt)
    }

    private fun network(seq: List<String>, a: String, b: String, lookback: Int, salt: Int): String {
        val slice = seq.takeLast(lookback.coerceAtLeast(6))
        if (slice.size < 6) return state(seq, lookback, salt)
        val last = slice.last()
        val next = mutableMapOf<String, Int>()
        for (i in 1 until slice.size) {
            if (slice[i - 1] == last) next[slice[i]] = (next[slice[i]] ?: 0) + 1
        }
        return next.maxWithOrNull(
            compareBy<Map.Entry<String, Int>> { it.value }.thenBy { -saltTie(it.key, salt) }
        )?.key ?: state(seq, lookback, salt)
    }

    private fun struct(seq: List<String>, a: String, b: String, lookback: Int, salt: Int): String {
        if (seq.size < 6) return state(seq, lookback, salt)
        val n = (5 + salt % 4).coerceAtMost(seq.size) // 5～8
        val tail = seq.takeLast(n)
        var switches = 0
        for (i in 1 until tail.size) if (tail[i] != tail[i - 1]) switches++
        val threshold = 2 + (salt % 3)
        return if (switches >= threshold) {
            if (seq.last() == a) b else a
        } else state(seq, lookback, salt)
    }

    private fun candidate(seq: List<String>, a: String, b: String, lookback: Int, salt: Int): String {
        if (seq.size < 5) return state(seq, lookback, salt)
        val counts = seq.takeLast(lookback.coerceIn(8, 30)).groupingBy { it }.eachCount()
        val ordered = counts.entries.sortedWith(
            compareByDescending<Map.Entry<String, Int>> { it.value }.thenBy { saltTie(it.key, salt) }
        )
        val top = ordered.firstOrNull()?.key ?: return state(seq, lookback, salt)
        val second = ordered.getOrNull(1)?.key
        // salt 偶数偏热，奇数在接近时选次热
        return if (second != null && (counts[second] ?: 0) * 2 >= (counts[top] ?: 0) && salt % 2 == 1) second else top
    }

    private fun optimize(seq: List<String>, a: String, b: String, lookback: Int, salt: Int): String {
        if (seq.size < 6) return state(seq, lookback, salt)
        val shortN = 3 + (salt % 4)
        val short = seq.takeLast(shortN).groupingBy { it }.eachCount()
            .maxWithOrNull(compareBy<Map.Entry<String, Int>> { it.value }.thenBy { -saltTie(it.key, salt) })?.key
        val transfer = network(seq, a, b, lookback, salt)
        return when {
            short != null && short == transfer -> short
            salt % 3 == 0 -> transfer.ifBlank { short.orEmpty() }.ifBlank { state(seq, lookback, salt) }
            else -> short.orEmpty().ifBlank { transfer }.ifBlank { state(seq, lookback, salt) }
        }
    }
}
