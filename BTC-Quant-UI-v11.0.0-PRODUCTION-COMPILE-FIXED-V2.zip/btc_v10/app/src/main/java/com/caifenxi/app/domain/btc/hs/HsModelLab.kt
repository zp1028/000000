package com.caifenxi.app.domain.btc.hs

import com.caifenxi.app.domain.btc.BtcCandle
import com.caifenxi.app.domain.btc.MarketRegime
import kotlin.math.abs

/** Strict chronological model laboratory with regime attribution. */
class HsModelLab(private val minSamples: Int = 24) {
    data class ModelScore(val modelId:String,val samples:Int,val hitRate:Double,val brier:Double,val logLoss:Double,val regime:MarketRegime)
    data class RegimeCell(val modelId:String,val regime:MarketRegime,val samples:Int,val hitRate:Double,val brier:Double)
    data class Report(val version:String,val holdoutSamples:Int,val models:List<ModelScore>,val regimeMatrix:List<RegimeCell>)
    fun evaluate(c:List<BtcCandle>):Report {
        if(c.size<minSamples+35)return Report(VERSION,0,emptyList(),emptyList())
        val split=(c.size*.8).toInt().coerceIn(30,c.lastIndex-1)
        val models=MODEL_IDS.mapNotNull{score(it,c,split)}
        val cells=MODEL_IDS.flatMap{id->MarketRegime.entries.mapNotNull{r->cell(id,r,c,split)}}
        return Report(VERSION,c.size-split-1,models,cells)
    }
    private fun score(id:String,c:List<BtcCandle>,s:Int):ModelScore? { val rows=(s until c.lastIndex).map{i->predict(id,c,i) to (c[i+1].close>c[i].close)}; if(rows.size<minSamples)return null; return metrics(id,MarketRegime.RANGE,rows) }
    private fun cell(id:String,r:MarketRegime,c:List<BtcCandle>,s:Int):RegimeCell? { val rows=(s until c.lastIndex).filter{detect(c,it)==r}.map{i->predict(id,c,i) to (c[i+1].close>c[i].close)}; if(rows.size<8)return null; val m=metrics(id,r,rows); return RegimeCell(id,r,m.samples,m.hitRate,m.brier) }
    private fun metrics(id:String,r:MarketRegime,rows:List<Pair<Double,Boolean>>):ModelScore { val hit=rows.count{(p,y)->(p>=.5)==y}.toDouble()/rows.size; val b=rows.map{(p,y)->val e=p-if(y)1.0 else 0.0;e*e}.average(); val ll=rows.map{(p0,y)->val p=p0.coerceIn(1e-6,1-1e-6);if(y)-kotlin.math.ln(p) else -kotlin.math.ln(1-p)}.average(); return ModelScore(id,rows.size,hit,b,ll,r) }
    fun ensembleProbability(c: List<BtcCandle>, index: Int = c.lastIndex, regime: MarketRegime = detect(c, index), weights: Map<String, Double> = emptyMap()): Double {
        if (c.isEmpty() || index <= 0 || index >= c.size) return 0.5
        val active = if (weights.isEmpty()) MODEL_IDS.associateWith { 1.0 / MODEL_IDS.size } else weights
        val total = active.values.sum().coerceAtLeast(1e-9)
        return active.entries.sumOf { (id, w) -> predict(id, c, index) * w.coerceAtLeast(0.0) }
            .div(total).coerceIn(0.03, 0.97)
    }

    private fun predict(id:String,c:List<BtcCandle>,i:Int):Double=when(id){
        "TREND"->sig((ema(c,i,9)/ema(c,i,21)-1)*180)
        "MOMENTUM"->sig((c[i].close/c[i-1].close-1)*12+(c[i].close/c[(i-8).coerceAtLeast(0)].close-1)*5)
        "MEAN_REVERSION"->sig((c.subList((i-19).coerceAtLeast(0),i+1).map{it.close}.average()/c[i].close-1)*70)
        "BREAKOUT"->{val hi=c.subList((i-19).coerceAtLeast(0),i).maxOf{it.high};val lo=c.subList((i-19).coerceAtLeast(0),i).minOf{it.low};when{c[i].close>hi->.68;c[i].close<lo->.32;else->.5}}
        "VOLATILITY"->{val range=(c[i].high-c[i].low)/c[i].close.coerceAtLeast(1e-9);val body=(c[i].close-c[i].open)/c[i].close.coerceAtLeast(1e-9);sig(body*70+(range-.008)*15*if(body>=0)1 else -1)}
        else->.5
    }.coerceIn(.03,.97)
    private fun detect(c:List<BtcCandle>,i:Int):MarketRegime {if(i<30)return MarketRegime.RANGE;val close=c[i].close;val e9=ema(c,i,9);val e21=ema(c,i,21);val e50=ema(c,i,50);val atr=c.subList((i-13).coerceAtLeast(1),i+1).map{it.high-it.low}.average()/close;val trend=abs(e9-e50)/close;val hi=c.subList((i-19).coerceAtLeast(0),i).maxOf{it.high};val lo=c.subList((i-19).coerceAtLeast(0),i).minOf{it.low};return when{atr>.02->MarketRegime.HIGH_VOLATILITY;close>hi||close<lo->MarketRegime.BREAKOUT;e9>e21&&e21>e50&&trend>.004->MarketRegime.TREND_UP;e9<e21&&e21<e50&&trend>.004->MarketRegime.TREND_DOWN;else->MarketRegime.RANGE}}
    private fun ema(c:List<BtcCandle>,i:Int,p:Int):Double{val s=(i-p*2).coerceAtLeast(0);var e=c[s].close;val k=2.0/(p+1);for(j in s+1..i)e=c[j].close*k+e*(1-k);return e}
    private fun sig(z:Double)=1.0/(1.0+kotlin.math.exp(-z.coerceIn(-12.0,12.0)))
    companion object{const val VERSION="HS-LAB-1.1-WF";val MODEL_IDS=listOf("TREND","MOMENTUM","MEAN_REVERSION","BREAKOUT","VOLATILITY")}
}
