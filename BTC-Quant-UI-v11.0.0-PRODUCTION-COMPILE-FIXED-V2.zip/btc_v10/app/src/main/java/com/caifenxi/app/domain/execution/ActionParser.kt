package com.caifenxi.app.domain.execution

import org.json.JSONObject

/**
 * 解析 LLM 返回的 JSON Action
 */
object ActionParser {

    data class Action(
        val type: String,
        val x: Float = 0f,
        val y: Float = 0f,
        val target: String = "",
        val text: String = "",
        val direction: String = "",
        val amount: Int = 0,
        val delayMs: Long = 500,
        val reason: String = "",
        val confidence: Float = 0f
    ) {
        override fun toString(): String {
            return when (type) {
                "click" -> "click($x, $y, $target)"
                "type" -> "type($x, $y, $text)"
                "scroll" -> "scroll($direction, $amount)"
                "wait" -> "wait(${delayMs}ms)"
                "finish" -> "finish($reason)"
                "fail" -> "fail($reason)"
                else -> "$type(...)"
            }
        }
    }

    fun parse(jsonStr: String): Action {
        return try {
            val json = JSONObject(jsonStr.trim())
            val actionObj = json.optJSONObject("action") ?: JSONObject()
            Action(
                type = actionObj.optString("type", "fail"),
                x = actionObj.optDouble("x", 0.0).toFloat(),
                y = actionObj.optDouble("y", 0.0).toFloat(),
                target = actionObj.optString("target", ""),
                text = actionObj.optString("text", ""),
                direction = actionObj.optString("direction", ""),
                amount = actionObj.optInt("amount", 0),
                delayMs = actionObj.optLong("delayMs", 500),
                reason = actionObj.optString("reason", ""),
                confidence = json.optDouble("confidence", 0.0).toFloat()
            )
        } catch (e: Exception) {
            Action(type = "fail", reason = "JSON解析失败: ${e.message}")
        }
    }

    /**
     * 校验置信度，低于阈值拒绝执行
     */
    fun validate(action: Action, minConfidence: Float = 0.75f): Action {
        return if (action.confidence < minConfidence && action.type != "fail" && action.type != "finish") {
            Action(type = "fail", reason = "置信度不足: ${action.confidence} < $minConfidence")
        } else {
            action
        }
    }
}
