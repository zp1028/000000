# BTC Quant v9.8 — UI Alignment & Runtime Interaction Audit

## UI
- Main BTC Quant shell changed to a compact terminal-style dark header + horizontally scrollable tabs so all nine modules remain reachable on narrow Android screens.
- Dashboard adds an explicit 5m / 15m / 1h selector; changing it immediately refreshes the corresponding primary timeframe.
- Decision Center redesigned into the same dense terminal visual language as the reference: dark panels, monospace metrics, timeframe matrix, Model Lab, Lifecycle, Attribution and Snapshot Replay.

## Runtime/UI binding
- Snapshot Replay is now populated from the persistent `HsSnapshotStore`; the UI no longer displays an always-empty replay list.
- Decorative runtime/status chips in active BTC screens no longer expose empty click handlers.
- Strategy status chips are explicitly non-interactive.

## Audit findings
- Active BTC screens: no empty `onClick = {}` handlers remain.
- Active BTC domain/UI scan: no TODO/placeholder markers remain except the known Polymarket live cancel/signing boundary.
- Manifest contains only the BTC runtime service and launcher activity.
- CI workflows use Gradle 8.9 directly.

## Known external integration boundary
Polymarket live order placement/cancellation requires EIP-712 order signing and L2 HMAC authentication. The current broker deliberately surfaces that missing signer instead of pretending a skeleton REST request is a valid live order. Paper/dry-run paths remain executable.

## Validation
- Source ZIP integrity verified with `unzip -t`.
- Local APK compilation cannot be claimed because the package still lacks `gradle-wrapper.jar`; CI Gradle 8.9 is the authoritative build path.
