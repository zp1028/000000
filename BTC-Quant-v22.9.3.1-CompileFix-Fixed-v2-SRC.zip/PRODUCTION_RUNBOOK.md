# BTC Quant v11.0.0 落地运行手册

## 安全默认
- 默认 **PAPER**，不自动实盘
- LIVE 需：API Key + 确认语授权 + 数据门 `liveTradeAllowed` + Kill Switch 关闭
- 单笔风险硬上限默认 **2%** 净值
- 执行前：Kill Switch · 数据门 · 机会分 · 冷却 · 幂等

## 推荐上线顺序
1. 安装 BTC Quant Debug/Release 单一 APK
2. 打开 App → BTC 量化 → 看板，确认 8s 轮询有 p_hat / edge
3. **设置 → 上线自检** 全部打勾（至少 PAPER 可用）
4. **自注** Tab 启动运行时（PAPER），观察自动日志
5. 配置币安/Polymarket 密钥，做连通性测试
6. 输入确认语授权 LIVE（`I ACCEPT LIVE AUTO RISK`）
7. 小额试单；异常立即 **Kill Switch** 或 **全链路 KILL**

## 关键按钮
| 动作 | 位置 |
|------|------|
| Kill Switch | 设置 / 执行风控 |
| 全链路 KILL | 设置（停前台服务 + 执行门） |
| 恢复运行 | 设置 |
| 保存风控参数 | 设置（即时生效） |
| 启动/停止运行时 | 自注 Tab |

## 构建
```bash
./gradlew assembleRelease      # 唯一正式 Release APK
./gradlew assembleDebug        # 唯一 Debug APK
```

## 已知边界
- 实盘盈亏自负；模型不保证正期望
- Demo 模式不会伪造盘口/Oracle 下单
- 无网时保留上一份真实快照，不覆盖为 Demo（除非手动 loadDemo）
