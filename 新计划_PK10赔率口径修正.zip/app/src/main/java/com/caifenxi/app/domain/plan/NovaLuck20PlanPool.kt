package com.caifenxi.app.domain.plan

import com.caifenxi.app.domain.model.PlanDefinition
import com.caifenxi.app.domain.model.PlanHitCriteria
import com.caifenxi.app.domain.model.PlanOutputFormat

/** 快乐8/幸运20 专用计划池（与 PK10 Nova 隔离） */
object NovaLuck20PlanPool {
    private val algos = listOf("FREQ", "EWMA", "MKV1", "RHYTHM", "STATE", "SIMILAR")
    private val windows = listOf(10, 20, 30, 50, 100)

    val ALL: List<PlanDefinition> = buildList {
        for ((i, algo) in algos.withIndex()) {
            val w = windows[i % windows.size]
            add(PlanDefinition(
                planId = "NOVA-L20-DX-$algo",
                planName = "和值大小·$algo",
                category = "L20-大小",
                algorithm = algo,
                window = w,
                playType = "大小",
                baselineValue = 0.50
            ))
            add(PlanDefinition(
                planId = "NOVA-L20-DS-$algo",
                planName = "和值单双·$algo",
                category = "L20-单双",
                algorithm = algo,
                window = w,
                playType = "单双",
                baselineValue = 0.50
            ))
            add(PlanDefinition(
                planId = "NOVA-L20-CB-$algo",
                planName = "和值组合·$algo",
                category = "L20-组合",
                algorithm = algo,
                window = w,
                playType = "组合",
                baselineValue = 0.25,
                participateCombo = true
            ))
        }
        for (algo in listOf("FREQ", "EWMA", "MKV1")) {
            add(PlanDefinition(
                planId = "NOVA-L20-NUM-$algo",
                planName = "任选号码·$algo",
                category = "L20-号码",
                algorithm = algo,
                window = 40,
                playType = "数字",
                outputFormat = PlanOutputFormat.NUMBER_SCORES,
                hitCriteria = PlanHitCriteria.TOP20_HIT,
                baselineValue = 0.20,
                participateConsensus = false
            ))
        }
    }

    fun find(planId: String): PlanDefinition? = ALL.find { it.planId == planId }
}
