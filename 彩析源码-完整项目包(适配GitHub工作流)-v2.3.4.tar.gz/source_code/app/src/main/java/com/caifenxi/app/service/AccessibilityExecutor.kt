package com.caifenxi.app.service

import android.content.Context
import com.caifenxi.app.domain.execution.BetAction
import com.caifenxi.app.domain.execution.BetCommand
import com.caifenxi.app.domain.execution.ExecutionResult
import com.caifenxi.app.domain.execution.Executor
import com.caifenxi.app.util.RuntimeLog

/**
 * 无障碍执行器（AccessibilityExecutor）。
 *
 * 把统一 BetCommand 翻译为原 AutoBetAccessibilityService.performBet 调用，
 * 保留原有「节点识别 + 区域限制 + 挂起等待 + 成功/失败回写」全部能力。
 * 结果通过 AutoBetController 的成功/失败通知闭环（notifyBetSucceeded / notifyBetFailedOrTimedOut）。
 */
class AccessibilityExecutor(private val context: Context) : Executor {

    override val id: String = "accessibility"

    override val isAvailable: Boolean
        get() = AutoBetAccessibilityService.isRunning()

    override fun execute(command: BetCommand, onResult: (ExecutionResult) -> Unit): Boolean {
        val service = AutoBetAccessibilityService.instance
        if (service == null) {
            RuntimeLog.warn("Execution", "无障碍服务不可用，cmdId=${command.cmdId} 拒绝受理")
            onResult(
                ExecutionResult.fail(
                    command.cmdId,
                    ExecutionResult.WEBVIEW_DISCONNECTED,
                    "无障碍服务未连接"
                )
            )
            return false
        }

        val dx = command.bets.firstOrNull { it.category == BetAction.CAT_DX }?.value
            ?.takeIf { it == "大" || it == "小" }
        val ds = command.bets.firstOrNull { it.category == BetAction.CAT_DS }?.value
            ?.takeIf { it == "单" || it == "双" }
        val combo = command.bets.firstOrNull { it.category == BetAction.CAT_COMBO }?.value
            ?.takeIf { it in listOf("大单", "大双", "小单", "小双") }
        val predNumbers = command.bets
            .filter { it.category == BetAction.CAT_NUMBER }
            .map { it.value }
            .filter { it.toIntOrNull() != null }
            .distinct()
            .take(20)

        if (dx == null && ds == null && command.amountText.isNullOrBlank() &&
            combo == null && predNumbers.isEmpty()
        ) {
            RuntimeLog.warn("Execution", "cmdId=${command.cmdId} 无可执行注项，拒绝")
            onResult(ExecutionResult.fail(command.cmdId, ExecutionResult.ELEMENT_NOT_FOUND, "无可执行注项"))
            return false
        }

        RuntimeLog.info(
            "Execution",
            "无障碍受理 cmdId=${command.cmdId} 彩种=${command.lotteryKey} 期号=${command.issue} " +
                "dx=$dx ds=$ds combo=$combo amount=${command.amountText} nums=$predNumbers"
        )
        service.performBet(
            dx = dx,
            ds = ds,
            clickDelayMs = 350L,
            amountText = command.amountText,
            targetIssue = command.issue,
            lotteryKey = command.lotteryKey,
            combo = combo,
            predNumbers = predNumbers
        )
        // 受理即返回；真实结果由成功/失败回调经 AutoBetController 报告。
        return true
    }

    override fun cancel(cmdId: String) {
        // 无障碍单流水线：新任务会自然顶替；显式取消不支持。
        RuntimeLog.info("Execution", "无障碍取消 cmdId=$cmdId（忽略）")
    }

    override fun queryState(cmdId: String): ExecutionResult? = null
}
