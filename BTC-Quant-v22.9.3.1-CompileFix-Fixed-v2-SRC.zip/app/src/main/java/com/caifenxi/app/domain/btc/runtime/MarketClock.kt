package com.caifenxi.app.domain.btc.runtime

/** Single source of truth for bar boundaries/countdowns across paper/backtest/testnet/live. */
object MarketClock {
    data class Cycle(val timeframe: String, val durationMs: Long, val startMs: Long, val endMs: Long, val remainingMs: Long, val progress: Double)

    fun cycle(timeframe: String, nowMs: Long = System.currentTimeMillis()): Cycle {
        val duration = when (timeframe.lowercase()) {
            "1m", "1min" -> 60_000L
            "5m", "5min" -> 300_000L
            "15m", "15min" -> 900_000L
            "30m", "30min" -> 1_800_000L
            "1h", "60m", "60min" -> 3_600_000L
            else -> 300_000L
        }
        val start = Math.floorDiv(nowMs, duration) * duration
        val end = start + duration
        val remaining = (end - nowMs).coerceIn(0L, duration)
        val progress = ((nowMs - start).toDouble() / duration).coerceIn(0.0, 1.0)
        return Cycle(timeframe, duration, start, end, remaining, progress)
    }
}
