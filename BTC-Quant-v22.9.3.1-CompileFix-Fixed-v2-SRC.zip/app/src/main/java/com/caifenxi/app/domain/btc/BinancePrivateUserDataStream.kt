package com.caifenxi.app.domain.btc

import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONObject
import kotlinx.coroutines.*
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max

/**
 * Binance USD-M Futures private user stream.
 * ORDER_TRADE_UPDATE is the realtime order/fill source; ACCOUNT_UPDATE is the realtime
 * balance/position source. REST remains reconciliation/recovery, not the primary live feed.
 */
class BinancePrivateUserDataStream(
    private val apiKey: String,
    private val endpoint: String = "https://fapi.binance.com",
    private val wsBase: String = if (endpoint.contains("testnet", ignoreCase = true)) "wss://stream.binancefuture.com/ws" else "wss://fstream.binance.com/ws",
    private val client: OkHttpClient = OkHttpClient.Builder().connectTimeout(5, TimeUnit.SECONDS).readTimeout(0, TimeUnit.MILLISECONDS).pingInterval(15, TimeUnit.SECONDS).build()
) {
    data class OrderUpdate(val symbol: String, val orderId: Long, val clientOrderId: String, val status: String, val executionType: String, val side: String, val avgPrice: Double, val lastQty: Double, val cumulativeQty: Double, val lastPrice: Double, val realizedPnl: Double, val commission: Double, val eventTime: Long)
    data class AccountUpdate(val balances: Map<String, Double>, val positions: List<Position>, val reason: String, val eventTime: Long)
    data class StreamEvent(val eventType: String, val eventTime: Long, val transactionTime: Long, val rawHash: String)
    data class Position(val symbol: String, val amount: Double, val entryPrice: Double, val breakEvenPrice: Double, val unrealizedPnl: Double, val marginType: String, val side: String)

    interface Listener {
        fun onOrderUpdate(update: OrderUpdate) {}
        fun onAccountUpdate(update: AccountUpdate) {}
        fun onStreamEvent(event: StreamEvent) {}
        fun onGapDetected(eventType: String, previousEventTime: Long, currentEventTime: Long) {}
        fun onStatus(status: String, detail: String? = null) {}
    }

    private val running = AtomicBoolean(false)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var socket: WebSocket? = null
    private var listenKey: String? = null
    private var loop: Job? = null
    private var lastEventTime = 0L
    private var lastTransactionTime = 0L
    private val eventLedger = com.caifenxi.app.domain.btc.runtime.BinancePrivateEventLedger()
    private val lastTypeEvent = mutableMapOf<String, Long>()
    private val gapThresholdMs = 90_000L

    fun start(listener: Listener) {
        stop(); lastEventTime = 0L; lastTransactionTime = 0L; synchronized(lastTypeEvent) { lastTypeEvent.clear() }; eventLedger.reset(); running.set(true)
        loop = scope.launch {
            var backoff = 1_000L
            while (isActive && running.get()) {
                val key = createListenKey()
                if (key == null) {
                    listener.onStatus("ERROR", "Unable to create Binance listenKey")
                    delay(backoff); backoff = max(1_000L, (backoff * 2).coerceAtMost(15_000L)); continue
                }
                listenKey = key
                val connected = connect(key, listener)
                if (connected) backoff = 1_000L else {
                    delay(backoff); backoff = max(1_000L, (backoff * 2).coerceAtMost(15_000L))
                }
            }
        }
    }

    fun stop() {
        running.set(false); loop?.cancel(); loop = null
        socket?.close(1000, "client stop"); socket = null
        listenKey?.let { keepAlive(it, delete = true) }; listenKey = null
    }

    private suspend fun connect(key: String, listener: Listener): Boolean {
        val opened = CompletableDeferred<Boolean>(); val ended = CompletableDeferred<Unit>()
        val req = Request.Builder().url("$wsBase/$key").header("User-Agent", "BTCQuant/20.3").build()
        socket = client.newWebSocket(req, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) { listener.onStatus("LIVE", "Binance private user stream"); if (!opened.isCompleted) opened.complete(true) }
            override fun onMessage(webSocket: WebSocket, text: String) { runCatching { parse(JSONObject(text), listener) }.onFailure { listener.onStatus("LIVE", "parse: ${it.message}") } }
            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) { listener.onStatus("RECONNECTING", "closed $code"); if (!opened.isCompleted) opened.complete(false); if (!ended.isCompleted) ended.complete(Unit) }
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) { listener.onStatus("RECONNECTING", t.message); if (!opened.isCompleted) opened.complete(false); if (!ended.isCompleted) ended.complete(Unit) }
        })
        val ok = opened.await(); if (!ok) return false
        // Binance listenKey is valid for 60 minutes. Refresh every 25 minutes.
        while (running.get() && currentCoroutineContext().isActive) {
            delay(25 * 60 * 1000L)
            if (!keepAlive(key, false)) { listener.onStatus("RECONNECTING", "listenKey keepalive failed"); break }
        }
        ended.await(); return true
    }

    private fun createListenKey(): String? = runCatching {
        val req = Request.Builder().url("$endpoint/fapi/v1/listenKey").post(okhttp3.RequestBody.create(null, ByteArray(0))).header("X-MBX-APIKEY", apiKey).build()
        client.newCall(req).execute().use { response -> if (!response.isSuccessful) null else JSONObject(response.body?.string().orEmpty()).optString("listenKey").ifBlank { null } }
    }.getOrNull()

    private fun keepAlive(key: String, delete: Boolean): Boolean = runCatching {
        val method = if (delete) "DELETE" else "PUT"
        val req = Request.Builder().url("$endpoint/fapi/v1/listenKey").method(method, if (method == "DELETE") null else okhttp3.RequestBody.create(null, ByteArray(0))).header("X-MBX-APIKEY", apiKey).build()
        client.newCall(req).execute().use { it.isSuccessful }
    }.getOrDefault(false)

    private fun parse(o: JSONObject, listener: Listener) {
        val eventType = o.optString("e")
        val eventTime = o.optLong("E", System.currentTimeMillis())
        val transactionTime = o.optLong("T", eventTime)
        val rawHash = java.security.MessageDigest.getInstance("SHA-256").digest(o.toString().toByteArray()).joinToString("") { "%02x".format(it) }
        val ledger = eventLedger.accept(eventType, eventTime, transactionTime, o.toString())
        if (!ledger.accepted) {
            listener.onStatus(if (ledger.duplicate) "DUPLICATE_EVENT" else "STALE_EVENT", ledger.reason)
            return
        }
        lastEventTime = max(lastEventTime, eventTime)
        lastTransactionTime = max(lastTransactionTime, transactionTime)
        val previousTypeEvent = synchronized(lastTypeEvent) {
            val previous = lastTypeEvent[eventType] ?: 0L
            lastTypeEvent[eventType] = maxOf(previous, eventTime)
            previous
        }
        if (previousTypeEvent > 0L && eventTime - previousTypeEvent > gapThresholdMs) {
            listener.onGapDetected(eventType, previousTypeEvent, eventTime)
            listener.onStatus("RECONCILIATION_REQUIRED", "$eventType gap=${eventTime - previousTypeEvent}ms")
        }
        listener.onStreamEvent(StreamEvent(eventType, eventTime, transactionTime, rawHash))
        when (eventType) {
            "listenKeyExpired" -> {
                listener.onStatus("LISTEN_KEY_EXPIRED", "Binance listenKey expired; forcing renewal")
                socket?.close(4001, "listenKey expired")
                return
            }
            "ORDER_TRADE_UPDATE" -> {
                val x = o.optJSONObject("o") ?: return
                listener.onOrderUpdate(OrderUpdate(x.optString("s"), x.optLong("i"), x.optString("c"), x.optString("X"), x.optString("x"), x.optString("S"), x.optString("ap").toDoubleOrNull() ?: 0.0, x.optString("l").toDoubleOrNull() ?: 0.0, x.optString("z").toDoubleOrNull() ?: 0.0, x.optString("L").toDoubleOrNull() ?: 0.0, x.optString("rp").toDoubleOrNull() ?: 0.0, x.optString("n").toDoubleOrNull() ?: 0.0, eventTime))
            }
            "ACCOUNT_UPDATE" -> {
                val a = o.optJSONObject("a") ?: return
                val balances = buildMap { val b = a.optJSONArray("B") ?: return@buildMap; for (i in 0 until b.length()) { val x = b.optJSONObject(i) ?: continue; put(x.optString("a"), x.optString("wb").toDoubleOrNull() ?: 0.0) } }
                val positions = buildList { val p = a.optJSONArray("P") ?: return@buildList; for (i in 0 until p.length()) { val x = p.optJSONObject(i) ?: continue; add(Position(x.optString("s"), x.optString("pa").toDoubleOrNull() ?: 0.0, x.optString("ep").toDoubleOrNull() ?: 0.0, x.optString("bep").toDoubleOrNull() ?: 0.0, x.optString("up").toDoubleOrNull() ?: 0.0, x.optString("mt"), x.optString("ps"))) } }
                listener.onAccountUpdate(AccountUpdate(balances, positions, a.optString("m"), eventTime))
            }
        }
    }
}
