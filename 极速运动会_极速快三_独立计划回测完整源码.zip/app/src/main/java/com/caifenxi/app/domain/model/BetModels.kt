package com.caifenxi.app.domain.model

/**
 * 模拟下注相关模型。
 */

/** 下注来源类型 */
enum class BetSourceType(val id: String, val label: String) {
    COCKPIT("cockpit", "驾驶舱"),
    ALGO("algo", "算法"),
    PLAN("plan", "指定计划"),
    NOVA("nova", "新计划"),
    AUTO_BEST("auto_best", "竞技场最优"),
    CONSENSUS("consensus", "共识"),
    /** 新计划页独立共识（与计划引擎共识数据分离） */
    NOVA_CONSENSUS("nova_consensus", "新计划共识");

    companion object {
        fun fromId(id: String): BetSourceType = entries.find { it.id == id } ?: ALGO
    }
}

/** 下注分类 */
enum class BetCategory(val id: String, val label: String) {
    DX("大小", "大小"),
    DS("单双", "单双"),
    COMBO("组合", "组合"),
    NUMBER("数字", "数字"),
    POSITION_DX("定位大小", "定位大小"),
    POSITION_DS("定位单双", "定位单双"),
    DRAGON_TIGER("龙虎", "龙虎"),
    K3_SANJUN("三军", "三军"),
    K3_SUM_DX("和值大小", "和值大小"),
    K3_FISH_SHRIMP_CRAB("鱼虾蟹", "鱼虾蟹"),
    K3_LONGPAIR("长牌", "长牌");

    companion object {
        fun fromId(id: String): BetCategory? = entries.find { it.id == id }
    }
}

/**
 * 赔率配置。
 * 组合:按覆盖条数计算；1/2/3 条均按 4.0 倍，4 条全覆盖无有效收益(1.0)。
 */
object BetOdds {
    /** 兼容旧逻辑的中间值 */
    const val DX = 1.98
    const val DS = 1.98
    const val COMBO = 3.9
    const val NUMBER = 9.5

    /** 仅极速飞艇(10035)/极速赛车(10037)使用特殊冠亚和赔率。其他彩种大小单双统一 1.98。 */
    const val DX_DA = 2.2
    const val DX_XIAO = 1.79
    const val DS_DAN = 1.79
    const val DS_SHUANG = 2.2

    private fun isSpecialDxDsLottery(lotteryKey: String?): Boolean =
        lotteryKey == "10035" || lotteryKey == "10037"

    fun of(category: BetCategory): Double = when (category) {
        BetCategory.DX -> DX
        BetCategory.DS -> DS
        BetCategory.COMBO -> COMBO
        BetCategory.NUMBER -> NUMBER
        BetCategory.POSITION_DX, BetCategory.POSITION_DS, BetCategory.DRAGON_TIGER, BetCategory.K3_SUM_DX -> 1.98
        BetCategory.K3_SANJUN, BetCategory.K3_FISH_SHRIMP_CRAB -> 1.99
        BetCategory.K3_LONGPAIR -> 6.0
    }

    fun dxOdds(value: String, lotteryKey: String? = null): Double =
        if (isSpecialDxDsLottery(lotteryKey)) {
            when (value.trim()) {
                "大" -> DX_DA
                "小" -> DX_XIAO
                else -> DX
            }
        } else DX

    fun dsOdds(value: String, lotteryKey: String? = null): Double =
        if (isSpecialDxDsLottery(lotteryKey)) {
            when (value.trim()) {
                "单" -> DS_DAN
                "双" -> DS_SHUANG
                else -> DS
            }
        } else DS

    /** 组合覆盖 1/2/3 个方向时图表回测统一按 4 倍赔率计算；4 个全覆盖时无有效收益。 */
    fun comboOdds(coverCount: Int): Double = when {
        coverCount in 1..3 -> 4.0
        else -> 1.0
    }

    /** 图表/挂机：按玩法、预测文案和当前彩种解析赔率。 */
    fun forPlay(playType: String, prediction: String, lotteryKey: String? = null): Double {
        val raw = prediction.removePrefix("反:").trim()
        // 共识点可能带「组合:大单」前缀
        val cleaned = raw.substringAfter(":").takeIf { ":" in raw } ?: raw
        val parts = cleaned.split("/", "、", ",").map { it.trim() }.filter { it.isNotEmpty() }
        return when (playType) {
            "大小" -> dxOdds(parts.firstOrNull() ?: "", lotteryKey)
            "单双" -> dsOdds(parts.firstOrNull() ?: "", lotteryKey)
            "组合" -> comboOdds(parts.count { it in listOf("大单", "大双", "小单", "小双") }.coerceAtLeast(parts.size.coerceAtLeast(1)))
            "数字", "位置" -> NUMBER
            "定位大小", "定位单双", "龙虎", "和值大小" -> 1.98
            "三军", "鱼虾蟹" -> 1.99
            "长牌" -> 6.0
            else -> 1.98
        }
    }
}

/** PKS 位置名 */
object PksPositions {
    val NAMES = listOf("冠军", "亚军") + (3..10).map { "第${it}" }

    fun nameAt(index: Int): String = NAMES.getOrElse(index) { "第${index + 1}" }
}

/**
 * 挂机策略(UI 层使用,与 BotConfigEntity 对应)。
 */
data class BotConfig(
    val enabled: Boolean = false,
    val sourceType: String = "algo",
    val sourceId: String = "experience",
    /** 大小/单双/组合可分别指定不同计划（挂机）；空则回退 sourceId */
    val sourceIdDx: String = "",
    val sourceIdDs: String = "",
    val sourceIdCombo: String = "",
    val categories: Set<String> = setOf("大小", "单双"),
    val numberPosition: Int = 0,
    val amount: Double = 10.0,
    // 倍投配置(1.0 = 关闭)
    val winMult: Double = 1.0,
    val lossMult: Double = 1.0,
    val winMultPeriods: Int = 1,
    val lossMultPeriods: Int = 1,
    val maxMult: Int = 1,
    /** forward=正投 / reverse=反投（数字不取反） */
    val betMode: String = "forward",
    /**
     * 滚动预测：开启后指定计划/新计划不用引擎缓存结果，
     * 而用与图表相同的 NovaPlanAnalytics.predict 在最新历史上现算。
     */
    val rollingPredict: Boolean = false,
    /** 滚动口径：1=一期 2=二期 3=三期（与图表一致；二/三期挂机金额按轮内倍投由 lossMult 配合） */
    val rollingStage: Int = 1,
    val specialPlayCounts: Map<String, Int> = emptyMap()
)

/**
 * 挂机收益与对错统计。
 */
data class BetStats(
    // 收益
    val initialBalance: Double = 10000.0,
    val balance: Double = 10000.0,
    val totalProfit: Double = 0.0,
    val totalBet: Double = 0.0,
    val profitRate: Double = 0.0,          // 累计盈亏 / 初始资金
    // 胜率
    val totalSettled: Int = 0,
    val winCount: Int = 0,
    val loseCount: Int = 0,
    val winRate: Double = 0.0,
    // 本期
    val currentBetAmount: Double = 0.0,    // 本期下注总本金
    val currentProfit: Double = 0.0,       // 本期结算净盈亏
    // 按分类对错
    val byCategory: Map<String, CatBetStats> = emptyMap(),
    // 收益曲线(时序,按结算先后)
    val profitCurve: List<ProfitPoint> = emptyList(),
    // 最大回撤
    val maxDrawdown: Double = 0.0,         // 最大回撤金额(从峰值到谷底)
    val maxDrawdownPct: Double = 0.0,      // 最大回撤百分比
    val peakProfit: Double = 0.0,          // 累计收益峰值
    // 最长连对/连错区间(曲线上标注用)
    val maxHitStreak: Int = 0,             // 最长连对次数
    val maxMissStreak: Int = 0             // 最长连错次数
) {
    val effectiveBalance: Double get() = balance + currentProfit - currentBetAmount
}

data class CatBetStats(
    val catName: String,
    val settled: Int = 0,
    val hit: Int = 0,
    val miss: Int = 0,
    val winRate: Double = 0.0,
    /** 该分类累计盈亏(已结算) */
    val profit: Double = 0.0,
    val recentStreak: Int = 0,              // 正=连对,负=连错
    val maxHitStreak: Int = 0,
    val maxMissStreak: Int = 0,
    /** 两期滚动窗口:窗口内至少 1 次中 = 两期对(按注口径,与 hit/miss 一致) */
    val twoWindows: Int = 0,
    val twoHitRate: Double = 0.0,
    val twoMissRate: Double = 0.0,
    /** 三期滚动窗口:窗口内至少 1 次中 = 三期对 */
    val threeWindows: Int = 0,
    val threeHitRate: Double = 0.0,
    val threeMissRate: Double = 0.0
) {
    val hitRateStr: String
        get() = if (settled == 0) "-" else "%.1f%%".format(winRate * 100)
}

/**
 * 收益曲线数据点(每期结算后一个点)。
 */
data class ProfitPoint(
    val issueIndex: Int,          // 时序索引(0 开始)
    val issue: String,            // 期号
    val cumulativeProfit: Double, // 累计收益
    val hit: Boolean,             // 该期是否命中
    val drawdown: Double,         // 从历史峰值回撤金额
    val drawdownPct: Double       // 回撤百分比
)

/**
 * 钱包视图。
 */
data class WalletView(
    val initialBalance: Double = 10000.0,
    val balance: Double = 10000.0,
    val totalProfit: Double = 0.0,
    val totalBet: Double = 0.0,
    val winCount: Int = 0,
    val loseCount: Int = 0
)

/**
 * 下注订单视图(UI 层使用,与 BetEntity 对应)。
 */
data class BetView(
    val id: Long,
    val issue: String,
    val sourceLabel: String,
    val category: String,
    val betValue: String,
    val amount: Double,
    val odds: Double,
    val status: String,
    val profit: Double,
    val createdAt: Long,
    val settledAt: Long? = null
)
