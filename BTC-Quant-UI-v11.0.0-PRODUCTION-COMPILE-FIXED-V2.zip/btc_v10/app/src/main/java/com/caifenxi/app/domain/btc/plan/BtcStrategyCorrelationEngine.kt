package com.caifenxi.app.domain.btc.plan

import com.caifenxi.app.domain.btc.BtcPlanSignal
import kotlin.math.abs

/**
 * Lightweight signal-correlation guard. It uses recent directional contribution
 * vectors when available and falls back to strategy-family grouping otherwise.
 */
object BtcStrategyCorrelationEngine {
    data class PairScore(val left: String, val right: String, val correlation: Double)

    fun pairScores(history: Map<String, List<Double>>): List<PairScore> {
        val ids = history.keys.toList()
        val out = mutableListOf<PairScore>()
        for (i in 0 until ids.size) for (j in i + 1 until ids.size) {
            val a = history[ids[i]].orEmpty()
            val b = history[ids[j]].orEmpty()
            val n = minOf(a.size, b.size)
            if (n < 8) continue
            out += PairScore(ids[i], ids[j], pearson(a.takeLast(n), b.takeLast(n)))
        }
        return out.sortedByDescending { abs(it.correlation) }
    }

    fun diversify(signals: List<BtcPlanSignal>, threshold: Double = 0.82): List<BtcPlanSignal> {
        if (signals.size < 2) return signals
        val kept = mutableListOf<BtcPlanSignal>()
        signals.sortedByDescending { abs(it.contribution) }.forEach { candidate ->
            val familyDuplicate = kept.any { it.family == candidate.family && it.direction == candidate.direction }
            val penalty = if (familyDuplicate) (0.78 - ((threshold - 0.82).coerceIn(-0.1, 0.1) * 0.1)) else 1.0
            kept += candidate.copy(
                weight = (candidate.weight * penalty).coerceIn(0.15, 2.5),
                contribution = candidate.contribution * penalty
            )
        }
        // `threshold` is retained for future history-vector correlation; family fallback is deterministic.
        return kept.sortedByDescending { abs(it.contribution) }
    }

    private fun pearson(a: List<Double>, b: List<Double>): Double {
        val n = minOf(a.size, b.size)
        if (n < 2) return 0.0
        val am = a.takeLast(n).average()
        val bm = b.takeLast(n).average()
        var num = 0.0; var da = 0.0; var db = 0.0
        for (i in 0 until n) {
            val x = a[i] - am; val y = b[i] - bm
            num += x * y; da += x * x; db += y * y
        }
        return if (da == 0.0 || db == 0.0) 0.0 else (num / kotlin.math.sqrt(da * db)).coerceIn(-1.0, 1.0)
    }
}
