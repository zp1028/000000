package com.caifenxi.app.data.db.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * 挂机策略配置(每彩种一条)。
 */
@Entity(tableName = "bot_config")
data class BotConfigEntity(
    @PrimaryKey val lotteryKey: String,
    val enabled: Boolean = false,          // 挂机开关
    val sourceType: String = "algo",       // algo / plan / consensus
    val sourceId: String = "experience",   // 算法 id / 计划 id / "consensus"
    val categories: String = "大小,单双",   // 逗号分隔:大小,单双,组合,数字
    val numberPosition: Int = 0,           // 数字下注位置(0=冠军 ... 9=第10)
    val amount: Double = 10.0,             // 单注金额
    val winMult: Double = 1.0,              // 命中后倍数(1.0=关闭)
    val lossMult: Double = 1.0,             // 未中后倍数(1.0=关闭)
    val maxMult: Int = 1,                   // 最大倍数
    val updatedAt: Long = System.currentTimeMillis()
)
