package com.caifenxi.app.ui

import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.caifenxi.app.CaiFenXiApplication
import com.caifenxi.app.domain.engine.AnalysisEngine
import com.caifenxi.app.domain.engine.ConsensusEngine
import com.caifenxi.app.domain.engine.PredictEngine
import com.caifenxi.app.domain.model.ConsensusRecord
import com.caifenxi.app.domain.model.ConsensusStats
import com.caifenxi.app.domain.model.CustomPlan
import com.caifenxi.app.domain.model.DrawRecord
import com.caifenxi.app.domain.model.LabRow
import com.caifenxi.app.domain.model.ModelConsensus
import com.caifenxi.app.domain.model.PlanDefinition
import com.caifenxi.app.domain.model.PlanPredictionRecord
import com.caifenxi.app.domain.model.PlanRuntime
import com.caifenxi.app.domain.model.PlanTrendPoint
import com.caifenxi.app.domain.model.UserPrefs
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * 计划大厅 ViewModel。
 * 从 MainViewModel 拆出:负责计划池/回测/共识/自定义计划与实验室排行。
 * 与 MainViewModel 共享 Application 级 planEngine(同一份战绩状态)。
 */
class PlanViewModel : ViewModel() {

    private val app get() = CaiFenXiApplication.instance
    private val engine get() = app.planEngine
    private val consensusStore get() = app.consensusStore

    val planRows = mutableStateOf<List<Pair<PlanDefinition, PlanRuntime>>>(emptyList())
    val backtestRunning = mutableStateOf(false)
    val labRows = mutableStateOf<List<LabRow>>(emptyList())
    val planHistory = mutableStateOf<List<PlanPredictionRecord>>(emptyList())
    /** 当前目标期的未结算预测(按目标期全量过滤,不受 historyPreds 截断影响) */
    val currentPredictions = mutableStateOf<List<PlanPredictionRecord>>(emptyList())
    val selectedPlanHistory = mutableStateOf<List<PlanPredictionRecord>>(emptyList())
    val consensus = mutableStateOf<List<ModelConsensus>>(emptyList())
    /** 计划/共识统一目标期(与首页下期、挂机下注目标一致) */
    val planTargetIssue = mutableStateOf("-")
    val consensusRecords = mutableStateOf<List<ConsensusRecord>>(emptyList())
    val consensusStats = mutableStateOf(ConsensusStats())
    val customPlans = mutableStateOf<List<CustomPlan>>(emptyList())
    val planTrends = mutableStateOf<Map<String, List<PlanTrendPoint>>>(emptyMap())

    /** 异步增量回测任务:新任务开始前取消旧任务,避免回测堆积占用 CPU */
    private var backtestJob: Job? = null

    /** 手动回测:清零战绩后全量滚动验证,并生成本期计划与共识 */
    fun runBacktest(
        rows: List<DrawRecord>,
        prefs: UserPrefs,
        lotteryKey: String,
        onStatus: (String) -> Unit,
        onError: (String?) -> Unit,
        requestedPeriods: Int? = 500
    ) {
        viewModelScope.launch {
            if (rows.size < 40) {
                onError("历史不足,至少约 40 期再回测")
                return@launch
            }
            // 手动回测接管:取消正在跑的异步回测,避免状态互相覆盖
            backtestJob?.cancel()
            backtestRunning.value = true
            onStatus("回测中...")
            try {
                withContext(Dispatchers.Default) {
                    // 手动「重新滚动验证」:先清零旧战绩,再全量回测一次,
                    // 保证各计划样本数与历史预测不重复累加
                    engine.clearCareer()
                    engine.backtest(rows, prefs, minWarm = 30, forceFull = true, requestedPeriods = requestedPeriods, cancellationCheck = { !isActive })
                }
                val latest = rows.maxByOrNull { it.issue.toLongOrNull() ?: Long.MIN_VALUE } ?: rows.last()
                val cutoff = latest.issue
                val target = latest.nextIssue?.takeIf {
                    it.isNotBlank() && it != cutoff &&
                        (it.toLongOrNull() ?: 0L) > (cutoff.toLongOrNull() ?: 0L)
                } ?: PredictEngine.suggestNextIssue(cutoff)
                // 固定计划池预测 + 共识(combo 条数与设置同步)
                val preds = withContext(Dispatchers.Default) {
                    engine.activatePlansForIssue(target, prefs, force = true)
                    engine.predictForNext(rows, prefs, target, cutoff)
                }
                planRows.value = engine.getRuntimes()
                planHistory.value = engine.getAllRecentPredictions(5000)
                currentPredictions.value = engine.getCurrentPredictions(target)
                planTargetIssue.value = target
                consensus.value = engine.consensus(
                    lotteryKey, target, preds, comboTopN = prefs.comboPredCount.coerceIn(1, 4)
                )
                ConsensusEngine.recordPending(consensusStore, lotteryKey, target, consensus.value)
                refreshConsensusStats(lotteryKey)
                labRows.value = withContext(Dispatchers.Default) {
                    AnalysisEngine.labTable(rows, prefs)
                }
                onStatus("计划池 ${planRows.value.size} 条 · 回测完成")
            } catch (e: CancellationException) {
                onError("回测已取消")
            } catch (e: Exception) {
                onError(e.message)
            } finally {
                backtestRunning.value = false
            }
        }
    }

    /**
     * 由 MainViewModel 数据管线在预测完成后调用:同步计划/共识状态。
     * 主链路只做「轻量预测 + 共识」(不阻塞),增量回测放到后台异步执行,
     * 完成后自动刷新计划战绩与共识 —— 修复原实现回测卡死主链路导致
     * 共识丢失、计划页卡死、挂机无法下注的问题。
     * @return (共识列表, 计划运行态, 最近预测)
     */
    suspend fun syncAfterPredict(
        rows: List<DrawRecord>,
        prefs: UserPrefs,
        target: String,
        cutoff: String,
        lotteryKey: String
    ): Triple<List<ModelConsensus>, List<Pair<PlanDefinition, PlanRuntime>>, List<PlanPredictionRecord>> {
        val result = withContext(Dispatchers.Default) {
            engine.activatePlansForIssue(target, prefs, force = true)
            val preds = engine.predictForNext(rows, prefs, target, cutoff)
            val cons = engine.consensus(
                lotteryKey, target, preds, comboTopN = prefs.comboPredCount.coerceIn(1, 4)
            )
            val runtimes = engine.getRuntimes()
            val recent = engine.getAllRecentPredictions(5000)
            Triple(cons, runtimes, recent)
        }
        val (cons, runtimes, recent) = result
        planTargetIssue.value = target
        consensus.value = cons
        ConsensusEngine.recordPending(consensusStore, lotteryKey, target, cons)
        planRows.value = runtimes
        planHistory.value = recent
        planTrends.value = engine.getAllTrends(60)
        currentPredictions.value = engine.getCurrentPredictions(target)
        refreshConsensusStats(lotteryKey)
        // 异步增量回测:不阻塞主链路,完成后用最新战绩刷新计划/共识
        startIncrementalBacktest(rows, prefs, target, cutoff, lotteryKey)
        return result
    }

    /**
     * Nova 页面专用同步：强制使用 NovaPlanPool，不读取原计划池作为预测来源。
     * 共识只在 Nova 预测集合上计算，且仅回写 Nova 页面内存态，避免覆盖原计划页共识。
     */
    suspend fun syncNovaAfterPredict(
        rows: List<DrawRecord>,
        prefs: UserPrefs,
        target: String,
        cutoff: String,
        lotteryKey: String
    ) {
        if (rows.isEmpty()) return
        val novaIds = (NovaPlanPool.ALL + customPlans.value.map { it.toDefinition() })
            .filter { it.planId.startsWith("NOVA-") || it.planId.startsWith("NOVA-CUSTOM-") }
            .map { it.planId }
            .distinct()
        if (novaIds.isEmpty()) return
        val novaPrefs = prefs.copy(
            selectedPlanIds = novaIds,
            cockpitPlanId = ""
        )
        withContext(Dispatchers.Default) {
            engine.activatePlansForIssue(target, novaPrefs, force = true)
            engine.predictForNext(rows, novaPrefs, target, cutoff)
        }
        val novaPreds = withContext(Dispatchers.Default) { engine.getNovaCurrentPredictions(target) }
        val novaCons = withContext(Dispatchers.Default) {
            engine.consensus(
                lotteryKey, target, novaPreds,
                comboTopN = prefs.comboPredCount.coerceIn(1, 4)
            )
        }
        planTargetIssue.value = target
        currentPredictions.value = novaPreds
        planHistory.value = engine.getNovaRecentPredictions(5000)
        planRows.value = engine.getRuntimes().filter { it.first.planId.startsWith("NOVA-") || it.first.planId.startsWith("NOVA-CUSTOM-") }
        planTrends.value = engine.getAllTrends(60).filterKeys { it.startsWith("NOVA-") || it.startsWith("NOVA-CUSTOM-") }
        consensus.value = novaCons
    }

    /**
     * 从持久化待开共识恢复内存态(供挂机在 UI 未刷新时仍能取到方向)。
     */
    suspend fun loadPendingConsensusAsModels(lotteryKey: String, targetIssue: String): List<ModelConsensus> {
        val pending = consensusStore.loadAll(lotteryKey)
            .filter { it.targetIssue == targetIssue && it.result == "待开" }
        return pending.map { r ->
            ModelConsensus(
                lotteryKey = r.lotteryKey,
                targetIssue = r.targetIssue,
                category = r.category,
                leadingDirection = r.leadingDirection.ifBlank {
                    r.candidates.joinToString("/")
                },
                supportRatio = r.supportRatio,
                disagreement = 0.0,
                participatingPlans = r.participatingPlans,
                detail = emptyMap()
            )
        }
    }

    /** 后台增量回测:每期检查协程取消;完成后重算本期计划/共识与战绩 */
    private fun startIncrementalBacktest(
        rows: List<DrawRecord>,
        prefs: UserPrefs,
        target: String,
        cutoff: String,
        lotteryKey: String
    ) {
        backtestJob?.cancel()
        backtestJob = viewModelScope.launch {
            try {
                withContext(Dispatchers.Default) {
                    // 增量回测限时 8s:避免单次持锁过久阻塞心跳的在线预测/共识,
                    // 超时已保存进度(backtest 内部推进 lastBacktestIssue),剩余期数下次续跑
                    if (rows.size >= 40) engine.backtest(rows, prefs, minWarm = 30, timeLimitMs = 8_000) { !isActive }
                }
                val (cons, runtimes, recent) = withContext(Dispatchers.Default) {
                    val preds = engine.predictForNext(rows, prefs, target, cutoff)
                    Triple(
                        engine.consensus(
                            lotteryKey, target, preds,
                            comboTopN = prefs.comboPredCount.coerceIn(1, 4)
                        ),
                        engine.getRuntimes(),
                        engine.getAllRecentPredictions(5000)
                    )
                }
                consensus.value = cons
                ConsensusEngine.recordPending(consensusStore, lotteryKey, target, cons)
                planRows.value = runtimes
                planHistory.value = recent
                planTrends.value = engine.getAllTrends(60)
                currentPredictions.value = engine.getCurrentPredictions(target)
                refreshConsensusStats(lotteryKey)
            } catch (e: CancellationException) {
                // 被新任务接管或 ViewModel 销毁:静默
            } catch (e: Exception) {
                // 后台回测失败不影响主链路
            }
        }
    }

    /** 新开奖结算后刷新内存态(由 MainViewModel 调用) */
    fun refreshRuntimeState() {
        planRows.value = engine.getRuntimes()
        planHistory.value = engine.getAllRecentPredictions(5000)
        planTrends.value = engine.getAllTrends(60)
    }

    suspend fun refreshConsensusStats(lotteryKey: String) {
        consensusRecords.value = consensusStore.loadAll(lotteryKey).sortedByDescending { it.createdAt }
        consensusStats.value = consensusStore.stats(lotteryKey)
    }

    fun clearConsensusStats(lotteryKey: String) {
        viewModelScope.launch {
            try {
                consensusStore.clear(lotteryKey)
                refreshConsensusStats(lotteryKey)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // 清空/统计失败不影响主流程
            }
        }
    }

    fun runtimeForPlan(planId: String): PlanRuntime = engine.getRuntime(planId)

    fun loadPlanDetail(planId: String) {
        // 后台线程读取(回测持锁期间避免阻塞主线程)
        viewModelScope.launch(Dispatchers.Default) {
            try {
                selectedPlanHistory.value = engine.getPredictionHistory(planId, 40)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // 读取失败保持原状态
            }
        }
    }

    // ---- 自定义计划 ----

    /** 从 Room 加载当前彩种的自定义计划并注入 PlanEngine */
    fun loadCustomPlans(lotteryKey: String) {
        viewModelScope.launch {
            try {
                val key = lotteryKey
                val entities = app.customPlanDao.getByLottery(key)
                val plans = entities.map { it.toDomain() }
                customPlans.value = plans
                engine.setCustomPlans(
                    plans.filter { it.enabled }.map { it.toDefinition() }
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // 加载失败不影响主流程
            }
        }
    }

    /** 保存(新增或更新)自定义计划 */
    fun saveCustomPlan(plan: CustomPlan, onStatus: (String) -> Unit = {}) {
        viewModelScope.launch {
            try {
                app.customPlanDao.upsert(com.caifenxi.app.data.db.entity.CustomPlanEntity.fromDomain(plan))
                loadCustomPlans(plan.lotteryKey)
                onStatus("已保存计划「${plan.planName}」")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                onStatus("保存失败:${e.message}")
            }
        }
    }

    /** 删除自定义计划 */
    fun deleteCustomPlan(planId: String, lotteryKey: String, onStatus: (String) -> Unit = {}) {
        viewModelScope.launch {
            try {
                app.customPlanDao.deleteById(planId)
                loadCustomPlans(lotteryKey)
                onStatus("已删除计划")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                onStatus("删除失败:${e.message}")
            }
        }
    }

    /** 启用/停用自定义计划 */
    fun toggleCustomPlan(plan: CustomPlan, enabled: Boolean) {
        viewModelScope.launch {
            try {
                app.customPlanDao.upsert(
                    com.caifenxi.app.data.db.entity.CustomPlanEntity.fromDomain(
                        plan.copy(enabled = enabled, updatedAt = System.currentTimeMillis())
                    )
                )
                loadCustomPlans(plan.lotteryKey)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // 切换失败不影响主流程
            }
        }
    }
}
