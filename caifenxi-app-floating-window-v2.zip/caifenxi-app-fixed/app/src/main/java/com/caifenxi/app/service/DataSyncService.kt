package com.caifenxi.app.service

import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.ServiceCompat
import com.caifenxi.app.CaiFenXiApplication
import com.caifenxi.app.domain.engine.ConsensusEngine
import com.caifenxi.app.domain.engine.PredictEngine
import com.caifenxi.app.domain.engine.StatsEngine
import com.caifenxi.app.domain.model.AlgoMode
import com.caifenxi.app.domain.model.LotteryConfig
import com.caifenxi.app.domain.model.PredictionSnapshot
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.withContext

/**
 * 前台服务：后台保活拉最新开奖。
 * 新期会落库、结算,生成下一期计划/共识,并尝试挂机自动下注。
 */
class DataSyncService : Service() {

    companion object {
        const val ACTION_REFRESH_OVERLAY = "com.caifenxi.app.REFRESH_OVERLAY"
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null
    private var lastIssue: String? = null
    private var failStreak = 0
    private var overlay: FloatingOverlayController? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = NotificationHelper.buildForeground(this, "正在监听开奖…")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ServiceCompat.startForeground(
                this, 1001, notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
            )
        } else {
            startForeground(1001, notification)
        }
        job?.cancel()
        overlay = FloatingOverlayController(this)
        try { overlay?.refresh(CaiFenXiApplication.instance.configStore.loadPrefs()) } catch (_: Exception) {}
        job = scope.launch {
            val app = CaiFenXiApplication.instance
            while (isActive) {
                try {
                    val prefs = app.configStore.loadPrefs()
                    val key = prefs.selectedLotteryKey
                    val cfg = LotteryConfig.findByKey(key) ?: LotteryConfig.CATALOG.first()
                    withTimeout(25_000) {
                        val latest = app.apiClient.fetchLatest(cfg)
                        if (latest != null && latest.issue != lastIssue) {
                            app.drawRepository.cacheDraw(latest)
                            StatsEngine.settleWithDraw(app.statStore, key, latest)
                            ConsensusEngine.settleWithDraw(app.consensusStore, key, latest)
                            app.planEngine.settlePendingWithDraw(latest, prefs.backtestParams)
                            app.betEngine.settleWithDraw(key, latest)

                            val history = app.drawRepository.getWorkingHistory(key)
                            if (history.isNotEmpty()) {
                                val latestRow = history.maxByOrNull {
                                    it.issue.toLongOrNull() ?: Long.MIN_VALUE
                                } ?: history.last()
                                val cutoff = latestRow.issue
                                val apiNext = latestRow.nextIssue?.takeIf { n ->
                                    n.isNotBlank() && n != cutoff &&
                                        (n.toLongOrNull() ?: 0L) > (cutoff.toLongOrNull() ?: 0L)
                                }
                                val target = apiNext ?: PredictEngine.suggestNextIssue(cutoff)
                                // 先把“新期已到、预测尚未就绪”明确发布给悬浮窗。
                                // 这样开奖同步可以立即响应，但绝不会把上一期预测冒充成新期预测。
                                publishFloatingSnapshot(
                                    context = this@DataSyncService,
                                    lotteryName = cfg.name,
                                    lotteryKey = key,
                                    latestIssue = latest.issue,
                                    latestDrawTime = latest.drawTime,
                                    latestDx = latest.dx,
                                    latestDs = latest.ds,
                                    targetIssue = target,
                                    consensus = emptyList(),
                                    predictions = emptyList(),
                                    status = "CALCULATING"
                                )
                                overlay?.refresh(prefs)

                                val preds = app.planEngine.predictForNext(history, prefs, target, cutoff)
                                val cons = if (preds.isNotEmpty()) {
                                    app.planEngine.consensus(key, target, preds)
                                } else {
                                    emptyList()
                                }
                                if (cons.isNotEmpty()) {
                                    ConsensusEngine.recordPending(app.consensusStore, key, target, cons)
                                }

                                // 算法来源也必须在“最终快照”里准备好，不能先显示旧算法结果。
                                val botCfg = app.database.betDao().getBotConfig(key)
                                val needAlgoPrediction = prefs.floatingSource == "algo" ||
                                    botCfg == null || botCfg.sourceType == "algo"
                                val prediction: PredictionSnapshot? = try {
                                    if (needAlgoPrediction) {
                                        val modeId = if (prefs.floatingSource == "algo") {
                                            prefs.currentAlgo
                                        } else {
                                            botCfg?.sourceId ?: prefs.currentAlgo
                                        }
                                        val mode = AlgoMode.fromId(modeId)
                                        PredictEngine.predict(
                                            history, cfg.type, prefs, target, cutoff, mode
                                        )
                                    } else null
                                } catch (_: Exception) {
                                    null
                                }

                                publishFloatingSnapshot(
                                    context = this@DataSyncService,
                                    lotteryName = cfg.name,
                                    lotteryKey = key,
                                    latestIssue = latest.issue,
                                    latestDrawTime = latest.drawTime,
                                    latestDx = latest.dx,
                                    latestDs = latest.ds,
                                    targetIssue = target,
                                    consensus = cons,
                                    predictions = preds,
                                    algoDx = prediction?.dx?.direction,
                                    algoDs = prediction?.ds?.direction,
                                    status = "READY"
                                )
                                overlay?.refresh(prefs)

                                app.betEngine.placeAutoBets(
                                    lotteryKey = key,
                                    targetIssue = target,
                                    prediction = prediction,
                                    planPredictions = preds,
                                    consensus = cons
                                )
                            }

                            if (lastIssue != null) {
                                val summary = listOfNotNull(latest.dx, latest.ds, latest.combo)
                                    .joinToString(" ") + " " + latest.numbers.take(5).joinToString(",")
                                NotificationHelper.notifyNewDraw(
                                    this@DataSyncService,
                                    latest.issue,
                                    summary
                                )
                            }
                            lastIssue = latest.issue
                            failStreak = 0
                        }
                    }
                } catch (_: Exception) {
                    failStreak++
                }
                val wait = when {
                    failStreak >= 5 -> 90_000L
                    failStreak >= 2 -> 50_000L
                    else -> 40_000L
                }
                try {
                    val latestPrefs = app.configStore.loadPrefs()
                    withContext(Dispatchers.Main.immediate) { overlay?.refresh(latestPrefs) }
                } catch (_: Exception) {}
                delay(wait)
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        job?.cancel()
        overlay?.hide()
        overlay = null
        super.onDestroy()
    }
}
