package com.caifenxi.app.data.db.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.caifenxi.app.data.db.entity.HsFeedbackEntity
import com.caifenxi.app.data.db.entity.HsShadowClosedEntity
import com.caifenxi.app.data.db.entity.HsShadowOpenEntity

@Dao
interface HsFeedbackDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(row: HsFeedbackEntity): Long

    @Query("SELECT * FROM hs_feedback WHERE timeframe = :tf ORDER BY at DESC LIMIT :limit")
    fun recent(tf: String, limit: Int): List<HsFeedbackEntity>

    @Query("SELECT COUNT(*) FROM hs_feedback WHERE timeframe = :tf")
    fun count(tf: String): Int

    @Query("DELETE FROM hs_feedback WHERE id NOT IN (SELECT id FROM hs_feedback ORDER BY at DESC LIMIT :keep)")
    fun trim(keep: Int)
}

@Dao
interface HsShadowDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun upsertOpen(row: HsShadowOpenEntity)

    @Query("SELECT * FROM hs_shadow_open")
    fun allOpen(): List<HsShadowOpenEntity>

    @Query("SELECT * FROM hs_shadow_open WHERE id = :id LIMIT 1")
    fun getOpen(id: String): HsShadowOpenEntity?

    @Query("DELETE FROM hs_shadow_open WHERE id = :id")
    fun deleteOpen(id: String)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertClosed(row: HsShadowClosedEntity)

    @Query("SELECT * FROM hs_shadow_closed ORDER BY closedAt DESC LIMIT :limit")
    fun recentClosed(limit: Int): List<HsShadowClosedEntity>

    @Query("SELECT * FROM hs_shadow_closed WHERE (:tf IS NULL OR timeframe = :tf) ORDER BY closedAt DESC LIMIT :limit")
    fun recentClosedTf(tf: String?, limit: Int): List<HsShadowClosedEntity>

    @Query("DELETE FROM hs_shadow_closed WHERE id NOT IN (SELECT id FROM hs_shadow_closed ORDER BY closedAt DESC LIMIT :keep)")
    fun trimClosed(keep: Int)

    @Query("DELETE FROM hs_shadow_open WHERE id NOT IN (SELECT id FROM hs_shadow_open LIMIT :keep)")
    fun trimOpen(keep: Int)
}
