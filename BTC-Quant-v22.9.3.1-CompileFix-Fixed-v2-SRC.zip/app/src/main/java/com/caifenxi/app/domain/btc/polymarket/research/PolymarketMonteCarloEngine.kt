package com.caifenxi.app.domain.btc.polymarket.research

import kotlin.math.sqrt
import kotlin.random.Random

/** Bootstrap/Monte-Carlo robustness check over OOS trade returns. */
object PolymarketMonteCarloEngine {
    data class Report(val paths: Int, val tradesPerPath: Int, val medianReturn: Double, val p05Return: Double, val p95Return: Double, val medianMaxDrawdown: Double, val p95MaxDrawdown: Double, val ruinProbability: Double)

    fun bootstrap(returns: List<Double>, paths: Int = 1000, seed: Int = 42): Report {
        if (returns.isEmpty()) return Report(0,0,0.0,0.0,0.0,0.0,0.0,0.0)
        val rng = Random(seed); val finalReturns = DoubleArray(paths); val dds = DoubleArray(paths); var ruin = 0
        repeat(paths) { p ->
            var equity = 1.0; var peak = 1.0; var dd = 0.0
            repeat(returns.size) {
                val r = returns[rng.nextInt(returns.size)]
                equity *= (1.0+r).coerceAtLeast(0.001); peak = maxOf(peak,equity); dd = maxOf(dd,1.0-equity/peak)
            }
            finalReturns[p] = equity-1.0; dds[p] = dd; if (equity < 0.5) ruin++
        }
        finalReturns.sort(); dds.sort()
        fun q(a: DoubleArray, x: Double): Double = a[((a.size-1)*x).toInt().coerceIn(0,a.lastIndex)]
        return Report(paths, returns.size, q(finalReturns,.50), q(finalReturns,.05), q(finalReturns,.95), q(dds,.50), q(dds,.95), ruin.toDouble()/paths)
    }
}
