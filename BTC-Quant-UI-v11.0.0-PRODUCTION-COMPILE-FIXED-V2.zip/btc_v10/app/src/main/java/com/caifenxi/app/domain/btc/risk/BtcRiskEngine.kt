package com.caifenxi.app.domain.btc.risk

import com.caifenxi.app.domain.btc.BtcDirection
import com.caifenxi.app.domain.btc.BtcConsensus

 data class BtcRiskLimits(
    val maxDailyLossPct: Double = 2.0,
    val maxDrawdownPct: Double = 8.0,
    val maxPerpNotionalPct: Double = 25.0,
    val maxSameViewExposurePct: Double = 35.0,
    val maxLeverage: Int = 3,
    val minConfidence: Double = 0.60,
    val killSwitch: Boolean = false,
    // === 合约专用参数 ===
    val minMarginRatioPct: Double = 15.0,
    val minLiqDistancePct: Double = 5.0,
    val maxFundingCostPct: Double = 1.0
)

data class BtcRiskDecision(
    val allowed: Boolean,
    val reason: String,
    val notionalPct: Double,
    val leverage: Int,
    val reduceOnly: Boolean = false
)

/**
 * 合约专用风控决策：包含保证金比率、强平距离、资金费率成本检查。
 */
data class FuturesRiskDecision(
    val allowed: Boolean,
    val reason: String,
    val leverage: Int,
    val marginRatioOk: Boolean,
    val liqDistanceOk: Boolean,
    val fundingCostOk: Boolean
)

class BtcRiskEngine(private val limits: BtcRiskLimits = BtcRiskLimits()) {
    fun authorize(
        consensus: BtcConsensus,
        dailyPnlPct: Double,
        currentDrawdownPct: Double,
        requestedNotionalPct: Double
    ): BtcRiskDecision {
        if (limits.killSwitch) return denied("全局熔断")
        if (dailyPnlPct <= -limits.maxDailyLossPct) return denied("日亏损熔断")
        if (currentDrawdownPct >= limits.maxDrawdownPct) return denied("组合回撤熔断")
        if (consensus.direction == BtcDirection.FLAT) return denied("方向为 FLAT")
        if (consensus.probability < limits.minConfidence) return denied("置信度低于门槛")
        if (consensus.riskScore >= 0.90) return denied("波动风险过高")
        val size = requestedNotionalPct.coerceAtMost(limits.maxPerpNotionalPct).coerceAtLeast(0.0)
        if (size <= 0.0) return denied("仓位为零")
        return BtcRiskDecision(true, "允许", size, limits.maxLeverage)
    }

    /** 将实际 USDT 权益转换为百分比风控输入，避免固定 1000U 基准。 */
    fun authorizeByEquity(
        consensus: BtcConsensus,
        dailyPnlUsdt: Double,
        equityUsdt: Double,
        currentDrawdownPct: Double,
        requestedNotionalUsdt: Double
    ): BtcRiskDecision {
        if (equityUsdt <= 0.0) return denied("账户权益无效")
        val dailyPct = dailyPnlUsdt / equityUsdt * 100.0
        val requestedPct = requestedNotionalUsdt / equityUsdt * 100.0
        return authorize(consensus, dailyPct, currentDrawdownPct, requestedPct)
    }

    /**
     * 合约专用风控：检查保证金比率、强平距离、资金费率累计成本。
     * 用于持仓级 Layer 3 风控。
     */
    fun authorizeFutures(
        leverage: Int,
        marginRatioPct: Double,
        liqDistancePct: Double,
        fundingCostPct: Double
    ): FuturesRiskDecision {
        val marginOk = marginRatioPct >= limits.minMarginRatioPct
        val liqOk = liqDistancePct >= limits.minLiqDistancePct
        val fundingOk = fundingCostPct <= limits.maxFundingCostPct
        val levOk = leverage <= limits.maxLeverage
        val allowed = marginOk && liqOk && fundingOk && levOk
        val reason = buildString {
            if (!levOk) append("杠杆超限(${leverage}>${limits.maxLeverage}) ")
            if (!marginOk) append("保证金比率低(${"%.1f%%".format(marginRatioPct)}<${limits.minMarginRatioPct}%) ")
            if (!liqOk) append("强平距离近(${"%.1f%%".format(liqDistancePct)}<${limits.minLiqDistancePct}%) ")
            if (!fundingOk) append("资金费率成本高(${"%.2f%%".format(fundingCostPct)}>${limits.maxFundingCostPct}%) ")
            if (allowed) append("允许")
        }.trim()
        return FuturesRiskDecision(allowed, reason, leverage.coerceAtMost(limits.maxLeverage), marginOk, liqOk, fundingOk)
    }

    private fun denied(reason: String) = BtcRiskDecision(false, reason, 0.0, 0)
}
