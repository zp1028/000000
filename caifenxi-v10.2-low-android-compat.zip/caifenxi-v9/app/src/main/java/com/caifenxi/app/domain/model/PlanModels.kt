package com.caifenxi.app.domain.model

import kotlinx.serialization.Serializable

enum class PlanOutputFormat {
    DIRECTION,
    ZONE_DISTRIBUTION,
    NUMBER_SCORES,
    STRUCTURE_VALUE
}

enum class PlanHitCriteria {
    DIRECTION_MATCH,
    ZONE_DISTANCE,
    TOP20_HIT,
    STRUCTURE_RANGE
}

@Serializable
data class PlanDefinition(
    val planId: String,
    val planName: String,
    val category: String,
    val algorithm: String,
    val window: Int,
    /** 计划执行周期：1=单期，2=连续两期……由用户手动设置。 */
    val cyclePeriods: Int = 1,
    val outputFormat: PlanOutputFormat = PlanOutputFormat.DIRECTION,
    val hitCriteria: PlanHitCriteria = PlanHitCriteria.DIRECTION_MATCH,
    val backtestWindows: List<Int> = listOf(10, 20, 50, 100, 200, 500),
    val baselineType: String = "uniform_50",
    val baselineValue: Double = 0.50,
    val weightCap: Double = 1.0,
    val participateConsensus: Boolean = true,
    val participateCombo: Boolean = false,
    /** 是否为本期随机生成的实例 */
    val randomGenerated: Boolean = false,
    val seedIssue: String = ""
)

@Serializable
data class PlanRuntime(
    val planId: String,
    val weight: Double = 1.0,
    val score: Double = 50.0,
    val sampleCount: Int = 0,
    val hitCount: Int = 0,
    val consecutiveMiss: Int = 0,
    val consecutiveHit: Int = 0,
    val maxConsecutiveMiss: Int = 0,
    val maxConsecutiveHit: Int = 0,
    val recent10Rate: Double = 0.0,
    val recent50Rate: Double = 0.0,
    val recent200Rate: Double = 0.0,
    val baselineEdge: Double = 0.0,
    val weightDelta: Double = 0.0,
    val status: PlanStatus = PlanStatus.ACTIVE,
    val lastPrediction: String? = null,
    val lastTargetIssue: String? = null
) {
    /** 对错成功率 0~1（仅已结算样本） */
    val hitRate: Double
        get() = if (sampleCount <= 0) 0.0 else hitCount.toDouble() / sampleCount

    val hitRatePercent: String
        get() = if (sampleCount <= 0) "-" else "%.1f%%".format(hitRate * 100)
}

/** 计划评分/权重趋势快照：仅用于实时趋势展示，不改变回测口径。 */
data class PlanTrendPoint(
    val issue: String,
    val planId: String,
    val score: Double,
    val weight: Double,
    val hitRate: Double,
    val sampleCount: Int,
    val capturedAt: Long = System.currentTimeMillis()
)

enum class PlanStatus {
    ACTIVE,
    PROMOTED,
    DEMOTED,
    HOLD,
    ELIMINATED
}

@Serializable
data class PlanPredictionRecord(
    val planId: String,
    val lotteryKey: String,
    val targetIssue: String,
    val cutoffIssue: String,
    val output: String,
    val scoreAtPredict: Double,
    val weightAtPredict: Double,
    val settled: Boolean = false,
    val hit: Boolean? = null,
    val settledAt: Long? = null,
    val planName: String = "",
    val category: String = ""
)

@Serializable
data class ModelConsensus(
    val lotteryKey: String,
    val targetIssue: String,
    val category: String,
    val leadingDirection: String,
    val supportRatio: Double,
    val disagreement: Double,
    val participatingPlans: Int,
    val detail: Map<String, Double> = emptyMap()
)

/**
 * 用户自定义计划(持久化到 Room)。
 * category: 大小 / 单双 / 组合 / 号码 / 位置-冠军 / 位置-亚军 / 位置-第3 / 区间 / 结构 / AI
 * algorithm: FREQ / EWMA / MKV1 / MSF / OMIT / CHOT / STRUCT
 */
@Serializable
data class CustomPlan(
    val planId: String,
    val lotteryKey: String,
    val planName: String,
    val category: String,
    val algorithm: String = "FREQ",
    val window: Int = 30,
    /** 计划周期（期），支持手动设置 1～20。 */
    val cyclePeriods: Int = 1,
    val outputFormat: String = "DIRECTION",
    val hitCriteria: String = "DIRECTION_MATCH",
    val enabled: Boolean = true,
    val participateConsensus: Boolean = true,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
) {
    companion object {
        const val ID_PREFIX = "CUSTOM-"
    }

    /** 转换为 PlanEngine 使用的 PlanDefinition */
    fun toDefinition(): PlanDefinition = PlanDefinition(
        planId = planId,
        planName = planName,
        category = category,
        algorithm = algorithm,
        window = window,
        cyclePeriods = cyclePeriods,
        outputFormat = PlanOutputFormat.entries.find { it.name == outputFormat } ?: PlanOutputFormat.DIRECTION,
        hitCriteria = PlanHitCriteria.entries.find { it.name == hitCriteria } ?: PlanHitCriteria.DIRECTION_MATCH,
        participateConsensus = participateConsensus,
        randomGenerated = false,
        seedIssue = ""
    )
}

object ScoreWeights {
    const val RECENT_HIT = 30.0
    const val MID_HIT = 18.0
    const val LONG_HIT = 12.0
    const val STABILITY = 12.0
    const val SAMPLE = 8.0
    const val STREAK = 10.0
    const val BASELINE_BEAT = 10.0
}

/**
 * 回测评分权重(可配置化)。
 * updateRuntime 中实际生效的只有 recentHit / sample / streak,
 * 其余保留占位以便未来扩展;全部字段提供默认值等价于 ScoreWeights 常量。
 */
@Serializable
data class BacktestParams(
    val recentHit: Double = ScoreWeights.RECENT_HIT,
    val midHit: Double = ScoreWeights.MID_HIT,
    val longHit: Double = ScoreWeights.LONG_HIT,
    val stability: Double = ScoreWeights.STABILITY,
    val sample: Double = ScoreWeights.SAMPLE,
    val streak: Double = ScoreWeights.STREAK,
    val baselineBeat: Double = ScoreWeights.BASELINE_BEAT,
    /** 计划晋级分数阈值(score >= 该值且样本足够 → PROMOTED) */
    val promoteThreshold: Double = 65.0,
    /** 连错达到该值开始扣分 */
    val streakPenaltyStart: Int = 5
)


@Serializable
data class ConsensusRecord(
    val id: String,                 // lotteryKey|issue|category
    val lotteryKey: String,
    val targetIssue: String,
    val category: String,           // 大小 / 单双 / 组合
    val leadingDirection: String,   // 可能含多候选 大单/大双
    val candidates: List<String> = emptyList(),
    val supportRatio: Double = 0.0,
    val participatingPlans: Int = 0,
    val actual: String? = null,
    val result: String = "待开",    // 待开 / 对 / 错
    val createdAt: Long = System.currentTimeMillis(),
    val settledAt: Long? = null
)

@Serializable
data class ConsensusStats(
    val total: Int = 0,
    val pending: Int = 0,
    val hit: Int = 0,
    val miss: Int = 0,
    val hitRate: Double = 0.0,
    /** 按分类（大小/单双/组合）的完整统计：连击 + 两期/三期窗口率 */
    val byCategory: Map<String, CategoryStats> = emptyMap(),
    /** 当前连对（正）/连错（负） */
    val recentStreak: Int = 0,
    val maxHitStreak: Int = 0,
    val maxMissStreak: Int = 0,
    /** 两期滚动窗口：窗口内至少 1 次对 = 两期对 */
    val twoHitRate: Double = 0.0,
    val twoMissRate: Double = 0.0,
    /** 三期滚动窗口：窗口内至少 1 次对 = 三期对 */
    val threeHitRate: Double = 0.0,
    val threeMissRate: Double = 0.0,
    val twoWindows: Int = 0,
    val threeWindows: Int = 0
)
