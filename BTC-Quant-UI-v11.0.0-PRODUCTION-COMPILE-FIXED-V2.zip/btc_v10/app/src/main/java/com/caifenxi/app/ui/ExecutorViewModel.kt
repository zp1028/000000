package com.caifenxi.app.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.caifenxi.app.domain.execution.BetAction
import com.caifenxi.app.domain.execution.BetCommand
import com.caifenxi.app.domain.execution.ExecutionTask
import com.caifenxi.app.domain.execution.ExecutorManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/**
 * 网页执行台 ViewModel：真实派发 ExecutorManager，日志供 UI 展示。
 */
class ExecutorViewModel : ViewModel() {

    private val _executorStatus = MutableStateFlow(ExecutorStatus.IDLE)
    val executorStatus: StateFlow<ExecutorStatus> = _executorStatus.asStateFlow()

    private val _currentTask = MutableStateFlow<ExecutionTask?>(null)
    val currentTask: StateFlow<ExecutionTask?> = _currentTask.asStateFlow()

    private val _executorLogs = MutableStateFlow<List<String>>(emptyList())
    val executorLogs: StateFlow<List<String>> = _executorLogs.asStateFlow()

    private val _executorStats = MutableStateFlow(ExecutorStats())
    val executorStats: StateFlow<ExecutorStats> = _executorStats.asStateFlow()

    init {
        addLog("执行器就绪 · 等待挂机指令或测试执行")
        addLog("WebView=${if (ExecutorManager.isAvailable("webview")) "可用" else "未连接"} 模式=${ExecutorManager.getMode()}")
    }

    fun startTask(task: ExecutionTask) {
        viewModelScope.launch {
            _executorStatus.value = ExecutorStatus.RUNNING
            _currentTask.value = task
            addLog("开始 ${task.cmdId} ${task.lotteryKey}/${task.issue} ${task.dx ?: "-"}/${task.ds ?: "-"} 金额=${task.amountText}")

            val cmd = task.command ?: BetCommand(
                cmdId = task.cmdId,
                lotteryKey = task.lotteryKey,
                issue = task.issue,
                stage = task.stage,
                leg = task.leg,
                bets = buildList {
                    task.dx?.let { add(BetAction(BetAction.CAT_DX, it)) }
                    task.ds?.let { add(BetAction(BetAction.CAT_DS, it)) }
                    task.combo?.let { add(BetAction(BetAction.CAT_COMBO, it)) }
                    task.predNumbers.forEach { add(BetAction(BetAction.CAT_NUMBER, it)) }
                },
                amountText = task.amountText,
                source = task.source,
                expireAt = task.expireAt
            )

            if (cmd.bets.isEmpty()) {
                addLog("失败: 无注项")
                _executorStatus.value = ExecutorStatus.FAILED
                _currentTask.value = null
                return@launch
            }

            val result = suspendCancellableCoroutine { cont ->
                val accepted = ExecutorManager.execute(cmd) { r ->
                    if (cont.isActive) cont.resume(r)
                }
                if (!accepted) {
                    if (cont.isActive) {
                        cont.resume(
                            com.caifenxi.app.domain.execution.ExecutionResult.fail(
                                cmd.cmdId,
                                com.caifenxi.app.domain.execution.ExecutionResult.WEBVIEW_DISCONNECTED,
                                "无可用执行器（请打开网页页并加载投注站）"
                            )
                        )
                    }
                }
            }

            val stats = _executorStats.value
            if (result.success) {
                _executorStatus.value = ExecutorStatus.COMPLETED
                addLog("成功: ${result.message}")
                _executorStats.value = stats.copy(
                    totalTasks = stats.totalTasks + 1,
                    successfulTasks = stats.successfulTasks + 1
                )
            } else {
                _executorStatus.value = ExecutorStatus.FAILED
                addLog("失败: ${result.message}")
                _executorStats.value = stats.copy(
                    totalTasks = stats.totalTasks + 1,
                    failedTasks = stats.failedTasks + 1
                )
            }
            _currentTask.value = null
            _executorStatus.value = ExecutorStatus.IDLE
        }
    }

    fun stopAllTasks() {
        _executorStatus.value = ExecutorStatus.IDLE
        _currentTask.value = null
        addLog("已停止")
    }

    fun clearLogs() {
        _executorLogs.value = emptyList()
        addLog("日志已清空")
    }

    fun generateTestTask(): ExecutionTask {
        val cmd = BetCommand(
            cmdId = "test_${System.currentTimeMillis()}",
            lotteryKey = "pk10",
            issue = "test-issue",
            bets = listOf(
                BetAction(BetAction.CAT_DX, "大"),
                BetAction(BetAction.CAT_DS, "单")
            ),
            amountText = "10",
            source = "test",
            expireAt = System.currentTimeMillis() + 300_000
        )
        return ExecutionTask.fromCommand(cmd, source = "test").copy(executor = "webview")
    }

    private fun addLog(message: String) {
        val line = "${java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date())} $message"
        _executorLogs.value = (_executorLogs.value + line).takeLast(50)
    }

    enum class ExecutorStatus { IDLE, RUNNING, COMPLETED, FAILED, CANCELLED }

    data class ExecutorStats(
        val totalTasks: Int = 0,
        val successfulTasks: Int = 0,
        val failedTasks: Int = 0
    )
}
