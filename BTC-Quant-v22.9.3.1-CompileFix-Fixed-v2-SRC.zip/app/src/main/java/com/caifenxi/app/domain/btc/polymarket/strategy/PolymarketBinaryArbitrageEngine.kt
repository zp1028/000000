package com.caifenxi.app.domain.btc.polymarket.strategy

import com.caifenxi.app.domain.btc.polymarket.PolyMarket
import com.caifenxi.app.domain.btc.polymarket.PolyOrderBook

/**
 * Detects a true two-leg binary mispricing opportunity.
 * This is a research/execution-intent layer; it never submits either leg itself.
 */
data class BinaryArbitrageOpportunity(
    val marketId: String,
    val yesTokenId: String,
    val noTokenId: String,
    val yesAsk: Double,
    val noAsk: Double,
    val combinedCost: Double,
    val grossEdge: Double,
    val estimatedCosts: Double,
    val netEdge: Double,
    val size: Double,
    val trigger: String,
    val executable: Boolean
)

object PolymarketBinaryArbitrageEngine {
    fun detect(
        market: PolyMarket,
        yesBook: PolyOrderBook,
        noBook: PolyOrderBook?,
        feeRate: Double = 0.002,
        slippageBuffer: Double = 0.003,
        minNetEdge: Double = 0.01
    ): BinaryArbitrageOpportunity? {
        val no = noBook ?: return null
        val ya = yesBook.bestAsk ?: return null
        val na = no.bestAsk ?: return null
        if (ya <= 0.0 || na <= 0.0 || ya >= 1.0 || na >= 1.0) return null
        val combined = ya + na
        val gross = 1.0 - combined
        val costs = combined * feeRate + slippageBuffer
        val net = gross - costs
        if (net < minNetEdge) return null
        val size = minOf(
            yesBook.asks.minByOrNull { it.price }?.size ?: 0.0,
            no.asks.minByOrNull { it.price }?.size ?: 0.0
        ).coerceAtLeast(0.0)
        if (size <= 0.0) return null
        return BinaryArbitrageOpportunity(
            marketId = market.conditionId,
            yesTokenId = market.yesTokenId,
            noTokenId = market.noTokenId,
            yesAsk = ya,
            noAsk = na,
            combinedCost = combined,
            grossEdge = gross,
            estimatedCosts = costs,
            netEdge = net,
            size = size,
            trigger = "YES_ASK+NO_ASK<1",
            executable = true
        )
    }
}
