package com.caifenxi.app.domain.btc.runtime

import android.content.Context
import com.caifenxi.app.domain.btc.broker.BrokerResult
import org.json.JSONArray
import org.json.JSONObject
import java.util.ArrayDeque
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.max

/**
 * Final local execution gate for Polymarket writes.
 *
 * This is deliberately a conservative client-side limiter, not a claim about
 * venue quotas. It protects the account from burst retries when the network,
 * CLOB or credentials are unstable. Venue responses still remain authoritative.
 */
class PolymarketExecutionGuard(
    context: Context,
    private val maxOrdersPerMinute: Int = 8,
    private val maxCancelsPerMinute: Int = 12,
    private val maxConsecutiveFailures: Int = 3,
    private val failureCooldownMs: Long = 30_000L,
    private val maxHistory: Int = 80
) {
    data class Decision(val allowed: Boolean, val reason: String = "")

    private val prefs = context.applicationContext.getSharedPreferences("btc_poly_execution_guard_v1", Context.MODE_PRIVATE)
    private val orderTimes = ArrayDeque<Long>()
    private val cancelTimes = ArrayDeque<Long>()
    private var cooldownUntil = prefs.getLong("cooldownUntil", 0L)
    private var consecutiveFailures = prefs.getInt("consecutiveFailures", 0)
    private var lastHeartbeatAt = prefs.getLong("lastHeartbeatAt", 0L)
    private var lastFailureAt = prefs.getLong("lastFailureAt", 0L)
    private val blockedCount = AtomicInteger(prefs.getInt("blockedCount", 0))

    @Synchronized
    fun beforeOrder(now: Long = System.currentTimeMillis()): Decision {
        prune(orderTimes, now - 60_000L)
        if (now < cooldownUntil) return Decision(false, "执行熔断冷却中，剩余 ${(cooldownUntil - now + 999L) / 1000L}s")
        if (orderTimes.size >= maxOrdersPerMinute) return Decision(false, "本地订单速率闸门：60秒内已达到 $maxOrdersPerMinute 次")
        return Decision(true)
    }

    @Synchronized
    fun markOrderAttempt(now: Long = System.currentTimeMillis()) {
        prune(orderTimes, now - 60_000L)
        orderTimes.addLast(now)
        trim(orderTimes)
        persist()
    }

    @Synchronized
    fun afterOrder(result: BrokerResult, now: Long = System.currentTimeMillis()) {
        if (result.ok) {
            consecutiveFailures = 0
            cooldownUntil = 0L
        } else if (result.indeterminate || isRateLimit(result) || isTransient(result)) {
            consecutiveFailures++
            lastFailureAt = now
            val serverRetry = result.retryAfterMs.coerceAtLeast(0L)
            val cooldown = if (serverRetry > 0L) serverRetry else if (isRateLimit(result)) 30_000L else failureCooldownMs
            if (consecutiveFailures >= maxConsecutiveFailures || isRateLimit(result)) {
                cooldownUntil = max(cooldownUntil, now + cooldown)
            }
        }
        persist()
    }

    @Synchronized
    fun beforeCancel(now: Long = System.currentTimeMillis()): Decision {
        prune(cancelTimes, now - 60_000L)
        if (now < cooldownUntil) return Decision(false, "执行熔断冷却中，剩余 ${(cooldownUntil - now + 999L) / 1000L}s")
        if (cancelTimes.size >= maxCancelsPerMinute) return Decision(false, "本地撤单速率闸门：60秒内已达到 $maxCancelsPerMinute 次")
        return Decision(true)
    }

    @Synchronized
    fun markCancelAttempt(now: Long = System.currentTimeMillis()) {
        prune(cancelTimes, now - 60_000L)
        cancelTimes.addLast(now)
        trim(cancelTimes)
        persist()
    }

    @Synchronized
    fun afterCancel(result: BrokerResult, now: Long = System.currentTimeMillis()) {
        if (result.ok) consecutiveFailures = 0
        else if (result.indeterminate || isRateLimit(result) || isTransient(result)) {
            consecutiveFailures++
            lastFailureAt = now
            if (isRateLimit(result) || consecutiveFailures >= maxConsecutiveFailures) {
                val retry = result.retryAfterMs.takeIf { it > 0L } ?: failureCooldownMs
                cooldownUntil = max(cooldownUntil, now + retry)
            }
        }
        persist()
    }

    @Synchronized
    fun heartbeatDue(now: Long = System.currentTimeMillis(), minIntervalMs: Long = 8_000L): Boolean =
        now - lastHeartbeatAt >= minIntervalMs

    @Synchronized
    fun recordHeartbeat(result: BrokerResult, now: Long = System.currentTimeMillis()) {
        lastHeartbeatAt = now
        if (!result.ok && (result.indeterminate || isRateLimit(result) || isTransient(result))) {
            consecutiveFailures++
            lastFailureAt = now
            if (isRateLimit(result) || consecutiveFailures >= maxConsecutiveFailures) {
                cooldownUntil = max(cooldownUntil, now + (result.retryAfterMs.takeIf { it > 0L } ?: failureCooldownMs))
            }
        } else if (result.ok) {
            consecutiveFailures = 0
        }
        persist()
    }

    fun status(now: Long = System.currentTimeMillis()): String = synchronized(this) {
        when {
            now < cooldownUntil -> "COOLDOWN ${((cooldownUntil - now + 999L) / 1000L)}s"
            else -> "READY"
        }
    }

    private fun isRateLimit(result: BrokerResult): Boolean =
        result.httpCode == 429 || result.message.contains("429") || result.message.contains("rate limit", true) || result.message.contains("too many", true)

    private fun isTransient(result: BrokerResult): Boolean =
        result.httpCode in setOf(408, 425, 500, 502, 503, 504) ||
            result.message.contains("timeout", true) || result.message.contains("connect", true) || result.message.contains("temporarily", true)

    private fun prune(q: ArrayDeque<Long>, cutoff: Long) { while (q.isNotEmpty() && q.first < cutoff) q.removeFirst() }
    private fun trim(q: ArrayDeque<Long>) { while (q.size > maxHistory) q.removeFirst() }

    private fun persist() {
        val orders = JSONArray().apply { orderTimes.forEach { put(it) } }
        val cancels = JSONArray().apply { cancelTimes.forEach { put(it) } }
        prefs.edit()
            .putLong("cooldownUntil", cooldownUntil)
            .putInt("consecutiveFailures", consecutiveFailures)
            .putLong("lastHeartbeatAt", lastHeartbeatAt)
            .putLong("lastFailureAt", lastFailureAt)
            .putInt("blockedCount", blockedCount.get())
            .putString("orderTimes", orders.toString())
            .putString("cancelTimes", cancels.toString())
            .apply()
    }

    init {
        fun loadQueue(key: String, target: ArrayDeque<Long>) {
            runCatching {
                val a = JSONArray(prefs.getString(key, "[]"))
                for (i in 0 until a.length()) target.addLast(a.optLong(i))
            }
        }
        loadQueue("orderTimes", orderTimes)
        loadQueue("cancelTimes", cancelTimes)
        val now = System.currentTimeMillis()
        prune(orderTimes, now - 60_000L)
        prune(cancelTimes, now - 60_000L)
    }
}
