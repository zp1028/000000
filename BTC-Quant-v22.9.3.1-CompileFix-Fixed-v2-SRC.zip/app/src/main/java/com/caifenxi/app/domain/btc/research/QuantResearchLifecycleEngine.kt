package com.caifenxi.app.domain.btc.research

import com.caifenxi.app.domain.btc.factor.QuantFactorResearchEngine
import kotlin.math.abs

/**
 * Production research gate. A research score is never enough to activate a
 * factor: sample size, OOS consistency, ICIR and sign stability are checked
 * before a weight can reach the unattended runtime.
 */
object QuantResearchLifecycleEngine {
    enum class Status { IDEA, CANDIDATE, OOS_VALIDATED, SHADOW, ACTIVE, DOWNWEIGHT, RETIRED }

    data class Decision(
        val id: String,
        val status: Status,
        val weightMultiplier: Double,
        val score: Double,
        val reason: String,
        val evaluatedAtMs: Long
    )

    fun evaluate(
        metric: QuantFactorResearchEngine.Metric,
        nowMs: Long = System.currentTimeMillis(),
        minSamples: Int = 80
    ): Decision {
        val absIc = abs(metric.ic)
        val signStable = metric.firstIc == 0.0 || metric.secondIc == 0.0 || metric.firstIc * metric.secondIc > 0.0
        val quality = (
            absIc * 0.40 +
            metric.icir.coerceIn(0.0, 3.0) / 3.0 * 0.25 +
            metric.stability * 0.20 +
            metric.pLike * 0.15
        ).coerceIn(0.0, 1.0)
        val status = when {
            metric.samples < minSamples -> Status.CANDIDATE
            !signStable && abs(metric.firstIc - metric.secondIc) > 0.12 -> Status.DOWNWEIGHT
            absIc < 0.015 && metric.icir < 0.35 -> Status.RETIRED
            metric.icir >= 0.85 && metric.stability >= 0.55 && metric.pLike >= 0.20 -> Status.ACTIVE
            else -> Status.SHADOW
        }
        val multiplier = when (status) {
            Status.ACTIVE -> (0.55 + quality * 0.90).coerceIn(0.55, 1.45)
            Status.SHADOW -> (0.30 + quality * 0.55).coerceIn(0.30, 0.85)
            Status.DOWNWEIGHT -> 0.20
            Status.RETIRED -> 0.0
            Status.CANDIDATE, Status.IDEA, Status.OOS_VALIDATED -> 0.15
        }
        val reason = when (status) {
            Status.ACTIVE -> "OOS IC/ICIR/stability passed"
            Status.SHADOW -> "OOS evidence exists but promotion threshold not met"
            Status.DOWNWEIGHT -> "OOS sign instability"
            Status.RETIRED -> "OOS predictive value below floor"
            Status.CANDIDATE -> "insufficient OOS samples"
            else -> "research state"
        }
        return Decision(metric.factorId, status, multiplier, quality, reason, nowMs)
    }
}
