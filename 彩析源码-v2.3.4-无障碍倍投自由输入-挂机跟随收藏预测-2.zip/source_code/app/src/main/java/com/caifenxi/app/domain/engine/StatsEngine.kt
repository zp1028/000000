package com.caifenxi.app.domain.engine

import com.caifenxi.app.data.config.StatStore
import com.caifenxi.app.domain.model.DrawRecord
import com.caifenxi.app.domain.model.PredictionSnapshot
import com.caifenxi.app.domain.model.StatRecord

object StatsEngine {

    /**
     * 写入待开记录（一次性读写，避免逐条 upsert 造成 O(n²) 的 JSON 解析/序列化）：
     * - 大小/单双：单结果 exact
     * - 组合：comboList 多候选 any_of（命中任一即对）
     * - 位置：每个位置 TopN 号码 any_of
     */
    suspend fun recordPending(store: StatStore, snap: PredictionSnapshot, algoId: String) {
        val key = snap.lotteryKey
        val issue = snap.targetIssue
        val existing = store.loadAll(key).associateBy { it.id }.toMutableMap()

        fun upsert(
            cat: String,
            lean: String,
            candidates: List<String>,
            score: Double,
            matchMode: String
        ) {
            if (lean.isBlank() && candidates.isEmpty()) return
            val id = "$key|$issue|$cat|$algoId"
            val old = existing[id]
            if (old != null && old.result != "待开") return
            val main = lean.ifBlank { candidates.firstOrNull() ?: return }
            existing[id] = StatRecord(
                id = id,
                lotteryKey = key,
                issue = issue,
                category = cat,
                lean = main,
                candidates = candidates.ifEmpty { listOf(main) },
                result = "待开",
                algoId = algoId,
                score = score,
                matchMode = matchMode
            )
        }

        snap.dx?.let { upsert("大小", it.direction, listOf(it.direction), it.score, "exact") }
        snap.ds?.let { upsert("单双", it.direction, listOf(it.direction), it.score, "exact") }

        // 组合：按候选列表结算（任一命中即对）
        val comboCands = when {
            snap.comboList.isNotEmpty() -> snap.comboList.map { it.direction }
            snap.combo != null -> listOf(snap.combo.direction)
            else -> emptyList()
        }
        if (comboCands.isNotEmpty()) {
            val score = snap.comboList.firstOrNull()?.score ?: snap.combo?.score ?: 0.0
            upsert(
                cat = "组合",
                lean = comboCands.joinToString("/"),
                candidates = comboCands,
                score = score,
                matchMode = if (comboCands.size > 1) "any_of" else "exact"
            )
        }

        // 位置预测：每位 TopN
        snap.positions.forEach { pos ->
            val nums = pos.topNumbers.map { it.number.toString() }
            if (nums.isEmpty()) return@forEach
            upsert(
                cat = "位置-${pos.positionName}",
                lean = nums.joinToString("/"),
                candidates = nums,
                score = pos.topNumbers.firstOrNull()?.score ?: 0.0,
                matchMode = "any_of"
            )
        }

        // 一次性保存，避免逐条 loadAll/saveAll
        store.saveAll(existing.values.toList())
    }

    suspend fun settleWithDraw(store: StatStore, lotteryKey: String, draw: DrawRecord) {
        settleWithDraws(store, lotteryKey, listOf(draw))
    }

    /**
     * 批量结算：一次加载、内存结算、一次保存。
     * 原实现每期开奖都全量 loadAll + 逐条 upsert（内部又是全量 loadAll/saveAll），
     * 历史一多（极速彩种 5 天可达数千期）会造成严重卡顿甚至 ANR。
     */
    suspend fun settleWithDraws(store: StatStore, lotteryKey: String, draws: List<DrawRecord>) {
        if (draws.isEmpty()) return
        val all = store.loadAll(lotteryKey)
        val pending = all.filter { it.result == "待开" }
        if (pending.isEmpty()) return
        val byId = all.associateBy { it.id }.toMutableMap()
        var changed = false
        for (r in pending) {
            // 找到第一条「已到达该预测期号」的开奖（draws 升序，与逐期结算语义一致）
            val draw = draws.firstOrNull { issueReached(r.issue, it.issue) } ?: continue
            val actual = resolveActual(r.category, draw) ?: continue
            val hit = isHit(r, actual)
            byId[r.id] = r.copy(
                actual = actual,
                result = if (hit) "对" else "错",
                settledAt = System.currentTimeMillis()
            )
            changed = true
        }
        if (changed) store.saveAll(byId.values.toList())
    }

    suspend fun backfillFromHistory(store: StatStore, lotteryKey: String, history: List<DrawRecord>) {
        val byIssue = history.associateBy { it.issue }
        val pending = store.loadAll(lotteryKey).filter { it.result == "待开" }
        for (r in pending) {
            val draw = byIssue[r.issue] ?: continue
            val actual = resolveActual(r.category, draw) ?: continue
            store.upsert(
                r.copy(
                    actual = actual,
                    result = if (isHit(r, actual)) "对" else "错",
                    settledAt = System.currentTimeMillis()
                )
            )
        }
    }

    private fun issueReached(predIssue: String, drawIssue: String): Boolean {
        if (predIssue == drawIssue) return true
        val a = predIssue.toLongOrNull()
        val b = drawIssue.toLongOrNull()
        return a != null && b != null && a <= b
    }

    private fun resolveActual(category: String, draw: DrawRecord): String? {
        return when {
            category == "大小" -> draw.dx
            category == "单双" -> draw.ds
            category == "组合" -> draw.combo
            category.startsWith("位置-") -> {
                val name = category.removePrefix("位置-")
                // 快乐8 任选：实际开奖为整组号码，命中用 any_of 对候选比对
                if (name == "任选号码" || name == "号码池") {
                    return draw.numbers.joinToString(",")
                }
                val idx = when (name) {
                    "冠军" -> 0
                    "亚军" -> 1
                    else -> Regex("""第(\d+)""").find(name)?.groupValues?.get(1)?.toIntOrNull()?.minus(1)
                } ?: return null
                draw.numbers.getOrNull(idx)?.toString()
            }
            else -> null
        }
    }

    /**
     * exact：lean==actual
     * any_of：候选与 actual 任一相同即中；
     * 若 actual 为逗号分隔的开奖组（任选号码），则候选出现在开奖组中即中。
     */
    private fun isHit(r: StatRecord, actual: String): Boolean {
        return when (r.matchMode) {
            "any_of" -> {
                val cands = r.candidates.ifEmpty {
                    r.lean.split("/", "、", ",", " ").map { it.trim() }.filter { it.isNotEmpty() }
                }
                val drawn = actual.split("/", "、", ",", " ").map { it.trim() }.filter { it.isNotEmpty() }
                if (drawn.size > 1) cands.any { it in drawn } else cands.any { it == actual }
            }
            else -> r.lean == actual || r.candidates.any { it == actual }
        }
    }
}
