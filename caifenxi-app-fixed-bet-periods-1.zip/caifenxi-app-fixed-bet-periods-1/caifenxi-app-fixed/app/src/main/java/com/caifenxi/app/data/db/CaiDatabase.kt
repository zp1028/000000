package com.caifenxi.app.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.caifenxi.app.data.db.dao.BetDao
import com.caifenxi.app.data.db.dao.ConsensusDao
import com.caifenxi.app.data.db.dao.CustomPlanDao
import com.caifenxi.app.data.db.dao.DrawDao
import com.caifenxi.app.data.db.dao.ManualMarkDao
import com.caifenxi.app.data.db.dao.StatDao
import com.caifenxi.app.data.db.entity.BetEntity
import com.caifenxi.app.data.db.entity.BotConfigEntity
import com.caifenxi.app.data.db.entity.ConsensusEntity
import com.caifenxi.app.data.db.entity.CustomPlanEntity
import com.caifenxi.app.data.db.entity.DrawEntity
import com.caifenxi.app.data.db.entity.ManualMarkEntity
import com.caifenxi.app.data.db.entity.StatEntity
import com.caifenxi.app.data.db.entity.WalletEntity

@Database(
    entities = [
        DrawEntity::class,
        BetEntity::class,
        BotConfigEntity::class,
        WalletEntity::class,
        StatEntity::class,
        ConsensusEntity::class,
        ManualMarkEntity::class,
        CustomPlanEntity::class
    ],
    version = 7,
    exportSchema = false
)
abstract class CaiDatabase : RoomDatabase() {
    abstract fun drawDao(): DrawDao
    abstract fun betDao(): BetDao
    abstract fun statDao(): StatDao
    abstract fun consensusDao(): ConsensusDao
    abstract fun manualMarkDao(): ManualMarkDao
    abstract fun customPlanDao(): CustomPlanDao

    companion object {
        private val MIGRATION_4_5 = object : Migration(4, 5) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // Version 5 formalizes the existing schema without dropping user data.
            }
        }

        private val MIGRATION_5_6 = object : Migration(5, 6) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // Create stats table
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS `stats` (
                        `id` TEXT NOT NULL,
                        `lotteryKey` TEXT NOT NULL,
                        `issue` TEXT NOT NULL,
                        `category` TEXT NOT NULL,
                        `lean` TEXT NOT NULL,
                        `candidatesJson` TEXT NOT NULL,
                        `actual` TEXT,
                        `result` TEXT NOT NULL,
                        `algoId` TEXT NOT NULL,
                        `score` REAL NOT NULL,
                        `matchMode` TEXT NOT NULL,
                        `createdAt` INTEGER NOT NULL,
                        `settledAt` INTEGER,
                        PRIMARY KEY(`id`)
                    )
                """.trimIndent())
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_stats_lotteryKey_issue_category` ON `stats` (`lotteryKey`, `issue`, `category`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_stats_lotteryKey_createdAt` ON `stats` (`lotteryKey`, `createdAt`)")

                // Create consensus table
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS `consensus` (
                        `id` TEXT NOT NULL,
                        `lotteryKey` TEXT NOT NULL,
                        `targetIssue` TEXT NOT NULL,
                        `category` TEXT NOT NULL,
                        `leadingDirection` TEXT NOT NULL,
                        `candidatesJson` TEXT NOT NULL,
                        `supportRatio` REAL NOT NULL,
                        `participatingPlans` INTEGER NOT NULL,
                        `actual` TEXT,
                        `result` TEXT NOT NULL,
                        `createdAt` INTEGER NOT NULL,
                        `settledAt` INTEGER,
                        PRIMARY KEY(`id`)
                    )
                """.trimIndent())
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_consensus_lotteryKey_targetIssue_category` ON `consensus` (`lotteryKey`, `targetIssue`, `category`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_consensus_lotteryKey_createdAt` ON `consensus` (`lotteryKey`, `createdAt`)")

                // Create manual_marks table
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS `manual_marks` (
                        `lotteryKey` TEXT NOT NULL,
                        `category` TEXT NOT NULL,
                        `direction` TEXT NOT NULL,
                        `updatedAt` INTEGER NOT NULL,
                        PRIMARY KEY(`lotteryKey`, `category`)
                    )
                """.trimIndent())
            }
        }

        private val MIGRATION_6_7 = object : Migration(6, 7) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // Create custom_plans table
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS `custom_plans` (
                        `planId` TEXT NOT NULL,
                        `lotteryKey` TEXT NOT NULL,
                        `planName` TEXT NOT NULL,
                        `category` TEXT NOT NULL,
                        `algorithm` TEXT NOT NULL,
                        `window` INTEGER NOT NULL,
                        `outputFormat` TEXT NOT NULL,
                        `hitCriteria` TEXT NOT NULL,
                        `enabled` INTEGER NOT NULL,
                        `participateConsensus` INTEGER NOT NULL,
                        `createdAt` INTEGER NOT NULL,
                        `updatedAt` INTEGER NOT NULL,
                        PRIMARY KEY(`planId`)
                    )
                """.trimIndent())
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_custom_plans_lotteryKey_enabled` ON `custom_plans` (`lotteryKey`, `enabled`)")
            }
        }

        @Volatile private var instance: CaiDatabase? = null

        fun getInstance(context: Context): CaiDatabase {
            return instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    CaiDatabase::class.java,
                    "caifenxi.db"
                )
                    .addMigrations(MIGRATION_4_5, MIGRATION_5_6, MIGRATION_6_7)
                    // 老版本(v1~v4)无迁移路径时自动清库重建,避免启动闪退;
                    // 用户数据可通过「备份/恢复」功能导出留存
                    .fallbackToDestructiveMigration()
                    .build().also { instance = it }
            }
        }
    }
}
