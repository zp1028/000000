package com.caifenxi.app.data.db.dao

import androidx.room.*
import com.caifenxi.app.data.db.entity.ExecutionTaskEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ExecutionTaskDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entity: ExecutionTaskEntity)

    @Query("SELECT * FROM execution_tasks WHERE cmdId = :cmdId")
    suspend fun getById(cmdId: String): ExecutionTaskEntity?

    @Query("SELECT * FROM execution_tasks WHERE lotteryKey = :lotteryKey AND state IN (:states)")
    suspend fun getByLotteryAndStates(lotteryKey: String, states: List<String>): List<ExecutionTaskEntity>

    @Query("SELECT * FROM execution_tasks WHERE state = 'UNKNOWN' ORDER BY createdAt DESC")
    suspend fun getUnknowns(): List<ExecutionTaskEntity>

    @Query("SELECT * FROM execution_tasks WHERE state = 'UNKNOWN' ORDER BY createdAt DESC")
    fun observeUnknowns(): Flow<List<ExecutionTaskEntity>>

    @Query("SELECT * FROM execution_tasks WHERE lotteryKey = :lotteryKey ORDER BY createdAt DESC")
    fun observeByLottery(lotteryKey: String): Flow<List<ExecutionTaskEntity>>

    @Query("""
        SELECT * FROM execution_tasks 
        WHERE lotteryKey = :lotteryKey AND state = 'SUCCESS' 
        ORDER BY createdAt DESC LIMIT 1
    """)
    suspend fun getLastSuccess(lotteryKey: String): ExecutionTaskEntity?

    @Query("""
        SELECT EXISTS(
            SELECT 1 FROM execution_tasks 
            WHERE lotteryKey = :lotteryKey AND state = 'UNKNOWN'
        )
    """)
    suspend fun hasUnknownForLottery(lotteryKey: String): Boolean

    @Query("UPDATE execution_tasks SET state = :state WHERE cmdId = :cmdId AND state = :expectedState")
    suspend fun casUpdateState(cmdId: String, expectedState: String, state: String): Int

    @Query("UPDATE execution_tasks SET state = :state, resultJson = :resultJson, completedAt = :completedAt WHERE cmdId = :cmdId")
    suspend fun complete(cmdId: String, state: String, resultJson: String?, completedAt: Long): Int

    @Query("UPDATE execution_tasks SET state = 'ACKNOWLEDGED' WHERE cmdId = :cmdId AND state = 'UNKNOWN'")
    suspend fun acknowledgeUnknown(cmdId: String): Int

    @Query("SELECT * FROM execution_tasks WHERE lotteryKey = :lotteryKey AND issue = :issue AND state IN ('SUCCESS', 'EXECUTING', 'VERIFYING') LIMIT 1")
    suspend fun findExecutedForIssue(lotteryKey: String, issue: String): ExecutionTaskEntity?
}
