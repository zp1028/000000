package com.caifenxi.app.domain.btc.hs

import kotlin.math.max

/** Risk-based sizing; never increases size after a loss. Hard-capped by HsRuntimeConfig. */
object HsOpportunitySizing {
    data class Result(
        val riskFraction: Double,
        val notionalUsdt: Double,
        val multiplier: Double,
        val reason: String
    )

    fun calculate(
        equityUsdt: Double,
        netEdge: Double,
        halfKelly: Double,
        liquidity: Double,
        volatilityPct: Double,
        drawdownPct: Double,
        config: HsRuntimeConfig = HsRuntimeConfig.Default,
        opportunityMultiplier: Double = 1.0
    ): Result {
        val maxRiskFraction = config.maxRiskFraction
        if (equityUsdt <= 0 || netEdge <= 0 || liquidity <= 0 || opportunityMultiplier <= 0) {
            return Result(0.0, 0.0, 0.0, "edge/liquidity/机会倍率不足")
        }
        val vf = (0.012 / max(volatilityPct, 0.003)).coerceIn(0.35, 1.25)
        val df = (1 - drawdownPct.coerceIn(0.0, 0.20) / 0.20).coerceIn(0.0, 1.0)
        val ef = (netEdge / 0.05).coerceIn(0.0, 1.5)
        val f = minOf(
            maxRiskFraction,
            halfKelly.coerceIn(0.0, 0.10) * liquidity.coerceIn(0.0, 1.0) * vf * df * ef * opportunityMultiplier.coerceIn(0.0, 1.5)
        )
        val notional = (equityUsdt * f).coerceAtMost(config.maxNotionalUsdt)
        return Result(
            f,
            notional,
            (f / maxRiskFraction).coerceIn(0.0, 1.5),
            "½Kelly×流动性×波动×回撤×机会 · 上限 ${"%.0f".format(maxRiskFraction * 100)}%"
        )
    }
}
