package com.caifenxi.app.domain.model

/**
 * 各彩种可下注/可预测玩法目录：计划、图表、挂机、无障碍、文案统一从此取，避免串彩种。
 */
object LotteryPlayCatalog {

    data class Play(
        /** 内部 playType，与 PlanDefinition.playType 对齐 */
        val id: String,
        /** UI 短名 */
        val label: String,
        /** 说明 */
        val desc: String = "",
        /** 是否方向类（大小单双龙虎等） */
        val isDirection: Boolean = true
    )

    fun plays(type: LotteryType): List<Play> = when (type) {
        LotteryType.PKS -> listOf(
            Play("大小", "大小", "冠亚和大小"),
            Play("单双", "单双", "冠亚和单双"),
            Play("组合", "组合", "大单/大双/小单/小双"),
            Play("名次大小", "名次大小", "第1～10名：1-5小、6-10大"),
            Play("名次单双", "名次单双", "第1～10名号码单双"),
            Play("数字", "数字", "任选号码"),
            Play("位置", "定位号码", "名次直选号码", isDirection = false)
        )
        LotteryType.LUCK20 -> listOf(
            Play("大小", "大小", "和值大小"),
            Play("单双", "单双", "和值单双"),
            Play("组合", "组合", "和值组合"),
            Play("数字", "任选号码", "任意中1赔4", isDirection = false)
        )
        LotteryType.YDH -> listOf(
            // 与原计划页保持统一的“大小/单双/组合”入口，同时保留运动会专属逐球玩法。
            Play("大小", "大小", "第1球大小：4-6大、1-3小"),
            Play("单双", "单双", "第1球单双：1/3/5单、2/4/6双"),
            Play("组合", "组合", "第1球大小+单双"),
            Play("球大小", "球大小", "第1～6球：4-6大、1-3小"),
            Play("球单双", "球单双", "1/3/5单、2/4/6双"),
            Play("龙虎", "龙虎", "1vs6、2vs5、3vs4（等不中）"),
            Play("定位", "定位", "第N球直选1-6", isDirection = false)
        )
        LotteryType.K3 -> listOf(
            Play("大小", "大小", "和值≥11大、≤10小"),
            Play("单双", "单双", "和值奇数单、偶数双"),
            Play("组合", "组合", "和值大小+单双"),
            Play("和值", "和值", "和值3-18", isDirection = false),
            Play("位大小", "位大小", "第一/二/三位分别1-3小、4-6大"),
            Play("位单双", "位单双", "第一/二/三位分别单双"),
            Play("定位", "定位", "第一/二/三位指定1-6", isDirection = false),
            Play("三军", "三军", "点数至少出一次", isDirection = false),
            Play("鱼虾蟹", "鱼虾蟹", "三军映射", isDirection = false),
            Play("二不同号", "二不同号", "两个不同点数", isDirection = false),
            Play("二同号", "二同号", "两个相同点数", isDirection = false),
            Play("三不同号", "三不同号", "三个点数各不相同", isDirection = false),
            Play("三连号", "三连号", "123/234/345/456", isDirection = false),
            Play("三同号", "三同号", "111-666", isDirection = false),
            Play("长牌", "长牌", "两个不同点数同时出现", isDirection = false)
        )
        LotteryType.PC28 -> listOf(
            Play("大小", "大小", "和值14-27大、0-13小"),
            Play("单双", "单双", "和值奇数单、偶数双"),
            Play("组合", "组合", "和值大小+单双"),
            Play("极值", "极值", "极小0-5、极大22-27"),
            Play("对子", "对子", "三个号码中任意两个相同", isDirection = false),
            Play("顺子", "顺子", "三个号码连续", isDirection = false),
            Play("豹子", "豹子", "三个号码完全相同", isDirection = false),
            Play("位大小", "位大小", "第一/二/三位0-4小、5-9大"),
            Play("位单双", "位单双", "第一/二/三位单双"),
            Play("定位", "定位", "第一/二/三位指定0-9", isDirection = false),
            Play("数字", "数字", "和值0-27指定数字", isDirection = false)
        )
        LotteryType.OTHER -> emptyList()
    }

    fun playIds(type: LotteryType): List<String> = plays(type).map { it.id }

    fun labelOf(type: LotteryType, playId: String): String =
        plays(type).find { it.id == playId }?.label ?: playId

    fun summaryText(type: LotteryType): String {
        val list = plays(type)
        if (list.isEmpty()) return "暂无开放玩法"
        return list.joinToString(" · ") { it.label }
    }

    fun filterChipOptions(type: LotteryType): List<String> =
        listOf("全部") + plays(type).map { it.id }
}
