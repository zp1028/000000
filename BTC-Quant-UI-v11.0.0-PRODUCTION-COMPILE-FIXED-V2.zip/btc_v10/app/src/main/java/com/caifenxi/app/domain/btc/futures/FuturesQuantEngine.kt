package com.caifenxi.app.domain.btc.futures

import com.caifenxi.app.domain.btc.BtcCandle
import com.caifenxi.app.domain.btc.BtcConsensus
import com.caifenxi.app.domain.btc.BtcDirection
import com.caifenxi.app.domain.btc.DerivativesFeatures
import com.caifenxi.app.domain.btc.MarketRegime
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Futures quantitative trading engine: converts consensus + candles + derivatives
 * into a fully-specified FuturesSignal with ATR-based SL/TP, leverage selection,
 * liquidation-distance safety check, and optional funding-rate arbitrage.
 *
 * This is a SIGNAL GENERATOR — it never places orders. The ViewModel orchestrates
 * the actual broker calls.
 *
 * Core design: signal generation is deterministic and stateless (given the same
 * inputs, same output). The caller is responsible for calling once per cycle
 * and locking the direction until settlement.
 */
class FuturesQuantEngine {

    /**
     * Evaluate the current market state and produce a trading signal.
     *
     * Returns null when:
     * - consensus is null or FLAT
     * - confidence below configured threshold
     * - volatility too high (riskScore >= 0.90)
     * - liquidation distance < 2x stop distance (leverage too aggressive)
     * - insufficient candle data
     */
    fun evaluateSignal(
        consensus: BtcConsensus?,
        candles: List<BtcCandle>,
        config: FuturesQuantConfig,
        balance: Double,
        deriv: DerivativesFeatures? = null
    ): FuturesSignal? {
        // ── Gate 1: consensus & direction ──
        if (consensus == null || consensus.direction == BtcDirection.FLAT) return null
        if (candles.size < 20) return null

        // ── Gate 2: confidence threshold ──
        if (consensus.probability < config.minConfidence) return null

        // ── Gate 3: volatility risk ──
        if (consensus.riskScore >= 0.90) return null

        val last = candles.last()
        val entry = last.close

        // ── ATR calculation ──
        val atr = calcATR(candles, 14).coerceAtLeast(entry * 0.001)

        // ── Stop loss / take profit (ATR-based) ──
        val stopDistance = atr * config.stopLossAtrMult
        val tpDistance = atr * config.takeProfitAtrMult
        val isLong = consensus.direction == BtcDirection.UP
        val sl = if (isLong) entry - stopDistance else entry + stopDistance
        val tp = if (isLong) entry + tpDistance else entry - tpDistance

        // ── Dynamic leverage adjustment based on volatility ──
        val baseLeverage = config.leverage.coerceAtMost(config.maxLeverage)
        val adjLeverage = adjustLeverageForVolatility(baseLeverage, consensus.volatility)

        // ── Position sizing ──
        val notional = balance * config.positionSizePct / 100.0
        val margin = notional / adjLeverage.coerceAtLeast(1)
        val quantity = notional / entry

        // ── Gate 4: liquidation distance safety check ──
        // Simplified liq distance ≈ margin / quantity (price move that wipes margin)
        val liqDistance = if (quantity > 0.0) margin / quantity else Double.MAX_VALUE
        if (liqDistance < stopDistance * 2.0) {
            // Leverage too aggressive: stop would be hit before liquidation safety margin
            return null
        }

        // ── Multi-level take profit (optional) ──
        val multiTP = if (config.enableMultiTakeProfit) {
            buildMultiTakeProfit(isLong, entry, atr, config.takeProfitAtrMult)
        } else emptyList()

        // ── Funding rate arbitrage overlay ──
        val fundingReason = if (config.enableFundingArb && deriv != null) {
            checkFundingArb(deriv, consensus.direction)
        } else null

        val reasons = buildString {
            append("ATR=${"%.0f".format(atr)} ")
            append("SL=${"%.0f".format(sl)} ")
            append("TP=${"%.0f".format(tp)} ")
            append("lev=${adjLeverage}x ")
            append("qty=${"%.4f".format(quantity)} ")
            append("margin=${"%.1f".format(margin)}U ")
            append("conf=${"%.0f%%".format(consensus.probability * 100)} ")
            append("regime=${consensus.regime}")
            fundingReason?.let { append(" | FUNDING:$it") }
        }

        return FuturesSignal(
            direction = consensus.direction,
            entry = entry,
            stopLoss = max(0.0, sl),
            takeProfit = max(0.0, tp),
            quantity = quantity,
            leverage = adjLeverage,
            margin = margin,
            confidence = consensus.probability,
            atrValue = atr,
            reason = reasons,
            trailingStopPct = config.trailingStopPct,
            multiTakeProfit = multiTP
        )
    }

    /**
     * Determine if the current position should be closed based on:
     * - Consensus direction reversal (signal flip)
     * - Risk engine stop conditions
     * Returns a close reason string, or null if position should be held.
     */
    fun shouldClosePosition(
        currentPosition: FuturesPosition,
        newConsensus: BtcConsensus?,
        dailyPnlUsdt: Double,
        config: FuturesQuantConfig
    ): String? {
        if (currentPosition.isEmpty) return null

        // ── Daily loss stop ──
        if (dailyPnlUsdt <= -config.maxDailyLossUsdt) {
            return "日亏熔断 ${"%.1f".format(dailyPnlUsdt)}U <= -${config.maxDailyLossUsdt}U"
        }

        // ── Consensus reversal ──
        if (newConsensus != null && newConsensus.direction != BtcDirection.FLAT) {
            val posDir = currentPosition.direction
            val consensusDir = newConsensus.direction
            if (posDir != consensusDir && newConsensus.probability >= config.minConfidence) {
                return "信号反转 ${posDir}→${consensusDir} conf=${"%.0f%%".format(newConsensus.probability * 100)}"
            }
        }

        return null
    }

    /**
     * Adjust leverage down in high-volatility regimes to reduce liquidation risk.
     * ATR% > 1.2% → reduce to 2x; ATR% < 0.5% → allow up to config max.
     */
    private fun adjustLeverageForVolatility(baseLev: Int, atrPct: Double): Int {
        return when {
            atrPct > 0.015 -> max(1, baseLev - 1)   // extreme vol: reduce 1x
            atrPct > 0.012 -> max(1, baseLev - 1)   // high vol: reduce 1x
            atrPct < 0.004 -> min(baseLev + 1, 5)   // low vol: can increase 1x
            else -> baseLev                          // normal: keep
        }
    }

    /**
     * Build multi-level take profit: 50% at 2:1, 50% with trailing.
     */
    private fun buildMultiTakeProfit(
        isLong: Boolean,
        entry: Double,
        atr: Double,
        tpMult: Double
    ): List<TakeProfitLevel> {
        val tp1Dist = atr * tpMult * 0.6   // 60% of target for first level
        val tp2Dist = atr * tpMult         // full target for second level
        return listOf(
            TakeProfitLevel(
                price = if (isLong) entry + tp1Dist else entry - tp1Dist,
                qtyFraction = 0.5
            ),
            TakeProfitLevel(
                price = if (isLong) entry + tp2Dist else entry - tp2Dist,
                qtyFraction = 0.5
            )
        )
    }

    /**
     * Check if funding rate creates an arbitrage signal.
     * Extreme funding (z > 1.8) → crowd is one-sided → fade the crowd.
     */
    private fun checkFundingArb(deriv: DerivativesFeatures, consensusDir: BtcDirection): String? {
        if (!deriv.fundingExtreme) return null
        val z = deriv.fundingZScore
        return when {
            z > 1.8 && consensusDir == BtcDirection.DOWN ->
                "funding z=%.1f 做多拥挤→做空".format(z)
            z < -1.8 && consensusDir == BtcDirection.UP ->
                "funding z=%.1f 做空拥挤→做多".format(z)
            else -> null
        }
    }

    /**
     * Average True Range calculation (same algorithm as BtcPlanEngine).
     */
    private fun calcATR(candles: List<BtcCandle>, period: Int): Double {
        if (candles.size < 2) return 0.0
        val trs = candles.zipWithNext().map { (prev, curr) ->
            max(curr.high - curr.low, max(abs(curr.high - prev.close), abs(curr.low - prev.close)))
        }
        return trs.takeLast(period).average()
    }
}
