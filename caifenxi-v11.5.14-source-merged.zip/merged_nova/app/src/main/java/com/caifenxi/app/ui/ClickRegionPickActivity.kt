package com.caifenxi.app.ui

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import androidx.activity.ComponentActivity
import com.caifenxi.app.CaiFenXiApplication
import com.caifenxi.app.util.RuntimeLog
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * 全屏自由框选区域。
 *
 * EXTRA_MODE:
 * - [MODE_CLICK] 大小单双点击区域 → autoClickRegion*
 * - [MODE_INPUT] 输入框识别区域 → autoInputRegion*
 *
 * 坐标统一保存为相对屏幕 0～1 归一化值，并记录当时屏幕宽高。
 */
class ClickRegionPickActivity : ComponentActivity() {

    companion object {
        const val EXTRA_MODE = "region_mode"
        const val MODE_CLICK = "click"
        const val MODE_INPUT = "input"
    }

    private lateinit var pickView: RegionPickView
    private var mode: String = MODE_CLICK

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.TRANSPARENT
        mode = intent.getStringExtra(EXTRA_MODE) ?: MODE_CLICK

        val root = FrameLayout(this)
        pickView = RegionPickView(this).apply {
            titleText = when (mode) {
                MODE_INPUT -> "框选输入框区域"
                else -> "框选大小单双点击区域"
            }
            hintText = when (mode) {
                MODE_INPUT -> "拖出矩形覆盖金额输入框，确认后仅在该区域内搜索可输入节点"
                else -> "拖出矩形覆盖「大/小/单/双」按钮区域，确认后只点击该区域内的节点"
            }
            accentColor = when (mode) {
                MODE_INPUT -> Color.rgb(33, 150, 243) // blue
                else -> Color.rgb(76, 175, 80) // green
            }
        }
        try {
            val p = CaiFenXiApplication.instance.configStore.loadPrefs()
            if (mode == MODE_INPUT) {
                pickView.setNormalized(
                    p.autoInputRegionLeft,
                    p.autoInputRegionTop,
                    p.autoInputRegionRight,
                    p.autoInputRegionBottom
                )
            } else {
                pickView.setNormalized(
                    p.autoClickRegionLeft,
                    p.autoClickRegionTop,
                    p.autoClickRegionRight,
                    p.autoClickRegionBottom
                )
            }
        } catch (_: Exception) {
        }
        root.addView(
            pickView,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        )
        setContentView(root)

        pickView.onConfirm = { l, t, r, b ->
            try {
                val store = CaiFenXiApplication.instance.configStore
                val prefs = store.loadPrefs()
                val dm = resources.displayMetrics
                val sw = dm.widthPixels
                val sh = dm.heightPixels
                val updated = if (mode == MODE_INPUT) {
                    prefs.copy(
                        autoInputRegionEnabled = true,
                        autoInputRegionLeft = l,
                        autoInputRegionTop = t,
                        autoInputRegionRight = r,
                        autoInputRegionBottom = b,
                        autoInputRegionScreenW = sw,
                        autoInputRegionScreenH = sh
                    )
                } else {
                    prefs.copy(
                        autoClickRegionEnabled = true,
                        autoClickRegionLeft = l,
                        autoClickRegionTop = t,
                        autoClickRegionRight = r,
                        autoClickRegionBottom = b,
                        autoClickRegionScreenW = sw,
                        autoClickRegionScreenH = sh
                    )
                }
                store.savePrefs(updated)
                val tag = if (mode == MODE_INPUT) "输入区域" else "点击区域"
                RuntimeLog.info(
                    "AutoBet",
                    "$tag 已保存 L=${pct(l)} T=${pct(t)} R=${pct(r)} B=${pct(b)} screen=${sw}x$sh"
                )
            } catch (e: Exception) {
                RuntimeLog.warn("AutoBet", "保存框选区域失败: ${e.message}")
            }
            finish()
        }
        pickView.onCancel = { finish() }
    }

    private fun pct(v: Float) = "${(v * 100).toInt()}%"

    private class RegionPickView(context: android.content.Context) : View(context) {
        var onConfirm: ((Float, Float, Float, Float) -> Unit)? = null
        var onCancel: (() -> Unit)? = null
        var titleText: String = "框选区域"
        var hintText: String = "手指拖动选择矩形区域"
        var accentColor: Int = Color.rgb(76, 175, 80)

        private val dimPaint = Paint().apply {
            color = Color.argb(140, 0, 0, 0)
            style = Paint.Style.FILL
        }
        private val boxPaint = Paint().apply {
            style = Paint.Style.FILL
        }
        private val borderPaint = Paint().apply {
            style = Paint.Style.STROKE
            strokeWidth = 4f
            isAntiAlias = true
        }
        private val textPaint = Paint().apply {
            color = Color.WHITE
            textSize = 40f
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
        }
        private val hintPaint = Paint().apply {
            color = Color.argb(220, 255, 255, 255)
            textSize = 28f
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
        }
        private val btnPaint = Paint().apply {
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        private val btnTextPaint = Paint().apply {
            color = Color.WHITE
            textSize = 36f
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
        }

        private var startX = 0f
        private var startY = 0f
        private var curX = 0f
        private var curY = 0f
        private var dragging = false
        private var hasBox = false

        private val box = RectF()
        private val confirmBtn = RectF()
        private val cancelBtn = RectF()
        private val fullBtn = RectF()

        fun setNormalized(l: Float, t: Float, r: Float, b: Float) {
            post {
                val w = width.toFloat().coerceAtLeast(1f)
                val h = height.toFloat().coerceAtLeast(1f)
                box.set(l * w, t * h, r * w, b * h)
                hasBox = box.width() > 20 && box.height() > 20
                invalidate()
            }
        }

        override fun onDraw(canvas: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            boxPaint.color = Color.argb(80, Color.red(accentColor), Color.green(accentColor), Color.blue(accentColor))
            borderPaint.color = accentColor
            btnPaint.color = accentColor

            canvas.drawRect(0f, 0f, w, h, dimPaint)

            if (hasBox || dragging) {
                val rect = if (dragging) {
                    RectF(min(startX, curX), min(startY, curY), max(startX, curX), max(startY, curY))
                } else box
                // punch hole: redraw clear area by full dim then box highlight
                canvas.drawRect(rect, boxPaint)
                canvas.drawRect(rect, borderPaint)
            }

            canvas.drawText(titleText, w / 2f, 80f, textPaint)
            canvas.drawText(hintText, w / 2f, 130f, hintPaint)

            val btnH = 96f
            val margin = 24f
            val gap = 16f
            val btnW = (w - margin * 2 - gap * 2) / 3f
            val by = h - btnH - margin - 24f
            cancelBtn.set(margin, by, margin + btnW, by + btnH)
            fullBtn.set(margin + btnW + gap, by, margin + btnW * 2 + gap, by + btnH)
            confirmBtn.set(margin + btnW * 2 + gap * 2, by, w - margin, by + btnH)

            drawBtn(canvas, cancelBtn, "取消")
            drawBtn(canvas, fullBtn, "全屏")
            drawBtn(canvas, confirmBtn, "确认")
        }

        private fun drawBtn(canvas: Canvas, r: RectF, label: String) {
            canvas.drawRoundRect(r, 16f, 16f, btnPaint)
            val ty = r.centerY() - (btnTextPaint.descent() + btnTextPaint.ascent()) / 2
            canvas.drawText(label, r.centerX(), ty, btnTextPaint)
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    val x = event.x
                    val y = event.y
                    if (confirmBtn.contains(x, y) || cancelBtn.contains(x, y) || fullBtn.contains(x, y)) {
                        return true
                    }
                    startX = x
                    startY = y
                    curX = x
                    curY = y
                    dragging = true
                    hasBox = false
                    invalidate()
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (dragging) {
                        curX = event.x
                        curY = event.y
                        invalidate()
                    }
                    return true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    val x = event.x
                    val y = event.y
                    if (!dragging) {
                        when {
                            cancelBtn.contains(x, y) -> onCancel?.invoke()
                            fullBtn.contains(x, y) -> {
                                box.set(0f, 0f, width.toFloat(), height.toFloat())
                                hasBox = true
                                invalidate()
                            }
                            confirmBtn.contains(x, y) -> confirmNormalized()
                        }
                        return true
                    }
                    dragging = false
                    val l = min(startX, curX)
                    val t = min(startY, curY)
                    val r = max(startX, curX)
                    val b = max(startY, curY)
                    if (abs(r - l) > 20 && abs(b - t) > 20) {
                        box.set(l, t, r, b)
                        hasBox = true
                    }
                    // 点击按钮区
                    if (cancelBtn.contains(x, y)) onCancel?.invoke()
                    else if (fullBtn.contains(x, y)) {
                        box.set(0f, 0f, width.toFloat(), height.toFloat())
                        hasBox = true
                    } else if (confirmBtn.contains(x, y)) confirmNormalized()
                    invalidate()
                    return true
                }
            }
            return super.onTouchEvent(event)
        }

        private fun confirmNormalized() {
            if (!hasBox) return
            val w = width.toFloat().coerceAtLeast(1f)
            val h = height.toFloat().coerceAtLeast(1f)
            val l = (box.left / w).coerceIn(0f, 1f)
            val t = (box.top / h).coerceIn(0f, 1f)
            val r = (box.right / w).coerceIn(0f, 1f)
            val b = (box.bottom / h).coerceIn(0f, 1f)
            if (r - l < 0.02f || b - t < 0.02f) return
            onConfirm?.invoke(l, t, r, b)
        }
    }
}
