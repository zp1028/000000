package com.caifenxi.app.domain.btc.runtime

/** Deterministic signal lifecycle; a signal expires instead of being reused across horizons. */
object BtcSignalLifecycle {
    enum class Status { CREATED, VALIDATING, QUALIFIED, ARMED, EXECUTING, OPEN, CLOSED, SETTLED, EXPIRED, INVALIDATED, REPLACED }

    data class Signal(
        val id: String,
        val timeframe: String,
        val direction: String,
        val createdAt: Long,
        val expiresAt: Long,
        val status: Status = Status.CREATED,
        val reason: String = ""
    ) {
        fun isExpired(now: Long = System.currentTimeMillis()): Boolean = now >= expiresAt
    }

    fun create(timeframe: String, direction: String, now: Long = System.currentTimeMillis()): Signal {
        val ttl = when (timeframe) { "5m" -> 5 * 60_000L; "1h" -> 60 * 60_000L; else -> 15 * 60_000L }
        val id = "sig-${timeframe}-${now}"
        return Signal(id, timeframe, direction, now, now + ttl, Status.CREATED)
    }

    fun advance(signal: Signal, target: Status, now: Long = System.currentTimeMillis()): Signal {
        if (signal.isExpired(now) && target !in setOf(Status.CLOSED, Status.SETTLED)) {
            return signal.copy(status = Status.EXPIRED, reason = "signal TTL elapsed")
        }
        return signal.copy(status = target)
    }
}
