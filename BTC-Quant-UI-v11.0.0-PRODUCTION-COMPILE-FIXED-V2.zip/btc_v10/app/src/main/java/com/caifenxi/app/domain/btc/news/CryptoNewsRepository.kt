package com.caifenxi.app.domain.btc.news

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import java.util.UUID

/**
 * Collects public crypto headlines.
 * Primary: CoinGecko status / trending style public endpoints where available;
 * Fallback: built-in neutral empty list so offline PAPER still runs.
 *
 * Does not scrape full article bodies (copyright / ToS).
 */
class CryptoNewsRepository(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()
) {
    private var cache: NewsSnapshot? = null
    private var cacheAt = 0L

    suspend fun snapshot(force: Boolean = false): NewsSnapshot = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        if (!force && cache != null && now - cacheAt < 5 * 60_000L) return@withContext cache!!
        // Network/rate-limit failure must not fabricate a news item that looks
        // like a real headline. Empty news means "no verified news input".
        val items = runCatching { fetchCoinGeckoNewsish() }.getOrElse { emptyList() }
        val weighted = items.map { NewsImpactEngine.impact(it, now) }
        val net = if (weighted.isEmpty()) 0.0 else weighted.sumOf { it.score * it.weight } / weighted.sumOf { it.weight }.coerceAtLeast(0.0001)
        val high = weighted.count { it.weight >= 0.45 }
        val swan = items.any { NewsImpactEngine.isBlackSwan(it) }
        NewsSnapshot(
            asOf = now,
            items = items.sortedByDescending { it.publishedAt }.take(30),
            netSentiment = net.coerceIn(-1.0, 1.0),
            highImpactCount = high,
            blackSwan = swan,
            topHeadlines = items.sortedByDescending { it.impactScore }.take(5).map { it.title }
        ).also {
            cache = it
            cacheAt = now
        }
    }

    /** Public search trending coins as weak proxy headlines when dedicated news API absent. */
    private fun fetchCoinGeckoNewsish(): List<NewsItem> {
        val req = Request.Builder()
            .url("https://api.coingecko.com/api/v3/search/trending")
            .get()
            .header("Accept", "application/json")
            .build()
        client.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) return emptyList()
            val body = resp.body?.string().orEmpty()
            val root = JSONObject(body)
            val coins = root.optJSONArray("coins") ?: return emptyList()
            val now = System.currentTimeMillis()
            return buildList {
                for (i in 0 until coins.length()) {
                    val item = coins.getJSONObject(i).optJSONObject("item") ?: continue
                    val name = item.optString("name")
                    val symbol = item.optString("symbol")
                    val title = "Trending: $name ($symbol)"
                    val summary = "CoinGecko trending rank ${item.optInt("score", i)}"
                    val (sent, impact) = NewsSentiment.score(title, summary)
                    add(
                        NewsItem(
                            id = item.optString("id", UUID.randomUUID().toString()),
                            title = title,
                            summary = summary,
                            source = "coingecko-trending",
                            publishedAt = now - i * 60_000L,
                            entities = NewsSentiment.entities("$title $symbol BTC"),
                            tags = NewsSentiment.tags(title) + "trending",
                            sentiment = sent * 0.3, // weak signal
                            impactScore = (0.2 + impact * 0.3).coerceAtMost(0.5)
                        )
                    )
                }
            }
        }
    }

}
