package com.caifenxi.app.domain.btc

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max

/**
 * Binance public futures WebSocket feed used only for live UI/market state.
 * REST remains the source for historical candles and the HS engine refresh.
 * WebSocket reconnects with bounded backoff; it never controls order execution.
 */
class BinanceLiveMarketStream(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .pingInterval(15, TimeUnit.SECONDS)
        .build()
) {
    data class LiveTick(val symbol: String, val price: Double, val eventTime: Long)
    data class LiveKline(val symbol: String, val interval: String, val candle: BtcCandle, val closed: Boolean)
    data class LiveDepth(val symbol: String, val bids: List<BinanceOrderBookRepository.Level>, val asks: List<BinanceOrderBookRepository.Level>, val eventTime: Long, val updateId: Long)

    interface Listener {
        fun onTick(tick: LiveTick)
        fun onKline(kline: LiveKline)
        fun onDepth(depth: LiveDepth)
        fun onStatus(status: String, detail: String? = null)
    }

    private var socket: WebSocket? = null
    private var job: Job? = null
    private val running = AtomicBoolean(false)
    private val scope = CoroutineScope(Dispatchers.IO)
    private var symbol = "BTCUSDT"

    fun start(symbol: String, listener: Listener) {
        stop()
        this.symbol = symbol.uppercase()
        running.set(true)
        job = scope.launch {
            var backoff = 1_000L
            while (isActive && running.get()) {
                val connected = connect(listener)
                if (connected) {
                    // 连接存活期间 connect() 会一直等待，不会每秒创建第二条 socket。
                    backoff = 1_000L
                    if (running.get()) delay(1_000L)
                } else {
                    listener.onStatus("DISCONNECTED", "WebSocket connect failed")
                    if (running.get()) delay(backoff)
                    backoff = max(1_000L, (backoff * 2).coerceAtMost(15_000L))
                }
            }
        }
    }

    fun stop() {
        running.set(false)
        job?.cancel()
        job = null
        socket?.close(1000, "client stop")
        socket = null
    }

    private suspend fun connect(listener: Listener): Boolean {
        val s = symbol.lowercase()
        // Futures stream supplies mark/trade-adjacent price and top-20 depth.
        val streams = listOf("${s}@aggTrade", "${s}@depth20@100ms", "${s}@kline_5m", "${s}@kline_15m", "${s}@kline_1h").joinToString("/")
        val request = Request.Builder()
            .url("wss://fstream.binance.com/stream?streams=$streams")
            .header("User-Agent", "BTCQuant/16.2")
            .build()
        val opened = kotlinx.coroutines.CompletableDeferred<Boolean>()
        val ended = kotlinx.coroutines.CompletableDeferred<Unit>()
        socket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                listener.onStatus("LIVE", "Binance futures WebSocket")
                if (!opened.isCompleted) opened.complete(true)
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                runCatching { parse(text, listener) }.onFailure { listener.onStatus("LIVE", "parse: ${it.message}") }
            }

            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                listener.onStatus("RECONNECTING", "closing $code $reason")
                webSocket.close(code, reason)
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                listener.onStatus("RECONNECTING", "closed $code")
                if (!opened.isCompleted) opened.complete(false)
                if (!ended.isCompleted) ended.complete(Unit)
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                listener.onStatus("RECONNECTING", t.message ?: "socket failure")
                if (!opened.isCompleted) opened.complete(false)
                if (!ended.isCompleted) ended.complete(Unit)
            }
        })
        val ok = opened.await()
        if (!ok) return false
        // 真正连接成功后保持当前 socket，直到服务端关闭/网络失败。
        ended.await()
        return true
    }

    private fun parse(text: String, listener: Listener) {
        val root = JSONObject(text)
        val data = root.optJSONObject("data") ?: root
        val event = data.optString("e")
        val eventTime = data.optLong("E", System.currentTimeMillis())
        when (event) {
            "aggTrade" -> {
                val p = data.optString("p").toDoubleOrNull() ?: return
                if (p > 0.0) listener.onTick(LiveTick(symbol, p, eventTime))
            }
            "depthUpdate" -> {
                fun levels(key: String): List<BinanceOrderBookRepository.Level> {
                    val arr = data.optJSONArray(key) ?: return emptyList()
                    return buildList {
                        for (i in 0 until arr.length()) {
                            val row = arr.optJSONArray(i) ?: continue
                            val p = row.optString(0).toDoubleOrNull() ?: continue
                            val q = row.optString(1).toDoubleOrNull() ?: continue
                            if (p > 0.0 && q >= 0.0) add(BinanceOrderBookRepository.Level(p, q))
                        }
                    }
                }
                listener.onDepth(LiveDepth(symbol, levels("b"), levels("a"), eventTime, data.optLong("u", 0L)))
            }
            "kline" -> {
                val k = data.optJSONObject("k") ?: return
                val interval = k.optString("i")
                val openTime = k.optLong("t", 0L)
                val open = k.optString("o").toDoubleOrNull() ?: return
                val high = k.optString("h").toDoubleOrNull() ?: return
                val low = k.optString("l").toDoubleOrNull() ?: return
                val close = k.optString("c").toDoubleOrNull() ?: return
                val volume = k.optString("v").toDoubleOrNull() ?: 0.0
                if (openTime > 0L && open > 0 && high >= low && close > 0) {
                    listener.onKline(LiveKline(symbol, interval, BtcCandle(openTime, open, high, low, close, volume), k.optBoolean("x", false)))
                }
            }
        }
    }
}
