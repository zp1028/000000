package com.caifenxi.app.data.api

import com.caifenxi.app.domain.model.ApiConfig
import com.caifenxi.app.domain.model.DrawRecord
import com.caifenxi.app.domain.model.LotteryConfig
import com.caifenxi.app.domain.model.LotteryType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.OkHttpClient
import okhttp3.Request
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.concurrent.TimeUnit

class LotteryApiClient {

    private val client = OkHttpClient.Builder()
        .connectTimeout(ApiConfig.TIMEOUT_MS, TimeUnit.MILLISECONDS)
        .readTimeout(ApiConfig.TIMEOUT_MS, TimeUnit.MILLISECONDS)
        .build()

    private val json = Json { ignoreUnknownKeys = true; isLenient = true }
    private val dayFmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    suspend fun fetchHistory(config: LotteryConfig, days: Int = ApiConfig.DEFAULT_HISTORY_DAYS): List<DrawRecord> =
        withContext(Dispatchers.IO) {
            val dayList = (0 until days).map { offset ->
                Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -offset) }.time
                    .let { dayFmt.format(it) }
            }
            val endpoint = when (config.type) {
                LotteryType.LUCK20 -> "LuckTwenty/getBaseLuckTwentyList.do"
                LotteryType.PKS -> "pks/getPksHistoryList.do"
            }
            coroutineScope {
                val results = dayList.map { day ->
                    async { fetchDayItems(endpoint, config.code, day) }
                }.awaitAll()
                val rows = results.flatten().mapNotNull { parseItem(it, config) }
                rows.distinctBy { it.issue }.sortedBy { it.issue.toLongOrNull() ?: 0L }
            }
        }

    suspend fun fetchLatest(config: LotteryConfig): DrawRecord? = withContext(Dispatchers.IO) {
        val paths = when (config.type) {
            LotteryType.LUCK20 -> listOf(
                "LuckTwenty/getBaseLuckTewnty.do",
                "LuckTwenty/getBaseLuckTwenty.do"
            )
            LotteryType.PKS -> listOf("pks/getLotteryPksInfo.do", "pks/getPksInfo.do", "pks/getBasePks.do")
        }
        for (base in listOf(ApiConfig.PRIMARY_BASE, ApiConfig.ALT_BASE)) {
            for (path in paths) {
                try {
                    val body = getString("$base/$path?lotCode=${config.code}")
                    val root = json.parseToJsonElement(body) as? JsonObject ?: continue
                    val data = root["result"]?.jsonObject?.get("data")?.jsonObject
                        ?: root["data"]?.jsonObject
                        ?: continue
                    val parsed = parseItem(data, config) ?: continue
                    // 跳过过期数据:部分端点会返回固定示例(如北京PK10 停在 2020 年),
                    // 防止把旧期号当成「最新一期」污染首页并误结算待开订单
                    if (isStaleDrawTime(parsed.drawTime)) continue
                    return@withContext parsed
                } catch (_: Exception) {
                }
            }
        }
        // 兜底:api16868 上 PKS 类「最新一期」专用端点(getPksInfo.do / getBasePks.do)
        // 已全部 404,导致极速飞艇/极速赛车等彩种自动刷新永远拿不到新期。
        // 改用当日历史列表的第一条(该接口按时间倒序,首条即最新已完成期)。
        fetchLatestFromHistoryList(config)
    }

    /** 通过历史列表接口获取最新一期(今天为空时回退查昨天,例如刚过零点) */
    private fun fetchLatestFromHistoryList(config: LotteryConfig): DrawRecord? {
        val endpoint = when (config.type) {
            LotteryType.LUCK20 -> "LuckTwenty/getBaseLuckTwentyList.do"
            LotteryType.PKS -> "pks/getPksHistoryList.do"
        }
        val today = Calendar.getInstance()
        val yesterday = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -1) }
        val dayList = listOf(dayFmt.format(today.time), dayFmt.format(yesterday.time))
        for (day in dayList) {
            for (base in listOf(ApiConfig.PRIMARY_BASE, ApiConfig.ALT_BASE)) {
                try {
                    val body = getString("$base/$endpoint?lotCode=${config.code}&date=$day")
                    val arr = extractDataArray(body) ?: continue
                    // 列表按时间倒序,首条即最新
                    val first = arr.firstOrNull() as? JsonObject ?: continue
                    parseItem(first, config)?.let { return it }
                } catch (_: Exception) {
                }
            }
        }
        return null
    }

    /** 判断开奖时间是否已过期:距今超过 2 天视为无效数据(防止旧示例污染最新一期) */
    private fun isStaleDrawTime(drawTime: String): Boolean {
        if (drawTime.isBlank()) return true
        return try {
            val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
            val t = fmt.parse(drawTime.take(19).replace('T', ' ')) ?: return true
            System.currentTimeMillis() - t.time > 2L * 24 * 3600_000
        } catch (_: Exception) {
            true
        }
    }

    /** 从接口响应中提取 data 数组(兼容裸数组与 result.data 两种结构) */
    private fun extractDataArray(body: String): JsonArray? {
        return try {
            when (val root = json.parseToJsonElement(body)) {
                is JsonArray -> root
                is JsonObject -> root["result"]?.jsonObject?.get("data")?.jsonArray
                    ?: root["data"]?.jsonArray
                else -> null
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun fetchDayItems(endpoint: String, lotCode: Int, day: String): List<JsonObject> {
        for (base in listOf(ApiConfig.PRIMARY_BASE, ApiConfig.ALT_BASE)) {
            try {
                val body = getString("$base/$endpoint?lotCode=$lotCode&date=$day")
                val root = json.parseToJsonElement(body)
                val arr: JsonArray = when (root) {
                    is JsonArray -> root
                    is JsonObject -> {
                        root["result"]?.jsonObject?.get("data")?.jsonArray
                            ?: root["data"]?.jsonArray
                            ?: continue
                    }
                    else -> continue
                }
                val items = arr.mapNotNull { it as? JsonObject }
                if (items.isNotEmpty()) return items
            } catch (_: Exception) {
            }
        }
        return emptyList()
    }

    private fun getString(url: String): String {
        var lastError: Exception? = null
        repeat(ApiConfig.RETRIES + 1) { attempt ->
            try {
                val req = Request.Builder()
                    .url(url)
                    .header("User-Agent", "Mozilla/5.0")
                    .header("Accept", "application/json")
                    .get()
                    .build()
                client.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) error("HTTP ${resp.code}")
                    val body = resp.body?.string()?.takeIf { it.isNotBlank() }
                        ?: error("empty body")
                    return body
                }
            } catch (e: Exception) {
                lastError = e
                if (attempt < ApiConfig.RETRIES) {
                    Thread.sleep(250L shl attempt)
                }
            }
        }
        throw lastError ?: IllegalStateException("request failed")
    }

    private fun parseItem(it: JsonObject, config: LotteryConfig): DrawRecord? {
        fun str(vararg keys: String): String {
            for (k in keys) {
                val p = it[k]?.jsonPrimitive ?: continue
                // 兼容数字字段(期号等):contentOrNull 只对字符串返回内容,
                // 数字(如 preDrawIssue:751963)会返回 null,导致整期被丢弃
                val v = if (p is JsonNull) null else p.content
                if (!v.isNullOrBlank()) return v
            }
            return ""
        }
        fun intOrNull(vararg keys: String): Int? {
            for (k in keys) {
                val p = it[k]?.jsonPrimitive
                val n = p?.intOrNull ?: p?.contentOrNull?.toIntOrNull()
                if (n != null) return n
            }
            return null
        }

        val issue = str("preDrawIssue", "drawIssue", "issue", "expect")
        if (issue.isBlank()) return null
        val time = str("preDrawTime", "drawTime", "time")
        val code = str("preDrawCode", "drawCode", "openCode", "code")
        val nums = code.split(",", " ", "|")
            .mapNotNull { it.trim().toIntOrNull() }
            .filter { it > 0 }
        if (nums.isEmpty()) return null

        return when (config.type) {
            LotteryType.LUCK20 -> {
                if (nums.size < 20) return null
                val take = nums.take(20)
                if (take.size != 20 || take.any { it !in 1..80 } || take.distinct().size != 20) return null
                val sum = intOrNull("sumNum", "sum") ?: take.sum()
                val apiDx = intOrNull("sumBigSmall")
                val apiDs = intOrNull("sumSingleDouble")
                val dx = when (apiDx) {
                    1 -> "大"
                    0 -> "小"
                    else -> if (sum >= 810) "大" else "小"
                }
                val ds = when (apiDs) {
                    1 -> "单"
                    0 -> "双"
                    else -> if (sum % 2 == 1) "单" else "双"
                }
                DrawRecord(
                    lotteryKey = config.key,
                    issue = issue,
                    drawTime = time,
                    numbers = take,
                    sum = sum,
                    dx = dx,
                    ds = ds,
                    combo = dx + ds,
                    extra = nums.getOrNull(20),
                    nextIssue = str("drawIssue").ifBlank { null }
                )
            }
            LotteryType.PKS -> {
                if (nums.size < 10) return null
                val take = nums.take(10)
                if (take.size != 10 || take.any { it !in 1..10 } || take.distinct().size != 10) return null
                val guanYa = take[0] + take[1]
                val dx = if (guanYa > 11) "大" else "小"
                val ds = if (guanYa % 2 == 1) "单" else "双"
                DrawRecord(
                    lotteryKey = config.key,
                    issue = issue,
                    drawTime = time,
                    numbers = take,
                    sum = guanYa,
                    dx = dx,
                    ds = ds,
                    combo = dx + ds,
                    nextIssue = str("drawIssue").ifBlank { null }
                )
            }
        }
    }
}
