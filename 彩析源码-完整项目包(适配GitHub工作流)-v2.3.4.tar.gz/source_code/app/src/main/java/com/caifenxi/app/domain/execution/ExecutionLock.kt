package com.caifenxi.app.domain.execution

/**
 * 执行锁：范围 = lotteryKey + issue + cmdId。
 * 防止线程A执行的同时线程B重复执行同一任务。
 */
class ExecutionLock {

    private val locks = java.util.concurrent.ConcurrentHashMap<String, java.util.concurrent.locks.ReentrantLock>()

    /** 对指定任务上锁并执行 */
    fun <T> withLock(lotteryKey: String, issue: String, cmdId: String, block: () -> T): T {
        val key = key(lotteryKey, issue, cmdId)
        val lock = locks.computeIfAbsent(key) { java.util.concurrent.locks.ReentrantLock() }
        lock.lock()
        try {
            return block()
        } finally {
            lock.unlock()
            // 只清理无竞争且未被持有的锁，避免 map 无限膨胀
            if (lock.tryLock()) {
                try {
                    if (!lock.hasQueuedThreads()) {
                        locks.remove(key, lock)
                    }
                } finally {
                    lock.unlock()
                }
            }
        }
    }

    /** 仅按彩种+期号上锁（任务尚不存在时用） */
    fun <T> withLock(lotteryKey: String, issue: String, block: () -> T): T =
        withLock(lotteryKey, issue, "_", block)

    fun clear() {
        locks.clear()
    }

    private fun key(lotteryKey: String, issue: String, cmdId: String): String =
        "$lotteryKey|$issue|$cmdId"
}
