package com.caifenxi.app.domain.btc.polymarket.strategy

/** A point-in-time Polymarket/BTC observation used by offline research. */
data class PolymarketResearchRow(
    val timestampMs: Long,
    val marketId: String,
    val strategyWindowId: String,
    val currentBtc: Double?,
    val priceToBeat: Double?,
    val upPrice: Double,
    val downPrice: Double,
    val upAsk: Double,
    val downAsk: Double,
    val spread: Double,
    val liquidity: Double,
    val btcReturn15m: Double = 0.0,
    val volumeRatio: Double = 1.0,
    val remainingSec: Long? = null,
    /** 1 = YES/UP settled, 0 = NO/DOWN settled, null = unresolved. */
    val settledYes: Boolean? = null
)

data class PolymarketStrategyResearchMetric(
    val strategyId: String,
    val samples: Int,
    val trainSamples: Int,
    val testSamples: Int,
    val testWinRate: Double,
    val testProfitFactor: Double,
    val testExpectancy: Double,
    val testMaxDrawdown: Double,
    val testNetReturn: Double,
    val testSharpeLike: Double,
    val stability: Double,
    val costDrag: Double,
    val score: Double
)

data class PolymarketStrategyLifecycle(
    val strategyId: String,
    val status: PolymarketStrategyPool.Status,
    val weight: Double,
    val score: Double,
    val reason: String,
    val updatedAtMs: Long = System.currentTimeMillis()
)
