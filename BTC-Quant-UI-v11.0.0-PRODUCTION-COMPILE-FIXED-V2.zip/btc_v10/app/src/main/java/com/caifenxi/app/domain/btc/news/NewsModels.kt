package com.caifenxi.app.domain.btc.news

/**
 * Normalized news item for plan pool / AI context.
 * Prefer summaries over full copyrighted text.
 */
data class NewsItem(
    val id: String,
    val title: String,
    val summary: String,
    val source: String,
    val url: String = "",
    val publishedAt: Long,
    val collectedAt: Long = System.currentTimeMillis(),
    val entities: List<String> = emptyList(),
    val tags: List<String> = emptyList(),
    /** -1 bearish … +1 bullish */
    val sentiment: Double = 0.0,
    /** 0..1 relative impact heuristic */
    val impactScore: Double = 0.3
)

data class NewsSnapshot(
    val asOf: Long,
    val items: List<NewsItem>,
    /** Aggregate -1..1 weighted by impact */
    val netSentiment: Double,
    val highImpactCount: Int,
    val blackSwan: Boolean,
    val topHeadlines: List<String>
)
