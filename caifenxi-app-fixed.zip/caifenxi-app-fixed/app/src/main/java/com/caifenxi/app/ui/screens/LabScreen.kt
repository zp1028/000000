package com.caifenxi.app.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.caifenxi.app.domain.plan.PlanPool
import com.caifenxi.app.ui.MainViewModel
import kotlin.math.roundToInt

@Composable
fun LabScreen(vm: MainViewModel) {
    val lab = vm.labRows.value
    val plans = vm.planRows.value

    LazyColumn(Modifier.fillMaxSize().padding(16.dp)) {
        item {
            Text("🧪 模型实验室", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(
                "滚动验证 · 综合分非未来中奖概率 · 计划池 ${PlanPool.STRATEGY_VERSION}（${PlanPool.ALL.size}）",
                style = MaterialTheme.typography.bodySmall
            )
            Spacer(Modifier.height(8.dp))
            Button(onClick = { vm.runBacktest() }, enabled = !vm.backtestRunning.value) {
                Text(if (vm.backtestRunning.value) "验证中…" else "重新滚动验证")
            }
            Spacer(Modifier.height(12.dp))
            Text("算法排行（大小/单双计划）", fontWeight = FontWeight.Bold)
        }
        if (lab.isEmpty()) {
            item { Text("数据不足或未回测。请先首页加载，再点重新验证。") }
        } else {
            items(lab) { row ->
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Column(Modifier.padding(12.dp)) {
                        Text(row.name, fontWeight = FontWeight.Bold)
                        Text("${row.algo} · 窗${row.window} · n=${row.sample} · 命中${row.hits} · 率${(row.hitRate * 100).roundToInt()}% · 分${"%.1f".format(row.score)}")
                    }
                }
            }
        }
        item {
            Spacer(Modifier.height(16.dp))
            Text("完整计划池", fontWeight = FontWeight.Bold)
        }
        items(PlanPool.ALL.groupBy { it.category }.toList()) { (cat, list) ->
            Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                Column(Modifier.padding(12.dp)) {
                    Text("$cat（${list.size}）", fontWeight = FontWeight.SemiBold)
                    list.forEach {
                        val rt = plans.find { p -> p.first.planId == it.planId }?.second
                        val extra = if (rt != null) " · 分${"%.0f".format(rt.score)} 权${"%.2f".format(rt.weight)} ${rt.status}" else ""
                        Text(" · ${it.planName} [${it.algorithm}/${it.window}]$extra")
                    }
                }
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}
