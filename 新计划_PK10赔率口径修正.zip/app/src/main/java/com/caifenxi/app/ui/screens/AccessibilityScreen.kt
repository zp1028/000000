package com.caifenxi.app.ui.screens

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.caifenxi.app.domain.model.AutoClickPostAction
import com.caifenxi.app.domain.model.LotteryPlayCatalog
import com.caifenxi.app.domain.model.AutoClickPostActionsCodec
import com.caifenxi.app.service.AutoBetAccessibilityService
import com.caifenxi.app.service.AutoBetController
import com.caifenxi.app.service.DataSyncService
import com.caifenxi.app.ui.ClickRegionPickActivity
import com.caifenxi.app.ui.MainViewModel
import com.caifenxi.app.ui.components.CaptionMuted
import com.caifenxi.app.ui.components.GlobalCard
import com.caifenxi.app.ui.components.PrimaryButton
import com.caifenxi.app.ui.components.SectionTitle
import com.caifenxi.app.util.AndroidCompat
import com.caifenxi.app.ui.theme.CaiTokens
import java.util.UUID

@Composable
private fun A11ySwitch(title: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(title, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

/**
 * 无障碍跟投独立页：权限、固定步骤、后续可编排动作、区域框选、试点击。
 */
@Composable
fun AccessibilityScreen(vm: MainViewModel) {
    val context = LocalContext.current
    val p = vm.prefs.value
    var a11yOn by remember { mutableStateOf(AutoBetController.isAccessibilityEnabled(context)) }
    var serviceRunning by remember { mutableStateOf(AutoBetAccessibilityService.isRunning()) }
    var postActions by remember(p.autoClickPostActionsJson) {
        mutableStateOf(AutoClickPostActionsCodec.decode(p.autoClickPostActionsJson))
    }
    var newText by remember { mutableStateOf("") }

    fun refreshFlags() {
        a11yOn = AutoBetController.isAccessibilityEnabled(context)
        serviceRunning = AutoBetAccessibilityService.isRunning()
    }

    fun savePostActions(list: List<AutoClickPostAction>) {
        postActions = list
        vm.updatePrefs { it.copy(autoClickPostActionsJson = AutoClickPostActionsCodec.encode(list)) }
    }

    LaunchedEffect(Unit) { refreshFlags() }

    LazyColumn(
        Modifier
            .fillMaxSize()
            .padding(horizontal = CaiTokens.ScreenHPadding),
        verticalArrangement = Arrangement.spacedBy(CaiTokens.S8),
        contentPadding = PaddingValues(top = CaiTokens.S16, bottom = CaiTokens.ScreenBottom)
    ) {
        item {
            Text("无障碍跟投", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            CaptionMuted("固定：①大小单双 → ②倍投/复原数字；之后动作可增删排序，每条文案可单独框选区域")
        }

        item {
            SectionTitle("权限与总控")
            GlobalCard {
                Text(
                    when {
                        !a11yOn -> "系统无障碍：未开启"
                        !serviceRunning -> "无障碍：已开但未连接，请重开一次服务"
                        else -> "无障碍：已就绪"
                    },
                    fontWeight = FontWeight.SemiBold
                )
                PrimaryButton("打开系统无障碍设置", {
                    AutoBetController.openAccessibilitySettings(context)
                    refreshFlags()
                }, Modifier.fillMaxWidth())
                Spacer(Modifier.height(6.dp))
                A11ySwitch("启用真实自动点击", p.autoClickEnabled) { enabled ->
                    if (enabled && !AutoBetController.isAccessibilityEnabled(context)) {
                        AutoBetController.openAccessibilitySettings(context)
                    }
                    vm.updatePrefs { it.copy(autoClickEnabled = enabled) }
                    refreshFlags()
                }
                A11ySwitch("仅模拟（不真实点击）", p.autoClickSimulateOnly) {
                    vm.updatePrefs { pref -> pref.copy(autoClickSimulateOnly = it) }
                }
                A11ySwitch("跟随挂机预测来源", p.autoClickFollowBetSource) {
                    vm.updatePrefs { pref -> pref.copy(autoClickFollowBetSource = it) }
                }
                val lotteryKey = vm.currentLottery.value.key
                val srcDesc = remember(p.autoClickFollowBetSource, lotteryKey, p.floatingSource) {
                    AutoBetController.describeClickSource(context, p, lotteryKey)
                }
                CaptionMuted(srcDesc + "（关则仍用设置页悬浮窗来源）")
                A11ySwitch("无障碍控制悬浮窗", p.autoClickPanelEnabled) { enabled ->
                    if (enabled && !Settings.canDrawOverlays(context)) {
                        try {
                            context.startActivity(
                                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        } catch (_: Exception) {
                        }
                    }
                    vm.updatePrefs { it.copy(autoClickPanelEnabled = enabled) }
                    AndroidCompat.startDataSyncService(
                        context,
                        Intent(context, DataSyncService::class.java).setAction(DataSyncService.ACTION_REFRESH_OVERLAY)
                    )
                }
                A11ySwitch("显示点击红点", p.autoClickShowFeedback) {
                    vm.updatePrefs { pref -> pref.copy(autoClickShowFeedback = it) }
                }
            }
        }

        item {
            SectionTitle("① 固定 · 大小单双")
            GlobalCard {
                A11ySwitch("执行大小单双", p.autoExecClickDxDs) {
                    vm.updatePrefs { pref -> pref.copy(autoExecClickDxDs = it) }
                }
                A11ySwitch("点大小", p.autoClickDx) { vm.updatePrefs { pref -> pref.copy(autoClickDx = it) } }
                A11ySwitch("点单双", p.autoClickDs) { vm.updatePrefs { pref -> pref.copy(autoClickDs = it) } }
                Text("投注方向", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Row(
                    Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = p.autoClickBetMode != "reverse",
                        onClick = { vm.updatePrefs { it.copy(autoClickBetMode = "forward") } },
                        label = { Text("正投") }
                    )
                    FilterChip(
                        selected = p.autoClickBetMode == "reverse",
                        onClick = { vm.updatePrefs { it.copy(autoClickBetMode = "reverse") } },
                        label = { Text("反投") }
                    )
                }
                CaptionMuted(
                    if (p.autoClickBetMode == "reverse")
                        "反投：预测大→点小，单→点双；组合大单→小双、大双→小单（预测号码不取反）"
                    else
                        "正投：按预测原文点击大小/单双/组合"
                )
                Text(
                    if (p.autoClickRegionEnabled)
                        "点击区域 ✓ ${(p.autoClickRegionLeft * 100).toInt()}%–${(p.autoClickRegionRight * 100).toInt()}% × ${(p.autoClickRegionTop * 100).toInt()}%–${(p.autoClickRegionBottom * 100).toInt()}%"
                    else "点击区域：未限制（全屏搜）",
                    fontSize = 12.sp
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PrimaryButton("框选大小单双区域", {
                        context.startActivity(
                            Intent(context, ClickRegionPickActivity::class.java)
                                .putExtra(ClickRegionPickActivity.EXTRA_MODE, ClickRegionPickActivity.MODE_CLICK)
                        )
                    }, Modifier.weight(1f))
                    PrimaryButton("开关区域", {
                        vm.updatePrefs { it.copy(autoClickRegionEnabled = !it.autoClickRegionEnabled) }
                    }, ghost = true, modifier = Modifier.weight(1f))
                }
            }
        }

        item {
            SectionTitle("② 固定 · 倍投/复原数字")
            GlobalCard {
                A11ySwitch("启用点金额数字", p.autoInputEnabled) {
                    vm.updatePrefs { pref -> pref.copy(autoInputEnabled = it) }
                }
                CaptionMuted("上期对→复原 ${p.autoInputBaseAmount} · 上期错→倍投 ${p.autoInputMultAmount}")
                var base by remember(p.autoInputBaseAmount) { mutableStateOf(p.autoInputBaseAmount.toString()) }
                var mult by remember(p.autoInputMultAmount) { mutableStateOf(p.autoInputMultAmount.toString()) }
                OutlinedTextField(base, { base = it.filter { c -> c.isDigit() || c == '.' }.take(8) }, label = { Text("复原数字") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(mult, { mult = it.filter { c -> c.isDigit() || c == '.' }.take(8) }, label = { Text("倍投数字") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                PrimaryButton("应用金额设置", {
                    vm.updatePrefs {
                        it.copy(
                            autoInputBaseAmount = base.toDoubleOrNull() ?: it.autoInputBaseAmount,
                            autoInputMultAmount = mult.toDoubleOrNull() ?: it.autoInputMultAmount
                        )
                    }
                }, Modifier.fillMaxWidth())
                Text(
                    if (p.autoInputRegionEnabled) "数字键盘区域 ✓ 已框选" else "数字键盘区域：未框选（可回落全屏）",
                    fontSize = 12.sp
                )
                PrimaryButton("框选数字键盘区域", {
                    context.startActivity(
                        Intent(context, ClickRegionPickActivity::class.java)
                            .putExtra(ClickRegionPickActivity.EXTRA_MODE, ClickRegionPickActivity.MODE_INPUT)
                    )
                }, Modifier.fillMaxWidth())
            }
        }

        item {
            SectionTitle("③ 后续动作（可排序 / 增删）")
            CaptionMuted("在①②之后执行。第一项优先「组合」、第二「预测数字」；可适配当前彩种玩法。")
            val lot = vm.currentLottery.value
            Text("当前彩种：${lot.name}", fontWeight = FontWeight.SemiBold)
            CaptionMuted("可下注玩法：" + LotteryPlayCatalog.summaryText(lot.type))
            PrimaryButton(
                "按当前彩种重置后续动作（组合/数字优先开启）",
                {
                    val list = AutoClickPostAction.defaultsForLottery(lot.type)
                    postActions = list
                    savePostActions(list)
                },
                Modifier.fillMaxWidth()
            )
        }

        itemsIndexed(postActions, key = { _, a -> a.id }) { index, action ->
            GlobalCard {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        when (action.type) {
                            AutoClickPostAction.TYPE_COMBO -> "①组合（预测）"
                            AutoClickPostAction.TYPE_PRED_NUMBERS -> "②预测数字"
                            AutoClickPostAction.TYPE_PLAY -> "玩法「${action.text.ifBlank { "空" }}」"
                            else -> "文案「${action.text.ifBlank { "空" }}」"
                        },
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f)
                    )
                    Switch(checked = action.enabled, onCheckedChange = { on ->
                        savePostActions(postActions.mapIndexed { i, a -> if (i == index) a.copy(enabled = on) else a })
                    })
                }
                if (action.type == AutoClickPostAction.TYPE_TEXT) {
                    OutlinedTextField(
                        value = action.text,
                        onValueChange = { t ->
                            savePostActions(postActions.mapIndexed { i, a -> if (i == index) a.copy(text = t.take(12)) else a })
                        },
                        label = { Text("要点击的文字") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                Text(
                    if (action.regionEnabled)
                        "区域 ✓ L${(action.regionLeft * 100).toInt()}% …"
                    else "区域：未限制",
                    fontSize = 11.sp
                )
                Row(
                    Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    FilterChip(
                        selected = false,
                        onClick = {
                            if (index > 0) {
                                val list = postActions.toMutableList()
                                val item = list.removeAt(index)
                                list.add(index - 1, item)
                                savePostActions(list)
                            }
                        },
                        label = { Text("上移") },
                        enabled = index > 0
                    )
                    FilterChip(
                        selected = false,
                        onClick = {
                            if (index < postActions.lastIndex) {
                                val list = postActions.toMutableList()
                                val item = list.removeAt(index)
                                list.add(index + 1, item)
                                savePostActions(list)
                            }
                        },
                        label = { Text("下移") },
                        enabled = index < postActions.lastIndex
                    )
                    FilterChip(
                        selected = action.regionEnabled,
                        onClick = {
                            context.startActivity(
                                Intent(context, ClickRegionPickActivity::class.java)
                                    .putExtra(ClickRegionPickActivity.EXTRA_MODE, ClickRegionPickActivity.MODE_ACTION)
                                    .putExtra(ClickRegionPickActivity.EXTRA_ACTION_ID, action.id)
                            )
                        },
                        label = { Text("框选区域") }
                    )
                    if (action.type == AutoClickPostAction.TYPE_TEXT) {
                        FilterChip(
                            selected = false,
                            onClick = {
                                savePostActions(postActions.filterIndexed { i, _ -> i != index })
                            },
                            label = { Text("删除") }
                        )
                    }
                }
            }
        }

        item {
            GlobalCard {
                Text("新增文案点击", fontWeight = FontWeight.SemiBold)
                OutlinedTextField(
                    value = newText,
                    onValueChange = { newText = it.take(12) },
                    label = { Text("如：确认 / 投注 / 删除") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                PrimaryButton("添加动作", {
                    val t = newText.trim()
                    if (t.isNotEmpty()) {
                        savePostActions(
                            postActions + AutoClickPostAction(
                                id = UUID.randomUUID().toString().take(8),
                                type = AutoClickPostAction.TYPE_TEXT,
                                enabled = true,
                                text = t
                            )
                        )
                        newText = ""
                    }
                }, Modifier.fillMaxWidth())
                if (postActions.none { it.type == AutoClickPostAction.TYPE_COMBO }) {
                    TextButton(onClick = {
                        savePostActions(
                            listOf(
                                AutoClickPostAction(id = "combo", type = AutoClickPostAction.TYPE_COMBO, enabled = false)
                            ) + postActions
                        )
                    }) { Text("恢复「组合」动作") }
                }
                if (postActions.none { it.type == AutoClickPostAction.TYPE_PRED_NUMBERS }) {
                    TextButton(onClick = {
                        savePostActions(
                            postActions + AutoClickPostAction(
                                id = "pred_numbers",
                                type = AutoClickPostAction.TYPE_PRED_NUMBERS,
                                enabled = false
                            )
                        )
                    }) { Text("恢复「预测数字」动作") }
                }
            }
        }

        item {
            SectionTitle("参数")
            GlobalCard {
                Text("点击间隔：${p.autoClickDelayMs}ms")
                Slider(
                    value = p.autoClickDelayMs.toFloat(),
                    onValueChange = { v -> vm.updatePrefs { it.copy(autoClickDelayMs = v.toLong().coerceIn(100L, 2000L)) } },
                    valueRange = 100f..2000f
                )
                Text("连续失败停点：${p.autoClickFailStopCount} 次（0=不限制）")
                Slider(
                    value = p.autoClickFailStopCount.toFloat(),
                    onValueChange = { v -> vm.updatePrefs { it.copy(autoClickFailStopCount = v.toInt().coerceIn(0, 10)) } },
                    valueRange = 0f..10f,
                    steps = 9
                )
            }
        }

        item {
            SectionTitle("试点击")
            GlobalCard {
                CaptionMuted("不记挂机订单；请先切到投注页再点。会走完整流水线（含已开启的后续动作）。")
                PrimaryButton("立即试跑一轮", {
                    refreshFlags()
                    AutoBetController.tryNow(context)
                }, Modifier.fillMaxWidth())
            }
        }
    }
}
