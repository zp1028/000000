package com.caifenxi.app.domain.plan

import com.caifenxi.app.domain.model.DrawRecord
import com.caifenxi.app.domain.model.PlanDefinition
import kotlin.math.abs
import kotlin.math.pow
import kotlin.math.sqrt

/** NovaPlan 分析层：严格使用 cutoff 之前的数据，避免回测信息泄漏。 */
object NovaPlanAnalytics {
    data class Result(
        val planId: String,
        val output: String,
        val score: Double,
        val sampleCount: Int,
        val baseline: Double,
        val edge: Double,
        val stability: Double
    )

    data class BacktestReport(
        val planId: String,
        val periods: Int,
        val hits: Int,
        val misses: Int,
        val hitRate: Double,
        val randomBaseline: Double,
        val edge: Double,
        val maxHitStreak: Int,
        val maxMissStreak: Int,
        val stability: Double
    )

    fun predict(plan: PlanDefinition, history: List<DrawRecord>, outputCount: Int? = null): Result? {
        val data = history.takeLast(plan.window.coerceAtLeast(5))
        if (data.size < 5) return null
        val output = when (plan.playType) {
            "大小" -> directionOutput(plan, data, data.mapNotNull { it.dx }, "大", "小")
            "单双" -> directionOutput(plan, data, data.mapNotNull { it.ds }, "单", "双")
            "组合" -> comboOutput(plan, data, outputCount ?: 3)
            "数字" -> numberOutput(plan, data, null, outputCount ?: 3)
            "位置" -> numberOutput(plan, data, plan.positionIndex.coerceIn(0, 9), outputCount ?: 3)
            else -> data.lastOrNull()?.dx.orEmpty()
        }.ifBlank { return null }
        val baseline = plan.baselineValue
        val sampleFactor = (data.size.coerceAtMost(200) / 200.0)
        val score = (50.0 + sampleFactor * 10.0).coerceAtMost(60.0)
        return Result(plan.planId, output, score, data.size, baseline, 0.0, 1.0)
    }

    /**
     * walk-forward 回测：每个 target 只使用 target 之前的数据。
     * 执行周期 cyclePeriods=N：一次预测锁定后续 N 期，N 期内任意一期命中即计为中（常见多期计划口径）。
     * 步进也为 N，避免与一期回测完全同一组样本导致胜率不变。
     */
    fun backtest(plan: PlanDefinition, history: List<DrawRecord>, periods: Int): BacktestReport {
        val cycle = plan.cyclePeriods.coerceIn(1, 20)
        val n = periods.coerceAtLeast(1).coerceAtMost((history.size - 5).coerceAtLeast(1))
        val start = (history.size - n).coerceAtLeast(5)
        var hits = 0
        var misses = 0
        var hitStreak = 0
        var missStreak = 0
        var maxHit = 0
        var maxMiss = 0
        val rates = mutableListOf<Double>()
        var i = start
        while (i < history.size) {
            val prior = history.subList(0, i)
            val p = predict(plan, prior)
            if (p == null) {
                i += 1
                continue
            }
            val end = (i + cycle).coerceAtMost(history.size)
            // N 期内任一期命中 → 中；全部未中 → 错
            var hit = false
            for (j in i until end) {
                if (evaluate(plan, p.output, history[j])) {
                    hit = true
                    break
                }
            }
            if (hit) {
                hits++; hitStreak++; missStreak = 0; maxHit = maxOf(maxHit, hitStreak)
            } else {
                misses++; missStreak++; hitStreak = 0; maxMiss = maxOf(maxMiss, missStreak)
            }
            rates += if (hit) 1.0 else 0.0
            i += cycle
        }
        val total = hits + misses
        val rate = if (total == 0) 0.0 else hits.toDouble() / total
        // 多期计划随机基准随周期提升（近似 1-(1-p)^N）
        val singleBaseline = plan.baselineValue.coerceIn(0.01, 0.99)
        val baseline = if (cycle <= 1) singleBaseline else (1.0 - (1.0 - singleBaseline).pow(cycle))
        val mean = rate
        val variance = if (rates.size < 2) 0.0 else rates.map { (it - mean) * (it - mean) }.average()
        val stability = (1.0 - sqrt(variance) * 2.0).coerceIn(0.0, 1.0)
        return BacktestReport(plan.planId, total, hits, misses, rate, baseline, rate - baseline, maxHit, maxMiss, stability)
    }

    private fun evaluate(plan: PlanDefinition, output: String, actual: DrawRecord): Boolean {
        val parts = output.split("/", "、", ",").map { it.trim() }.filter { it.isNotEmpty() }
        return when (plan.playType) {
            "大小" -> parts.any { it == actual.dx }
            "单双" -> parts.any { it == actual.ds }
            "组合" -> parts.any { it == actual.combo }
            "数字" -> parts.any { it.toIntOrNull()?.let { n -> n in actual.numbers } == true }
            "位置" -> {
                if (actual.numbers.isEmpty()) return false
                val index = plan.positionIndex.coerceIn(0, actual.numbers.lastIndex)
                val n = actual.numberAt(index)
                parts.any { it.toIntOrNull() == n }
            }
            else -> false
        }
    }

    private fun directionOutput(
        plan: PlanDefinition,
        data: List<DrawRecord>,
        seq: List<String>,
        a: String,
        b: String
    ): String {
        if (seq.isEmpty()) return ""
        return when (plan.algorithm) {
            "RHYTHM" -> rhythm(seq, a, b)
            "SIMILAR" -> similarDirection(data, seq)
            "ANOMALY" -> anomaly(seq, a, b)
            else -> state(seq)
        }
    }

    private fun comboOutput(plan: PlanDefinition, data: List<DrawRecord>, topN: Int): String {
        val seq = data.mapNotNull { it.combo }
        if (seq.isEmpty()) return ""
        val base = seq.groupingBy { it }.eachCount().entries
            .sortedWith(compareByDescending<Map.Entry<String, Int>> { it.value }.thenBy { it.key })
            .map { it.key }
        val n = topN.coerceIn(1, 4)
        return if (plan.algorithm == "RHYTHM" && seq.size >= 3 && seq.takeLast(3).distinct().size == 1) {
            base.asReversed().take(n).joinToString("/")
        } else base.take(n).joinToString("/")
    }

    private fun numberOutput(plan: PlanDefinition, data: List<DrawRecord>, position: Int?, topN: Int): String {
        val counts = mutableMapOf<Int, Double>()
        data.forEachIndexed { index, row ->
            val nums = if (position == null) row.numbers else listOfNotNull(row.numberAt(position))
            val decay = when (plan.algorithm) {
                "RHYTHM", "ANOMALY", "SIMILAR" -> 0.8 + index.toDouble() / data.size * 0.7
                else -> 1.0
            }
            nums.forEach { n -> counts[n] = (counts[n] ?: 0.0) + decay }
        }
        if (counts.isEmpty()) return ""
        return counts.entries.sortedWith(compareByDescending<Map.Entry<Int, Double>> { it.value }.thenBy { it.key })
            .take(topN.coerceIn(1, 10))
            .joinToString("/") { it.key.toString() }
    }

    private fun state(seq: List<String>): String =
        seq.takeLast(8).groupingBy { it }.eachCount().maxWithOrNull(compareBy<Map.Entry<String, Int>> { it.value }.thenBy { it.key })?.key.orEmpty()

    private fun rhythm(seq: List<String>, a: String, b: String): String {
        if (seq.size < 4) return state(seq)
        return if (seq.takeLast(3).distinct().size == 1) {
            if (seq.last() == a) b else a
        } else state(seq)
    }

    private fun anomaly(seq: List<String>, a: String, b: String): String {
        val pA = seq.count { it == a }.toDouble() / seq.size.coerceAtLeast(1)
        return when {
            pA > 0.65 -> b
            pA < 0.35 -> a
            else -> state(seq)
        }
    }

    private fun similarDirection(data: List<DrawRecord>, seq: List<String>): String {
        if (seq.size < 8) return state(seq)
        val tail = seq.takeLast(5)
        val candidates = seq.dropLast(5).windowed(5)
        val best = candidates.minByOrNull { w -> w.zip(tail).count { it.first != it.second } } ?: return state(seq)
        val idx = candidates.indexOf(best)
        return seq.getOrNull(idx + 5) ?: state(seq)
    }
}
