package com.caifenxi.curveapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontWeight
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlin.math.max

/** 独立玩法模型：任何回测/走势都必须绑定彩种+玩法+位置，避免跨彩种污染。 */
data class PlaySpec(val id:String, val title:String, val positions:List<String> = emptyList(), val modes:List<String> = listOf("走势"))
data class LotteryDef(val code:String,val name:String,val path:String,val historyPath:String,val family:String,val plays:List<PlaySpec>)
data class Draw(val issue:String,val time:String,val nums:List<Int>)
data class Point(val issue:String,val value:Double,val draw:Draw)

enum class Tab(val title:String){HOME("首页"),HISTORY("开奖"),TREND("走势"),CHART("图表"),LOTTERY("彩种")}

private fun positions(n:Int)=List(n){"第${it+1}球"}
private val PDS=listOf("大小","单双")
private val PK10_PLAYS=listOf(
    PlaySpec("position_ds","位置大小单双",positions(10),PDS),
    PlaySpec("position_lh","位置龙虎",listOf("第一球vs第十球","第二球vs第九球","第三球vs第八球","第四球vs第七球","第五球vs第六球"),listOf("龙虎")),
    PlaySpec("gyh_ds","冠亚和",listOf("冠亚和"),listOf("大小","单双","数值")),
    PlaySpec("number","号码走势",positions(10),listOf("号码","遗漏","冷热"))
)
private val SPORT_PLAYS=listOf(
    PlaySpec("position_ds","定位大小单双",positions(6),PDS),
    PlaySpec("position_lh","定位龙虎",listOf("第一球vs第六球","第二球vs第五球","第三球vs第四球"),listOf("龙虎")),
    PlaySpec("position_num","定位号码",positions(6),listOf("1","2","3","4","5","6"))
)
private val K3_PLAYS=listOf(
    PlaySpec("sanjun","三军",listOf("三军"),listOf("1点","2点","3点","4点","5点","6点")),
    PlaySpec("sum","和值",listOf("和值"),listOf("数值","大小","单双")),
    PlaySpec("yxie","鱼虾蟹",listOf("鱼","虾","蟹"),listOf("鱼","虾","蟹")),
    PlaySpec("changpai","长牌",listOf("12","13","14","15","16","23","24","25","26","34","35","36","45","46","56"),listOf("不同号")),
    PlaySpec("number","号码走势",positions(3),listOf("号码","遗漏","冷热"))
)
private val SSC_PLAYS=listOf(
    PlaySpec("position_ds","定位大小单双",listOf("万位","千位","百位","十位","个位"),PDS),
    PlaySpec("number","定位号码",listOf("万位","千位","百位","十位","个位"),List(10){it.toString()}),
    PlaySpec("sum","和值",listOf("和值"),listOf("数值","大小","单双")),
    PlaySpec("trend","号码走势",listOf("万位","千位","百位","十位","个位"),listOf("号码","遗漏","冷热"))
)
private val ELEVEN_PLAYS=listOf(
    PlaySpec("position_ds","位置大小单双",positions(5),PDS),
    PlaySpec("number","位置号码",positions(5),List(11){(it+1).toString()}),
    PlaySpec("sum","和值",listOf("和值"),listOf("数值","大小","单双")),
    PlaySpec("trend","号码走势",positions(5),listOf("号码","遗漏","冷热"))
)
private val KL10_PLAYS=listOf(
    PlaySpec("position_ds","位置大小单双",positions(8),PDS),
    PlaySpec("number","位置号码",positions(8),List(18){(it+1).toString()}),
    PlaySpec("sum","和值",listOf("和值"),listOf("数值","大小","单双")),
    PlaySpec("trend","走势分析",positions(8),listOf("号码","遗漏","冷热"))
)
private val K8_PLAYS=listOf(
    PlaySpec("pick","选一至选十",List(10){"选${it+1}"},listOf("命中数","命中率","遗漏")),
    PlaySpec("number","号码走势",listOf("1~80"),listOf("出现次数","遗漏","冷热")),
    PlaySpec("position","位置号码",List(20){"第${it+1}个"},listOf("号码"))
)
private val LOTTO_PLAYS=listOf(PlaySpec("number","号码走势",listOf("前区","后区"),listOf("出现次数","遗漏","冷热")))
private val D3_PLAYS=listOf(
    PlaySpec("position_ds","定位大小单双",listOf("百位","十位","个位"),PDS),
    PlaySpec("number","定位号码",listOf("百位","十位","个位"),List(10){it.toString()}),
    PlaySpec("sum","和值",listOf("和值"),listOf("数值","大小","单双")),
    PlaySpec("trend","号码走势",listOf("百位","十位","个位"),listOf("号码","遗漏","冷热"))
)
private val PC28_PLAYS=listOf(PlaySpec("sum","和值",listOf("和值"),listOf("数值","大小","单双")),PlaySpec("trend","走势分析",listOf("和值"),listOf("数值","大小","单双","遗漏")))
private val SIX_PLAYS=listOf(PlaySpec("number","号码走势",listOf("正码","特码"),listOf("号码","遗漏","冷热")))

private val CATALOG=listOf(
 LotteryDef("10086","极速运动会","yundong/getLotteryYunDongInfo.do","yundong/getYunDongHistoryList.do","运动会",SPORT_PLAYS),
 LotteryDef("10035","极速飞艇","pks/getLotteryPksInfo.do","pks/getPksHistoryList.do","PK10",PK10_PLAYS),
 LotteryDef("10037","极速赛车","pks/getLotteryPksInfo.do","pks/getPksHistoryList.do","PK10",PK10_PLAYS),
 LotteryDef("10052","极速快三","JSFastThree/getBaseJSFastThree.do","JSFastThree/getJSFastThreeList.do","快3",K3_PLAYS),
 LotteryDef("10073","快乐8","LuckTwenty/getBaseLuckTewnty.do","LuckTwenty/getBaseLuckTwentyList.do","快乐8",K8_PLAYS),
 LotteryDef("10054","极速快乐8","LuckTwenty/getBaseLuckTewnty.do","LuckTwenty/getBaseLuckTwentyList.do","快乐8",K8_PLAYS),
 LotteryDef("10001","北京PK10","pks/getLotteryPksInfo.do","pks/getPksHistoryList.do","PK10",PK10_PLAYS),
 LotteryDef("10002","重庆时时彩","CQShiCai/getBaseCQShiCai.do","CQShiCai/getBaseCQShiCaiList.do","时时彩",SSC_PLAYS),
 LotteryDef("10039","福彩双色球","QuanGuoCai/getLotteryInfo.do","QuanGuoCai/getHistoryLotteryInfo.do","双色球",LOTTO_PLAYS),
 LotteryDef("10040","超级大乐透","QuanGuoCai/getLotteryInfo.do","QuanGuoCai/getHistoryLotteryInfo.do","大乐透",LOTTO_PLAYS),
 LotteryDef("10041","福彩3D","QuanGuoCai/getLotteryInfo.do","QuanGuoCai/getHistoryLotteryInfo.do","3D",D3_PLAYS),
 LotteryDef("10055","极速11选5","ElevenFive/getElevenFiveInfo.do","ElevenFive/getElevenFiveList.do","11选5",ELEVEN_PLAYS),
 LotteryDef("10057","幸运飞艇","pks/getLotteryPksInfo.do","pks/getPksHistoryList.do","PK10",PK10_PLAYS),
 LotteryDef("10058","SG飞艇","pks/getLotteryPksInfo.do","pks/getPksHistoryList.do","PK10",PK10_PLAYS),
 LotteryDef("10059","幸运时时彩","CQShiCai/getBaseCQShiCai.do","CQShiCai/getBaseCQShiCaiList.do","时时彩",SSC_PLAYS),
 LotteryDef("10064","台湾5分彩","CQShiCai/getBaseCQShiCai.do","CQShiCai/getBaseCQShiCaiList.do","时时彩",SSC_PLAYS),
 LotteryDef("10075","SG 时时彩","CQShiCai/getBaseCQShiCai.do","CQShiCai/getBaseCQShiCaiList.do","时时彩",SSC_PLAYS),
 LotteryDef("10076","SG 快3","JSFastThree/getBaseJSFastThree.do","JSFastThree/getJSFastThreeList.do","快3",K3_PLAYS),
 LotteryDef("10083","SG快乐十分","klsf/getLotteryInfo.do","klsf/getHistoryLotteryInfo.do","快乐十分",KL10_PLAYS),
 LotteryDef("10084","SG11选5","ElevenFive/getElevenFiveInfo.do","ElevenFive/getElevenFiveList.do","11选5",ELEVEN_PLAYS),
 LotteryDef("10081","极速蛋蛋","LuckTwenty/getPcLucky28.do","LuckTwenty/getPcLucky28List.do","28",PC28_PLAYS),
 LotteryDef("10074","PC蛋蛋幸运28","LuckTwenty/getPcLucky28.do","LuckTwenty/getPcLucky28List.do","28",PC28_PLAYS),
 LotteryDef("10088","加拿大PC28","LuckTwenty/getPcLucky28.do","LuckTwenty/getPcLucky28List.do","28",PC28_PLAYS),
 LotteryDef("10072","台湾今彩539","taiWanCai/getLotteryInfo.do","taiWanCai/getHistoryLotteryInfo.do","539",LOTTO_PLAYS),
 LotteryDef("10070","台湾大乐透","taiWanCai/getLotteryInfo.do","taiWanCai/getHistoryLotteryInfo.do","大乐透",LOTTO_PLAYS),
 LotteryDef("10071","台湾威力彩","taiWanCai/getLotteryInfo.do","taiWanCai/getHistoryLotteryInfo.do","威力彩",LOTTO_PLAYS),
 LotteryDef("10048","香港彩","smallSix/findSmallSixInfo.do","smallSix/findSmallSixHistory.do","六合彩",SIX_PLAYS),
 LotteryDef("10051","极速六合彩","speedSix/findSpeedSixInfo.do","speedSix/findSpeedSixHistory.do","六合彩",SIX_PLAYS)
)

private val Bg=Color(0xFFF6F7FB); private val Ink=Color(0xFF171A21); private val Muted=Color(0xFF7B8494); private val Primary=Color(0xFF4F5DFF); private val Green=Color(0xFF17A673); private val Red=Color(0xFFE55361)

class MainActivity:ComponentActivity(){override fun onCreate(b:Bundle?){super.onCreate(b);setContent{App()}}}

@Composable fun App(){
 var lot by remember{mutableStateOf(CATALOG.first())}; var tab by remember{mutableStateOf(Tab.HOME)}; var draws by remember{mutableStateOf<List<Draw>>(emptyList())}; var apiKey by remember{mutableStateOf("")}; var host by remember{mutableStateOf("https://api.csjid.com")}; val scope=rememberCoroutineScope(); var loading by remember{mutableStateOf(false)}
 fun refresh(){if(apiKey.isBlank())return; loading=true;scope.launch(Dispatchers.IO){val r=runCatching{LotteryApi.fetchHistory(LotteryApi.Config(host,lot.path,lot.historyPath,lot.code,apiKey))}.getOrDefault(emptyList());launch(Dispatchers.Main){draws=r.takeLast(10000);loading=false}}}
 MaterialTheme{Scaffold(containerColor=Bg,topBar={TopAppBar(title={Text(lot.name,fontWeight=FontWeight.Bold)},actions={TextButton(onClick={refresh()}){Text(if(loading)"加载中":"刷新")}})},bottomBar={NavigationBar{Tab.entries.forEach{NavigationBarItem(selected=tab==it,onClick={tab=it},icon={},label={Text(it.title)})}}}){p->Box(Modifier.padding(p)){when(tab){Tab.HOME->Home(lot,draws,apiKey,{apiKey=it},host,{host=it},{refresh()});Tab.HISTORY->History(draws);Tab.TREND->Trend(lot,draws);Tab.CHART->ChartPage(lot,draws);Tab.LOTTERY->LotteryPicker(lot){lot=it;draws=emptyList();tab=Tab.HOME}}}}}
}

@Composable fun Home(l:LotteryDef,d:List<Draw>,key:String,onKey:(String)->Unit,host:String,onHost:(String)->Unit,onRefresh:()->Unit){Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){CardBox{Text("独立彩种 · 数据分析中心",fontSize=20.sp,fontWeight=FontWeight.Bold);Text("${l.name} · ${l.family}",color=Muted);Spacer(Modifier.height(12.dp));Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Stat("历史期数",d.size.toString(),Modifier.weight(1f));Stat("玩法分类",l.plays.size.toString(),Modifier.weight(1f));Stat("曲线最多","10000期",Modifier.weight(1f))}};CardBox{Text("数据源",fontWeight=FontWeight.Bold);Spacer(Modifier.height(8.dp));OutlinedTextField(host,onHost,label={Text("API主域名")},singleLine=true,modifier=Modifier.fillMaxWidth());OutlinedTextField(key,onKey,label={Text("API Key")},singleLine=true,modifier=Modifier.fillMaxWidth());Spacer(Modifier.height(8.dp));Button(onClick=onRefresh,modifier=Modifier.fillMaxWidth()){Text("读取当前彩种开奖")}};CardBox{Text("玩法分类",fontWeight=FontWeight.Bold);Spacer(Modifier.height(8.dp));l.plays.forEach{p->Column(Modifier.fillMaxWidth().padding(vertical=5.dp)){Text(p.title,fontWeight=FontWeight.SemiBold);Text(p.positions.joinToString(" · ").ifBlank{"通用"},color=Muted,fontSize=11.sp)}}}}}

@Composable fun History(d:List<Draw>){Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){d.takeLast(100).asReversed().forEach{CardBox{Row(verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(it.issue,fontWeight=FontWeight.Bold);Text(it.time,color=Muted,fontSize=10.sp)}Row(horizontalArrangement=Arrangement.spacedBy(4.dp)){it.nums.take(20).forEach{Ball(it.toString())}}}}}}}

@Composable fun Trend(l:LotteryDef,d:List<Draw>){var play by remember(l.code){mutableStateOf(l.plays.first())};var position by remember(l.code){mutableStateOf(play.positions.firstOrNull().orEmpty())};Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){CardBox{Text("${l.name} · 独立走势",fontWeight=FontWeight.Bold);HorizontalChips(l.plays.map{it.title},play.title){name->play=l.plays.first{it.title==name};position=play.positions.firstOrNull().orEmpty()};Spacer(Modifier.height(8.dp));HorizontalChips(play.positions,position){position=it};Spacer(Modifier.height(8.dp));HorizontalChips(play.modes,play.modes.first()){}};CardBox{Text("从最新一期向历史期查看",color=Muted,fontSize=11.sp);LineChart(buildTrendValues(d,play,position))}}}

@Composable fun ChartPage(l:LotteryDef,d:List<Draw>){var play by remember(l.code){mutableStateOf(l.plays.first())};var position by remember(l.code){mutableStateOf(play.positions.firstOrNull().orEmpty())};var mode by remember(l.code){mutableStateOf(play.modes.firstOrNull().orEmpty())};var period by remember{mutableStateOf(1500)};var scale by remember{mutableFloatStateOf(1f)};var pan by remember{mutableFloatStateOf(0f)};val safePeriod=minOf(period,d.size);val points=remember(d,play.id,position,mode,safePeriod){buildSeries(d.takeLast(safePeriod),play,position,mode)};Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){CardBox{Text("${l.name} · 回测曲线",fontWeight=FontWeight.Bold);Text("彩种、玩法、位置三层独立绑定",color=Muted,fontSize=11.sp);HorizontalChips(l.plays.map{it.title},play.title){name->play=l.plays.first{it.title==name};position=play.positions.firstOrNull().orEmpty();mode=play.modes.firstOrNull().orEmpty()};Spacer(Modifier.height(6.dp));HorizontalChips(play.positions,position){position=it};Spacer(Modifier.height(6.dp));HorizontalChips(play.modes,mode){mode=it};Spacer(Modifier.height(6.dp));HorizontalChips(listOf(30,50,100,200,500,1000,1500,2000,5000,10000).map{"${it}期"},"${period}期"){period=it.removeSuffix("期").toInt()}};CardBox{ZoomCurve(points,scale,pan,{scale=(scale*1.2f).coerceAtMost(8f)},{scale=(scale/1.2f).coerceAtLeast(.5f)},{scale=1f;pan=0f},{s,p->scale=s.coerceIn(.5f,8f);pan+=p});Text("零轴参考线 · 最高点 · 最低点 · 回撤虚线",color=Muted,fontSize=11.sp)};CardBox{Summary(points)}}}

private fun extractIndex(pos:String, size:Int):Int {val n=Regex("\\d+").find(pos)?.value?.toIntOrNull();return ((n?:1)-1).coerceIn(0,max(0,size-1))}
private fun valueFor(draw:Draw,play:PlaySpec,position:String,mode:String):Double {val nums=draw.nums;if(nums.isEmpty())return 0.0;when(play.id){"position_ds","number","trend"->{val idx=extractIndex(position,nums.size);val n=nums.getOrElse(idx){nums.first()};return when(mode){"大小"->if(n>=5)1.0 else -1.0;"单双"->if(n%2==1)1.0 else -1.0;"遗漏","冷热","出现次数"->n.toDouble();else->n.toDouble()}};"position_lh"->{val pair=Regex("(\\d+).*?(\\d+)").find(position);if(pair!=null){val a=nums.getOrElse(pair.groupValues[1].toInt()-1){0};val b=nums.getOrElse(pair.groupValues[2].toInt()-1){0};return when(mode){"龙虎"->if(a>b)1.0 else if(a<b)-1.0 else 0.0;else->a-b.toDouble()}}};"gyh_ds","sum"->{val sum=nums.sum();return when(mode){"大小"->if(sum>=nums.size*5.0)1.0 else -1.0;"单双"->if(sum%2==1)1.0 else -1.0;else->sum.toDouble()}};"pick"->return nums.size.toDouble();"changpai"->return nums.distinct().size.toDouble();"sanjun"->return nums.count{it==Regex("\\d+").find(position)?.value?.toIntOrNull()}.toDouble();"yxie"->return nums.sum().toDouble()}
return nums.first().toDouble()}
fun buildSeries(d:List<Draw>,play:PlaySpec,position:String,mode:String):List<Point>{if(d.isEmpty())return emptyList();var cum=0.0;var peak=0.0;return d.map{dr->val v=valueFor(dr,play,position,mode);cum+=v;peak=max(peak,cum);Point(dr.issue,cum,dr)}}
fun buildTrendValues(d:List<Draw>,play:PlaySpec,position:String):List<Float>{return d.takeLast(1500).map{valueFor(it,play,position,play.modes.firstOrNull()?:("号码")).toFloat()}}

@Composable fun Summary(p:List<Point>){val hi=p.maxByOrNull{it.value};val lo=p.minByOrNull{it.value};val cur=p.lastOrNull()?.value?:0.0;val peak=p.fold(Double.NEGATIVE_INFINITY){m,x->max(m,x.value)};val dd=(peak-cur).coerceAtLeast(0.0);Row{Stat("当前",String.format("%.1f",cur),Modifier.weight(1f));Stat("最高",String.format("%.1f",hi?.value?:0.0),Modifier.weight(1f));Stat("最低",String.format("%.1f",lo?.value?:0.0),Modifier.weight(1f));Stat("回撤",String.format("%.1f",dd),Modifier.weight(1f))}}

@Composable fun ZoomCurve(p:List<Point>,scale:Float,pan:Float,zoomIn:()->Unit,zoomOut:()->Unit,reset:()->Unit,onGesture:(Float,Float)->Unit){Column{Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){Button(onClick=zoomOut){Text("−")};Button(onClick=zoomIn){Text("＋")};Button(onClick=reset){Text("重置")}};Canvas(Modifier.fillMaxWidth().height(300.dp).pointerInput(Unit){detectTransformGestures{_,offset,zoom,_->onGesture(scale*zoom,offset.x)}}){drawGrid();val vals=p.map{it.value};if(vals.isEmpty())return@Canvas;val lo=minOf(0.0,vals.minOrNull()?:0.0);val hi=maxOf(0.0,vals.maxOrNull()?:0.0);val span=max(.001,hi-lo);val zero=size.height-((0-lo)/span).toFloat()*size.height;drawLine(Muted,Offset(0f,zero),Offset(size.width,zero),1.5f);val path=Path();vals.forEachIndexed{i,v->val x=(i.toFloat()/max(1,vals.size-1))*size.width*scale+pan;val y=size.height-((v-lo)/span).toFloat()*size.height;if(i==0)path.moveTo(x,y)else path.lineTo(x,y)};drawPath(path,Green,Stroke(4f,cap=StrokeCap.Round));var maxSeen=Double.NEGATIVE_INFINITY;vals.forEachIndexed{i,v->maxSeen=max(maxSeen,v);val dd=v-maxSeen;val x=(i.toFloat()/max(1,vals.size-1))*size.width*scale+pan;val y=size.height-((dd-lo)/span).toFloat()*size.height;drawLine(Red.copy(alpha=.45f),Offset(x,y),Offset(x,y+5f),1f)}}}}

@Composable fun HorizontalChips(items:List<String>,selected:String,onPick:(String)->Unit){if(items.isEmpty())return;Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(6.dp)){items.forEach{FilterChip(selected==it,{onPick(it)},label={Text(it)})}}
}
@Composable fun LotteryPicker(current:LotteryDef,onPick:(LotteryDef)->Unit){var q by remember{mutableStateOf("")};Column(Modifier.fillMaxSize().padding(16.dp)){OutlinedTextField(q,{q=it},label={Text("搜索彩种 / lotCode")},singleLine=true,modifier=Modifier.fillMaxWidth());Spacer(Modifier.height(10.dp));Column(Modifier.verticalScroll(rememberScrollState())){CATALOG.filter{q.isBlank()||it.name.contains(q)||it.code.contains(q)}.forEach{CardBox{Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(it.name,fontWeight=FontWeight.Bold);Text("lotCode ${it.code} · ${it.family}",color=Muted,fontSize=11.sp)}if(current.code==it.code)Text("当前",color=Primary)};TextButton(onClick={onPick(it)}){Text("切换")};Spacer(Modifier.height(4.dp));Text("玩法：${it.plays.joinToString("、"){p->p.title}}",color=Muted,fontSize=11.sp)}}}}}

@Composable fun CardBox(content:@Composable ColumnScope.()->Unit){Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(18.dp),elevation=CardDefaults.cardElevation(1.dp)){Column(Modifier.padding(15.dp),content=content)}}
@Composable fun Stat(t:String,v:String,m:Modifier){Column(m){Text(t,color=Muted,fontSize=10.sp);Text(v,fontWeight=FontWeight.Bold,fontSize=18.sp)}}
@Composable fun Ball(s:String){Box(Modifier.size(28.dp).background(Color.White,RoundedCornerShape(50)),contentAlignment=Alignment.Center){Text(s,fontSize=11.sp,fontWeight=FontWeight.Bold,color=Ink)}}
@Composable fun LineChart(v:List<Float>){Canvas(Modifier.fillMaxWidth().height(240.dp)){drawGrid();curve(v)}}
fun androidx.compose.ui.graphics.drawscope.DrawScope.drawGrid(){for(i in 1..4){val y=size.height*i/5;drawLine(Muted.copy(alpha=.12f),Offset(0f,y),Offset(size.width,y),1f)}}
fun androidx.compose.ui.graphics.drawscope.DrawScope.curve(v:List<Float>){if(v.isEmpty())return;val lo=v.minOrNull()?:0f;val hi=v.maxOrNull()?:1f;val span=max(.001f,hi-lo);val path=Path();v.forEachIndexed{i,x->val px=i*(size.width/max(1,v.size-1));val py=size.height-((x-lo)/span)*size.height;if(i==0)path.moveTo(px,py)else path.lineTo(px,py)};drawPath(path,Primary,Stroke(3f,cap=StrokeCap.Round))}
