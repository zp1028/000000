package com.caifenxi.app.domain.plan

import com.caifenxi.app.domain.model.LotteryType
import com.caifenxi.app.domain.model.PlanDefinition

/** 极速运动会：6球大小/单双/定位 + 3组龙虎，全部按位置独立建池。 */
object NovaYdhPlanPool {
    val ALL: List<PlanDefinition> get() = PlanPoolV2.all(LotteryType.YDH)
    val CANDIDATES: List<PlanDefinition> get() = PlanPoolV2.candidates(LotteryType.YDH)
    fun find(planId: String): PlanDefinition? = PlanPoolV2.find(planId)
}
