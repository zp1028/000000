package com.caifenxi.app.domain.btc.news

import kotlin.math.exp

/** Time-decayed news impact. Recent high-impact items matter more than stale headlines. */
object NewsImpactEngine {
    data class Impact(val itemId: String, val score: Double, val weight: Double, val ageMinutes: Double)

    fun impact(item: NewsItem, now: Long = System.currentTimeMillis(), halfLifeMinutes: Double = 90.0): Impact {
        val ageMinutes = ((now - item.publishedAt).coerceAtLeast(0L) / 60_000.0)
        val decay = exp(-kotlin.math.ln(2.0) * ageMinutes / halfLifeMinutes.coerceAtLeast(1.0))
        val weight = item.impactScore.coerceIn(0.0, 1.0) * decay
        return Impact(item.id, item.sentiment.coerceIn(-1.0, 1.0), weight, ageMinutes)
    }

    fun aggregate(items: List<NewsItem>, now: Long = System.currentTimeMillis()): Double {
        if (items.isEmpty()) return 0.0
        val impacts = items.map { impact(it, now) }
        val denominator = impacts.sumOf { it.weight }
        if (denominator <= 0.0) return 0.0
        return impacts.sumOf { it.score * it.weight } / denominator
    }

    fun isBlackSwan(item: NewsItem): Boolean {
        val text = (item.title + " " + item.summary).lowercase()
        val keys = listOf("exploit", "hack", "bankruptcy", "insolvency", "depeg", "冻结", "黑客", "崩盘", "脱锚", "破产")
        return item.impactScore >= 0.85 && keys.any(text::contains)
    }
}
