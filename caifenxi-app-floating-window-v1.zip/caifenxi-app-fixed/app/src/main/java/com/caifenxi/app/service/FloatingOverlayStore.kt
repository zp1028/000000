package com.caifenxi.app.service

import android.content.Context
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

@Serializable
data class FloatingPlanItem(
    val planId: String,
    val planName: String,
    val dx: String? = null,
    val ds: String? = null
)

@Serializable
data class FloatingSnapshot(
    val lotteryKey: String = "",
    val lotteryName: String = "彩析",
    val latestIssue: String = "-",
    val targetIssue: String = "-",
    val latestDrawTime: String = "",
    val latestDx: String? = null,
    val latestDs: String? = null,
    val consensusDx: String? = null,
    val consensusDs: String? = null,
    val previousConsensusDx: String? = null,
    val previousConsensusDs: String? = null,
    val previousDxResult: String? = null,
    val previousDsResult: String? = null,
    val plans: List<FloatingPlanItem> = emptyList(),
    val updatedAt: Long = 0L
)

object FloatingOverlayStore {
    private const val PREFS = "floating_overlay"
    private const val KEY = "snapshot"
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    fun save(context: Context, snapshot: FloatingSnapshot) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY, json.encodeToString(snapshot)).apply()
    }

    fun load(context: Context): FloatingSnapshot? {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY, null) ?: return null
        return try { json.decodeFromString<FloatingSnapshot>(raw) } catch (_: Exception) { null }
    }
}


suspend fun publishFloatingSnapshot(
    context: Context,
    lotteryName: String,
    lotteryKey: String,
    latestIssue: String,
    latestDrawTime: String,
    latestDx: String?,
    latestDs: String?,
    targetIssue: String,
    consensus: List<com.caifenxi.app.domain.model.ModelConsensus>,
    predictions: List<com.caifenxi.app.domain.model.PlanPredictionRecord>
) {
    val app = com.caifenxi.app.CaiFenXiApplication.instance
    val records = try { app.consensusStore.loadAll(lotteryKey) } catch (_: Exception) { emptyList() }
    val prevDx = records.firstOrNull { it.targetIssue == latestIssue && it.category == "大小" }
    val prevDs = records.firstOrNull { it.targetIssue == latestIssue && it.category == "单双" }
    val snap = FloatingSnapshot(
        lotteryKey = lotteryKey,
        lotteryName = lotteryName,
        latestIssue = latestIssue,
        targetIssue = targetIssue,
        latestDrawTime = latestDrawTime,
        latestDx = latestDx,
        latestDs = latestDs,
        consensusDx = consensus.firstOrNull { it.category == "大小" }?.leadingDirection,
        consensusDs = consensus.firstOrNull { it.category == "单双" }?.leadingDirection,
        previousConsensusDx = prevDx?.leadingDirection,
        previousConsensusDs = prevDs?.leadingDirection,
        previousDxResult = prevDx?.result,
        previousDsResult = prevDs?.result,
        plans = predictions
            .filter { it.category == "大小" || it.category == "单双" }
            .groupBy { it.planId }
            .map { (_, rows) ->
                val first = rows.first()
                FloatingPlanItem(
                    planId = first.planId,
                    planName = first.planName.ifBlank { first.planId },
                    dx = rows.firstOrNull { it.category == "大小" }?.output,
                    ds = rows.firstOrNull { it.category == "单双" }?.output
                )
            },
        updatedAt = System.currentTimeMillis()
    )
    FloatingOverlayStore.save(context, snap)
}
