package com.caifenxi.app.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.caifenxi.app.domain.execution.ExecutionTask
import com.caifenxi.app.domain.execution.BetCommand
import com.caifenxi.app.domain.execution.BetAction
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.*

/**
 * 执行器 ViewModel：管理执行任务和日志
 * 简化版本，用于测试内置浏览器执行功能
 */
class ExecutorViewModel : ViewModel() {
    
    // 执行状态
    private val _executorStatus = MutableStateFlow(ExecutorStatus.IDLE)
    val executorStatus: StateFlow<ExecutorStatus> = _executorStatus.asStateFlow()
    
    // 当前任务
    private val _currentTask = MutableStateFlow<ExecutionTask?>(null)
    val currentTask: StateFlow<ExecutionTask?> = _currentTask.asStateFlow()
    
    // 执行日志
    private val _executorLogs = MutableStateFlow<List<LogEntry>>(emptyList())
    val executorLogs: StateFlow<List<LogEntry>> = _executorLogs.asStateFlow()
    
    // 执行统计
    private val _executorStats = MutableStateFlow(ExecutorStats())
    val executorStats: StateFlow<ExecutorStats> = _executorStats.asStateFlow()
    
    init {
        // 初始化
        addLog("执行器初始化完成")
    }
    
    /**
     * 开始执行任务
     */
    fun startTask(task: ExecutionTask) {
        viewModelScope.launch {
            _executorStatus.value = ExecutorStatus.RUNNING
            _currentTask.value = task
            
            addLog("开始执行任务: ${task.cmdId}")
            
            // 模拟执行过程
            kotlinx.coroutines.delay(2000)
            
            // 模拟成功执行
            val success = (task.cmdId.hashCode() % 2) == 0
            
            if (success) {
                _executorStatus.value = ExecutorStatus.COMPLETED
                addLog("任务执行成功: ${task.cmdId}")
            } else {
                _executorStatus.value = ExecutorStatus.FAILED
                addLog("任务执行失败: ${task.cmdId}")
            }
            
            // 更新统计
            val currentStats = _executorStats.value
            _executorStats.value = currentStats.copy(
                totalTasks = currentStats.totalTasks + 1,
                successfulTasks = if (success) currentStats.successfulTasks + 1 else currentStats.successfulTasks,
                failedTasks = if (!success) currentStats.failedTasks + 1 else currentStats.failedTasks
            )
            
            // 清空当前任务
            _currentTask.value = null
            _executorStatus.value = ExecutorStatus.IDLE
        }
    }
    
    /**
     * 停止执行任务
     */
    fun stopTask(taskId: String) {
        viewModelScope.launch {
            _executorStatus.value = ExecutorStatus.CANCELLED
            _currentTask.value = null
            addLog("任务已取消: $taskId")
        }
    }
    
    /**
     * 停止所有任务
     */
    fun stopAllTasks() {
        viewModelScope.launch {
            _executorStatus.value = ExecutorStatus.IDLE
            _currentTask.value = null
            addLog("所有任务已停止")
        }
    }
    
    /**
     * 清空日志
     */
    fun clearLogs() {
        _executorLogs.value = emptyList()
        _executorStats.value = ExecutorStats()
        addLog("日志已清空")
    }
    
    /**
     * 生成测试任务
     */
    fun generateTestTask(): ExecutionTask {
        val betCommand = BetCommand(
            cmdId = "test_${System.currentTimeMillis()}",
            lotteryKey = "pk10",
            issue = "${System.currentTimeMillis()}",
            bets = listOf(
                BetAction(BetAction.CAT_DX, "大"),
                BetAction(BetAction.CAT_DS, "单")
            ),
            amountText = "10",
            source = "test",
            createdAt = System.currentTimeMillis(),
            expireAt = System.currentTimeMillis() + 300000 // 5分钟后过期
        )
        
        return ExecutionTask(
            cmdId = betCommand.cmdId,
            lotteryKey = betCommand.lotteryKey,
            issue = betCommand.issue,
            dx = "大",
            ds = "单",
            amountText = betCommand.amountText,
            combo = null,
            predNumbers = emptyList(),
            textActions = emptyList(),
            source = betCommand.source,
            executor = "webview",
            status = ExecutionTask.TaskStatus.CREATED,
            retryCount = 0,
            retryOf = null,
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis(),
            expireAt = betCommand.expireAt,
            lastError = null,
            result = null
        )
    }
    
    /**
     * 执行器状态枚举
     */
    enum class ExecutorStatus {
        IDLE,        // 空闲
        RUNNING,    // 运行中
        COMPLETED,   // 已完成
        FAILED,      // 失败
        CANCELLED   // 已取消
    }
    
    /**
     * 执行器统计信息
     */
    data class ExecutorStats(
        val totalTasks: Int = 0,
        val successfulTasks: Int = 0,
        val failedTasks: Int = 0,
        val successRate: Float = 0f
    ) {
        val successRatePercent: Float
            get() = if (totalTasks > 0) (successfulTasks * 100f / totalTasks) else 0f
    }
    
    /**
     * 日志条目
     */
    data class LogEntry(
        val taskId: String,
        val message: String,
        val details: String,
        val success: Boolean,
        val timestamp: Long
    )
    
    /**
     * 添加日志
     */
    private fun addLog(message: String, details: String = "", success: Boolean = true) {
        val timestamp = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault())
            .format(java.util.Date())
        val log = LogEntry(
            taskId = _currentTask.value?.cmdId ?: "system",
            message = message,
            details = details,
            success = success,
            timestamp = System.currentTimeMillis()
        )
        _executorLogs.value = _executorLogs.value + log
    }
}