package com.caifenxi.app.ui.screens

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.caifenxi.app.domain.model.*
import com.caifenxi.app.domain.plan.NovaPlanAnalytics
import com.caifenxi.app.domain.plan.NovaPlanPool
import com.caifenxi.app.domain.plan.NovaPlanWorkbench
import com.caifenxi.app.ui.MainViewModel
import com.caifenxi.app.ui.components.CaptionMuted
import com.caifenxi.app.ui.components.GlobalCard
import com.caifenxi.app.ui.components.PrimaryButton
import com.caifenxi.app.ui.components.SectionTitle
import com.caifenxi.app.ui.theme.CaiTokens
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

private enum class NovaPlanTab(val label: String) {
    OVERVIEW("总览"), LIBRARY("计划库"), LEADERBOARD("排行榜"), BACKTEST("回测"), PREDICTIONS("预测记录"), CONSENSUS("共识预测"), RECORDS("历史战绩")
}

/**
 * Nova 新计划池：采用“实验室 + 计划引擎”的轻量信息架构.
 * 核心原则：少筛选、少页面、重要信息前置；详情通过点选计划进入，不在首页堆叠所有控制项。
 */
@Composable
fun NovaPlanScreen(vm: MainViewModel) {
    var tab by remember { mutableStateOf(NovaPlanTab.OVERVIEW) }
    var selectedId by remember { mutableStateOf<String?>(null) }
    var filter by remember { mutableStateOf("全部") }
    var cycle by remember { mutableStateOf(1) }
    var backtestPeriods by remember { mutableStateOf(500) }
    var running by remember { mutableStateOf(false) }
    var selectedReport by remember { mutableStateOf<NovaPlanAnalytics.BacktestReport?>(null) }
    var leaderboard by remember { mutableStateOf<List<Pair<PlanDefinition, NovaPlanAnalytics.BacktestReport>>>(emptyList()) }
    var leaderboardLoading by remember { mutableStateOf(false) }
    var leaderboardFilter by remember { mutableStateOf("全部") }
    var leaderboardStage by remember { mutableStateOf(0) }
    var explanation by remember { mutableStateOf<NovaPlanWorkbench.Explanation?>(null) }
    var ensemble by remember { mutableStateOf<NovaPlanWorkbench.Ensemble?>(null) }
    val scope = rememberCoroutineScope()
    val history = vm.history.value
    val records = vm.planHistory.value
    val cockpitId = vm.prefs.value.cockpitPlanId
    val customPlans = vm.customPlans.value.map { it.toDefinition() }.filter { it.planId.startsWith("NOVA-CUSTOM-") }
    val allPlans = (NovaPlanPool.ALL + customPlans).distinctBy { it.planId }
    val filtered = allPlans.filter { filter == "全部" || it.playType == filter }
    val selected = selectedId?.let { id -> allPlans.firstOrNull { it.planId == id } }
    val target = vm.nextIssueText.value.takeIf { it.isNotBlank() && it != "-" } ?: vm.planVM.planTargetIssue.value

    LaunchedEffect(tab, target) {
        if (tab == NovaPlanTab.CONSENSUS) vm.refreshPlanConsensusTab()
    }
    LaunchedEffect(cycle, backtestPeriods, leaderboardFilter, leaderboardStage, history.size) {
        if (tab == NovaPlanTab.LEADERBOARD && history.size >= 6) {
            leaderboardLoading = true
            leaderboard = withContext(Dispatchers.Default) {
                val candidates = allPlans.filter { leaderboardFilter == "全部" || it.playType == leaderboardFilter }
                candidates.mapNotNull { plan ->
                    val baseReport = NovaPlanAnalytics.backtest(plan.copy(cyclePeriods = cycle), history, backtestPeriods.coerceAtMost(10000))
                    val report = if (leaderboardStage == 0) baseReport else {
                        val stage = NovaPlanAnalytics.stageBacktest(plan.copy(cyclePeriods = cycle), history, backtestPeriods.coerceAtMost(10000), leaderboardStage)
                        baseReport.copy(
                            periods = stage.periods, hits = stage.hits, misses = stage.misses,
                            hitRate = stage.hitRate, randomBaseline = stage.randomBaseline, edge = stage.edge,
                            maxHitStreak = stage.maxHitStreak, maxMissStreak = stage.maxMissStreak, stability = stage.stability
                        )
                    }
                    plan to report
                }.sortedWith(compareByDescending<Pair<PlanDefinition, NovaPlanAnalytics.BacktestReport>> { leaderboardScore(it.second) }
                    .thenByDescending { it.second.hitRate }
                    .thenByDescending { it.second.stability })
            }
            leaderboardLoading = false
        }
    }
    LaunchedEffect(cycle) { selectedReport = null }

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = CaiTokens.ScreenHPadding, vertical = CaiTokens.S12),
        verticalArrangement = Arrangement.spacedBy(CaiTokens.S8),
        contentPadding = PaddingValues(bottom = CaiTokens.ScreenBottom)
    ) {
        item {
            Text("新计划池", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            CaptionMuted("NovaPlan ${NovaPlanPool.VERSION} · 独立算法池，与计划引擎的预测、回测、结算、共识数据互通")
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                NovaPlanTab.values().forEach { t -> FilterChip(selected = tab == t, onClick = { tab = t }, label = { Text(t.label) }) }
            }
        }

        item {
            GlobalCard(containerColor = MaterialTheme.colorScheme.secondaryContainer) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(Modifier.weight(1f)) {
                        Text("本期状态", fontWeight = FontWeight.Bold)
                        Text("目标第 ${target.ifBlank { "-" }} 期 · ${filtered.size} 个计划")
                        CaptionMuted(if (cockpitId.isBlank()) "当前预测来源：自动计划池" else "当前驾驶舱：$cockpitId · 周期 ${vm.prefs.value.cockpitPlanCyclePeriods}期")
                    }
                    if (selected != null) Text("已选", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                }
            }
        }

        when (tab) {
            NovaPlanTab.OVERVIEW -> {
                item {
                    GlobalCard {
                        Text("计划池概览", fontWeight = FontWeight.Bold)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                            SummaryBox("总计划", allPlans.size.toString(), Modifier.weight(1f))
                            SummaryBox("大小", allPlans.count { it.playType == "大小" }.toString(), Modifier.weight(1f))
                            SummaryBox("单双", allPlans.count { it.playType == "单双" }.toString(), Modifier.weight(1f))
                            SummaryBox("组合", allPlans.count { it.playType == "组合" }.toString(), Modifier.weight(1f))
                        }
                        Spacer(Modifier.height(8.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            PrimaryButton("计划库", onClick = { tab = NovaPlanTab.LIBRARY }, modifier = Modifier.weight(1f))
                            PrimaryButton("回测", onClick = { tab = NovaPlanTab.BACKTEST }, ghost = true, modifier = Modifier.weight(1f))
                            PrimaryButton("共识", onClick = { tab = NovaPlanTab.CONSENSUS }, ghost = true, modifier = Modifier.weight(1f))
                        }
                    }
                }
                item {
                    SectionTitle("当前计划")
                    if (selected == null) GlobalCard { CaptionMuted("进入计划库点选计划，详情会固定显示在顶部。") }
                    else PlanDetailCard(selected, history, records, vm.prefs.value, cycle, vm.planVM.runtimeForPlan(selected.planId), vm.currentPredictions.value.firstOrNull { it.planId == selected.planId }, selected.planId == cockpitId, { vm.selectCockpitPlan(selected.planId, cycle) }, { explanation = NovaPlanWorkbench.explain(selected, history) }, { tab = NovaPlanTab.RECORDS }, { selectedId = null })
                }
            }
            NovaPlanTab.LIBRARY -> {
                item {
                    GlobalCard {
                        Text("计划库", fontWeight = FontWeight.Bold)
                        CaptionMuted("像实验室一样点计划看详情；筛选只保留最常用的玩法分类")
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                            (listOf("全部") + NovaPlanPool.PLAY_TYPES).forEach { p -> FilterChip(selected = filter == p, onClick = { filter = p }, label = { Text(p) }) }
                        }
                        Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 5.dp), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                            NovaPlanPool.CYCLE_OPTIONS.forEach { n -> FilterChip(selected = cycle == n, onClick = { cycle = n }, label = { Text("执行${n}期") }) }
                        }
                    }
                }
                renderPlanLibrary(this, history, records, filtered, selected, cycle, vm.prefs.value,
                    onSelect = { selectedId = it; vm.loadPlanDetail(it) },
                    onExplain = { p -> explanation = NovaPlanWorkbench.explain(p, history) },
                    onAdd = { /* 自定义计划统一放到计划引擎，Nova 页面保持轻量 */ })
                selected?.let { p -> item { PlanDetailCard(p, history, records, vm.prefs.value, cycle, vm.planVM.runtimeForPlan(p.planId), vm.currentPredictions.value.firstOrNull { it.planId == p.planId }, p.planId == cockpitId, { vm.selectCockpitPlan(p.planId, cycle) }, { explanation = NovaPlanWorkbench.explain(p, history) }, { tab = NovaPlanTab.RECORDS }, {}) } }
            }
            NovaPlanTab.LEADERBOARD -> {
                item { LeaderboardHeader(backtestPeriods, { backtestPeriods = it }, leaderboardFilter, { leaderboardFilter = it }, leaderboardStage, { leaderboardStage = it }, leaderboardLoading) }
                if (history.size < 6) {
                    item { GlobalCard { CaptionMuted("历史开奖样本不足，至少需要6期数据后才能生成统一排行榜。") } }
                } else if (leaderboardLoading) {
                    item { GlobalCard { Text("正在计算统一排行榜…", fontWeight = FontWeight.Bold); LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp)) } }
                } else if (leaderboard.isEmpty()) {
                    item { GlobalCard { CaptionMuted("暂无可排行计划。") } }
                } else {
                    item {
                        GlobalCard {
                            Text("统一回测排行榜", fontWeight = FontWeight.Bold)
                            CaptionMuted("所有新计划使用同一回测窗口、同一 Walk-forward 规则统一比较；综合分只用于排序，不代表真实概率。")
                            Spacer(Modifier.height(6.dp))
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("排名 / 计划", fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.8f))
                                Text("胜率", fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.8f))
                                Text("Edge", fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.8f))
                                Text("稳定", fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.8f))
                            }
                        }
                    }
                    leaderboard.forEachIndexed { index, row ->
                        item(key = "rank-${row.first.planId}") { LeaderboardRow(index + 1, row.first, row.second, selected?.planId == row.first.planId, { selectedId = row.first.planId; tab = NovaPlanTab.LIBRARY; vm.loadPlanDetail(row.first.planId) }) }
                    }
                }
            }
            NovaPlanTab.BACKTEST -> {
                item { ArenaHeader(backtestPeriods, { backtestPeriods = it }, running) {
                    selected?.let { plan -> scope.launch { running = true; selectedReport = withContext(Dispatchers.Default) { NovaPlanAnalytics.backtest(plan.copy(cyclePeriods = cycle), history, backtestPeriods.coerceAtMost(10000)) }; running = false } }
                } }
                if (selected == null) item { GlobalCard { Text("先选择一个计划", fontWeight = FontWeight.Bold); CaptionMuted("回测页面只保留一个核心动作：选计划 → 设回测期数 → 开始回测。") } }
                else {
                    item { BacktestCard(selected, selectedReport) }
                    selectedReport?.let { r -> item { GlobalCard { Text("回测摘要", fontWeight = FontWeight.Bold); Text("样本 ${r.periods} · 命中 ${r.hits} · 错 ${r.misses} · 胜率 ${(r.hitRate*100).roundToInt()}%"); Text("基准 ${(r.randomBaseline*100).roundToInt()}% · Edge ${(r.edge*100).roundToInt()}% · 稳定性 ${(r.stability*100).roundToInt()}%"); Text("最长连中 ${r.maxHitStreak} · 最长连错 ${r.maxMissStreak}") } } }
                }
            }
            NovaPlanTab.PREDICTIONS -> {
                val current = vm.currentPredictions.value.filter { target.isBlank() || it.targetIssue == target }
                item { GlobalCard { Text("预测记录", fontWeight = FontWeight.Bold); CaptionMuted("目标第 ${target.ifBlank { "-" }} 期 · 当前实际输出来源与计划引擎保持一致"); Text("共 ${current.size} 条") } }
                if (current.isEmpty()) item { GlobalCard { CaptionMuted("暂无本期预测。同步开奖或刷新预测后再查看。") } }
                current.forEach { r -> item(key = "prediction-${r.planId}-${r.targetIssue}") { GlobalCard { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Column(Modifier.weight(1f)) { Text(r.planName.ifBlank { r.planId }, fontWeight = FontWeight.Bold); CaptionMuted("${r.category} · 第${r.targetIssue}期"); Text(r.output, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }; Column(horizontalAlignment = androidx.compose.ui.Alignment.End) { Text("${r.scoreAtPredict.toInt()}分", fontWeight = FontWeight.Bold); CaptionMuted("权重 ${"%.2f".format(r.weightAtPredict)}") } } } } }
            }
            NovaPlanTab.CONSENSUS -> {
                val cons = vm.consensus.value.filter { it.targetIssue == target }
                item { GlobalCard { Text("共识预测", fontWeight = FontWeight.Bold); CaptionMuted("目标第 ${target.ifBlank { "-" }} 期 · 与计划引擎共识数据统一") } }
                if (cons.isEmpty()) item { GlobalCard { CaptionMuted("暂无共识预测。请先刷新开奖并生成计划预测。") } }
                cons.forEach { c -> item(key = "cons-${c.category}-${c.targetIssue}") { GlobalCard { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("${c.category} · ${c.leadingDirection}", fontWeight = FontWeight.Bold); Text("${(c.supportRatio*100).roundToInt()}%", fontWeight = FontWeight.Bold) }; CaptionMuted("参与 ${c.participatingPlans} 个计划 · 分歧 ${(c.disagreement*100).roundToInt()}%"); LinearProgressIndicator({ c.supportRatio.toFloat().coerceIn(0f,1f) }, Modifier.fillMaxWidth()) } } }
            }
            NovaPlanTab.RECORDS -> renderRecords(this, history, records, selected, cycle)
        }
    }

    explanation?.let { e ->
        AlertDialog(onDismissRequest = { explanation = null }, title = { Text("计划解释") }, text = { Column { Text(e.title, fontWeight = FontWeight.Bold); CaptionMuted("${e.planId} · 窗口 ${e.inputWindow}期 · 评分 ${e.score.roundToInt()}"); e.factors.forEach { Text("${it.first} · ${(it.second*100).roundToInt()}%") } } }, confirmButton = { TextButton(onClick = { explanation = null }) { Text("关闭") } })
    }
}

private fun renderOverview(
    scope: LazyListScope,
    history: List<DrawRecord>,
    plans: List<PlanDefinition>,
    selected: PlanDefinition?,
    periods: Int,
    go: (String) -> Unit
) {
    scope.item {
        GlobalCard {
            Text("新计划池驾驶舱", fontWeight = FontWeight.Bold)
            Text("${plans.size} 个计划 · 回测窗口 ${periods} 期 · 支持大小/单双/组合/数字/位置")
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                SummaryBox("大小", plans.count { it.playType == "大小" }.toString(), Modifier.weight(1f))
                SummaryBox("单双", plans.count { it.playType == "单双" }.toString(), Modifier.weight(1f))
                SummaryBox("组合", plans.count { it.playType == "组合" }.toString(), Modifier.weight(1f))
                SummaryBox("数字", plans.count { it.playType == "数字" }.toString(), Modifier.weight(1f))
                SummaryBox("位置", plans.count { it.playType == "位置" }.toString(), Modifier.weight(1f))
            }
            Spacer(Modifier.height(8.dp))
            CaptionMuted("竞品常见的“计划→周期→结果→胜率→排行”链路已经统一到 Nova；历史开奖与回测数据继续由原数据层提供。")
            if (selected != null) Text("当前计划：${selected.planName} · ${selected.playType}${if (selected.positionIndex >= 0) " · ${NovaPlanPool.meta(selected).positionLabel}" else ""}")
            Spacer(Modifier.height(6.dp))
            PrimaryButton("打开计划库", onClick = { go("计划库") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                PrimaryButton("排行榜", onClick = { go("排行榜") }, ghost = true, modifier = Modifier.weight(1f))
                PrimaryButton("战绩", onClick = { go("战绩") }, ghost = true, modifier = Modifier.weight(1f))
                PrimaryButton("回测", onClick = { go("回测") }, ghost = true, modifier = Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun SummaryBox(label: String, value: String, modifier: Modifier) {
    Column(modifier, horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally) {
        Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text(label, fontSize = 10.sp)
    }
}

private fun renderPlanLibrary(
    scope: LazyListScope,
    history: List<DrawRecord>,
    records: List<PlanPredictionRecord>,
    plans: List<PlanDefinition>,
    selected: PlanDefinition?,
    cycle: Int,
    prefs: com.caifenxi.app.domain.model.UserPrefs,
    onSelect: (String) -> Unit,
    onExplain: (PlanDefinition) -> Unit,
    onAdd: () -> Unit
) {
    scope.item {
        GlobalCard {
            Text("计划记录", fontWeight = FontWeight.Bold)
            CaptionMuted("按竞品式表格查看：计划周期 / 最终截止 / 计划结果 / 推荐号；点击任意计划即可打开详情、回测和战绩。")
            PrimaryButton("＋ 新增计划", onClick = onAdd, modifier = Modifier.fillMaxWidth())
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("计划周期", fontWeight = FontWeight.Bold)
                Text("最终截止", fontWeight = FontWeight.Bold)
                Text("计划结果", fontWeight = FontWeight.Bold)
                Text("推荐号", fontWeight = FontWeight.Bold)
            }
        }
    }
    // 不使用 LazyListScope.items(List) 扩展，避免不同 Compose 版本下的泛型/作用域解析问题。
    // 所有计划仍作为独立的 LazyList item 渲染，不改变原有 UI 和交互。
    if (plans.size > 80) {
        scope.item {
            CaptionMuted("当前筛选 ${plans.size} 个，列表仅渲染前 80 个以保持流畅；请用玩法/分组/搜索继续缩小范围。")
        }
    }
    plans.take(80).forEach { plan ->
        scope.item {
            // 列表不在主线程同步跑 predict，避免卡顿；推荐号优先用已有战绩/预测记录
            val latest = records.firstOrNull { record -> record.planId == plan.planId }
            val preview = latest?.output ?: "点查看"
            GlobalCard(containerColor = if (selected?.planId == plan.planId) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface, onClick = { onSelect(plan.planId) }) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(Modifier.weight(1.1f)) {
                        Text("1/${cycle}期", fontWeight = FontWeight.SemiBold)
                        Text("执行周期", fontSize = 11.sp)
                    }
                    Column(Modifier.weight(1f)) {
                        Text("窗口${plan.window}期")
                        Text("截止${history.lastOrNull()?.issue ?: "-"}", fontSize = 11.sp)
                    }
                    Column(Modifier.weight(1.2f)) {
                        Text(if (latest?.settled == true) if (latest.hit == true) "中" else "错" else "待开")
                        Text(plan.playType, fontSize = 11.sp)
                    }
                    Column(Modifier.weight(1.6f)) {
                        Text(preview, fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            FilterChip(selected = selected?.planId == plan.planId, onClick = { onSelect(plan.planId) }, label = { Text("查看") })
                            FilterChip(selected = false, onClick = { onExplain(plan) }, label = { Text("解释") })
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RankingRow(row: NovaPlanWorkbench.ArenaRow, selected: Boolean, onSelect: () -> Unit) {
    // 整卡可点，避免只点小按钮“没反应”
    GlobalCard(
        containerColor = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
        onClick = onSelect
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column(Modifier.weight(1f)) {
                Text(row.plan.planName, fontWeight = FontWeight.SemiBold)
                CaptionMuted("${row.plan.planId} · ${row.plan.playType}${if (row.plan.positionIndex >= 0) " · ${NovaPlanPool.meta(row.plan).positionLabel}" else ""}")
                Text("胜率 ${(row.report.hitRate * 100).toInt()}% · 样本 ${row.report.periods} · 连中 ${row.report.maxHitStreak} · 连错 ${row.report.maxMissStreak}")
                Text("Edge ${(row.report.edge * 100).toInt()}% · 稳定性 ${(row.report.stability * 100).toInt()}% · ${row.lifecycle}", fontSize = 11.sp)
            }
            Column(horizontalAlignment = androidx.compose.ui.Alignment.End) {
                Text("${row.rankScore.toInt()}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("查看详情", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        }
    }
}

private fun renderRecords(
    scope: LazyListScope,
    history: List<DrawRecord>,
    records: List<PlanPredictionRecord>,
    selected: PlanDefinition?,
    cycle: Int
) {
    val rows = if (selected == null) records else records.filter { it.planId == selected.planId }
    scope.item {
        GlobalCard {
            Text("计划战绩", fontWeight = FontWeight.Bold)
            CaptionMuted("只统计已结算预测；完整数据不限制500期，当前页面按最近记录分页展示。")
            Text("${selected?.planName ?: "全部计划"} · 周期 ${cycle}期 · 记录 ${rows.size}")
        }
    }
    rows.take(200).forEach { r ->
        scope.item(key = "${r.planId}-${r.targetIssue}-${r.cutoffIssue}") {
            GlobalCard {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(Modifier.weight(1f)) {
                        Text("${r.targetIssue} · ${r.planName}", fontWeight = FontWeight.SemiBold)
                        Text("${r.category} · 预测 ${r.output}", fontSize = 12.sp)
                        Text(if (r.settled) "已结算 · ${if (r.hit == true) "中" else "错"}" else "待开", fontSize = 12.sp)
                    }
                    Text(if (r.hit == true) "中" else if (r.settled) "错" else "?", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun HistoryRecordCard(r: PlanPredictionRecord) {
    val result = when {
        !r.settled -> "待开"
        r.hit == true -> "中"
        else -> "错"
    }
    val resultColor = when (result) {
        "中" -> Color(0xFF2E7D32)
        "错" -> Color(0xFFC62828)
        else -> Color(0xFFF9A825)
    }
    GlobalCard {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column(Modifier.weight(1f)) {
                Text("第 ${r.targetIssue} 期 · ${r.planName.ifBlank { r.planId }}", fontWeight = FontWeight.Bold)
                CaptionMuted("截止 ${r.cutoffIssue} · ${r.category}")
                Text("预测：${r.output}", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                CaptionMuted("预测评分 ${"%.1f".format(r.scoreAtPredict)} · 权重 ${"%.3f".format(r.weightAtPredict)}")
            }
            Text(result, fontWeight = FontWeight.Bold, color = resultColor, fontSize = 16.sp)
        }
    }
}

private fun leaderboardScore(r: NovaPlanAnalytics.BacktestReport): Double =
    r.hitRate * 0.50 + r.edge.coerceIn(-1.0, 1.0) * 0.25 + r.stability * 0.15 +
        (r.maxHitStreak.toDouble() / (r.maxHitStreak + r.maxMissStreak + 1.0)) * 0.10

@Composable
private fun LeaderboardHeader(
    periods: Int,
    onPeriods: (Int) -> Unit,
    filter: String,
    onFilter: (String) -> Unit,
    stage: Int,
    onStage: (Int) -> Unit,
    loading: Boolean
) {
    GlobalCard {
        Text("统一回测排行榜", fontWeight = FontWeight.Bold)
        CaptionMuted(if (loading) "正在按统一规则重新计算…" else "所有计划统一回测，自动按综合表现排序")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            (listOf("全部") + NovaPlanPool.PLAY_TYPES).forEach { p ->
                FilterChip(selected = filter == p, onClick = { onFilter(p) }, label = { Text(p) })
            }
        }
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf(0 to "全部", 1 to "首期", 2 to "二期", 3 to "三期").forEach { (value, label) ->
                FilterChip(selected = stage == value, onClick = { onStage(value) }, label = { Text(label) })
            }
        }
        CaptionMuted(if (stage == 0) "全部：按原多期计划口径统计；选择首期/二期/三期后，对错率、Edge、稳定性和排名全部独立计算。" else "${listOf("", "首期", "二期", "三期")[stage]}为独立统计，不与其它期次混合。")
        Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { onPeriods((periods - 50).coerceAtLeast(20)) }) { Text("−") }
            Text("回测 ${periods} 期", modifier = Modifier.padding(top = 12.dp), fontWeight = FontWeight.Bold)
            OutlinedButton(onClick = { onPeriods((periods + 50).coerceAtMost(10000)) }) { Text("+") }
        }
    }
}

@Composable
private fun LeaderboardRow(
    rank: Int,
    plan: PlanDefinition,
    report: NovaPlanAnalytics.BacktestReport,
    selected: Boolean,
    onClick: () -> Unit
) {
    val rankText = when (rank) { 1 -> "🥇"; 2 -> "🥈"; 3 -> "🥉"; else -> "#$rank" }
    GlobalCard(containerColor = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            Text(rankText, fontWeight = FontWeight.Bold, modifier = Modifier.width(38.dp))
            Column(Modifier.weight(1.8f)) {
                Text(plan.planName, fontWeight = FontWeight.Bold)
                CaptionMuted("${plan.playType} · ${plan.algorithm} · ${report.periods}样本")
            }
            Text("${(report.hitRate * 100).roundToInt()}%", fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.8f))
            Text("${(report.edge * 100).roundToInt()}%", fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.8f))
            Text("${(report.stability * 100).roundToInt()}%", fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.8f))
        }
        Spacer(Modifier.height(5.dp))
        CaptionMuted("对 ${report.hits} · 错 ${report.misses} · 连中 ${report.maxHitStreak} · 连错 ${report.maxMissStreak} · 综合分 ${"%.3f".format(leaderboardScore(report))}")
        TextButton(onClick = onClick) { Text("查看计划") }
    }
}

@Composable
private fun BacktestCard(plan: PlanDefinition, report: NovaPlanAnalytics.BacktestReport?) {
    GlobalCard {
        Text("${plan.planName} · 回测结果", fontWeight = FontWeight.Bold)
        if (report == null) CaptionMuted("正在计算或历史样本不足") else {
            Text("样本 ${report.periods} · 对 ${report.hits} · 错 ${report.misses}")
            Text("胜率 ${(report.hitRate * 100).toInt()}% · 随机基准 ${(report.randomBaseline * 100).toInt()}% · Edge ${(report.edge * 100).toInt()}%")
            Text("最大连中 ${report.maxHitStreak} · 最大连错 ${report.maxMissStreak} · 稳定性 ${(report.stability * 100).toInt()}%")
            if (report.stages.isNotEmpty()) {
                Spacer(Modifier.height(6.dp))
                Text("分期对错率", fontWeight = FontWeight.SemiBold)
                report.stages.toSortedMap().forEach { (stage, r) ->
                    Text("${listOf("", "首期", "二期", "三期")[stage]}：${r.hits} 对 / ${r.misses} 错 · ${(r.hitRate * 100).toInt()}%", fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
private fun PlanDetailCard(
    plan: PlanDefinition,
    history: List<DrawRecord>,
    records: List<PlanPredictionRecord>,
    prefs: com.caifenxi.app.domain.model.UserPrefs,
    cycle: Int,
    runtime: com.caifenxi.app.domain.model.PlanRuntime,
    currentPrediction: PlanPredictionRecord?,
    selected: Boolean,
    onUse: () -> Unit,
    onExplain: () -> Unit,
    onViewRecords: () -> Unit,
    onClose: () -> Unit = {}
) {
    val count = when (plan.playType) {
        "组合" -> prefs.comboPredCount
        "数字" -> prefs.zuheTopN
        "位置" -> prefs.positionTopN
        else -> 1
    }
    val result = NovaPlanAnalytics.predict(plan.copy(cyclePeriods = cycle), history, count)
    val historyRows = records.filter { it.planId == plan.planId }.take(10)
    GlobalCard(containerColor = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("计划详情 · ${plan.planName}", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            TextButton(onClick = onClose) { Text("关闭") }
        }
        CaptionMuted("${plan.planId} · ${plan.algorithm} · ${plan.playType}${if (plan.positionIndex >= 0) " · ${NovaPlanPool.meta(plan).positionLabel}" else ""} · 窗口${plan.window}期 · 执行${cycle}期（生涯胜率来自引擎；周期胜率请到「回测/排行榜」按当前周期计算）")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            SummaryBox("胜率", runtime.hitRatePercent, Modifier.weight(1f))
            SummaryBox("样本", runtime.sampleCount.toString(), Modifier.weight(1f))
            SummaryBox("连中", runtime.maxConsecutiveHit.toString(), Modifier.weight(1f))
            SummaryBox("连错", runtime.maxConsecutiveMiss.toString(), Modifier.weight(1f))
        }
        Spacer(Modifier.height(8.dp))
        Text("当期预测：${currentPrediction?.output ?: result?.output ?: "暂无"}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        CaptionMuted("目标期 ${currentPrediction?.targetIssue ?: "-"} · 输出数量按设置：组合${prefs.comboPredCount} / 号码${prefs.zuheTopN} / 位置${prefs.positionTopN}")
        if (historyRows.isNotEmpty()) {
            Spacer(Modifier.height(6.dp))
            Text("最近战绩", fontWeight = FontWeight.SemiBold)
            historyRows.forEach { r -> Text("${r.targetIssue} · ${r.output} · ${if (!r.settled) "待开" else if (r.hit == true) "中" else "错"}", fontSize = 12.sp) }
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            PrimaryButton(if (selected) "已用于驾驶舱" else "用于驾驶舱", onClick = onUse, modifier = Modifier.weight(1f), enabled = !selected)
            PrimaryButton("全部战绩", onClick = onViewRecords, ghost = true, modifier = Modifier.weight(1f))
            PrimaryButton("解释", onClick = onExplain, ghost = true, modifier = Modifier.weight(1f))
        }
    }
}

@Composable
private fun ArenaHeader(periods: Int, onPeriods: (Int) -> Unit, running: Boolean, onRun: () -> Unit) {
    GlobalCard {
        Text("排行榜 / 回测窗口", fontWeight = FontWeight.Bold)
        CaptionMuted("回测期数手动调整；支持20～10000期。历史战绩和回测窗口不再固定500期。")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { onPeriods((periods - 50).coerceAtLeast(20)) }) { Text("−") }
            Text("${periods}期", modifier = Modifier.padding(top = 12.dp))
            OutlinedButton(onClick = { onPeriods((periods + 50).coerceAtMost(10000)) }) { Text("+") }
        }
        PrimaryButton(if (running) "计算中…" else "开始回测 / 更新排行榜", onClick = onRun, modifier = Modifier.fillMaxWidth(), enabled = !running)
    }
}
