package com.caifenxi.app.domain.btc.hs

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.max

/** v18.2: feedback for the final fused decision, not only individual models. */
class FusionFeedbackStore(context: Context? = null, private val maxRecords: Int = 2000) {
    data class Record(
        val id: String,
        val timeframe: String,
        val predictedUp: Double,
        val actualUp: Boolean,
        val modelComponent: Double,
        val factorComponent: Double,
        val strategyComponent: Double,
        val disagreement: Double,
        val at: Long
    )
    data class Metrics(val samples: Int, val brier: Double, val hitRate: Double, val recentBrier: Double, val baselineBrier: Double)
    data class ComponentMetrics(val modelBrier: Double, val factorBrier: Double, val strategyBrier: Double)
    data class Weights(val model: Double, val factor: Double, val strategy: Double)

    private val prefs = context?.applicationContext?.getSharedPreferences("btc_hs_fusion_feedback_v1", Context.MODE_PRIVATE)
    private val rows = ArrayList<Record>()
    init { load() }

    @Synchronized fun observe(r: Record) {
        if (r.id.isBlank() || rows.any { it.id == r.id }) return
        rows.add(r)
        if (rows.size > maxRecords) rows.subList(0, rows.size - maxRecords).clear()
        persist()
    }

    @Synchronized fun metrics(tf: String): Metrics {
        val all = rows.filter { it.timeframe == tf }
        if (all.isEmpty()) return Metrics(0, .25, 0.0, .25, .25)
        fun brier(rs: List<Record>) = rs.map { val e = it.predictedUp - if (it.actualUp) 1.0 else 0.0; e * e }.average()
        val recent = all.takeLast(minOf(60, all.size))
        val hit = recent.count { (it.predictedUp >= .5) == it.actualUp }.toDouble() / max(1, recent.size)
        return Metrics(all.size, brier(all), hit, brier(recent), brier(all))
    }

    /** Convert attribution performance into runtime fusion weights. More recent lower Brier gets more weight. */
    @Synchronized fun componentMetrics(tf: String): ComponentMetrics {
        val all = rows.filter { it.timeframe == tf }.takeLast(120)
        if (all.isEmpty()) return ComponentMetrics(.25, .25, .25)
        fun error(v: (Record) -> Double): Double = all.map { r ->
            val p = (v(r) + 1.0) / 2.0
            val y = if (r.actualUp) 1.0 else 0.0
            val e = p - y; e * e
        }.average()
        return ComponentMetrics(error { it.modelComponent }, error { it.factorComponent }, error { it.strategyComponent })
    }

    @Synchronized fun weights(tf: String): Weights {
        val all = rows.filter { it.timeframe == tf }.takeLast(120)
        if (all.size < 20) return Weights(.42, .30, .28)
        fun componentError(v: (Record) -> Double): Double {
            val rs = all.map { it to (v(it) + 1.0) / 2.0 }
            return rs.map { (it.second - if (it.first.actualUp) 1.0 else 0.0).let { e -> e * e } }.average()
        }
        val scores = listOf(
            1.0 / (0.05 + componentError { it.modelComponent }),
            1.0 / (0.05 + componentError { it.factorComponent }),
            1.0 / (0.05 + componentError { it.strategyComponent })
        )
        val sum = scores.sum().coerceAtLeast(1e-9)
        val normalized = scores.map { it / sum }
        // Keep diversification: no single source can dominate because of a short lucky streak.
        val clipped = normalized.map { it.coerceIn(.20, .55) }
        val s = clipped.sum()
        return Weights(clipped[0] / s, clipped[1] / s, clipped[2] / s)
    }

    @Synchronized fun recent(tf: String, limit: Int = 100): List<Record> = rows.filter { it.timeframe == tf }.takeLast(limit)
    @Synchronized fun size(): Int = rows.size

    private fun load() = runCatching {
        val a = JSONArray(prefs?.getString("rows", "[]") ?: "[]")
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            rows.add(Record(o.getString("id"), o.getString("tf"), o.getDouble("p"), o.getBoolean("y"), o.getDouble("m"), o.getDouble("f"), o.getDouble("s"), o.getDouble("d"), o.getLong("at")))
        }
        if (rows.size > maxRecords) rows.subList(0, rows.size - maxRecords).clear()
    }
    private fun persist() {
        val p = prefs ?: return
        runCatching {
        val a = JSONArray()
        rows.forEach { r -> a.put(JSONObject().apply {
            put("id",r.id); put("tf",r.timeframe); put("p",r.predictedUp); put("y",r.actualUp)
            put("m",r.modelComponent); put("f",r.factorComponent); put("s",r.strategyComponent); put("d",r.disagreement); put("at",r.at)
        }) }
        p.edit().putString("rows", a.toString()).apply()
        }
    }
}
