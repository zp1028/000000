package com.caifenxi.app.domain.plan

import com.caifenxi.app.domain.model.LotteryConfig
import com.caifenxi.app.domain.model.LotteryType
import com.caifenxi.app.domain.model.PlanDefinition

/**
 * 彩种 → 计划池 唯一入口，禁止跨彩种混用计划定义。
 */
object LotteryPlanPools {

    fun novaPlansFor(type: LotteryType): List<PlanDefinition> = when (type) {
        LotteryType.YDH -> NovaYdhPlanPool.ALL
        LotteryType.K3 -> NovaK3PlanPool.ALL
        LotteryType.PKS, LotteryType.LUCK20 -> NovaPlanPool.ALL
        LotteryType.PC28, LotteryType.OTHER -> emptyList()
    }

    fun novaPlansFor(config: LotteryConfig): List<PlanDefinition> = novaPlansFor(config.type)

    fun find(planId: String, type: LotteryType): PlanDefinition? {
        if (planId.isBlank()) return null
        return when {
            planId.startsWith("NOVA-YDH-") -> NovaYdhPlanPool.find(planId)
            planId.startsWith("NOVA-K3-") -> NovaK3PlanPool.find(planId)
            planId.startsWith("NOVA-") -> NovaPlanPool.find(planId)
            else -> PlanPool.ALL.find { it.planId == planId }
        }?.takeIf { belongsTo(it, type) }
    }

    /** 不指定彩种时按 ID 前缀查找（仅解析用，下单前仍应校验 belongsTo） */
    fun findAny(planId: String): PlanDefinition? {
        if (planId.isBlank()) return null
        return NovaYdhPlanPool.find(planId)
            ?: NovaK3PlanPool.find(planId)
            ?: NovaPlanPool.find(planId)
            ?: PlanPool.ALL.find { it.planId == planId }
    }

    fun belongsTo(plan: PlanDefinition, type: LotteryType): Boolean {
        val id = plan.planId
        return when (type) {
            LotteryType.YDH -> id.startsWith("NOVA-YDH-")
            LotteryType.K3 -> id.startsWith("NOVA-K3-")
            LotteryType.PKS, LotteryType.LUCK20 ->
                id.startsWith("NOVA-") && !id.startsWith("NOVA-YDH-") && !id.startsWith("NOVA-K3-")
                    || PlanPool.ALL.any { it.planId == id }
            LotteryType.PC28, LotteryType.OTHER -> false
        }
    }

    fun legacyPlansFor(type: LotteryType): List<PlanDefinition> =
        if (type == LotteryType.PKS || type == LotteryType.LUCK20) PlanPool.ALL else emptyList()

    fun defaultNovaId(type: LotteryType): String =
        novaPlansFor(type).firstOrNull()?.planId ?: ""
}
