package com.caifenxi.app.ui.screens

import android.content.Intent
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.caifenxi.app.service.DataSyncService
import com.caifenxi.app.ui.MainViewModel
import com.caifenxi.app.ui.components.CaptionMuted
import com.caifenxi.app.ui.components.GlobalCard
import com.caifenxi.app.ui.components.PrimaryButton
import com.caifenxi.app.ui.components.SectionTitle
import com.caifenxi.app.ui.theme.CaiTokens

@Composable
fun SettingsScreen(vm: MainViewModel) {
    val p = vm.prefs.value
    val context = LocalContext.current

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = CaiTokens.ScreenHPadding, vertical = CaiTokens.S16)
            .padding(bottom = CaiTokens.ScreenBottom)
    ) {
        Text("设置", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(CaiTokens.S16))

        SectionTitle("外观")
        GlobalCard {
            Text("主题", fontWeight = FontWeight.SemiBold)
            Row(Modifier.padding(vertical = CaiTokens.S8)) {
                listOf("system" to "跟随系统", "light" to "浅色", "dark" to "深色").forEach { (k, lab) ->
                    FilterChip(
                        selected = p.themeMode == k,
                        onClick = { vm.updatePrefs { it.copy(themeMode = k, darkMode = k == "dark") } },
                        label = { Text(lab) },
                        modifier = Modifier.padding(end = CaiTokens.S8)
                    )
                }
            }
        }

        SectionTitle("参数档位")
        GlobalCard {
            Row {
                listOf("simple" to "简单", "balanced" to "均衡", "pro" to "专业").forEach { (k, lab) ->
                    FilterChip(
                        selected = p.sensitivityMode == k,
                        onClick = { vm.updatePrefs { it.copy(sensitivityMode = k) } },
                        label = { Text(lab) },
                        modifier = Modifier.padding(end = CaiTokens.S8)
                    )
                }
            }
            CaptionMuted("简单档适合浏览；专业档保留更多参数")
        }

        
        SectionTitle("预测数量")
        GlobalCard {
            Text("组合预测条数", fontWeight = FontWeight.SemiBold)
            Row(Modifier.padding(vertical = CaiTokens.S8)) {
                listOf(1, 2, 3, 4).forEach { n ->
                    FilterChip(
                        selected = p.comboPredCount == n,
                        onClick = { vm.updatePrefs { it.copy(comboPredCount = n) } },
                        label = { Text("$n 个") },
                        modifier = Modifier.padding(end = CaiTokens.S8)
                    )
                }
            }
            CaptionMuted("主预测与计划池「组合」类计划均输出前 N 个候选；命中任一即对")
            Spacer(Modifier.height(CaiTokens.S8))
            Text("计划池每期生成数量", fontWeight = FontWeight.SemiBold)
            Row(Modifier.padding(vertical = CaiTokens.S8)) {
                listOf(6, 8, 12, 16, 20, 24).forEach { n ->
                    FilterChip(
                        selected = p.planPoolCount == n,
                        onClick = { vm.updatePrefs { it.copy(planPoolCount = n) } },
                        label = { Text("$n") },
                        modifier = Modifier.padding(end = CaiTokens.S8)
                    )
                }
            }
            CaptionMuted("生成条数；组合/号码候选数见上方「组合预测条数」与位置 TopN")
            Spacer(Modifier.height(CaiTokens.S8))
            Text("位置 / 号码预测 TopN", fontWeight = FontWeight.SemiBold)
            Row(Modifier.padding(vertical = CaiTokens.S8)) {
                listOf(1, 2, 3, 5).forEach { n ->
                    FilterChip(
                        selected = p.positionTopN == n,
                        onClick = { vm.updatePrefs { it.copy(positionTopN = n, zuheTopN = n) } },
                        label = { Text("$n") },
                        modifier = Modifier.padding(end = CaiTokens.S8)
                    )
                }
            }
            CaptionMuted("位置预测与计划池「号码」类输出个数")
        }

        SectionTitle("行为")
        GlobalCard {
            SettingSwitch("自动刷新", p.autoRefresh) { v -> vm.updatePrefs { it.copy(autoRefresh = v) } }
            SettingSwitch("EWMA 自适应", p.ewmaEnabled) { v -> vm.updatePrefs { it.copy(ewmaEnabled = v) } }
            SettingSwitch("预测冻结", p.predFreeze) { v -> vm.updatePrefs { it.copy(predFreeze = v) } }
        }

        Spacer(Modifier.height(CaiTokens.S16))
        PrimaryButton(
            "启动后台开奖监听",
            onClick = { context.startForegroundService(Intent(context, DataSyncService::class.java)) },
            modifier = Modifier.fillMaxWidth()
        )

        SectionTitle("AI（可选）")
        GlobalCard {
            OutlinedTextField(
                value = p.aiApiKey,
                onValueChange = { key -> vm.updatePrefs { it.copy(aiApiKey = key) } },
                label = { Text("API Key") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            CaptionMuted("仅本机保存，留空使用本地规则")
        }

        Spacer(Modifier.height(CaiTokens.S24))
        CaptionMuted("彩析 · 香槟金设计令牌 · 仅供学习研究，请理性购彩")
    }
}

@Composable
private fun SettingSwitch(title: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = CaiTokens.S4),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
