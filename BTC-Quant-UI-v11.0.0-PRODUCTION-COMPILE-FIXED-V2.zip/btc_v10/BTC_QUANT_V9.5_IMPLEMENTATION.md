# BTC Quant v9.5.0 — HS Model Lifecycle & Attribution

- Model lifecycle: candidate / active / degraded / retired
- Recent-vs-baseline feedback drift detection
- Regime-aware model health metadata
- Shadow MFE/MAE and edge-capture attribution
- Snapshot IDs for reproducible decision state
- Lifecycle metadata is informational and does not bypass execution risk gates
