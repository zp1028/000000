package com.caifenxi.app.ui.screens

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.material3.HorizontalDivider
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.layout.width
import androidx.core.content.FileProvider
import com.caifenxi.app.domain.model.BacktestParams
import com.caifenxi.app.domain.plan.NovaPlanPool
import com.caifenxi.app.service.AutoBetAccessibilityService
import com.caifenxi.app.service.AutoBetController
import com.caifenxi.app.ui.ClickRegionPickActivity
import com.caifenxi.app.service.DataSyncService
import com.caifenxi.app.util.AndroidCompat
import com.caifenxi.app.ui.MainViewModel
import com.caifenxi.app.ui.components.CaptionMuted
import com.caifenxi.app.ui.components.GlobalCard
import com.caifenxi.app.ui.components.PrimaryButton
import com.caifenxi.app.ui.components.SectionTitle
import com.caifenxi.app.ui.theme.CaiTokens
import com.caifenxi.app.util.RuntimeLog
import kotlin.math.roundToInt

@Composable
fun SettingsScreen(vm: MainViewModel) {
    val p = vm.prefs.value
    val context = LocalContext.current

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = CaiTokens.ScreenHPadding, vertical = CaiTokens.S16)
            .padding(bottom = CaiTokens.ScreenBottom)
    ) {
        Text("设置", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(CaiTokens.S16))

        SectionTitle("外观")
        GlobalCard {
            Text("主题", fontWeight = FontWeight.SemiBold)
            Row(Modifier.padding(vertical = CaiTokens.S8)) {
                listOf("system" to "跟随系统", "light" to "浅色", "dark" to "深色").forEach { (k, lab) ->
                    FilterChip(
                        selected = p.themeMode == k,
                        onClick = { vm.updatePrefs { it.copy(themeMode = k, darkMode = k == "dark") } },
                        label = { Text(lab) },
                        modifier = Modifier.padding(end = CaiTokens.S8)
                    )
                }
            }
        }

        SectionTitle("参数档位")
        GlobalCard {
            Row {
                listOf("simple" to "简单", "balanced" to "均衡", "pro" to "专业").forEach { (k, lab) ->
                    FilterChip(
                        selected = p.sensitivityMode == k,
                        onClick = { vm.updatePrefs { it.copy(sensitivityMode = k) } },
                        label = { Text(lab) },
                        modifier = Modifier.padding(end = CaiTokens.S8)
                    )
                }
            }
            CaptionMuted("简单档适合浏览;专业档保留更多参数")
        }

        SectionTitle("预测数量")
        GlobalCard {
            Text("组合预测条数", fontWeight = FontWeight.SemiBold)
            Row(Modifier.padding(vertical = CaiTokens.S8)) {
                listOf(1, 2, 3, 4).forEach { n ->
                    FilterChip(
                        selected = p.comboPredCount == n,
                        onClick = { vm.updatePrefs { it.copy(comboPredCount = n) } },
                        label = { Text("$n 个") },
                        modifier = Modifier.padding(end = CaiTokens.S8)
                    )
                }
            }
            CaptionMuted("同步到:首页组合候选、共识「组合」方向数、挂机组合覆盖赔率计算")
            Spacer(Modifier.height(CaiTokens.S8))
            Text("默认计划池容量", fontWeight = FontWeight.SemiBold)
            Row(Modifier.padding(vertical = CaiTokens.S8)) {
                listOf(6, 8, 12, 16, 20, 24).forEach { n ->
                    FilterChip(
                        selected = p.planPoolCount == n,
                        onClick = { vm.updatePrefs { it.copy(planPoolCount = n) } },
                        label = { Text("$n") },
                        modifier = Modifier.padding(end = CaiTokens.S8)
                    )
                }
            }
            CaptionMuted("未在实验室手动勾选时,取模板前 N 条+自定义计划(不再随机)")
            Spacer(Modifier.height(CaiTokens.S8))
            Text("位置 / 号码预测数量 TopN", fontWeight = FontWeight.SemiBold)
            Row(
                Modifier.horizontalScroll(rememberScrollState()).padding(vertical = CaiTokens.S8),
                horizontalArrangement = Arrangement.spacedBy(CaiTokens.S8)
            ) {
                // 快乐8 任选可多号；PK10 位置仍用较小 TopN
                listOf(1, 2, 3, 5, 8, 10, 15, 20).forEach { n ->
                    FilterChip(
                        selected = p.positionTopN == n,
                        onClick = { vm.updatePrefs { it.copy(positionTopN = n, zuheTopN = n) } },
                        label = { Text("$n") }
                    )
                }
            }
            CaptionMuted(
                "PK10：每位位置 TopN。" +
                    "极速快乐8/幸运20：取消多位置，仅「任选号码」一个池，从 1～80 选 TopN；" +
                    "与当期开出任一号码相同即中。"
            )
            Spacer(Modifier.height(CaiTokens.S8))
            PrimaryButton(
                "应用全局（组合条数 / 位置数量）",
                onClick = {
                    // prefs 已在点 Chip 时写入；再显式保存一次并触发本地重算预测
                    val cur = vm.prefs.value
                    vm.updatePrefs {
                        it.copy(
                            comboPredCount = cur.comboPredCount.coerceIn(1, 4),
                            positionTopN = cur.positionTopN.coerceIn(1, 20),
                            zuheTopN = cur.positionTopN.coerceIn(1, 20)
                        )
                    }
                    try { vm.recomputeFromCache() } catch (_: Exception) {}
                    vm.statusText.value =
                        "已应用全局：组合${cur.comboPredCount}条 · 位置Top${cur.positionTopN}（首页/计划/图表）"
                },
                modifier = Modifier.fillMaxWidth()
            )
            CaptionMuted("应用后全局生效；图表若已打开请再点「开始回测」按新条数与赔率重算。")
        }

        SectionTitle("悬浮窗")
        GlobalCard {
            val overlayAllowed = Settings.canDrawOverlays(context)
            SettingSwitch("启用悬浮窗", p.floatingEnabled) { enabled ->
                if (enabled && !overlayAllowed) {
                    try {
                        context.startActivity(
                            Intent(
                                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:${context.packageName}")
                            )
                        )
                    } catch (_: Exception) {
                        context.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION))
                    }
                }
                vm.updatePrefs { it.copy(floatingEnabled = enabled) }
                try {
                    AndroidCompat.startDataSyncService(
                        context,
                        Intent(context, DataSyncService::class.java).setAction(DataSyncService.ACTION_REFRESH_OVERLAY)
                    )
                } catch (_: Exception) {}
            }
            CaptionMuted(if (overlayAllowed) "悬浮窗权限：已允许" else "首次开启需要系统悬浮窗权限")
            Spacer(Modifier.height(CaiTokens.S8))
            Text("预测来源", fontWeight = FontWeight.SemiBold)
            Row(Modifier.padding(vertical = CaiTokens.S8)) {
                listOf("consensus" to "共识", "plan" to "指定计划", "algo" to "算法").forEach { (k, lab) ->
                    FilterChip(
                        selected = p.floatingSource == k,
                        onClick = { vm.updatePrefs { it.copy(floatingSource = k) } },
                        label = { Text(lab) },
                        modifier = Modifier.padding(end = CaiTokens.S8)
                    )
                }
            }
            Spacer(Modifier.height(CaiTokens.S8))
            Text("悬浮窗显示模式", fontWeight = FontWeight.SemiBold)
            Row(Modifier.padding(vertical = CaiTokens.S8)) {
                listOf("full" to "完整", "mini" to "半隐身", "hidden" to "隐藏").forEach { (k, lab) ->
                    FilterChip(
                        selected = p.floatingMode == k,
                        onClick = { vm.updatePrefs { it.copy(floatingMode = k) } },
                        label = { Text(lab) },
                        modifier = Modifier.padding(end = CaiTokens.S8)
                    )
                }
            }
            if (p.floatingMode != "hidden") {
                Text("半隐身透明度：${(p.floatingMiniOpacity * 100).roundToInt()}%", fontWeight = FontWeight.SemiBold)
                Slider(
                    value = p.floatingMiniOpacity,
                    onValueChange = { v -> vm.updatePrefs { it.copy(floatingMiniOpacity = v) } },
                    valueRange = 0.2f..0.8f
                )
                Text("图标大小：${p.floatingMiniSize}dp", fontWeight = FontWeight.SemiBold)
                Slider(
                    value = p.floatingMiniSize.toFloat(),
                    onValueChange = { v -> vm.updatePrefs { it.copy(floatingMiniSize = v.roundToInt()) } },
                    valueRange = 32f..72f
                )
                Text("自动缩小：${if (p.floatingAutoCollapseSeconds == 0) "关闭" else "${p.floatingAutoCollapseSeconds}秒"}", fontWeight = FontWeight.SemiBold)
                Row(Modifier.padding(vertical = CaiTokens.S4)) {
                    listOf(0, 3, 5, 10).forEach { sec ->
                        FilterChip(
                            selected = p.floatingAutoCollapseSeconds == sec,
                            onClick = { vm.updatePrefs { it.copy(floatingAutoCollapseSeconds = sec) } },
                            label = { Text(if (sec == 0) "关闭" else "${sec}s") },
                            modifier = Modifier.padding(end = CaiTokens.S4)
                        )
                    }
                }
                SettingSwitch("自动吸附屏幕边缘", p.floatingEdgeSnap) { v -> vm.updatePrefs { it.copy(floatingEdgeSnap = v) } }
                CaptionMuted("半隐身模式会缩小为低透明度图标，点击即可恢复完整信息。")
            }

            if (p.floatingSource == "plan") {
                val allPlans = buildList {
                    addAll(vm.planRows.value.map { it.first })
                    addAll(NovaPlanPool.ALL)
                    addAll(vm.customPlans.value.map { it.toDefinition() })
                }.distinctBy { it.planId }
                val dxPlans = allPlans.filter { it.category == "大小" || (it.planId.startsWith("NOVA-") && it.playType == "大小") }
                val dsPlans = allPlans.filter { it.category == "单双" || (it.planId.startsWith("NOVA-") && it.playType == "单双") }
                val selectedDx = p.floatingDxPlanId.ifBlank { p.floatingPlanId }
                val selectedDs = p.floatingDsPlanId.ifBlank { p.floatingPlanId }

                Text("大小计划", fontWeight = FontWeight.SemiBold)
                Row(Modifier.padding(vertical = CaiTokens.S8)) {
                    dxPlans.forEach { plan ->
                        FilterChip(
                            selected = selectedDx == plan.planId,
                            onClick = { vm.updatePrefs { it.copy(floatingDxPlanId = plan.planId, floatingPlanId = plan.planId) } },
                            label = { Text(plan.planName) },
                            modifier = Modifier.padding(end = CaiTokens.S8)
                        )
                    }
                }
                if (dxPlans.isEmpty()) CaptionMuted("暂无大小计划，请先加载计划池")

                Text("单双计划", fontWeight = FontWeight.SemiBold)
                Row(Modifier.padding(vertical = CaiTokens.S8)) {
                    dsPlans.forEach { plan ->
                        FilterChip(
                            selected = selectedDs == plan.planId,
                            onClick = { vm.updatePrefs { it.copy(floatingDsPlanId = plan.planId) } },
                            label = { Text(plan.planName) },
                            modifier = Modifier.padding(end = CaiTokens.S8)
                        )
                    }
                }
                if (dsPlans.isEmpty()) CaptionMuted("暂无单双计划，请先加载计划池")
                CaptionMuted("大小和单双分别选择一个计划；两者都生成后才切换悬浮窗结果。")
            }
            SettingSwitch("允许拖动", p.floatingDraggable) { v -> vm.updatePrefs { it.copy(floatingDraggable = v) } }
            CaptionMuted("只读展示，不参与下注；与后台开奖同步。预测计算期间保留上一份已确认结果，完整新预测确认后一次性切换，不会把旧预测套到新期号。")
            Spacer(Modifier.height(CaiTokens.S8))
            Text("透明度：${(p.floatingOpacity * 100).roundToInt()}%", fontWeight = FontWeight.SemiBold)
            Slider(
                value = p.floatingOpacity,
                onValueChange = { v -> vm.updatePrefs { it.copy(floatingOpacity = v) } },
                valueRange = 0.55f..1f
            )
            Text("字号：${p.floatingTextSize.roundToInt()}sp", fontWeight = FontWeight.SemiBold)
            Slider(
                value = p.floatingTextSize,
                onValueChange = { v -> vm.updatePrefs { it.copy(floatingTextSize = v) } },
                valueRange = 11f..18f
            )
        }

        SectionTitle("真实自动点击")
        GlobalCard {
            val a11yOn = remember { mutableStateOf(AutoBetController.isAccessibilityEnabled(context)) }
            val serviceRunning = remember { mutableStateOf(AutoBetAccessibilityService.isRunning()) }
            // 回到设置页时刷新状态
            LaunchedEffect(Unit) {
                a11yOn.value = AutoBetController.isAccessibilityEnabled(context)
                serviceRunning.value = AutoBetAccessibilityService.isRunning()
            }

            SettingSwitch("启用真实自动点击", p.autoClickEnabled) { enabled ->
                if (enabled && !AutoBetController.isAccessibilityEnabled(context)) {
                    AutoBetController.openAccessibilitySettings(context)
                }
                vm.updatePrefs { it.copy(autoClickEnabled = enabled) }
                a11yOn.value = AutoBetController.isAccessibilityEnabled(context)
                serviceRunning.value = AutoBetAccessibilityService.isRunning()
            }
            val statusText = when {
                !p.autoClickEnabled -> "已关闭"
                a11yOn.value && serviceRunning.value -> "运行中 · 无障碍已开启"
                a11yOn.value -> "无障碍已开启 · 等待服务连接"
                else -> "请先在系统设置中开启「彩析」无障碍服务"
            }
            CaptionMuted(statusText)
            Spacer(Modifier.height(CaiTokens.S8))

            if (!a11yOn.value) {
                PrimaryButton(
                    text = "去开启无障碍服务",
                    onClick = {
                        AutoBetController.openAccessibilitySettings(context)
                    },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(CaiTokens.S8))
            }

            SettingSwitch("无障碍控制悬浮窗", p.autoClickPanelEnabled) { enabled ->
                if (enabled && !Settings.canDrawOverlays(context)) {
                    try {
                        context.startActivity(
                            Intent(
                                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:${context.packageName}")
                            )
                        )
                    } catch (_: Exception) {
                        context.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION))
                    }
                }
                vm.updatePrefs { it.copy(autoClickPanelEnabled = enabled) }
                try {
                    context.startForegroundService(
                        Intent(context, DataSyncService::class.java).setAction(DataSyncService.ACTION_REFRESH_OVERLAY)
                    )
                } catch (_: Exception) {}
            }
            CaptionMuted("开启后显示独立悬浮面板。在第三方投注页点「开始」即识别并点击当前屏幕的大小/单双。需同时开启系统无障碍与悬浮窗权限。")
            HorizontalDivider(modifier = Modifier.padding(vertical = CaiTokens.S8))
            Text("无障碍自动执行", fontWeight = FontWeight.Bold)
            CaptionMuted(
                "两项区域均支持全屏自由拖动框选（已去掉预设写死）：" +
                    "①大小单双区域 ②数字键盘区域，互不影响。" +
                    "执行顺序固定：先点大小单双 → 等待 → 再点数字。"
            )

            // ① 大小单双点击区域（自由框选）
            Text("① 大小单双点击区域（自由框选）", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = CaiTokens.S8))
            CaptionMuted(
                if (p.autoClickRegionEnabled)
                    "已设置 ✓  左${(p.autoClickRegionLeft*100).toInt()}% 上${(p.autoClickRegionTop*100).toInt()}% 右${(p.autoClickRegionRight*100).toInt()}% 下${(p.autoClickRegionBottom*100).toInt()}%"
                else "未设置 → 全屏搜索大小单双（不限制区域）"
            )
            PrimaryButton(
                text = "全屏自由框选 · 大小单双区域",
                onClick = {
                    context.startActivity(
                        Intent(context, ClickRegionPickActivity::class.java)
                            .putExtra(ClickRegionPickActivity.EXTRA_MODE, ClickRegionPickActivity.MODE_CLICK)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                },
                modifier = Modifier.fillMaxWidth()
            )
            SettingSwitch("启用大小单双区域限制", p.autoClickRegionEnabled) { v ->
                vm.updatePrefs { it.copy(autoClickRegionEnabled = v) }
            }
            CaptionMuted("关闭限制=全屏找大/小/单/双；开启后只点你框选的矩形内节点。")

            // ② 数字键盘区域（独立自由框选）
            Text("② 数字键盘区域（自由框选）", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = CaiTokens.S12))
            CaptionMuted(
                if (p.autoInputRegionEnabled)
                    "已设置 ✓  左${(p.autoInputRegionLeft*100).toInt()}% 上${(p.autoInputRegionTop*100).toInt()}% 右${(p.autoInputRegionRight*100).toInt()}% 下${(p.autoInputRegionBottom*100).toInt()}%"
                else "未设置 → 点数字时回落点击区域或全屏"
            )
            PrimaryButton(
                text = "全屏自由框选 · 数字键盘区域",
                onClick = {
                    context.startActivity(
                        Intent(context, ClickRegionPickActivity::class.java)
                            .putExtra(ClickRegionPickActivity.EXTRA_MODE, ClickRegionPickActivity.MODE_INPUT)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                },
                modifier = Modifier.fillMaxWidth()
            )
            SettingSwitch("启用数字键盘区域限制", p.autoInputRegionEnabled) { v ->
                vm.updatePrefs { it.copy(autoInputRegionEnabled = v) }
            }
            CaptionMuted(
                "与大小单双区域完全独立。流程：先点大小单双 → 再在本区域内逐位点数字。" +
                    "请框选投注页数字键(0-9/.)所在范围。"
            )

            // ③ 数字设置（复原 / 倍投）——草稿编辑，点「应用」才写入
            Text("③ 数字设置", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = CaiTokens.S12))
            SettingSwitch("启用自动点击数字", p.autoInputEnabled) { v ->
                vm.updatePrefs { it.copy(autoInputEnabled = v) }
            }
            CaptionMuted(
                "根据上一期对错选择本期金额：对/未知 → 复原数字；错且未追投 → 倍投数字；追投最多 1 期后恢复复原数字。" +
                    "金额拆成数字后在键盘区域逐位点击（不再使用无障碍文本输入）。"
            )
            val baseDraft = remember {
                mutableStateOf(
                    p.autoInputBaseAmount.let {
                        if (it == it.toLong().toDouble()) it.toLong().toString() else it.toString()
                    }
                )
            }
            val multDraft = remember {
                mutableStateOf(
                    p.autoInputMultAmount.let {
                        if (it == it.toLong().toDouble()) it.toLong().toString() else it.toString()
                    }
                )
            }
            val applyHint = remember { mutableStateOf("") }
            LaunchedEffect(p.autoInputBaseAmount, p.autoInputMultAmount) {
                val baseStr = p.autoInputBaseAmount.let {
                    if (it == it.toLong().toDouble()) it.toLong().toString() else it.toString()
                }
                val multStr = p.autoInputMultAmount.let {
                    if (it == it.toLong().toDouble()) it.toLong().toString() else it.toString()
                }
                // 仅当草稿与已保存值一致时同步，避免覆盖正在编辑的内容
                if (baseDraft.value.toDoubleOrNull() == p.autoInputBaseAmount) {
                    baseDraft.value = baseStr
                }
                if (multDraft.value.toDoubleOrNull() == p.autoInputMultAmount) {
                    multDraft.value = multStr
                }
            }
            OutlinedTextField(
                value = baseDraft.value,
                onValueChange = { s -> baseDraft.value = s.filter { c -> c.isDigit() || c == '.' } },
                label = { Text("复原数字") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().padding(top = CaiTokens.S4)
            )
            OutlinedTextField(
                value = multDraft.value,
                onValueChange = { s -> multDraft.value = s.filter { c -> c.isDigit() || c == '.' } },
                label = { Text("倍投数字") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().padding(top = CaiTokens.S4)
            )
            PrimaryButton(
                text = "应用数字设置",
                onClick = {
                    val base = baseDraft.value.toDoubleOrNull()
                    val mult = multDraft.value.toDoubleOrNull()
                    when {
                        base == null || base <= 0 -> applyHint.value = "复原数字无效，请输入大于 0 的数字"
                        mult == null || mult <= 0 -> applyHint.value = "倍投数字无效，请输入大于 0 的数字"
                        else -> {
                            vm.updatePrefs {
                                it.copy(autoInputBaseAmount = base, autoInputMultAmount = mult)
                            }
                            applyHint.value = "已应用：复原=$base  倍投=$mult"
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth().padding(top = CaiTokens.S8)
            )
            if (applyHint.value.isNotBlank()) {
                CaptionMuted(applyHint.value)
            }
            CaptionMuted(
                "当前已生效：复原=${
                    p.autoInputBaseAmount.let {
                        if (it == it.toLong().toDouble()) it.toLong().toString() else it.toString()
                    }
                }  倍投=${
                    p.autoInputMultAmount.let {
                        if (it == it.toLong().toDouble()) it.toLong().toString() else it.toString()
                    }
                }  · 追投次数：1 期（固定）"
            )

            Text("执行顺序", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = CaiTokens.S12))
            SettingSwitch("① 先点击大小单双", p.autoExecClickDxDs) { v ->
                vm.updatePrefs { it.copy(autoExecClickDxDs = v) }
            }
            SettingSwitch("② 再识别数字键盘区域", p.autoExecFindInput) { v ->
                vm.updatePrefs { it.copy(autoExecFindInput = v) }
            }
            SettingSwitch("③ 逐位点击数字", p.autoExecTypeAmount) { v ->
                vm.updatePrefs { it.copy(autoExecTypeAmount = v) }
            }
            SettingSwitch("④ 输入后校验（兼容保留）", p.autoExecVerifyInput) { v ->
                vm.updatePrefs { it.copy(autoExecVerifyInput = v) }
            }

            SettingSwitch("显示点击红点", p.autoClickShowFeedback) { v ->
                vm.updatePrefs { it.copy(autoClickShowFeedback = v) }
            }
            SettingSwitch("自动点大小", p.autoClickDx) { v ->
                vm.updatePrefs { it.copy(autoClickDx = v) }
            }
            SettingSwitch("自动点单双", p.autoClickDs) { v ->
                vm.updatePrefs { it.copy(autoClickDs = v) }
            }
            Text("投注方向", fontWeight = FontWeight.SemiBold)
            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = p.autoClickBetMode != "reverse",
                    onClick = { vm.updatePrefs { it.copy(autoClickBetMode = "forward") } },
                    label = { Text("正投") }
                )
                FilterChip(
                    selected = p.autoClickBetMode == "reverse",
                    onClick = { vm.updatePrefs { it.copy(autoClickBetMode = "reverse") } },
                    label = { Text("反投") }
                )
            }
            CaptionMuted(
                if (p.autoClickBetMode == "reverse")
                    "反投：预测取反点击（大↔小、单↔双；组合大单↔小双）"
                else
                    "正投：按预测原文点击"
            )

            Text(
                "点击间隔：${p.autoClickDelayMs}ms",
                fontWeight = FontWeight.SemiBold
            )
            Slider(
                value = p.autoClickDelayMs.toFloat(),
                onValueChange = { v ->
                    vm.updatePrefs { it.copy(autoClickDelayMs = v.toLong()) }
                },
                valueRange = 150f..1500f
            )

            CaptionMuted(
                "固定顺序：①点大小单双（自由框选区域）→ 等待 → ②再逐位点数字（独立自由框选区域）。" +
                    "两区域均可全屏任意拖动，无预设写死。开启真实自动点击后，每期 READY 执行一次（按期号去重）。" +
                    "若当时仍在本应用，会挂起最多约 45 秒，请切到投注页。"
            )
            Spacer(Modifier.height(CaiTokens.S8))
            PrimaryButton(
                text = "立即尝试一次（当前预测）",
                onClick = {
                    a11yOn.value = AutoBetController.isAccessibilityEnabled(context)
                    serviceRunning.value = AutoBetAccessibilityService.isRunning()
                    AutoBetController.tryNow(context)
                },
                modifier = Modifier.fillMaxWidth()
            )
        }

        SectionTitle("历史缓存")
        GlobalCard {
            Text("同步/工作期数（从最新往前）", fontWeight = FontWeight.SemiBold)
            CaptionMuted(
                "当前 ${p.workingHistoryLimit.coerceIn(200, 8000)} 期 · 库内可更多，仅加载最近 N 期到内存参与预测/图表。"
            )
            WeightSlider(
                label = "缓存期数",
                value = p.workingHistoryLimit.coerceIn(200, 8000).toFloat(),
                range = 200f..8000f,
                step = 100f,
                onChange = { v ->
                    val n = v.toInt().coerceIn(200, 8000)
                    vm.updatePrefs { it.copy(workingHistoryLimit = n) }
                }
            )
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf(500, 1000, 1500, 2000, 3000, 5000, 8000).forEach { n ->
                    FilterChip(
                        selected = p.workingHistoryLimit == n,
                        onClick = {
                            vm.updatePrefs { it.copy(workingHistoryLimit = n) }
                            vm.loadData()
                        },
                        label = { Text("${n}期") }
                    )
                }
            }
            PrimaryButton(
                "按当前期数重新加载历史",
                onClick = { vm.loadData() },
                modifier = Modifier.fillMaxWidth()
            )
            CaptionMuted("调整后点按钮或快捷芯片会从最新一期往前加载对应期数。")
        }

        SectionTitle("行为")
        GlobalCard {
            SettingSwitch("自动刷新", p.autoRefresh) { v -> vm.updatePrefs { it.copy(autoRefresh = v) } }
            SettingSwitch("EWMA 自适应", p.ewmaEnabled) { v -> vm.updatePrefs { it.copy(ewmaEnabled = v) } }
            SettingSwitch("预测冻结", p.predFreeze) { v -> vm.updatePrefs { it.copy(predFreeze = v) } }
        }

        SectionTitle("回测评分权重")
        GlobalCard {
            val bp = p.backtestParams
            WeightSlider(
                label = "近期命中权重",
                value = bp.recentHit.toFloat(),
                range = 0f..60f,
                step = 1f,
                onChange = { v -> vm.updatePrefs { it.copy(backtestParams = bp.copy(recentHit = v.toDouble())) } }
            )
            WeightSlider(
                label = "样本量权重",
                value = bp.sample.toFloat(),
                range = 0f..30f,
                step = 0.5f,
                onChange = { v -> vm.updatePrefs { it.copy(backtestParams = bp.copy(sample = v.toDouble())) } }
            )
            WeightSlider(
                label = "连错惩罚权重",
                value = bp.streak.toFloat(),
                range = 0f..30f,
                step = 0.5f,
                onChange = { v -> vm.updatePrefs { it.copy(backtestParams = bp.copy(streak = v.toDouble())) } }
            )
            WeightSlider(
                label = "晋级阈值",
                value = bp.promoteThreshold.toFloat(),
                range = 40f..90f,
                step = 1f,
                onChange = { v -> vm.updatePrefs { it.copy(backtestParams = bp.copy(promoteThreshold = v.toDouble())) } }
            )
            WeightSlider(
                label = "连错扣分起点",
                value = bp.streakPenaltyStart.toFloat(),
                range = 1f..10f,
                step = 1f,
                onChange = { v -> vm.updatePrefs { it.copy(backtestParams = bp.copy(streakPenaltyStart = v.toInt())) } }
            )
            Spacer(Modifier.height(CaiTokens.S8))
            PrimaryButton(
                "恢复默认权重",
                ghost = true,
                onClick = { vm.updatePrefs { it.copy(backtestParams = BacktestParams()) } },
                modifier = Modifier.fillMaxWidth()
            )
            CaptionMuted("权重仅在重新回测后生效;连错惩罚按(连错-起点+1)×权重×0.15 扣分")
        }

        Spacer(Modifier.height(CaiTokens.S16))
        PrimaryButton(
            "启动后台开奖监听",
            onClick = { AndroidCompat.startDataSyncService(context, Intent(context, DataSyncService::class.java)) },
            modifier = Modifier.fillMaxWidth()
        )

        SectionTitle("AI(可选)")
        GlobalCard {
            OutlinedTextField(
                value = p.aiApiKey,
                onValueChange = { key -> vm.updatePrefs { it.copy(aiApiKey = key) } },
                label = { Text("API Key") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            CaptionMuted("仅本机保存,留空使用本地规则")
        }

        SectionTitle("数据管理")
        DataManagementCard(vm = vm)

        Spacer(Modifier.height(CaiTokens.S24))
        CaptionMuted("彩析 · 香槟金设计令牌 · 仅供学习研究,请理性购彩")
    }
}

@Composable
private fun DataManagementCard(vm: MainViewModel) {
    val context = LocalContext.current
    val exported = vm.exportedFile.value
    val exportedList = remember { mutableStateOf<List<java.io.File>>(emptyList()) }
    fun refreshList() {
        exportedList.value = com.caifenxi.app.data.config.DataExportHelper.listExports(context)
    }

    // 分享最近一次导出的文件
    LaunchedEffect(exported) {
        val f = exported ?: return@LaunchedEffect
        try {
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", f)
            val share = Intent(Intent.ACTION_SEND).apply {
                type = if (f.name.endsWith(".csv")) "text/csv" else "application/json"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(share, "分享 ${f.name}"))
        } catch (_: Exception) {
            // FileProvider 未就绪时静默失败
        }
        vm.exportedFile.value = null
    }

    // 从文件选择器选择备份 JSON 恢复
    val restorePicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            try {
                val dir = com.caifenxi.app.data.config.DataExportHelper.exportDir(context)
                val target = java.io.File(dir, "restore-backup.json")
                context.contentResolver.openInputStream(uri)?.use { input ->
                    target.outputStream().use { output -> input.copyTo(output) }
                }
                vm.restoreFromBackup(target.name)
            } catch (e: Exception) {
                vm.statusText.value = "读取备份失败:${e.message}"
            }
        }
    }

    GlobalCard {
        Text("数据一致性", fontWeight = FontWeight.SemiBold)
        CaptionMuted("补结算漏网待开战绩/共识/挂机,并补生成下期共识")
        Spacer(Modifier.height(CaiTokens.S8))
        PrimaryButton("一致性校验并修复", onClick = { vm.runConsistencyCheck() }, modifier = Modifier.fillMaxWidth())
    }

    Spacer(Modifier.height(CaiTokens.S8))

    GlobalCard {
        Text("运行日志", fontWeight = FontWeight.SemiBold)
        CaptionMuted("失败/错误带问题编号(如 E102),便于对照排查。最新在上。")
        Spacer(Modifier.height(CaiTokens.S8))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            PrimaryButton("清空日志", onClick = { vm.clearRuntimeLog() }, ghost = true, modifier = Modifier.weight(1f))
            Spacer(Modifier.padding(CaiTokens.S8))
            PrimaryButton("立即尝试挂机", onClick = { vm.tryPlaceBotNow() }, modifier = Modifier.weight(1f))
        }
        Spacer(Modifier.height(CaiTokens.S8))
        val logScroll = rememberScrollState()
        Column(
            Modifier
                .fillMaxWidth()
                .heightIn(min = 160.dp, max = 280.dp)
                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f))
                .verticalScroll(logScroll)
                .padding(CaiTokens.S8)
        ) {
            val logs = RuntimeLog.entries
            if (logs.isEmpty()) {
                CaptionMuted("暂无日志。刷新共识、挂机下单后会出现记录。")
            } else {
                logs.forEach { e ->
                    val color = when (e.level) {
                        RuntimeLog.Level.ERROR -> Color(0xFFC62828)
                        RuntimeLog.Level.WARN -> Color(0xFFF9A825)
                        RuntimeLog.Level.INFO -> MaterialTheme.colorScheme.onSurfaceVariant
                    }
                    Text(
                        "${e.timeText} [${e.code}] ${e.message}",
                        color = color,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(vertical = 2.dp)
                    )
                }
            }
        }
    }

    Spacer(Modifier.height(CaiTokens.S8))

    GlobalCard {
        Text("CSV 导出(全部彩种)", fontWeight = FontWeight.SemiBold)
        CaptionMuted("文件保存在应用外部目录 export/,导出后自动弹出分享")
        Spacer(Modifier.height(CaiTokens.S8))
        PrimaryButton("导出开奖历史 CSV", onClick = { vm.exportDrawsCsv() }, ghost = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(CaiTokens.S4))
        PrimaryButton("导出下注历史 CSV", onClick = { vm.exportBetsCsv() }, ghost = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(CaiTokens.S4))
        PrimaryButton("导出统计记录 CSV", onClick = { vm.exportStatsCsv() }, ghost = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(CaiTokens.S4))
        PrimaryButton("导出共识记录 CSV", onClick = { vm.exportConsensusCsv() }, ghost = true, modifier = Modifier.fillMaxWidth())
    }

    Spacer(Modifier.height(CaiTokens.S8))

    GlobalCard {
        Text("全量备份 / 恢复", fontWeight = FontWeight.SemiBold)
        CaptionMuted("备份包含全部彩种的开奖、下注、统计、共识、自定义计划与设置")
        Spacer(Modifier.height(CaiTokens.S8))
        PrimaryButton("导出全量备份(JSON)", onClick = { vm.exportFullBackup() }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(CaiTokens.S8))
        PrimaryButton(
            if (vm.restoring.value) "恢复中..." else "从备份文件恢复",
            onClick = { restorePicker.launch(arrayOf("application/json", "application/octet-stream", "*/*")) },
            enabled = !vm.restoring.value,
            ghost = true,
            modifier = Modifier.fillMaxWidth()
        )
        CaptionMuted("恢复会覆盖当前数据并重建统计,完成后请回到首页刷新(建议先备份)")
        Spacer(Modifier.height(CaiTokens.S8))
        PrimaryButton("查看已导出文件", onClick = { refreshList() }, ghost = true, modifier = Modifier.fillMaxWidth())
        if (exportedList.value.isNotEmpty()) {
            Spacer(Modifier.height(CaiTokens.S8))
            exportedList.value.take(8).forEach { f ->
                CaptionMuted("• ${f.name}(${f.length() / 1024} KB)")
            }
        }
    }
}

@Composable
private fun RegionSlider(title: String, value: Float, onChange: (Float) -> Unit) {
    Text("$title：${(value * 100).toInt()}%", fontWeight = FontWeight.SemiBold)
    Slider(
        value = value,
        onValueChange = onChange,
        valueRange = 0f..1f
    )
}

@Composable
private fun SettingSwitch(title: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = CaiTokens.S4),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun WeightSlider(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    step: Float,
    onChange: (Float) -> Unit
) {
    Column(Modifier.padding(vertical = CaiTokens.S4)) {
        Row(Modifier.fillMaxWidth()) {
            Text(label, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
            Text(
                if (step >= 1f) "%.0f".format(value) else "%.1f".format(value),
                fontWeight = FontWeight.SemiBold,
                style = MaterialTheme.typography.bodyMedium
            )
        }
        Slider(
            value = value.coerceIn(range),
            onValueChange = { v -> onChange(((v - range.start) / step).roundToInt() * step + range.start) },
            valueRange = range,
            steps = ((range.endInclusive - range.start) / step).toInt().coerceAtLeast(0) - 1
        )
    }
}
