package com.caifenxi.app.domain.execution

import com.caifenxi.app.util.RuntimeLog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

/**
 * 统一执行任务管理器。
 *
 * 核心原则：
 * 1. cmdId 为第一主键（同一彩种同期的重试 = 新 cmdId + retryOf 串历史）；
 * 2. 所有状态按 cmdId 隔离，杜绝旧式全局 pending/inflight 覆盖；
 * 3. 防重复：同一 cmdId 只允许一个运行中任务；
 * 4. 只有明确 FAILED 才自动重试；TIMEOUT/UNKNOWN 一律进入状态确认而非盲目重试；
 * 5. 任务带过期时间 expireAt，超期任务不得再执行。
 */
class ExecutionTaskManager(
    private val maxRetry: Int = 3,
    private val retryDelayMs: Long = 5_000L
) {

    private val taskPool = ConcurrentHashMap<String, ExecutionTask>()      // cmdId -> task
    private val keyToCmdIds = ConcurrentHashMap<String, MutableList<String>>() // lottery|issue -> cmdIds
    private val runningJobs = ConcurrentHashMap<String, Job>()             // cmdId -> running coroutine

    private val lock = ExecutionLock()
    private val cmdSeq = AtomicInteger(0)
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    /** 执行回调：true=该轮动作执行成功且已受理；由执行器异步返回结果 */
    fun submitTask(
        task: ExecutionTask,
        executor: Executor?,
        onResult: (ExecutionResult) -> Unit = {}
    ): Boolean {
        if (task.cmdId.isBlank()) return false
        val exist = taskPool[task.cmdId]
        if (exist != null && !exist.isTerminal) {
            RuntimeLog.warn("Execution", "cmdId=${task.cmdId} 已在执行/未结束，防重复跳过")
            return false
        }
        if (exist != null && exist.status == ExecutionTask.TaskStatus.SUCCESS) {
            RuntimeLog.warn("Execution", "cmdId=${task.cmdId} 已成功，跳过")
            return false
        }
        if (task.expireAt > 0L && System.currentTimeMillis() > task.expireAt) {
            RuntimeLog.warn("Execution", "cmdId=${task.cmdId} 已过期，拒绝执行")
            return false
        }

        taskPool[task.cmdId] = task
        addToKeyIndex(task)
        RuntimeLog.info(
            "Execution",
            "提交任务 cmdId=${task.cmdId} 彩种=${task.lotteryKey} 期号=${task.issue} 次数=${task.retryCount}"
        )

        if (executor == null) {
            RuntimeLog.warn("Execution", "cmdId=${task.cmdId} 无执行器，任务进入 WAITING_EXECUTOR")
            return false
        }

        launchExecute(task, executor, onResult)
        return true
    }

    /** 生成唯一 cmdId */
    fun generateCmdId(lotteryKey: String, issue: String): String {
        val seq = cmdSeq.incrementAndGet()
        val ts = System.currentTimeMillis() % 100_000
        return "CMD-${lotteryKey.replace(":", "")}-${issue}-$ts-$seq"
    }

    /** 创建重试任务（原任务明确 FAILED 才调用） */
    fun createRetry(
        origin: ExecutionTask,
        newCmdId: String,
        executor: Executor?,
        onResult: (ExecutionResult) -> Unit = {}
    ): Boolean {
        if (origin.retryCount + 1 > maxRetry) {
            RuntimeLog.warn("Execution", "cmdId=${origin.cmdId} 重试次数超限($maxRetry)，放弃")
            updateStatus(origin.cmdId, ExecutionTask.TaskStatus.FAILED, lastError = "重试次数超限")
            return false
        }
        val retry = origin.copy(
            cmdId = newCmdId,
            status = ExecutionTask.TaskStatus.CREATED,
            retryCount = origin.retryCount + 1,
            retryOf = origin.cmdId,
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis(),
            lastError = null,
            result = null
        )
        return submitTask(retry, executor, onResult)
    }

    /** 执行器受理后立即回调一次（任务已交给执行器/网页） */
    fun markPublished(cmdId: String) {
        updateStatus(cmdId, ExecutionTask.TaskStatus.PUBLISHED)
    }

    fun markReceived(cmdId: String) {
        updateStatus(cmdId, ExecutionTask.TaskStatus.RECEIVED)
    }

    fun markExecuting(cmdId: String) {
        updateStatus(cmdId, ExecutionTask.TaskStatus.EXECUTING)
    }

    fun markVerifying(cmdId: String) {
        updateStatus(cmdId, ExecutionTask.TaskStatus.VERIFYING)
    }

    /**
     * 结果回调：
     * - SUCCESS → SUCCESS（去重后续不再执行）
     * - 明确 FAILED → 自动重试（若未超限）
     * - UNKNOWN/TIMEOUT → 进入 UNKNOWN，等待状态确认，绝不盲目重试
     */
    fun onResult(
        result: ExecutionResult,
        executor: Executor?,
        onRetry: (ExecutionResult) -> Unit = {}
    ) {
        val task = taskPool[result.cmdId] ?: return
        runningJobs.remove(result.cmdId)?.let {
            if (it.isActive) it.cancel()
        }
        when {
            result.success -> {
                updateStatus(
                    result.cmdId,
                    ExecutionTask.TaskStatus.SUCCESS,
                    result = result.message
                )
                onRetry(result)
            }
            result.errorType == ExecutionResult.TIMEOUT ||
                result.errorType == ExecutionResult.UNKNOWN_RESULT -> {
                // 结果未知：不能直接判失败/重试，等待状态确认
                updateStatus(
                    result.cmdId,
                    ExecutionTask.TaskStatus.UNKNOWN,
                    lastError = result.message
                )
                onRetry(result)
            }
            result.errorType == ExecutionResult.COMMAND_EXPIRED -> {
                updateStatus(
                    result.cmdId,
                    ExecutionTask.TaskStatus.EXPIRED,
                    lastError = result.message
                )
                onRetry(result)
            }
            result.errorType == ExecutionResult.DUPLICATE_COMMAND -> {
                // 网页已执行过，视为成功防重复
                updateStatus(
                    result.cmdId,
                    ExecutionTask.TaskStatus.SUCCESS,
                    result = "网页返回重复指令，视为已执行"
                )
                onRetry(result)
            }
            else -> {
                // 明确失败：允许自动重试
                if (task.retryCount < maxRetry) {
                    val newCmdId = generateCmdId(task.lotteryKey, task.issue)
                    updateStatus(
                        result.cmdId,
                        ExecutionTask.TaskStatus.FAILED,
                        lastError = result.message
                    )
                    scope.launch {
                        delay(retryDelayMs)
                        createRetry(task, newCmdId, executor, onRetry)
                    }
                } else {
                    updateStatus(
                        result.cmdId,
                        ExecutionTask.TaskStatus.FAILED,
                        lastError = result.message
                    )
                    onRetry(result)
                }
            }
        }
    }

    /** 超时统一入口：进入 UNKNOWN 并尝试状态确认，不直接判失败 */
    fun handleTimeout(cmdId: String, executor: Executor?) {
        val task = taskPool[cmdId] ?: return
        if (task.isTerminal) return
        updateStatus(cmdId, ExecutionTask.TaskStatus.UNKNOWN, lastError = "执行超时")
        runningJobs.remove(cmdId)?.let { if (it.isActive) it.cancel() }
        // 交给执行器确认实际状态（可能网页其实已成功）
        executor?.queryState(cmdId)?.let { result ->
            if (result.success) {
                updateStatus(cmdId, ExecutionTask.TaskStatus.SUCCESS, result = result.message)
            }
        }
    }

    fun cancel(cmdId: String) {
        val task = taskPool[cmdId] ?: return
        if (task.isTerminal) return
        updateStatus(cmdId, ExecutionTask.TaskStatus.CANCELLED, lastError = "用户取消")
        runningJobs.remove(cmdId)?.let { if (it.isActive) it.cancel() }
    }

    fun getTask(cmdId: String): ExecutionTask? = taskPool[cmdId]

    /** 查询某彩种某期所有任务（按时间升序，含历史重试） */
    fun getTasks(lotteryKey: String, issue: String): List<ExecutionTask> {
        val ids = keyToCmdIds["$lotteryKey|$issue"] ?: return emptyList()
        return ids.mapNotNull { taskPool[it] }.sortedBy { it.createdAt }
    }

    fun getLatestTask(lotteryKey: String, issue: String): ExecutionTask? =
        getTasks(lotteryKey, issue).lastOrNull()

    fun getAllTasks(): List<ExecutionTask> = taskPool.values.sortedBy { it.createdAt }

    /** 清理终态任务（保留最近 N 条已成功，供挂机页去重读取） */
    fun cleanup(keepSuccess: Int = 50) {
        val successKept = AtomicInteger(keepSuccess)
        taskPool.entries.removeIf { (_, t) ->
            if (t.status == ExecutionTask.TaskStatus.SUCCESS) {
                if (successKept.getAndDecrement() > 0) return@removeIf false
            }
            t.isTerminal
        }
        keyToCmdIds.entries.removeIf { (_, v) ->
            v.removeIf { cmd -> taskPool[cmd] == null }
            v.isEmpty()
        }
    }

    fun shutdown() {
        scope.cancel()
        runningJobs.clear()
        RuntimeLog.info("Execution", "执行任务管理器已关闭")
    }

    private fun launchExecute(
        task: ExecutionTask,
        executor: Executor,
        onResult: (ExecutionResult) -> Unit
    ) {
        val job = scope.launch {
            lock.withLock(task.lotteryKey, task.issue, task.cmdId) {
                val current = taskPool[task.cmdId] ?: return@withLock
                if (current.isTerminal) return@withLock
                if (current.expireAt > 0L && System.currentTimeMillis() > current.expireAt) {
                    updateStatus(
                        task.cmdId,
                        ExecutionTask.TaskStatus.EXPIRED,
                        lastError = "任务过期"
                    )
                    return@withLock
                }
                updateStatus(task.cmdId, ExecutionTask.TaskStatus.PUBLISHED)
                executor.execute(task.toCommand()) { result ->
                    this@ExecutionTaskManager.onResult(result, executor, onResult)
                }
            }
        }
        runningJobs[task.cmdId] = job
    }

    private fun updateStatus(
        cmdId: String,
        status: ExecutionTask.TaskStatus,
        lastError: String? = null,
        result: String? = null
    ) {
        taskPool[cmdId]?.let { t ->
            taskPool[cmdId] = t.copyState(status = status, lastError = lastError, result = result)
            RuntimeLog.info(
                "Execution",
                "任务状态更新 cmdId=$cmdId ${t.status} -> $status"
            )
        }
    }

    private fun addToKeyIndex(task: ExecutionTask) {
        keyToCmdIds.computeIfAbsent("${task.lotteryKey}|${task.issue}") {
            java.util.concurrent.CopyOnWriteArrayList()
        }.add(task.cmdId)
    }
}

/** ExecutionTask → BetCommand 便捷转换 */
fun ExecutionTask.toCommand(): BetCommand = BetCommand(
    cmdId = cmdId,
    lotteryKey = lotteryKey,
    issue = issue,
    stage = stage,
    leg = leg,
    bets = buildList {
        dx?.let { add(BetAction(BetAction.CAT_DX, it)) }
        ds?.let { add(BetAction(BetAction.CAT_DS, it)) }
        combo?.let { add(BetAction(BetAction.CAT_COMBO, it)) }
        predNumbers.forEach { add(BetAction(BetAction.CAT_NUMBER, it)) }
        textActions.forEach { add(BetAction(BetAction.CAT_TEXT, it)) }
    },
    amountText = amountText,
    source = source,
    createdAt = createdAt,
    expireAt = expireAt
)
