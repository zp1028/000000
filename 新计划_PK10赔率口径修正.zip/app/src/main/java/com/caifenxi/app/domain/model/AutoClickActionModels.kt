package com.caifenxi.app.domain.model

import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

/**
 * 大小单双、倍投数字之后的可编排点击动作。
 * 按彩种提供默认可执行玩法（组合/数字/龙虎/三军等），切换彩种时 UI 展示当前彩种玩法。
 */
@Serializable
data class AutoClickPostAction(
    val id: String,
    val type: String = TYPE_TEXT,
    val enabled: Boolean = true,
    /** TEXT / 玩法标签时要点击的文案 */
    val text: String = "",
    val regionEnabled: Boolean = false,
    val regionLeft: Float = 0f,
    val regionTop: Float = 0f,
    val regionRight: Float = 1f,
    val regionBottom: Float = 1f
) {
    companion object {
        const val TYPE_COMBO = "combo"
        const val TYPE_PRED_NUMBERS = "pred_numbers"
        const val TYPE_TEXT = "text"
        /** 当前彩种扩展玩法：用 text 作为要点击文案（龙/虎/三军点数等） */
        const val TYPE_PLAY = "play"

        fun defaultList(): List<AutoClickPostAction> = listOf(
            AutoClickPostAction(id = "combo", type = TYPE_COMBO, enabled = true, text = "组合"),
            AutoClickPostAction(id = "pred_numbers", type = TYPE_PRED_NUMBERS, enabled = true, text = "预测数字")
        )

        /**
         * 按彩种生成默认可执行动作（组合/数字优先排第一、二）。
         * 用户已有自定义 JSON 时不覆盖；仅在空配置或切换彩种引导时使用。
         */
        fun defaultsForLottery(type: LotteryType): List<AutoClickPostAction> {
            val base = listOf(
                AutoClickPostAction(id = "combo", type = TYPE_COMBO, enabled = true, text = "组合"),
                AutoClickPostAction(id = "pred_numbers", type = TYPE_PRED_NUMBERS, enabled = true, text = "预测数字")
            )
            val extra = when (type) {
                LotteryType.YDH -> listOf(
                    AutoClickPostAction(id = "ydh_long", type = TYPE_PLAY, enabled = false, text = "龙"),
                    AutoClickPostAction(id = "ydh_hu", type = TYPE_PLAY, enabled = false, text = "虎"),
                    AutoClickPostAction(id = "ydh_da", type = TYPE_PLAY, enabled = false, text = "大"),
                    AutoClickPostAction(id = "ydh_xiao", type = TYPE_PLAY, enabled = false, text = "小")
                )
                LotteryType.K3 -> listOf(
                    AutoClickPostAction(id = "k3_da", type = TYPE_PLAY, enabled = false, text = "大"),
                    AutoClickPostAction(id = "k3_xiao", type = TYPE_PLAY, enabled = false, text = "小"),
                    AutoClickPostAction(id = "k3_sanjun", type = TYPE_PLAY, enabled = false, text = "三军"),
                    AutoClickPostAction(id = "k3_yxx", type = TYPE_PLAY, enabled = false, text = "鱼虾蟹")
                )
                LotteryType.LUCK20 -> listOf(
                    AutoClickPostAction(id = "l20_pick", type = TYPE_PRED_NUMBERS, enabled = true, text = "任选号码")
                )
                LotteryType.PKS -> listOf(
                    AutoClickPostAction(id = "pks_da", type = TYPE_PLAY, enabled = false, text = "大"),
                    AutoClickPostAction(id = "pks_xiao", type = TYPE_PLAY, enabled = false, text = "小")
                )
                else -> emptyList()
            }
            // 去重 id
            return (base + extra).distinctBy { it.id }
        }

        /** 彩种可下注玩法说明（UI 展示） */
        fun playLabelsFor(type: LotteryType): List<String> = when (type) {
            LotteryType.PKS -> listOf("大小", "单双", "组合", "定位数字")
            LotteryType.LUCK20 -> listOf("大小", "单双", "组合", "任选号码(中1赔4)")
            LotteryType.YDH -> listOf("球大小", "球单双", "龙虎", "定位1-6")
            LotteryType.K3 -> listOf("和值大小", "三军", "鱼虾蟹", "长牌")
            LotteryType.PC28 -> listOf("（待设计）")
            LotteryType.OTHER -> listOf("（待设计）")
        }
    }
}

object AutoClickPostActionsCodec {
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    fun encode(list: List<AutoClickPostAction>): String =
        try {
            json.encodeToString(list)
        } catch (_: Exception) {
            "[]"
        }

    fun decode(raw: String?): List<AutoClickPostAction> {
        if (raw.isNullOrBlank()) return AutoClickPostAction.defaultList()
        return try {
            json.decodeFromString<List<AutoClickPostAction>>(raw).ifEmpty { AutoClickPostAction.defaultList() }
        } catch (_: Exception) {
            AutoClickPostAction.defaultList()
        }
    }
}
