package com.caifenxi.app.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.caifenxi.app.domain.model.AlgoMode
import com.caifenxi.app.domain.model.BetCategory
import com.caifenxi.app.domain.model.BetSourceType
import com.caifenxi.app.domain.model.BotConfig
import com.caifenxi.app.domain.model.CatBetStats
import com.caifenxi.app.domain.model.LotteryType
import com.caifenxi.app.domain.model.PksPositions
import com.caifenxi.app.domain.model.ProfitPoint
import com.caifenxi.app.ui.MainViewModel
import com.caifenxi.app.ui.components.CaptionMuted
import com.caifenxi.app.ui.components.GlobalCard
import com.caifenxi.app.ui.components.PrimaryButton
import com.caifenxi.app.ui.components.SectionTitle
import com.caifenxi.app.ui.theme.CaiTokens
import kotlin.math.roundToInt

@Composable
fun BetScreen(vm: MainViewModel) {
    val cfg = vm.botConfig.value
    val stats = vm.betStats.value
    val bets = vm.betHistory.value
    val isPks = vm.currentLottery.value.type == LotteryType.PKS
    val isConsensus = cfg.sourceType == "consensus"

    var amountText by remember(cfg.amount) { mutableStateOf(cfg.amount.toInt().toString()) }
    var initText by remember(stats.initialBalance) { mutableStateOf(stats.initialBalance.toInt().toString()) }
    var winMultText by remember(cfg.winMult) { mutableStateOf(cfg.winMult.toString()) }
    var lossMultText by remember(cfg.lossMult) { mutableStateOf(cfg.lossMult.toString()) }
    var winPeriodsText by remember(cfg.winMultPeriods) { mutableStateOf(cfg.winMultPeriods.toString()) }
    var lossPeriodsText by remember(cfg.lossMultPeriods) { mutableStateOf(cfg.lossMultPeriods.toString()) }
    var maxMultText by remember(cfg.maxMult) { mutableStateOf(cfg.maxMult.toString()) }
    var curveExpanded by remember { mutableStateOf(true) }

    LazyColumn(
        Modifier
            .fillMaxSize()
            .padding(horizontal = CaiTokens.ScreenHPadding)
            .padding(top = CaiTokens.S16),
        verticalArrangement = Arrangement.spacedBy(CaiTokens.S12)
    ) {
        item {
            Text("模拟下注", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            CaptionMuted("虚拟资金 · 每期开奖自动结算 · 仅本地模拟")
        }

        // ---- 资金与收益区 ----
        item {
            GlobalCard {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text("当前余额", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                        Text(
                            "%.0f".format(stats.balance),
                            fontWeight = FontWeight.Bold,
                            fontSize = 30.sp,
                            color = MaterialTheme.colorScheme.secondary
                        )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            if (stats.totalProfit >= 0) "+%.0f".format(stats.totalProfit)
                            else "%.0f".format(stats.totalProfit),
                            fontWeight = FontWeight.Bold,
                            color = if (stats.totalProfit >= 0) Color(0xFF2E7D32) else Color(0xFFC62828)
                        )
                        CaptionMuted("累计盈亏")
                    }
                }
                Spacer(Modifier.height(CaiTokens.S12))

                // 收益/胜率指标行
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    StatMini("总投注", "%.0f".format(stats.totalBet))
                    StatMini("中奖", "${stats.winCount}")
                    StatMini("未中", "${stats.loseCount}")
                    StatMini("胜率", if (stats.totalSettled > 0) "${(stats.winRate * 100).roundToInt()}%" else "-")
                }
                Spacer(Modifier.height(CaiTokens.S8))

                // 收益率进度条
                val rateColor = if (stats.profitRate >= 0) Color(0xFF2E7D32) else Color(0xFFC62828)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("收益率", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    Text(
                        "${(stats.profitRate * 100).roundToInt()}%",
                        fontWeight = FontWeight.Bold,
                        color = rateColor,
                        fontSize = 13.sp
                    )
                }
                LinearProgressIndicator(
                    progress = { (stats.profitRate.coerceIn(-1.0, 1.0) + 1.0).toFloat() / 2.0f },
                    modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                    color = rateColor
                )
                Spacer(Modifier.height(CaiTokens.S8))

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    StatMini("本期投入", "%.0f".format(stats.currentBetAmount))
                    StatMini("本期盈亏",
                        if (stats.currentProfit >= 0) "+${stats.currentProfit.roundToInt()}"
                        else "${stats.currentProfit.roundToInt()}")
                    StatMini("初始", "%.0f".format(stats.initialBalance))
                }
                Spacer(Modifier.height(CaiTokens.S12))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = initText,
                        onValueChange = { initText = it.filter { c -> c.isDigit() } },
                        label = { Text("初始资金") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    Spacer(Modifier.width(CaiTokens.S8))
                    PrimaryButton("设置", onClick = {
                        val v = initText.toDoubleOrNull() ?: 0.0
                        if (v > 0) vm.setInitialBalance(v)
                    }, ghost = true)
                }
            }
        }

        // ---- 收益曲线区(可折叠) ----
        item {
            GlobalCard {
                Row(
                    Modifier.fillMaxWidth().clickable { curveExpanded = !curveExpanded },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("收益曲线", fontWeight = FontWeight.Bold)
                            Spacer(Modifier.width(CaiTokens.S8))
                            if (stats.totalProfit >= 0) {
                                Text(
                                    "+${stats.totalProfit.roundToInt()}",
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF2E7D32),
                                    fontSize = 14.sp
                                )
                            } else {
                                Text(
                                    "${stats.totalProfit.roundToInt()}",
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFC62828),
                                    fontSize = 14.sp
                                )
                            }
                        }
                        CaptionMuted(
                            "最大回撤 ${stats.maxDrawdown.roundToInt()} " +
                                "(${(stats.maxDrawdownPct * 100).roundToInt()}%) · " +
                                "最长连对 ${stats.maxHitStreak} · 最长连错 ${stats.maxMissStreak}"
                        )
                    }
                    Icon(
                        if (curveExpanded) Icons.Filled.KeyboardArrowUp else Icons.Filled.KeyboardArrowDown,
                        contentDescription = if (curveExpanded) "收起" else "展开",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                AnimatedVisibility(visible = curveExpanded) {
                    Column(Modifier.padding(top = CaiTokens.S12)) {
                        if (stats.profitCurve.isEmpty()) {
                            Text("暂无结算数据,开启挂机后自动生成收益曲线。",
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        } else {
                            ProfitCurveChart(
                                points = stats.profitCurve,
                                maxDrawdown = stats.maxDrawdown
                            )
                            Spacer(Modifier.height(CaiTokens.S8))
                            CaptionMuted("绿涨红跌 · 虚线标注最大回撤区间 · 色带标注最长连对/连错")
                        }
                    }
                }
            }
        }

        // ---- 挂机设置区 ----
        item {
            SectionTitle("挂机策略")
            GlobalCard {
                // 来源选择
                Text("预测来源", fontWeight = FontWeight.SemiBold)
                Row(
                    Modifier.horizontalScroll(rememberScrollState()).padding(vertical = CaiTokens.S8),
                    horizontalArrangement = Arrangement.spacedBy(CaiTokens.S8)
                ) {
                    BetSourceType.entries.forEach { s ->
                        FilterChip(
                            selected = cfg.sourceType == s.id,
                            onClick = {
                                val defaultId = when (s) {
                                    BetSourceType.ALGO -> "experience"
                                    BetSourceType.PLAN -> vm.planRows.value.firstOrNull()?.first?.planId
                                        ?: "S-FREQ-010"
                                    BetSourceType.CONSENSUS -> "consensus"
                                }
                                vm.saveBotConfig(cfg.copy(sourceType = s.id, sourceId = defaultId))
                            },
                            label = { Text(s.label) }
                        )
                    }
                }

                // 具体来源项
                when (cfg.sourceType) {
                    "algo" -> {
                        Text("算法", fontWeight = FontWeight.SemiBold)
                        Row(
                            Modifier.horizontalScroll(rememberScrollState()).padding(vertical = CaiTokens.S8),
                            horizontalArrangement = Arrangement.spacedBy(CaiTokens.S8)
                        ) {
                            AlgoMode.entries.forEach { a ->
                                FilterChip(
                                    selected = cfg.sourceId == a.id,
                                    onClick = { vm.saveBotConfig(cfg.copy(sourceId = a.id)) },
                                    label = { Text(a.label) }
                                )
                            }
                        }
                    }
                    "plan" -> {
                        Text("计划模型", fontWeight = FontWeight.SemiBold)
                        CaptionMuted("当前: ${cfg.sourceId}")
                        Row(
                            Modifier.horizontalScroll(rememberScrollState()).padding(vertical = CaiTokens.S8),
                            horizontalArrangement = Arrangement.spacedBy(CaiTokens.S8)
                        ) {
                            vm.planRows.value.take(10).forEach { (def, _) ->
                                FilterChip(
                                    selected = cfg.sourceId == def.planId,
                                    onClick = { vm.saveBotConfig(cfg.copy(sourceId = def.planId)) },
                                    label = { Text(def.planId) }
                                )
                            }
                        }
                    }
                    "consensus" -> {
                        Text("共识预测", fontWeight = FontWeight.SemiBold)
                        CaptionMuted("按共识方向自动下注(大小/单双/组合)")
                    }
                }

                Spacer(Modifier.height(CaiTokens.S12))

                // 分类多选(共识时隐藏数字)
                Text("下注分类", fontWeight = FontWeight.SemiBold)
                Row(
                    Modifier.horizontalScroll(rememberScrollState()).padding(vertical = CaiTokens.S8),
                    horizontalArrangement = Arrangement.spacedBy(CaiTokens.S8)
                ) {
                    BetCategory.entries
                        .filter { !(isConsensus && it == BetCategory.NUMBER) }
                        .forEach { c ->
                            FilterChip(
                                selected = cfg.categories.contains(c.id),
                                onClick = {
                                    val next = if (cfg.categories.contains(c.id)) cfg.categories - c.id
                                    else cfg.categories + c.id
                                    vm.saveBotConfig(cfg.copy(categories = next))
                                },
                                label = { Text(c.label) }
                            )
                        }
                }
                if (isConsensus) {
                    CaptionMuted("共识无数字类预测,数字分类已隐藏")
                }

                // 数字位置选择(PKS + 数字分类 + 非共识 时才显示)
                if (cfg.categories.contains(BetCategory.NUMBER.id) && isPks && !isConsensus) {
                    Spacer(Modifier.height(CaiTokens.S12))
                    Text("数字位置", fontWeight = FontWeight.SemiBold)
                    Row(
                        Modifier.horizontalScroll(rememberScrollState()).padding(vertical = CaiTokens.S8),
                        horizontalArrangement = Arrangement.spacedBy(CaiTokens.S8)
                    ) {
                        (0 until 10).forEach { i ->
                            FilterChip(
                                selected = cfg.numberPosition == i,
                                onClick = { vm.saveBotConfig(cfg.copy(numberPosition = i)) },
                                label = { Text(PksPositions.nameAt(i)) }
                            )
                        }
                    }
                }

                Spacer(Modifier.height(CaiTokens.S12))

                // 单注金额
                Text("单注金额", fontWeight = FontWeight.SemiBold)
                Row(
                    Modifier.padding(vertical = CaiTokens.S8),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = amountText,
                        onValueChange = { amountText = it.filter { c -> c.isDigit() } },
                        label = { Text("每注金额") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    Spacer(Modifier.width(CaiTokens.S8))
                    PrimaryButton("保存", onClick = {
                        val v = amountText.toDoubleOrNull() ?: 0.0
                        if (v > 0) vm.saveBotConfig(cfg.copy(amount = v))
                    }, ghost = true)
                }

                Spacer(Modifier.height(CaiTokens.S8))

                // 启停开关
                Row(
                    Modifier.fillMaxWidth().padding(vertical = CaiTokens.S4),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        if (cfg.enabled) "挂机运行中" else "挂机已暂停",
                        fontWeight = FontWeight.Bold,
                        color = if (cfg.enabled) Color(0xFF2E7D32) else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.weight(1f)
                    )
                    Switch(
                        checked = cfg.enabled,
                        onCheckedChange = { vm.saveBotConfig(cfg.copy(enabled = it)) }
                    )
                }
                CaptionMuted("开启后每期开奖自动结算并按下期预测自动下注")
            }
        }

        // ---- 倍投设置区 ----
        item {
            SectionTitle("倍投设置")
            GlobalCard {
                Row(
                    Modifier.fillMaxWidth().padding(vertical = CaiTokens.S4),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("对了倍投", fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    Switch(
                        checked = cfg.winMult > 1.0,
                        onCheckedChange = { on ->
                            val mult = if (on) (winMultText.toDoubleOrNull() ?: 1.5).coerceIn(1.1, 10.0) else 1.0
                            vm.saveBotConfig(cfg.copy(winMult = mult))
                        }
                    )
                    if (cfg.winMult > 1.0) {
                        Spacer(Modifier.width(CaiTokens.S8))
                        OutlinedTextField(
                            value = winMultText,
                            onValueChange = { winMultText = it.filter { c -> c.isDigit() || c == '.' } },
                            label = { Text("系数") },
                            modifier = Modifier.width(72.dp),
                            singleLine = true
                        )
                        Spacer(Modifier.width(CaiTokens.S4))
                        CaptionMuted("倍")
                    }
                }
                Row(
                    Modifier.fillMaxWidth().padding(vertical = CaiTokens.S4),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("对了倍投期数", fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    OutlinedTextField(
                        value = winPeriodsText,
                        onValueChange = { winPeriodsText = it.filter(Char::isDigit) },
                        label = { Text("期数") },
                        modifier = Modifier.width(72.dp),
                        singleLine = true
                    )
                    Spacer(Modifier.width(CaiTokens.S4))
                    PrimaryButton("应用", onClick = {
                        val v = winPeriodsText.toIntOrNull() ?: 1
                        vm.saveBotConfig(cfg.copy(winMultPeriods = v.coerceIn(1, 20)))
                    }, ghost = true)
                }

                Row(
                    Modifier.fillMaxWidth().padding(vertical = CaiTokens.S4),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("错了倍投", fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    Switch(
                        checked = cfg.lossMult > 1.0,
                        onCheckedChange = { on ->
                            val mult = if (on) (lossMultText.toDoubleOrNull() ?: 1.5).coerceIn(1.1, 10.0) else 1.0
                            vm.saveBotConfig(cfg.copy(lossMult = mult))
                        }
                    )
                    if (cfg.lossMult > 1.0) {
                        Spacer(Modifier.width(CaiTokens.S8))
                        OutlinedTextField(
                            value = lossMultText,
                            onValueChange = { lossMultText = it.filter { c -> c.isDigit() || c == '.' } },
                            label = { Text("系数") },
                            modifier = Modifier.width(72.dp),
                            singleLine = true
                        )
                        Spacer(Modifier.width(CaiTokens.S4))
                        CaptionMuted("倍")
                    }
                }
                Row(
                    Modifier.fillMaxWidth().padding(vertical = CaiTokens.S4),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("错了倍投期数", fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    OutlinedTextField(
                        value = lossPeriodsText,
                        onValueChange = { lossPeriodsText = it.filter(Char::isDigit) },
                        label = { Text("期数") },
                        modifier = Modifier.width(72.dp),
                        singleLine = true
                    )
                    Spacer(Modifier.width(CaiTokens.S4))
                    PrimaryButton("应用", onClick = {
                        val v = lossPeriodsText.toIntOrNull() ?: 1
                        vm.saveBotConfig(cfg.copy(lossMultPeriods = v.coerceIn(1, 20)))
                    }, ghost = true)
                }

                Row(
                    Modifier.fillMaxWidth().padding(vertical = CaiTokens.S4),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("最大倍数上限", fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    OutlinedTextField(
                        value = maxMultText,
                        onValueChange = { maxMultText = it.filter { c -> c.isDigit() } },
                        label = { Text("上限") },
                        modifier = Modifier.width(72.dp),
                        singleLine = true
                    )
                    Spacer(Modifier.width(CaiTokens.S4))
                    PrimaryButton("应用", onClick = {
                        val v = maxMultText.toIntOrNull() ?: 1
                        vm.saveBotConfig(cfg.copy(maxMult = v.coerceIn(1, 20)))
                    }, ghost = true)
                }
                CaptionMuted("对/错倍投分别设置系数和持续期数;超过设定期数后恢复基础注额。")
            }
        }

        // ---- 对错统计区 ----
        item {
            SectionTitle("挂机对错统计")
            GlobalCard {
                val catStats = stats.byCategory
                if (catStats.isEmpty() || catStats.values.all { it.settled == 0 }) {
                    Text("暂无已结算数据", color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    catStats.values.filter { it.settled > 0 }.forEach { cs ->
                        CatStatsRow(cs)
                        Spacer(Modifier.height(CaiTokens.S8))
                    }
                }
            }
        }

        // ---- 记录区 ----
        item {
            SectionTitle("下注记录")
            GlobalCard {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    CaptionMuted("共 ${bets.size} 注")
                    PrimaryButton("清空记录", onClick = { vm.clearBetHistory() }, ghost = true)
                }
            }
        }

        if (bets.isEmpty()) {
            item { GlobalCard { Text("暂无下注记录,开启挂机后自动生成。") } }
        } else {
            items(bets.take(80), key = { it.id }) { b ->
                BetRow(b)
            }
        }

        item { Spacer(Modifier.height(CaiTokens.S24)) }
    }
}

@Composable
private fun StatMini(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
        CaptionMuted(label)
    }
}

@Composable
private fun CatStatsRow(cs: CatBetStats) {
    val rateColor = when {
        cs.recentStreak > 0 -> Color(0xFF2E7D32)
        cs.recentStreak < 0 -> Color(0xFFC62828)
        else -> MaterialTheme.colorScheme.onSurfaceVariant
    }
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(cs.catName, fontWeight = FontWeight.Bold)
            Text(
                if (cs.recentStreak >= 0) "连对 ${cs.recentStreak}" else "连错 ${-cs.recentStreak}",
                fontWeight = FontWeight.Bold,
                color = rateColor
            )
        }
        Spacer(Modifier.height(CaiTokens.S4))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("中 ${cs.hit} / 未中 ${cs.miss}", fontSize = 13.sp)
            Text("${cs.hitRateStr}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
        }
        LinearProgressIndicator(
            progress = { cs.winRate.toFloat().coerceIn(0f, 1f) },
            modifier = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)),
            color = MaterialTheme.colorScheme.secondary
        )
        CaptionMuted("最长连对 ${cs.maxHitStreak} · 最长连错 ${cs.maxMissStreak}")
    }
}

@Composable
private fun BetRow(b: com.caifenxi.app.domain.model.BetView) {
    val statusColor = when (b.status) {
        "中" -> Color(0xFF2E7D32)
        "未中" -> Color(0xFFC62828)
        else -> Color(0xFFF9A825)
    }
    GlobalCard {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column(Modifier.weight(1f)) {
                Text("第 ${b.issue} 期 · ${b.category}", fontWeight = FontWeight.Bold)
                Text("押「${b.betValue}」 · ${b.sourceLabel}", fontSize = 13.sp)
                CaptionMuted(
                    "本金 ${b.amount.toInt()} · 赔率 ${b.odds}" +
                        if (b.status == "待开") " · 待开" else ""
                )
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(b.status, fontWeight = FontWeight.Bold, color = statusColor)
                Text(
                    when {
                        b.status == "待开" -> "-"
                        b.profit >= 0 -> "+${b.profit.roundToInt()}"
                        else -> "${b.profit.roundToInt()}"
                    },
                    fontWeight = FontWeight.Bold,
                    color = if (b.profit >= 0) Color(0xFF2E7D32) else Color(0xFFC62828)
                )
            }
        }
    }
}

/**
 * 收益曲线图(Compose Canvas 自绘)。
 * - 折线:累计收益;绿(盈利)红(亏损),零轴虚线
 * - 回撤:虚线连接历史峰值点 → 最大回撤谷底点,标注回撤金额
 * - 连对/连错:在曲线下方用绿色/红色色带标注最长连对/连错区间
 */
@Composable
private fun ProfitCurveChart(
    points: List<ProfitPoint>,
    maxDrawdown: Double
) {
    val green = Color(0xFF2E7D32)
    val red = Color(0xFFC62828)
    val amber = Color(0xFFF9A825)
    val chartHeight = 160.dp
    val secondaryColor = MaterialTheme.colorScheme.secondary

    // 找到最长连对/连错的起始索引区间(用于色带标注)
    val (hitStart, hitEnd) = findLongestStreak(points, hit = true)
    val (missStart, missEnd) = findLongestStreak(points, hit = false)

    // 找到最大回撤:峰值点索引与谷底点索引
    val (ddPeakIdx, ddTroughIdx) = findMaxDrawdownIdx(points)

    Canvas(modifier = Modifier.fillMaxWidth().height(chartHeight)) {
        if (points.isEmpty()) return@Canvas
        val w = size.width
        val h = size.height
        val padL = 8f
        val padR = 8f
        val padT = 10f
        val padB = 14f
        val chartW = w - padL - padR
        val chartH = h - padT - padB

        val profits = points.map { it.cumulativeProfit }
        val minP = profits.minOrNull() ?: 0.0
        val maxP = profits.maxOrNull() ?: 0.0
        // 含零轴:范围覆盖 [0, max] 或 [min, 0]
        val lo = minOf(0.0, minP)
        val hi = maxOf(0.0, maxP)
        val span = (hi - lo).coerceAtLeast(1.0)
        // 顶部留 10% 余量
        val yRange = span * 1.15
        val yBase = (padT + chartH * (hi / yRange)).toFloat()  // 零轴 y 坐标

        fun xOf(i: Int): Float {
            val n = points.size
            return if (n <= 1) padL + chartW / 2f else padL + chartW * i / (n - 1)
        }

        fun yOf(v: Double): Float {
            val t = ((hi - v) / yRange).toFloat().coerceIn(0f, 1f)
            return padT + chartH * t
        }

        // 1) 连对/连错色带(曲线下方)
        if (hitStart in 0..hitEnd && hitEnd in 0 until points.size) {
            val x1 = xOf(hitStart)
            val x2 = if (hitEnd + 1 < points.size) xOf(hitEnd + 1) else xOf(points.size - 1) + 1
            drawRect(
                color = green.copy(alpha = 0.10f),
                topLeft = Offset(x1, yBase),
                size = androidx.compose.ui.geometry.Size(x2 - x1, chartH - (yBase - padT))
            )
        }
        if (missStart in 0..missEnd && missEnd in 0 until points.size) {
            val x1 = xOf(missStart)
            val x2 = if (missEnd + 1 < points.size) xOf(missEnd + 1) else xOf(points.size - 1) + 1
            drawRect(
                color = red.copy(alpha = 0.10f),
                topLeft = Offset(x1, yBase),
                size = androidx.compose.ui.geometry.Size(x2 - x1, chartH - (yBase - padT))
            )
        }

        // 2) 零轴虚线
        drawLine(
            color = Color(0xFF999999),
            start = Offset(padL, yBase),
            end = Offset(w - padR, yBase),
            strokeWidth = 1.5f,
            pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(8f, 6f))
        )

        // 3) 收益折线
        val linePath = Path()
        points.forEachIndexed { i, p ->
            val x = xOf(i)
            val y = yOf(p.cumulativeProfit)
            if (i == 0) linePath.moveTo(x, y) else linePath.lineTo(x, y)
        }
        drawPath(linePath, color = secondaryColor, style = Stroke(width = 4f, cap = StrokeCap.Round))

        // 4) 填充:零轴以下红色、以上绿色(简化为整条曲线下方到零轴的填充)
        if (points.size > 1) {
            val fillPath = Path()
            val firstX = xOf(0)
            val lastX = xOf(points.size - 1)
            fillPath.moveTo(firstX, yBase)
            points.forEachIndexed { i, p ->
                fillPath.lineTo(xOf(i), yOf(p.cumulativeProfit))
            }
            fillPath.lineTo(lastX, yBase)
            fillPath.close()
            val fillColor = if (points.last().cumulativeProfit >= 0) green.copy(alpha = 0.08f) else red.copy(alpha = 0.08f)
            drawPath(fillPath, color = fillColor)
        }

        // 5) 数据点(小圆点,中=绿 未中=红)
        points.forEachIndexed { i, p ->
            val c = if (p.hit) green else red
            drawCircle(color = c, radius = 3f, center = Offset(xOf(i), yOf(p.cumulativeProfit)))
        }

        // 6) 最大回撤标注:峰值 → 谷底虚线 + 谷底标记
        if (ddPeakIdx >= 0 && ddTroughIdx >= 0 && ddPeakIdx != ddTroughIdx && maxDrawdown > 0) {
            val px = xOf(ddPeakIdx)
            val py = yOf(points[ddPeakIdx].cumulativeProfit)
            val tx = xOf(ddTroughIdx)
            val ty = yOf(points[ddTroughIdx].cumulativeProfit)
            drawLine(
                color = amber,
                start = Offset(px, py),
                end = Offset(tx, ty),
                strokeWidth = 2f,
                pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(6f, 6f))
            )
            // 峰值空心圆
            drawCircle(color = amber, radius = 5f, center = Offset(px, py), style = Stroke(width = 2f))
            // 谷底实心圆
            drawCircle(color = amber, radius = 5f, center = Offset(tx, ty))
        }
    }
}

/** 找到最长连对/连错的起止索引区间 */
private fun findLongestStreak(points: List<ProfitPoint>, hit: Boolean): Pair<Int, Int> {
    var bestStart = -1
    var bestEnd = -1
    var bestLen = 0
    var curStart = -1
    var curLen = 0
    points.forEachIndexed { i, p ->
        if (p.hit == hit) {
            if (curStart < 0) curStart = i
            curLen++
            if (curLen > bestLen) {
                bestLen = curLen
                bestStart = curStart
                bestEnd = i
            }
        } else {
            curStart = -1
            curLen = 0
        }
    }
    return bestStart to bestEnd
}

/** 找到最大回撤对应的峰值索引与谷底索引(峰值在前,谷底在后) */
private fun findMaxDrawdownIdx(points: List<ProfitPoint>): Pair<Int, Int> {
    var peakIdx = 0
    var peakVal = points.firstOrNull()?.cumulativeProfit ?: 0.0
    var bestPeak = -1
    var bestTrough = -1
    var bestDD = 0.0
    points.forEachIndexed { i, p ->
        if (p.cumulativeProfit > peakVal) {
            peakVal = p.cumulativeProfit
            peakIdx = i
        }
        val dd = peakVal - p.cumulativeProfit
        if (dd > bestDD) {
            bestDD = dd
            bestPeak = peakIdx
            bestTrough = i
        }
    }
    return bestPeak to bestTrough
}
