package com.caifenxi.app.domain.btc

/** Single funding settlement sample from exchange history. */
data class FundingPoint(
    val symbol: String,
    val fundingTime: Long,
    val fundingRate: Double,
    val markPrice: Double? = null
)

/** Open interest snapshot (hist API period bar). */
data class OpenInterestPoint(
    val symbol: String,
    val timestamp: Long,
    val sumOpenInterest: Double,
    val sumOpenInterestValue: Double
)

data class BtcDerivativesSnapshot(
    val symbol: String,
    val markPrice: Double,
    val indexPrice: Double,
    val fundingRate: Double,
    val nextFundingTime: Long,
    val openInterest: Double,
    val openInterestValue: Double = 0.0,
    val updatedAt: Long = System.currentTimeMillis()
)

/**
 * Point-in-time derivatives features aligned to a bar.
 * Only uses history with timestamp <= barTime.
 */
data class DerivativesFeatures(
    val barTime: Long,
    val fundingRate: Double,
    val fundingZScore: Double,
    val fundingExtreme: Boolean,
    val fundingBias: Double,          // -1 short-crowd expensive → fade short bias to long
    val oi: Double,
    val oiChangePct: Double,
    val oiTrend: Double,              // -1..1
    val priceOiAlign: Double,         // price up + oi up = trend confirm
    val derivativesScore: Double,     // -1..1 composite for plan pool
    val featureVersion: String = "deriv-v1"
)
