package com.caifenxi.app.domain.btc.hs

/** Human-readable, auditable explanation generated from the same values used for the decision. */
data class HsDecisionExplanation(
    val decision: String,
    val direction: String,
    val headline: String,
    val reasons: List<String>,
    val risks: List<String>,
    val metrics: List<Pair<String, String>>
) {
    fun compact(): String = buildString {
        append(decision).append(" ").append(direction).append(" · ").append(headline)
        if (reasons.isNotEmpty()) append(" | ").append(reasons.joinToString("; "))
        if (risks.isNotEmpty()) append(" | risks: ").append(risks.joinToString("; "))
    }
}
