package com.caifenxi.app.domain.btc.runtime

import com.caifenxi.app.domain.btc.TradingSignal
import com.caifenxi.app.domain.btc.broker.BrokerOrderResult
import com.caifenxi.app.domain.btc.broker.BrokerResult
import com.caifenxi.app.domain.btc.futures.ClosePositionRequest
import com.caifenxi.app.domain.btc.futures.FuturesOrderType
import com.caifenxi.app.domain.btc.futures.LeverageResult
import com.caifenxi.app.domain.btc.futures.MarginMode
import com.caifenxi.app.domain.btc.broker.EventContractBroker
import com.caifenxi.app.domain.btc.broker.EventMarketBroker
import com.caifenxi.app.domain.btc.broker.PerpBroker

/**
 * v22.6 canonical execution gateway.
 *
 * Controllers/orchestrators may create signals and run venue-specific recovery/read
 * operations, but order writes are routed through this gateway. The gateway does not
 * perform risk authorization; TradingCore/UnifiedRisk remains the authorization layer.
 */
class UnifiedExecutionGateway(
    private val perp: PerpBroker? = null,
    private val event: EventContractBroker? = null,
    private val prediction: EventMarketBroker? = null
) {
    suspend fun placePerp(signal: TradingSignal.ContractSignal, clientOrderId: String): BrokerOrderResult {
        val broker = requireNotNull(perp) { "PERP execution adapter unavailable" }
        return broker.place(signal, clientOrderId)
    }

    suspend fun cancelPrediction(orderId: String): BrokerResult {
        val broker = requireNotNull(prediction) { "PREDICTION execution adapter unavailable" }
        return broker.cancel(orderId)
    }

    suspend fun setPerpLeverage(symbol: String, leverage: Int): LeverageResult {
        val broker = requireNotNull(perp) { "PERP execution adapter unavailable" }
        return broker.setLeverage(symbol, leverage)
    }

    suspend fun setPerpMarginMode(symbol: String, mode: MarginMode): BrokerOrderResult {
        val broker = requireNotNull(perp) { "PERP execution adapter unavailable" }
        return broker.setMarginMode(symbol, mode)
    }

    suspend fun placePerpConditional(
        symbol: String,
        side: String,
        type: FuturesOrderType,
        quantity: Double,
        stopPrice: Double?,
        trailingDelta: Double? = null,
        clientOrderId: String
    ): com.caifenxi.app.domain.btc.broker.BrokerOrderResult {
        val broker = requireNotNull(perp) { "PERP execution adapter unavailable" }
        return broker.placeConditionalOrder(
            symbol = symbol, side = side, type = type, quantity = quantity,
            stopPrice = stopPrice, trailingDelta = trailingDelta, reduceOnly = true, clientOrderId = clientOrderId
        )
    }

    suspend fun closePerpPosition(request: ClosePositionRequest): com.caifenxi.app.domain.btc.broker.BrokerOrderResult {
        val broker = requireNotNull(perp) { "PERP execution adapter unavailable" }
        return broker.closePosition(request)
    }

    suspend fun placeEvent(signal: TradingSignal.EventContractSignal): BrokerResult {
        val broker = requireNotNull(event) { "EVENT execution adapter unavailable" }
        return broker.place(signal)
    }

    suspend fun placePrediction(signal: TradingSignal.PredictionMarketSignal): BrokerResult {
        val broker = requireNotNull(prediction) { "PREDICTION execution adapter unavailable" }
        return broker.place(signal)
    }
}
