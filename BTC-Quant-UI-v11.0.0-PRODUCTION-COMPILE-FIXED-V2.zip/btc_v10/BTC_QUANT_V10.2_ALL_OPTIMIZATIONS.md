# BTC Quant v10.2 — 全量优化落地

本版本在 v10.1 基础上落地：
- Executable Edge 2.0：概率、Ask/Bid、盘口深度、费用、spread、slippage、liquidity impact、latency -> Net Edge。
- Signal lifecycle：CREATED/VALIDATING/QUALIFIED/ARMED/EXECUTING/OPEN/CLOSED/SETTLED/EXPIRED/INVALIDATED/REPLACED，并按 5m/15m/1h TTL。
- Portfolio Exposure Engine：净暴露、总暴露、方向集中度。
- Research Center：数据质量、pHat、Raw/Net Edge、Regime、Model×Timeframe、风险、Snapshot Replay 状态。
- UI：新增“研究”Tab；终端顶部真实数据模式状态保留。
- 修复 applyMarketBundle 中 Polymarket 参数引用错误，确保使用当前传入 market map。

原则：LIVE/PAPER/DEMO 数据不混用；没有真实签名能力时不伪造 Polymarket LIVE 下单成功。
