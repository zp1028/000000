package com.caifenxi.app.domain.btc.research

import org.json.JSONObject

object ResearchArtifactExporter {
    fun csv(artifact: ResearchArtifact): String = buildString {
        appendLine("type,id,value")
        artifact.factorWeights.forEach { (k,v) -> appendLine("factor,$k,$v") }
        artifact.strategyWeights.forEach { (k,v) -> appendLine("strategy,$k,$v") }
        artifact.fusionWeights.forEach { (k,v) -> appendLine("fusion,$k,$v") }
    }
    fun manifest(artifact: ResearchArtifact): String = JSONObject().apply {
        put("artifactId", artifact.artifactId); put("datasetCutoffMs", artifact.datasetCutoffMs)
        put("featureVersion", artifact.featureVersion); put("modelVersion", artifact.modelVersion); put("regime", artifact.regime)
        put("wfoSamples", artifact.wfoSamples); put("profitFactor", artifact.profitFactor); put("maxDrawdownPct", artifact.maxDrawdownPct)
        put("sharpe", artifact.sharpe); put("sortino", artifact.sortino); put("brierScore", artifact.brierScore); put("logLoss", artifact.logLoss)
        put("ic", artifact.ic); put("icir", artifact.icir); put("costModelVersion", artifact.costModelVersion); put("lineageId", artifact.lineageId)
    }.toString(2)
}
