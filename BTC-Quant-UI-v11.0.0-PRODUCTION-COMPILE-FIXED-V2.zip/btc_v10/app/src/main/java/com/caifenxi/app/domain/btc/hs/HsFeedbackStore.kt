package com.caifenxi.app.domain.btc.hs

import android.content.Context
import com.caifenxi.app.data.db.CaiDatabase
import com.caifenxi.app.data.db.entity.HsFeedbackEntity
import org.json.JSONArray
import org.json.JSONObject
import java.util.ArrayDeque

/**
 * 模型反馈存储 —— 优先 Room，无 Context 时内存；首次启动从旧 prefs 迁移一次。
 */
class HsFeedbackStore(context: Context? = null, private val maxRecords: Int = 2000) {
    data class TimeframeMetrics(val recentBrier: Double, val baselineBrier: Double, val recentHit: Double, val samples: Int)
    data class Record(val timeframe: String, val predictedUp: Double, val actualUp: Boolean, val at: Long = System.currentTimeMillis())

    private val appCtx = context?.applicationContext
    private val dao = appCtx?.let { runCatching { CaiDatabase.getInstance(it).hsFeedbackDao() }.getOrNull() }
    private val mem = ArrayDeque<Record>()
    private val prefs = appCtx?.getSharedPreferences("btc_hs_feedback_v2", Context.MODE_PRIVATE)

    init {
        migrateFromPrefsIfNeeded()
        if (dao == null) loadMemFromPrefs()
    }

    @Synchronized
    fun observe(timeframe: String, predictedUp: Double, actualUp: Boolean) {
        val p = predictedUp.coerceIn(0.0, 1.0)
        val at = System.currentTimeMillis()
        val databaseDao = dao
        if (databaseDao != null) {
            runCatching {
                databaseDao.insert(HsFeedbackEntity(timeframe = timeframe, predictedUp = p, actualUp = actualUp, at = at))
                databaseDao.trim(maxRecords)
            }
        } else {
            mem.addLast(Record(timeframe, p, actualUp, at))
            while (mem.size > maxRecords) mem.removeFirst()
            persistMem()
        }
    }

    @Synchronized
    fun metrics(timeframe: String): Pair<Double, Double> {
        val r = recentRows(timeframe, 300)
        if (r.isEmpty()) return 0.25 to 0.0
        val brier = r.map { (it.predictedUp - if (it.actualUp) 1.0 else 0.0).let { e -> e * e } }.average()
        val hit = r.count { (it.predictedUp >= 0.5) == it.actualUp }.toDouble() / r.size
        return brier to hit
    }

    @Synchronized
    fun count(timeframe: String): Int =
        dao?.count(timeframe) ?: mem.count { it.timeframe == timeframe }

    @Synchronized
    fun modelMetrics(timeframe: String): TimeframeMetrics {
        val rows = recentRows(timeframe, 300)
        if (rows.isEmpty()) return TimeframeMetrics(0.25, 0.25, 0.0, 0)
        fun brier(rs: List<Record>) = rs.map { val e = it.predictedUp - if (it.actualUp) 1.0 else 0.0; e * e }.average()
        val recent = rows.takeLast(minOf(60, rows.size))
        val hit = recent.count { (it.predictedUp >= 0.5) == it.actualUp }.toDouble() / recent.size
        return TimeframeMetrics(brier(recent), brier(rows), hit, rows.size)
    }

    private fun recentRows(tf: String, limit: Int): List<Record> {
        dao?.let { d ->
            return runCatching {
                d.recent(tf, limit).map { Record(it.timeframe, it.predictedUp, it.actualUp, it.at) }.reversed()
            }.getOrDefault(emptyList())
        }
        return mem.filter { it.timeframe == tf }.toList().takeLast(limit)
    }

    private fun migrateFromPrefsIfNeeded() {
        val p = prefs ?: return
        val d = dao ?: return
        if (p.getBoolean("migrated_to_room_v1", false)) return
        val raw = p.getString("records", null) ?: run {
            p.edit().putBoolean("migrated_to_room_v1", true).apply()
            return
        }
        runCatching {
            val a = JSONArray(raw)
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                d.insert(
                    HsFeedbackEntity(
                        timeframe = o.getString("tf"),
                        predictedUp = o.getDouble("p"),
                        actualUp = o.getBoolean("y"),
                        at = o.optLong("at", System.currentTimeMillis())
                    )
                )
            }
            d.trim(maxRecords)
            p.edit().putBoolean("migrated_to_room_v1", true).remove("records").apply()
        }
    }

    private fun loadMemFromPrefs() {
        val raw = prefs?.getString("records", null) ?: return
        runCatching {
            val a = JSONArray(raw)
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                mem.addLast(Record(o.getString("tf"), o.getDouble("p"), o.getBoolean("y"), o.optLong("at")))
            }
            while (mem.size > maxRecords) mem.removeFirst()
        }
    }

    private fun persistMem() {
        val p = prefs ?: return
        val a = JSONArray()
        mem.forEach { r ->
            a.put(JSONObject().apply {
                put("tf", r.timeframe); put("p", r.predictedUp); put("y", r.actualUp); put("at", r.at)
            })
        }
        p.edit().putString("records", a.toString()).apply()
    }
}
