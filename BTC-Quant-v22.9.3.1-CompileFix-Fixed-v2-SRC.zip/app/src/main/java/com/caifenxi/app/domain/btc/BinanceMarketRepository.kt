package com.caifenxi.app.domain.btc

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * 多源 K 线拉取。币安主站在部分地区返回 451，优先使用 data-api.binance.vision / binance.us / OKX。
 */
class BinanceMarketRepository(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .callTimeout(12, TimeUnit.SECONDS)
        .build()
) {
    private data class Endpoint(val name: String, val urlBuilder: (symbol: String, interval: String, limit: Int, endTime: Long?) -> String, val parser: String)

    private val endpoints = listOf(
        Endpoint(
            "binance-vision-spot",
            { s, i, n, e -> "https://data-api.binance.vision/api/v3/klines?symbol=${s.uppercase()}&interval=$i&limit=$n" + (e?.let { "&endTime=$it" } ?: "") },
            "binance"
        ),
        Endpoint(
            "binance-us-spot",
            { s, i, n, e -> "https://api.binance.us/api/v3/klines?symbol=${s.uppercase()}&interval=$i&limit=$n" + (e?.let { "&endTime=$it" } ?: "") },
            "binance"
        ),
        Endpoint(
            "binance-fapi",
            { s, i, n, e -> "https://fapi.binance.com/fapi/v1/klines?symbol=${s.uppercase()}&interval=$i&limit=$n" + (e?.let { "&endTime=$it" } ?: "") },
            "binance"
        ),
        Endpoint(
            "binance-spot",
            { s, i, n, e -> "https://api.binance.com/api/v3/klines?symbol=${s.uppercase()}&interval=$i&limit=$n" + (e?.let { "&endTime=$it" } ?: "") },
            "binance"
        ),
        Endpoint(
            "okx",
            { s, i, n, e ->
                val inst = s.uppercase().replace("USDT", "-USDT")
                val bar = when (i) {
                    "1m" -> "1m"; "5m" -> "5m"; "15m" -> "15m"; "1h" -> "1H"; "4h" -> "4H"; "1d" -> "1D"
                    else -> i
                }
                "https://www.okx.com/api/v5/market/candles?instId=$inst&bar=$bar&limit=$n" + (e?.let { "&after=$it" } ?: "")
            },
            "okx"
        )
    )

    suspend fun loadKlines(symbol: String, interval: String, limit: Int = 300): List<BtcCandle> = withContext(Dispatchers.IO) {
        require(symbol.matches(Regex("[A-Za-z0-9._-]{3,20}"))) { "非法交易对: $symbol" }
        require(interval.matches(Regex("[0-9]+[mhdwM]"))) { "非法周期: $interval" }
        val safeLimit = limit.coerceIn(80, 1500)
        var lastError: Exception? = null
        for (ep in endpoints) {
            try {
                val url = ep.urlBuilder(symbol, interval, safeLimit, null)
                val request = Request.Builder()
                    .url(url)
                    .header("User-Agent", "BTCQuant/11.0 (Android)")
                    .header("Accept", "application/json")
                    .get()
                    .build()
                client.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) {
                        lastError = IllegalStateException("${ep.name} HTTP ${response.code}")
                        return@use
                    }
                    val body = response.body?.string().orEmpty()
                    val candles = when (ep.parser) {
                        "okx" -> parseOkx(body)
                        else -> parseBinance(body)
                    }
                    if (candles.size >= 40) return@withContext candles
                    lastError = IllegalStateException("${ep.name} 返回 K 线不足: ${candles.size}")
                }
            } catch (e: Exception) {
                lastError = e
            }
        }
        throw lastError ?: IllegalStateException("所有行情源均不可用")
    }

    /** Load a real historical window. No synthetic/demo candles are ever mixed into this result. */
    suspend fun loadKlinesRange(
        symbol: String, interval: String, startTimeMs: Long, endTimeMs: Long = System.currentTimeMillis(),
        warmupBars: Int = 100
    ): List<BtcCandle> = withContext(Dispatchers.IO) {
        require(startTimeMs < endTimeMs) { "回测开始时间必须早于结束时间" }
        require(symbol.matches(Regex("[A-Za-z0-9._-]{3,20}"))) { "非法交易对: $symbol" }
        require(interval.matches(Regex("[0-9]+[mhdwM]"))) { "非法周期: $interval" }
        val intervalMs = interval.toMillis()
        val neededStart = (startTimeMs - warmupBars.toLong() * intervalMs).coerceAtLeast(0L)
        val target = ((endTimeMs - neededStart) / intervalMs + 2).toInt().coerceAtMost(200_000)
        val all = linkedMapOf<Long, BtcCandle>()
        val chunk = if (interval == "1m" || interval == "5m" || interval == "15m") 1000 else 1500
        var cursor = endTimeMs
        var lastError: Exception? = null
        var guard = 0
        while (guard++ < 250 && all.size < target) {
            var pageLoaded = false
            for (ep in endpoints) {
                try {
                    val url = ep.urlBuilder(symbol, interval, chunk, cursor)
                    val request = Request.Builder().url(url)
                        .header("User-Agent", "BTCQuant/22.9.1")
                        .header("Accept", "application/json").get().build()
                    client.newCall(request).execute().use { response ->
                        if (!response.isSuccessful) { lastError = IllegalStateException("${ep.name} HTTP ${response.code}"); return@use }
                        val body = response.body?.string().orEmpty()
                        val page = when (ep.parser) { "okx" -> parseOkx(body); else -> parseBinance(body) }
                        val filtered = page.filter { it.openTime >= neededStart && it.openTime <= endTimeMs }
                        if (filtered.isNotEmpty()) {
                            filtered.forEach { all[it.openTime] = it }
                            cursor = (filtered.minOf { it.openTime } - 1L).coerceAtLeast(neededStart)
                            pageLoaded = true
                        }
                    }
                    if (pageLoaded) break
                } catch (e: Exception) { lastError = e }
            }
            if (!pageLoaded || cursor <= neededStart) break
        }
        if (all.isEmpty()) throw (lastError ?: IllegalStateException("历史 K 线为空"))
        all.values.sortedBy { it.openTime }
    }

    private fun String.toMillis(): Long {
        val n = dropLast(1).toLong()
        return when (last()) {
            'm' -> n * 60_000L
            'h', 'H' -> n * 3_600_000L
            'd', 'D' -> n * 86_400_000L
            'w', 'W' -> n * 604_800_000L
            else -> error("不支持的周期: $this")
        }
    }

    private fun parseBinance(body: String): List<BtcCandle> {
        val arr = JSONArray(body)
        return buildList(arr.length()) {
            var previousTime = Long.MIN_VALUE
            for (i in 0 until arr.length()) {
                val k = arr.getJSONArray(i)
                val openTime = k.getLong(0)
                val open = k.getString(1).toDouble()
                val high = k.getString(2).toDouble()
                val low = k.getString(3).toDouble()
                val close = k.getString(4).toDouble()
                val volume = k.getString(5).toDouble()
                if (openTime <= previousTime) continue
                if (listOf(open, high, low, close, volume).any { !it.isFinite() }) continue
                if (high < low) continue
                add(BtcCandle(openTime, open, high, low, close, volume))
                previousTime = openTime
            }
        }.sortedBy { it.openTime }
    }

    /** OKX 返回新→旧，需反转 */
    private fun parseOkx(body: String): List<BtcCandle> {
        val root = JSONObject(body)
        if (root.optString("code") != "0") return emptyList()
        val arr = root.optJSONArray("data") ?: return emptyList()
        val list = ArrayList<BtcCandle>(arr.length())
        for (i in 0 until arr.length()) {
            val k = arr.getJSONArray(i)
            // [ts, o, h, l, c, vol, volCcy, volCcyQuote, confirm]
            val openTime = k.getString(0).toLong()
            val open = k.getString(1).toDouble()
            val high = k.getString(2).toDouble()
            val low = k.getString(3).toDouble()
            val close = k.getString(4).toDouble()
            val volume = k.getString(5).toDouble()
            if (listOf(open, high, low, close, volume).any { !it.isFinite() }) continue
            list.add(BtcCandle(openTime, open, high, low, close, volume))
        }
        return list.sortedBy { it.openTime }
    }
}
