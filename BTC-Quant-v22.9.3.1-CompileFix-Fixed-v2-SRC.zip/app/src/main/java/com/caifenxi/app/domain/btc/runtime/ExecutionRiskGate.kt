package com.caifenxi.app.domain.btc.runtime

import kotlin.math.abs

data class ExecutionRiskLimits(
    val maxOrderNotional: Double = 1_000.0,
    val maxDailyLoss: Double = 500.0,
    val maxDrawdownPct: Double = 10.0,
    val maxPositionQty: Double = Double.MAX_VALUE
)

data class ExecutionRiskDecision(val allowed: Boolean, val reason: String, val riskUsed: Double = 0.0)

/** Shared last-mile gate. Every mode can use it; LIVE should additionally require external authorization. */
class ExecutionRiskGate(private val limits: ExecutionRiskLimits = ExecutionRiskLimits()) {
    fun evaluate(intent: OrderIntentSpec, marketPrice: Double, account: PaperAccount, position: PaperPosition): ExecutionRiskDecision {
        if (intent.quantity <= 0.0 || marketPrice <= 0.0) return ExecutionRiskDecision(false, "数量或价格无效")
        val notional = intent.quantity * marketPrice
        if (notional > limits.maxOrderNotional) return ExecutionRiskDecision(false, "订单名义价值超过限制", notional)
        if (account.realizedPnl < -abs(limits.maxDailyLoss)) return ExecutionRiskDecision(false, "达到日亏损限制")
        if (account.drawdownPct >= limits.maxDrawdownPct) return ExecutionRiskDecision(false, "达到最大回撤限制")
        val signed = if (intent.side == OrderSide.BUY) intent.quantity else -intent.quantity
        if (abs(position.quantity + signed) > limits.maxPositionQty) return ExecutionRiskDecision(false, "持仓数量超过限制")
        return ExecutionRiskDecision(true, "风控通过", notional)
    }
}
