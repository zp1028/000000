package com.caifenxi.app.domain.btc.paper

import com.caifenxi.app.domain.btc.hs.HsRuntimeConfig

/**
 * 半凯利仓位（v2）—— 硬上限 2% 净值 + 绝对金额上限
 */
class StakeSizingEngine(
    private val config: HsRuntimeConfig = HsRuntimeConfig.Default
) {
    private val kellyFraction get() = config.kellyFraction
    private val maxFractionOfBalance get() = config.maxRiskFraction
    private val maxAmount get() = config.maxNotionalUsdt
    private val minAmount get() = config.minNotionalUsdt
    private val minEdge get() = config.minNetEdge

    data class StakeSuggestion(
        val recommended: Boolean,
        val amount: Double,
        val fractionOfBalance: Double,
        val kellyValue: Double,
        val adjustedKelly: Double,
        val expectedProfit: Double,
        val maxLoss: Double,
        val expectedValue: Double,
        val winProbability: Double,
        val odds: Double,
        val reason: String
    ) {
        companion object {
            fun notRecommended(
                reason: String,
                winProbability: Double = 0.0,
                odds: Double = 0.0,
                kelly: Double = 0.0
            ) = StakeSuggestion(
                recommended = false, amount = 0.0, fractionOfBalance = 0.0,
                kellyValue = kelly, adjustedKelly = 0.0,
                expectedProfit = 0.0, maxLoss = 0.0, expectedValue = 0.0,
                winProbability = winProbability, odds = odds, reason = reason
            )
        }
    }

    fun calculate(
        balance: Double,
        odds: Double,
        consensusProbability: Double,
        consensusStrength: Double = 1.0,
        edge: Double = 0.0,
        opportunityMultiplier: Double = 1.0
    ): StakeSuggestion {
        if (balance < minAmount) {
            return StakeSuggestion.notRecommended(
                "余额不足（需 ≥ %.0f, 可用 %.2f）".format(minAmount, balance),
                consensusProbability, odds
            )
        }
        if (odds <= 1.0) {
            return StakeSuggestion.notRecommended("赔率无效（≤ 1.0）", consensusProbability, odds)
        }
        if (opportunityMultiplier <= 0.0) {
            return StakeSuggestion.notRecommended("机会倍率为 0（NO_TRADE/数据门）", consensusProbability, odds)
        }

        val p = consensusProbability.coerceIn(0.01, 0.99)
        val q = 1.0 - p
        val b = odds - 1.0
        val kelly = (b * p - q) / b
        val ev = p * b - q

        if (kelly <= 0.0 || ev <= 0.0) {
            return StakeSuggestion.notRecommended(
                "EV≤0 或凯利≤0 · kelly=${"%.3f".format(kelly)} EV=${"%.3f".format(ev)}",
                p, odds, kelly
            )
        }
        if (edge < minEdge && edge != 0.0) {
            return StakeSuggestion.notRecommended(
                "edge=${"%.1f%%".format(edge * 100)} < ${"%.1f%%".format(minEdge * 100)}",
                p, odds, kelly
            )
        }

        val strength = consensusStrength.coerceIn(0.3, 1.0)
        val adjusted = (kelly * kellyFraction * strength * opportunityMultiplier.coerceIn(0.0, 1.5)).coerceAtLeast(0.0)
        val cappedFraction = minOf(adjusted, maxFractionOfBalance)
        var amount = balance * cappedFraction
        amount = amount.coerceIn(minAmount, maxAmount)
        amount = minOf(amount, balance)

        val expectedProfit = amount * b
        val fractionPct = if (balance > 0) amount * 100.0 / balance else 0.0

        return StakeSuggestion(
            recommended = true,
            amount = amount,
            fractionOfBalance = fractionPct,
            kellyValue = kelly,
            adjustedKelly = adjusted,
            expectedProfit = expectedProfit,
            maxLoss = amount,
            expectedValue = ev,
            winProbability = p,
            odds = odds,
            reason = "½Kelly×opp ${"%.1f%%".format(cappedFraction * 100)} → ${"%.2f".format(amount)}U @ ${"%.2f".format(odds)}x · EV=+${"%.3f".format(ev)}"
        )
    }

    fun quickSizing(
        balance: Double,
        odds: Double,
        consensusProbability: Double,
        consensusStrength: Double = 1.0,
        edge: Double = 0.0,
        opportunityMultiplier: Double = 1.0
    ): Double {
        val s = calculate(balance, odds, consensusProbability, consensusStrength, edge, opportunityMultiplier)
        return if (s.recommended) s.amount else 0.0
    }

    fun kellyValue(odds: Double, winProbability: Double): Double {
        if (odds <= 1.0 || winProbability <= 0.0 || winProbability >= 1.0) return 0.0
        val b = odds - 1.0
        val p = winProbability
        return (b * p - (1.0 - p)) / b
    }

    fun expectedValue(odds: Double, winProbability: Double): Double {
        if (odds <= 1.0) return 0.0
        val b = odds - 1.0
        return winProbability * b - (1.0 - winProbability)
    }

    fun previewTable(
        balance: Double,
        odds: Double,
        confidences: List<Pair<Double, Double>>
    ): List<StakeSuggestion> = confidences.map { (p, s) ->
        calculate(balance, odds, p, s)
    }
}
