package com.caifenxi.app.data.config

import android.content.Context

/** Keeps the pre-Room JSON payloads available for a later typed migration. */
object LegacyJsonBackup {
    private const val BACKUP_PREFS = "caifenxi_legacy_backup"
    private const val DONE = "backup_done_v1"

    private val sources = listOf(
        "caifenxi_prefs" to listOf("user_prefs_json"),
        "caifenxi_stats" to listOf("stat_records_json"),
        "caifenxi_consensus" to listOf("consensus_records"),
        "caifenxi_manual" to listOf("manual_marks")
    )

    fun backupOnce(context: Context) {
        val backup = context.getSharedPreferences(BACKUP_PREFS, Context.MODE_PRIVATE)
        if (backup.getBoolean(DONE, false)) return

        val editor = backup.edit()
        sources.forEach { (name, keys) ->
            val source = context.getSharedPreferences(name, Context.MODE_PRIVATE)
            keys.forEach { key ->
                source.getString(key, null)?.let {
                    editor.putString("$name:$key", it)
                }
            }
        }
        // Mark completion only after all available payloads have been staged.
        editor.putBoolean(DONE, true).commit()
    }
}
