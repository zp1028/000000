package com.caifenxi.app.domain.btc.coord

import com.caifenxi.app.domain.btc.paper.BinaryOptionEngine

/** 纸交易账户协调器 —— 余额 / 挂单名义 / 日盈亏 / 回撤 */
class PaperAccountCoordinator(
    private val engine: BinaryOptionEngine
) {
    data class Snapshot(
        val balance: Double,
        val available: Double,
        val openNotional: Double,
        val todayPnl: Double,
        val pnl30d: Double,
        val maxDrawdownPct: Double
    )

    fun snapshot(): Snapshot {
        val acc = engine.account()
        val daily = engine.dailyStats()
        val stats = engine.statsSummary()
        val openNotional = acc.pendingBets.sumOf { it.amount }
        return Snapshot(
            balance = acc.balance,
            available = (acc.balance - openNotional).coerceAtLeast(0.0),
            openNotional = openNotional,
            todayPnl = daily.netProfit,
            pnl30d = stats.netProfit,
            maxDrawdownPct = -kotlin.math.abs(acc.maxDrawdownPct)
        )
    }
}
