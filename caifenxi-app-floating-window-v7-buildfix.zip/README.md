# 悬浮窗 v7 编译修复版

基于 v6，仅修复 Kotlin 字符串模板中的编译错误：
- `第$target期` 会被 Kotlin 解析成变量 `target期`，导致 `Unresolved reference 'target期'`。
- 已改为 `第${target}期`。

未改变悬浮窗业务逻辑。

GitHub Actions 使用现有 Build APK 工作流即可。
