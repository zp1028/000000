package com.caifenxi.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.caifenxi.app.domain.model.AlgoMode
import com.caifenxi.app.ui.MainViewModel
import com.caifenxi.app.ui.components.CaptionMuted
import com.caifenxi.app.ui.components.GlobalCard
import com.caifenxi.app.ui.components.PrimaryButton
import com.caifenxi.app.ui.theme.CaiTokens
import kotlin.math.roundToInt

private enum class StatsTab { OVERVIEW, PREDS, DRAWS, PLANS }

@Composable
fun HistoryScreen(vm: MainViewModel) {
    val summary = vm.statsSummary.value
    val records = vm.statRecords.value
    val draws = vm.history.value.asReversed()
    val planRows = vm.planRows.value
    var tab by remember { mutableStateOf(StatsTab.OVERVIEW) }
    var predCategoryFilter by remember { mutableStateOf("全部") }
    var drawPage by remember { mutableStateOf(0) }
    var pagedDraws by remember { mutableStateOf<List<com.caifenxi.app.domain.model.DrawRecord>>(emptyList()) }
    var predPage by remember { mutableStateOf(0) }
    var predResultFilter by remember { mutableStateOf("全部") }
    var pagedPreds by remember { mutableStateOf<List<com.caifenxi.app.domain.model.StatRecord>>(emptyList()) }

    LaunchedEffect(tab, vm.currentLottery.value.key) {
        if (tab == StatsTab.PREDS) {
            predPage = 0
            pagedPreds = emptyList()
            vm.loadPredictionPage(0, 100, predCategoryFilter, predResultFilter) { rows -> pagedPreds = rows }
        }
        if (tab == StatsTab.DRAWS) {
            drawPage = 0
            pagedDraws = emptyList()
            vm.loadHistoryPage(0, 100) { rows -> pagedDraws = rows }
        }
    }

    LazyColumn(
        Modifier
            .fillMaxSize()
            .padding(horizontal = CaiTokens.ScreenHPadding)
            .padding(top = CaiTokens.S16, bottom = CaiTokens.ScreenBottom),
        verticalArrangement = Arrangement.spacedBy(CaiTokens.S8)
    ) {
        item {
            Text("战绩", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            CaptionMuted(vm.currentLottery.value.name)
            Row(
                Modifier.horizontalScroll(rememberScrollState()).padding(vertical = CaiTokens.S8),
                horizontalArrangement = Arrangement.spacedBy(CaiTokens.S8)
            ) {
                listOf(
                    StatsTab.OVERVIEW to "总览",
                    StatsTab.PREDS to "预测记录",
                    StatsTab.PLANS to "计划战绩",
                    StatsTab.DRAWS to "开奖历史"
                ).forEach { (t, lab) ->
                    FilterChip(selected = tab == t, onClick = { tab = t }, label = { Text(lab) })
                }
            }
        }

        when (tab) {
            StatsTab.OVERVIEW -> {
                item {
                    GlobalCard {
                        Text("预测战绩总览（全部分类合计）", fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(CaiTokens.S12))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                            BigStat("已结算", "${summary.hit + summary.miss}")
                            BigStat("对", "${summary.hit}", Color(0xFF2E7D32))
                            BigStat("错", "${summary.miss}", Color(0xFFC62828))
                            BigStat(
                                "命中率",
                                if (summary.hit + summary.miss == 0) "-" else "${(summary.hitRate * 100).roundToInt()}%",
                                MaterialTheme.colorScheme.secondary
                            )
                        }
                        Spacer(Modifier.height(CaiTokens.S8))
                        val streakText = when {
                            summary.recentStreak > 0 -> "当前连对 ${summary.recentStreak}"
                            summary.recentStreak < 0 -> "当前连错 ${-summary.recentStreak}"
                            else -> "暂无连续"
                        }
                        CaptionMuted("$streakText · 待开 ${summary.pending}")
                    }
                }
                item {
                    GlobalCard {
                        Text("连对连错 · 两期/三期对错率", fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(CaiTokens.S12))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                            BigStat("最长连对", "${summary.maxHitStreak}", Color(0xFF2E7D32))
                            BigStat("最长连错", "${summary.maxMissStreak}", Color(0xFFC62828))
                            BigStat(
                                "当前连续",
                                when {
                                    summary.recentStreak > 0 -> "连对${summary.recentStreak}"
                                    summary.recentStreak < 0 -> "连错${-summary.recentStreak}"
                                    else -> "-"
                                },
                                if (summary.recentStreak >= 0) Color(0xFF2E7D32) else Color(0xFFC62828)
                            )
                        }
                        Spacer(Modifier.height(CaiTokens.S12))
                        WindowRateBar(
                            title = "两期对错率",
                            hitLabel = "两期内至少对 1 次（两期对）",
                            missLabel = "两期全错（两期错）",
                            hitRate = summary.twoHitRate,
                            missRate = summary.twoMissRate,
                            windows = summary.twoWindows
                        )
                        Spacer(Modifier.height(CaiTokens.S8))
                        WindowRateBar(
                            title = "三期对错率",
                            hitLabel = "三期内至少对 1 次（三期对）",
                            missLabel = "三期全错（三期错）",
                            hitRate = summary.threeHitRate,
                            missRate = summary.threeMissRate,
                            windows = summary.threeWindows
                        )
                        Spacer(Modifier.height(CaiTokens.S4))
                        CaptionMuted("口径：以连续两期为一个窗口，窗口内对一次及以上记「两期对」，两期全错记「两期错」；三期同理。窗口按期号顺序滚动统计。本卡片为全部分类合计，各分类独立明细见下方「分类命中」。")
                    }
                }
                if (summary.byCategory.isNotEmpty()) {
                    item {
                        GlobalCard {
                            Text("分类命中（按分类独立统计连对连错与两期/三期对错率）", fontWeight = FontWeight.Bold)
                            summary.byCategory.forEach { (cat, st) ->
                                CategoryStatBlock(cat, st)
                            }
                        }
                    }
                }
                if (summary.byAlgo.isNotEmpty()) {
                    item {
                        GlobalCard {
                            Text("算法命中（按算法独立统计连对连错与两期/三期对错率）", fontWeight = FontWeight.Bold)
                            summary.byAlgo.forEach { (algo, st) ->
                                CategoryStatBlock(AlgoMode.fromId(algo).label, st)
                            }
                        }
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(CaiTokens.S8)) {
                        PrimaryButton("回填结算", onClick = { vm.backfillStats() }, ghost = true)
                        PrimaryButton("清空战绩", onClick = { vm.clearStats() }, ghost = true)
                        PrimaryButton("刷新", onClick = { vm.loadData() })
                    }
                }
            }
            StatsTab.PREDS -> {
                val categories = listOf("全部", "大小", "单双", "组合", "位置")
                item {
                    Text("预测记录", fontWeight = FontWeight.Bold)
                    CaptionMuted("已加载 ${pagedPreds.size} / ${vm.predictionTotalCount.value} 条 · 分页加载 · 预测冻结后只允许补充开奖结果")
                    Row(
                        Modifier.horizontalScroll(rememberScrollState()).padding(vertical = CaiTokens.S8),
                        horizontalArrangement = Arrangement.spacedBy(CaiTokens.S8)
                    ) {
                        categories.forEach { cat ->
                            FilterChip(
                                selected = predCategoryFilter == cat,
                                onClick = {
                                    predCategoryFilter = cat
                                    predPage = 0
                                    pagedPreds = emptyList()
                                    vm.loadPredictionPage(0, 100, cat, predResultFilter) { rows -> pagedPreds = rows }
                                },
                                label = { Text(cat) }
                            )
                        }
                    }
                    Row(
                        Modifier.horizontalScroll(rememberScrollState()).padding(bottom = CaiTokens.S8),
                        horizontalArrangement = Arrangement.spacedBy(CaiTokens.S8)
                    ) {
                        listOf("全部", "待开", "对", "错").forEach { result ->
                            FilterChip(
                                selected = predResultFilter == result,
                                onClick = {
                                    predResultFilter = result
                                    predPage = 0
                                    pagedPreds = emptyList()
                                    vm.loadPredictionPage(0, 100, predCategoryFilter, result) { rows -> pagedPreds = rows }
                                },
                                label = { Text(result) }
                            )
                        }
                    }
                }
                if (pagedPreds.isEmpty()) {
                    item { GlobalCard { Text(if (vm.predictionPageLoading.value) "正在加载预测历史..." else "暂无预测记录") } }
                } else {
                    items(pagedPreds, key = { it.id }) { r ->
                        val color = when (r.result) {
                            "对" -> Color(0xFF2E7D32)
                            "错" -> Color(0xFFC62828)
                            else -> Color(0xFFF9A825)
                        }
                        GlobalCard {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    Modifier
                                        .background(color, RoundedCornerShape(CaiTokens.RadiusIcon))
                                        .padding(horizontal = CaiTokens.S12, vertical = CaiTokens.S4)
                                ) {
                                    Text(r.result, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                }
                                Spacer(Modifier.width(CaiTokens.S12))
                                Column(Modifier.weight(1f)) {
                                    Text("第 ${r.issue} 期 · ${r.category}", fontWeight = FontWeight.SemiBold)
                                    Text(
                                        buildString {
                                            if (r.candidates.size > 1) append("候选「${r.candidates.joinToString(" / ")}」")
                                            else append("预测「${r.lean}」")
                                            r.actual?.let { append(" → 开奖「$it」") } ?: append(" · 待开奖")
                                        },
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                    CaptionMuted(
                                        "${AlgoMode.fromId(r.algoId).label} · " +
                                            (if (r.matchMode == "any_of") "命中任一即对 · " else "精确匹配 · ") +
                                            "支持度 ${"%.0f".format(r.score * 100)}%"
                                    )
                                }
                            }
                        }
                    }
                    if (pagedPreds.size < vm.predictionTotalCount.value) {
                        item {
                            PrimaryButton(
                                if (vm.predictionPageLoading.value) "加载中..." else "加载更多",
                                onClick = {
                                    if (!vm.predictionPageLoading.value) {
                                        predPage += 1
                                        vm.loadPredictionPage(predPage, 100, predCategoryFilter, predResultFilter) { rows -> pagedPreds = pagedPreds + rows }
                                    }
                                },
                                ghost = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
            }
            StatsTab.PLANS -> {
                item {
                    Text("计划战绩", fontWeight = FontWeight.Bold)
                    CaptionMuted("各计划成功率（点计划页可看详情）")
                }
                if (planRows.isEmpty()) {
                    item { GlobalCard { Text("暂无计划数据，请先加载并生成计划。") } }
                } else {
                    items(planRows, key = { it.first.planId }) { (def, rt) ->
                        GlobalCard {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Column(Modifier.weight(1f)) {
                                    Text(def.planName, fontWeight = FontWeight.Bold)
                                    CaptionMuted("${def.category} · ${def.algorithm}")
                                }
                                Text(
                                    rt.hitRatePercent,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.secondary
                                )
                            }
                            Text("对 ${rt.hitCount} / ${rt.sampleCount} · 评分 ${"%.0f".format(rt.score)} · ${rt.status}")
                            if (rt.sampleCount > 0) {
                                androidx.compose.material3.LinearProgressIndicator(
                                    progress = { rt.hitRate.toFloat() },
                                    modifier = Modifier.fillMaxWidth().padding(top = CaiTokens.S4),
                                    color = MaterialTheme.colorScheme.secondary
                                )
                            }
                        }
                    }
                }
            }
            StatsTab.DRAWS -> {
                item {
                    Text("开奖历史", fontWeight = FontWeight.Bold)
                    CaptionMuted("已加载 ${pagedDraws.size} / ${vm.historyTotalCount.value} 条 · 分页加载，历史超过500期也可继续查看")
                }
                if (pagedDraws.isEmpty()) {
                    item { GlobalCard { Text(if (vm.historyPageLoading.value) "正在加载历史..." else "暂无开奖历史") } }
                } else items(pagedDraws, key = { it.issue }) { row ->
                    GlobalCard {
                        Text("第 ${row.issue} 期 · ${row.drawTime.take(19)}", fontWeight = FontWeight.SemiBold)
                        Text(row.numbers.joinToString(" "), style = MaterialTheme.typography.bodyMedium)
                        val tags = listOfNotNull(row.dx, row.ds, row.combo)
                        if (tags.isNotEmpty()) CaptionMuted(tags.joinToString(" · "))
                    }
                }
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                        val hasMore = pagedDraws.size < vm.historyTotalCount.value
                        if (hasMore) {
                            PrimaryButton(
                                if (vm.historyPageLoading.value) "加载中..." else "加载更多（+100）",
                                onClick = {
                                    if (!vm.historyPageLoading.value) {
                                        val next = drawPage + 1
                                        vm.loadHistoryPage(next, 100) { rows ->
                                            if (rows.isNotEmpty()) {
                                                pagedDraws = pagedDraws + rows
                                                drawPage = next
                                            }
                                        }
                                    }
                                }
                            )
                        } else if (pagedDraws.isNotEmpty()) {
                            CaptionMuted("已加载全部 ${pagedDraws.size} 条历史记录")
                        }
                    }
                }
            }
        }
        item { Spacer(Modifier.height(CaiTokens.S24)) }
    }
}

@Composable
private fun CategoryStatBlock(label: String, st: com.caifenxi.app.domain.model.CategoryStats) {
    Column(Modifier.padding(vertical = 6.dp)) {
        val rate = if (st.hit + st.miss == 0) 0 else (st.hit * 100.0 / (st.hit + st.miss)).roundToInt()
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, fontWeight = FontWeight.SemiBold)
            Text("对${st.hit} 错${st.miss} · $rate%")
        }
        androidx.compose.material3.LinearProgressIndicator(
            progress = { (rate / 100f).coerceIn(0f, 1f) },
            modifier = Modifier.fillMaxWidth(),
            color = MaterialTheme.colorScheme.secondary
        )
        val cur = when {
            st.recentStreak > 0 -> "当前连对 ${st.recentStreak}"
            st.recentStreak < 0 -> "当前连错 ${-st.recentStreak}"
            else -> "当前无连续"
        }
        CaptionMuted("$cur · 最长连对 ${st.maxHitStreak} · 最长连错 ${st.maxMissStreak}")
        if (st.twoWindows > 0) {
            CaptionMuted(
                "两期对 ${(st.twoHitRate * 100).roundToInt()}% · 两期错 ${(st.twoMissRate * 100).roundToInt()}%（${st.twoWindows} 窗口）"
            )
        }
        if (st.threeWindows > 0) {
            CaptionMuted(
                "三期对 ${(st.threeHitRate * 100).roundToInt()}% · 三期错 ${(st.threeMissRate * 100).roundToInt()}%（${st.threeWindows} 窗口）"
            )
        }
    }
}

@Composable
private fun WindowRateBar(
    title: String,
    hitLabel: String,
    missLabel: String,
    hitRate: Double,
    missRate: Double,
    windows: Int
) {
    Column(Modifier.padding(vertical = 4.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text("样本窗口 $windows 个")
        }
        Spacer(Modifier.height(CaiTokens.S4))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(hitLabel, color = Color(0xFF2E7D32), fontSize = 13.sp)
            Text(
                if (windows > 0) "${(hitRate * 100).roundToInt()}%" else "-",
                fontWeight = FontWeight.Bold,
                color = Color(0xFF2E7D32),
                fontSize = 13.sp
            )
        }
        androidx.compose.material3.LinearProgressIndicator(
            progress = { hitRate.toFloat().coerceIn(0f, 1f) },
            modifier = Modifier.fillMaxWidth(),
            color = Color(0xFF2E7D32)
        )
        Spacer(Modifier.height(CaiTokens.S4))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(missLabel, color = Color(0xFFC62828), fontSize = 13.sp)
            Text(
                if (windows > 0) "${(missRate * 100).roundToInt()}%" else "-",
                fontWeight = FontWeight.Bold,
                color = Color(0xFFC62828),
                fontSize = 13.sp
            )
        }
        androidx.compose.material3.LinearProgressIndicator(
            progress = { missRate.toFloat().coerceIn(0f, 1f) },
            modifier = Modifier.fillMaxWidth(),
            color = Color(0xFFC62828)
        )
    }
}

@Composable
private fun BigStat(label: String, value: String, color: Color = Color.Unspecified) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            value,
            fontWeight = FontWeight.Bold,
            fontSize = 20.sp,
            color = if (color == Color.Unspecified) MaterialTheme.colorScheme.onSurface else color
        )
        CaptionMuted(label)
    }
}
