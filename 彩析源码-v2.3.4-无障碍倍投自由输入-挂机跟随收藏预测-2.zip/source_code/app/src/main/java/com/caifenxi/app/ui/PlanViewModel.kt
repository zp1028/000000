package com.caifenxi.app.ui

import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.caifenxi.app.CaiFenXiApplication
import com.caifenxi.app.domain.engine.AnalysisEngine
import com.caifenxi.app.domain.engine.ConsensusEngine
import com.caifenxi.app.domain.engine.DataAnomalyDetector
import com.caifenxi.app.domain.plan.ConsensusVersionLock
import com.caifenxi.app.domain.engine.PredictEngine
import com.caifenxi.app.domain.model.ConsensusRecord
import com.caifenxi.app.domain.model.ConsensusStats
import com.caifenxi.app.domain.model.CustomPlan
import com.caifenxi.app.domain.model.DrawRecord
import com.caifenxi.app.domain.model.LabRow
import com.caifenxi.app.domain.model.ModelConsensus
import com.caifenxi.app.domain.model.PlanDefinition
import com.caifenxi.app.domain.model.PlanPredictionRecord
import com.caifenxi.app.domain.model.PlanRuntime
import com.caifenxi.app.domain.model.PlanTrendPoint
import com.caifenxi.app.domain.model.UserPrefs
import com.caifenxi.app.domain.plan.NovaPlanPool
import com.caifenxi.app.domain.plan.LotteryPlanPools
import com.caifenxi.app.domain.model.LotteryConfig
import com.caifenxi.app.domain.plan.NovaPlanAnalytics
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * 计划大厅 ViewModel。
 * 从 MainViewModel 拆出:负责计划池/回测/共识/自定义计划与实验室排行。
 * 与 MainViewModel 共享 Application 级 planEngine(同一份战绩状态)。
 */
class PlanViewModel : ViewModel() {

    private val app get() = CaiFenXiApplication.instance
    private val engine get() = app.planEngine
    private val consensusStore get() = app.consensusStore

    val planRows = mutableStateOf<List<Pair<PlanDefinition, PlanRuntime>>>(emptyList())
    val backtestRunning = mutableStateOf(false)
    val labRows = mutableStateOf<List<LabRow>>(emptyList())
    val planHistory = mutableStateOf<List<PlanPredictionRecord>>(emptyList())
    /** 当前目标期的未结算预测(按目标期全量过滤,不受 historyPreds 截断影响) */
    val currentPredictions = mutableStateOf<List<PlanPredictionRecord>>(emptyList())
    val selectedPlanHistory = mutableStateOf<List<PlanPredictionRecord>>(emptyList())
    val consensus = mutableStateOf<List<ModelConsensus>>(emptyList())
    /** 新计划页独立共识（不与计划引擎 consensus 混用） */
    val novaConsensus = mutableStateOf<List<ModelConsensus>>(emptyList())
    /** 新计划页独立运行态/当期预测，禁止写回 planRows 以免计划引擎页串池 */
    val novaPlanRows = mutableStateOf<List<Pair<PlanDefinition, PlanRuntime>>>(emptyList())
    val novaCurrentPredictions = mutableStateOf<List<PlanPredictionRecord>>(emptyList())
    val novaPlanHistory = mutableStateOf<List<PlanPredictionRecord>>(emptyList())
    /** 计划/共识统一目标期(与首页下期、挂机下注目标一致) */
    val planTargetIssue = mutableStateOf("-")
    val consensusRecords = mutableStateOf<List<ConsensusRecord>>(emptyList())
    val consensusStats = mutableStateOf(ConsensusStats())
    /** 新计划页独立共识战绩/记录（与计划引擎 consensusRecords 分离） */
    val novaConsensusRecords = mutableStateOf<List<ConsensusRecord>>(emptyList())
    val novaConsensusStats = mutableStateOf(ConsensusStats())
    val customPlans = mutableStateOf<List<CustomPlan>>(emptyList())
    /** 公式生成器产出的当前彩种计划实例（内存，切彩种清空） */
    val generatedNovaPlans = mutableStateOf<List<com.caifenxi.app.domain.model.PlanDefinition>>(emptyList())
    val generateSalt = mutableStateOf(0)
    val lastGeneratedScores = mutableStateOf<Map<String, Double>>(emptyMap())
    val planTrends = mutableStateOf<Map<String, List<PlanTrendPoint>>>(emptyMap())

    // Nova 排行榜状态放在 ViewModel，离开页面/切换分页不会丢失筛选、页码和最近计算结果。
    val novaLeaderboard = mutableStateOf<List<Pair<PlanDefinition, NovaPlanAnalytics.BacktestReport>>>(emptyList())
    val novaLeaderboardCategory = mutableStateOf("全部")
    val novaLeaderboardStage = mutableStateOf(0) // 0全部 1首期 2两期窗口 3三期窗口
    val novaLeaderboardPeriods = mutableStateOf(500)
    val novaLeaderboardPage = mutableStateOf(0)
    val novaLeaderboardLoading = mutableStateOf(false)
    /** 计划库轻量胜率缓存：planId -> (hitRate, periods)，打开计划库即可显示 */
    val novaLibraryRates = mutableStateOf<Map<String, Pair<Double, Int>>>(emptyMap())
    val novaLibraryRatesLoading = mutableStateOf(false)
    /** 图表回测状态：独立于排行榜/计划战绩，不写回计划引擎运行态。 */
    val novaChartReports = mutableStateOf<List<NovaPlanAnalytics.ChartReport>>(emptyList())
    val novaChartRunning = mutableStateOf(false)
    val novaChartStage = mutableStateOf(1)
    // 图表页 UI 状态：放在 VM 中，切换底部 Tab 再回来仍保留（不随页面 remember 重建丢失）
    val chartSource = mutableStateOf("新计划池")
    val chartMode = mutableStateOf("累计收益")
    val chartPeriods = mutableStateOf(500)
    val chartStakeText = mutableStateOf("10")
    val chartSelectedIds = mutableStateOf<List<String>>(emptyList())
    val chartPlayFilter = mutableStateOf("全部")
    val chartAutoRefresh = mutableStateOf(true)
    /** 新期到来时 +1，图表页监听后自动重跑回测 */
    val chartRefreshToken = mutableStateOf(0)
    val chartPlansExpanded = mutableStateOf(true)
    /** 图表回测下注方向：false正投 true反投 */
    val chartBetInvert = mutableStateOf(false)
    /** 图表回测投注模式：普通 / 过关斩将（固定过三关） */
    val chartGuanguan = mutableStateOf(false)
    /** 过关斩将目标关数：1~10关 */
    val chartGuanguanTarget = mutableStateOf(3)
    @Volatile private var lastLibraryRatePeriods: Int = -1
    val novaConsensusLimit = mutableStateOf(50) // 默认50；上限已放开至500，可覆盖全部 Nova 计划
    val novaAnomalyReport = mutableStateOf(DataAnomalyDetector.Report(emptyList()))
    val lockedConsensusVersion = mutableStateOf<String?>(null)

    // ── 计划工作台 UI/回测状态：放在 VM，切 Tab 再回来不丢失；新期可自动滚动更新 ──
    val workbenchRuntimeCache = mutableStateOf<Map<String, PlanRuntime>>(emptyMap())
    val workbenchJumpCache = mutableStateOf<Map<String, Pair<Int, Int>>>(emptyMap())
    val workbenchJumpMaxCache = mutableStateOf<Map<String, Pair<Int, Int>>>(emptyMap())
    val workbenchReport = mutableStateOf<NovaPlanAnalytics.ChartReport?>(null)
    val workbenchSelectedId = mutableStateOf<String?>(null)
    val workbenchPeriods = mutableStateOf(500)
    val workbenchPeriodMode = mutableStateOf("最近")
    val workbenchAllPeriods = mutableStateOf(false)
    val workbenchBacktestStage = mutableStateOf(1)
    val workbenchResultLimit = mutableStateOf(50)
    val workbenchHitLian = mutableStateOf(0)
    val workbenchMissLian = mutableStateOf(0)
    val workbenchHitJump = mutableStateOf(0)
    val workbenchMissJump = mutableStateOf(0)
    val workbenchCycleFilter = mutableStateOf(0)
    val workbenchCategory = mutableStateOf("全部")
    val workbenchPositionFilter = mutableStateOf("全部")
    val workbenchPlanSearch = mutableStateOf("")
    val workbenchPlanTier = mutableStateOf("全部")
    val workbenchSourceName = mutableStateOf("ALL")
    val workbenchLevelName = mutableStateOf("HALL")
    val workbenchTabName = mutableStateOf("DETAIL")
    val workbenchLeaderboardTab = mutableStateOf("HIT_STREAK")
    val workbenchAutoRefresh = mutableStateOf(true)
    val workbenchRefreshToken = mutableStateOf(0)
    val workbenchLastIssueKey = mutableStateOf("")
    val workbenchStatusHint = mutableStateOf("")
    val workbenchBatchProgress = mutableStateOf("")
    val workbenchBatchRunning = mutableStateOf(false)
    val workbenchDetailMode = mutableStateOf(false)
    val workbenchHistoryPage = mutableStateOf(40)
    private var workbenchBatchJob: Job? = null

    /** 异步增量回测任务:新任务开始前取消旧任务,避免回测堆积占用 CPU */
    private var backtestJob: Job? = null
    private var chartJob: Job? = null
    private var leaderboardJob: Job? = null

    /** 手动回测:清零战绩后全量滚动验证,并生成本期计划与共识 */
    fun runBacktest(
        rows: List<DrawRecord>,
        prefs: UserPrefs,
        lotteryKey: String,
        onStatus: (String) -> Unit,
        onError: (String?) -> Unit,
        requestedPeriods: Int? = 500
    ) {
        viewModelScope.launch {
            if (rows.size < 40) {
                onError("历史不足,至少约 40 期再回测")
                return@launch
            }
            // 手动回测接管:取消正在跑的异步回测,避免状态互相覆盖
            backtestJob?.cancel()
            backtestRunning.value = true
            onStatus("回测中...")
            try {
                withContext(Dispatchers.Default) {
                    // 手动「重新滚动验证」:先清零旧战绩,再全量回测一次,
                    // 保证各计划样本数与历史预测不重复累加
                    engine.clearCareer()
                    engine.backtest(rows, prefs, minWarm = 30, forceFull = true, requestedPeriods = requestedPeriods, cancellationCheck = { !isActive })
                }
                val latest = rows.maxByOrNull { it.issue.toLongOrNull() ?: Long.MIN_VALUE } ?: rows.last()
                val cutoff = latest.issue
                val target = latest.nextIssue?.takeIf {
                    it.isNotBlank() && it != cutoff &&
                        (it.toLongOrNull() ?: 0L) > (cutoff.toLongOrNull() ?: 0L)
                } ?: PredictEngine.suggestNextIssue(cutoff)
                // 固定计划池预测 + 共识(combo 条数与设置同步)
                val preds = withContext(Dispatchers.Default) {
                    engine.activatePlansForIssue(target, prefs, force = true)
                    engine.predictForNext(rows, prefs, target, cutoff)
                }
                planRows.value = engine.getRuntimes().filter {
                    !it.first.planId.startsWith("NOVA-") && !it.first.planId.startsWith("NOVA-CUSTOM-")
                }.ifEmpty {
                    // 保底：展示原 PlanPool，避免竞技排行空白
                    com.caifenxi.app.domain.plan.PlanPool.ALL.map { def ->
                        def to com.caifenxi.app.domain.model.PlanRuntime(planId = def.planId)
                    }
                }
                planHistory.value = engine.getAllRecentPredictions(5000).filter {
                    !it.planId.startsWith("NOVA-") && !it.planId.startsWith("NOVA-CUSTOM-")
                }
                currentPredictions.value = engine.getCurrentPredictions(target).filter {
                    !it.planId.startsWith("NOVA-") && !it.planId.startsWith("NOVA-CUSTOM-")
                }
                planTargetIssue.value = target
                consensus.value = engine.consensus(
                    lotteryKey, target, preds.filter {
                        !it.planId.startsWith("NOVA-") && !it.planId.startsWith("NOVA-CUSTOM-")
                    }, comboTopN = prefs.comboPredCount.coerceIn(1, 4)
                )
                ConsensusEngine.recordPending(consensusStore, lotteryKey, target, consensus.value, poolSource = "LEGACY")
                refreshConsensusStats(lotteryKey)
                labRows.value = withContext(Dispatchers.Default) {
                    AnalysisEngine.labTable(rows, prefs)
                }
                onStatus("计划池 ${planRows.value.size} 条 · 回测完成")
            } catch (e: CancellationException) {
                onError("回测已取消")
            } catch (e: Exception) {
                onError(e.message)
            } finally {
                backtestRunning.value = false
            }
        }
    }

    /**
     * 由 MainViewModel 数据管线在预测完成后调用:同步计划/共识状态。
     * 主链路只做「轻量预测 + 共识」(不阻塞),增量回测放到后台异步执行,
     * 完成后自动刷新计划战绩与共识 —— 修复原实现回测卡死主链路导致
     * 共识丢失、计划页卡死、挂机无法下注的问题。
     * @return (共识列表, 计划运行态, 最近预测)
     */
    suspend fun syncAfterPredict(
        rows: List<DrawRecord>,
        prefs: UserPrefs,
        target: String,
        cutoff: String,
        lotteryKey: String
    ): Triple<List<ModelConsensus>, List<Pair<PlanDefinition, PlanRuntime>>, List<PlanPredictionRecord>> {
        val result = withContext(Dispatchers.Default) {
            engine.activatePlansForIssue(target, prefs, force = true)
            val preds = engine.predictForNext(rows, prefs, target, cutoff)
            val cons = engine.consensus(
                lotteryKey, target, preds, comboTopN = prefs.comboPredCount.coerceIn(1, 4)
            )
            val runtimes = engine.getRuntimes()
            val recent = engine.getAllRecentPredictions(5000)
            Triple(cons, runtimes, recent)
        }
        val (cons, runtimes, recent) = result
        planTargetIssue.value = target
        // 计划引擎态只保留非 Nova，避免与新计划页串池
        val legacyRuntimes = runtimes.filter {
            !it.first.planId.startsWith("NOVA-") && !it.first.planId.startsWith("NOVA-CUSTOM-")
        }
        val legacyRecent = recent.filter {
            !it.planId.startsWith("NOVA-") && !it.planId.startsWith("NOVA-CUSTOM-")
        }
        val legacyCons = cons.filter { c ->
            val ids = c.participatingPlanIds.split(",").map { it.trim() }.filter { it.isNotEmpty() }
            ids.isEmpty() || ids.none { it.startsWith("NOVA-") || it.startsWith("NOVA-CUSTOM-") }
        }.ifEmpty { cons }
        consensus.value = legacyCons
        ConsensusEngine.recordPending(consensusStore, lotteryKey, target, legacyCons, poolSource = "LEGACY")
        planRows.value = legacyRuntimes
        planHistory.value = legacyRecent
        planTrends.value = engine.getAllTrends(60).filterKeys {
            !it.startsWith("NOVA-") && !it.startsWith("NOVA-CUSTOM-")
        }
        currentPredictions.value = engine.getCurrentPredictions(target).filter {
            !it.planId.startsWith("NOVA-") && !it.planId.startsWith("NOVA-CUSTOM-")
        }
        refreshConsensusStats(lotteryKey)
        // 实时链路绝不依赖回测：开奖、结算、历史记录、下一轮预测必须先独立完成。
        // 历史回测仅用于战绩/排行榜统计，由用户主动触发，不得阻塞或覆盖实时预测。
        return result
    }

    /**
     * Nova 页面专用同步：强制使用 NovaPlanPool，不读取原计划池作为预测来源。
     * 共识只在 Nova 预测集合上计算，且仅回写 Nova 页面内存态，避免覆盖原计划页共识。
     */
    suspend fun syncNovaAfterPredict(
        rows: List<DrawRecord>,
        prefs: UserPrefs,
        target: String,
        cutoff: String,
        lotteryKey: String
    ) {
        if (rows.isEmpty()) return
        val type = LotteryConfig.findByKey(lotteryKey)?.type
        val pool = if (type != null) LotteryPlanPools.novaPlansFor(type) else emptyList()
        // 新计划页生成器是独立池：系统 Nova + 本批生成 + 已落库自定义，禁止回退到 PlanPool/Lab。
        val generatedOk = generatedNovaPlans.value.filter { def ->
            type != null && LotteryPlanPools.belongsTo(def, type)
        }
        // 自定义计划仅允许挂到当前彩种前缀，禁止跨彩种 ID 混入
        val customOk = customPlans.value.map { it.toDefinition() }.filter { def ->
            type != null && LotteryPlanPools.belongsTo(def, type)
        }
        val novaIds = (pool + generatedOk + customOk)
            .map { it.planId }
            .distinct()
        if (novaIds.isEmpty()) return
        val novaPrefs = prefs.copy(
            selectedPlanIds = novaIds,
            cockpitPlanId = ""
        )
        withContext(Dispatchers.Default) {
            engine.activatePlansForIssue(target, novaPrefs, force = true)
            engine.predictForNext(rows, novaPrefs, target, cutoff)
        }
        val novaPreds = withContext(Dispatchers.Default) { engine.getNovaCurrentPredictions(target) }
        // 共识版本：若挂机已锁定则沿用锁定版本，否则签发新版本号写入快照
        val lock = ConsensusVersionLock.activeConstraint()
        val version = lock?.version ?: ConsensusVersionLock.mintVersion()
        lockedConsensusVersion.value = lock?.version
        // 共识参与上限：锁定中使用锁定值，否则用 UI 配置；最高 500
        val consensusLimit = (lock?.consensusLimit ?: novaConsensusLimit.value).coerceIn(1, 500)
        // 优先参与大小/单双/组合，保证能产出共识记录
        val consensusPreds = withContext(Dispatchers.Default) {
            val directionCats = setOf("大小", "单双", "组合")
            val ranked = novaPreds
                .filter { it.category in directionCats }
                .ifEmpty { novaPreds }
                .sortedWith(
                    compareByDescending<PlanPredictionRecord> { engine.getRuntime(it.planId).score }
                        .thenByDescending { engine.getRuntime(it.planId).weight }
                        .thenByDescending { engine.getRuntime(it.planId).hitRate }
                )
            val limited = if (lock != null && lock.participatingPlanIds.isNotEmpty()) {
                val allowed = lock.participatingPlanIds.toSet()
                ranked.filter { it.planId in allowed }.ifEmpty { ranked.take(consensusLimit) }
            } else {
                ranked.take(consensusLimit)
            }
            limited.map { it.copy(consensusVersion = version) }
        }
        val novaCons = withContext(Dispatchers.Default) {
            engine.consensus(
                lotteryKey, target, consensusPreds,
                comboTopN = prefs.comboPredCount.coerceIn(1, 4)
            ).map { it.copy(consensusVersion = version) }
        }
        planTargetIssue.value = target
        // 只写 Nova 独立态，绝不覆盖计划引擎 planRows / currentPredictions / consensus
        novaCurrentPredictions.value = novaPreds
        novaPlanHistory.value = engine.getNovaRecentPredictions(5000)
        novaPlanRows.value = engine.getNovaRuntimes()
        novaConsensus.value = novaCons
        if (novaCons.isNotEmpty()) {
            ConsensusEngine.recordPending(consensusStore, lotteryKey, target, novaCons, poolSource = "NOVA")
        }
        refreshNovaConsensusStats(lotteryKey)
        // 恢复原计划池 activePlans，防止计划引擎页随后读到 Nova 池
        withContext(Dispatchers.Default) {
            try {
                engine.activatePlansForIssue(target, prefs, force = true)
            } catch (e: Exception) {
                com.caifenxi.app.util.RuntimeLog.warn("PlanEngine", "恢复原计划池失败: ${e.message}")
            }
        }
        val settled = novaPlanHistory.value.filter { it.settled }
        val rts = novaPlanRows.value.map { it.second }
        novaAnomalyReport.value = DataAnomalyDetector.scan(settled, rts, stuckWindow = 20)
    }

    /** 挂机启动：锁定当前共识策略版本与参与集合 */
    fun lockConsensusForHang(lotteryKey: String) {
        val cons = consensus.value
        val planIds = cons.flatMap { it.participatingPlanIds.split(",").map { s -> s.trim() } }
            .filter { it.isNotEmpty() }
            .distinct()
            .ifEmpty {
                currentPredictions.value
                    .sortedByDescending { engine.getRuntime(it.planId).score }
                    .take(novaConsensusLimit.value.coerceIn(1, 500))
                    .map { it.planId }
            }
        val session = ConsensusVersionLock.lockForHang(
            lotteryKey = lotteryKey,
            consensusLimit = novaConsensusLimit.value.coerceIn(1, 500),
            participatingPlanIds = planIds,
            note = "hang-start"
        )
        lockedConsensusVersion.value = session.version
    }

    /** 挂机停止：解锁，允许下次使用新策略 */
    fun unlockConsensusAfterHang() {
        ConsensusVersionLock.unlock()
        lockedConsensusVersion.value = null
    }

    /**
     * 从持久化待开共识恢复内存态(供挂机在 UI 未刷新时仍能取到方向)。
     */
    suspend fun loadPendingConsensusAsModels(lotteryKey: String, targetIssue: String): List<ModelConsensus> {
        val pending = consensusStore.loadAll(lotteryKey)
            .filter { it.targetIssue == targetIssue && it.result == "待开" }
        return pending.map { r ->
            ModelConsensus(
                lotteryKey = r.lotteryKey,
                targetIssue = r.targetIssue,
                category = r.category,
                leadingDirection = r.leadingDirection.ifBlank {
                    r.candidates.joinToString("/")
                },
                supportRatio = r.supportRatio,
                disagreement = 0.0,
                participatingPlans = r.participatingPlans,
                detail = emptyMap()
            )
        }
    }

    /** 后台增量回测:每期检查协程取消;完成后重算本期计划/共识与战绩 */
    private fun startIncrementalBacktest(
        rows: List<DrawRecord>,
        prefs: UserPrefs,
        target: String,
        cutoff: String,
        lotteryKey: String
    ) {
        backtestJob?.cancel()
        backtestJob = viewModelScope.launch {
            try {
                withContext(Dispatchers.Default) {
                    // 增量回测限时 8s:避免单次持锁过久阻塞心跳的在线预测/共识,
                    // 超时已保存进度(backtest 内部推进 lastBacktestIssue),剩余期数下次续跑
                    if (rows.size >= 40) engine.backtest(rows, prefs, minWarm = 30, timeLimitMs = 8_000) { !isActive }
                }
                val (cons, runtimes, recent) = withContext(Dispatchers.Default) {
                    val preds = engine.predictForNext(rows, prefs, target, cutoff)
                    Triple(
                        engine.consensus(
                            lotteryKey, target, preds,
                            comboTopN = prefs.comboPredCount.coerceIn(1, 4)
                        ),
                        engine.getRuntimes(),
                        engine.getAllRecentPredictions(5000)
                    )
                }
                // 增量回测后仍只回写计划引擎态，过滤 Nova，避免串池
                val legacyRuntimes = runtimes.filter {
                    !it.first.planId.startsWith("NOVA-") && !it.first.planId.startsWith("NOVA-CUSTOM-")
                }
                val legacyRecent = recent.filter {
                    !it.planId.startsWith("NOVA-") && !it.planId.startsWith("NOVA-CUSTOM-")
                }
                val legacyCons = cons.filter { c ->
                    val ids = c.participatingPlanIds.split(",").map { it.trim() }.filter { it.isNotEmpty() }
                    ids.isEmpty() || ids.none { it.startsWith("NOVA-") || it.startsWith("NOVA-CUSTOM-") }
                }.ifEmpty { cons }
                consensus.value = legacyCons
                ConsensusEngine.recordPending(consensusStore, lotteryKey, target, legacyCons, poolSource = "LEGACY")
                planRows.value = legacyRuntimes
                planHistory.value = legacyRecent
                planTrends.value = engine.getAllTrends(60).filterKeys {
                    !it.startsWith("NOVA-") && !it.startsWith("NOVA-CUSTOM-")
                }
                currentPredictions.value = engine.getCurrentPredictions(target).filter {
                    !it.planId.startsWith("NOVA-") && !it.planId.startsWith("NOVA-CUSTOM-")
                }
                refreshConsensusStats(lotteryKey)
            } catch (e: CancellationException) {
                // 被新任务接管或 ViewModel 销毁:静默
            } catch (e: Exception) {
                // 后台回测失败不影响主链路
            }
        }
    }

    /** 新开奖结算后刷新内存态(由 MainViewModel 调用) */
    fun refreshRuntimeState() {
        planRows.value = engine.getRuntimes().filter {
            !it.first.planId.startsWith("NOVA-") && !it.first.planId.startsWith("NOVA-CUSTOM-")
        }
        planHistory.value = engine.getAllRecentPredictions(5000).filter {
            !it.planId.startsWith("NOVA-") && !it.planId.startsWith("NOVA-CUSTOM-")
        }
        planTrends.value = engine.getAllTrends(60).filterKeys {
            !it.startsWith("NOVA-") && !it.startsWith("NOVA-CUSTOM-")
        }
    }

    suspend fun refreshConsensusStats(lotteryKey: String) {
        // 仅计划引擎池
        val list = consensusStore.loadBySource(lotteryKey, "LEGACY").sortedByDescending { it.createdAt }
        consensusRecords.value = list
        consensusStats.value = consensusStore.statsBySource(lotteryKey, "LEGACY")
    }

    /** 仅刷新新计划页独立共识战绩/记录（按参与计划 ID 过滤 Nova） */
    suspend fun refreshNovaConsensusStats(lotteryKey: String) {
        // 仅新计划池（物理字段 poolSource=NOVA；兼容旧数据用 planId 前缀）
        val list = consensusStore.loadBySource(lotteryKey, "NOVA").sortedByDescending { it.createdAt }
        val fallback = if (list.isNotEmpty()) list else {
            consensusStore.loadAll(lotteryKey).filter { r ->
                r.poolSource == "NOVA" || r.participatingPlanIds.split(",")
                    .map { it.trim() }
                    .any { it.startsWith("NOVA-") || it.startsWith("NOVA-CUSTOM-") }
            }.sortedByDescending { it.createdAt }
        }
        novaConsensusRecords.value = fallback
        novaConsensusStats.value = com.caifenxi.app.data.config.ConsensusStore.computeStats(fallback)
    }

    fun clearConsensusStats(lotteryKey: String) {
        viewModelScope.launch {
            try {
                consensusStore.clear(lotteryKey)
                refreshConsensusStats(lotteryKey)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // 清空/统计失败不影响主流程
            }
        }
    }

    /**
     * 只读 UI 缓存，避免 Compose 滑动布局时抢 PlanEngine 全局锁。
     * Nova 计划优先查 novaPlanRows。
     */
    fun runtimeForPlan(planId: String): PlanRuntime {
        if (planId.startsWith("NOVA-") || planId.startsWith("NOVA-CUSTOM-")) {
            novaPlanRows.value.firstOrNull { it.first.planId == planId }?.second?.let { return it }
        }
        planRows.value.firstOrNull { it.first.planId == planId }?.second?.let { return it }
        return PlanRuntime(planId)
    }

    fun loadPlanDetail(planId: String) {
        // 后台线程读取(回测持锁期间避免阻塞主线程)
        viewModelScope.launch(Dispatchers.Default) {
            try {
                selectedPlanHistory.value = engine.getPredictionHistory(planId, 40)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // 读取失败保持原状态
            }
        }
    }


    /**
     * 计划库打开时补算短窗口回测（默认 200 期），不阻塞 UI，结果写入 novaLibraryRates。
     * 与排行榜独立，避免「未点排行榜就全是待回测」。
     */
    fun ensureNovaLibraryRates(rows: List<DrawRecord>, periods: Int = 200) {
        if (rows.size < 6) return
        if (novaLibraryRatesLoading.value) return
        val win = periods.coerceIn(50, 2000)
        // 库容量随彩种变化，不再用 PK10 池大小作门槛
        if (lastLibraryRatePeriods == win && novaLibraryRates.value.isNotEmpty()) return
        novaLibraryRatesLoading.value = true
        viewModelScope.launch(Dispatchers.Default) {
            try {
                val map = LinkedHashMap<String, Pair<Double, Int>>()
                val type = rows.firstOrNull()?.lotteryKey?.let { LotteryConfig.findByKey(it)?.type }
                val plans = (
                    if (type != null) {
                        LotteryPlanPools.novaPlansFor(type) +
                            generatedNovaPlans.value.filter { LotteryPlanPools.belongsTo(it, type) } +
                            customPlans.value.map { it.toDefinition() }
                            .filter { LotteryPlanPools.belongsTo(it, type) }
                    } else emptyList()
                )
                for (plan in plans) {
                    val report = NovaPlanAnalytics.backtest(plan.copy(cyclePeriods = 1), rows, win)
                    map[plan.planId] = report.hitRate to report.periods
                }
                lastLibraryRatePeriods = win
                novaLibraryRates.value = map
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                com.caifenxi.app.util.RuntimeLog.warn("NovaLibrary", "轻量回测失败: ${e.message}")
            } finally {
                novaLibraryRatesLoading.value = false
            }
        }
    }

    /** 图表页回测：支持单计划或多计划对比，结果仅供图表/分析展示。 */
    /** 切彩种时清空图表/排行/工作台回测，避免上一彩种曲线与计划残留 */
    fun clearLotteryScopedUi() {
        novaChartReports.value = emptyList()
        chartSelectedIds.value = emptyList()
        novaLeaderboard.value = emptyList()
        novaLibraryRates.value = emptyMap()
        lastLibraryRatePeriods = -1
        generatedNovaPlans.value = emptyList()
        generateSalt.value = 0
        lastGeneratedScores.value = emptyMap()
        chartRefreshToken.value = 0
        workbenchRuntimeCache.value = emptyMap()
        workbenchJumpCache.value = emptyMap()
        workbenchJumpMaxCache.value = emptyMap()
        workbenchReport.value = null
        workbenchSelectedId.value = null
        workbenchLastIssueKey.value = ""
        workbenchRefreshToken.value = 0
        workbenchBatchProgress.value = ""
        workbenchStatusHint.value = ""
        workbenchBatchJob?.cancel()
        workbenchBatchRunning.value = false
        workbenchDetailMode.value = false
    }

    fun notifyWorkbenchNewIssue(latestIssue: String) {
        if (latestIssue.isBlank()) return
        if (latestIssue == workbenchLastIssueKey.value) return
        workbenchLastIssueKey.value = latestIssue
        workbenchRefreshToken.value = workbenchRefreshToken.value + 1
    }

    fun cancelWorkbenchBatch() {
        workbenchBatchJob?.cancel()
        workbenchBatchJob = null
        workbenchBatchRunning.value = false
    }

    fun setWorkbenchBatchJob(job: Job?) {
        workbenchBatchJob?.cancel()
        workbenchBatchJob = job
    }

    /**
     * 生成计划公式 → 短窗样本外回测过滤 → 内存列表 + 落库为自定义计划。
     * @return 通过过滤的计划数
     */
    fun generateNovaPlans(
        type: com.caifenxi.app.domain.model.LotteryType,
        seedIssue: String,
        count: Int = 24,
        refresh: Boolean = true,
        history: List<com.caifenxi.app.domain.model.DrawRecord> = emptyList(),
        lotteryKey: String = "",
        prefs: com.caifenxi.app.domain.model.UserPrefs = com.caifenxi.app.domain.model.UserPrefs(),
        onStatus: (String) -> Unit = {}
    ) {
        if (refresh) generateSalt.value = generateSalt.value + 1
        val salt = generateSalt.value
        val raw = com.caifenxi.app.domain.plan.PlanFormulaGenerator.generate(
            type = type,
            count = count,
            seedIssue = seedIssue,
            salt = salt
        )
        viewModelScope.launch(Dispatchers.Default) {
            val minRate = prefs.genPlanMinHitRate.coerceIn(0.35, 0.70)
            val btPeriods = prefs.genPlanBacktestPeriods.coerceIn(30, 300)
            val scored = ArrayList<Pair<com.caifenxi.app.domain.model.PlanDefinition, Double>>()
            for (p in raw) {
                if (history.size < 20) {
                    scored += p to 0.5
                    continue
                }
                val rep = try {
                    NovaPlanAnalytics.backtest(p, history, btPeriods)
                } catch (_: Exception) {
                    null
                }
                val rate = rep?.hitRate ?: 0.0
                if (rate + 1e-9 >= minRate || history.size < 40) {
                    scored += p to rate
                }
            }
            scored.sortByDescending { it.second }
            val kept = scored.map { (plan, rate) ->
                plan.copy(planName = "${plan.planName} · 样本外${"%.0f".format(rate * 100)}%")
            }
            generatedNovaPlans.value = kept
            lastGeneratedScores.value = scored.associate { it.first.planId to it.second }
            // 落库：NovaGen|play|pos|algo|seed
            if (lotteryKey.isNotBlank()) {
                try {
                    val now = System.currentTimeMillis()
                    // 清理本彩种旧 GEN 计划，避免无限膨胀
                    val existing = try {
                        app.database.customPlanDao().getByLottery(lotteryKey)
                    } catch (_: Exception) {
                        emptyList()
                    }
                    existing.filter { it.category.startsWith("NovaGen|") }.forEach {
                        try { app.database.customPlanDao().deleteById(it.planId) } catch (_: Exception) {}
                    }
                    kept.take(40).forEach { plan ->
                        val cp = com.caifenxi.app.domain.model.CustomPlan(
                            planId = plan.planId,
                            lotteryKey = lotteryKey,
                            planName = plan.planName,
                            category = "NovaGen|${plan.playType}|${plan.positionIndex}|${type.name}|$seedIssue",
                            algorithm = plan.algorithm,
                            window = plan.window,
                            cyclePeriods = plan.cyclePeriods,
                            outputFormat = plan.outputFormat.name,
                            hitCriteria = plan.hitCriteria.name,
                            enabled = true,
                            participateConsensus = plan.participateConsensus,
                            createdAt = now,
                            updatedAt = now
                        )
                        try {
                            app.database.customPlanDao().upsert(
                                com.caifenxi.app.data.db.entity.CustomPlanEntity.fromDomain(cp)
                            )
                        } catch (_: Exception) {}
                    }
                    loadCustomPlans(lotteryKey)
                } catch (_: Exception) {}
            }
            onStatus("生成 ${raw.size} 条，通过样本外门槛 ${kept.size} 条（≥${"%.0f".format(minRate * 100)}% / ${btPeriods}期）")
        }
    }

    /** 本批生成计划的样本外命中率 */
    
    /** 一键将本批 TopN 样本外计划设为驾驶舱候选（返回 planId 列表） */
    fun topGeneratedPlanIds(n: Int = 3): List<String> =
        generatedNovaPlans.value
            .sortedByDescending { lastGeneratedScores.value[it.planId] ?: 0.0 }
            .take(n.coerceIn(1, 10))
            .map { it.planId }

    fun clearNovaChart() {
        // 取消进行中的回测；只清空曲线，保留来源/模式/期数/勾选等 UI 记忆
        chartJob?.cancel()
        chartJob = null
        novaChartRunning.value = false
        novaChartReports.value = emptyList()
    }

    fun runConsensusChartBacktest(
        source: String,
        records: List<com.caifenxi.app.domain.model.ConsensusRecord>,
        periods: Int,
        stake: Double,
        categories: List<String> = listOf("大小", "单双", "组合"),
        invert: Boolean = false,
        guanguan: Boolean = false,
        guanguanTarget: Int = 3
    ) {
        chartJob?.cancel()
        novaChartRunning.value = true
        val cats = categories.ifEmpty { listOf("大小", "单双", "组合") }
        val inv = invert
        val gg = guanguan
        val ggTarget = guanguanTarget.coerceIn(1, 10)
        chartJob = viewModelScope.launch(Dispatchers.Default) {
            try {
                // 按大小/单双/组合分别回测，可多曲线对比；支持正投/反投
                val reports = NovaPlanAnalytics.chartBacktestConsensus(source, records, periods, stake, cats, inv, gg, ggTarget)
                if (!isActive) return@launch
                withContext(Dispatchers.Main) { novaChartReports.value = reports }
            } catch (_: CancellationException) {
            } finally {
                withContext(Dispatchers.Main) { novaChartRunning.value = false }
            }
        }
    }

    fun runNovaChartBacktest(
        rows: List<DrawRecord>,
        plans: List<PlanDefinition>,
        periods: Int,
        stake: Double,
        invert: Boolean = false,
        comboCount: Int = 3,
        numberCount: Int = 3,
        guanguan: Boolean = false,
        guanguanTarget: Int = 3
    ) {
        if (rows.size < 6 || plans.isEmpty()) return
        chartJob?.cancel()
        novaChartRunning.value = true
        val safePlans = plans.distinctBy { it.planId }.take(5)
        val stage = novaChartStage.value
        val safePeriods = periods.coerceIn(1, 5000)
        val inv = invert
        val comboN = comboCount.coerceIn(1, 4)
        val numN = numberCount.coerceIn(1, 10)
        val gg = guanguan
        val ggTarget = guanguanTarget.coerceIn(1, 10)
        chartJob = viewModelScope.launch(Dispatchers.Default) {
            try {
                val reports = ArrayList<NovaPlanAnalytics.ChartReport>(safePlans.size)
                for (plan in safePlans) {
                    if (!isActive) return@launch
                    val topN = when (plan.playType) {
                        "组合" -> comboN
                        "数字", "位置", "定位", "三军", "鱼虾蟹" -> numN
                        else -> null
                    }
                    reports += NovaPlanAnalytics.chartBacktest(
                        plan, rows, safePeriods, stake, stage, inv,
                        stageMult = if (plan.playType == "组合") 4.0 else 2.0,
                        outputCount = topN,
                        guanguan = gg,
                        guanguanTarget = ggTarget
                    )
                }
                if (!isActive) return@launch
                withContext(Dispatchers.Main) { novaChartReports.value = reports }
            } catch (_: CancellationException) {
            } finally {
                withContext(Dispatchers.Main) { novaChartRunning.value = false }
            }
        }
    }

    /** Nova 统一动态排行榜：统一回测窗口，按当前期次口径重新计算。结果缓存在 VM，离开页面不重置。 */
    fun refreshNovaLeaderboard(rows: List<DrawRecord>) {
        if (rows.size < 6) return
        leaderboardJob?.cancel()
        val category = novaLeaderboardCategory.value
        val stage = novaLeaderboardStage.value
        val periods = novaLeaderboardPeriods.value.coerceIn(20, 5000)
        val type = rows.firstOrNull()?.lotteryKey?.let { LotteryConfig.findByKey(it)?.type }
        val plans = (
            if (type != null) {
                LotteryPlanPools.novaPlansFor(type) +
                    generatedNovaPlans.value.filter { LotteryPlanPools.belongsTo(it, type) } +
                    customPlans.value.map { it.toDefinition() }
                    .filter { LotteryPlanPools.belongsTo(it, type) }
            } else emptyList()
        )
            .distinctBy { it.planId }
            .filter { category == "全部" || it.playType == category }
        novaLeaderboardLoading.value = true
        leaderboardJob = viewModelScope.launch(Dispatchers.Default) {
            try {
                val result = ArrayList<Pair<PlanDefinition, NovaPlanAnalytics.BacktestReport>>(plans.size)
                for (plan in plans) {
                    if (!isActive) return@launch
                    val base = NovaPlanAnalytics.backtest(plan, rows, periods)
                    val report = when (stage) {
                        2 -> base.copy(periods = base.twoWindows, hits = base.twoHitWindows, misses = base.twoMissWindows, hitRate = base.twoHitRate, edge = base.twoHitRate - base.randomBaseline)
                        3 -> base.copy(periods = base.threeWindows, hits = base.threeHitWindows, misses = base.threeMissWindows, hitRate = base.threeHitRate, edge = base.threeHitRate - base.randomBaseline)
                        else -> base
                    }
                    result += plan to report
                }
                if (!isActive) return@launch
                val sorted = result.sortedWith(compareByDescending<Pair<PlanDefinition, NovaPlanAnalytics.BacktestReport>> {
                    it.second.hitRate * 0.50 + it.second.edge.coerceIn(-1.0, 1.0) * 0.25 + it.second.stability * 0.15 +
                        (it.second.maxHitStreak.toDouble() / (it.second.maxHitStreak + it.second.maxMissStreak + 1.0)) * 0.10
                }.thenByDescending { it.second.hitRate }.thenByDescending { it.second.stability })
                withContext(Dispatchers.Main) {
                    novaLeaderboard.value = sorted
                    novaLeaderboardPage.value = novaLeaderboardPage.value.coerceAtMost(((sorted.size - 1).coerceAtLeast(0)) / 20)
                }
            } catch (_: CancellationException) {
            } finally {
                withContext(Dispatchers.Main) { novaLeaderboardLoading.value = false }
            }
        }
    }

    // ---- 自定义计划 ----

    /** 从 Room 加载当前彩种的自定义计划并注入 PlanEngine */
    fun loadCustomPlans(lotteryKey: String) {
        viewModelScope.launch {
            try {
                val key = lotteryKey
                val entities = app.customPlanDao.getByLottery(key)
                val plans = entities.map { it.toDomain() }
                customPlans.value = plans
                engine.setCustomPlans(
                    plans.filter { it.enabled }.map { it.toDefinition() }
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // 加载失败不影响主流程
            }
        }
    }

    /** 保存(新增或更新)自定义计划 */
    fun saveCustomPlan(plan: CustomPlan, onStatus: (String) -> Unit = {}) {
        viewModelScope.launch {
            try {
                app.customPlanDao.upsert(com.caifenxi.app.data.db.entity.CustomPlanEntity.fromDomain(plan))
                loadCustomPlans(plan.lotteryKey)
                onStatus("已保存计划「${plan.planName}」")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                onStatus("保存失败:${e.message}")
            }
        }
    }

    /** 删除自定义计划 */
    fun deleteCustomPlan(planId: String, lotteryKey: String, onStatus: (String) -> Unit = {}) {
        viewModelScope.launch {
            try {
                app.customPlanDao.deleteById(planId)
                loadCustomPlans(lotteryKey)
                onStatus("已删除计划")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                onStatus("删除失败:${e.message}")
            }
        }
    }

    /** 启用/停用自定义计划 */
    fun toggleCustomPlan(plan: CustomPlan, enabled: Boolean) {
        viewModelScope.launch {
            try {
                app.customPlanDao.upsert(
                    com.caifenxi.app.data.db.entity.CustomPlanEntity.fromDomain(
                        plan.copy(enabled = enabled, updatedAt = System.currentTimeMillis())
                    )
                )
                loadCustomPlans(plan.lotteryKey)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // 切换失败不影响主流程
            }
        }
    }
}
