# BTC Quant v17.6.0 — Ops Recovery

v17.6 在 v17.5 的 Settlement + Restart Recovery 之上增加生产运行期 Ops 层：

Market/Execution → Reconciliation → Recovery → Watchdog → Risk/Execution Gate → Settlement/Redeem → Audit

核心新增：
- ExecutionOpsCore
- ExecutionWatchdogCore
- ExecutionIncidentLedger

Watchdog 不直接下单；异常先转换为可审计的运行时动作。
