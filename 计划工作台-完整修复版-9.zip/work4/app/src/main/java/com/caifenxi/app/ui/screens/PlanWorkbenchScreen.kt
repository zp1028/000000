package com.caifenxi.app.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.caifenxi.app.domain.model.DrawRecord
import com.caifenxi.app.domain.model.PlanDefinition
import com.caifenxi.app.domain.model.PlanRuntime
import com.caifenxi.app.domain.plan.AlgoChartPlans
import com.caifenxi.app.domain.plan.LotteryPlanPools
import com.caifenxi.app.domain.plan.NovaPlanAnalytics
import com.caifenxi.app.domain.plan.WorkbenchBacktestCache
import com.caifenxi.app.domain.model.BetSourceType
import com.caifenxi.app.domain.plan.PlanPool
import com.caifenxi.app.ui.MainViewModel
import com.caifenxi.app.ui.components.CaptionMuted
import com.caifenxi.app.ui.components.GlobalCard
import com.caifenxi.app.ui.components.PageHeader
import com.caifenxi.app.ui.components.PrimaryButton
import com.caifenxi.app.ui.theme.CaiTokens
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.material3.OutlinedTextField
import androidx.compose.ui.platform.ClipboardManager
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString

private enum class WorkbenchTab(val label: String) {
    DETAIL("计划详情"),
    REVERSE("相反计划"),
    HISTORY("历史开奖"),
    TREND("计划走势"),
    GUIDE("计划攻略")
}

private enum class WorkbenchSource(val label: String) {
    ALL("全部计划"), LEGACY("原计划"), NOVA("新计划"), CANDIDATE("候选池"), CUSTOM("自定义"), MODEL("算法模型")
}

private enum class WorkbenchLevel(val label: String, val source: WorkbenchSource?) {
    HALL("计划大厅", null),
    BASIC("基础计划", WorkbenchSource.LEGACY),   // 原计划池
    COMBO("新计划池", WorkbenchSource.NOVA),     // 正式新计划（原「组合计划」易误解为空）
    EXTREME("极限候选", WorkbenchSource.CANDIDATE) // 候选策略池
}

private enum class LeaderboardTab(val label: String) {
    HIT_STREAK("最高连中"), HIT_RATE("最高胜率"), MISS_STREAK("最高连挂"),
    CURRENT_HIT("当前连中跳"), CURRENT_MISS("当前连挂跳")
}


/** 回测用历史切片：今日=按最新期号日期前缀；最近=全量供 chart 内部再截断 */
private fun sliceHistoryForMode(history: List<DrawRecord>, mode: String): List<DrawRecord> {
    if (history.isEmpty()) return history
    if (mode != "今日") return history
    val latest = history.lastOrNull()?.issue.orEmpty()
    val dayKey = when {
        latest.length >= 8 -> latest.take(8)
        latest.length >= 6 -> latest.take(6)
        else -> latest.take(4)
    }
    val day = history.filter { it.issue.startsWith(dayKey) }
    return if (day.size >= 6) day else history.takeLast(minOf(200, history.size))
}

/**
 * 完整珠段次数：例如 ✘✔✔✘✔✔✘ 中「双珠连中」出现 2 次。
 * wantHit=true 统计连中珠；false 统计连挂珠。runLen=珠数。
 */
private fun countZhuSegments(flags: List<Boolean>, runLen: Int, wantHit: Boolean): Int {
    if (runLen <= 0 || flags.isEmpty()) return 0
    var count = 0
    var i = 0
    while (i < flags.size) {
        if (flags[i] != wantHit) { i++; continue }
        var j = i
        while (j < flags.size && flags[j] == wantHit) j++
        val len = j - i
        // 完整珠段：长度恰好为 runLen，且被另一侧夹住（或在序列端点）
        if (len == runLen) {
            val leftOk = i == 0 || flags[i - 1] != wantHit
            val rightOk = j == flags.size || flags[j] != wantHit
            if (leftOk && rightOk) count++
        }
        i = j
    }
    return count
}

@Composable
fun PlanWorkbenchScreen(vm: MainViewModel) {
    var source by remember { mutableStateOf(WorkbenchSource.ALL) }
    var level by remember { mutableStateOf(WorkbenchLevel.HALL) }
    var category by remember { mutableStateOf("全部") }
    var positionFilter by remember { mutableStateOf("全部") }
    var selectedId by remember { mutableStateOf<String?>(null) }
    var tab by remember { mutableStateOf(WorkbenchTab.DETAIL) }
    var leaderboardTab by remember { mutableStateOf(LeaderboardTab.HIT_STREAK) }
    var periods by remember { mutableStateOf(500) }
    /** 最近N期 | 今日(自然日0点起的期号前缀) */
    var periodMode by remember { mutableStateOf("最近") }
    var resultLimit by remember { mutableStateOf(50) }
    var cycleFilter by remember { mutableStateOf(0) }
    /** 回测期数口径：1=一期，2=二期倍投轮，3=三期倍投轮；切换后重算胜率与详情 */
    var backtestStage by remember { mutableStateOf(1) }
    /**
     * 当前连中跳珠数：0=不限；N=当前连续中 N 期（N珠连中跳）。
     * 一次完整双珠连中跳 = ✘✔✔✘。
     */
    var hitZhu by remember { mutableStateOf(0) }
    /**
     * 当前连挂跳珠数：0=不限；N=当前连续挂 N 期（N珠连挂跳）。
     * 一次完整双珠连挂跳 = ✔✘✘✔；一次三珠连挂跳 = ✔✘✘✘✔。
     */
    var missZhu by remember { mutableStateOf(0) }
    var report by remember { mutableStateOf<NovaPlanAnalytics.ChartReport?>(null) }
    var running by remember { mutableStateOf(false) }
    /** 统一回测写入的运行态缓存（尤其候选池原本无引擎 runtime） */
    var runtimeCache by remember { mutableStateOf<Map<String, PlanRuntime>>(emptyMap()) }
    var batchRunning by remember { mutableStateOf(false) }
    var batchProgress by remember { mutableStateOf("") }
    var batchJob by remember { mutableStateOf<Job?>(null) }
    var planSearch by remember { mutableStateOf("") }
    /** 精选=App风格；扩展=矩阵计划；全部=不限 */
    var planTier by remember { mutableStateOf("全部") }
    var historyPage by remember { mutableStateOf(40) }
    var statusHint by remember { mutableStateOf("") }
    /** true=全屏详情（不再把详情堆在列表底部） */
    var detailMode by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current

    val lottery = vm.currentLottery.value
    val history = vm.history.value.sortedWith(compareBy<DrawRecord> { it.issue.toLongOrNull() ?: Long.MIN_VALUE }.thenBy { it.issue })
    val custom = vm.customPlans.value.filter { it.lotteryKey == lottery.key }.map { it.toDefinition() }
    // 实验室临时生成计划：不混入工作台「全部/新计划」主池，避免和正式计划混淆统计
    val generated = vm.planVM.generatedNovaPlans.value.filter { LotteryPlanPools.belongsTo(it, lottery.type) }
    // 新计划只取正式池，不含实验室生成物
    val nova = remember(lottery.type) { LotteryPlanPools.novaPlansFor(lottery.type).distinctBy { it.planId } }
    val candidates = remember(lottery.type) { (
        com.caifenxi.app.domain.plan.PlanAppStylePool.extreme(lottery.type) + when (lottery.type) {
            com.caifenxi.app.domain.model.LotteryType.PKS -> com.caifenxi.app.domain.plan.NovaPlanPool.CANDIDATES
            com.caifenxi.app.domain.model.LotteryType.YDH -> com.caifenxi.app.domain.plan.NovaYdhPlanPool.CANDIDATES
            com.caifenxi.app.domain.model.LotteryType.K3 -> com.caifenxi.app.domain.plan.NovaK3PlanPool.CANDIDATES
            com.caifenxi.app.domain.model.LotteryType.PC28 -> com.caifenxi.app.domain.plan.NovaPc28PlanPool.CANDIDATES
            com.caifenxi.app.domain.model.LotteryType.LUCK20 -> com.caifenxi.app.domain.plan.NovaLuck20PlanPool.CANDIDATES
            else -> emptyList()
        }
    ).distinctBy { it.planId } }
    val legacy = remember(lottery.type) { LotteryPlanPools.legacyPlansFor(lottery.type) }
    // 算法模型（经验/形态/融合）= 实验室口径，仅在「算法模型」筛选下出现，不进计划大厅
    val models = if (lottery.type.name in listOf("YDH", "K3")) emptyList() else AlgoChartPlans.EXPERIENCE + AlgoChartPlans.PATTERN + AlgoChartPlans.FUSION

    // 计划大厅/全部：仅正式原计划 + 正式新计划 + 用户自定义；不含实验室生成、不含候选池、不含算法模型
    val all = (legacy + nova + custom).distinctBy { it.planId }
    val sourcePlans = when (source) {
        WorkbenchSource.ALL -> all
        WorkbenchSource.LEGACY -> legacy
        WorkbenchSource.NOVA -> nova
        WorkbenchSource.CANDIDATE -> candidates
        WorkbenchSource.CUSTOM -> custom
        WorkbenchSource.MODEL -> models
    }
    val favoriteIds = vm.favoritePlanIds(lottery.key)
    val playOptions = listOf("全部") + sourcePlans.map { it.playType }.distinct().sorted()
    val positionOptions = listOf("全部") + sourcePlans.mapNotNull { p ->
        if (p.positionIndex >= 0) "位置${p.positionIndex + 1}" else null
    }.distinct().sortedBy { it.removePrefix("位置").toIntOrNull() ?: 0 }
    val filtered = sourcePlans.asSequence()
        .filter { category == "全部" || category == "★ 收藏" || it.playType == category }
        .filter { positionFilter == "全部" || "位置${it.positionIndex + 1}" == positionFilter }
        .filter { cycleFilter == 0 || it.cyclePeriods == cycleFilter }
        .let { seq -> if (category == "★ 收藏") seq.filter { it.planId in favoriteIds } else seq }
        .let { seq ->
            if (hitZhu > 0 || missZhu > 0) {
                seq.filter { p ->
                    val rt = runtimeCache[p.planId] ?: vm.planVM.runtimeForPlan(p.planId)
                    (hitZhu == 0 || rt.consecutiveHit == hitZhu) &&
                        (missZhu == 0 || rt.consecutiveMiss == missZhu)
                }
            } else seq
        }
        .let { seq ->
            val q = planSearch.trim()
            if (q.isEmpty()) seq
            else seq.filter {
                it.planName.contains(q, ignoreCase = true) ||
                    it.planId.contains(q, ignoreCase = true) ||
                    it.playType.contains(q, ignoreCase = true) ||
                    it.algorithm.contains(q, ignoreCase = true)
            }
        }
        .let { seq ->
            when (planTier) {
                "精选" -> seq.filter {
                    it.planId.startsWith("APP-") || it.category.contains("App") ||
                        it.algorithm in setOf("LUZHU", "GENZHU", "SHUANGZHU", "SANZHU", "YILOU_BU", "SHA_RE", "FANZHU", "CHANGLOONG", "DINGBAN")
                }
                "扩展" -> seq.filter {
                    !it.planId.startsWith("APP-") && !it.planId.startsWith("APPX-") &&
                        it.algorithm !in setOf("LUZHU", "GENZHU", "SHUANGZHU", "SANZHU", "YILOU_BU", "SHA_RE", "FANZHU", "CHANGLOONG", "DINGBAN")
                }
                "极限App" -> seq.filter { it.planId.startsWith("APPX-") || it.category.contains("极限") }
                else -> seq
            }
        }
        .take(resultLimit)
        .toList()
    val selected = filtered.firstOrNull { it.planId == selectedId } ?: filtered.firstOrNull()

    fun resolveRuntime(planId: String): PlanRuntime {
        runtimeCache[planId]?.let { return it }
        return vm.planVM.runtimeForPlan(planId)
    }

    val leaderboardRows = filtered.map { p -> p to resolveRuntime(p.planId) }
        .sortedWith(when (leaderboardTab) {
            LeaderboardTab.HIT_STREAK -> compareByDescending<Pair<PlanDefinition, PlanRuntime>> { it.second.maxConsecutiveHit }.thenByDescending { it.second.hitRate }.thenByDescending { it.second.sampleCount }
            LeaderboardTab.HIT_RATE -> compareByDescending<Pair<PlanDefinition, PlanRuntime>> { if (it.second.sampleCount >= 5) it.second.hitRate else -1.0 }.thenByDescending { it.second.score }.thenByDescending { it.second.sampleCount }
            LeaderboardTab.MISS_STREAK -> compareByDescending<Pair<PlanDefinition, PlanRuntime>> { it.second.maxConsecutiveMiss }.thenByDescending { it.second.sampleCount }
            LeaderboardTab.CURRENT_HIT -> compareByDescending<Pair<PlanDefinition, PlanRuntime>> { it.second.consecutiveHit }.thenByDescending { it.second.maxConsecutiveHit }.thenByDescending { it.second.sampleCount }
            LeaderboardTab.CURRENT_MISS -> compareByDescending<Pair<PlanDefinition, PlanRuntime>> { it.second.consecutiveMiss }.thenByDescending { it.second.maxConsecutiveMiss }.thenByDescending { it.second.sampleCount }
        }).take(20)

    LaunchedEffect(lottery.key, all.size, candidates.size, models.size, generated.size) {
        // 收藏校验可含候选/模型/已生成；但主列表展示不混入实验室临时计划
        vm.pruneFavoritePlans((all + candidates + custom + models + generated).map { it.planId }.toSet(), lottery.key)
    }

    LaunchedEffect(source, level, category, positionFilter, cycleFilter, hitZhu, missZhu, filtered.size, lottery.key) {
        if (selectedId !in filtered.map { it.planId }) selectedId = filtered.firstOrNull()?.planId
    }

    LaunchedEffect(lottery.key) {
        vm.loadCustomPlans()
        selectedId = null
        report = null
    }

    fun runPlanBacktest(plan: PlanDefinition, stageOverride: Int? = null) {
        if (history.size < 6) return
        val st = (stageOverride ?: backtestStage).coerceIn(1, 3)
        val histSnap = sliceHistoryForMode(history, periodMode)
        val periodsSnap = if (periodMode == "今日") histSnap.size.coerceAtLeast(1) else periods
        val lastIssue = histSnap.lastOrNull()?.issue.orEmpty()
        val cacheKey = WorkbenchBacktestCache.key(plan.planId, st, periodsSnap, lastIssue, histSnap.size, false)
        WorkbenchBacktestCache.get(cacheKey)?.let { cached ->
            report = cached
            val pts = cached.points
            runtimeCache = runtimeCache + (plan.planId to PlanRuntime(
                planId = plan.planId,
                sampleCount = cached.hits + cached.misses,
                hitCount = cached.hits,
                consecutiveMiss = cached.currentMissStreak,
                consecutiveHit = cached.currentHitStreak,
                maxConsecutiveMiss = cached.maxMissStreak,
                maxConsecutiveHit = cached.maxHitStreak,
                lastPrediction = pts.lastOrNull()?.prediction,
                lastTargetIssue = pts.lastOrNull()?.issue
            ))
            return
        }
        val oc = when (plan.playType) {
            "组合" -> vm.prefs.value.comboPredCount
            "数字", "位置", "定位" -> vm.prefs.value.positionTopN
            else -> null
        }
        running = true
        report = null
        scope.launch {
            try {
                val rep = withContext(Dispatchers.Default) {
                    NovaPlanAnalytics.chartBacktest(
                        plan = plan,
                        history = histSnap,
                        periods = periodsSnap,
                        stake = 10.0,
                        stage = st,
                        invert = false,
                        outputCount = oc
                    )
                }
                WorkbenchBacktestCache.put(cacheKey, rep)
                report = rep
                val pts = rep.points
                runtimeCache = runtimeCache + (plan.planId to PlanRuntime(
                    planId = plan.planId,
                    sampleCount = rep.hits + rep.misses,
                    hitCount = rep.hits,
                    consecutiveMiss = rep.currentMissStreak,
                    consecutiveHit = rep.currentHitStreak,
                    maxConsecutiveMiss = rep.maxMissStreak,
                    maxConsecutiveHit = rep.maxHitStreak,
                    lastPrediction = pts.lastOrNull()?.prediction,
                    lastTargetIssue = pts.lastOrNull()?.issue
                ))
            } catch (e: Exception) {
                report = null
                statusHint = "回测失败：${e.message ?: "未知错误"}"
            } finally {
                running = false
            }
        }
    }

    // 仅在详情模式且已选计划时回测，避免一进工作台就卡死主线程
    LaunchedEffect(selectedId, lottery.key, history.size, periods, backtestStage, detailMode, periodMode) {
        if (!detailMode) return@LaunchedEffect
        val id = selectedId ?: return@LaunchedEffect
        val p = filtered.firstOrNull { it.planId == id } ?: return@LaunchedEffect
        if (history.size >= 6) {
            runPlanBacktest(p, backtestStage)
        }
    }

    /** 统一回测：可取消；结果写入 runtimeCache */
    fun runBatchBacktest() {
        if (batchRunning || history.size < 6) return
        val targets = filtered.take(resultLimit.coerceAtLeast(20))
        if (targets.isEmpty()) return
        batchJob?.cancel()
        batchRunning = true
        batchProgress = "0/${targets.size}"
        batchJob = scope.launch {
            val map = LinkedHashMap<String, PlanRuntime>()
            try {
                targets.forEachIndexed { idx, plan ->
                    ensureActive()
                    val oc = when (plan.playType) {
                        "组合" -> vm.prefs.value.comboPredCount
                        "数字", "位置", "定位" -> vm.prefs.value.positionTopN
                        else -> null
                    }
                    val rep = withContext(Dispatchers.Default) {
                        NovaPlanAnalytics.chartBacktest(
                            plan = plan,
                            history = history,
                            periods = periods.coerceAtMost(500),
                            stake = 10.0,
                            stage = backtestStage.coerceIn(1, 3),
                            invert = false,
                            outputCount = oc
                        )
                    }
                    map[plan.planId] = PlanRuntime(
                        planId = plan.planId,
                        sampleCount = rep.hits + rep.misses,
                        hitCount = rep.hits,
                        consecutiveMiss = rep.currentMissStreak,
                        consecutiveHit = rep.currentHitStreak,
                        maxConsecutiveMiss = rep.maxMissStreak,
                        maxConsecutiveHit = rep.maxHitStreak,
                        lastPrediction = rep.points.lastOrNull()?.prediction,
                        lastTargetIssue = rep.points.lastOrNull()?.issue
                    )
                    batchProgress = "${idx + 1}/${targets.size}"
                }
                runtimeCache = runtimeCache + map
                batchProgress = "完成${map.size}个"
                selected?.let { runPlanBacktest(it) }
            } catch (e: kotlinx.coroutines.CancellationException) {
                runtimeCache = runtimeCache + map
                batchProgress = "已取消·已保存${map.size}个"
                throw e
            } finally {
                batchRunning = false
                batchJob = null
            }
        }
    }

    fun cancelBatchBacktest() {
        batchJob?.cancel()
        batchJob = null
        batchRunning = false
        if (!batchProgress.startsWith("完成") && !batchProgress.startsWith("已取消")) {
            batchProgress = "已取消"
        }
    }

    if (detailMode && selected != null) {
        // —— 全屏详情页：不再堆在列表底部 ——
        PlanDetailFullPage(
            plan = selected,
            report = report,
            history = history,
            running = running,
            backtestStage = backtestStage,
            periods = periods,
            tab = tab,
            onTab = { tab = it },
            onBack = { detailMode = false; report = null },
            onStage = { s ->
                if (s != backtestStage) {
                    backtestStage = s
                    report = null
                    // 立即按新口径重算，避免仍显示一期胜率
                    WorkbenchBacktestCache.clear()
                    runPlanBacktest(selected, s)
                }
            },
            onRefresh = { runPlanBacktest(selected, backtestStage) },
            onPeriodsChange = { n ->
                periods = n
                // 期数变更后立刻按新期数重算（含二期/三期口径）
                runPlanBacktest(selected, backtestStage)
            },
            onFavorite = { vm.togglePlanFavorite(selected.planId) },
            isFavorite = vm.isPlanFavorite(selected.planId),
            resolveRuntime = { resolveRuntime(it) },
            sourceLabel = sourceLabel(selected, legacy, nova, candidates, custom, models),
            candidates = candidates,
            clipboard = clipboard,
            vm = vm,
            nextIssue = vm.nextIssueText.value,
            historyPage = historyPage,
            onHistoryPage = { historyPage = it },
            onSetBotSource = {
                val cfg = vm.botConfig.value
                vm.saveBotConfig(
                    cfg.copy(
                        sourceType = BetSourceType.FAVORITE.id,
                        sourceId = selected.planId,
                        sourceIdDx = selected.planId,
                        sourceIdDs = selected.planId,
                        sourceIdCombo = selected.planId,
                        rollingPredict = true
                    )
                )
                if (!vm.isPlanFavorite(selected.planId)) vm.togglePlanFavorite(selected.planId)
                statusHint = "已设为挂机来源并收藏：${selected.planName}"
            }
        )
    } else LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = CaiTokens.S12, vertical = CaiTokens.S8),
        verticalArrangement = Arrangement.spacedBy(CaiTokens.S8),
        contentPadding = PaddingValues(bottom = CaiTokens.ScreenBottom)
    ) {
        item {
            GlobalCard {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(lottery.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        CaptionMuted("计划工作台 · ${com.caifenxi.app.domain.model.LotteryPlayCatalog.summaryText(lottery.type)}")
                        val histN = history.size
                        val next = vm.nextIssueText.value
                        CaptionMuted(
                            if (histN < 6) "历史不足(${histN}期)，请先同步开奖"
                            else "历史${histN}期 · 下期 ${if (next.isBlank() || next == "-") "—" else next}"
                        )
                    }
                    Text("★ ${favoriteIds.size}", color = CaiTokens.Warning, fontWeight = FontWeight.Bold)
                }
            }
        }
        item {
            val levelCounts = mapOf(
                WorkbenchLevel.HALL to all.size,
                WorkbenchLevel.BASIC to legacy.size,
                WorkbenchLevel.COMBO to nova.size,
                WorkbenchLevel.EXTREME to candidates.size
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                WorkbenchLevel.entries.forEach { l ->
                    val cnt = levelCounts[l] ?: 0
                    Column(
                        Modifier.weight(1f).clickable {
                            level = l
                            source = l.source ?: WorkbenchSource.ALL
                            category = "全部"
                            positionFilter = "全部"
                            hitZhu = 0
                            missZhu = 0
                            selectedId = null
                            // 极限候选数量大，自动放宽条数
                            if (l == WorkbenchLevel.EXTREME) resultLimit = 500
                        }.padding(vertical = 8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            l.label,
                            fontWeight = if (level == l) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 13.sp,
                            color = if (level == l) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            "${cnt}个",
                            fontSize = 11.sp,
                            color = if (cnt == 0) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        if (level == l) HorizontalDivider(Modifier.padding(top = 4.dp), thickness = 3.dp)
                    }
                }
            }
            if (sourcePlans.isEmpty()) {
                CaptionMuted(
                    when (level) {
                        WorkbenchLevel.BASIC -> "基础计划（原计划池）当前彩种无数据"
                        WorkbenchLevel.COMBO -> "新计划池当前彩种无正式计划"
                        WorkbenchLevel.EXTREME -> "极限候选池当前彩种无候选策略"
                        else -> "计划大厅暂无计划"
                    }
                )
            } else {
                CaptionMuted(
                    when (level) {
                        WorkbenchLevel.BASIC -> "基础计划=原计划池 · ${legacy.size}个"
                        WorkbenchLevel.COMBO -> "新计划池=正式Nova · ${nova.size}个（不含实验室生成/候选）"
                        WorkbenchLevel.EXTREME -> "极限候选=策略候选池 · ${candidates.size}个 · 建议点「统一回测」填充连跳数据"
                        else -> "计划大厅=原计划+新计划+自定义 · ${all.size}个"
                    }
                )
            }
        }
        item {
            GlobalCard {
                Text("玩法分类", fontWeight = FontWeight.Bold)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    playOptions.forEach { c ->
                        FilterChip(selected = category == c, onClick = { category = c; selectedId = null }, label = { Text(c) })
                    }
                    FilterChip(selected = category == "★ 收藏", onClick = { category = "★ 收藏"; selectedId = null }, label = { Text("★ 收藏 ${favoriteIds.size}") })
                }
                Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    positionOptions.forEach { p ->
                        FilterChip(selected = positionFilter == p, onClick = { positionFilter = p; selectedId = null }, label = { Text(p) })
                    }
                }
                Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    WorkbenchSource.entries.filter { it == WorkbenchSource.CUSTOM || it == WorkbenchSource.MODEL }.forEach { s ->
                        FilterChip(selected = source == s, onClick = { source = s; category = "全部"; positionFilter = "全部"; selectedId = null }, label = { Text(s.label) })
                    }
                }
                Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("全部", "精选", "极限App", "扩展").forEach { tier ->
                        FilterChip(
                            selected = planTier == tier,
                            onClick = { planTier = tier; selectedId = null },
                            label = { Text(tier) }
                        )
                    }
                }
                CaptionMuted("精选=路珠/双珠等App口径；极限App=多窗口变体；扩展=矩阵统计计划")
                CaptionMuted(
                    if (periodMode == "今日") "回测范围：今日自然日（按期号日期，约0点后新一天）"
                    else "回测范围：最近 ${periods} 期（非自然日；可在走势里改期数）"
                )
                if (statusHint.isNotEmpty()) CaptionMuted(statusHint)
            }
        }
        item {
            GlobalCard {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    WorkbenchFilterButton("计划数量", if (resultLimit >= 9999) "全部" else "≤${resultLimit}", Modifier.weight(1f)) { resultLimit = when (resultLimit) { 50 -> 100; 100 -> 200; 200 -> 500; 500 -> 1000; 1000 -> 9999; else -> 50 } }
                    WorkbenchFilterButton("计划周期", if (cycleFilter == 0) "全部" else "${cycleFilter}期", Modifier.weight(1f)) { cycleFilter = when (cycleFilter) { 0 -> 1; 1 -> 2; 2 -> 3; 3 -> 5; else -> 0 } }
                    WorkbenchFilterButton(
                        "回测范围",
                        if (periodMode == "今日") "今日0点起" else "最近${periods}期",
                        Modifier.weight(1f)
                    ) {
                        periodMode = if (periodMode == "今日") "最近" else "今日"
                        report = null
                        WorkbenchBacktestCache.clear()
                    }
                    WorkbenchFilterButton(
                        "回测口径",
                        when (backtestStage) { 2 -> "二期"; 3 -> "三期"; else -> "一期" },
                        Modifier.weight(1f)
                    ) {
                        backtestStage = when (backtestStage) { 1 -> 2; 2 -> 3; else -> 1 }
                        report = null
                        runtimeCache = emptyMap() // 口径变了，旧连跳缓存作废
                    }
                    WorkbenchFilterButton(
                        "连中跳",
                        zhuLabel(hitZhu, "连中"),
                        Modifier.weight(1f)
                    ) {
                        // 0→1珠→双珠→三珠→四珠→五珠→全部
                        hitZhu = when (hitZhu) { 0 -> 1; 1 -> 2; 2 -> 3; 3 -> 4; 4 -> 5; else -> 0 }
                        missZhu = 0 // 连中与连挂互斥（同一时刻只能处于一种连续状态）
                        selectedId = null
                    }
                }
                Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    WorkbenchFilterButton(
                        "连挂跳",
                        zhuLabel(missZhu, "连挂"),
                        Modifier.weight(1f)
                    ) {
                        missZhu = when (missZhu) { 0 -> 1; 1 -> 2; 2 -> 3; 3 -> 4; 4 -> 5; else -> 0 }
                        hitZhu = 0
                        selectedId = null
                    }
                    WorkbenchFilterButton(
                        "双珠/三珠",
                        when {
                            missZhu == 2 -> "双珠连挂"
                            missZhu == 3 -> "三珠连挂"
                            hitZhu == 2 -> "双珠连中"
                            hitZhu == 3 -> "三珠连中"
                            else -> "快捷"
                        },
                        Modifier.weight(1f)
                    ) {
                        // 快捷：双珠连挂 → 三珠连挂 → 双珠连中 → 三珠连中 → 全部
                        when {
                            hitZhu == 0 && missZhu == 0 -> { missZhu = 2; hitZhu = 0 }
                            missZhu == 2 -> { missZhu = 3; hitZhu = 0 }
                            missZhu == 3 -> { hitZhu = 2; missZhu = 0 }
                            hitZhu == 2 -> { hitZhu = 3; missZhu = 0 }
                            else -> { hitZhu = 0; missZhu = 0 }
                        }
                        selectedId = null
                    }
                    WorkbenchFilterButton("重置筛选", "清空", Modifier.weight(1f)) {
                        hitZhu = 0
                        missZhu = 0
                        cycleFilter = 0
                        resultLimit = 50
                        backtestStage = 1
                        planTier = "全部"
                        planSearch = ""
                        report = null
                        selectedId = null
                        statusHint = ""
                    }
                }
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    PrimaryButton(
                        "开始搜索",
                        {
                            selectedId = null
                            detailMode = false
                            report = null
                            statusHint = "已筛选 ${filtered.size} 条，点列表进入详情"
                        },
                        Modifier.weight(1f),
                        enabled = filtered.isNotEmpty()
                    )
                    PrimaryButton(
                        if (batchRunning) "回测中 $batchProgress" else "统一回测",
                        { runBatchBacktest() },
                        Modifier.weight(1f),
                        enabled = !batchRunning && filtered.isNotEmpty() && history.size >= 6
                    )
                    if (batchRunning) {
                        PrimaryButton("取消", { cancelBatchBacktest() }, Modifier.weight(0.7f), ghost = true)
                    }
                }
                CaptionMuted(
                    buildString {
                        append("当前 ${source.label} · ${filtered.size} 个结果 · 正式 ${all.size} · 候选 ${candidates.size}")
                        if (generated.isNotEmpty()) append(" · 实验室生成${generated.size}条(不混入主池)")
                        if (hitZhu > 0) append(" · ${zhuLabel(hitZhu, "连中")}")
                        if (missZhu > 0) append(" · ${zhuLabel(missZhu, "连挂")}")
                        if (runtimeCache.isNotEmpty()) append(" · 已缓存回测${runtimeCache.size}")
                        if (batchProgress.isNotEmpty()) append(" · $batchProgress")
                    }
                )
                CaptionMuted("珠数说明：✔✘✘✔=一次双珠连挂跳；✔✘✘✘✔=一次三珠连挂跳；筛选精确匹配当前连续中/挂期数")
            }
        }
        item {
            GlobalCard {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    LeaderboardTab.entries.forEach { t ->
                        FilterChip(selected = leaderboardTab == t, onClick = { leaderboardTab = t }, label = { Text(t.label) })
                    }
                }
            }
        }
        item {
            val chunks = leaderboardRows.chunked(2)
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                chunks.forEach { pair ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        pair.forEach { (p, rt) ->
                            GlobalCard(Modifier.weight(1f).clickable { selectedId = p.planId; tab = WorkbenchTab.DETAIL; report = null; detailMode = true }) {
                                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                    Text(p.planName.take(11), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                                    Text(if (p.planId in favoriteIds) "★" else "☆", color = CaiTokens.Warning)
                                }
                                when (leaderboardTab) {
                                    LeaderboardTab.HIT_STREAK -> Text("最高连中${rt.maxConsecutiveHit}珠")
                                    LeaderboardTab.HIT_RATE -> Text(if (rt.sampleCount > 0) "中奖率${"%.0f".format(rt.hitRate * 100)}%" else "中奖率—")
                                    LeaderboardTab.MISS_STREAK -> Text("最高连挂${rt.maxConsecutiveMiss}珠")
                                    LeaderboardTab.CURRENT_HIT -> Text(if (rt.consecutiveHit > 0) zhuLabel(rt.consecutiveHit, "连中") else "连中0")
                                    LeaderboardTab.CURRENT_MISS -> Text(if (rt.consecutiveMiss > 0) zhuLabel(rt.consecutiveMiss, "连挂") else "连挂0")
                                }
                                CaptionMuted("${p.playType} · ${if (p.positionIndex >= 0) "位置${p.positionIndex + 1}" else "不定位"}")
                            }
                        }
                        if (pair.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            }
        }
        item {
            GlobalCard {
                Text("计划列表 · ${filtered.size}个", fontWeight = FontWeight.Bold)
                OutlinedTextField(
                    value = planSearch,
                    onValueChange = { planSearch = it; selectedId = null },
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    singleLine = true,
                    placeholder = { Text("搜索计划名/ID/玩法/算法") }
                )
                if (filtered.isEmpty()) {
                    CaptionMuted(
                        when {
                            planSearch.isNotBlank() -> "无匹配「$planSearch」的计划，请改关键词或重置筛选"
                            sourcePlans.isEmpty() -> "当前分类下没有计划，请切换「基础/新计划池/极限候选」"
                            else -> "筛选后无结果，可点重置筛选或切换玩法"
                        }
                    )
                } else {
                    CaptionMuted("共 ${filtered.size} 条，列表虚拟滚动，可点进详情")
                }
            }
        }
        if (filtered.isNotEmpty()) {
            items(filtered.size, key = { filtered[it].planId }) { idx ->
                val p = filtered[idx]
                val rt = resolveRuntime(p.planId)
                val selectedRow = p.planId == selected?.planId
                GlobalCard(
                    Modifier.clickable {
                        selectedId = p.planId
                        tab = WorkbenchTab.DETAIL
                        report = null
                        detailMode = true
                        historyPage = 40
                    }
                ) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            if (p.planId in favoriteIds) "★" else "☆",
                            color = CaiTokens.Warning,
                            modifier = Modifier.padding(end = 6.dp)
                        )
                        Column(Modifier.weight(1f)) {
                            Text(
                                p.planName,
                                fontWeight = if (selectedRow) FontWeight.Bold else FontWeight.Normal,
                                color = if (selectedRow) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                                fontSize = 13.sp,
                                maxLines = 1
                            )
                            CaptionMuted("${p.playType} · ${p.algorithm} · 窗${p.window}")
                        }
                        Text(
                            if (rt.sampleCount > 0) "${"%.0f".format(rt.hitRate * 100)}%" else "—",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }

        item {
            GlobalCard {
                CaptionMuted(
                    when {
                        history.size < 6 -> "开奖历史不足，请先在首页/历史页同步数据后再回测"
                        filtered.isEmpty() -> "当前筛选无计划，可切换「精选/扩展」或重置筛选"
                        else -> "点击上方计划进入独立详情（下期预测 · 回测 · 挂机绑定）"
                    }
                )
            }
        }
    }
}

/** 珠数文案：1珠 / 双珠 / 三珠 / N珠 + 连中|连挂跳 */
private fun zhuLabel(n: Int, kind: String): String = when {
    n <= 0 -> "全部"
    n == 1 -> "1珠${kind}跳"
    n == 2 -> "双珠${kind}跳"
    n == 3 -> "三珠${kind}跳"
    else -> "${n}珠${kind}跳"
}

@Composable
private fun WorkbenchFilterButton(title: String, value: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    OutlinedButton(
        onClick = onClick,
        modifier = modifier,
        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 8.dp)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(title, fontSize = 11.sp)
            Text(value, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

private fun sourceLabel(p: PlanDefinition, legacy: List<PlanDefinition>, nova: List<PlanDefinition>, candidates: List<PlanDefinition>, custom: List<PlanDefinition>, models: List<PlanDefinition>): String = when {
    legacy.any { it.planId == p.planId } -> "原计划池"
    nova.any { it.planId == p.planId } -> "新计划池"
    candidates.any { it.planId == p.planId } -> "候选策略池"
    custom.any { it.planId == p.planId } -> "自定义计划"
    models.any { it.planId == p.planId } -> "算法模型"
    else -> "计划"
}


@Composable
private fun PlanDetailCard(plan: PlanDefinition, report: NovaPlanAnalytics.ChartReport?) {
    GlobalCard {
        Text("计划详情", fontWeight = FontWeight.Bold)
        DetailRow("计划ID", plan.planId)
        DetailRow("计划名称", plan.planName)
        DetailRow("玩法", plan.playType)
        DetailRow("分类", plan.category)
        DetailRow("算法", plan.algorithm)
        DetailRow("样本窗口", "${plan.window}期")
        DetailRow("执行周期", "${plan.cyclePeriods}期")
        DetailRow("命中基准", "${"%.1f".format(plan.baselineValue * 100)}%")
        DetailRow("共识参与", if (plan.participateConsensus) "是" else "否")
        report?.let {
            HorizontalDivider(Modifier.padding(vertical = 6.dp))
            Text("最近回测", fontWeight = FontWeight.SemiBold)
            DetailRow("回测期数", "${it.periods}期")
            DetailRow("命中", "${it.hits} / ${it.misses}")
            DetailRow("命中率", "${"%.2f".format(it.hitRate * 100)}%")
            DetailRow("累计收益", "${"%.2f".format(it.netProfit)}")
            DetailRow("最大连中", "${it.maxHitStreak}周期")
            DetailRow("最大连挂", "${it.maxMissStreak}周期")
            DetailRow("最大回撤", "${"%.2f".format(it.maxDrawdown)}")
        }
    }
}

/**
 * 全屏计划详情（独立页，不堆在列表底部）
 */
@Composable
private fun PlanDetailFullPage(
    plan: PlanDefinition,
    report: NovaPlanAnalytics.ChartReport?,
    history: List<DrawRecord>,
    running: Boolean,
    backtestStage: Int,
    periods: Int,
    tab: WorkbenchTab,
    onTab: (WorkbenchTab) -> Unit,
    onBack: () -> Unit,
    onStage: (Int) -> Unit,
    onRefresh: () -> Unit,
    onPeriodsChange: (Int) -> Unit,
    onFavorite: () -> Unit,
    isFavorite: Boolean,
    resolveRuntime: (String) -> PlanRuntime,
    sourceLabel: String,
    candidates: List<PlanDefinition>,
    clipboard: ClipboardManager,
    vm: MainViewModel,
    nextIssue: String,
    historyPage: Int = 40,
    onHistoryPage: (Int) -> Unit = {},
    onSetBotSource: () -> Unit = {}
) {
    val planRt = resolveRuntime(plan.planId)
    val pts = report?.points.orEmpty()
    // 胜率/连跳只认当前报告（禁止回落到一期缓存）
    val hits = report?.hits ?: 0
    val misses = report?.misses ?: 0
    val total = hits + misses
    val rate = if (total > 0) hits * 100.0 / total else 0.0
    // 一期按期连续；二期/三期按轮连续（来自 ChartReport 轮统计）
    val curHit = report?.currentHitStreak
        ?: if (pts.isNotEmpty()) pts.takeLastWhile { it.hit }.size else 0
    val curMiss = report?.currentMissStreak
        ?: if (pts.isNotEmpty()) pts.takeLastWhile { !it.hit }.size else 0
    val maxHit = report?.maxHitStreak ?: 0
    val maxMiss = report?.maxMissStreak ?: 0
    val zhuFlags = remember(report, backtestStage, pts) {
        when {
            backtestStage >= 2 && report?.roundResults?.isNotEmpty() == true -> report.roundResults
            else -> pts.map { it.hit }
        }
    }
    val zhuHit2 = remember(zhuFlags) { countZhuSegments(zhuFlags, 2, true) }
    val zhuMiss2 = remember(zhuFlags) { countZhuSegments(zhuFlags, 2, false) }
    val zhuHit3 = remember(zhuFlags) { countZhuSegments(zhuFlags, 3, true) }
    val zhuMiss3 = remember(zhuFlags) { countZhuSegments(zhuFlags, 3, false) }
    // 下一期预测：用全量历史现算，不是最后一期已开奖回测点
    val nextPred = remember(plan.planId, history.size, plan.window) {
        val oc = when (plan.playType) {
            "组合" -> vm.prefs.value.comboPredCount
            "数字", "位置", "定位" -> vm.prefs.value.positionTopN
            else -> null
        }
        if (history.size >= 6) NovaPlanAnalytics.predict(plan, history, oc)?.output else null
    }
    val lastSettled = pts.lastOrNull()
    val stageLabel = when (backtestStage) { 2 -> "二期"; 3 -> "三期"; else -> "一期" }

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = CaiTokens.S12, vertical = CaiTokens.S8),
        verticalArrangement = Arrangement.spacedBy(CaiTokens.S8),
        contentPadding = PaddingValues(bottom = CaiTokens.ScreenBottom)
    ) {
        item {
            GlobalCard {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    PrimaryButton("← 返回列表", onBack, ghost = true)
                    Spacer(Modifier.weight(1f))
                    Text(if (isFavorite) "★" else "☆", color = CaiTokens.Warning, modifier = Modifier.clickable(onClick = onFavorite))
                }
                Text(plan.planName, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                CaptionMuted("$sourceLabel · ${plan.playType} · 计划周期${plan.cyclePeriods}期 · 回测口径$stageLabel")
            }
        }
        item {
            GlobalCard {
                Text("回测口径（切换会重算胜率与历史）", fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(1 to "一期", 2 to "二期", 3 to "三期").forEach { (s, lab) ->
                        FilterChip(
                            selected = backtestStage == s,
                            onClick = { onStage(s) },
                            label = { Text(lab) }
                        )
                    }
                }
                CaptionMuted(
                    when (backtestStage) {
                        2 -> "二期轮口径：锁一次预测最多追2期；任一期中=本轮中，两期全挂=本轮挂。胜率=中轮/总轮（高于一期属正常）。"
                        3 -> "三期轮口径：锁一次预测最多追3期；任一期中=本轮中，三期全挂=本轮挂。胜率=中轮/总轮（高于一期属正常）。"
                        else -> "一期：每期独立预测、独立结算。胜率=中期/总期。"
                    }
                )
            }
        }
        item {
            GlobalCard(containerColor = MaterialTheme.colorScheme.secondaryContainer) {
                // 下一期（未开奖）预测
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("下期预测", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.width(12.dp))
                    Text(
                        nextPred ?: if (running) "计算中…" else "—",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(Modifier.width(10.dp))
                    Text(
                        if (nextIssue.isNotBlank() && nextIssue != "-") "目标$nextIssue" else "等待开奖",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                // 最近一期已结算回测结果（仅参考）
                if (lastSettled != null) {
                    CaptionMuted(
                        "最近已开 ${lastSettled.issue.takeLast(6)}：预测 ${lastSettled.prediction} → ${if (lastSettled.hit) "中" else "挂"}"
                    )
                }
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(
                        "当前连中：${curHit}${if (backtestStage >= 2) "轮" else "珠"}",
                        color = if (curHit > 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp
                    )
                    Text(
                        "当前连挂：${curMiss}${if (backtestStage >= 2) "轮" else "珠"}",
                        color = if (curMiss > 0) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp
                    )
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    CaptionMuted("历史最大连中：${maxHit}${if (backtestStage >= 2) "轮" else "珠"}")
                    CaptionMuted("历史最大连挂：${maxMiss}${if (backtestStage >= 2) "轮" else "珠"}")
                }
                CaptionMuted("完整珠段：双珠连中${zhuHit2} · 三珠连中${zhuHit3} · 双珠连挂${zhuMiss2} · 三珠连挂${zhuMiss3}（✘✔✔✘✔✔✘=2次双珠连中）")
                Text(
                    if (running) "正在按【$stageLabel】重算胜率…"
                    else if (report == null) "尚未回测"
                    else "【$stageLabel】${if (backtestStage >= 2) "轮" else "期"}回测 中${hits} 挂${misses} · 胜率 ${"%.2f".format(rate)}%（样本${report.periods}点）",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.primary
                )
                Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    WorkbenchTab.entries.forEach { t ->
                        FilterChip(selected = tab == t, onClick = { onTab(t) }, label = { Text(t.label) })
                    }
                }
            }
        }
        when (tab) {
            WorkbenchTab.DETAIL -> {
                item { PlanDetailCard(plan, report) }
                item { PlanHistoryListCard(plan, report, history, limit = historyPage.coerceAtMost(80), stage = backtestStage) }
                item {
                    if ((report?.points?.size ?: 0) > historyPage) {
                        PrimaryButton("加载更多历史", {
                            onHistoryPage((historyPage + 40).coerceAtMost(report?.points?.size ?: historyPage))
                        }, Modifier.fillMaxWidth(), ghost = true)
                    }
                }
            }
            WorkbenchTab.REVERSE -> item { ReversePlanCard(plan, history, periods, vm, stage = backtestStage) }
            WorkbenchTab.HISTORY -> {
                item { PlanHistoryListCard(plan, report, history, limit = historyPage.coerceAtLeast(40), stage = backtestStage) }
                item {
                    PrimaryButton("加载更多历史", {
                        onHistoryPage((historyPage + 50).coerceAtMost(500))
                    }, Modifier.fillMaxWidth(), ghost = true)
                }
            }
            WorkbenchTab.TREND -> item {
                TrendCard(report, periods, onPeriodsChange = onPeriodsChange, onRun = onRefresh)
            }
            WorkbenchTab.GUIDE -> item { GuideCard(plan) }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                PrimaryButton(if (isFavorite) "已收藏" else "收藏", onFavorite, Modifier.weight(1f), ghost = true)
                PrimaryButton("复制预测", {
                    clipboard.setText(AnnotatedString("${plan.planName} ${nextPred ?: "—"} ${plan.playType}"))
                }, Modifier.weight(1f), ghost = true)
                PrimaryButton(if (running) "回测中…" else "刷新回测", onRefresh, Modifier.weight(1f), enabled = !running && history.size >= 6)
            }
            Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                PrimaryButton("设为挂机来源", onSetBotSource, Modifier.weight(1f))
                PrimaryButton("相反计划", { onTab(WorkbenchTab.REVERSE) }, Modifier.weight(1f), ghost = true)
            }
            CaptionMuted("设为挂机：写入挂机「收藏计划」来源并开启滚动现算；请到挂机页确认开关。")
        }
    }
}

/**
 * 历史开奖列表。号码过多（快乐8）只显示前几个；二期/三期显示追号轮次标记。
 */
@Composable
private fun PlanHistoryListCard(
    plan: PlanDefinition,
    report: NovaPlanAnalytics.ChartReport?,
    history: List<DrawRecord>,
    limit: Int,
    stage: Int = 1
) {
    val cycle = plan.cyclePeriods.coerceAtLeast(1)
    val drawByIssue = remember(history) { history.associateBy { it.issue } }
    GlobalCard {
        Text("历史开奖 · ${when (stage) { 2 -> "二期追号"; 3 -> "三期追号"; else -> "一期" }}", fontWeight = FontWeight.Bold)
        if (report == null || report.points.isEmpty()) {
            CaptionMuted(if (history.size < 6) "历史数据不足，无法回测" else "正在生成历史结算…")
            return@GlobalCard
        }
        val rows = report.points.takeLast(limit).reversed()
        // 二期/三期：相同预测连续段视为一轮，标注 1/2、1/3
        val stepMap = mutableMapOf<String, String>()
        if (stage >= 2) {
            var step = 0
            var prevPred: String? = null
            report.points.forEach { p ->
                if (p.prediction != prevPred || step >= stage) {
                    step = 1
                    prevPred = p.prediction
                } else {
                    step++
                }
                stepMap[p.issue] = "$step/$stage"
                if (p.hit) {
                    step = 0
                    prevPred = null
                }
            }
        }
        rows.forEach { p ->
            val issueNum = p.issue.toLongOrNull()
            val rangeLabel = when {
                stage >= 2 -> {
                    val mark = stepMap[p.issue].orEmpty()
                    "${p.issue.takeLast(4)}${if (mark.isNotEmpty()) "($mark)" else ""}"
                }
                cycle > 1 && issueNum != null -> {
                    val end = issueNum + cycle - 1
                    "${p.issue.takeLast(4)}-${end.toString().takeLast(4)}"
                }
                else -> p.issue.takeLast(6)
            }
            val predShort = p.prediction.removePrefix("反:").let { raw ->
                val cleaned = raw.substringAfter(":").takeIf { ":" in raw } ?: raw
                cleaned.split("/", "、", ",").firstOrNull()?.trim().orEmpty().ifBlank { cleaned.take(8) }
            }
            // 快乐8等号码过多：最多显示 5 个
            val allNums = drawByIssue[p.issue]?.numbers.orEmpty()
            val nums = when {
                allNums.isEmpty() -> ""
                allNums.size > 6 -> allNums.take(5).joinToString(",") + "…"
                else -> allNums.joinToString(",")
            }
            val latest = history.lastOrNull()?.issue
            val resultText = when {
                latest != null && p.issue > latest -> "等待"
                p.hit -> "中"
                else -> "挂"
            }
            val resultColor = when (resultText) {
                "中" -> MaterialTheme.colorScheme.primary
                "挂" -> MaterialTheme.colorScheme.error
                else -> MaterialTheme.colorScheme.onSurfaceVariant
            }
            Row(
                Modifier.fillMaxWidth().padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "$rangeLabel ${plan.playType}($predShort)",
                    modifier = Modifier.weight(1.2f),
                    fontSize = 12.sp,
                    maxLines = 1
                )
                if (nums.isNotEmpty()) {
                    Text(
                        nums,
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.weight(0.9f),
                        maxLines = 1
                    )
                }
                Text(resultText, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = resultColor)
            }
        }
    }
}

@Composable
private fun ReversePlanCard(plan: PlanDefinition, history: List<DrawRecord>, periods: Int, vm: MainViewModel, stage: Int = 1) {
    val reverse = remember(plan.planId, history.size, periods, stage) {
        NovaPlanAnalytics.chartBacktest(plan, history, periods, 10.0, stage = stage, invert = true, outputCount = when (plan.playType) { "组合" -> vm.prefs.value.comboPredCount; "数字", "位置", "定位" -> vm.prefs.value.positionTopN; else -> null })
    }
    GlobalCard {
        Text("相反计划", fontWeight = FontWeight.Bold)
        CaptionMuted("正投计划 ${plan.planName} 的方向/对错取反后的独立统计，不修改原计划。")
        DetailRow("计划名称", reverse.plan.planName)
        DetailRow("回测期数", "${reverse.periods}期")
        DetailRow("命中率", "${"%.2f".format(reverse.hitRate * 100)}%")
        DetailRow("累计收益", "${"%.2f".format(reverse.netProfit)}")
        DetailRow("最大连中", "${reverse.maxHitStreak}期")
        DetailRow("最大连挂", "${reverse.maxMissStreak}期")
    }
}

@Composable
private fun TrendCard(report: NovaPlanAnalytics.ChartReport?, periods: Int, onPeriodsChange: (Int) -> Unit, onRun: () -> Unit) {
    GlobalCard {
        Text("计划走势", fontWeight = FontWeight.Bold)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf(100, 200, 500, 1000, 2000, 5000).forEach { n -> FilterChip(selected = periods == n, onClick = { onPeriodsChange(n) }, label = { Text("${n}期") }) }
        }
        PrimaryButton("刷新走势", onRun, Modifier.fillMaxWidth(), ghost = true)
        if (report == null || report.points.size < 2) {
            CaptionMuted("暂无走势数据")
        } else {
            val points = report.points.takeLast(150)
            val lineColor = MaterialTheme.colorScheme.primary
            Canvas(Modifier.fillMaxWidth().height(180.dp).padding(top = 8.dp)) {
                val min = points.minOf { it.cumulativeProfit }
                val max = points.maxOf { it.cumulativeProfit }
                val range = (max - min).coerceAtLeast(1.0)
                val path = Path()
                points.forEachIndexed { i, p ->
                    val x = if (points.size == 1) 0f else size.width * i / (points.size - 1)
                    val y = size.height - ((p.cumulativeProfit - min) / range * size.height).toFloat()
                    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                drawPath(path = path, color = lineColor, style = androidx.compose.ui.graphics.drawscope.Stroke(width = 4f))
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("${points.first().issue}", fontSize = 11.sp)
                Text("${points.last().issue}", fontSize = 11.sp)
            }
            DetailRow("当前趋势", report.currentTrend)
            DetailRow("累计收益", "${"%.2f".format(report.netProfit)}")
            DetailRow("最大回撤", "${"%.2f".format(report.maxDrawdown)}")
        }
    }
}

@Composable
private fun GuideCard(plan: PlanDefinition) {
    GlobalCard {
        Text("计划攻略", fontWeight = FontWeight.Bold)
        CaptionMuted("这里展示当前计划的计算口径，方便在工作台直接理解计划，而不需要跳到其它页面。")
        DetailRow("计划类型", plan.playType)
        DetailRow("计算算法", plan.algorithm)
        DetailRow("历史窗口", "最近 ${plan.window} 期")
        DetailRow("输出形式", plan.outputFormat.name)
        DetailRow("命中标准", plan.hitCriteria.name)
        DetailRow("基础概率", "${"%.1f".format(plan.baselineValue * 100)}%")
        Text("回测规则", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 8.dp))
        CaptionMuted("采用 walk-forward：预测某一期时只使用该期之前的开奖数据；每期独立结算，避免把未来开奖号码泄漏到历史预测。")
        CaptionMuted("过关斩将、正投/反投等资金模式属于图表回测层，不改变计划本身的预测算法。")
    }
}

@Composable
private fun DetailRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
        Text(label, modifier = Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
        Text(value, modifier = Modifier.weight(1.7f), fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}
