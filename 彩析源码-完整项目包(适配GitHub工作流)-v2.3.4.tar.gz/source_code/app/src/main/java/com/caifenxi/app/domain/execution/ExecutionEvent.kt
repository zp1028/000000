package com.caifenxi.app.domain.execution

/**
 * 执行生命周期事件（日志可回放一次任务全过程）。
 */
data class ExecutionEvent(
    val cmdId: String,
    /** CREATED / PUBLISHED / RECEIVED / VALIDATING / READY / EXECUTING / VERIFYING / SUCCESS / FAILED / UNKNOWN / EXPIRED / CANCELLED */
    val stage: String,
    val message: String = "",
    val at: Long = System.currentTimeMillis()
)
