package com.caifenxi.app.domain.btc.runtime

import android.content.Context
import org.json.JSONObject

/** Persistent journal for indeterminate Binance execution attempts. Never auto-clears UNKNOWN. */
class ExecutionUncertaintyStore(context: Context) {
    private val prefs = context.getSharedPreferences("btc_execution_uncertainty", Context.MODE_PRIVATE)

    @Synchronized
    fun put(clientOrderId: String, decisionId: String, symbol: String, mode: String, message: String) {
        val o = JSONObject().apply {
            put("clientOrderId", clientOrderId); put("decisionId", decisionId); put("symbol", symbol)
            put("mode", mode); put("message", message); put("createdAt", System.currentTimeMillis())
        }
        prefs.edit().putString(clientOrderId, o.toString()).apply()
    }

    @Synchronized
    fun all(): List<String> = prefs.all.keys.mapNotNull { prefs.getString(it, null) }

    @Synchronized
    fun resolve(clientOrderId: String) { prefs.edit().remove(clientOrderId).apply() }
}
