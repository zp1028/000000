package com.caifenxi.app.domain.engine

import com.caifenxi.app.data.db.dao.BetDao
import com.caifenxi.app.data.db.entity.BetEntity
import com.caifenxi.app.data.db.entity.BotConfigEntity
import com.caifenxi.app.data.db.entity.WalletEntity
import com.caifenxi.app.domain.model.BetCategory
import com.caifenxi.app.domain.model.BetOdds
import com.caifenxi.app.domain.model.BetSourceType
import com.caifenxi.app.domain.model.BetStats
import com.caifenxi.app.domain.model.CatBetStats
import com.caifenxi.app.domain.model.DrawRecord
import com.caifenxi.app.domain.model.ModelConsensus
import com.caifenxi.app.domain.model.PlanPredictionRecord
import com.caifenxi.app.domain.model.PksPositions
import com.caifenxi.app.domain.model.PredictionSnapshot
import com.caifenxi.app.domain.model.ProfitPoint

/**
 * 模拟下注引擎:下单 + 每期自动结算 + 倍投 + 统计。
 *
 * 倍投规则(各分类独立追踪):
 * - 上一注「中了」→ 本期金额 = min(上期金额 × winMult, 基数 × maxMult)
 * - 上一注「未中」→ 本期金额 = min(上期金额 × lossMult, 基数 × maxMult)
 * - 对/错倍投只持续设置的期数;超过期数后恢复基数。
 * - 一旦结果方向改变,重新按新方向开始计数。
 */
class BetEngine(private val dao: BetDao) {

    companion object {
        const val DEFAULT_INITIAL = 10000.0
    }

    // ---- 内存中追踪各分类上一注结果(lotteryKey -> catName -> lastHit?)----
    private val lastHitMap = mutableMapOf<String, MutableMap<String, Boolean?>>()

    /**
     * 根据挂机策略 + 当前预测,为指定目标期自动下单。
     * @return 本次实际下的注数量
     */
    suspend fun placeAutoBets(
        lotteryKey: String,
        targetIssue: String,
        prediction: PredictionSnapshot?,
        planPredictions: List<PlanPredictionRecord>,
        consensus: List<ModelConsensus>
    ): Int {
        val config = dao.getBotConfig(lotteryKey) ?: return 0
        if (!config.enabled) return 0
        if (config.amount <= 0) return 0

        val categories = config.categories.split(",").mapNotNull { BetCategory.fromId(it.trim()) }
        if (categories.isEmpty()) return 0

        val picks = resolvePicks(config, prediction, planPredictions, consensus)
        if (picks.isEmpty()) return 0

        // 保证账户已初始化
        dao.getWallet(lotteryKey) ?: ensureWallet(lotteryKey, DEFAULT_INITIAL)
        val balance = dao.getWallet(lotteryKey)?.balance ?: 0.0

        // 初始资金(用于倍数上限计算)
        val initial = dao.getWallet(lotteryKey)?.initialBalance ?: DEFAULT_INITIAL

        val catStreaks = lastHitMap.getOrPut(lotteryKey) { mutableMapOf() }
        var placed = 0
        var remaining = balance

        for (cat in categories) {
            val value = picks[cat] ?: continue

            // 计算本期金额:根据上一期结果 + 已连续倍投期数决定是否继续倍投
            val lastHit = catStreaks[cat.id]
            val prevAmount = getLastAmount(lotteryKey, cat.id)
            val streak = if (lastHit == null) 0 else getRecentStreak(lotteryKey, cat.id, lastHit)
            val currentAmount = calcAmount(
                baseAmount = config.amount,
                lastAmount = prevAmount,
                lastHit = lastHit,
                streak = streak,
                winMult = config.winMult,
                lossMult = config.lossMult,
                winMultPeriods = config.winMultPeriods,
                lossMultPeriods = config.lossMultPeriods,
                maxMult = config.maxMult,
                maxCap = initial * config.maxMult
            ).coerceAtMost(remaining.coerceAtLeast(0.0))

            if (currentAmount <= 0 || remaining <= 0) break

            val odds = BetOdds.of(cat)
            val bet = BetEntity(
                lotteryKey = lotteryKey,
                issue = targetIssue,
                sourceType = config.sourceType,
                sourceId = config.sourceId,
                category = cat.id,
                betValue = value,
                amount = currentAmount,
                odds = odds,
                status = "待开",
                profit = 0.0
            )
            dao.insertBet(bet)
            remaining -= currentAmount
            placed++
        }
        return placed
    }

    /**
     * 计算本期下注金额。
     * streak 表示上一期结果方向已经连续出现了多少次。
     * 例如“对了倍投3期”: 第1/2/3个连续命中后的下一注按倍投计算,第4个连续命中后恢复基数。
     */
    private fun calcAmount(
        baseAmount: Double,
        lastAmount: Double,
        lastHit: Boolean?,
        streak: Int,
        winMult: Double,
        lossMult: Double,
        winMultPeriods: Int,
        lossMultPeriods: Int,
        maxMult: Int,
        maxCap: Double
    ): Double {
        if (lastHit == null || streak <= 0) return baseAmount
        val periods = if (lastHit) winMultPeriods else lossMultPeriods
        val mult = if (lastHit) winMult else lossMult
        if (mult <= 1.0 || streak > periods) return baseAmount
        val next = lastAmount * mult
        return next.coerceAtMost(maxCap).coerceAtLeast(baseAmount)
    }

    /** 获取某分类最近一注的金额(用于计算倍投),查 DB 历史记录 */
    private suspend fun getLastAmount(lotteryKey: String, catName: String): Double {
        val bets = dao.getBets(lotteryKey)
        return bets.filter { it.category == catName && it.status != "待开" }
            .maxByOrNull { it.settledAt ?: 0 }?.amount ?: 0.0
    }

    /**
     * 获取最近连续相同结果的期数。
     * 只统计已结算记录,避免把未开奖订单算进倍投周期。
     */
    private suspend fun getRecentStreak(lotteryKey: String, catName: String, targetHit: Boolean): Int {
        val bets = dao.getBets(lotteryKey)
            .filter { it.category == catName && it.status != "待开" }
            .sortedByDescending { it.settledAt ?: it.createdAt }
        var streak = 0
        for (bet in bets) {
            val hit = bet.status == "中"
            if (hit != targetHit) break
            streak++
        }
        return streak
    }

    /**
     * 用一期开奖结果结算所有待开订单,并更新各分类连对/连错追踪。
     */
    suspend fun settleWithDraw(lotteryKey: String, draw: DrawRecord) {
        val pending = dao.getPendingBefore(lotteryKey, draw.issue)
            .plus(dao.getPendingBets(lotteryKey, draw.issue))
            .distinctBy { it.id }
        if (pending.isEmpty()) return

        val wallet = dao.getWallet(lotteryKey) ?: WalletEntity(lotteryKey = lotteryKey)
        var balance = wallet.balance
        var totalProfit = wallet.totalProfit
        var totalBet = wallet.totalBet
        var win = wallet.winCount
        var lose = wallet.loseCount

        val catStreaks = lastHitMap.getOrPut(lotteryKey) { mutableMapOf() }

        val updated = pending.map { bet ->
            val hit = judge(bet.category, bet.betValue, draw)
            val profit = if (hit) bet.amount * (bet.odds - 1.0) else -bet.amount
            balance += bet.amount + profit
            totalProfit += profit
            totalBet += bet.amount
            if (hit) win++ else lose++

            // 更新该分类的连对/连错状态
            catStreaks[bet.category] = hit

            bet.copy(
                status = if (hit) "中" else "未中",
                profit = profit,
                settledAt = System.currentTimeMillis()
            )
        }
        dao.updateBets(updated)
        dao.upsertWallet(
            wallet.copy(
                balance = balance,
                totalProfit = totalProfit,
                totalBet = totalBet,
                winCount = win,
                loseCount = lose,
                updatedAt = System.currentTimeMillis()
            )
        )
    }

    /**
     * 从 DB 历史计算收益统计 + 对错统计。
     */
    suspend fun getBetStats(lotteryKey: String): BetStats {
        val wallet = dao.getWallet(lotteryKey)
        val bets = dao.getBets(lotteryKey)

        val initial = wallet?.initialBalance ?: DEFAULT_INITIAL
        val balance = wallet?.balance ?: initial
        val totalProfit = wallet?.totalProfit ?: 0.0
        val totalBet = wallet?.totalBet ?: 0.0
        val winCount = wallet?.winCount ?: 0
        val loseCount = wallet?.loseCount ?: 0

        val settled = bets.filter { it.status != "待开" }
        val totalSettled = settled.size

        // 本期(最新期)投入与盈亏
        val latestIssue = bets.filter { it.status != "待开" }
            .maxOfOrNull { it.issue } ?: ""
        val currentBets = bets.filter { it.issue == latestIssue }
        val currentBetAmount = currentBets.sumOf { it.amount }
        val currentProfit = currentBets.sumOf { it.profit }

        // 按分类统计对错(从历史记录重算,不依赖内存 streak)
        val byCategory = BetCategory.entries.associate { cat ->
            cat.id to buildCatStats(cat.id, bets)
        }

        // 收益曲线:按结算时间升序排列已结算注,逐期累计收益
        val settledChron = settled.sortedBy { it.settledAt ?: Long.MAX_VALUE }
        var running = 0.0
        var peak = 0.0
        var maxDD = 0.0
        var maxDDPct = 0.0
        val curve = mutableListOf<ProfitPoint>()
        settledChron.forEachIndexed { idx, b ->
            running += b.profit
            if (running > peak) peak = running
            val dd = peak - running
            val ddPct = if (peak > 0) dd / peak else 0.0
            if (dd > maxDD) maxDD = dd
            if (ddPct > maxDDPct) maxDDPct = ddPct
            curve.add(
                ProfitPoint(
                    issueIndex = idx,
                    issue = b.issue,
                    cumulativeProfit = running,
                    hit = b.status == "中",
                    drawdown = dd,
                    drawdownPct = ddPct
                )
            )
        }

        // 最长连对/连错(全局,按结算时序)
        var maxHitStreak = 0
        var maxMissStreak = 0
        var curHit = 0
        var curMiss = 0
        settledChron.forEach { b ->
            if (b.status == "中") {
                curHit++; curMiss = 0
                if (curHit > maxHitStreak) maxHitStreak = curHit
            } else {
                curMiss++; curHit = 0
                if (curMiss > maxMissStreak) maxMissStreak = curMiss
            }
        }

        return BetStats(
            initialBalance = initial,
            balance = balance,
            totalProfit = totalProfit,
            totalBet = totalBet,
            profitRate = if (initial > 0) totalProfit / initial else 0.0,
            totalSettled = totalSettled,
            winCount = winCount,
            loseCount = loseCount,
            winRate = if (totalSettled > 0) winCount.toDouble() / totalSettled else 0.0,
            currentBetAmount = currentBetAmount,
            currentProfit = currentProfit,
            byCategory = byCategory,
            profitCurve = curve,
            maxDrawdown = maxDD,
            maxDrawdownPct = maxDDPct,
            peakProfit = peak,
            maxHitStreak = maxHitStreak,
            maxMissStreak = maxMissStreak
        )
    }

    private fun buildCatStats(catName: String, allBets: List<BetEntity>): CatBetStats {
        val catBets = allBets.filter { it.category == catName && it.status != "待开" }
            .sortedBy { it.settledAt ?: Long.MAX_VALUE }

        val hit = catBets.count { it.status == "中" }
        val miss = catBets.size - hit
        val settled = catBets.size

        // 计算连对/连错
        var recent = 0
        var curStreak = 0
        var maxHit = 0
        var maxMiss = 0
        catBets.reversed().forEach { b ->
            val isHit = b.status == "中"
            if (curStreak >= 0) {
                if (isHit) { curStreak++; maxHit = maxOf(maxHit, curStreak) }
                else { curStreak = -1; maxMiss = maxOf(maxMiss, 1) }
            } else {
                if (!isHit) { curStreak--; maxMiss = maxOf(maxMiss, -curStreak) }
                else { curStreak = 1; maxHit = maxOf(maxHit, 1) }
            }
        }
        // recentStreak: 正=连对,负=连错
        recent = curStreak

        return CatBetStats(
            catName = BetCategory.fromId(catName)?.label ?: catName,
            settled = settled,
            hit = hit,
            miss = miss,
            winRate = if (settled > 0) hit.toDouble() / settled else 0.0,
            recentStreak = recent,
            maxHitStreak = maxHit,
            maxMissStreak = maxMiss
        )
    }

    /** 判定一注是否命中 */
    private fun judge(category: String, betValue: String, draw: DrawRecord): Boolean {
        return when (BetCategory.fromId(category)) {
            BetCategory.DX -> draw.dx == betValue
            BetCategory.DS -> draw.ds == betValue
            BetCategory.COMBO -> draw.combo == betValue
            BetCategory.NUMBER -> {
                val parts = betValue.split("=")
                if (parts.size != 2) return false
                val posIdx = PksPositions.NAMES.indexOf(parts[0])
                if (posIdx < 0) return false
                val num = parts[1].toIntOrNull() ?: return false
                draw.numberAt(posIdx) == num
            }
            null -> false
        }
    }

    suspend fun ensureWallet(lotteryKey: String, initialBalance: Double): WalletEntity {
        val existing = dao.getWallet(lotteryKey)
        if (existing != null) return existing
        val w = WalletEntity(lotteryKey = lotteryKey, initialBalance = initialBalance, balance = initialBalance)
        dao.upsertWallet(w)
        return w
    }

    // ---- 来源解析 ----

    private fun resolvePicks(
        config: BotConfigEntity,
        prediction: PredictionSnapshot?,
        planPredictions: List<PlanPredictionRecord>,
        consensus: List<ModelConsensus>
    ): Map<BetCategory, String> {
        return when (BetSourceType.fromId(config.sourceType)) {
            BetSourceType.ALGO -> resolveAlgo(config.numberPosition, prediction)
            BetSourceType.PLAN -> resolvePlan(config.sourceId, planPredictions)
            BetSourceType.CONSENSUS -> resolveConsensus(consensus)
        }
    }

    private fun resolveAlgo(positionIndex: Int, prediction: PredictionSnapshot?): Map<BetCategory, String> {
        if (prediction == null) return emptyMap()
        val map = mutableMapOf<BetCategory, String>()
        prediction.dx?.direction?.let { map[BetCategory.DX] = it }
        prediction.ds?.direction?.let { map[BetCategory.DS] = it }
        prediction.combo?.direction?.let { map[BetCategory.COMBO] = it }
        prediction.positions.getOrNull(positionIndex)?.topNumbers?.firstOrNull()?.number?.let {
            map[BetCategory.NUMBER] = "${PksPositions.nameAt(positionIndex)}=$it"
        }
        return map
    }

    private fun resolvePlan(planId: String, planPredictions: List<PlanPredictionRecord>): Map<BetCategory, String> {
        val rec = planPredictions.lastOrNull { it.planId == planId && !it.settled }
            ?: planPredictions.lastOrNull { it.planId == planId }
            ?: return emptyMap()
        val map = mutableMapOf<BetCategory, String>()
        val out = rec.output.trim()
        when {
            out.isEmpty() -> {}
            out in listOf("大单", "大双", "小单", "小双") -> map[BetCategory.COMBO] = out
            out in listOf("大", "小") -> map[BetCategory.DX] = out
            out in listOf("单", "双") -> map[BetCategory.DS] = out
            else -> {
                if (out in listOf("大", "小")) map[BetCategory.DX] = out
                else if (out in listOf("单", "双")) map[BetCategory.DS] = out
            }
        }
        return map
    }

    private fun resolveConsensus(consensus: List<ModelConsensus>): Map<BetCategory, String> {
        val map = mutableMapOf<BetCategory, String>()
        consensus.forEach { c ->
            when (c.category) {
                "大小" -> map[BetCategory.DX] = c.leadingDirection
                "单双" -> map[BetCategory.DS] = c.leadingDirection
                "组合" -> map[BetCategory.COMBO] = c.leadingDirection
            }
        }
        return map
    }
}
