package com.caifenxi.app.domain.plan

import com.caifenxi.app.domain.model.LotteryType
import com.caifenxi.app.domain.model.PlanDefinition

/** 极速快三：和值、三军/鱼虾蟹、特殊形态，以及三个位次的独立分析计划。 */
object NovaK3PlanPool {
    val ALL: List<PlanDefinition> get() = PlanPoolV2.all(LotteryType.K3)
    val CANDIDATES: List<PlanDefinition> get() = PlanPoolV2.candidates(LotteryType.K3)
    fun find(planId: String): PlanDefinition? = PlanPoolV2.find(planId)
}
