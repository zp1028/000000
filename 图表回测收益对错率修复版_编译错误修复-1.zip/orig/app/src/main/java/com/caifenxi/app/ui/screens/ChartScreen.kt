package com.caifenxi.app.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.caifenxi.app.domain.model.*
import com.caifenxi.app.domain.plan.NovaPlanAnalytics
import com.caifenxi.app.domain.plan.NovaPlanPool
import com.caifenxi.app.domain.plan.PlanPool
import com.caifenxi.app.ui.MainViewModel
import com.caifenxi.app.ui.components.CaptionMuted
import com.caifenxi.app.ui.components.GlobalCard
import com.caifenxi.app.ui.components.PrimaryButton
import com.caifenxi.app.ui.theme.CaiTokens
import kotlin.math.roundToInt

@Composable
fun ChartScreen(vm: MainViewModel) {
    var chartPeriods by remember { mutableStateOf(500) }
    var chartStakeText by remember { mutableStateOf("10") }
    var chartSelectedIds by remember { mutableStateOf<List<String>>(emptyList()) }
    var chartSource by remember { mutableStateOf("新计划池") }
    var chartMode by remember { mutableStateOf("累计收益") }
    var chartCycle by remember { mutableStateOf(1) }
    var chartDetail by remember { mutableStateOf<NovaPlanAnalytics.ChartPoint?>(null) }
    var chartPlansExpanded by remember { mutableStateOf(true) }
    var chartResetToken by remember { mutableIntStateOf(0) }
    val history = vm.history.value
    val custom = vm.customPlans.value.map { it.toDefinition() }.filter { it.planId.startsWith("NOVA-CUSTOM-") }
    val novaPlans = (NovaPlanPool.ALL + custom).distinctBy { it.planId }
    val sourcePlans = when (chartSource) {
        "原计划池" -> PlanPool.ALL
        "自定义计划" -> custom
        "经验学习模型" -> listOf(PlanDefinition(
            planId = "MODEL-EXPERIENCE", planName = "经验学习模型", category = "模型",
            algorithm = "EXPERIENCE_MODEL", window = 50, playType = "大小"
        ))
        "形态匹配模型" -> listOf(PlanDefinition(
            planId = "MODEL-PATTERN", planName = "形态匹配模型", category = "模型",
            algorithm = "PATTERN_MODEL", window = 50, playType = "大小"
        ))
        else -> novaPlans
    }.distinctBy { it.planId }
    val reports = vm.planVM.novaChartReports.value
    val legacyConsensus = vm.planVM.consensusRecords.value
    val novaConsensus = vm.planVM.novaConsensusRecords.value
    val isConsensusSource = chartSource == "原计划共识" || chartSource == "新计划共识"
    val consensusPool = if (chartSource == "新计划共识") "NOVA" else "LEGACY"
    val consensusRecords = if (chartSource == "新计划共识") novaConsensus else legacyConsensus
    val consensusPlan = remember(consensusRecords, consensusPool, chartPeriods, chartCycle, chartStakeText) {
        NovaPlanAnalytics.consensusChartBacktest(
            consensusRecords, consensusPool, chartPeriods, chartStakeText.toDoubleOrNull() ?: 10.0, chartCycle
        ).plan
    }

    if (chartDetail != null) {
        val pt = chartDetail!!
        AlertDialog(
            onDismissRequest = { chartDetail = null },
            confirmButton = { TextButton(onClick = { chartDetail = null }) { Text("关闭") } },
            title = { Text("回测节点详情") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("期号：${pt.issue}")
                Text("预测：${pt.prediction}")
                Text("结果：${if (pt.hit) "对" else "错"}")
                Text("单期盈亏：${chartFmtMoney(pt.periodProfit)}")
                Text("累计盈亏：${chartFmtMoney(pt.cumulativeProfit)}")
                Text("当时命中率：${"%.2f".format(pt.hitRate * 100)}%")
                Text("回撤：${chartFmtMoney(pt.drawdown)}")
            }}
        )
    }

    LazyColumn(Modifier.fillMaxSize().padding(horizontal = CaiTokens.ScreenHPadding, vertical = CaiTokens.S12), verticalArrangement = Arrangement.spacedBy(CaiTokens.S8), contentPadding = PaddingValues(bottom = CaiTokens.ScreenBottom)) {
        item {
            Text("📊 图表回测", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            CaptionMuted("独立图表分页：原计划池、新计划池或自定义计划均可选择具体计划回测与对比。")
        }
        item {
            GlobalCard {
                Text("回测设置", fontWeight = FontWeight.Bold)
                ChartFilterLine("回测来源", listOf("新计划池", "原计划池", "自定义计划", "经验学习模型", "形态匹配模型", "原计划共识", "新计划共识"), chartSource) { chartSource = it; chartSelectedIds = emptyList() }
                ChartFilterLine("图表", listOf("累计收益", "单期盈亏", "命中率", "涨跌趋势", "回撤"), chartMode) { chartMode = it }
                ChartFilterLine("回测期数", listOf(100,200,500,1000,2000,5000).map { "${it}期" }, "${chartPeriods}期") { chartPeriods = it.removeSuffix("期").toInt() }
                ChartFilterLine("预测周期", listOf("一期", "两期", "三期"), "${if (chartCycle == 1) "一期" else if (chartCycle == 2) "两期" else "三期"}") { chartCycle = when (it) { "两期" -> 2; "三期" -> 3; else -> 1 } }
                OutlinedTextField(value=chartStakeText, onValueChange={chartStakeText=it.filter{c->c.isDigit()||c=='.'}.take(10)}, label={Text("回测单注金额")}, singleLine=true, modifier=Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth().clickable { chartPlansExpanded = !chartPlansExpanded }, verticalAlignment = Alignment.CenterVertically) {
                    Text("选择计划 / 共识（最多5个）", fontWeight=FontWeight.SemiBold, modifier=Modifier.weight(1f))
                    Text(if (chartPlansExpanded) "收起 ▲" else "展开 ▼", fontSize=12.sp)
                }
                if (chartPlansExpanded) {
                    if (isConsensusSource) {
                        val available = if (consensusRecords.isEmpty()) emptyList() else listOf(consensusPlan)
                        if (available.isEmpty()) CaptionMuted("暂无${if (chartSource == "新计划共识") "新计划" else "原计划"}共识历史记录，请先完成共识预测并结算")
                        available.forEach { p ->
                            val checked = p.planId in chartSelectedIds
                            Row(Modifier.fillMaxWidth().clickable { chartSelectedIds = if (checked) chartSelectedIds - p.planId else listOf(p.planId) }, verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(checked = checked, onCheckedChange = { on -> chartSelectedIds = if (on) listOf(p.planId) else emptyList() })
                                Column(Modifier.weight(1f)) { Text(p.planName, fontSize = 13.sp, fontWeight = if (checked) FontWeight.Bold else FontWeight.Normal); CaptionMuted("历史共识 · 已结算 ${consensusRecords.count { it.result != "待开" }} 条") }
                            }
                        }
                    } else {
                        if (sourcePlans.isEmpty()) CaptionMuted("该来源暂无可回测计划")
                        sourcePlans.forEach { p ->
                            val checked = p.planId in chartSelectedIds
                            Row(
                                Modifier.fillMaxWidth().clickable {
                                    chartSelectedIds = if (checked) chartSelectedIds - p.planId
                                    else (chartSelectedIds + p.planId).distinct().take(5)
                                },
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = checked,
                                    onCheckedChange = { on ->
                                        chartSelectedIds = if (on) (chartSelectedIds + p.planId).distinct().take(5)
                                        else chartSelectedIds - p.planId
                                    }
                                )
                                Column(Modifier.weight(1f)) {
                                    Text(p.planName, fontSize = 13.sp, fontWeight = if (checked) FontWeight.Bold else FontWeight.Normal)
                                    CaptionMuted("${p.playType} · ${p.algorithm} · ${p.window}期")
                                }
                            }
                        }
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    val canRun = if (isConsensusSource) consensusRecords.any { it.result != "待开" } else history.size >= 6
                    PrimaryButton(if(vm.planVM.novaChartRunning.value)"正在回测…" else "开始回测 / 更新图表",{
                        val stake = chartStakeText.toDoubleOrNull() ?: 10.0
                        if (isConsensusSource) {
                            if (chartSelectedIds.isNotEmpty()) vm.planVM.novaChartReports.value = listOf(NovaPlanAnalytics.consensusChartBacktest(consensusRecords, consensusPool, chartPeriods, stake, chartCycle))
                        } else {
                            val selected=sourcePlans.filter{it.planId in chartSelectedIds}.ifEmpty{sourcePlans.take(1)}
                            vm.planVM.runNovaChartBacktest(history,selected,chartPeriods,stake,chartCycle)
                        }
                        chartResetToken++
                    },Modifier.weight(1f),enabled=!vm.planVM.novaChartRunning.value&&canRun)
                    OutlinedButton(onClick={ chartResetToken++; chartDetail=null; chartSelectedIds=emptyList(); vm.planVM.novaChartReports.value=emptyList() }) { Text("重置图表") }
                }
            }
        }
        if(reports.isEmpty()){ item{GlobalCard{CaptionMuted("请选择计划并开始回测")}} } else {
            item{GlobalCard{Text(if(reports.size==1)"回测曲线" else "计划对比曲线",fontWeight=FontWeight.Bold);CaptionMuted("与挂机曲线保持相同的双指缩放、放大后拖动和复位交互；点击曲线可查看节点详情。") ;ChartCurve(reports,chartMode,{chartDetail=it},chartResetToken)}}
            item{GlobalCard{Text("回测统计",fontWeight=FontWeight.Bold);reports.forEach{r->Text(r.plan.planName,fontWeight=FontWeight.SemiBold,modifier=Modifier.padding(top=6.dp));Text("${r.periods}期 · 对 ${r.hits} / 错 ${r.misses} · 命中率 ${(r.hitRate*100).roundToInt()}% · 单注 ${chartFmtMoney(r.stake)}");Text("总投入 ${chartFmtMoney(r.totalStake)} · 净收益 ${chartFmtMoney(r.netProfit)} · 最大回撤 ${chartFmtMoney(r.maxDrawdown)}");CaptionMuted("最高点 ${chartFmtMoney(r.maxPeak)} · 最低点 ${chartFmtMoney(r.minTrough)} · 最大连对 ${r.maxHitStreak} · 最大连错 ${r.maxMissStreak}")}}}
            item{GlobalCard{Text("涨跌趋势分析",fontWeight=FontWeight.Bold);reports.forEach{r->Text("${r.plan.planName}：${r.currentTrend}",fontWeight=FontWeight.SemiBold);CaptionMuted("最高点 ${chartFmtMoney(r.maxPeak)} · 最低点 ${chartFmtMoney(r.minTrough)} · 当前 ${chartFmtMoney(r.points.lastOrNull()?.cumulativeProfit?:0.0)}");CaptionMuted("距最高点 ${chartFmtMoney(r.distanceFromPeak)} · 从最低点反弹 ${chartFmtMoney(r.reboundFromTrough)} · 当前位置 ${"%.1f".format(r.positionPercent)}%")}}}
            item{GlobalCard{Text("计划对比分析",fontWeight=FontWeight.Bold);if(reports.size<2)CaptionMuted("选择至少2个计划后显示横向对比")else{reports.sortedByDescending{it.netProfit}.forEachIndexed{idx,r->Text("${idx+1}. ${r.plan.planName}",fontWeight=FontWeight.SemiBold);Text("命中率 ${(r.hitRate*100).roundToInt()}% · 净收益 ${chartFmtMoney(r.netProfit)} · 最大回撤 ${chartFmtMoney(r.maxDrawdown)} · 最大连错 ${r.maxMissStreak}",fontSize=12.sp)};CaptionMuted("收益最佳：${reports.maxByOrNull{it.netProfit}?.plan?.planName?:"-"} · 命中率最高：${reports.maxByOrNull{it.hitRate}?.plan?.planName?:"-"} · 回撤最小：${reports.minByOrNull{it.maxDrawdown}?.plan?.planName?:"-"}")}}}
            item{GlobalCard{Text("图表分析报告",fontWeight=FontWeight.Bold);reports.forEach{r->val cur=r.points.lastOrNull()?.cumulativeProfit?:0.0;val dir=if(r.netProfit>0)"累计收益为正"else if(r.netProfit<0)"累计收益为负"else"累计收益持平";Text(r.plan.planName,fontWeight=FontWeight.SemiBold,modifier=Modifier.padding(top=6.dp));Text("整体表现：$dir；回测 ${r.periods} 个有效单元，命中率 ${(r.hitRate*100).roundToInt()}%，净收益 ${chartFmtMoney(r.netProfit)}。");Text("收益分析：总投入 ${chartFmtMoney(r.totalStake)}，最高点 ${chartFmtMoney(r.maxPeak)}，最低点 ${chartFmtMoney(r.minTrough)}。");Text("趋势分析：${r.currentTrend}；当前 ${chartFmtMoney(cur)}，距最高点 ${chartFmtMoney(r.distanceFromPeak)}，从最低点反弹 ${chartFmtMoney(r.reboundFromTrough)}。");Text("风险分析：最大回撤 ${chartFmtMoney(r.maxDrawdown)}，最大连对 ${r.maxHitStreak}，最大连错 ${r.maxMissStreak}。")}}}
            item {
                GlobalCard { Text("完整回测明细", fontWeight = FontWeight.Bold); CaptionMuted("明细采用虚拟列表，仅创建当前屏幕附近节点，5000期×5计划也不会一次性创建全部UI。") }
            }
            reports.forEach { r ->
                item { Text(r.plan.planName, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 6.dp)) }
                items(r.points.asReversed(), key = { "${r.plan.planId}-${it.issue}-${it.cumulativeProfit}" }) { pt ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("${pt.issue} · ${pt.prediction} · ${if (pt.hit) "对" else "错"}", fontSize = 11.sp, modifier = Modifier.weight(1f))
                        Text(chartFmtMoney(pt.periodProfit), fontSize = 11.sp, modifier = Modifier.width(70.dp))
                        Text(chartFmtMoney(pt.cumulativeProfit), fontSize = 11.sp, modifier = Modifier.width(80.dp))
                    }
                }
            }
        }
    }
}
