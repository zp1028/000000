package com.caifenxi.app.data.db.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.caifenxi.app.data.db.entity.PolymarketSnapshotEntity

@Dao
interface PolymarketSnapshotDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(snapshot: PolymarketSnapshotEntity): Long

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(snapshots: List<PolymarketSnapshotEntity>): List<Long>

    @Query("SELECT * FROM polymarket_snapshots WHERE marketId = :marketId ORDER BY capturedAtMs ASC")
    suspend fun history(marketId: String): List<PolymarketSnapshotEntity>

    @Query("SELECT * FROM polymarket_snapshots WHERE capturedAtMs BETWEEN :fromMs AND :toMs ORDER BY capturedAtMs ASC")
    suspend fun range(fromMs: Long, toMs: Long): List<PolymarketSnapshotEntity>

    @Query("SELECT * FROM polymarket_snapshots WHERE strategyId = :strategyId ORDER BY capturedAtMs ASC")
    suspend fun strategyHistory(strategyId: String): List<PolymarketSnapshotEntity>

    @Query("UPDATE polymarket_snapshots SET resolvedOutcome = :outcome WHERE marketId = :marketId")
    suspend fun settleMarket(marketId: String, outcome: String): Int

    @Query("SELECT COUNT(*) FROM polymarket_snapshots")
    suspend fun count(): Long

    @Query("DELETE FROM polymarket_snapshots WHERE capturedAtMs < :cutoffMs")
    suspend fun pruneBefore(cutoffMs: Long): Int
}
