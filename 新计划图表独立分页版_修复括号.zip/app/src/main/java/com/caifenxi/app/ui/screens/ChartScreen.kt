package com.caifenxi.app.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.caifenxi.app.domain.model.*
import com.caifenxi.app.domain.plan.NovaPlanAnalytics
import com.caifenxi.app.domain.plan.NovaPlanPool
import com.caifenxi.app.domain.plan.PlanPool
import com.caifenxi.app.ui.MainViewModel
import com.caifenxi.app.ui.components.CaptionMuted
import com.caifenxi.app.ui.components.GlobalCard
import com.caifenxi.app.ui.components.PrimaryButton
import com.caifenxi.app.ui.theme.CaiTokens
import kotlin.math.roundToInt

@Composable
fun ChartScreen(vm: MainViewModel) {
    var chartPeriods by remember { mutableStateOf(500) }
    var chartStakeText by remember { mutableStateOf("10") }
    var chartSelectedIds by remember { mutableStateOf<List<String>>(emptyList()) }
    var chartSource by remember { mutableStateOf("新计划池") }
    var chartMode by remember { mutableStateOf("累计收益") }
    var chartDetail by remember { mutableStateOf<NovaPlanAnalytics.ChartPoint?>(null) }
    val history = vm.history.value
    val custom = vm.customPlans.value.map { it.toDefinition() }.filter { it.planId.startsWith("NOVA-CUSTOM-") }
    val novaPlans = (NovaPlanPool.ALL + custom).distinctBy { it.planId }
    val sourcePlans = when (chartSource) {
        "原计划池" -> PlanPool.ALL
        "自定义计划" -> custom
        else -> novaPlans
    }.distinctBy { it.planId }
    val reports = vm.planVM.novaChartReports.value

    if (chartDetail != null) {
        val pt = chartDetail!!
        AlertDialog(
            onDismissRequest = { chartDetail = null },
            confirmButton = { TextButton(onClick = { chartDetail = null }) { Text("关闭") } },
            title = { Text("回测节点详情") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("期号：${pt.issue}")
                Text("预测：${pt.prediction}")
                Text("结果：${if (pt.hit) "对" else "错"}")
                Text("单期盈亏：${fmtMoney(pt.periodProfit)}")
                Text("累计盈亏：${fmtMoney(pt.cumulativeProfit)}")
                Text("当时命中率：${"%.2f".format(pt.hitRate * 100)}%")
                Text("回撤：${fmtMoney(pt.drawdown)}")
            }}
        )
    }

    LazyColumn(Modifier.fillMaxSize().padding(horizontal = CaiTokens.ScreenHPadding, vertical = CaiTokens.S12), verticalArrangement = Arrangement.spacedBy(CaiTokens.S8), contentPadding = PaddingValues(bottom = CaiTokens.ScreenBottom)) {
        item {
            Text("📊 图表回测", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            CaptionMuted("独立图表分页：原计划池、新计划池或自定义计划均可选择具体计划回测与对比。")
        }
        item {
            GlobalCard {
                Text("回测设置", fontWeight = FontWeight.Bold)
                FilterLineChart("计划来源", listOf("新计划池", "原计划池", "自定义计划"), chartSource) { chartSource = it; chartSelectedIds = emptyList() }
                FilterLineChart("图表", listOf("累计收益", "单期盈亏", "命中率", "涨跌趋势", "回撤"), chartMode) { chartMode = it }
                FilterLineChart("回测", listOf(100,200,500,1000,2000,5000).map { "${it}期" }, "${chartPeriods}期") { chartPeriods = it.removeSuffix("期").toInt() }
                OutlinedTextField(value=chartStakeText, onValueChange={chartStakeText=it.filter{c->c.isDigit()||c=='.'}.take(10)}, label={Text("回测单注金额")}, singleLine=true, modifier=Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                Text("选择具体计划（最多5个，可多选对比）", fontWeight=FontWeight.SemiBold)
                if (sourcePlans.isEmpty()) CaptionMuted("该来源暂无可回测计划")
                sourcePlans.forEach { p ->
                    val checked=p.planId in chartSelectedIds
                    Row(Modifier.fillMaxWidth().clickable{chartSelectedIds=if(checked) chartSelectedIds-p.planId else (chartSelectedIds+p.planId).distinct().take(5)}, verticalAlignment=Alignment.CenterVertically){
                        Checkbox(checked=checked,onCheckedChange={on->chartSelectedIds=if(on)(chartSelectedIds+p.planId).distinct().take(5) else chartSelectedIds-p.planId})
                        Column(Modifier.weight(1f)){Text(p.planName,fontSize=13.sp,fontWeight=if(checked)FontWeight.Bold else FontWeight.Normal);CaptionMuted("${p.playType} · ${p.algorithm} · ${p.window}期")}
                    }
                }
                val selected=sourcePlans.filter{it.planId in chartSelectedIds}.ifEmpty{sourcePlans.take(1)}
                PrimaryButton(if(vm.planVM.novaChartRunning.value)"正在回测…" else "开始回测 / 更新图表",{vm.planVM.runNovaChartBacktest(history,selected,chartPeriods,chartStakeText.toDoubleOrNull()?:10.0)},Modifier.fillMaxWidth(),enabled=!vm.planVM.novaChartRunning.value&&history.size>=6)
            }
        }
        if(reports.isEmpty()){ item{GlobalCard{CaptionMuted("请选择计划并开始回测")}} } else {
            item{GlobalCard{Text(if(reports.size==1)"回测曲线" else "计划对比曲线",fontWeight=FontWeight.Bold);CaptionMuted("与挂机曲线保持相同的双指缩放、放大后拖动和复位交互；点击曲线可查看节点详情。") ;NovaBacktestCurveChart(reports,chartMode){chartDetail=it}}}
            item{GlobalCard{Text("回测统计",fontWeight=FontWeight.Bold);reports.forEach{r->Text(r.plan.planName,fontWeight=FontWeight.SemiBold,modifier=Modifier.padding(top=6.dp));Text("${r.periods}期 · 对 ${r.hits} / 错 ${r.misses} · 命中率 ${(r.hitRate*100).roundToInt()}% · 单注 ${fmtMoney(r.stake)}");Text("总投入 ${fmtMoney(r.totalStake)} · 净收益 ${fmtMoney(r.netProfit)} · 最大回撤 ${fmtMoney(r.maxDrawdown)}");CaptionMuted("最高点 ${fmtMoney(r.maxPeak)} · 最低点 ${fmtMoney(r.minTrough)} · 最大连对 ${r.maxHitStreak} · 最大连错 ${r.maxMissStreak}")}}}
            item{GlobalCard{Text("涨跌趋势分析",fontWeight=FontWeight.Bold);reports.forEach{r->Text("${r.plan.planName}：${r.currentTrend}",fontWeight=FontWeight.SemiBold);CaptionMuted("最高点 ${fmtMoney(r.maxPeak)} · 最低点 ${fmtMoney(r.minTrough)} · 当前 ${fmtMoney(r.points.lastOrNull()?.cumulativeProfit?:0.0)}");CaptionMuted("距最高点 ${fmtMoney(r.distanceFromPeak)} · 从最低点反弹 ${fmtMoney(r.reboundFromTrough)} · 当前位置 ${"%.1f".format(r.positionPercent)}%")}}}
            item{GlobalCard{Text("计划对比分析",fontWeight=FontWeight.Bold);if(reports.size<2)CaptionMuted("选择至少2个计划后显示横向对比")else{reports.sortedByDescending{it.netProfit}.forEachIndexed{idx,r->Text("${idx+1}. ${r.plan.planName}",fontWeight=FontWeight.SemiBold);Text("命中率 ${(r.hitRate*100).roundToInt()}% · 净收益 ${fmtMoney(r.netProfit)} · 最大回撤 ${fmtMoney(r.maxDrawdown)} · 最大连错 ${r.maxMissStreak}",fontSize=12.sp)};CaptionMuted("收益最佳：${reports.maxByOrNull{it.netProfit}?.plan?.planName?:"-"} · 命中率最高：${reports.maxByOrNull{it.hitRate}?.plan?.planName?:"-"} · 回撤最小：${reports.minByOrNull{it.maxDrawdown}?.plan?.planName?:"-"}")}}}
            item{GlobalCard{Text("图表分析报告",fontWeight=FontWeight.Bold);reports.forEach{r->val cur=r.points.lastOrNull()?.cumulativeProfit?:0.0;val dir=if(r.netProfit>0)"累计收益为正"else if(r.netProfit<0)"累计收益为负"else"累计收益持平";Text(r.plan.planName,fontWeight=FontWeight.SemiBold,modifier=Modifier.padding(top=6.dp));Text("整体表现：$dir；回测 ${r.periods} 个有效单元，命中率 ${(r.hitRate*100).roundToInt()}%，净收益 ${fmtMoney(r.netProfit)}。");Text("收益分析：总投入 ${fmtMoney(r.totalStake)}，最高点 ${fmtMoney(r.maxPeak)}，最低点 ${fmtMoney(r.minTrough)}。");Text("趋势分析：${r.currentTrend}；当前 ${fmtMoney(cur)}，距最高点 ${fmtMoney(r.distanceFromPeak)}，从最低点反弹 ${fmtMoney(r.reboundFromTrough)}。");Text("风险分析：最大回撤 ${fmtMoney(r.maxDrawdown)}，最大连对 ${r.maxHitStreak}，最大连错 ${r.maxMissStreak}。")}}}
            item{GlobalCard{Text("完整回测明细",fontWeight=FontWeight.Bold);reports.forEach{r->Text(r.plan.planName,fontWeight=FontWeight.SemiBold,modifier=Modifier.padding(top=6.dp));r.points.asReversed().forEach{pt->Row(Modifier.fillMaxWidth().padding(vertical=2.dp),horizontalArrangement=Arrangement.SpaceBetween){Text("${pt.issue} · ${pt.prediction} · ${if(pt.hit)"对"else"错"}",fontSize=11.sp,modifier=Modifier.weight(1f));Text(fmtMoney(pt.periodProfit),fontSize=11.sp,modifier=Modifier.width(70.dp));Text(fmtMoney(pt.cumulativeProfit),fontSize=11.sp,modifier=Modifier.width(80.dp))}}}}
        }
    }
}

@Composable private fun FilterLineChart(title:String,options:List<String>,selected:String,onSelect:(String)->Unit){Column(Modifier.fillMaxWidth().padding(top=5.dp)){CaptionMuted(title);Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(5.dp)){options.forEach{FilterChip(selected=selected==it,onClick={onSelect(it)},label={Text(it)})}}}}

private fun fmtMoney(v:Double):String=if(v>=0)"+${"%.2f".format(v)}" else "${"%.2f".format(v)}"

@Composable
private fun NovaBacktestCurveChart(reports: List<NovaPlanAnalytics.ChartReport>, mode: String, onPointClick: (NovaPlanAnalytics.ChartPoint) -> Unit) {
    val chartHeight = 220.dp
    var scale by remember(reports.map { it.plan.planId to it.points.size }) { mutableFloatStateOf(1f) }
    var offsetX by remember(reports.map { it.plan.planId to it.points.size }) { mutableFloatStateOf(0f) }
    var offsetY by remember(reports.map { it.plan.planId to it.points.size }) { mutableFloatStateOf(0f) }
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            CaptionMuted(if (scale <= 1.01f) "双指缩放 · 放大后单指拖动 · 当前1x" else "拖动查看细节 · 当前${"%.1f".format(scale)}x")
            if (scale > 1.01f || kotlin.math.abs(offsetX) > 1f || kotlin.math.abs(offsetY) > 1f) TextButton(onClick = { scale = 1f; offsetX = 0f; offsetY = 0f }) { Text("复位") }
        }
        Box(Modifier.fillMaxWidth().height(chartHeight).clip(RoundedCornerShape(8.dp))
            .pointerInput(reports.map { it.points.size } to mode) {
                detectTapGestures { pos ->
                    if (reports.isNotEmpty()) {
                        val r = reports.first()
                        if (r.points.isNotEmpty()) {
                            val idx = ((pos.x / size.width) * r.points.size).roundToInt().coerceIn(0, r.points.lastIndex)
                            onPointClick(r.points[idx])
                        }
                    }
                }
            }
            .pointerInput(reports.map { it.points.size }) {
            awaitEachGesture {
                try {
                    do {
                        val event = awaitPointerEvent()
                        if (event.changes.none { it.pressed }) break
                        val zoom = event.calculateZoom()
                        val pan = event.calculatePan()
                        val multi = event.changes.count { it.pressed } >= 2
                        if (multi || kotlin.math.abs(zoom - 1f) > 0.01f || scale > 1.01f) {
                            val newScale = (scale * zoom).coerceIn(1f, 6f)
                            val ratio = if (scale > 0f) newScale / scale else 1f
                            scale = newScale
                            if (newScale <= 1.01f) { scale = 1f; offsetX = 0f; offsetY = 0f }
                            else {
                                val maxX = size.width * (newScale - 1f)
                                val maxY = size.height * (newScale - 1f) * .4f
                                offsetX = (offsetX * ratio + pan.x).coerceIn(-maxX, maxX)
                                offsetY = (offsetY * ratio + pan.y).coerceIn(-maxY, maxY)
                            }
                            event.changes.forEach { if (it.positionChanged()) it.consume() }
                        }
                    } while (true)
                } catch (_: Exception) {}
            }
        }) {
            Canvas(Modifier.fillMaxSize().graphicsLayer { scaleX = scale; scaleY = scale; translationX = offsetX; translationY = offsetY }) {
                val all = reports.flatMap { it.points }
                if (all.isEmpty()) return@Canvas
                val maxCount = reports.maxOf { it.points.size }.coerceAtLeast(1)
                val minY = reports.minOfOrNull { it.points.minOfOrNull { p -> p.cumulativeProfit } ?: 0.0 } ?: 0.0
                val maxY = reports.maxOfOrNull { it.points.maxOfOrNull { p -> p.cumulativeProfit } ?: 0.0 } ?: 0.0
                val lo = minOf(0.0, minY); val hi = maxOf(0.0, maxY); val span = (hi - lo).coerceAtLeast(1.0); val range = span * 1.15
                val padL = 10f; val padR = 10f; val padT = 12f; val padB = 14f
                val cw = size.width - padL - padR; val ch = size.height - padT - padB
                fun x(i: Int): Float = if (maxCount <= 1) padL + cw / 2f else padL + cw * i / (maxCount - 1)
                fun valueAt(r: NovaPlanAnalytics.ChartReport, p: NovaPlanAnalytics.ChartPoint): Double = when (mode) {
                    "单期盈亏" -> p.periodProfit
                    "命中率" -> p.hitRate * 100.0
                    "涨跌趋势" -> if (p.periodProfit > 0) 1.0 else if (p.periodProfit < 0) -1.0 else 0.0
                    "回撤" -> p.drawdown
                    else -> p.cumulativeProfit
                }
                val values = reports.flatMap { r -> r.points.map { p -> valueAt(r, p) } }
                val modeMin = values.minOrNull() ?: lo
                val modeMax = values.maxOrNull() ?: hi
                val modeLo = minOf(0.0, modeMin)
                val modeHi = maxOf(0.0, modeMax)
                val modeRange = (modeHi - modeLo).coerceAtLeast(1.0) * 1.15
                fun y(v: Double): Float = padT + ch * (((modeHi - v) / modeRange).toFloat().coerceIn(0f, 1f))
                val zeroY = y(0.0)
                drawLine(Color(0xFF999999), Offset(padL, zeroY), Offset(size.width - padR, zeroY), 1.5f, pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(8f,6f)))
                reports.forEachIndexed { idx, r ->
                    val path = Path()
                    r.points.forEachIndexed { i, p -> if (i == 0) path.moveTo(x(i), y(valueAt(r, p))) else path.lineTo(x(i), y(valueAt(r, p))) }
                    drawPath(path, Color(0xFF1565C0).copy(alpha = (1f - idx * .12f).coerceAtLeast(.45f)), style = Stroke(width = 3f, cap = StrokeCap.Round))
                    val hiIdx = r.points.indices.maxByOrNull { r.points[it].cumulativeProfit } ?: -1
                    val loIdx = r.points.indices.minByOrNull { r.points[it].cumulativeProfit } ?: -1
                    if (hiIdx >= 0) drawCircle(Color(0xFF2E7D32), 4f, Offset(x(hiIdx), y(r.points[hiIdx].cumulativeProfit)))
                    if (loIdx >= 0) drawCircle(Color(0xFFC62828), 4f, Offset(x(loIdx), y(r.points[loIdx].cumulativeProfit)))
                }
            }
        }
        reports.forEach { r -> CaptionMuted("${r.plan.planName} · 最高 ${fmtMoney(r.maxPeak)} · 最低 ${fmtMoney(r.minTrough)} · 当前 ${fmtMoney(r.points.lastOrNull()?.cumulativeProfit ?: 0.0)}") }
    }
}

}
