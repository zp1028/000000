package com.caifenxi.app.domain.btc.hs

import com.caifenxi.app.domain.btc.MarketRegime
import kotlin.math.abs

/**
 * Controls model promotion/retirement using only observed holdout + feedback data.
 * It never changes live orders directly; it only returns eligibility/weights metadata.
 */
object HsModelLifecycle {
    enum class Status { CANDIDATE, ACTIVE, DEGRADED, RETIRED }
    data class State(val modelId:String,val status:Status,val score:Double,val drift:Double,val reason:String)
    data class Report(val generatedAt:Long,val states:List<State>,val activeModels:List<String>)

    fun evaluate(lab: HsModelLab.Report, feedback: Map<String, HsFeedbackStore.TimeframeMetrics>): Report {
        val states = lab.models.map { m ->
            val fb = feedback[m.modelId]
            val drift = fb?.let { abs(it.recentBrier - it.baselineBrier) } ?: 0.0
            val sampleOk = m.samples >= 24
            val quality = (0.55*m.hitRate + 0.45*(1.0-m.brier)).coerceIn(0.0,1.0)
            val status = when {
                !sampleOk -> Status.CANDIDATE
                drift > 0.08 || m.brier > 0.28 -> Status.RETIRED
                drift > 0.045 || m.brier > 0.255 -> Status.DEGRADED
                else -> Status.ACTIVE
            }
            val reason = when(status) {
                Status.ACTIVE -> "holdout + feedback stable"
                Status.DEGRADED -> "performance drift detected"
                Status.RETIRED -> "poor calibration or material drift"
                Status.CANDIDATE -> "insufficient validated samples"
            }
            State(m.modelId,status,quality,drift,reason)
        }
        return Report(System.currentTimeMillis(), states, states.filter{it.status==Status.ACTIVE}.map{it.modelId})
    }

    fun regimeHealth(lab: HsModelLab.Report, regime: MarketRegime): Map<String,Double> =
        lab.models.associate { m ->
            val c=lab.regimeMatrix.firstOrNull{it.modelId==m.modelId&&it.regime==regime}
            m.modelId to if(c==null) 0.25 else (0.6*c.hitRate+0.4*(1.0-c.brier)).coerceIn(0.0,1.0)
        }
}
