package com.caifenxi.app.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.FilterChip
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.caifenxi.app.domain.model.PlanDefinition
import com.caifenxi.app.domain.model.PlanPredictionRecord
import com.caifenxi.app.domain.model.PlanRuntime
import com.caifenxi.app.domain.plan.PlanPool
import com.caifenxi.app.ui.MainViewModel
import com.caifenxi.app.ui.components.CaptionMuted
import com.caifenxi.app.ui.components.PageHeader
import com.caifenxi.app.ui.components.EmptyStateBlock
import com.caifenxi.app.domain.model.LotteryPlayCatalog
import com.caifenxi.app.ui.components.GlobalCard
import com.caifenxi.app.ui.components.PrimaryButton
import com.caifenxi.app.ui.theme.CaiTokens
import kotlin.math.roundToInt

private enum class PlanTab(val label: String) {
    DASHBOARD("引擎总览"),
    LIBRARY("计划库"),
    LEADERBOARD("竞技排行"),
    CURRENT("本期计划"),
    CONSENSUS("共识预测"),
    CONSENSUS_STATS("共识战绩"),
    CONSENSUS_LOG("共识记录"),
    PLAN_STATS("计划战绩"),
    CUSTOM("自定义")
}

@Composable
fun PlanScreen(vm: MainViewModel, onOpenNova: () -> Unit = {}) {
    val rows = vm.planRows.value
    val consensus = vm.consensus.value
    val latestIssue = vm.latest.value?.issue
    // 目标期以首页下期为准(由最新开奖推算),禁止继续展示落后于最新期的旧共识目标
    val targetIssue = vm.nextIssueText.value
        .takeIf { it.isNotBlank() && it != "-" }
        ?: vm.planVM.planTargetIssue.value
    val consensusForTarget = consensus.filter { it.targetIssue == targetIssue }
    var tab by remember { mutableStateOf(PlanTab.DASHBOARD) }
    var expandedId by remember { mutableStateOf<String?>(null) }
    var consensusCat by remember { mutableStateOf("全部") }
    var consensusResult by remember { mutableStateOf("全部") }
    var showCustomEditor by remember { mutableStateOf(false) }
    var editingCustom by remember { mutableStateOf<com.caifenxi.app.domain.model.CustomPlan?>(null) }
    var showBacktestDialog by remember { mutableStateOf(false) }
    var backtestPeriodsText by remember { mutableStateOf("500") }

    // 首次进入时加载自定义计划;切入共识页时按最新期对齐目标
    androidx.compose.runtime.LaunchedEffect(vm.currentLottery.value.key) {
        vm.loadCustomPlans()
    }

    androidx.compose.runtime.LaunchedEffect(tab) {
        if (tab == PlanTab.LEADERBOARD && vm.planVM.planRows.value.isEmpty() && vm.history.value.size >= 6) {
            // 仅刷新运行态展示，不强制全量回测
            vm.planVM.refreshRuntimeState()
        }
    }

    androidx.compose.runtime.LaunchedEffect(tab, latestIssue, targetIssue) {
        if (tab == PlanTab.CONSENSUS) {
            vm.refreshPlanConsensusTab()
        }
    }

    if (showBacktestDialog) {
        AlertDialog(
            onDismissRequest = { if (!vm.backtestRunning.value) showBacktestDialog = false },
            title = { Text("计划回测设置", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(CaiTokens.S8)) {
                    CaptionMuted("选择本次滚动回测的历史窗口。不会删除历史数据。")
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(CaiTokens.S8)) {
                        listOf(50, 100, 200, 500, 1000, 2000, 5000).forEach { n ->
                            FilterChip(
                                selected = backtestPeriodsText == n.toString(),
                                onClick = { backtestPeriodsText = n.toString() },
                                label = { Text("${n}期") }
                            )
                        }
                    }
                    OutlinedTextField(
                        value = backtestPeriodsText,
                        onValueChange = { value -> backtestPeriodsText = value.filter { it.isDigit() }.take(7) },
                        label = { Text("自定义期数") },
                        singleLine = true,
                        supportingText = { Text("输入 30 以上；留空或无效时使用500期") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val n = backtestPeriodsText.toIntOrNull()?.coerceAtLeast(30) ?: 500
                        backtestPeriodsText = n.toString()
                        showBacktestDialog = false
                        vm.runBacktest(n)
                    },
                    enabled = !vm.backtestRunning.value
                ) { Text("开始回测") }
            },
            dismissButton = {
                TextButton(onClick = { showBacktestDialog = false }, enabled = !vm.backtestRunning.value) { Text("取消") }
            }
        )
    }

    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = CaiTokens.ScreenHPadding)
            .padding(top = CaiTokens.S16)
    ) {
        PageHeader(
            title = "计划大厅",
            lotteryName = vm.currentLottery.value.name,
            playSummary = LotteryPlayCatalog.summaryText(vm.currentLottery.value.type),
            subtitle = "原计划引擎 · 与新计划池数据隔离"
        )
        val latestTime = vm.latest.value?.drawTime?.take(19).orEmpty()
        CaptionMuted(
            buildString {
                append("最新第 ${latestIssue ?: "-"} 期")
                if (latestTime.isNotBlank()) append("($latestTime)")
                append(" · 目标第 ${if (targetIssue.isBlank()) "-" else targetIssue} 期")
                append(" · 挂机认此目标")
            }
        )
        val staleHint = remember(latestTime) {
            if (latestTime.isBlank()) return@remember true
            try {
                val fmt = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US)
                val t = fmt.parse(latestTime)?.time ?: return@remember true
                System.currentTimeMillis() - t > 3L * 24 * 3600_000
            } catch (_: Exception) {
                true
            }
        }
        if (staleHint) {
            CaptionMuted("⚠ 最新开奖已过期:可能是停盘彩种(如北京PK10)或仍用本地旧缓存。请换极速赛车/飞艇并首页刷新。")
        }
        Spacer(Modifier.height(CaiTokens.S8))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(CaiTokens.S8)) {
            PrimaryButton("打开新计划池", onClick = onOpenNova, modifier = Modifier.weight(1f))
            PrimaryButton("计划回测", onClick = { showBacktestDialog = true }, ghost = true, modifier = Modifier.weight(1f))
        }
        Spacer(Modifier.height(CaiTokens.S8))
        PrimaryButton(
            text = if (vm.backtestRunning.value) "回测中…" else "按计划池回测并刷新共识",
            onClick = { showBacktestDialog = true },
            enabled = !vm.backtestRunning.value,
            modifier = Modifier.fillMaxWidth()
        )
        CaptionMuted("回测期数可自定义；500期只是默认窗口，历史数据不设500期上限。")
        Row(
            Modifier
                .horizontalScroll(rememberScrollState())
                .padding(vertical = CaiTokens.S12),
            horizontalArrangement = Arrangement.spacedBy(CaiTokens.S8)
        ) {
            PlanTab.entries.forEach { t ->
                FilterChip(
                    selected = tab == t,
                    onClick = { tab = t },
                    label = { Text(t.label) }
                )
            }
        }

        LazyColumn(
            Modifier
                .fillMaxSize()
                .padding(bottom = CaiTokens.ScreenBottom),
            verticalArrangement = Arrangement.spacedBy(CaiTokens.S8)
        ) {
            when (tab) {
                PlanTab.DASHBOARD -> {
                    item {
                        GlobalCard {
                            Text("计划引擎 v2.0", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            CaptionMuted("数据 → 特征 → 计划 → 滚动回测 → 评分 → 动态权重 → 共识 → 预测")
                            Spacer(Modifier.height(CaiTokens.S12))
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(CaiTokens.S8)) {
                                StatCell("计划数", "${PlanPool.ALL.size + vm.customPlans.value.size}")
                                StatCell("已结算", "${rows.sumOf { it.second.sampleCount }}")
                                StatCell("活跃", "${rows.count { it.second.status.name == "ACTIVE" || it.second.status.name == "PROMOTED" }}")
                                StatCell("目标期", targetIssue)
                            }
                        }
                    }
                    item {
                        GlobalCard {
                            Text("核心功能入口", fontWeight = FontWeight.Bold)
                            CaptionMuted("原来的功能全部集中到这里，点击上方分页即可进入具体模块。")
                            Spacer(Modifier.height(CaiTokens.S8))
                            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(CaiTokens.S8)) {
                                listOf(PlanTab.LIBRARY, PlanTab.LEADERBOARD, PlanTab.CURRENT, PlanTab.CONSENSUS, PlanTab.PLAN_STATS, PlanTab.CUSTOM).forEach { t ->
                                    FilterChip(selected = false, onClick = { tab = t }, label = { Text(t.label) })
                                }
                            }
                        }
                    }
                    item {
                        GlobalCard {
                            Text("计划池状态", fontWeight = FontWeight.Bold)
                            CaptionMuted("当前计划池：${rows.size} · 自定义：${vm.customPlans.value.size} · 回测窗口：可手动调整")
                            Spacer(Modifier.height(CaiTokens.S8))
                            PrimaryButton(
                                text = if (vm.backtestRunning.value) "回测中…" else "打开回测设置",
                                onClick = { showBacktestDialog = true },
                                enabled = !vm.backtestRunning.value,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
                PlanTab.LIBRARY -> {
                    item {
                        GlobalCard {
                            Text("计划库 · 系统计划", fontWeight = FontWeight.Bold)
                            CaptionMuted("计划 = 算法 + 参数 + 窗口 + 玩法；可精确到 planId。")
                        }
                    }
                    items(PlanPool.ALL, key = { it.planId }) { def ->
                        val rt = rows.find { it.first.planId == def.planId }?.second ?: PlanRuntime(def.planId)
                        GlobalCard {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Column(Modifier.weight(1f)) {
                                    Text(def.planName, fontWeight = FontWeight.Bold)
                                    CaptionMuted("${def.planId} · ${def.category} · ${def.algorithm} · 窗口 ${def.window}期 · 周期 ${def.cyclePeriods}期")
                                }
                                Text(rt.hitRatePercent, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                    item {
                        GlobalCard {
                            Text("自定义计划", fontWeight = FontWeight.Bold)
                            CaptionMuted("共 ${vm.customPlans.value.size} 个；可在“自定义”页新建、编辑和查看战绩。")
                        }
                    }
                }
                PlanTab.LEADERBOARD -> {
                    item {
                        GlobalCard {
                            Text("模型竞技场", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            CaptionMuted("按样本与得分排序。无数据时请点「重新滚动验证」完成回测。")
                            if (vm.backtestRunning.value) {
                                LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp))
                            }
                        }
                    }
                    val leaderboard = vm.planVM.planRows.value
                        .sortedWith(
                            compareByDescending<Pair<PlanDefinition, PlanRuntime>> { it.second.sampleCount >= 5 }
                                .thenByDescending { it.second.score }
                                .thenByDescending { it.second.hitRate }
                                .thenByDescending { it.second.sampleCount }
                        )
                        .sortedWith(compareByDescending<Pair<PlanDefinition, PlanRuntime>> { it.second.score }.thenByDescending { it.second.hitRate }.thenByDescending { it.second.sampleCount })
                    if (leaderboard.isEmpty()) {
                        item {
                            GlobalCard {
                                Text("暂无排行数据", fontWeight = FontWeight.Bold)
                                CaptionMuted("请先同步开奖，再点上方「重新滚动验证」生成战绩。")
                                PrimaryButton("立即回测排行", { showBacktestDialog = true }, Modifier.fillMaxWidth().padding(top = 8.dp))
                            }
                        }
                    }
                    items(leaderboard.take(50), key = { "lb-" + it.first.planId }) { (def, rt) ->
                        GlobalCard {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Column(Modifier.weight(1f)) {
                                    Text(def.planName, fontWeight = FontWeight.Bold)
                                    CaptionMuted("${def.planId} · ${def.category} · 样本 ${rt.sampleCount} · 连中 ${rt.consecutiveHit} · 连错 ${rt.consecutiveMiss}")
                                }
                                Column(horizontalAlignment = androidx.compose.ui.Alignment.End) {
                                    Text("${"%.1f".format(rt.score)}分", fontWeight = FontWeight.Bold)
                                    Text(rt.hitRatePercent, color = MaterialTheme.colorScheme.secondary)
                                }
                            }
                        }
                    }
                }
                PlanTab.CONSENSUS -> {
                    item {
                        GlobalCard {
                            Text("共识预测 · 目标第 ${if (targetIssue.isBlank()) "-" else targetIssue} 期", fontWeight = FontWeight.Bold)
                            CaptionMuted("与挂机「来源=共识」共用此数据。为空时请点上方回测或回首页刷新。")
                        }
                    }
                    val allRecords = vm.consensusRecords.value
                    if (consensusForTarget.isEmpty()) {
                        item {
                            GlobalCard {
                                Text("当前目标期暂无共识预测")
                                CaptionMuted("请先首页同步开奖，或点「重新随机生成并回测」")
                            }
                        }
                    } else {
                        items(consensusForTarget) { c ->
                            val rec = allRecords.firstOrNull {
                                it.targetIssue == c.targetIssue && it.category == c.category
                            }
                            val resultColor = when (rec?.result) {
                                "对" -> Color(0xFF2E7D32)
                                "错" -> Color(0xFFC62828)
                                else -> Color(0xFFF9A825)
                            }
                            GlobalCard {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("${c.category} → ${c.leadingDirection}", fontWeight = FontWeight.Bold)
                                    Text(rec?.result ?: "待开", fontWeight = FontWeight.Bold, color = resultColor)
                                }
                                CaptionMuted("目标期 ${c.targetIssue}")
                                if (c.detail.isNotEmpty()) {
                                    CaptionMuted(
                                        "候选: " + c.detail.entries.sortedByDescending { it.value }
                                            .joinToString(" · ") { "${it.key} ${(it.value * 100).roundToInt()}%" }
                                    )
                                }
                                LinearProgressIndicator(
                                    progress = { c.supportRatio.toFloat().coerceIn(0f, 1f) },
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                    color = MaterialTheme.colorScheme.secondary
                                )
                                CaptionMuted(
                                    "支持 ${(c.supportRatio * 100).roundToInt()}% · ${c.participatingPlans} 计划 · 分歧 ${(c.disagreement * 100).roundToInt()}%"
                                )
                            }
                        }
                    }
                }
                PlanTab.CURRENT -> {
                    if (rows.isEmpty()) {
                        item { GlobalCard { Text("暂无计划，请先首页加载或点上方重新生成。") } }
                    } else {
                        items(rows, key = { it.first.planId }) { (def, rt) ->
                            val current = vm.currentPredictions.value.filter {
                                it.planId == def.planId &&
                                    (targetIssue == "-" || it.targetIssue == targetIssue)
                            }
                            PlanCard(
                                def = def,
                                rt = rt,
                                currentPreds = current,
                                history = emptyList(),
                                expanded = expandedId == def.planId,
                                showHistory = false,
                                onToggle = {
                                    expandedId = if (expandedId == def.planId) null else def.planId
                                    if (expandedId == def.planId) vm.loadPlanDetail(def.planId)
                                }
                            )
                        }
                    }
                }
                PlanTab.CONSENSUS_STATS -> {
                    item {
                        val cs = vm.consensusStats.value
                        GlobalCard {
                            Text("共识对错率总览", fontWeight = FontWeight.Bold)
                            CaptionMuted("总览按目标期一期一计（主分类全对=期对）；下方仍按分类分项")
                            Spacer(Modifier.height(CaiTokens.S12))
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                                StatCell("已结算期", "${cs.hit + cs.miss}")
                                StatCell("期对", "${cs.hit}", Color(0xFF2E7D32))
                                StatCell("期错", "${cs.miss}", Color(0xFFC62828))
                                StatCell(
                                    "对错率",
                                    if (cs.hit + cs.miss == 0) "-" else "${(cs.hitRate * 100).roundToInt()}%",
                                    MaterialTheme.colorScheme.secondary
                                )
                            }
                            if (cs.pending > 0) CaptionMuted("待开期 ${cs.pending}")
                            Spacer(Modifier.height(CaiTokens.S8))
                            cs.byCategory.forEach { (cat, st) ->
                                val rate = if (st.hit + st.miss == 0) 0 else (st.hit * 100.0 / (st.hit + st.miss)).roundToInt()
                                Text("$cat：对 ${st.hit} / 错 ${st.miss} · 命中率 $rate%", fontWeight = FontWeight.SemiBold)
                                if (st.hit + st.miss > 0) {
                                    LinearProgressIndicator(
                                        progress = { (rate / 100f).coerceIn(0f, 1f) },
                                        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
                                        color = MaterialTheme.colorScheme.secondary
                                    )
                                }
                                val cur = when {
                                    st.recentStreak > 0 -> "当前连对 ${st.recentStreak}"
                                    st.recentStreak < 0 -> "当前连错 ${-st.recentStreak}"
                                    else -> "当前无连续"
                                }
                                CaptionMuted("$cur · 最长连对 ${st.maxHitStreak} · 最长连错 ${st.maxMissStreak}")
                                if (st.twoWindows > 0) {
                                    CaptionMuted(
                                        "两期对 ${(st.twoHitRate * 100).roundToInt()}% · 两期错 ${(st.twoMissRate * 100).roundToInt()}%（${st.twoWindows} 窗口）"
                                    )
                                }
                                if (st.threeWindows > 0) {
                                    CaptionMuted(
                                        "三期对 ${(st.threeHitRate * 100).roundToInt()}% · 三期错 ${(st.threeMissRate * 100).roundToInt()}%（${st.threeWindows} 窗口）"
                                    )
                                }
                                Spacer(Modifier.height(CaiTokens.S4))
                            }
                            Spacer(Modifier.height(CaiTokens.S8))
                            PrimaryButton("清空共识战绩", onClick = { vm.clearConsensusStats() }, ghost = true)
                        }
                    }
                    item {
                        val cs = vm.consensusStats.value
                        GlobalCard {
                            Text("共识连对连错 · 两期/三期对错率", fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(CaiTokens.S12))
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                                StatCell("最长连对", "${cs.maxHitStreak}", Color(0xFF2E7D32))
                                StatCell("最长连错", "${cs.maxMissStreak}", Color(0xFFC62828))
                                StatCell(
                                    "当前连续",
                                    when {
                                        cs.recentStreak > 0 -> "连对${cs.recentStreak}"
                                        cs.recentStreak < 0 -> "连错${-cs.recentStreak}"
                                        else -> "-"
                                    },
                                    if (cs.recentStreak >= 0) Color(0xFF2E7D32) else Color(0xFFC62828)
                                )
                            }
                            Spacer(Modifier.height(CaiTokens.S12))
                            ConsensusWindowRate(
                                title = "两期对错率",
                                hitRate = cs.twoHitRate,
                                missRate = cs.twoMissRate,
                                windows = cs.twoWindows
                            )
                            Spacer(Modifier.height(CaiTokens.S8))
                            ConsensusWindowRate(
                                title = "三期对错率",
                                hitRate = cs.threeHitRate,
                                missRate = cs.threeMissRate,
                                windows = cs.threeWindows
                            )
                            Spacer(Modifier.height(CaiTokens.S4))
                            CaptionMuted("口径：以连续两期为一个窗口，窗口内对一次及以上记「两期对」，两期全错记「两期错」；三期同理。本卡片为全部分类合计，各分类独立明细见上方总览。")
                        }
                    }
                }
                PlanTab.CONSENSUS_LOG -> {
                    val all = vm.consensusRecords.value
                    val cats = listOf("全部") + all.map { it.category }.distinct().sorted()
                    val results = listOf("全部", "待开", "对", "错")
                    val filtered = all.filter {
                        (consensusCat == "全部" || it.category == consensusCat) &&
                            (consensusResult == "全部" || it.result == consensusResult)
                    }
                    item {
                        CaptionMuted("共 ${filtered.size} / ${all.size} 条")
                        Row(
                            Modifier.horizontalScroll(rememberScrollState()).padding(vertical = CaiTokens.S8),
                            horizontalArrangement = Arrangement.spacedBy(CaiTokens.S8)
                        ) {
                            cats.forEach { cat ->
                                FilterChip(
                                    selected = consensusCat == cat,
                                    onClick = { consensusCat = cat },
                                    label = { Text(cat) }
                                )
                            }
                        }
                        Row(
                            Modifier.horizontalScroll(rememberScrollState()).padding(bottom = CaiTokens.S8),
                            horizontalArrangement = Arrangement.spacedBy(CaiTokens.S8)
                        ) {
                            results.forEach { r ->
                                FilterChip(
                                    selected = consensusResult == r,
                                    onClick = { consensusResult = r },
                                    label = { Text(if (r == "全部") "全部结果" else r) }
                                )
                            }
                        }
                        PrimaryButton("导出共识 CSV", onClick = { vm.exportConsensusCsv() }, ghost = true)
                    }
                    if (filtered.isEmpty()) {
                        item { GlobalCard { Text("暂无共识记录") } }
                    } else {
                        items(filtered, key = { it.id }) { r ->
                            val color = when (r.result) {
                                "对" -> Color(0xFF2E7D32)
                                "错" -> Color(0xFFC62828)
                                else -> Color(0xFFF9A825)
                            }
                            GlobalCard {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Column(Modifier.weight(1f)) {
                                        Text("第 ${r.targetIssue} 期 · ${r.category}", fontWeight = FontWeight.Bold)
                                        Text(
                                            "共识「${r.leadingDirection}」" +
                                                (r.actual?.let { " → 开奖「$it」" } ?: " · 待开奖")
                                        )
                                        if (r.candidates.size > 1) {
                                            CaptionMuted("候选: ${r.candidates.joinToString(" / ")}")
                                        }
                                        CaptionMuted(
                                            "支持度 ${(r.supportRatio * 100).roundToInt()}% · ${r.participatingPlans} 计划" +
                                                " · 记录于 ${android.text.format.DateFormat.format("MM-dd HH:mm", r.createdAt)}"
                                        )
                                    }
                                    Text(r.result, fontWeight = FontWeight.Bold, color = color)
                                }
                            }
                        }
                    }
                }
                PlanTab.PLAN_STATS -> {
                    item {
                        CaptionMuted("各计划累计成功率 · 点开可看历史预测")
                    }
                    item {
                        val trendRows = vm.planVM.planTrends.value
                        val top = rows.take(5)
                        if (top.isNotEmpty()) {
                            GlobalCard {
                                Text("评分与权重趋势", fontWeight = FontWeight.Bold)
                                CaptionMuted("仅展示最近 60 个结算点；趋势用于观察计划变强/衰退，不改变预测结果。")
                                Spacer(Modifier.height(CaiTokens.S8))
                                top.forEach { (def, rt) ->
                                    val points = trendRows[def.planId].orEmpty()
                                    PlanTrendChart(
                                        name = def.planName,
                                        points = points.map { it.score },
                                        modifier = Modifier.fillMaxWidth().height(72.dp)
                                    )
                                    CaptionMuted(
                                        "${def.planId} · 评分 ${"%.1f".format(rt.score)} · 权重 ${"%.3f".format(rt.weight)} · ${rt.hitRatePercent}"
                                    )
                                    Spacer(Modifier.height(CaiTokens.S8))
                                }
                            }
                        }
                    }
                    if (rows.isEmpty()) {
                        item { GlobalCard { Text("暂无计划数据") } }
                    } else {
                        items(rows, key = { "s-" + it.first.planId }) { (def, rt) ->
                            val hist = vm.planHistory.value
                                .filter { it.planId == def.planId && it.settled }
                                .take(20)
                            PlanCard(
                                def = def,
                                rt = rt,
                                currentPreds = emptyList(),
                                history = hist,
                                expanded = expandedId == "s-" + def.planId,
                                showHistory = true,
                                onToggle = {
                                    val id = "s-" + def.planId
                                    expandedId = if (expandedId == id) null else id
                                    if (expandedId == id) vm.loadPlanDetail(def.planId)
                                }
                            )
                        }
                    }
                }
                PlanTab.CUSTOM -> {
                    item {
                        GlobalCard {
                            Text("自定义计划", fontWeight = FontWeight.Bold)
                            CaptionMuted("保存后自动进入计划池参与回测/共识;点开可看对错率与战绩。")
                            Spacer(Modifier.height(CaiTokens.S8))
                            PrimaryButton(
                                text = "新建计划",
                                onClick = {
                                    editingCustom = null
                                    showCustomEditor = true
                                },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                    val customs = vm.customPlans.value
                    if (customs.isEmpty()) {
                        item { GlobalCard { Text("暂无自定义计划,点上方「新建计划」添加。") } }
                    } else {
                        items(customs, key = { it.planId }) { cp ->
                            val rt = rows.find { it.first.planId == cp.planId }?.second
                            val expanded = expandedId == "c-" + cp.planId
                            GlobalCard(onClick = {
                                val id = "c-" + cp.planId
                                expandedId = if (expandedId == id) null else id
                                if (expandedId == id) vm.loadPlanDetail(cp.planId)
                            }) {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Column(Modifier.weight(1f)) {
                                        Text(cp.planName, fontWeight = FontWeight.Bold)
                                        CaptionMuted(
                                            "${cp.category} · ${cp.algorithm} · 窗${cp.window} · 周期${cp.cyclePeriods}期" +
                                                if (cp.participateConsensus) " · 参与共识" else " · 不参与共识"
                                        )
                                        rt?.lastPrediction?.let { pred ->
                                            Text(
                                                "当期：$pred",
                                                fontWeight = FontWeight.SemiBold,
                                                color = MaterialTheme.colorScheme.secondary
                                            )
                                        }
                                    }
                                    Column(horizontalAlignment = androidx.compose.ui.Alignment.End) {
                                        Text(
                                            rt?.hitRatePercent ?: "-",
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.secondary
                                        )
                                        Text(
                                            if (cp.enabled) "启用" else "停用",
                                            fontWeight = FontWeight.Bold,
                                            color = if (cp.enabled) Color(0xFF2E7D32) else Color(0xFFC62828)
                                        )
                                    }
                                }
                                if ((rt?.sampleCount ?: 0) > 0) {
                                    LinearProgressIndicator(
                                        progress = { (rt?.hitRate ?: 0.0).toFloat().coerceIn(0f, 1f) },
                                        modifier = Modifier.fillMaxWidth().padding(top = CaiTokens.S4),
                                        color = MaterialTheme.colorScheme.secondary
                                    )
                                }
                                Row(
                                    Modifier.padding(top = CaiTokens.S8),
                                    horizontalArrangement = Arrangement.spacedBy(CaiTokens.S8)
                                ) {
                                    androidx.compose.material3.TextButton(onClick = {
                                        editingCustom = cp
                                        showCustomEditor = true
                                    }) { Text("编辑") }
                                    androidx.compose.material3.TextButton(onClick = {
                                        vm.toggleCustomPlan(cp, !cp.enabled)
                                    }) { Text(if (cp.enabled) "停用" else "启用") }
                                    androidx.compose.material3.TextButton(onClick = { vm.deleteCustomPlan(cp.planId) }) {
                                        Text("删除", color = Color(0xFFC62828))
                                    }
                                }
                                AnimatedVisibility(visible = expanded) {
                                    Column(Modifier.padding(top = CaiTokens.S8)) {
                                        CaptionMuted("对 ${rt?.hitCount ?: 0}/${rt?.sampleCount ?: 0}")
                                        Text("历史战绩", fontWeight = FontWeight.SemiBold)
                                        val hist = vm.planVM.selectedPlanHistory.value
                                            .filter { it.planId == cp.planId }
                                        if (hist.isEmpty()) CaptionMuted("尚无已结算,请先回测")
                                        else hist.take(20).forEach { rec ->
                                            val tag = when (rec.hit) {
                                                true -> "对"; false -> "错"; null -> "—"
                                            }
                                            val color = when (rec.hit) {
                                                true -> Color(0xFF2E7D32)
                                                false -> Color(0xFFC62828)
                                                null -> MaterialTheme.colorScheme.onSurfaceVariant
                                            }
                                            Row(
                                                Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Text("第${rec.targetIssue}期 「${rec.output}」")
                                                Text(tag, fontWeight = FontWeight.Bold, color = color)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(CaiTokens.S24)) }
        }

        if (showCustomEditor) {
            CustomPlanEditor(
                vm = vm,
                initial = editingCustom,
                onDismiss = { showCustomEditor = false },
                onSave = { plan ->
                    vm.saveCustomPlan(plan)
                    showCustomEditor = false
                }
            )
        }
    }
}

@Composable
private fun CustomPlanEditor(
    vm: MainViewModel,
    initial: com.caifenxi.app.domain.model.CustomPlan?,
    onDismiss: () -> Unit,
    onSave: (com.caifenxi.app.domain.model.CustomPlan) -> Unit
) {
    val lotteryKey = vm.currentLottery.value.key
    var name by remember { mutableStateOf(initial?.planName ?: "") }
    var category by remember { mutableStateOf(initial?.category ?: "大小") }
    var algorithm by remember { mutableStateOf(initial?.algorithm ?: "FREQ") }
    var window by remember { mutableStateOf((initial?.window ?: 30).toString()) }
    var cyclePeriods by remember { mutableStateOf((initial?.cyclePeriods ?: 1).toString()) }
    var consensusOn by remember { mutableStateOf(initial?.participateConsensus ?: true) }
    val categories = listOf("大小", "单双", "组合", "号码", "位置-冠军", "位置-亚军", "位置-第3")
    val algorithms = listOf("FREQ", "EWMA", "MKV1", "MSF")

    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "新建计划" else "编辑计划") },
        text = {
            Column {
                androidx.compose.material3.OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("计划名称") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(CaiTokens.S8))
                Text("类别", style = MaterialTheme.typography.labelMedium)
                Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = CaiTokens.S4)) {
                    categories.forEach { c ->
                        FilterChip(
                            selected = category == c,
                            onClick = { category = c },
                            label = { Text(c) },
                            modifier = Modifier.padding(end = CaiTokens.S4)
                        )
                    }
                }
                Spacer(Modifier.height(CaiTokens.S8))
                Text("算法", style = MaterialTheme.typography.labelMedium)
                Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = CaiTokens.S4)) {
                    algorithms.forEach { a ->
                        FilterChip(
                            selected = algorithm == a,
                            onClick = { algorithm = a },
                            label = { Text(a) },
                            modifier = Modifier.padding(end = CaiTokens.S4)
                        )
                    }
                }
                Spacer(Modifier.height(CaiTokens.S8))
                androidx.compose.material3.OutlinedTextField(
                    value = window,
                    onValueChange = { window = it.filter { ch -> ch.isDigit() }.take(4) },
                    label = { Text("窗口期数(≥5)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Spacer(Modifier.height(CaiTokens.S8))
                androidx.compose.material3.OutlinedTextField(
                    value = cyclePeriods,
                    onValueChange = { cyclePeriods = it.filter { ch -> ch.isDigit() }.take(2) },
                    label = { Text("计划周期（期）") },
                    supportingText = { Text("手动设置 1～20 期；周期用于计划执行与战绩分组") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Spacer(Modifier.height(CaiTokens.S4))
                Row(Modifier.fillMaxWidth(), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Text("参与共识", modifier = Modifier.weight(1f))
                    androidx.compose.material3.Switch(
                        checked = consensusOn,
                        onCheckedChange = { consensusOn = it }
                    )
                }
            }
        },
        confirmButton = {
            androidx.compose.material3.TextButton(
                enabled = name.isNotBlank() && (window.toIntOrNull() ?: 0) >= 5 && (cyclePeriods.toIntOrNull() ?: 0) in 1..20,
                onClick = {
                    val win = (window.toIntOrNull() ?: 30).coerceAtLeast(5)
                    val cycle = (cyclePeriods.toIntOrNull() ?: 1).coerceIn(1, 20)
                    val now = System.currentTimeMillis()
                    val plan = initial?.copy(
                        planName = name.trim(),
                        category = category,
                        algorithm = algorithm,
                        window = win,
                        cyclePeriods = cycle,
                        participateConsensus = consensusOn,
                        updatedAt = now
                    ) ?: com.caifenxi.app.domain.model.CustomPlan(
                        planId = com.caifenxi.app.domain.model.CustomPlan.ID_PREFIX +
                            lotteryKey + "-" + now.toString(16),
                        lotteryKey = lotteryKey,
                        planName = name.trim(),
                        category = category,
                        algorithm = algorithm,
                        window = win,
                        cyclePeriods = cycle,
                        participateConsensus = consensusOn
                    )
                    onSave(plan)
                }
            ) { Text("保存") }
        },
        dismissButton = {
            androidx.compose.material3.TextButton(onClick = onDismiss) { Text("取消") }
        }
    )
}

@Composable
private fun StatCell(label: String, value: String, color: Color = Color.Unspecified) {
    Column(horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally) {
        Text(
            value,
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.titleMedium,
            color = if (color == Color.Unspecified) MaterialTheme.colorScheme.onSurface else color
        )
        CaptionMuted(label)
    }
}

@Composable
private fun ConsensusWindowRate(title: String, hitRate: Double, missRate: Double, windows: Int) {
    Column(Modifier.padding(vertical = 4.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text("样本窗口 $windows 个")
        }
        Spacer(Modifier.height(CaiTokens.S4))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("窗口内至少对 1 次", color = Color(0xFF2E7D32), fontSize = 13.sp)
            Text(
                if (windows > 0) "${(hitRate * 100).roundToInt()}%" else "-",
                fontWeight = FontWeight.Bold,
                color = Color(0xFF2E7D32),
                fontSize = 13.sp
            )
        }
        LinearProgressIndicator(
            progress = { hitRate.toFloat().coerceIn(0f, 1f) },
            modifier = Modifier.fillMaxWidth(),
            color = Color(0xFF2E7D32)
        )
        Spacer(Modifier.height(CaiTokens.S4))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("窗口内全错", color = Color(0xFFC62828), fontSize = 13.sp)
            Text(
                if (windows > 0) "${(missRate * 100).roundToInt()}%" else "-",
                fontWeight = FontWeight.Bold,
                color = Color(0xFFC62828),
                fontSize = 13.sp
            )
        }
        LinearProgressIndicator(
            progress = { missRate.toFloat().coerceIn(0f, 1f) },
            modifier = Modifier.fillMaxWidth(),
            color = Color(0xFFC62828)
        )
    }
}

@Composable
private fun PlanTrendChart(
    name: String,
    points: List<Double>,
    modifier: Modifier = Modifier
) {
    Column(modifier) {
        Text(name, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        if (points.size < 2) {
            CaptionMuted("样本不足，暂时没有趋势曲线")
            return@Column
        }
        // Canvas 的 draw 作用域不是 @Composable，颜色必须在外部读取
        val lineColor = MaterialTheme.colorScheme.primary
        val baselineColor = MaterialTheme.colorScheme.outlineVariant
        Canvas(Modifier.fillMaxSize()) {
            val minV = (points.minOrNull() ?: 0.0).coerceAtMost(50.0)
            val maxV = (points.maxOrNull() ?: 100.0).coerceAtLeast(50.0)
            val span = (maxV - minV).coerceAtLeast(1.0)
            val path = Path()
            points.forEachIndexed { index, value ->
                val x = size.width * index / (points.size - 1).coerceAtLeast(1)
                val y = size.height - ((value - minV) / span).toFloat() * size.height
                if (index == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            drawPath(path, color = lineColor, style = androidx.compose.ui.graphics.drawscope.Stroke(width = 3f))
            val baseY = size.height - ((50.0 - minV) / span).toFloat() * size.height
            drawLine(
                color = baselineColor,
                start = androidx.compose.ui.geometry.Offset(0f, baseY.coerceIn(0f, size.height)),
                end = androidx.compose.ui.geometry.Offset(size.width, baseY.coerceIn(0f, size.height)),
                strokeWidth = 1f
            )
        }
    }
}

@Composable
private fun PlanCard(
    def: PlanDefinition,
    rt: PlanRuntime,
    currentPreds: List<PlanPredictionRecord>,
    history: List<PlanPredictionRecord>,
    expanded: Boolean,
    showHistory: Boolean,
    onToggle: () -> Unit
) {
    GlobalCard(onClick = onToggle) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column(Modifier.weight(1f)) {
                Text(def.planName, fontWeight = FontWeight.Bold)
                CaptionMuted("${def.category} · ${def.algorithm} · 窗${def.window}")
                val curOut = currentPreds.firstOrNull()?.output ?: rt.lastPrediction
                if (curOut != null && !showHistory) {
                    Text(
                        "当期：${curOut}" + (currentPreds.firstOrNull()?.targetIssue?.let { " → 第${it}期" } ?: ""),
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.secondary
                    )
                }
            }
            Column(horizontalAlignment = androidx.compose.ui.Alignment.End) {
                Text(rt.hitRatePercent, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
                CaptionMuted(if (expanded) "收起" else "详情")
            }
        }
        if (rt.sampleCount > 0) {
            LinearProgressIndicator(
                progress = { rt.hitRate.toFloat().coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth().padding(top = CaiTokens.S4),
                color = MaterialTheme.colorScheme.secondary
            )
        }
        AnimatedVisibility(visible = expanded) {
            Column(Modifier.padding(top = CaiTokens.S12)) {
                DetailLine("ID", def.planId)
                DetailLine("参数", "${def.category}/${def.algorithm}/窗${def.window}")
                DetailLine("战绩", "对 ${rt.hitCount}/${rt.sampleCount} · ${rt.hitRatePercent}")
                DetailLine("综合评分", "%.1f · 权重 %.3f (%+.3f)".format(rt.score, rt.weight, rt.weightDelta))
                DetailLine("滚动命中", "10期 %.1f%% · 50期 %.1f%% · 200期 %.1f%%".format(rt.recent10Rate * 100, rt.recent50Rate * 100, rt.recent200Rate * 100))
                DetailLine("连中/连错", "当前 ${rt.consecutiveHit}/${rt.consecutiveMiss} · 最大 ${rt.maxConsecutiveHit}/${rt.maxConsecutiveMiss}")
                DetailLine("基准优势", "%+.1f%%".format(rt.baselineEdge * 100))
                if (!showHistory) {
                    Text("当期预测", fontWeight = FontWeight.SemiBold)
                    val cur = currentPreds.ifEmpty {
                        rt.lastPrediction?.let {
                            listOf(
                                PlanPredictionRecord(
                                    planId = def.planId, lotteryKey = "",
                                    targetIssue = rt.lastTargetIssue ?: "-", cutoffIssue = "-",
                                    output = it, scoreAtPredict = rt.score, weightAtPredict = rt.weight,
                                    planName = def.planName, category = def.category
                                )
                            )
                        } ?: emptyList()
                    }
                    if (cur.isEmpty()) CaptionMuted("暂无")
                    else cur.forEach { rec ->
                        Text("第${rec.targetIssue}期 → ${rec.output}", fontWeight = FontWeight.Medium)
                    }
                }
                if (showHistory) {
                    Text("历史预测与结果", fontWeight = FontWeight.SemiBold)
                    if (history.isEmpty()) CaptionMuted("尚无已结算历史")
                    else history.forEach { rec ->
                        val tag = when (rec.hit) { true -> "对"; false -> "错"; null -> "—" }
                        val color = when (rec.hit) {
                            true -> Color(0xFF2E7D32)
                            false -> Color(0xFFC62828)
                            null -> MaterialTheme.colorScheme.onSurfaceVariant
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("第${rec.targetIssue}期 「${rec.output}」")
                            Text(tag, fontWeight = FontWeight.Bold, color = color)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DetailLine(k: String, v: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(k, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(v, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
    }
}
