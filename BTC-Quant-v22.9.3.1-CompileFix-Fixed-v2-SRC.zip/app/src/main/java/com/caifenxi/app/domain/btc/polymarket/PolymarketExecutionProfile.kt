package com.caifenxi.app.domain.btc.polymarket

/** Execution protocol/profile selected before a CLOB write. */
enum class PolymarketSignatureType(val wire: Int) {
    EOA(0),
    POLY_PROXY(1),
    GNOSIS_SAFE(2),
    POLY_1271(3)
}

enum class PolymarketOrderProtocol { V1, V2, V3, UNKNOWN }

data class PolymarketExecutionProfile(
    val protocol: PolymarketOrderProtocol,
    val signatureType: PolymarketSignatureType,
    val funderAddress: String,
    val signerAddress: String,
    val liveReady: Boolean,
    val reason: String
)
