package com.caifenxi.app.data.repository

import com.caifenxi.app.data.api.LotteryApiClient
import com.caifenxi.app.data.config.ConfigStore
import com.caifenxi.app.data.db.dao.DrawDao
import com.caifenxi.app.data.db.entity.DrawEntity
import com.caifenxi.app.domain.model.ApiConfig
import com.caifenxi.app.domain.model.DrawRecord
import com.caifenxi.app.domain.model.LotteryBetRules
import com.caifenxi.app.domain.model.LotteryConfig
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

class DrawRepository(
    private val api: LotteryApiClient,
    private val drawDao: DrawDao,
    private val configStore: ConfigStore
) {
    private val json = Json { encodeDefaults = true }

    /** 全量本地缓存(仅导出/迁移等场景使用,日常勿用) */
    suspend fun getLocalHistory(key: String): List<DrawRecord> =
        drawDao.getByLottery(key).map { it.toDomain() }

    /**
     * 工作窗口:只取最新 [limit] 期,升序。
     * 避免 8000+ 条全量加载导致超时与「同步失败」。
     */
    suspend fun getWorkingHistory(
        key: String,
        limit: Int = ApiConfig.WORKING_HISTORY_LIMIT
    ): List<DrawRecord> {
        if (limit <= 0) return getLocalHistory(key)
        return drawDao.getRecentDesc(key, limit).asReversed().map { it.toDomain() }
    }

    suspend fun countLocal(key: String): Int = drawDao.countByLottery(key)

    /** 历史分页：倒序读取指定页，页面层可按需加载更多。 */
    suspend fun getHistoryPage(key: String, page: Int, pageSize: Int = 100): List<DrawRecord> {
        val safePage = page.coerceAtLeast(0)
        val safeSize = pageSize.coerceIn(20, 200)
        return drawDao.getPageDesc(key, safeSize, safePage * safeSize).map { it.toDomain() }
    }

    /** 写入/更新单期开奖(心跳与前台服务用) */
    suspend fun cacheDraw(record: DrawRecord) {
        // 写库前统一按当前彩种规则补全 dx/ds/combo，保证计划/回测读取到同一口径。
        drawDao.upsertAll(listOf(LotteryBetRules.enrich(record).toEntity()))
    }

    /**
     * 缓存优先：网络合并后返回**工作窗口**(非全库)。
     * @return Triple(工作窗口数据, 来源说明, 库内总条数)
     */
    suspend fun fetchAndCacheHistory(
        config: LotteryConfig,
        days: Int = ApiConfig.DEFAULT_HISTORY_DAYS,
        workLimit: Int = ApiConfig.WORKING_HISTORY_LIMIT
    ): Triple<List<DrawRecord>, String, Int> {
        val totalBefore = drawDao.countByLottery(config.key)
        val localWork = getWorkingHistory(config.key, workLimit)
        return try {
            val remote = api.fetchHistory(config, days)
            if (remote.isNotEmpty()) {
                drawDao.upsertAll(remote.map { it.toEntity() })
                val total = drawDao.countByLottery(config.key)
                val work = getWorkingHistory(config.key, workLimit)
                val source = if (totalBefore == 0) "网络" else "缓存+网络"
                Triple(work, source, total)
            } else {
                val total = drawDao.countByLottery(config.key)
                if (localWork.isNotEmpty()) {
                    Triple(localWork, "缓存（网络无新数据）", total)
                } else {
                    Triple(emptyList(), "网络返回空", total)
                }
            }
        } catch (e: Exception) {
            val total = drawDao.countByLottery(config.key)
            if (localWork.isNotEmpty() || total > 0) {
                val work = if (localWork.isNotEmpty()) localWork else getWorkingHistory(config.key, workLimit)
                Triple(work, "缓存（网络失败: ${e.message?.take(40)}）", total)
            } else {
                throw e
            }
        }
    }

    private fun DrawRecord.toEntity() = DrawEntity(
        lotteryKey = lotteryKey,
        issue = issue,
        drawTime = drawTime,
        numbersJson = json.encodeToString(numbers),
        sum = sum,
        dx = dx,
        ds = ds,
        combo = combo,
        extra = extra,
        nextIssue = nextIssue
    )

    private fun DrawEntity.toDomain(): DrawRecord {
        val nums = try {
            json.decodeFromString<List<Int>>(numbersJson)
        } catch (_: Exception) {
            emptyList()
        }
        val raw = DrawRecord(
            lotteryKey = lotteryKey,
            issue = issue,
            drawTime = drawTime,
            numbers = nums,
            sum = sum,
            dx = dx,
            ds = ds,
            combo = combo,
            extra = extra,
            nextIssue = nextIssue
        )
        // 按彩种规则重算大小/单双/组合，避免历史缓存混用「总和」口径
        return LotteryBetRules.enrich(raw)
    }
}
