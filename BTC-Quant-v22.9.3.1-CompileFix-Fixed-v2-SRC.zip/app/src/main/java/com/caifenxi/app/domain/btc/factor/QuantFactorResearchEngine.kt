package com.caifenxi.app.domain.btc.factor

import com.caifenxi.app.domain.btc.BtcCandle
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * Factor research layer. It evaluates factor-vs-forward-return relationship on
 * a historical slice without allowing observations to use future candles.
 */
object QuantFactorResearchEngine {
    data class Metric(
        val factorId: String,
        val samples: Int,
        val ic: Double,
        val hitRate: Double,
        val meanAbs: Double,
        val stability: Double,
        val score: Double,
        val icir: Double = 0.0,
        val firstIc: Double = 0.0,
        val secondIc: Double = 0.0,
        val pLike: Double = 0.0
    )

    fun walkForward(
        candles: List<BtcCandle>,
        forwardBars: Int = 3,
        step: Int = 1,
        startIndex: Int = 60,
        endIndexExclusive: Int = candles.size
    ): List<Metric> {
        if (candles.size < startIndex + forwardBars + 5) return emptyList()
        val end = endIndexExclusive.coerceAtMost(candles.size - forwardBars)
        val rows = mutableMapOf<String, MutableList<Pair<Double, Double>>>()
        var i = startIndex
        while (i < end) {
            val history = candles.subList(0, i + 1)
            val snapshot = QuantFactorEngine.calculate(history)
            if (snapshot == null) {
                i += step
                continue
            }
            val base = candles[i].close
            val future = candles[i + forwardBars].close
            val forwardReturn = if (base == 0.0) 0.0 else (future - base) / base
            snapshot.factors.forEach { f -> rows.getOrPut(f.id) { mutableListOf() }.add(f.normalized to forwardReturn) }
            i += step.coerceAtLeast(1)
        }
        return rows.map { (id, pairs) ->
            val x = pairs.map { it.first }
            val y = pairs.map { it.second }
            val ic = pearson(x, y)
            val hit = if (pairs.isEmpty()) 0.0 else pairs.count { (a, b) -> a == 0.0 || b == 0.0 || a * b > 0.0 }.toDouble() / pairs.size
            val meanAbs = x.map(::abs).average().coerceAtMost(1.0)
            val half = pairs.size / 2
            val firstIc = if (half >= 4) pearson(x.take(half), y.take(half)) else 0.0
            val secondIc = if (pairs.size - half >= 4) pearson(x.drop(half), y.drop(half)) else 0.0
            val stability = (1.0 - abs(firstIc - secondIc)).coerceIn(0.0, 1.0)
            val score = (abs(ic) * 0.55 + abs(hit - 0.5) * 0.30 + stability * 0.15) * meanAbs.coerceAtLeast(0.1)
            val chunk = maxOf(4, pairs.size / 5)
            val foldIcs = pairs.chunked(chunk).filter { it.size >= 4 }.map { fold -> pearson(fold.map { it.first }, fold.map { it.second }) }
            val icMean = foldIcs.average().takeIf { it.isFinite() } ?: 0.0
            val icStd = if (foldIcs.size < 2) 0.0 else sqrt(foldIcs.map { (it - icMean) * (it - icMean) }.average())
            val icir = if (icStd <= 1e-9) abs(icMean) * sqrt(foldIcs.size.toDouble().coerceAtLeast(1.0)) else abs(icMean) / icStd * sqrt(foldIcs.size.toDouble())
            val pLike = if (pairs.size < 8) 0.0 else (abs(ic) * sqrt(pairs.size.toDouble())).coerceIn(0.0, 1.0)
            Metric(id, pairs.size, ic, hit, meanAbs, stability, score, icir, firstIc, secondIc, pLike)
        }.sortedByDescending { it.score }
    }

    private fun pearson(x: List<Double>, y: List<Double>): Double {
        if (x.size != y.size || x.size < 3) return 0.0
        val mx = x.average(); val my = y.average()
        var num = 0.0; var dx = 0.0; var dy = 0.0
        for (i in x.indices) {
            val a = x[i] - mx; val b = y[i] - my
            num += a * b; dx += a * a; dy += b * b
        }
        val den = sqrt(dx * dy)
        return if (den <= 1e-12) 0.0 else (num / den).coerceIn(-1.0, 1.0)
    }
}
