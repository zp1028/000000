package com.caifenxi.app.domain.btc.polymarket.strategy

import com.caifenxi.app.domain.btc.BtcCandle
import com.caifenxi.app.domain.btc.TradingSignal
import com.caifenxi.app.domain.btc.factor.QuantFactorEngine
import com.caifenxi.app.domain.btc.factor.QuantFactorWeightStore
import com.caifenxi.app.domain.btc.BtcRegimeEngine
import com.caifenxi.app.domain.btc.portfolio.AdaptiveRegimeWeightEngine
import com.caifenxi.app.domain.btc.polymarket.PolyMarket
import com.caifenxi.app.domain.btc.polymarket.PolyOrderBook

/**
 * Automatic Polymarket decision engine.
 * Data -> factors -> independent strategies -> ranked edge -> execution ticket.
 * It never calls a broker itself; the runtime/execution gate owns the final action.
 */
class PolymarketAutoQuantEngine(
    private val pool: PolymarketStrategyPool = PolymarketStrategyPool,
    private val factorWeights: QuantFactorWeightStore? = null
) {
    data class Result(
        val factorSnapshot: QuantFactorEngine.Snapshot?,
        val candidates: List<PolymarketStrategyPool.Signal>,
        val best: PolymarketStrategyPool.Signal?,
        val autoEligible: Boolean,
        val reason: String
    )

    fun evaluate(
        candles: List<BtcCandle>,
        market: PolyMarket,
        yesBook: PolyOrderBook,
        noBook: PolyOrderBook?,
        deriv: com.caifenxi.app.domain.btc.DerivativesFeatures? = null,
        externalModelYes: Double? = null,
        minEdge: Double = 0.05,
        maxSpread: Double = 0.08,
        minLiquidity: Double = 0.25,
        currentBtc: Double? = candles.lastOrNull()?.close,
        nowMs: Long = System.currentTimeMillis()
    ): Result {
        val factors = QuantFactorEngine.calculate(candles, deriv)
            ?: return Result(null, emptyList(), null, false, "因子样本不足")
        val btcReturn15m = QuantFactorEngine.pctChange(candles.map { it.close }, 3)
        val volumeRatio = run {
            val v = candles.map { it.volume }
            if (v.size < 40) 1.0 else v.takeLast(20).average() / v.dropLast(20).takeLast(20).average().coerceAtLeast(1e-9)
        }
        val regime = AdaptiveRegimeWeightEngine.classify(BtcRegimeEngine().detect(candles))
        val candidates = pool.evaluate(
            market = market,
            yesBook = yesBook,
            noBook = noBook,
            factors = factors,
            externalModelYes = externalModelYes,
            currentBtc = currentBtc,
            nowMs = nowMs,
            btcReturn15m = btcReturn15m,
            volumeRatio = volumeRatio
        ).filter { it.edge >= minEdge && it.spread <= maxSpread && it.liquidity >= minLiquidity }
        val weighted = candidates.map { c ->
            val familyFactor = when {
                c.strategyId.contains("MOMENTUM") -> "MOMENTUM-COMPOSITE"
                c.strategyId.contains("MEAN-REVERT") || c.strategyId.contains("CONVERGENCE") -> "MEAN-REVERSION"
                c.strategyId.contains("ORDERBOOK") -> "DERIVATIVES-COMPOSITE"
                c.strategyId.contains("FUNDING") || c.strategyId.contains("OI") -> "DERIVATIVES-COMPOSITE"
                c.strategyId.contains("BINANCE") -> "CROSS-MARKET"
                else -> "TREND-COMPOSITE"
            }
            val q = factorWeights?.weight(familyFactor, 1.0) ?: 1.0
            val regimeMultiplier = AdaptiveRegimeWeightEngine.strategyMultiplier(c.strategyId, c.direction, regime.regime)
            c.copy(score = c.score * (0.70 + 0.30 * q) * regimeMultiplier, reason = "${c.reason}; ${regime.reason}")
        }.sortedByDescending { it.score }
        val best = weighted.firstOrNull()
        val eligible = best != null && regime.multiplier > 0.0
        return Result(
            factorSnapshot = factors,
            candidates = weighted,
            best = best,
            autoEligible = eligible,
            reason = if (best == null) "没有通过 edge/spread/liquidity 自动执行门槛" else if (!eligible) "regime风险门关闭" else "${best.strategyId} ${best.outcome} edge=${"%.3f".format(best.edge)}"
        )
    }

    fun toExecutionSignal(best: PolymarketStrategyPool.Signal, size: Double = 10.0): TradingSignal.PredictionMarketSignal =
        TradingSignal.PredictionMarketSignal(
            venue = "POLYMARKET",
            marketId = best.marketId,
            outcome = best.outcome,
            marketPrice = best.marketPrice,
            modelProbability = best.modelProbability,
            edge = best.edge,
            expectedValue = best.edge,
            liquidityScore = best.liquidity,
            spread = best.spread,
            timeToResolutionSec = 0L,
            action = "BUY",
            strategyId = best.strategyId,
            positionSize = size
        )
}
