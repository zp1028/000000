package com.caifenxi.app.domain.btc.runtime

import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap

/** Persistent-process event ordering/deduplication projection for Binance private events. */
class BinancePrivateEventLedger(private val maxEntries: Int = 2000) {
    data class Result(val accepted: Boolean, val duplicate: Boolean, val stale: Boolean, val reason: String)
    private val seen = ConcurrentHashMap<String, Long>()
    private data class Cursor(var eventTime: Long = 0L, var transactionTime: Long = 0L)
    private val cursors = mutableMapOf<String, Cursor>()
    @Volatile private var lastEventTime = 0L
    @Volatile private var lastTransactionTime = 0L

    @Synchronized fun accept(eventType: String, eventTime: Long, transactionTime: Long, raw: String): Result {
        val hash = sha256(raw)
        if (seen.containsKey(hash)) return Result(false, true, false, "duplicate")
        val cursor = cursors.getOrPut(eventType) { Cursor() }
        // Ordering is scoped per event type. ORDER_TRADE_UPDATE and ACCOUNT_UPDATE
        // are independent streams; a global timestamp cursor can incorrectly drop
        // valid events from the slower stream.
        if (eventTime < cursor.eventTime || transactionTime < cursor.transactionTime) {
            return Result(false, false, true, "out_of_order:$eventType")
        }
        seen[hash] = eventTime
        cursor.eventTime = maxOf(cursor.eventTime, eventTime)
        cursor.transactionTime = maxOf(cursor.transactionTime, transactionTime)
        lastEventTime = maxOf(lastEventTime, eventTime)
        lastTransactionTime = maxOf(lastTransactionTime, transactionTime)
        trim()
        return Result(true, false, false, "accepted")
    }

    @Synchronized fun reset() { seen.clear(); cursors.clear(); lastEventTime = 0L; lastTransactionTime = 0L }

    private fun trim() {
        if (seen.size <= maxEntries) return
        val remove = seen.entries.sortedBy { it.value }.take(seen.size - maxEntries)
        remove.forEach { seen.remove(it.key) }
    }

    private fun sha256(value: String): String = MessageDigest.getInstance("SHA-256").digest(value.toByteArray()).joinToString("") { "%02x".format(it) }
}
