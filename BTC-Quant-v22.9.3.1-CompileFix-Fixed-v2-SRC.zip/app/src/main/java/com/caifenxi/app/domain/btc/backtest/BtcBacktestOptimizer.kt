package com.caifenxi.app.domain.btc.backtest

import com.caifenxi.app.domain.btc.BtcCandle

/** Small deterministic grid optimizer inspired by hyperopt-style research loops. */
object BtcBacktestOptimizer {
    data class Grid(
        val riskPerTradePct: List<Double> = listOf(0.25, 0.5, 0.75),
        val maxHoldingBars: List<Int> = listOf(6, 12, 24),
        val slippagePct: List<Double> = listOf(0.01, 0.02, 0.04),
        val spreadPct: List<Double> = listOf(0.005, 0.01, 0.02)
    )

    fun optimize(
        engine: BtcBacktestEngine,
        planId: String,
        candles: List<BtcCandle>,
        base: BacktestConfig = BacktestConfig(),
        grid: Grid = Grid(),
        topK: Int = 10
    ): List<BacktestOptimizationResult> {
        val out = mutableListOf<BacktestOptimizationResult>()
        for (risk in grid.riskPerTradePct) for (hold in grid.maxHoldingBars) for (slip in grid.slippagePct) for (spread in grid.spreadPct) {
            val cfg = base.copy(riskPerTradePct = risk, maxHoldingBars = hold, slippagePct = slip, spreadPct = spread)
            val wfo = engine.walkForward(planId, candles, cfg)
            if (wfo.isEmpty()) continue
            val sample = wfo.sumOf { it.sampleSize }
            val ret = wfo.sumOf { it.totalReturnPct }
            val dd = wfo.maxOf { it.maxDrawdownPct }
            val pf = wfo.map { it.profitFactor }.average()
            val score = ret * (0.5 + (pf.coerceAtMost(2.0) / 2.0)) - dd * 0.75 + sample * 0.002
            val aggregate = wfo.last().copy(
                totalReturnPct = ret,
                maxDrawdownPct = dd,
                sampleSize = sample,
                profitFactor = pf
            )
            out += BacktestOptimizationResult(cfg, aggregate, score)
        }
        return out.sortedByDescending { it.objectiveScore }.take(topK.coerceIn(1, 50))
    }
}
