package com.caifenxi.app.service

import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.ServiceCompat
import com.caifenxi.app.CaiFenXiApplication
import com.caifenxi.app.domain.engine.ConsensusEngine
import com.caifenxi.app.domain.engine.PredictEngine
import com.caifenxi.app.domain.engine.StatsEngine
import com.caifenxi.app.domain.model.LotteryConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeout

/**
 * 前台服务：后台保活拉最新开奖。
 * 新期会落库、结算,并生成下一期计划预测与共识(避免仅心跳「已存在」时跳过导致共识空白)。
 */
class DataSyncService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null
    private var lastIssue: String? = null
    private var failStreak = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = NotificationHelper.buildForeground(this, "正在监听开奖…")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ServiceCompat.startForeground(
                this, 1001, notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
            )
        } else {
            startForeground(1001, notification)
        }
        job?.cancel()
        job = scope.launch {
            val app = CaiFenXiApplication.instance
            while (isActive) {
                try {
                    val prefs = app.configStore.loadPrefs()
                    val key = prefs.selectedLotteryKey
                    val cfg = LotteryConfig.findByKey(key) ?: LotteryConfig.CATALOG.first()
                    withTimeout(20_000) {
                        val latest = app.apiClient.fetchLatest(cfg)
                        if (latest != null && latest.issue != lastIssue) {
                            // 落库
                            app.drawRepository.cacheDraw(latest)
                            // 结算(幂等:仅待开会变)
                            StatsEngine.settleWithDraw(app.statStore, key, latest)
                            ConsensusEngine.settleWithDraw(app.consensusStore, key, latest)
                            app.planEngine.settlePendingWithDraw(latest, prefs.backtestParams)
                            app.betEngine.settleWithDraw(key, latest)

                            // 生成下一期计划预测 + 共识并持久化
                            val history = app.drawRepository.getLocalHistory(key)
                            if (history.isNotEmpty()) {
                                val cutoff = history.last().issue
                                val target = history.last().nextIssue
                                    ?.takeIf { it.isNotBlank() && it != cutoff }
                                    ?: PredictEngine.suggestNextIssue(cutoff)
                                val preds = app.planEngine.predictForNext(history, prefs, target, cutoff)
                                if (preds.isNotEmpty()) {
                                    val cons = app.planEngine.consensus(key, target, preds)
                                    if (cons.isNotEmpty()) {
                                        ConsensusEngine.recordPending(app.consensusStore, key, target, cons)
                                    }
                                }
                            }

                            if (lastIssue != null) {
                                val summary = listOfNotNull(latest.dx, latest.ds, latest.combo)
                                    .joinToString(" ") + " " + latest.numbers.take(5).joinToString(",")
                                NotificationHelper.notifyNewDraw(
                                    this@DataSyncService,
                                    latest.issue,
                                    summary
                                )
                            }
                            lastIssue = latest.issue
                            failStreak = 0
                        }
                    }
                } catch (_: Exception) {
                    failStreak++
                }
                val wait = when {
                    failStreak >= 5 -> 90_000L
                    failStreak >= 2 -> 50_000L
                    else -> 40_000L
                }
                delay(wait)
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        job?.cancel()
        super.onDestroy()
    }
}
