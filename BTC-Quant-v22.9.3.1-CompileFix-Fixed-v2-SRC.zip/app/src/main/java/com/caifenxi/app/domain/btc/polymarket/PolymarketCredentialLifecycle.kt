package com.caifenxi.app.domain.btc.polymarket

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.math.BigInteger
import java.util.concurrent.TimeUnit

/**
 * Explicit L1 -> L2 credential lifecycle for an EOA CLOB account.
 *
 * This class deliberately does not auto-create credentials during an order tick.
 * Credential provisioning is an operator action, so a transient network failure
 * cannot accidentally turn into repeated auth creation attempts.
 *
 * POLY_1271/deposit-wallet authentication is not guessed here: current public
 * SDKs have an unresolved L1-auth/API-key binding mismatch for those accounts.
 */
class PolymarketCredentialLifecycle(
    private val privateKey: String,
    private val address: String,
    private val baseUrl: String = "https://clob.polymarket.com",
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()
) {
    data class ApiCredentials(
        val apiKey: String,
        val secret: String,
        val passphrase: String
    )

    data class ProvisionResult(
        val ok: Boolean,
        val credentials: ApiCredentials? = null,
        val created: Boolean = false,
        val message: String = ""
    )

    suspend fun createOrDerive(nonce: BigInteger = BigInteger.ZERO): ProvisionResult = withContext(Dispatchers.IO) {
        val signer = runCatching { PolymarketEip712Signer.deriveAddress(privateKey) }.getOrElse {
            return@withContext ProvisionResult(false, message = "invalid EOA private key: ${it.message}")
        }
        if (!signer.equals(address, ignoreCase = true)) {
            return@withContext ProvisionResult(false, message = "private key address does not match POLY_ADDRESS")
        }
        val ts = System.currentTimeMillis() / 1000L
        val sig = PolymarketEip712Signer.signClobAuth(privateKey, ts, nonce, 137L)
        val headers = mapOf(
            "POLY_ADDRESS" to signer,
            "POLY_SIGNATURE" to sig,
            "POLY_TIMESTAMP" to ts.toString(),
            "POLY_NONCE" to nonce.toString(),
            "Accept" to "application/json"
        )

        val create = request("POST", "/auth/api-key", headers)
        if (create.first) {
            parseCredentials(create.second)?.let {
                return@withContext ProvisionResult(true, it, created = true, message = "CLOB API credentials created")
            }
        }

        val derive = request("GET", "/auth/derive-api-key", headers)
        if (derive.first) {
            parseCredentials(derive.second)?.let {
                return@withContext ProvisionResult(true, it, created = false, message = "CLOB API credentials derived")
            }
        }

        ProvisionResult(
            false,
            message = "credential provisioning failed; create=${create.third}, derive=${derive.third}"
        )
    }

    private fun request(method: String, path: String, headers: Map<String, String>): Triple<Boolean, String, String> {
        return runCatching {
            val b = Request.Builder().url(baseUrl.trimEnd('/') + path)
            headers.forEach { (k, v) -> b.header(k, v) }
            b.method(method, null)
            client.newCall(b.build()).execute().use { response ->
                val text = response.body?.string().orEmpty()
                Triple(response.isSuccessful, text, "HTTP ${response.code}: ${text.take(240)}")
            }
        }.getOrElse { Triple(false, "", it.message ?: "network error") }
    }

    private fun parseCredentials(raw: String): ApiCredentials? = runCatching {
        val o = JSONObject(raw)
        val key = o.optString("apiKey").ifBlank { o.optString("api_key") }
        val secret = o.optString("secret").ifBlank { o.optString("apiSecret") }
        val pass = o.optString("passphrase").ifBlank { o.optString("apiPassphrase") }
        if (key.isBlank() || secret.isBlank() || pass.isBlank()) null
        else ApiCredentials(key, secret, pass)
    }.getOrNull()
}
