package com.caifenxi.app.domain.btc.hs

import kotlin.math.exp
import kotlin.math.ln

/** Small-data safe calibration: Platt scaling and PAVA isotonic regression with holdout selection. */
object BtcProbabilityCalibrationEngine {
    data class Sample(val raw: Double, val outcome: Double)

    fun calibrate(raw: Double, samples: List<Sample>): Double {
        if (samples.size < 24) return raw.coerceIn(0.03, 0.97)
        val split = (samples.size * 0.70).toInt().coerceIn(12, samples.size - 8)
        val fit = samples.take(split); val eval = samples.drop(split)
        val platt = fitPlatt(raw, fit)
        val iso = fitIsotonic(raw, fit)
        val plattErr = eval.map { (plattFor(it.raw, fit) - it.outcome).let { e -> e * e } }.average()
        val isoErr = eval.map { (isotonicFor(it.raw, fit) - it.outcome).let { e -> e * e } }.average()
        return (if (isoErr <= plattErr) iso else platt).coerceIn(0.03, 0.97)
    }

    fun platt(raw: Double, samples: List<Sample>): Double = fitPlatt(raw, samples).coerceIn(0.03, 0.97)
    fun isotonic(raw: Double, samples: List<Sample>): Double = fitIsotonic(raw, samples).coerceIn(0.03, 0.97)

    private fun fitPlatt(raw: Double, samples: List<Sample>): Double {
        if (samples.size < 12) return raw
        var a = 1.0; var b = 0.0
        repeat(40) {
            var ga = 0.0; var gb = 0.0; var haa = 1e-4; var hab = 0.0; var hbb = 1e-4
            for (s in samples) {
                val x = ln(s.raw.coerceIn(1e-5, 1 - 1e-5) / (1 - s.raw.coerceIn(1e-5, 1 - 1e-5)))
                val p = sigmoid(a * x + b); val e = p - s.outcome; val w = (p * (1 - p)).coerceAtLeast(1e-5)
                ga += e * x; gb += e; haa += w * x * x; hab += w * x; hbb += w
            }
            val det = (haa * hbb - hab * hab).coerceAtLeast(1e-9)
            val da = (hbb * ga - hab * gb) / det; val db = (-hab * ga + haa * gb) / det
            a = (a - da).coerceIn(-8.0, 8.0); b = (b - db).coerceIn(-8.0, 8.0)
        }
        val x = ln(raw.coerceIn(1e-5, 1 - 1e-5) / (1 - raw.coerceIn(1e-5, 1 - 1e-5)))
        return sigmoid(a * x + b)
    }

    private fun plattFor(raw: Double, samples: List<Sample>): Double = fitPlatt(raw, samples)

    private fun fitIsotonic(raw: Double, samples: List<Sample>): Double {
        if (samples.size < 8) return raw
        val sorted = samples.sortedBy { it.raw }
        val blocks = mutableListOf<MutableList<Sample>>()
        for (s in sorted) {
            blocks += mutableListOf(s)
            while (blocks.size >= 2 && blocks[blocks.lastIndex - 1].averageOutcome() > blocks.last().averageOutcome()) {
                val merged = mutableListOf<Sample>(); merged += blocks.removeAt(blocks.lastIndex - 1); merged += blocks.removeAt(blocks.lastIndex); blocks += merged
            }
        }
        val target = raw.coerceIn(0.0, 1.0)
        val block = blocks.firstOrNull { target <= it.last().raw } ?: blocks.last()
        return block.averageOutcome()
    }

    private fun isotonicFor(raw: Double, samples: List<Sample>): Double = fitIsotonic(raw, samples)
    private fun List<Sample>.averageOutcome(): Double = if (isEmpty()) 0.5 else map { it.outcome }.average()
    private fun sigmoid(x: Double): Double = 1.0 / (1.0 + exp(-x.coerceIn(-30.0, 30.0)))
}
