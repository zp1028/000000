package com.caifenxi.app.domain.btc.runtime

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ConcurrentLinkedDeque

/** Bounded persistent audit trail for runtime decisions/executions. */
class BtcExecutionAudit(context: Context? = null, private val maxEntries: Int = 500) {
    data class Entry(
        val at: Long = System.currentTimeMillis(),
        val decisionId: String,
        val executionId: String?,
        val stage: String,
        val outcome: String,
        val detail: String = ""
    )

    private val entries = ConcurrentLinkedDeque<Entry>()
    private val prefs = context?.applicationContext?.getSharedPreferences("btc_execution_audit_v2", Context.MODE_PRIVATE)

    init { load() }

    @Synchronized fun add(entry: Entry) {
        entries.addLast(entry)
        while (entries.size > maxEntries) entries.pollFirst()
        persist()
    }

    fun recent(limit: Int = 50): List<Entry> = entries.toList().takeLast(limit.coerceIn(1, maxEntries))

    @Synchronized fun clear() { entries.clear(); prefs?.edit()?.remove("entries")?.apply() }

    private fun load() { runCatching {
        val a=JSONArray(prefs?.getString("entries","[]") ?: "[]")
        for(i in 0 until a.length()) { val o=a.getJSONObject(i); entries.addLast(Entry(o.optLong("at"),o.getString("decision"),o.optString("execution").ifBlank{null},o.getString("stage"),o.getString("outcome"),o.optString("detail"))) }
        while(entries.size>maxEntries)entries.pollFirst()
    } }

    private fun persist() { val p=prefs?:return; val a=JSONArray(); entries.forEach{e->a.put(JSONObject().apply{put("at",e.at);put("decision",e.decisionId);put("execution",e.executionId);put("stage",e.stage);put("outcome",e.outcome);put("detail",e.detail)})}; p.edit().putString("entries",a.toString()).apply() }
}
