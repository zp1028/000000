# 彩析 CaiFenXi

Kotlin + Jetpack Compose。设计令牌：主色 #1A1A1A、香槟金 #C8A97E、浅底 #F8F8F8 / 深底 #0D0D0D；8pt 间距；卡片圆角 20；胶囊按钮；柔和阴影。

## 功能摘要
- 缓存优先拉数、主备 API、错误可解释
- 六种算法 + 手动标记 + 预测冻结
- 分析：频率/和值/大小单双/时段/路珠
- 战绩自动对错、计划池 40、实验室滚动验证
- 主题：跟随系统 / 浅 / 深

## 构建
Android Studio 打开本目录，或 Actions：`./gradlew assembleDebug`
