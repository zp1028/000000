# v12 修复说明 (2026-09-14)

## 问题
1. 看板大量图表静止不动
2. 决策页数据不刷新
3. 策略页分析周期无法切换
4. 回测结果一直为空（0 笔交易）

## 根因与修复

### 看板/决策静止 + 周期切不动
`BtcQuantViewModel.refresh()` 在「曾有 LIVE 快照 + 本次网络失败」时直接 return，导致 UI 永久冻结。
- 增加 90s 软超时：超时后允许 Demo 接管，看板恢复动态
- 保鲜期内仍支持从缓存切换 5m/15m/1h K 线
- `BtcDashboardState` 增加 candles5m/15m/1h 缓存
- Dashboard 本地 timeframe 与 ViewModel 同步
- 策略页周期仅保留实际支持的 5m/15m/1h
- Demo K 线种子按分钟变化，离线图表也会演变

### 回测永远为空
UI 使用的 planId（BTC-TREND 等）与 `BtcPlanRegistry` 真实 id（BTC-EMA-TREND 等）不一致，
`signals.firstOrNull { it.planId == planId }` 永远匹配失败。
- `enabledPlans` / `availablePlans` / 默认 planId 已与 Registry 对齐
- K 线不足时自动用 Demo 300 根跑回测
- 0 笔时给出明确提示

## 修改文件
- app/src/main/java/com/caifenxi/app/ui/BtcQuantViewModel.kt
- app/src/main/java/com/caifenxi/app/domain/btc/BtcModels.kt
- app/src/main/java/com/caifenxi/app/domain/btc/BtcDemoDataProvider.kt
- app/src/main/java/com/caifenxi/app/ui/screens/DashboardTab.kt
- app/src/main/java/com/caifenxi/app/ui/screens/StrategyTab.kt
