package com.caifenxi.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.CloudQueue
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.caifenxi.app.domain.btc.paper.BetDirection
import com.caifenxi.app.domain.btc.paper.EdgeAssessment
import com.caifenxi.app.domain.btc.paper.StakeSizingEngine
import com.caifenxi.app.domain.btc.runtime.BtcRunMode
import com.caifenxi.app.domain.btc.runtime.BtcRuntimeStatus
import com.caifenxi.app.ui.BtcQuantViewModel
import com.caifenxi.app.ui.theme.CaiTokens
import java.text.SimpleDateFormat
import java.util.Date

/**
 * 自动下注 Tab：二元期权自动下注执行台
 *
 * 功能：
 * - 当前 5 分钟周期信息 + 实时方向
 * - 执行台面板：Edge 评估 + 变动赔率 + 固定1U 下注 + 下单前确认卡
 * - 最近执行结果展示
 * - 下注账户概览
 * - 平台连接状态指示器（Polymarket / Binance）
 * - 自动下注配置（Paper/Polymarket/Binance）+ 挂机控制
 * - 下注日志
 */
@Composable
fun AutoTradeTab(viewModel: BtcQuantViewModel) {
    val state by viewModel.state.collectAsState()
    val runtimeState by viewModel.runtimeState.collectAsState()
    val runtimeConfig by viewModel.runtimeConfig.collectAsState()
    val tradeLog by viewModel.autoTradeLog.collectAsState()
    val currentRound by viewModel.currentRound.collectAsState()
    val binaryAccount by viewModel.binaryAccount.collectAsState()
    val stakePreview by viewModel.stakePreview.collectAsState()
    val edgeAssessment by viewModel.edgeAssessment.collectAsState()
    val platformStatus by viewModel.platformStatus.collectAsState()
    val lastExecution by viewModel.lastExecution.collectAsState()
    val dailyStats by viewModel.dailyStats.collectAsState()
    val exec by viewModel.executionStatus.collectAsState()
    val readiness by viewModel.readiness.collectAsState()
    val dailyControlConfig by viewModel.dailyControlConfig.collectAsState()
    val marketOddsList by viewModel.marketOddsList.collectAsState()

    // 共识或市场赔率变化时自动刷新 edge 评估
    LaunchedEffect(state.consensus?.direction, state.consensus?.probability, marketOddsList) {
        viewModel.previewStakeSizing()
    }
    LaunchedEffect(runtimeState.lastHeartbeatAt) {
        viewModel.refreshRuntimeState()
    }
    // 预测挂机：RUNNING 时按 pollSeconds 自动执行 Paper/自注一轮（页面在前台时）
    LaunchedEffect(runtimeState.status, runtimeConfig.pollSeconds, runtimeState.killSwitch) {
        if (runtimeState.status != BtcRuntimeStatus.RUNNING || runtimeState.killSwitch) return@LaunchedEffect
        while (true) {
            runCatching {
                viewModel.refresh()
                viewModel.previewStakeSizing()
                viewModel.executeAutoTradeTick()
            }
            val sec = runtimeConfig.pollSeconds.coerceIn(10L, 120L)
            kotlinx.coroutines.delay(sec * 1000L)
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
    ) {

    // 生产就绪条
    Card(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A22))
    ) {
        Column(Modifier.padding(12.dp)) {
            val readyLive = readiness?.readyForLive == true
            val readyPaper = readiness?.readyForPaper == true
            Text(
                when {
                    exec.killSwitch -> "KILL SWITCH — 禁止下单"
                    readyLive -> "LIVE 就绪 · 门控放行"
                    readyPaper -> "PAPER 可用 · 完成自检后再上 LIVE"
                    else -> "未就绪 · 请到设置页查看自检项"
                },
                color = when {
                    exec.killSwitch -> Color(0xFFFF5252)
                    readyLive -> Color(0xFF69F0AE)
                    readyPaper -> Color(0xFFFFD54F)
                    else -> Color(0xFFFF8A80)
                },
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp
            )
            Text(
                exec.lastVerdictReason ?: readiness?.items?.firstOrNull { !it.ok }?.detail ?: "—",
                color = Color(0xFF9AA0A6),
                fontSize = 10.sp
            )
        }
    }


        // === 标题 ===
        Row(
            Modifier.fillMaxWidth().padding(24.dp, 18.dp, 24.dp, 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("自动下注", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
                Text(
                    "二元期权 - 5min 周期 - Yes/No - Paper / Polymarket / Binance",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            val running = runtimeState.status == BtcRuntimeStatus.RUNNING
            val killed = runtimeState.killSwitch
            StatusPill(text = runtimeState.status.name, active = running, danger = killed)
        }

        // === 当前周期卡 ===
        Card(
            Modifier.padding(horizontal = 24.dp, vertical = 4.dp).fillMaxWidth(),
            shape = RoundedCornerShape(20.dp)
        ) {
            Column(Modifier.padding(16.dp)) {
                SectionTitleInline("当前 5 分钟周期")
                val round = currentRound
                if (round != null) {
                    val now = System.currentTimeMillis()
                    val remaining = (round.endTime - now) / 1000
                    val remainingMin = remaining / 60
                    val remainingSec = remaining % 60
                    MetricLine("周期 ID", "#${round.roundId / 300_000}")
                    MetricLine("开窗价格", "%.2f USDT".format(round.openPrice))
                    MetricLine("开始时间", fmtTime(round.startTime))
                    MetricLine("结束时间", fmtTime(round.endTime))
                    MetricLine("倒计时", "%d:%02d".format(remainingMin, remainingSec))

                    // 实时方向指示
                    val liveDir = viewModel.binaryLiveDirection()
                    val liveMove = viewModel.binaryCurrentMovePct()
                    val dirColor = if (liveDir == BetDirection.YES) CaiTokens.Success else CaiTokens.Danger
                    Spacer(Modifier.height(6.dp))
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = dirColor.copy(alpha = 0.12f)
                    ) {
                        Row(Modifier.padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                if (liveDir == BetDirection.YES) "YES - 涨" else "NO - 跌",
                                color = dirColor,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(
                                "%.2f%%".format(liveMove),
                                color = dirColor,
                                fontSize = 12.sp
                            )
                        }
                    }
                } else {
                    Text("等待周期开启...", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }

        Spacer(Modifier.height(8.dp))

        // === 日级盈亏统计卡 ===
        DailyStatsCard(
            dailyStats = dailyStats,
            dailyControlConfig = dailyControlConfig
        )

        Spacer(Modifier.height(8.dp))

        // === 执行台面板：Edge 对比 + 变动赔率 + 固定1U ===
        ExecutionPanelCard(
            viewModel = viewModel,
            state = state,
            binaryAccount = binaryAccount,
            edgeAssessment = edgeAssessment,
            stakePreview = stakePreview,
            runtimeConfig = runtimeConfig
        )

        Spacer(Modifier.height(8.dp))

        // === 最近执行结果 ===
        if (lastExecution != null) {
            LastExecutionCard(lastExecution!!)
            Spacer(Modifier.height(8.dp))
        }

        // === 账户快览 ===
        Card(
            Modifier.padding(horizontal = 24.dp, vertical = 4.dp).fillMaxWidth(),
            shape = RoundedCornerShape(20.dp)
        ) {
            Column(Modifier.padding(16.dp)) {
                SectionTitleInline("下注账户")
                MetricLine("余额", "%.2f USDT".format(binaryAccount.balance))
                MetricLine("待结算", "${binaryAccount.pendingBets.size} 笔")
                MetricLine("已结算", "${binaryAccount.settledBets.size} 笔")
                MetricLine("累计下注", "%.2f USDT".format(binaryAccount.totalWagered))
                MetricLine("累计拿回", "%.2f USDT".format(binaryAccount.totalPayout))
                MetricLine("净盈亏", "%.2f USDT".format(binaryAccount.netProfit))
            }
        }

        Spacer(Modifier.height(8.dp))

        // === 平台连接状态 ===
        PlatformStatusCard(
            platformStatus = platformStatus,
            viewModel = viewModel
        )

        Spacer(Modifier.height(8.dp))

        // === 自动下注配置 ===
        AutoTradeConfigCard(
            viewModel = viewModel,
            runtimeConfig = runtimeConfig,
            runtimeState = runtimeState,
            state = state
        )

        Spacer(Modifier.height(8.dp))

        // === 手动执行 ===
        Card(
            Modifier.padding(horizontal = 24.dp, vertical = 4.dp).fillMaxWidth(),
            shape = RoundedCornerShape(20.dp)
        ) {
            Column(Modifier.padding(16.dp)) {
                SectionTitleInline("手动执行下注")
                Text(
                    "基于 Edge 评估（模型概率 vs 市场定价）+ 变动赔率 + 固定 1U 下注，在当前 5 分钟周期内下注。亏损上限 = 下注本金。",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { viewModel.executeAutoTradeTick() }) {
                        Icon(Icons.Filled.PlayArrow, null)
                        Spacer(Modifier.width(6.dp))
                        Text("执行一轮")
                    }
                    OutlinedButton(onClick = { viewModel.forceSettleCurrentRound() }) {
                        Text("强制结算")
                    }
                    OutlinedButton(onClick = { viewModel.clearAutoTradeLog() }) {
                        Text("清空日志")
                    }
                }
            }
        }

        Spacer(Modifier.height(8.dp))

        // === 交易日志 ===
        Card(
            Modifier.padding(horizontal = 24.dp, vertical = 4.dp).fillMaxWidth(),
            shape = RoundedCornerShape(20.dp)
        ) {
            Column(Modifier.padding(16.dp)) {
                SectionTitleInline("下注日志 (${tradeLog.size})")
                if (tradeLog.isEmpty()) {
                    Text(
                        "暂无日志。点击「执行一轮」或启动自动挂机。",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 12.dp)
                    )
                } else {
                    tradeLog.forEach { entry ->
                        BetLogRow(entry)
                        if (tradeLog.indexOf(entry) < tradeLog.size - 1) {
                            HorizontalDivider(Modifier.padding(vertical = 4.dp))
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(40.dp))
    }
}

/**
 * 执行台面板：Edge 对比 + 变动赔率 + 固定1U 下注
 */
@Composable
private fun ExecutionPanelCard(
    viewModel: BtcQuantViewModel,
    state: com.caifenxi.app.domain.btc.BtcDashboardState,
    binaryAccount: com.caifenxi.app.domain.btc.paper.BinaryOptionAccount,
    edgeAssessment: EdgeAssessment?,
    stakePreview: StakeSizingEngine.StakeSuggestion?,
    runtimeConfig: com.caifenxi.app.domain.btc.runtime.BtcRuntimeConfig
) {
    Card(
        Modifier.padding(horizontal = 24.dp, vertical = 4.dp).fillMaxWidth(),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            SectionTitleInline("执行台 - Edge 评估")

            MetricLine("账户余额", "%.2f USDT".format(binaryAccount.balance))
            MetricLine("固定下注", "1 USDT / 注")
            MetricLine("策略池方向", state.consensus?.direction?.name ?: "--")
            MetricLine("模型概率", state.consensus?.let { "%.0f%%".format(it.probability * 100) } ?: "--")

            Spacer(Modifier.height(8.dp))
            HorizontalDivider(Modifier.padding(vertical = 4.dp))
            Spacer(Modifier.height(4.dp))

            val assessment = edgeAssessment
            if (assessment != null && assessment.shouldBet && assessment.chosenDirection != null) {
                // === 有 edge，推荐下注 ===
                val chosenDir = assessment.chosenDirection!!
                val dirColor = if (chosenDir == BetDirection.YES) CaiTokens.Success else CaiTokens.Danger

                Text("Edge 建议下注", fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = CaiTokens.Accent)
                Spacer(Modifier.height(6.dp))

                // 方向 + 变动赔率高亮卡
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = dirColor.copy(alpha = 0.10f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = dirColor,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    if (chosenDir == BetDirection.YES) "Y" else "N",
                                    color = Color.White,
                                    fontWeight = FontWeight.Black,
                                    fontSize = 16.sp
                                )
                            }
                        }
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(
                                "1 USDT",
                                fontWeight = FontWeight.Black,
                                fontSize = 20.sp,
                                color = dirColor
                            )
                            Text(
                                chosenDir.label,
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Spacer(Modifier.weight(1f))
                        Column(horizontalAlignment = Alignment.End) {
                            Text("@ %.2fx".format(assessment.chosenOdds), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            Text("edge +%.1f%%".format(assessment.chosenEdge * 100), fontSize = 11.sp, color = dirColor)
                        }
                    }
                }

                Spacer(Modifier.height(8.dp))

                // Edge 对比表
                SectionTitleInline("两方向 Edge 对比")
                MetricLine("YES edge", "%+.1f%% @ %.2fx".format(assessment.edgeYes * 100, assessment.marketYesOdds))
                MetricLine("NO edge", "%+.1f%% @ %.2fx".format(assessment.edgeNo * 100, assessment.marketNoOdds))
                MetricLine("市场 YES 价", "%.2f (隐含 %.0f%%)".format(assessment.marketProbYes, assessment.marketProbYes * 100))
                MetricLine("市场 NO 价", "%.2f (隐含 %.0f%%)".format(assessment.marketProbNo, assessment.marketProbNo * 100))
                MetricLine("模型 YES 概率", "%.0f%%".format(assessment.modelProbYes * 100))
                MetricLine("模型 NO 概率", "%.0f%%".format(assessment.modelProbNo * 100))

                Spacer(Modifier.height(8.dp))

                // 收益指标
                MetricLine("预期收益(赢)", "+%.2f USDT".format(1.0 * (assessment.chosenOdds - 1.0)))
                MetricLine("最大亏损(输)", "-1.00 USDT")
                MetricLine("单笔 EV", "%+.4f USDT".format(assessment.evPerBet))

                Spacer(Modifier.height(8.dp))

                // 下单确认按钮
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { viewModel.executeAutoTradeTick() }) {
                        Icon(Icons.Filled.PlayArrow, null)
                        Spacer(Modifier.width(6.dp))
                        Text("确认下注 1 U")
                    }
                    OutlinedButton(onClick = { viewModel.previewStakeSizing() }) {
                        Text("刷新 Edge")
                    }
                }

                Spacer(Modifier.height(4.dp))
                Text(
                    "亏损上限 = 1 USDT (下注本金)，无杠杆无资金费率无强平",
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    assessment.reason,
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else if (assessment != null && !assessment.shouldBet) {
                // === Edge 不足，跳过 ===
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = CaiTokens.Warning.copy(alpha = 0.10f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.Warning, null, tint = CaiTokens.Warning)
                        Spacer(Modifier.width(8.dp))
                        Column {
                            Text("Edge 不足，跳过本周期", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = CaiTokens.Warning)
                            Text(assessment.reason, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }

                Spacer(Modifier.height(8.dp))
                SectionTitleInline("两方向 Edge 对比")
                MetricLine("YES edge", "%+.1f%% @ %.2fx".format(assessment.edgeYes * 100, assessment.marketYesOdds))
                MetricLine("NO edge", "%+.1f%% @ %.2fx".format(assessment.edgeNo * 100, assessment.marketNoOdds))
            } else {
                // === 无评估数据 ===
                Text(
                    "等待策略池共识和市场赔率加载...",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(vertical = 12.dp)
                )
                OutlinedButton(onClick = { viewModel.previewStakeSizing() }) {
                    Text("手动评估")
                }
            }
        }
    }
}

/**
 * 最近执行结果卡
 */
@Composable
private fun LastExecutionCard(result: BtcQuantViewModel.ExecutionResult) {
    val successColor = if (result.success) CaiTokens.Success else CaiTokens.Danger
    val timeStr = SimpleDateFormat("HH:mm:ss").format(Date(result.timestamp))

    Card(
        Modifier.padding(horizontal = 24.dp, vertical = 4.dp).fillMaxWidth(),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            SectionTitleInline("最近执行结果")
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    shape = CircleShape,
                    color = successColor.copy(alpha = 0.15f),
                    modifier = Modifier.size(32.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        if (result.success) {
                            Icon(Icons.Filled.Check, null, tint = successColor, modifier = Modifier.size(18.dp))
                        } else {
                            Icon(Icons.Filled.Warning, null, tint = successColor, modifier = Modifier.size(18.dp))
                        }
                    }
                }
                Spacer(Modifier.width(8.dp))
                Column {
                    Text(
                        "${if (result.success) "成功" else "失败"} - ${result.mode}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = successColor
                    )
                    Text(timeStr, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Spacer(Modifier.height(8.dp))
            MetricLine("方向", result.direction.label)
            MetricLine("金额", "%.0f USDT".format(result.amount))
            MetricLine("赔率", "%.1fx".format(result.odds))
            MetricLine("开窗价", "%.2f".format(result.openPrice))
            MetricLine("周期", "#${result.roundId / 300_000}")
            if (!result.orderId.isNullOrBlank()) {
                MetricLine("订单 ID", result.orderId)
            }
            Spacer(Modifier.height(4.dp))
            Text(
                result.message,
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

/**
 * 平台连接状态卡
 */
@Composable
private fun PlatformStatusCard(
    platformStatus: BtcQuantViewModel.PlatformStatus,
    viewModel: BtcQuantViewModel
) {
    Card(
        Modifier.padding(horizontal = 24.dp, vertical = 4.dp).fillMaxWidth(),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                SectionTitleInline("平台连接状态")
                OutlinedButton(
                    onClick = { viewModel.checkPlatformConnectivity() },
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                ) {
                    Text("检查", fontSize = 11.sp)
                }
            }

            // Polymarket 状态
            PlatformStatusRow(
                name = "Polymarket",
                connected = platformStatus.polymarketConnected,
                balance = platformStatus.polymarketBalance
            )
            Spacer(Modifier.height(6.dp))

            // Binance 状态
            PlatformStatusRow(
                name = "Binance",
                connected = platformStatus.binanceConnected,
                balance = platformStatus.binanceBalance
            )

            if (platformStatus.lastCheck > 0) {
                Spacer(Modifier.height(4.dp))
                Text(
                    "上次检查: ${fmtTime(platformStatus.lastCheck)}",
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun PlatformStatusRow(name: String, connected: Boolean, balance: Double) {
    val color = if (connected) CaiTokens.Success else MaterialTheme.colorScheme.onSurfaceVariant
    Row(
        Modifier.fillMaxWidth().padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Surface(
            shape = CircleShape,
            color = color.copy(alpha = 0.15f),
            modifier = Modifier.size(20.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    if (connected) Icons.Filled.CloudQueue else Icons.Filled.CloudOff,
                    null,
                    tint = color,
                    modifier = Modifier.size(12.dp)
                )
            }
        }
        Spacer(Modifier.width(8.dp))
        Text(name, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.width(80.dp))
        Text(
            if (connected) "已连接" else "未连接",
            fontSize = 11.sp,
            color = color,
            modifier = Modifier.width(60.dp)
        )
        if (connected && balance > 0) {
            Text(
                "%.2f USDT".format(balance),
                fontSize = 11.sp,
                color = color
            )
        }
    }
}

@Composable
private fun AutoTradeConfigCard(
    viewModel: BtcQuantViewModel,
    runtimeConfig: com.caifenxi.app.domain.btc.runtime.BtcRuntimeConfig,
    runtimeState: com.caifenxi.app.domain.btc.runtime.BtcRuntimeState,
    state: com.caifenxi.app.domain.btc.BtcDashboardState
) {
    var pollSec by remember(runtimeConfig.pollSeconds) {
        mutableStateOf(runtimeConfig.pollSeconds.toString())
    }

    val running = runtimeState.status == BtcRuntimeStatus.RUNNING
    val killed = runtimeState.killSwitch

    Card(
        Modifier.padding(horizontal = 24.dp, vertical = 4.dp).fillMaxWidth(),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            SectionTitleInline("自动下注配置")

            MetricLine("Symbol", runtimeConfig.symbol)
            MetricLine("K 线周期", runtimeConfig.timeframe)
            MetricLine("当前共识", state.consensus?.direction?.name ?: "--")
            MetricLine("共识概率", state.consensus?.let { "%.0f%%".format(it.probability * 100) } ?: "--")
            MetricLine("份额模式", "固定 1U + 变动赔率")

            Spacer(Modifier.height(8.dp))

            // 运行模式
            Text("下注模式", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(
                Modifier.fillMaxWidth().padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                BtcRunMode.entries.forEach { mode ->
                    FilterChip(
                        selected = runtimeConfig.runMode == mode,
                        onClick = { viewModel.updateRuntimeConfig(runMode = mode) },
                        label = { Text(mode.name, fontSize = 11.sp) }
                    )
                }
            }
            if (runtimeConfig.runMode == BtcRunMode.LIVE) {
                Text(
                    "LIVE 模式将使用真实资金下注！请确保密钥已配置且充分测试。",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.error
                )
            }

            Spacer(Modifier.height(8.dp))

            // 轮询间隔
            OutlinedTextField(
                value = pollSec,
                onValueChange = { pollSec = it.filter { c -> c.isDigit() } },
                label = { Text("轮询间隔 (秒)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(8.dp))

            // 保存配置
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = {
                    val sec = pollSec.toLongOrNull() ?: 20L
                    viewModel.updateRuntimeConfig(pollSeconds = sec)
                }) { Text("保存配置") }
            }

            Spacer(Modifier.height(8.dp))

            // 挂机控制
            HorizontalDivider(Modifier.padding(vertical = 8.dp))
            Text("挂机控制", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    enabled = !running && !killed,
                    onClick = { viewModel.setRuntimeEnabled(true, runtimeConfig.runMode) }
                ) {
                    Icon(Icons.Filled.PlayArrow, null)
                    Spacer(Modifier.width(4.dp))
                    Text("启动")
                }
                OutlinedButton(
                    enabled = running,
                    onClick = { viewModel.setRuntimeEnabled(false) }
                ) {
                    Icon(Icons.Filled.Stop, null)
                    Spacer(Modifier.width(4.dp))
                    Text("停止")
                }
                OutlinedButton(
                    enabled = !killed,
                    onClick = { viewModel.killRuntime() }
                ) { Text("全停") }
                if (killed) {
                    OutlinedButton(onClick = { viewModel.resumeRuntime() }) { Text("解除") }
                }
            }
        }
    }
}

/**
 * 日级盈亏统计卡
 *
 * 展示当日整体盈亏状态：日期、总笔数、胜率、净盈亏、回撤、止盈止损状态、自动停机指示
 */
@Composable
private fun DailyStatsCard(
    dailyStats: com.caifenxi.app.domain.btc.paper.DailyStats,
    dailyControlConfig: com.caifenxi.app.domain.btc.paper.DailyControlConfig
) {
    val profitColor = if (dailyStats.netProfit >= 0) CaiTokens.Success else CaiTokens.Danger
    val isStopped = dailyStats.autoStopped

    Card(
        Modifier.padding(horizontal = 24.dp, vertical = 4.dp).fillMaxWidth(),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                SectionTitleInline("日级盈亏统计")
                if (isStopped) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = CaiTokens.Warning.copy(alpha = 0.15f)
                    ) {
                        Row(
                            Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Filled.Warning, null, tint = CaiTokens.Warning, modifier = Modifier.size(14.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("已停机", fontSize = 11.sp, color = CaiTokens.Warning, fontWeight = FontWeight.Bold)
                        }
                    }
                } else {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = CaiTokens.Success.copy(alpha = 0.12f)
                    ) {
                        Text(
                            "运行中",
                            fontSize = 11.sp,
                            color = CaiTokens.Success,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            // 日期
            Text(
                if (dailyStats.date.isNotEmpty()) dailyStats.date else "--",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(Modifier.height(8.dp))

            // 核心盈亏指标（2行2列）
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(horizontalAlignment = Alignment.Start) {
                    Text("日净盈亏", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        "%s%.2f USDT".format(if (dailyStats.netProfit >= 0) "+" else "", dailyStats.netProfit),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        color = profitColor
                    )
                    Text(
                        "%s%.1f%%".format(if (dailyStats.netProfitPct >= 0) "+" else "", dailyStats.netProfitPct),
                        fontSize = 12.sp,
                        color = profitColor
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("胜率", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        "%.0f%%".format(dailyStats.winRatePct),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        color = if (dailyStats.winRatePct >= 50) CaiTokens.Success else CaiTokens.Danger
                    )
                    Text(
                        "${dailyStats.wins}胜 / ${dailyStats.losses}负 / ${dailyStats.totalBets}笔",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(Modifier.height(8.dp))
            HorizontalDivider(Modifier.padding(vertical = 2.dp))
            Spacer(Modifier.height(6.dp))

            // 详细指标
            MetricLine("日初余额", "%.2f USDT".format(dailyStats.startBalance))
            MetricLine("当前余额", "%.2f USDT".format(dailyStats.currentBalance))
            MetricLine("日内峰值", "%.2f USDT".format(dailyStats.peakBalance))
            MetricLine("日内回撤", "%.2f USDT (%.1f%%)".format(dailyStats.maxDrawdown, dailyStats.maxDrawdownPct))
            MetricLine("累计下注", "%.2f USDT".format(dailyStats.totalWagered))
            MetricLine("累计拿回", "%.2f USDT".format(dailyStats.totalPayout))
            MetricLine("盈亏比", "%.2f".format(dailyStats.profitFactor))

            Spacer(Modifier.height(8.dp))
            HorizontalDivider(Modifier.padding(vertical = 2.dp))
            Spacer(Modifier.height(6.dp))

            // 止盈止损线
            SectionTitleInline("日级控制线")
            val stopLossAmt = dailyControlConfig.dailyStopLossAmount(dailyStats.startBalance)
            val takeProfitAmt = dailyControlConfig.dailyTakeProfitAmount(dailyStats.startBalance)
            MetricLine("日止损线", "-%.2f USDT (%.0f%%)".format(stopLossAmt, dailyControlConfig.dailyStopLossPct))
            MetricLine("日止盈线", "+%.2f USDT (%.0f%%)".format(takeProfitAmt, dailyControlConfig.dailyTakeProfitPct))
            MetricLine("日最大下注", "${dailyControlConfig.maxDailyBets} 笔")

            // 剩余可下注次数
            val remainingBets = (dailyControlConfig.maxDailyBets - dailyStats.totalBets).coerceAtLeast(0)
            MetricLine("剩余次数", "$remainingBets 笔")

            // 止盈止损状态
            if (dailyStats.stopLossHit) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = CaiTokens.Danger.copy(alpha = 0.12f),
                    modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
                ) {
                    Row(
                        Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.Warning, null, tint = CaiTokens.Danger, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(
                            "日止损触发 - 亏损 %.2f USDT，自动停机等待次日".format(-dailyStats.netProfit),
                            fontSize = 11.sp,
                            color = CaiTokens.Danger,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            } else if (dailyStats.takeProfitHit) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = CaiTokens.Success.copy(alpha = 0.12f),
                    modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
                ) {
                    Row(
                        Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.Check, null, tint = CaiTokens.Success, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(
                            "日止盈达成 - 盈利 %.2f USDT (+%.1f%%)，自动停机锁定利润".format(
                                dailyStats.netProfit, dailyStats.netProfitPct
                            ),
                            fontSize = 11.sp,
                            color = CaiTokens.Success,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun BetLogRow(entry: BtcQuantViewModel.AutoTradeLogEntry) {
    val dirColor = when (entry.direction) {
        "YES" -> CaiTokens.Success
        "NO" -> CaiTokens.Danger
        else -> CaiTokens.Warning
    }
    val timeStr = SimpleDateFormat("HH:mm:ss").format(Date(entry.timestamp))

    Row(
        Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // 时间
        Text(timeStr, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.width(60.dp))
        // 方向
        Surface(
            shape = RoundedCornerShape(4.dp),
            color = dirColor.copy(alpha = 0.15f)
        ) {
            Text(
                entry.direction,
                color = dirColor,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
            )
        }
        Spacer(Modifier.width(6.dp))
        // 详情
        Column(Modifier.weight(1f)) {
            if (entry.betAmount > 0) {
                Text(
                    "%.0f USDT @ %.1fx - Open=%.2f".format(
                        entry.betAmount, entry.odds, entry.openPrice
                    ),
                    fontSize = 10.sp
                )
            }
            Text(
                "[${entry.mode}] ${entry.result}",
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}


@Composable
private fun StatusPill(text: String, active: Boolean = false, danger: Boolean = false) {
    val color = when {
        danger -> Color(0xFFFF5252)
        active -> Color(0xFF00E676)
        else -> MaterialTheme.colorScheme.onSurfaceVariant
    }
    Surface(
        shape = RoundedCornerShape(50),
        color = color.copy(alpha = 0.10f),
        border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.45f))
    ) {
        Text(
            text, color = color, fontSize = 10.sp, fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp)
        )
    }
}
