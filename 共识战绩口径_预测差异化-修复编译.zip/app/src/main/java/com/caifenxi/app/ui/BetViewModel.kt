package com.caifenxi.app.ui

import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.caifenxi.app.CaiFenXiApplication
import com.caifenxi.app.domain.engine.BetEngine
import com.caifenxi.app.domain.model.BetStats
import com.caifenxi.app.domain.model.BetView
import com.caifenxi.app.domain.model.BotConfig
import com.caifenxi.app.domain.model.WalletView
import kotlinx.coroutines.launch

/**
 * 挂机 / 模拟下注 ViewModel。
 * 从 MainViewModel 拆出:负责挂机策略、钱包、下注历史、收益曲线与统计。
 * 依赖 Application 级共享 betEngine 与 betDao,不依赖 MainViewModel。
 */
class BetViewModel : ViewModel() {

    private val app get() = CaiFenXiApplication.instance
    private val betEngine get() = app.betEngine
    private val betDao get() = app.database.betDao()

    val botConfig = mutableStateOf(BotConfig())
    val wallet = mutableStateOf(WalletView())
    val betHistory = mutableStateOf<List<BetView>>(emptyList())
    val betStats = mutableStateOf(BetStats())
    /** 曲线刷新版本;曲线重置只清空视图状态,不删除订单。 */
    val betCurveRevision = mutableStateOf(0)
    val betCurveReset = mutableStateOf(false)

    /** 从 DB 刷新挂机策略、钱包与下注历史到 UI 状态 */
    fun refreshBetState(lotteryKey: String, onStatus: (String) -> Unit = {}) {
        viewModelScope.launch {
            try {
                val key = lotteryKey
                // 有新统计时自动取消「曲线已重置」占位,避免一直空白
                betCurveReset.value = false
                val cfg = betDao.getBotConfig(key)
                botConfig.value = cfg?.let {
                    BotConfig(
                        enabled = it.enabled,
                        sourceType = it.sourceType,
                        sourceId = it.sourceId,
                        categories = it.categories.split(",").map { c -> c.trim() }.filter { c -> c.isNotEmpty() }.toSet(),
                        numberPosition = it.numberPosition,
                        amount = it.amount,
                        winMult = it.winMult,
                        lossMult = it.lossMult,
                        winMultPeriods = it.winMultPeriods,
                        lossMultPeriods = it.lossMultPeriods,
                        maxMult = it.maxMult,
                        betMode = it.betMode.ifBlank { "forward" }
                    )
                } ?: BotConfig()
                // 供无障碍/设置页主线程读取，避免 runBlocking 查库卡死
                if (cfg != null) {
                    com.caifenxi.app.service.AutoBetController.updateBotSourceCache(key, cfg.sourceType, cfg.sourceId)
                }

                val w = betDao.getWallet(key)
                wallet.value = w?.let {
                    WalletView(
                        initialBalance = it.initialBalance,
                        balance = it.balance,
                        totalProfit = it.totalProfit,
                        totalBet = it.totalBet,
                        winCount = it.winCount,
                        loseCount = it.loseCount
                    )
                } ?: WalletView()

                val bets = betDao.getBets(key)
                betHistory.value = bets.map { b ->
                    BetView(
                        id = b.id,
                        issue = b.issue,
                        sourceLabel = b.sourceId,
                        category = b.category,
                        betValue = b.betValue,
                        amount = b.amount,
                        odds = b.odds,
                        status = b.status,
                        profit = b.profit,
                        createdAt = b.createdAt,
                        settledAt = b.settledAt
                    )
                }

                // 刷新统计数据
                betStats.value = betEngine.getBetStats(key)
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                onStatus("挂机状态刷新失败:${e.message}")
            }
        }
    }

    /** 重新读取挂机订单、钱包和统计,不删除任何数据。 */
    fun refreshBetOverview(lotteryKey: String, onStatus: (String) -> Unit = {}) {
        refreshBetState(lotteryKey, onStatus)
    }

    /** 清零挂机总览:删除订单、恢复钱包,保留当前挂机策略。 */
    fun resetBetOverview(lotteryKey: String, onStatus: (String) -> Unit = {}) {
        viewModelScope.launch {
            try {
                val key = lotteryKey
                val initial = betStats.value.initialBalance.takeIf { it > 0 } ?: BetEngine.DEFAULT_INITIAL
                betEngine.resetBetOverview(key, initial)
                betCurveReset.value = false
                betCurveRevision.value++
                refreshBetState(key, onStatus)
                onStatus("挂机总览已重置")
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                onStatus("重置失败:${e.message}")
            }
        }
    }

    /** 重新从现有订单生成收益曲线。 */
    fun refreshBetCurve(lotteryKey: String) {
        viewModelScope.launch {
            try {
                betCurveReset.value = false
                betCurveRevision.value++
                betStats.value = betEngine.getBetStats(lotteryKey)
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                // 曲线刷新失败保持原状态
            }
        }
    }

    /** 只重置曲线视图状态,不删除订单、钱包或挂机策略。 */
    fun resetBetCurve() {
        betCurveReset.value = true
        betCurveRevision.value++
    }

    /** 保存挂机策略 */
    fun saveBotConfig(config: BotConfig, lotteryKey: String, onStatus: (String) -> Unit = {}) {
        viewModelScope.launch {
            try {
                val key = lotteryKey
                betDao.upsertBotConfig(
                    com.caifenxi.app.data.db.entity.BotConfigEntity(
                        lotteryKey = key,
                        enabled = config.enabled,
                        sourceType = config.sourceType,
                        sourceId = config.sourceId,
                        categories = config.categories.sorted().joinToString(","),
                        numberPosition = config.numberPosition,
                        amount = config.amount,
                        winMult = config.winMult.coerceIn(1.0, 10.0),
                        lossMult = config.lossMult.coerceIn(1.0, 10.0),
                        winMultPeriods = config.winMultPeriods.coerceIn(1, 20),
                        lossMultPeriods = config.lossMultPeriods.coerceIn(1, 20),
                        maxMult = config.maxMult.coerceIn(1, 20),
                        betMode = if (config.betMode == "reverse") "reverse" else "forward"
                    )
                )
                botConfig.value = config
                com.caifenxi.app.service.AutoBetController.updateBotSourceCache(
                    key, config.sourceType, config.sourceId
                )
                onStatus(if (config.enabled) "挂机已开启" else "挂机已暂停")
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                onStatus("保存失败:${e.message}")
            }
        }
    }

    /** 初始化/重置虚拟账户资金 */
    fun setInitialBalance(amount: Double, lotteryKey: String, onStatus: (String) -> Unit = {}) {
        viewModelScope.launch {
            try {
                val key = lotteryKey
                betEngine.ensureWallet(key, amount)
                refreshBetState(key, onStatus)
                onStatus("初始资金已设为 $amount")
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                onStatus("设置失败:${e.message}")
            }
        }
    }

    /** 清空下注历史;待开单会退回已扣本金,已结算盈亏保留在钱包余额中 */
    fun clearBetHistory(lotteryKey: String) {
        viewModelScope.launch {
            try {
                betEngine.clearBetsRefundPending(lotteryKey)
                refreshBetState(lotteryKey)
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                // 清空失败不影响主流程
            }
        }
    }

    /** 挂机自动下注(由 MainViewModel 在新一期开奖/预测后调用) */
    suspend fun placeAutoBets(
        lotteryKey: String,
        targetIssue: String,
        prediction: com.caifenxi.app.domain.model.PredictionSnapshot?,
        planPredictions: List<com.caifenxi.app.domain.model.PlanPredictionRecord>,
        consensus: List<com.caifenxi.app.domain.model.ModelConsensus>
    ): Int = betEngine.placeAutoBets(
        lotteryKey = lotteryKey,
        targetIssue = targetIssue,
        prediction = prediction,
        planPredictions = planPredictions,
        consensus = consensus
    )

    /** 带回失败原因,便于状态栏提示 */
    suspend fun placeAutoBetsDetailed(
        lotteryKey: String,
        targetIssue: String,
        prediction: com.caifenxi.app.domain.model.PredictionSnapshot?,
        planPredictions: List<com.caifenxi.app.domain.model.PlanPredictionRecord>,
        consensus: List<com.caifenxi.app.domain.model.ModelConsensus>
    ) = betEngine.placeAutoBetsDetailed(
        lotteryKey = lotteryKey,
        targetIssue = targetIssue,
        prediction = prediction,
        planPredictions = planPredictions,
        consensus = consensus
    )

    /** 新开奖结算(由 MainViewModel 调用) */
    suspend fun settleWithDraw(lotteryKey: String, draw: com.caifenxi.app.domain.model.DrawRecord) {
        betEngine.settleWithDraw(lotteryKey, draw)
        // 无障碍金额策略：优先用「点击预测 vs 开奖」；若无点击记录再回落挂机注单
        try {
            val ctx = CaiFenXiApplication.instance.applicationContext
            com.caifenxi.app.service.AutoBetController.recordHitFromDraw(
                context = ctx,
                lotteryKey = lotteryKey,
                issue = draw.issue,
                actualDx = draw.dx,
                actualDs = draw.ds
            )
            // 回落：仅当尚无对错记录时，用内部挂机注单（任一注中=对）
            val info = com.caifenxi.app.service.AutoBetController.getAmountStrategyInfo(
                ctx,
                CaiFenXiApplication.instance.configStore.loadPrefs()
            )
            if (info.lastHit == null) {
                val bets = betDao.getBets(lotteryKey).filter { it.issue == draw.issue && it.status != "待开" }
                if (bets.isNotEmpty()) {
                    val hit = bets.any { it.status == "中" }
                    com.caifenxi.app.service.AutoBetController.recordLastHit(ctx, hit)
                }
            }
        } catch (_: Exception) {
        }
    }
}
