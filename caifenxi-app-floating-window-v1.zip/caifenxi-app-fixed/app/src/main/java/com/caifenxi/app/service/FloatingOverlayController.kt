package com.caifenxi.app.service

import android.content.Context
import android.graphics.Color as AndroidColor
import android.graphics.PixelFormat
import android.os.Build
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import com.caifenxi.app.CaiFenXiApplication
import com.caifenxi.app.domain.model.UserPrefs
import kotlin.math.max
import kotlin.math.min

/** 悬浮窗只读展示器；预测来源全部来自 DataSyncService 写入的统一快照。 */
class FloatingOverlayController(private val context: Context) {
    private val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var root: LinearLayout? = null
    private var params: WindowManager.LayoutParams? = null

    fun refresh(prefs: UserPrefs) {
        if (!prefs.floatingEnabled || !android.provider.Settings.canDrawOverlays(context)) {
            hide()
            return
        }
        val snap = FloatingOverlayStore.load(context) ?: return
        if (root == null) create(prefs)
        render(prefs, snap)
    }

    fun hide() {
        root?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        root = null
        params = null
    }

    private fun create(prefs: UserPrefs) {
        val lp = WindowManager.LayoutParams(
            dp(190), WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = prefs.floatingX
            y = prefs.floatingY
        }
        val box = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(9), dp(12), dp(9))
            setBackgroundColor(AndroidColor.argb(225, 25, 25, 25))
            elevation = dp(8).toFloat()
        }
        box.setOnTouchListener(DragTouchListener(lp))
        wm.addView(box, lp)
        root = box
        params = lp
    }

    private fun render(prefs: UserPrefs, snap: FloatingSnapshot) {
        val box = root ?: return
        box.alpha = prefs.floatingOpacity
        box.removeAllViews()
        val source = when (prefs.floatingSource) {
            "plan" -> snap.plans.firstOrNull { it.planId == prefs.floatingPlanId }
            else -> null
        }
        val dx = source?.dx ?: snap.consensusDx
        val ds = source?.ds ?: snap.consensusDs
        val sourceName = source?.planName ?: "共识"
        add(box, "${snap.lotteryName}  ·  悬浮预测", true, prefs)
        add(box, "第 ${snap.latestIssue} → 下期 ${snap.targetIssue}", false, prefs)
        add(box, "大小：${dx ?: "-"}    单双：${ds ?: "-"}", true, prefs)
        add(box, "来源：$sourceName", false, prefs)
        val last = listOfNotNull(
            snap.previousDxResult?.takeIf { it.isNotBlank() }?.let { "大小$it" },
            snap.previousDsResult?.takeIf { it.isNotBlank() }?.let { "单双$it" }
        ).joinToString("  ")
        if (last.isNotBlank()) add(box, "上期：$last", false, prefs)
        val age = if (snap.updatedAt > 0) System.currentTimeMillis() - snap.updatedAt else Long.MAX_VALUE
        add(box, if (age > 180_000L) "⚠ 数据可能过期" else "● 数据已同步", false, prefs)
    }

    private fun add(box: LinearLayout, text: String, bold: Boolean, prefs: UserPrefs) {
        box.addView(TextView(context).apply {
            this.text = text
            setTextColor(AndroidColor.WHITE)
            textSize = prefs.floatingTextSize
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, dp(2), 0, dp(2))
        })
    }

    private fun dp(v: Int) = (v * context.resources.displayMetrics.density).toInt()

    private inner class DragTouchListener(private val lp: WindowManager.LayoutParams) : View.OnTouchListener {
        private var downX = 0f
        private var downY = 0f
        private var startX = 0
        private var startY = 0
        private var lastUpAt = 0L
        override fun onTouch(v: View, event: MotionEvent): Boolean {
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX; downY = event.rawY
                    startX = lp.x; startY = lp.y
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = startX + (event.rawX - downX).toInt()
                    lp.y = startY + (event.rawY - downY).toInt()
                    try { wm.updateViewLayout(v, lp) } catch (_: Exception) {}
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    val now = System.currentTimeMillis()
                    if (now - lastUpAt < 320L) {
                        hide()
                        CaiFenXiApplication.instance.configStore.savePrefs(
                            CaiFenXiApplication.instance.configStore.loadPrefs().copy(floatingEnabled = false)
                        )
                        lastUpAt = 0L
                        return true
                    }
                    lastUpAt = now
                    val p = CaiFenXiApplication.instance.configStore.loadPrefs()
                    CaiFenXiApplication.instance.configStore.savePrefs(
                        p.copy(floatingX = lp.x, floatingY = lp.y)
                    )
                    return true
                }
            }
            return false
        }
    }
}
