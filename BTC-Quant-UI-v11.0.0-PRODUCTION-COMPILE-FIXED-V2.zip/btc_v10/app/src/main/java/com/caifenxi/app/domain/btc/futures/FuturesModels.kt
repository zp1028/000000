package com.caifenxi.app.domain.btc.futures

import com.caifenxi.app.domain.btc.BtcDirection

// ── Order-side / position-side enums ──────────────────────────────

enum class FuturesOrderType(val binanceValue: String) {
    MARKET("MARKET"),
    LIMIT("LIMIT"),
    STOP_MARKET("STOP_MARKET"),
    TAKE_PROFIT_MARKET("TAKE_PROFIT_MARKET"),
    TRAILING_STOP_MARKET("TRAILING_STOP_MARKET")
}

enum class PositionSide { LONG, SHORT, EMPTY }

enum class MarginMode(val binanceValue: String) {
    ISOLATED("ISOLATED"),
    CROSSED("CROSSED")
}

// ── Position ──────────────────────────────────────────────────────

data class FuturesPosition(
    val symbol: String,
    val side: PositionSide,
    val entryPrice: Double,
    val quantity: Double,           // contract qty in BTC
    val leverage: Int,
    val margin: Double,             // margin allocated (USDT)
    val liquidationPrice: Double,
    val markPrice: Double,
    val unrealizedPnl: Double,
    val marginRatio: Double,        // margin / notional
    val stopLossPrice: Double?,
    val takeProfitPrice: Double?,
    val trailingStopPct: Double?,
    val highestSinceEntry: Double?, // for trailing stop (LONG)
    val lowestSinceEntry: Double?,  // for trailing stop (SHORT)
    val openTime: Long
) {
    val notional: Double get() = quantity * markPrice
    val roiPct: Double
        get() = if (margin > 0.0) (unrealizedPnl / margin) * 100.0 else 0.0
    val isEmpty: Boolean get() = side == PositionSide.EMPTY || quantity <= 0.0
    val direction: BtcDirection
        get() = when (side) {
            PositionSide.LONG -> BtcDirection.UP
            PositionSide.SHORT -> BtcDirection.DOWN
            PositionSide.EMPTY -> BtcDirection.FLAT
        }

    companion object {
        fun empty(symbol: String = "BTCUSDT") = FuturesPosition(
            symbol = symbol,
            side = PositionSide.EMPTY,
            entryPrice = 0.0,
            quantity = 0.0,
            leverage = 1,
            margin = 0.0,
            liquidationPrice = 0.0,
            markPrice = 0.0,
            unrealizedPnl = 0.0,
            marginRatio = 0.0,
            stopLossPrice = null,
            takeProfitPrice = null,
            trailingStopPct = null,
            highestSinceEntry = null,
            lowestSinceEntry = null,
            openTime = 0L
        )
    }
}

// ── Signal (output of engine, before broker execution) ─────────────

data class FuturesSignal(
    val direction: BtcDirection,
    val entry: Double,
    val stopLoss: Double,
    val takeProfit: Double,
    val quantity: Double,
    val leverage: Int,
    val margin: Double,
    val confidence: Double,
    val atrValue: Double,
    val reason: String,
    val trailingStopPct: Double? = null,
    val multiTakeProfit: List<TakeProfitLevel> = emptyList()
)

data class TakeProfitLevel(
    val price: Double,
    val qtyFraction: Double  // e.g. 0.5 = 50% of position
)

// ── Configuration ──────────────────────────────────────────────────

data class FuturesQuantConfig(
    val symbol: String = "BTCUSDT",
    val leverage: Int = 3,
    val positionSizePct: Double = 5.0,
    val stopLossAtrMult: Double = 1.5,
    val takeProfitAtrMult: Double = 3.0,
    val trailingStopPct: Double? = null,
    val marginMode: MarginMode = MarginMode.ISOLATED,
    val autoMode: Boolean = false,
    val minConfidence: Double = 0.60,
    val maxDailyLossUsdt: Double = 200.0,
    val maxDailyLossPct: Double = 2.0,
    val maxDrawdownPct: Double = 8.0,
    val maxPositions: Int = 3,
    val maxLeverage: Int = 3,
    val enableFundingArb: Boolean = true,
    val enableMultiTakeProfit: Boolean = false
)

// ── Daily stats ────────────────────────────────────────────────────

data class FuturesDailyStats(
    val date: String,           // yyyy-MM-dd
    val totalTrades: Int = 0,
    val wins: Int = 0,
    val losses: Int = 0,
    val grossProfit: Double = 0.0,
    val grossLoss: Double = 0.0,
    val netPnl: Double = 0.0,
    val peakEquity: Double = 0.0,
    val maxDrawdown: Double = 0.0,
    val fundingCost: Double = 0.0,
    val maxConsecutiveLosses: Int = 0,
    val currentConsecutiveLosses: Int = 0,
    val stopLossHits: Int = 0,
    val takeProfitHits: Int = 0,
    val maxDailyLossUsdt: Double = 200.0
) {
    val winRate: Double
        get() = if (totalTrades > 0) wins.toDouble() / totalTrades * 100.0 else 0.0
    val isStopLossHit: Boolean
        get() = netPnl <= -maxDailyLossUsdt
}

// ── Execution log entry ─────────────────────────────────────────────

data class FuturesLogEntry(
    val timestamp: Long,
    val action: String,
    val detail: String,
    val pnl: Double? = null,
    val level: LogLevel = LogLevel.INFO
)

enum class LogLevel { INFO, WARN, ERROR, SUCCESS }

// ── Position risk from exchange ───────────────────────────────────

data class PositionRiskInfo(
    val symbol: String,
    val positionAmt: Double,      // positive=long, negative=short
    val entryPrice: Double,
    val markPrice: Double,
    val unRealizedProfit: Double,
    val liquidationPrice: Double,
    val leverage: String,         // e.g. "3"
    val maxNotionalValue: String,
    val marginType: String        // "isolated" or "cross"
)

// ── Leverage setting result ───────────────────────────────────────

data class LeverageResult(
    val success: Boolean,
    val leverage: Int,
    val maxNotionalValue: Double,
    val message: String
)

// ── Close position request ─────────────────────────────────────────

data class ClosePositionRequest(
    val symbol: String,
    val reduceOnly: Boolean = true,
    val reason: String = "manual"
)
