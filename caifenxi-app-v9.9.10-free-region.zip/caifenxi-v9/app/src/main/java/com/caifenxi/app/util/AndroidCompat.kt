package com.caifenxi.app.util

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat

/**
 * Android 7+ compatibility helpers.  All API-specific calls are isolated here so
 * older devices do not load newer platform methods through an unguarded path.
 */
object AndroidCompat {
    fun startDataSyncService(context: Context, serviceIntent: Intent): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                ContextCompat.startForegroundService(context, serviceIntent)
            } else {
                context.startService(serviceIntent)
            }
            true
        } catch (e: Exception) {
            RuntimeLog.warn("AndroidCompat", "启动后台服务失败: ${e.javaClass.simpleName}")
            false
        }
    }

    fun startForegroundCompat(service: Service, id: Int, notification: android.app.Notification) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            // Use the DATA_SYNC type only on Android 10+, where the constant exists.
            androidx.core.app.ServiceCompat.startForeground(
                service,
                id,
                notification,
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
            )
        } else {
            service.startForeground(id, notification)
        }
    }

    fun hasPostNotifications(context: Context): Boolean {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
            ContextCompat.checkSelfPermission(
                context,
                android.Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
    }
}
