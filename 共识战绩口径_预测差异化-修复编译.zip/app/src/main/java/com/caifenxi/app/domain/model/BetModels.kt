package com.caifenxi.app.domain.model

/**
 * 模拟下注相关模型。
 */

/** 下注来源类型 */
enum class BetSourceType(val id: String, val label: String) {
    COCKPIT("cockpit", "驾驶舱"),
    ALGO("algo", "算法"),
    PLAN("plan", "指定计划"),
    NOVA("nova", "新计划"),
    AUTO_BEST("auto_best", "竞技场最优"),
    CONSENSUS("consensus", "共识"),
    /** 新计划页独立共识（与计划引擎共识数据分离） */
    NOVA_CONSENSUS("nova_consensus", "新计划共识");

    companion object {
        fun fromId(id: String): BetSourceType = entries.find { it.id == id } ?: ALGO
    }
}

/** 下注分类 */
enum class BetCategory(val id: String, val label: String) {
    DX("大小", "大小"),
    DS("单双", "单双"),
    COMBO("组合", "组合"),
    NUMBER("数字", "数字");

    companion object {
        fun fromId(id: String): BetCategory? = entries.find { it.id == id }
    }
}

/**
 * 赔率配置。
 * 组合:按覆盖的组合种类数(共4种:大单/大双/小单/小双)递减:
 * 1/4 → 3.9, 2/4 → 1.9, 3/4+ → 1.0
 */
object BetOdds {
    const val DX = 1.98
    const val DS = 1.98
    const val COMBO = 3.9
    const val NUMBER = 9.5

    fun of(category: BetCategory): Double = when (category) {
        BetCategory.DX -> DX
        BetCategory.DS -> DS
        BetCategory.COMBO -> COMBO
        BetCategory.NUMBER -> NUMBER
    }

    /** 组合覆盖 n 个方向时的赔率 */
    fun comboOdds(coverCount: Int): Double = when {
        coverCount <= 1 -> 3.9
        coverCount == 2 -> 1.9
        else -> 1.0
    }
}

/** PKS 位置名 */
object PksPositions {
    val NAMES = listOf("冠军", "亚军") + (3..10).map { "第${it}" }

    fun nameAt(index: Int): String = NAMES.getOrElse(index) { "第${index + 1}" }
}

/**
 * 挂机策略(UI 层使用,与 BotConfigEntity 对应)。
 */
data class BotConfig(
    val enabled: Boolean = false,
    val sourceType: String = "algo",
    val sourceId: String = "experience",
    val categories: Set<String> = setOf("大小", "单双"),
    val numberPosition: Int = 0,
    val amount: Double = 10.0,
    // 倍投配置(1.0 = 关闭)
    val winMult: Double = 1.0,
    val lossMult: Double = 1.0,
    val winMultPeriods: Int = 1,
    val lossMultPeriods: Int = 1,
    val maxMult: Int = 1,
    /** forward=正投 / reverse=反投（数字不取反） */
    val betMode: String = "forward"
)

/**
 * 挂机收益与对错统计。
 */
data class BetStats(
    // 收益
    val initialBalance: Double = 10000.0,
    val balance: Double = 10000.0,
    val totalProfit: Double = 0.0,
    val totalBet: Double = 0.0,
    val profitRate: Double = 0.0,          // 累计盈亏 / 初始资金
    // 胜率
    val totalSettled: Int = 0,
    val winCount: Int = 0,
    val loseCount: Int = 0,
    val winRate: Double = 0.0,
    // 本期
    val currentBetAmount: Double = 0.0,    // 本期下注总本金
    val currentProfit: Double = 0.0,       // 本期结算净盈亏
    // 按分类对错
    val byCategory: Map<String, CatBetStats> = emptyMap(),
    // 收益曲线(时序,按结算先后)
    val profitCurve: List<ProfitPoint> = emptyList(),
    // 最大回撤
    val maxDrawdown: Double = 0.0,         // 最大回撤金额(从峰值到谷底)
    val maxDrawdownPct: Double = 0.0,      // 最大回撤百分比
    val peakProfit: Double = 0.0,          // 累计收益峰值
    // 最长连对/连错区间(曲线上标注用)
    val maxHitStreak: Int = 0,             // 最长连对次数
    val maxMissStreak: Int = 0             // 最长连错次数
) {
    val effectiveBalance: Double get() = balance + currentProfit - currentBetAmount
}

data class CatBetStats(
    val catName: String,
    val settled: Int = 0,
    val hit: Int = 0,
    val miss: Int = 0,
    val winRate: Double = 0.0,
    /** 该分类累计盈亏(已结算) */
    val profit: Double = 0.0,
    val recentStreak: Int = 0,              // 正=连对,负=连错
    val maxHitStreak: Int = 0,
    val maxMissStreak: Int = 0,
    /** 两期滚动窗口:窗口内至少 1 次中 = 两期对(按注口径,与 hit/miss 一致) */
    val twoWindows: Int = 0,
    val twoHitRate: Double = 0.0,
    val twoMissRate: Double = 0.0,
    /** 三期滚动窗口:窗口内至少 1 次中 = 三期对 */
    val threeWindows: Int = 0,
    val threeHitRate: Double = 0.0,
    val threeMissRate: Double = 0.0
) {
    val hitRateStr: String
        get() = if (settled == 0) "-" else "%.1f%%".format(winRate * 100)
}

/**
 * 收益曲线数据点(每期结算后一个点)。
 */
data class ProfitPoint(
    val issueIndex: Int,          // 时序索引(0 开始)
    val issue: String,            // 期号
    val cumulativeProfit: Double, // 累计收益
    val hit: Boolean,             // 该期是否命中
    val drawdown: Double,         // 从历史峰值回撤金额
    val drawdownPct: Double       // 回撤百分比
)

/**
 * 钱包视图。
 */
data class WalletView(
    val initialBalance: Double = 10000.0,
    val balance: Double = 10000.0,
    val totalProfit: Double = 0.0,
    val totalBet: Double = 0.0,
    val winCount: Int = 0,
    val loseCount: Int = 0
)

/**
 * 下注订单视图(UI 层使用,与 BetEntity 对应)。
 */
data class BetView(
    val id: Long,
    val issue: String,
    val sourceLabel: String,
    val category: String,
    val betValue: String,
    val amount: Double,
    val odds: Double,
    val status: String,
    val profit: Double,
    val createdAt: Long,
    val settledAt: Long? = null
)
