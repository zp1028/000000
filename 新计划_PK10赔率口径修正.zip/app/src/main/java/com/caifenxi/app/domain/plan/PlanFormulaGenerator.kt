package com.caifenxi.app.domain.plan

import com.caifenxi.app.domain.model.LotteryType
import com.caifenxi.app.domain.model.PlanDefinition
import com.caifenxi.app.domain.model.PlanHitCriteria
import com.caifenxi.app.domain.model.PlanOutputFormat
import com.caifenxi.app.domain.model.LotteryPlayCatalog
import kotlin.math.absoluteValue

/**
 * 计划公式生成器：模板 + 种子 → 计划实例（可复现 / 可换一批）。
 * seedIssue 锚定期号时，同彩种同期生成结果一致；salt 变化则换一套。
 */
object PlanFormulaGenerator {

    private val algos = listOf("FREQ", "EWMA", "MKV1", "RHYTHM", "STATE", "SIMILAR", "STRUCT")
    private val windows = listOf(10, 15, 20, 30, 40, 50, 80, 100)

    /**
     * @param count 生成条数
     * @param seedIssue 期号锚（空则用 salt 纯随机感）
     * @param salt 点击「换一批」时递增
     */
    fun generate(
        type: LotteryType,
        count: Int = 20,
        seedIssue: String = "",
        salt: Int = 0
    ): List<PlanDefinition> {
        val plays = LotteryPlayCatalog.plays(type)
        if (plays.isEmpty()) return emptyList()
        val n = count.coerceIn(1, 100)
        val base = (seedIssue.hashCode().toLong().absoluteValue + salt * 9973L + type.name.hashCode())
        val rnd = java.util.Random(base)
        val out = ArrayList<PlanDefinition>(n)
        repeat(n) { i ->
            val play = plays[rnd.nextInt(plays.size)]
            val algo = algos[rnd.nextInt(algos.size)]
            val window = windows[rnd.nextInt(windows.size)]
            val pos = when (play.id) {
                "球大小", "球单双", "定位" -> rnd.nextInt(6)
                "龙虎" -> rnd.nextInt(3)
                "位置", "名次大小", "名次单双" -> rnd.nextInt(10)
                else -> -1
            }
            val id = "NOVA-GEN-${type.name}-$seedIssue-$salt-$i"
            val name = "${play.label}·$algo·${window}期" + if (pos >= 0) "·位${pos + 1}" else ""
            out += PlanDefinition(
                planId = id,
                planName = name,
                category = "GEN-${type.name}",
                algorithm = algo,
                window = window,
                playType = play.id,
                positionIndex = pos,
                outputFormat = if (play.isDirection) PlanOutputFormat.DIRECTION else PlanOutputFormat.NUMBER_SCORES,
                hitCriteria = if (play.isDirection) PlanHitCriteria.DIRECTION_MATCH else PlanHitCriteria.TOP20_HIT,
                baselineValue = when (play.id) {
                    "组合" -> 0.25
                    "定位", "数字", "三军", "鱼虾蟹" -> 0.2
                    "长牌" -> 0.15
                    else -> 0.50
                },
                participateConsensus = play.isDirection,
                participateCombo = play.id == "组合",
                randomGenerated = true,
                seedIssue = seedIssue
            )
        }
        return out
    }
}
