package com.caifenxi.app.service

import android.webkit.WebView
import com.caifenxi.app.domain.execution.BetAction
import com.caifenxi.app.domain.execution.BetCommand
import com.caifenxi.app.domain.execution.ExecutionResult
import com.caifenxi.app.domain.execution.Executor
import com.caifenxi.app.util.RuntimeLog

/**
 * WebView 统一执行器（接入 ExecutorManager，与无障碍共用同一套 BetCommand）。
 *
 * 由宿主 UI（内置网页执行页/WebView Activity）在拿到 WebView 后调用 [attach] 激活；
 * [detach] 后 isAvailable=false，ExecutorManager 自动回落到无障碍执行器。
 */
object WebViewExecutor : Executor {

    override val id: String = "webview"

    @Volatile
    private var executor: WebViewBetExecutor? = null

    @Volatile
    override var isAvailable: Boolean = false
        private set

    /** 宿主页面将 WebView 注入执行器（onPageFinished 后调用最佳） */
    fun attach(webView: WebView) {
        val ex = WebViewBetExecutor()
        ex.initWebView(webView)
        executor = ex
        isAvailable = true
        RuntimeLog.info("Execution", "WebView 执行器已就绪")
    }

    fun detach() {
        try {
            executor?.clearWebView()
        } catch (_: Exception) {
        }
        executor = null
        isAvailable = false
        RuntimeLog.info("Execution", "WebView 执行器已断开")
    }

    override fun execute(command: BetCommand, onResult: (ExecutionResult) -> Unit): Boolean {
        val ex = executor ?: run {
            RuntimeLog.warn("Execution", "WebView 未注入，cmdId=${command.cmdId} 拒绝受理")
            onResult(
                ExecutionResult.fail(
                    command.cmdId,
                    ExecutionResult.WEBVIEW_DISCONNECTED,
                    "WebView 未连接"
                )
            )
            return false
        }
        val dx = command.bets.firstOrNull { it.category == BetAction.CAT_DX }?.value
            ?.takeIf { it == "大" || it == "小" }
        val ds = command.bets.firstOrNull { it.category == BetAction.CAT_DS }?.value
            ?.takeIf { it == "单" || it == "双" }
        val combo = command.bets.firstOrNull { it.category == BetAction.CAT_COMBO }?.value
            ?.takeIf { it in listOf("大单", "大双", "小单", "小双") }
        val predNumbers = command.bets
            .filter { it.category == BetAction.CAT_NUMBER }
            .map { it.value }
            .filter { it.toIntOrNull() != null }
            .distinct()
            .take(20)
        RuntimeLog.info(
            "Execution",
            "WebView 受理 cmdId=${command.cmdId} 彩种=${command.lotteryKey} 期号=${command.issue}"
        )
        val accepted = ex.executeWebViewBet(dx, ds, command.amountText, combo, predNumbers)
        if (!accepted) {
            onResult(
                ExecutionResult.fail(
                    command.cmdId,
                    ExecutionResult.WEBVIEW_DISCONNECTED,
                    "WebView 指令投递失败"
                )
            )
        }
        // WebView 执行结果回传依赖网页端 Bridge（后续阶段），这里先按受理返回。
        return accepted
    }

    override fun cancel(cmdId: String) {
        RuntimeLog.info("Execution", "WebView 取消 cmdId=$cmdId（忽略，需 Bridge 支持）")
    }

    override fun queryState(cmdId: String): ExecutionResult? = null
}
