package com.caifenxi.app.domain.execution

import android.content.Context

/**
 * 网页点击识别配置：自定义玩法文字 + 可选点击区域（相对屏幕百分比）。
 * 配置后脚本只匹配这些文字，并只在区域内点选。
 */
object ClickMatchConfig {

    private const val PREFS = "click_match_config"

    data class Profile(
        /** 逻辑键 → 页面真实按钮文字 */
        val labelBig: String = "大",
        val labelSmall: String = "小",
        val labelOdd: String = "单",
        val labelEven: String = "双",
        /** 是否启用区域限制 */
        val regionEnabled: Boolean = false,
        /** 相对视口百分比 0~100 */
        val regionLeft: Int = 0,
        val regionTop: Int = 15,
        val regionRight: Int = 100,
        val regionBottom: Int = 90
    ) {
        fun mapLabel(logical: String): String = when (logical.trim()) {
            "大" -> labelBig.ifBlank { "大" }
            "小" -> labelSmall.ifBlank { "小" }
            "单" -> labelOdd.ifBlank { "单" }
            "双" -> labelEven.ifBlank { "双" }
            else -> logical
        }
    }

    @Volatile
    private var cached: Profile? = null

    fun load(context: Context): Profile {
        cached?.let { return it }
        val sp = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return Profile(
            labelBig = sp.getString("label_big", "大") ?: "大",
            labelSmall = sp.getString("label_small", "小") ?: "小",
            labelOdd = sp.getString("label_odd", "单") ?: "单",
            labelEven = sp.getString("label_even", "双") ?: "双",
            regionEnabled = sp.getBoolean("region_enabled", false),
            regionLeft = sp.getInt("region_left", 0).coerceIn(0, 100),
            regionTop = sp.getInt("region_top", 15).coerceIn(0, 100),
            regionRight = sp.getInt("region_right", 100).coerceIn(0, 100),
            regionBottom = sp.getInt("region_bottom", 90).coerceIn(0, 100)
        ).also { cached = it }
    }

    fun save(context: Context, profile: Profile) {
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("label_big", profile.labelBig.trim().ifBlank { "大" })
            .putString("label_small", profile.labelSmall.trim().ifBlank { "小" })
            .putString("label_odd", profile.labelOdd.trim().ifBlank { "单" })
            .putString("label_even", profile.labelEven.trim().ifBlank { "双" })
            .putBoolean("region_enabled", profile.regionEnabled)
            .putInt("region_left", profile.regionLeft.coerceIn(0, 100))
            .putInt("region_top", profile.regionTop.coerceIn(0, 100))
            .putInt("region_right", profile.regionRight.coerceIn(0, 100))
            .putInt("region_bottom", profile.regionBottom.coerceIn(0, 100))
            .apply()
        cached = profile
    }

    fun clearCache() {
        cached = null
    }
}
